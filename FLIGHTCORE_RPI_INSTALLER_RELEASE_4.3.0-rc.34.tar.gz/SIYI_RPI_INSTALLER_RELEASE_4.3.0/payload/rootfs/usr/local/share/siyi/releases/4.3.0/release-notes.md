# FlightCore 4.3.0 RC34

Canonical machine identity: `4.3.0-rc.34`. Build: `20260821.223000-34c7e19`.

RC34 prevents a brief Airlink interruption from turning into repeated Ground Station video teardown/reconnect cycles. It also retains the separation between lightweight Airlink health display and explicit WiFiLink camera management.

## Corrections

- Airlink source readiness is retried every two seconds while the source is unavailable; the previous retry path could wait up to thirty seconds.
- A transient WebRTC `disconnected` state receives a five-second grace period; a real `failed` state still recovers immediately.
- Buffer, backlog and isolated freeze statistics remain visible as health warnings but no longer destroy a functioning WHEP reader.
- A decoder rebuild requires a sustained twenty-second no-frame condition and is serialized behind a sixty-second cooldown.
- The Control Center `Airlink OK` pill reads only local MediaMTX path health and never opens WiFiLink HTTP or SSH sessions.
- Air Link Camera settings probes remain explicit, single-flight, cached and negatively backed off.
- RC34 metadata consistently reports the RC34 candidate and exact build identity.

## Preserved behavior

SIYI video, telemetry, joystick, flight modes, flight-control authority, Flight Logs, cloud compatibility and log-storage controls are unchanged. WiFiLink firmware, Wi-Fi profiles, router settings and network configuration are not modified.

## Acceptance boundary

Factory validation covers exact RC33 upgrade identity, all retained clean historical upgrade routes, fresh-install packaging, JavaScript/Python/shell syntax, health/management isolation, serialized recovery and immutable manifests. Physical acceptance must confirm: reader return within three seconds of MediaMTX source readiness, Android picture within five seconds, no Ground Station reload, and zero unintended `gs_wifilink` reader drops during a thirty-minute soak.
