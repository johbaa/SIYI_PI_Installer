#!/bin/bash
set -e

apt_lock_guard() {
  echo "=== APT LOCK GUARD ==="

  sudo systemctl stop packagekit 2>/dev/null || true
  sudo systemctl mask packagekit 2>/dev/null || true

  for i in $(seq 1 60); do
    if sudo fuser /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/lib/apt/lists/lock >/dev/null 2>&1; then
      echo "[APT_LOCK] waiting ${i}/60..."
      sleep 3
    else
      break
    fi
  done

  if sudo fuser /var/lib/dpkg/lock-frontend /var/lib/dpkg/lock /var/lib/apt/lists/lock >/dev/null 2>&1; then
    echo "[APT_LOCK] ERROR: apt/dpkg lock still held"
    ps aux | grep -Ei "apt|dpkg|packagekit|unattended" | grep -v grep || true
    exit 1
  fi

  sudo dpkg --configure -a
}

apt_lock_guard


echo "=== SIYI Public Installer ==="

sudo apt update
sudo apt-get install -y \
  python3 \
  python3-venv \
  python3-pip \
  network-manager \
  iproute2 \
  psmisc \
  jq \
  git \
  meson \
  ninja-build \
  pkg-config \
  gcc \
  g++ \
  libsystemd-dev \
  systemd-dev \
  iptables \
  curl \
  systemd-dev \
  curl


echo "=== Install ZeroTier ==="
apt_lock_guard
if ! command -v zerotier-cli >/dev/null 2>&1; then
  curl -s https://install.zerotier.com | sudo bash
fi
sudo systemctl enable zerotier-one
sudo systemctl start zerotier-one

echo "=== Copy config ==="
cp config/siyi-config.json /home/pi/siyi-config.json
cp config/button_map.csv /home/pi/button_map.csv

echo "=== Copy scripts ==="
sudo cp scripts/siyi-battery-cache.py /home/pi/siyi-battery-cache.py
sudo chmod +x /home/pi/siyi-battery-cache.py
cp scripts/siyi_mav_button_bridge.py /home/pi/siyi_mav_button_bridge.py
cp scripts/siyi_tcp_proxy_inject.py /home/pi/siyi_tcp_proxy_inject.py
chmod +x /home/pi/siyi_mav_button_bridge.py /home/pi/siyi_tcp_proxy_inject.py

echo "=== Copy webui ==="
rm -rf /home/pi/siyi-webui
mkdir -p /home/pi/siyi-webui
cp -a webui/. /home/pi/siyi-webui/

echo "=== Configure camera eth0 ==="
sudo nmcli connection delete cam-eth0 2>/dev/null || true
sudo nmcli connection add type ethernet ifname eth0 con-name cam-eth0 ipv4.addresses $(jq -r .camera_eth_ip /home/pi/siyi-config.json 2>/dev/null || echo 192.168.144.20/24) ipv4.method manual ipv6.method ignore
sudo nmcli connection up cam-eth0 || true

echo "=== Python venv ==="
python3 -m venv /home/pi/siyi-bridge-venv
/home/pi/siyi-bridge-venv/bin/pip install --upgrade pip
/home/pi/siyi-bridge-venv/bin/pip install pymavlink numpy future pyserial

echo "=== Copy services ==="
sudo cp services/siyi-webui.service /etc/systemd/system/
sudo cp services/siyi-rec-proxy.service /etc/systemd/system/
sudo cp services/siyi-button-bridge.service /etc/systemd/system/
sudo cp services/siyi-battery-cache.service /etc/systemd/system/
sudo cp services/mavlink-router.service /etc/systemd/system/ 2>/dev/null || true

echo "=== MAVLink config ==="
sudo mkdir -p /etc/mavlink-router
sudo tee /etc/mavlink-router/main.conf >/dev/null <<'EOL'
[General]
TcpServerPort=5760
ReportStats=false

[UartEndpoint fc]
Device=/dev/serial0
Baud=57600

[UdpEndpoint button_safety]
Mode=Normal
Address=127.0.0.1
Port=14600

[UdpEndpoint webui_status_monitor]
Mode=Normal
Address=127.0.0.1
Port=14601
EOL



echo "=== Install endpoint apply script ==="
cp scripts/apply_siyi_endpoints.sh /home/pi/apply_siyi_endpoints.sh
chmod +x /home/pi/apply_siyi_endpoints.sh
chown pi:pi /home/pi/apply_siyi_endpoints.sh


echo "=== Install REC redirect service ==="
sudo cp services/siyi-rec-redirect.service /etc/systemd/system/siyi-rec-redirect.service
sudo chmod 644 /etc/systemd/system/siyi-rec-redirect.service
sudo systemctl daemon-reload
sudo systemctl enable siyi-rec-redirect.service
sudo systemctl restart siyi-rec-redirect.service
\
echo "=== Install camera time sync ==="
sudo cp scripts/siyi_set_camera_time.sh /usr/local/bin/siyi_set_camera_time.sh
sudo chmod +x /usr/local/bin/siyi_set_camera_time.sh
sudo cp scripts/siyi_proxy_socket_time_sync.sh /usr/local/bin/siyi_proxy_socket_time_sync.sh
sudo chmod +x /usr/local/bin/siyi_proxy_socket_time_sync.sh
sudo cp scripts/siyi_direct_camera_time_sync.py /usr/local/bin/siyi_direct_camera_time_sync.py
sudo chmod +x /usr/local/bin/siyi_direct_camera_time_sync.py
sudo cp scripts/siyi_verified_camera_time_sync.sh /usr/local/bin/siyi_verified_camera_time_sync.sh
sudo chmod +x /usr/local/bin/siyi_verified_camera_time_sync.sh
sudo cp services/siyi-camera-time-sync.service /etc/systemd/system/siyi-camera-time-sync.service
sudo chmod 644 /etc/systemd/system/siyi-camera-time-sync.service
sudo systemctl daemon-reload
sudo systemctl enable siyi-camera-time-sync.service

echo "=== Enable services ==="

# Install button bridge startup ordering override.
# This lets the public installer work before ZeroTier is configured:
# the bridge will keep retrying until a zt* interface exists, then start automatically.
sudo mkdir -p /etc/systemd/system/siyi-button-bridge.service.d
sudo cp systemd-overrides/siyi-button-bridge.service.d/wait-for-zt.conf /etc/systemd/system/siyi-button-bridge.service.d/wait-for-zt.conf

sudo systemctl daemon-reload
sudo systemctl enable siyi-webui
sudo systemctl enable siyi-rec-proxy
sudo systemctl enable siyi-button-bridge
sudo systemctl enable siyi-battery-cache

if ! command -v mavlink-routerd >/dev/null 2>&1; then
  echo "=== Build mavlink-router ==="
  rm -rf /home/pi/mavlink-router-build
  git clone https://github.com/mavlink-router/mavlink-router.git /home/pi/mavlink-router-build
  cd /home/pi/mavlink-router-build
  git submodule update --init --recursive
  meson setup build .
  ninja -C build
  sudo ninja -C build install
  cd /home/pi
fi

sudo systemctl enable mavlink-router

sudo systemctl restart siyi-webui

echo "=== Start REC proxy before verified camera time sync ==="
sudo systemctl restart siyi-rec-proxy
sleep 3

echo "=== Proxy socket camera time sync ==="
sudo /usr/local/bin/siyi_proxy_socket_time_sync.sh

echo "=== Restart MAVLink router before button bridge ==="
sudo systemctl reset-failed mavlink-router.service siyi-button-bridge.service || true
sudo systemctl restart mavlink-router
sudo systemctl restart siyi-battery-cache
sleep 3

echo "=== Start button bridge last ==="
sudo systemctl restart siyi-button-bridge




echo "=== Install MediaMTX ==="
ARCH="$(uname -m)"
case "$ARCH" in
  aarch64) ASSET="linux_arm64.tar.gz" ;;
  armv7l|armv6l) ASSET="linux_armv7.tar.gz" ;;
  *) echo "Unsupported arch"; exit 1 ;;
esac

URL=$(curl -s https://api.github.com/repos/bluenviron/mediamtx/releases/latest | jq -r '.assets[].browser_download_url' | grep $ASSET | head -n1)

rm -rf /tmp/mediamtx
mkdir -p /tmp/mediamtx
cd /tmp/mediamtx
curl -L $URL -o mediamtx.tar.gz
tar -xzf mediamtx.tar.gz

sudo cp mediamtx /usr/local/bin/

sudo mkdir -p /usr/local/etc/mediamtx
sudo tee /usr/local/etc/mediamtx/mediamtx.yml >/dev/null <<EOF
logLevel: info
rtspAddress: :8554
rtspTransports: [tcp]

paths:
  main.264:
    source: rtsp://192.168.144.25:8554/main.264
    sourceProtocol: tcp
    sourceOnDemand: yes
EOF

sudo tee /etc/systemd/system/mediamtx.service >/dev/null <<EOF
[Unit]
Description=MediaMTX RTSP relay
After=network.target

[Service]
ExecStart=/usr/local/bin/mediamtx /usr/local/etc/mediamtx/mediamtx.yml
Restart=always

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable mediamtx
sudo systemctl restart mediamtx


echo "=== RTSP Redirect ==="
sudo sysctl -w net.ipv4.ip_forward=1

sudo iptables -t nat -A PREROUTING -i zt+ -d 192.168.144.25 -p tcp --dport 8554 -j REDIRECT --to-ports 8554
sudo iptables -t nat -A PREROUTING -i wlan0 -d 192.168.144.25 -p tcp --dport 8554 -j REDIRECT --to-ports 8554

sudo tee /etc/systemd/system/siyi-rtsp-redirect.service >/dev/null <<EOF
[Unit]
Description=RTSP redirect
After=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/sh -c 'iptables -t nat -A PREROUTING -i zt+ -d 192.168.144.25 -p tcp --dport 8554 -j REDIRECT --to-ports 8554; iptables -t nat -A PREROUTING -i wlan0 -d 192.168.144.25 -p tcp --dport 8554 -j REDIRECT --to-ports 8554'

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl enable siyi-rtsp-redirect
sudo systemctl start siyi-rtsp-redirect


echo

echo
cat <<EOF

========================================
✅ SIYI INSTALL COMPLETE
========================================

=== OPEN WEB UI ===
http://$(hostname -I | tr " " "\n" | grep -E "^192\.168\.0\." | head -n1):8080

👉 Use WiFi IP for local access and configure Zero Tier and Hosts
EOF

