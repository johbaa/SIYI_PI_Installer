# FlightCore 4.3.0 RC30

Canonical machine identity: `4.3.0-rc.30`. Build: `20260821.111225-30b7e41`.

RC30 combines Flight Log storage controls with a coordinated Airlink recovery fix. Its exact parent is clean RC29 build `20260820.201500-29d9a23`.

## Flight Log storage controls

- Operators can delete a flight from local storage, cloud storage, or both, with confirmation and audit logging.
- A configurable 0.25–48 GiB local quota prevents Flight Logs from filling the Raspberry Pi SD card.
- Automatic cleanup removes only the oldest completed logs that have an exact successful cloud receipt.
- Active, incomplete, pending, failed, unsynchronized and unverified logs are protected.
- Deletion is disarmed-only.

## Coordinated Airlink recovery

- One serialized recovery manager owns Airlink WebRTC recovery.
- MediaMTX source readiness is verified before a WHEP session is created.
- WHEP requests use bounded timeouts, cancellation and stale-generation protection.
- Retries use controlled 2, 4, 8, 15 and 30 second backoff; manual Resync starts a clean attempt.
- An Airlink outage remains isolated to the Airlink pane. SIYI video, telemetry, joystick/control paths and flight-controller failsafe authority continue independently.
- Recovery events are journaled without starting another recovery loop.

## Safety and compatibility

The recovery layer does not issue RTL, SET_MODE or other flight commands and does not reload the Ground Station page. Exact RC6/Factory V71 and exact clean RC17 through RC29 sources, plus genuinely fresh installation, remain supported.

## Acceptance status

Factory automation covers packaging, API contracts, deterministic fixtures and control-path isolation. Physical upgrade, Android recovery, forced Airlink interruption, SIYI continuity and flight acceptance remain explicit external gates.
