#!/usr/bin/env bash
set -Eeuo pipefail
REQUIRE_FC=0
FC_ONLY=0
PRE_REBOOT=0
JSON_OUT=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    --require-fc) REQUIRE_FC=1; shift ;;
    --fc-only) FC_ONLY=1; REQUIRE_FC=1; shift ;;
    --pre-reboot) PRE_REBOOT=1; shift ;;
    --json-output) JSON_OUT="${2:-}"; shift 2 ;;
    *) echo "Unknown health option: $1" >&2; exit 2 ;;
  esac
done
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
META="$SCRIPT_DIR/release-metadata.json"
[ -f "$META" ] || META=/usr/local/share/siyi/releases/4.2.0/release-metadata.json
[ -f "$META" ] || { echo "HEALTH CHECK FAILED: release_metadata_missing" >&2; exit 1; }
readarray -t EXPECTED < <(python3 - "$META" <<'PYMETA'
import json,sys
m=json.load(open(sys.argv[1],encoding='utf-8'))
print(str(m['version']).strip())
print(str(m['build_id']).strip())
PYMETA
)
EXPECTED_VERSION="${EXPECTED[0]}"
EXPECTED_BUILD="${EXPECTED[1]}"
failures=()
notices=()
port_listening(){ ss -lntupH 2>/dev/null | awk '{print $5}' | grep -Eq "(^|:)$1$"; }
url_ok(){ curl -fsS -L --max-time 8 "$1" >/dev/null; }
service_ok(){ systemctl is-active --quiet "$1"; }
read_marker(){ local p="$1"; [ -r "$p" ] || return 1; tr -d '[:space:]' <"$p"; }
fc_probe(){
  /home/pi/siyi-bridge-venv/bin/python - <<'PYFC'
import json,time
from pymavlink import mavutil
result={'genuine_heartbeats':0,'sources':[],'messages':0,'error':None}
try:
    c=mavutil.mavlink_connection('tcp:127.0.0.1:5760',source_system=253,source_component=191,autoreconnect=False)
    end=time.time()+10; sources=set()
    while time.time()<end:
        m=c.recv_match(blocking=True,timeout=0.5)
        if m is None: continue
        result['messages']+=1
        if m.get_type()!='HEARTBEAT': continue
        sysid=int(m.get_srcSystem() or 0); compid=int(m.get_srcComponent() or 0)
        mtype=int(getattr(m,'type',-1)); autopilot=int(getattr(m,'autopilot',-1))
        if sysid>0 and mtype!=int(mavutil.mavlink.MAV_TYPE_GCS) and autopilot!=int(mavutil.mavlink.MAV_AUTOPILOT_INVALID):
            result['genuine_heartbeats']+=1; sources.add(f'{sysid}:{compid}')
    result['sources']=sorted(sources)
except Exception as exc: result['error']=str(exc)
print(json.dumps(result,sort_keys=True))
raise SystemExit(0 if result['genuine_heartbeats']>=2 and result['messages']>=3 else 1)
PYFC
}
if [ "$FC_ONLY" -eq 0 ]; then
  actual_version="$(read_marker /etc/siyi/release_version 2>/dev/null || true)"
  actual_build="$(read_marker /etc/siyi/release_build 2>/dev/null || true)"
  [ "$actual_version" = "$EXPECTED_VERSION" ] || failures+=("release_version")
  [ "$actual_build" = "$EXPECTED_BUILD" ] || failures+=("release_build")
  command -v mediamtx >/dev/null || failures+=("mediamtx_missing")
  command -v mavlink-routerd >/dev/null || failures+=("mavlink_router_missing")
  command -v espeak-ng >/dev/null || failures+=("espeak_ng_missing")
  if command -v mediamtx >/dev/null; then mediamtx --version 2>&1 | grep -Fq 'v1.12.2' || failures+=("mediamtx_version"); fi
  if command -v mavlink-routerd >/dev/null; then mavlink-routerd --version 2>&1 | grep -Fq 'v4-16-g2362c62' || failures+=("mavlink_router_version"); fi
  cmdline=""; for p in /boot/firmware/cmdline.txt /boot/cmdline.txt; do [ ! -f "$p" ] || { cmdline="$p"; break; }; done
  [ -n "$cmdline" ] || failures+=("boot_cmdline_missing")
  if [ -n "$cmdline" ] && grep -Eq '(^| )(console=(serial0|ttyS0|ttyAMA0),[^ ]+)' "$cmdline"; then failures+=("serial_console_conflict"); fi
  if [ "$PRE_REBOOT" -eq 0 ]; then
    [ -e /dev/serial0 ] || failures+=("serial0_missing")
    for unit in NetworkManager.service zerotier-one.service mavlink-router.service mediamtx.service siyi-battery-cache.service siyi-button-bridge.service siyi-groundstation.service siyi-joystickd.service siyi-paramd.service siyi-rec-proxy.service siyi-rec-redirect.service siyi-rtsp-redirect.service siyi-telemetry-canvas.service siyi-video-dual.service siyi-video-source.service siyi-webui.service; do
      service_ok "$unit" || failures+=("service:$unit")
    done
    for port in 5760 8080 8554 9997; do port_listening "$port" || failures+=("port:$port"); done
    url_ok http://127.0.0.1:8080/health || failures+=("url:webui_health")
    url_ok http://127.0.0.1:8080/groundstation || failures+=("url:groundstation")
    url_ok http://127.0.0.1:8080/parameters || failures+=("url:parameters")
    url_ok http://127.0.0.1:9997/v3/paths/list || failures+=("url:mediamtx_api")
  fi
fi
fc_json=""
if [ "$PRE_REBOOT" -eq 0 ]; then
  set +e; fc_json="$(fc_probe 2>/dev/null)"; fc_rc=$?; set -e
  if [ "$fc_rc" -ne 0 ]; then
    if [ "$REQUIRE_FC" -eq 1 ]; then failures+=("genuine_fc_heartbeat"); else notices+=("genuine_fc_heartbeat_not_verified"); fi
  fi
fi
if [ -n "$JSON_OUT" ]; then
  python3 - "$JSON_OUT" "${failures[*]}" "${notices[*]}" "$fc_json" <<'PYJSON'
import datetime,json,os,sys,tempfile
path,failures,notices,fc=sys.argv[1:]
data={'captured_at':datetime.datetime.now().astimezone().isoformat(timespec='seconds'),'ok':not bool(failures.strip()),'failures':failures.split() if failures.strip() else [],'notices':notices.split() if notices.strip() else []}
try: data['fc_probe']=json.loads(fc) if fc else None
except Exception: data['fc_probe']={'raw':fc}
os.makedirs(os.path.dirname(path),exist_ok=True)
fd,tmp=tempfile.mkstemp(prefix='.health.',dir=os.path.dirname(path))
with os.fdopen(fd,'w',encoding='utf-8') as f: json.dump(data,f,indent=2); f.write('\n')
os.chmod(tmp,0o644); os.replace(tmp,path)
PYJSON
fi
if [ "${#notices[@]}" -gt 0 ]; then printf 'NOTICE: %s\n' "${notices[@]}"; fi
if [ "${#failures[@]}" -gt 0 ]; then printf 'HEALTH CHECK FAILED: %s\n' "${failures[*]}" >&2; exit 1; fi
echo "HEALTH CHECK PASSED"
