# SIYI 4.2.0 physical acceptance checklist

## Installation
- [ ] Fresh Raspberry Pi OS 64-bit / Debian 13, no `/etc/siyi`.
- [ ] Local release installation finishes and reboots without manual marker creation.
- [ ] `/etc/siyi/release_version` is `4.2.0` and build is `SIYI_4_2_0_BASELINE_V6`.
- [ ] No serial-console token remains; `/dev/serial0` exists; TCP 5760 listens.
- [ ] `sudo siyi-acceptance-test` passes with a genuine FC heartbeat.

## Feature parity
- [ ] Main WebUI, first setup and all workspace pages.
- [ ] Ground Station fly view, main video, camera/video/map PiP and split view.
- [ ] Full HUD, round HUD, home marker and telemetry groups.
- [ ] Phone/desktop-specific geometry persistence across refresh and reboot.
- [ ] Parameter browser, metadata, grouping, read/write and import.
- [ ] SIYI camera, WiFiLink2, MediaMTX, redirects and dual video.
- [ ] Gimbal movement, presets, zoom and native recording indication.
- [ ] Joystick axes, button mappings, safety and 50 Hz WebSocket transport.
- [ ] 20 taps and 5 holds per action button: zero false holds and duplicates.
- [ ] Network jitter cannot convert a released tap into a hold.
- [ ] Continuous control stops on release, cancel, timeout and WebSocket loss.
- [ ] Connectivity page can switch between saved Pi Wi-Fi profiles.
- [ ] Reboot persistence repeated at least twice.

## Release progression
- [ ] A second independent fresh installation produces the same target state.
- [ ] Failure injection never reports success after checksum, dependency or health failure.
- [ ] Only after acceptance: publish 4.2.0 as stable.
- [ ] 4.2.1 must test fresh installation and upgrade from the genuine released 4.2.0.
