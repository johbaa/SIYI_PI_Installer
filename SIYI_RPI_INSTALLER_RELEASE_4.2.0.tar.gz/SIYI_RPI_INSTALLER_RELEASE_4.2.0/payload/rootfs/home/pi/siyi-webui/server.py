# SIYI_RELEASE_4_1_0_AUTHORITATIVE_LIVE_BASELINE
import threading
import datetime
import math

# === CONFIG LOAD ===
import json
from email.utils import parsedate_to_datetime
from zoneinfo import ZoneInfo
try:
    with open("/home/pi/siyi-config.json") as cf:
        CFG = json.load(cf)
except Exception:
    CFG = {}

CAM_IP = CFG.get("camera_ip", "192.168.144.25")
QGC_HOSTS = CFG.get("qgc_hosts", [])
VIDEO_PORT = CFG.get("video_port", 5600)
# === END CONFIG ===

RELEASE_VERSION_FILE = "/etc/siyi/release_version"

def get_release_version():
    try:
        with open(RELEASE_VERSION_FILE, "r", encoding="utf-8") as f:
            v = f.read().strip()
        return v if v else "unknown"
    except Exception:
        return "unknown"

VERSION = get_release_version()


# === SOFTWARE_UPDATE_V3 ===
SOFTWARE_UPDATE_MANIFEST_URL = (
    "https://raw.githubusercontent.com/"
    "johbaa/SIYI_PI_Installer/main/manifest.json"
)
SOFTWARE_UPDATE_LOG_FILE = "/tmp/siyi_webui_update.log"
SOFTWARE_UPDATE_PID_FILE = "/run/siyi-github-upgrade.pid"
SOFTWARE_UPDATE_STATE_FILE = "/var/lib/siyi-upgrade/state.json"
SOFTWARE_UPDATE_LAUNCHER = "/usr/local/sbin/siyi-github-upgrade-launch"
SOFTWARE_UPDATE_PREFERENCES_FILE = "/var/lib/siyi-upgrade/preserve_preferences.json"
# SOFTWARE_UPDATE_NO_WIZARD_AFTER_UPGRADE_V1
SOFTWARE_UPDATE_COMPLETED_FILE = "/var/lib/siyi-upgrade/upgrade_completed"
SOFTWARE_UPDATE_ACTIVE_STATUSES = {
    "starting", "checking", "downloading", "verifying", "backing_up",
    "installing", "restoring", "restarting",
}
SOFTWARE_UPDATE_PRESERVE_GROUPS = (
    ("buttons", "Button assignments and safety"),
    ("flaps", "Flap configuration"),
    ("mavlink", "MAVLink router, hosts and endpoints"),
    ("camera", "Camera and core SIYI configuration"),
    ("gimbal", "Gimbal presets, zero and virtual settings"),
    ("voice", "CPU temperature voice settings"),
    ("video", "Video sources and Air Link device connection"),
)
SOFTWARE_UPDATE_DEFAULT_PRESERVE = tuple(
    key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS
)


def _software_version_tuple(value):
    value = str(value or "").strip()
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", value):
        raise ValueError("Invalid release version: " + value)
    return tuple(int(part) for part in value.split("."))


def software_update_is_newer(candidate, current):
    return _software_version_tuple(candidate) > _software_version_tuple(current)


# SOFTWARE_UPDATE_MANIFEST_CACHE_BYPASS_V1
def software_update_manifest():
    separator = "&" if "?" in SOFTWARE_UPDATE_MANIFEST_URL else "?"
    manifest_url = (
        SOFTWARE_UPDATE_MANIFEST_URL
        + separator
        + "cache_bust="
        + str(time.time_ns())
    )
    req = urllib.request.Request(
        manifest_url,
        headers={
            "User-Agent": "SIYI-Pi-Updater/4",
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
        },
    )
    with urllib.request.urlopen(req, timeout=8) as response:
        raw = response.read(65536)
    data = json.loads(raw.decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("GitHub manifest is not a JSON object")
    stable = str(data.get("stable", "")).strip()
    _software_version_tuple(stable)
    return {"stable": stable}


# SOFTWARE_UPDATE_PID_EPERM_FIX_V1
# The upgrade worker runs as root while the WebUI runs as pi. On Linux,
# os.kill(pid, 0) raises PermissionError when the process exists but the
# caller is not allowed to signal it. That means "running", not "stopped".
def software_update_pid_running():
    try:
        with open(SOFTWARE_UPDATE_PID_FILE, "r", encoding="utf-8") as f:
            pid = int(f.read().strip())
    except (OSError, ValueError):
        return False

    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def software_update_state():
    state = {
        "running": False,
        "status": "idle",
        "progress": 0,
        "stage": "No upgrade is running",
        "from_version": get_release_version(),
        "to_version": "",
        "started_at": "",
        "updated_at": "",
        "technical_log": "",
        "error": "",
    }
    state_mtime = 0.0
    try:
        state_mtime = os.path.getmtime(SOFTWARE_UPDATE_STATE_FILE)
        with open(SOFTWARE_UPDATE_STATE_FILE, "r", encoding="utf-8") as f:
            loaded = json.load(f)
        if isinstance(loaded, dict):
            state.update(loaded)
    except Exception:
        pass

    pid_running = software_update_pid_running()
    declared_running = bool(state.get("running"))
    status = str(state.get("status", "idle"))
    startup_grace = (
        declared_running
        and status == "starting"
        and state_mtime > 0
        and (time.time() - state_mtime) < 30
    )
    running = bool(pid_running or startup_grace)
    state["running"] = running

    if declared_running and not running and status in SOFTWARE_UPDATE_ACTIVE_STATUSES:
        state["status"] = "failed"
        state["progress"] = round(max(0.0, min(99.0, float(state.get("progress", 0) or 0))), 1)
        state["stage"] = "Upgrade process stopped unexpectedly"
        if not state.get("error"):
            state["error"] = "The upgrade process is no longer running."

    try:
        state["progress"] = round(max(0.0, min(100.0, float(state.get("progress", 0) or 0))), 1)
    except Exception:
        state["progress"] = 0
    for key in (
        "status", "stage", "from_version", "to_version", "started_at",
        "updated_at", "technical_log", "error",
    ):
        state[key] = str(state.get(key, "") or "")
    return state


def software_update_running():
    return bool(software_update_state().get("running"))


def software_update_lock_active():
    return software_update_running()


def software_update_log_tail(limit=30000):
    try:
        with open(SOFTWARE_UPDATE_LOG_FILE, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - limit), os.SEEK_SET)
            return f.read().decode("utf-8", errors="replace")
    except Exception:
        return "Waiting for upgrade status..."


def software_update_status_payload():
    state = software_update_state()
    state["current"] = get_release_version()
    state["log"] = software_update_log_tail()
    return state


def software_update_preserve_preferences():
    allowed = {key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS}
    try:
        with open(SOFTWARE_UPDATE_PREFERENCES_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        values = data.get("preserve", [])
        if not isinstance(values, list):
            raise ValueError("preserve is not a list")
        requested = {str(value) for value in values}
        # Preferences written before video-source support had no schema marker.
        # Preserve the new setting by default once, while still respecting a
        # deliberate unchecked choice saved by the new UI.
        if int(data.get("schema_version", 1) or 1) < 2:
            requested.add("video")
        if not requested.issubset(allowed):
            raise ValueError("unknown preservation group")
        return tuple(
            key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS
            if key in requested
        )
    except FileNotFoundError:
        return SOFTWARE_UPDATE_DEFAULT_PRESERVE
    except Exception:
        return SOFTWARE_UPDATE_DEFAULT_PRESERVE


def software_update_validate_preserve_groups(values):
    allowed = {key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS}
    requested = [str(value).strip() for value in values if str(value).strip()]
    unknown = [value for value in requested if value not in allowed]
    if unknown:
        raise ValueError("Unknown preservation option: " + ", ".join(unknown))
    requested_set = set(requested)
    return tuple(
        key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS
        if key in requested_set
    )


def software_update_page():
    current = get_release_version()
    state = software_update_state()
    running = bool(state.get("running"))
    latest = "Unavailable"
    error = ""
    update_available = False

    try:
        latest = software_update_manifest()["stable"]
        update_available = software_update_is_newer(latest, current)
    except Exception as exc:
        error = str(exc)

    if running:
        state_text = "Installation is running"
        state_class = "warn"
    elif error:
        state_text = "Could not check GitHub"
        state_class = "bad"
    elif update_available:
        state_text = "A newer published release is available"
        state_class = "ok"
    else:
        state_text = "This system is up to date"
        state_class = "ok"

    disabled = "disabled" if (running or not update_available) else ""
    button_text = "Installation running..." if running else "Install published update"
    error_html = (
        "<p class='bad'><b>GitHub check failed:</b> " + esc(error) + "</p>"
        if error else ""
    )

    selected_preferences = set(software_update_preserve_preferences())
    selectable_rows = []
    for key, label in SOFTWARE_UPDATE_PRESERVE_GROUPS:
        checked = "checked" if key in selected_preferences else ""
        selectable_rows.append(
            "<label style='display:flex;align-items:center;gap:10px;"
            "padding:7px 0;cursor:pointer;'>"
            f"<input style='pointer-events:auto;width:auto;' type='checkbox' "
            f"name='preserve' value='{esc(key)}' data-label='{esc(label)}' {checked}>"
            f"<span>{esc(label)}</span>"
            "</label>"
        )
    selectable_html = "".join(selectable_rows)

    return f"""
    <h1>Software Update</h1>

    <div class='card'>
      <h2>Published release</h2>
      <table>
        <tr><th>Current installed version</th><td><b>{esc(current)}</b></td></tr>
        <tr><th>Latest published version</th><td><b>{esc(latest)}</b></td></tr>
        <tr><th>Status</th><td class='{state_class}'><b>{esc(state_text)}</b></td></tr>
      </table>
      {error_html}
    </div>

    <form method='post' action='/software_update_start'
          data-current='{esc(current)}' data-latest='{esc(latest)}'
          onsubmit='return softwareUpdateConfirm(this);'>
      <div class='card'>
        <h2>Settings to preserve</h2>
        <p class='small'>
          Checked user settings are restored after a successful upgrade.
          Unchecked groups are reset to the defaults supplied by the new release.
          A complete safety backup is always retained for rollback.
        </p>

        <h3>Always preserved</h3>
        <label style='display:flex;align-items:center;gap:10px;padding:7px 0;opacity:.85;'>
          <input style='width:auto;' type='checkbox' checked disabled>
          <span><b>Pi Wi-Fi profiles and saved passwords</b> — Always preserved</span>
        </label>
        <label style='display:flex;align-items:center;gap:10px;padding:7px 0;opacity:.85;'>
          <input style='width:auto;' type='checkbox' checked disabled>
          <span><b>ZeroTier identity and membership</b> — Always preserved</span>
        </label>
        <label style='display:flex;align-items:center;gap:10px;padding:7px 0;opacity:.85;'>
          <input style='width:auto;' type='checkbox' checked disabled>
          <span><b>Air Link Wi-Fi profiles and camera settings</b> — Stored on Air Link and not modified by Pi upgrades</span>
        </label>

        <h3>User-selectable settings</h3>
        {selectable_html}

        <label style='display:flex;align-items:center;gap:10px;padding:12px 0;cursor:pointer;'>
          <input style='pointer-events:auto;width:auto;' type='checkbox'
                 name='remember' value='1' checked>
          <span>Remember these choices for future upgrades</span>
        </label>

        <button style='pointer-events:auto;min-width:220px;' {disabled}>{esc(button_text)}</button>

        <p class='small'>
          The button is enabled only when the GitHub version is newer than the installed version.
          The release checksum is verified before installation.
        </p>
      </div>
    </form>

    <script>
    function softwareUpdateConfirm(form){{
      const selected = Array.from(form.querySelectorAll("input[name='preserve']:checked"))
        .map(function(input){{ return input.dataset.label || input.value; }});
      let message = 'Upgrade ' + form.dataset.current + ' → ' + form.dataset.latest + '?\\n\\n';
      message += 'Always preserved:\\n• Pi Wi-Fi profiles and saved passwords\\n• ZeroTier identity and membership\\n• Air Link profiles/camera settings remain on the Air Link device\\n\\n';
      if(selected.length){{
        message += 'Also preserve:\\n• ' + selected.join('\\n• ');
      }}else{{
        message += 'No selectable user settings are selected.\\n'
          + 'Release defaults will be used for all selectable groups.';
      }}
      message += '\\n\\nThe WebUI will be locked during installation.';
      if(!confirm(message)) return false;
      if(window.siyiUpgradeShowStarting){{
        window.siyiUpgradeShowStarting(form.dataset.current, form.dataset.latest);
      }}
      return true;
    }}
    </script>
    """
# === SOFTWARE_UPDATE_V3 END ===
#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse, parse_qsl
import subprocess
import socket
socket.setdefaulttimeout(5)
from pymavlink.dialects.v20 import common as mavlink2
from pymavlink.dialects.v20 import ardupilotmega as mavlink2
import shlex, os, csv, html, time, shutil, re, json, urllib.request, urllib.parse, urllib.error, zipfile, tempfile, math

PORT=8080

BUTTON_MAP="/home/pi/button_map.csv"
MAVCONF="/etc/mavlink-router/main.conf"
VIDEO_SERVICE="/etc/systemd/system/siyi-video-dual.service"
VIDEO_SOURCE_CONFIG="/etc/siyi/video_source.json"
VIDEO_SOURCE_STATUS="/run/siyi-video-source/status.json"
VIDEO_SOURCE_CONTROL="/usr/local/sbin/siyi-video-source-control"
BACKUP_DIR="/home/pi/siyi-webui/backups"
ENDPOINTS_FILE="/etc/siyi/endpoints.json"
ZT_CONFIG_FILE="/etc/siyi/zerotier_config.json"
ZT_TOKEN_FILE="/etc/siyi/zerotier_api_token"
BUTTON_SAFETY_FILE="/etc/siyi/button_safety.json"
GIMBAL_PRESETS_FILE="/etc/siyi/gimbal_presets.json"
GIMBAL_STATE_FILE="/home/pi/siyi_gimbal_state.json"
GIMBAL_ZERO_FILE="/etc/siyi/gimbal_zero.json"
FLIGHT_SAFETY_ACTIONS=["MANUAL","FBWA","AUTOTUNE","CRUISE","AUTO","LOITER","RTL","TAKEOFF","QHOVER","QLOITER","QLAND","QRTL"]



def send_mavlink_tcp5760(pkt):
    try:
        with socket.create_connection(("127.0.0.1", 5760), timeout=0.8) as sock:
            sock.sendall(pkt)
        return True
    except Exception as e:
        print("[WEBUI_TCP5760_SEND_FAIL]", repr(e), flush=True)
        return False


# GROUND_STATION_ARM_SELECTOR_V2_8_15_BACKEND
def groundstation_airborne_evidence():
    """Return conservative airborne evidence for the DISARM safety gate."""
    state = {}
    try:
        raw = _groundstation_fetch("/state", timeout=1.2)
        loaded = json.loads(raw.decode("utf-8"))
        if isinstance(loaded, dict):
            state = loaded
    except Exception:
        state = {}

    vehicle = state.get("vehicle") if isinstance(state.get("vehicle"), dict) else {}
    position = state.get("position") if isinstance(state.get("position"), dict) else {}
    speed = state.get("speed") if isinstance(state.get("speed"), dict) else {}

    explicit_in_air = vehicle.get("in_air")
    if explicit_in_air is None:
        explicit_in_air = state.get("in_air")
    landed = vehicle.get("landed")
    if landed is None:
        landed = state.get("landed")

    def number_or_none(value):
        try:
            value = float(value)
            return value if math.isfinite(value) else None
        except Exception:
            return None

    relative_alt = number_or_none(position.get("relative_alt_m"))
    airspeed = number_or_none(speed.get("airspeed_m_s"))
    groundspeed = number_or_none(speed.get("groundspeed_m_s"))
    vertical_speed = number_or_none(speed.get("vertical_speed_m_s"))

    reasons = []
    if explicit_in_air is True:
        reasons.append("vehicle reports in air")
    if landed is False:
        reasons.append("vehicle reports not landed")
    if relative_alt is not None and relative_alt > 3.0:
        reasons.append("relative altitude %.1f m" % relative_alt)
    if (
        airspeed is not None
        and airspeed > 8.0
        and relative_alt is not None
        and relative_alt > 1.0
    ):
        reasons.append("airspeed %.1f m/s" % airspeed)
    if (
        groundspeed is not None
        and groundspeed > 8.0
        and relative_alt is not None
        and relative_alt > 1.0
    ):
        reasons.append("groundspeed %.1f m/s" % groundspeed)
    if (
        vertical_speed is not None
        and abs(vertical_speed) > 2.0
        and relative_alt is not None
        and relative_alt > 1.0
    ):
        reasons.append("vertical speed %.1f m/s" % vertical_speed)

    return {
        "airborne": bool(reasons),
        "reasons": reasons,
        "state_available": bool(state),
    }


def groundstation_send_arm_state(action):
    action = str(action or "").strip().upper()
    if action not in {"ARM", "DISARM"}:
        return {"ok": False, "error": "invalid arm action", "action": action}

    current_armed = vehicle_is_armed_now()
    requested_armed = action == "ARM"
    if current_armed == requested_armed:
        return {
            "ok": True,
            "noop": True,
            "action": action,
            "armed": current_armed,
        }

    if action == "DISARM":
        safety = read_button_safety_config()
        if bool(safety.get("block_disarm_in_air", True)):
            evidence = groundstation_airborne_evidence()
            if evidence.get("airborne"):
                return {
                    "ok": False,
                    "blocked": True,
                    "error": "Safety block: DISARM disabled while aircraft appears airborne",
                    "action": action,
                    "evidence": evidence.get("reasons", []),
                }

    # Normal MAV_CMD_COMPONENT_ARM_DISARM only. No force-disarm magic value is
    # ever used, so the flight controller retains all pre-arm and in-flight
    # disarm protections.
    mav = mavlink2.MAVLink(None)
    packet = mav.command_long_encode(
        1,
        1,
        400,
        0,
        1.0 if requested_armed else 0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
        0.0,
    ).pack(mav)
    ok = send_mavlink_tcp5760(packet)
    print(
        "[WEBUI_ARM_STATE_TCP5760]",
        action,
        "ok=" + str(ok),
        flush=True,
    )
    return {
        "ok": bool(ok),
        "action": action,
        "requested_armed": requested_armed,
        "tx": "mavlink_tcp5760",
        "command": "MAV_CMD_COMPONENT_ARM_DISARM",
        "forced": False,
    }


FLIGHT_MODE_CACHE_FILE="/tmp/siyi_flight_mode.json"
BUTTON_SAFETY_FILE="/etc/siyi/button_safety.json"

def read_pi_ui_mode_safety_blockers():

    default_block = {"MANUAL", "TAKEOFF"}

    try:
        with open(BUTTON_SAFETY_FILE, encoding="utf-8") as f:
            data = json.load(f)

        vals = data.get("block_when_armed", list(default_block))

        if not isinstance(vals, list):
            return default_block

        allowed = {
            "MANUAL", "FBWA", "AUTOTUNE", "CRUISE", "LOITER", "RTL",
            "TAKEOFF", "QHOVER", "QLOITER", "QLAND", "QRTL"
        }

        return {
            str(x).strip()
            for x in vals
            if str(x).strip() in allowed
        }

    except Exception:
        return default_block

def vehicle_is_armed_now():

    try:
        data = flight_mode_state_read_once()
        base_mode = int(data.get("base_mode", 0) or 0)
        return bool(base_mode & 128)

    except Exception:
        return False



ARDUPLANE_MODE_NAMES = {
    0:"MANUAL", 1:"CIRCLE", 2:"STABILIZE", 3:"TRAINING", 4:"ACRO",
    5:"FBWA", 6:"FBWB", 7:"CRUISE", 8:"AUTOTUNE", 10:"AUTO",
    11:"RTL", 12:"LOITER", 13:"TAKEOFF", 15:"GUIDED", 16:"INITIALISING",
    17:"QSTABILIZE", 18:"QHOVER", 19:"QLOITER", 20:"QLAND",
    21:"QRTL", 22:"QAUTOTUNE", 23:"QACRO", 24:"THERMAL",
    25:"LOITER_TO_QLAND", 26:"AUTOLAND"
}

def _parse_autopilot_heartbeat(pkt):
    try:
        if pkt and pkt[0] == 0xFD and len(pkt) >= 21:
            length = pkt[1]
            msgid = pkt[7] | (pkt[8] << 8) | (pkt[9] << 16)
            payload = pkt[10:10+length]
            if msgid == 0 and len(payload) >= 9:
                custom_mode = int.from_bytes(payload[0:4], "little", signed=False)
                mav_type = payload[4]
                autopilot = payload[5]
                base_mode = payload[6]
                if autopilot == 3 and mav_type != 6:
                    return (ARDUPLANE_MODE_NAMES.get(custom_mode, f"MODE {custom_mode}"), custom_mode, base_mode)

        if pkt and pkt[0] == 0xFE and len(pkt) >= 17:
            length = pkt[1]
            msgid = pkt[5]
            payload = pkt[6:6+length]
            if msgid == 0 and len(payload) >= 9:
                custom_mode = int.from_bytes(payload[0:4], "little", signed=False)
                mav_type = payload[4]
                autopilot = payload[5]
                base_mode = payload[6]
                if autopilot == 3 and mav_type != 6:
                    return (ARDUPLANE_MODE_NAMES.get(custom_mode, f"MODE {custom_mode}"), custom_mode, base_mode)
    except Exception:
        pass
    return None

def _write_flight_mode_cache(mode, custom_mode, base_mode):
    try:
        tmp = FLIGHT_MODE_CACHE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({
                "mode": mode,
                "custom_mode": custom_mode,
                "base_mode": base_mode,
                "last_seen": time.time(),
                "source": "server_mode_monitor"
            }, f)
        os.replace(tmp, FLIGHT_MODE_CACHE_FILE)
    except Exception as e:
        print("[MODE_MONITOR_CACHE_WRITE_FAIL]", repr(e), flush=True)

def _mode_monitor_loop():
    while True:
        try:
            print("[MODE_MONITOR_TCP5760] connecting to 127.0.0.1:5760", flush=True)

            with socket.create_connection(("127.0.0.1", 5760), timeout=3.0) as sock:
                sock.settimeout(1.0)
                mav = mavlink2.MAVLink(None)

                print("[MODE_MONITOR_TCP5760] connected", flush=True)

                while True:
                    try:
                        data = sock.recv(4096)
                        if not data:
                            raise RuntimeError("TCP5760 closed")

                        for b in data:
                            try:
                                msg = mav.parse_char(bytes([b]))
                            except Exception:
                                msg = None

                            if not msg:
                                continue

                            if msg.get_type() == "HEARTBEAT":
                                try:
                                    autopilot = int(getattr(msg, "autopilot", -1))
                                    mav_type = int(getattr(msg, "type", -1))
                                    custom_mode = int(getattr(msg, "custom_mode", -1))
                                    base_mode = int(getattr(msg, "base_mode", 0))

                                    if autopilot == 3 and mav_type != 6:
                                        mode = ARDUPLANE_MODE_NAMES.get(custom_mode, f"MODE {custom_mode}")
                                        _write_flight_mode_cache(mode, custom_mode, base_mode)
                                except Exception as e:
                                    print("[MODE_MONITOR_TCP5760_HEARTBEAT_FAIL]", repr(e), flush=True)

                    except socket.timeout:
                        pass

        except Exception as e:
            print("[MODE_MONITOR_TCP5760_FAIL]", repr(e), flush=True)
            time.sleep(1)

def start_mode_monitor_once():
    try:
        if getattr(start_mode_monitor_once, "_started", False):
            return
        start_mode_monitor_once._started = True
        t = threading.Thread(target=_mode_monitor_loop, daemon=True)
        t.start()
    except Exception as e:
        print("[MODE_MONITOR_START_FAIL]", repr(e), flush=True)

start_mode_monitor_once()

def flight_mode_state_read_once(timeout=0):
    try:
        data=json.load(open(FLIGHT_MODE_CACHE_FILE, encoding="utf-8"))
        last=float(data.get("last_seen",0) or 0)
        age=round(time.time()-last,1) if last else None
        return {
            "mode":data.get("mode","UNKNOWN"),
            "custom_mode":data.get("custom_mode"),
            "age_s":age,
            "last_seen":last,
            "base_mode":data.get("base_mode"),
            "source":data.get("source","cache_only")
        }
    except Exception:
        return {
            "mode":"UNKNOWN",
            "custom_mode":None,
            "age_s":None,
            "last_seen":0,
            "base_mode":None,
            "source":"none"
        }


SETUP_COMPLETE_FILE="/etc/siyi/setup_complete.json"
SETUP_SKIP_FILE="/tmp/siyi_setup_skip"

WIFI_PASSWORD_STORE="/home/pi/siyi-webui/wifi_passwords.json"

def wifi_pw_store_read():
    try:
        if os.path.exists(WIFI_PASSWORD_STORE):
            return json.load(open(WIFI_PASSWORD_STORE, encoding="utf-8"))
    except Exception:
        pass
    return {}

def wifi_pw_store_write(d):
    try:
        os.makedirs(os.path.dirname(WIFI_PASSWORD_STORE), exist_ok=True)
        with open(WIFI_PASSWORD_STORE, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=2)
        os.chmod(WIFI_PASSWORD_STORE, 0o600)
    except Exception as e:
        print("wifi password store write failed:", e)

def wifi_nm_password_get(name):
    try:
        result = subprocess.run(
            [
                "sudo", "-n", "nmcli", "--show-secrets",
                "-g", "802-11-wireless-security.psk",
                "connection", "show", str(name),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=8,
            check=False,
        )
        value = (result.stdout or "").strip()
        if result.returncode == 0 and value and value not in {"--", "(none)"}:
            return value
    except Exception:
        pass
    return ""


def wifi_pw_get(name):
    store = wifi_pw_store_read()
    value = str(store.get(name, "") or "")
    if value:
        return value

    value = wifi_nm_password_get(name)
    if value:
        store[name] = value
        wifi_pw_store_write(store)
    return value

def wifi_pw_set(name, password):
    d = wifi_pw_store_read()
    d[name] = password
    wifi_pw_store_write(d)

def wifi_pw_delete(name):
    d = wifi_pw_store_read()
    if name in d:
        del d[name]
        wifi_pw_store_write(d)


def setup_config_is_valid():
    try:
        eps = load_endpoints()
        return (
            len([e for e in eps if e.get("ip","").strip()]) >= 1
            and bool(zt_network_id_current())
            and bool(zt_read_token())
        )
    except Exception:
        return False

def setup_is_complete():
    try:
        if os.path.exists(SETUP_COMPLETE_FILE):
            return setup_config_is_valid()

        return False
    except Exception:
        return False

def setup_should_force():
    # A software upgrade must return to the normal WebUI, not reopen the
    # first-install wizard. The wizard remains available manually.
    if os.path.exists(SOFTWARE_UPDATE_COMPLETED_FILE):
        return False
    return (not setup_is_complete()) and (not os.path.exists(SETUP_SKIP_FILE))

def setup_banner():
    if setup_config_is_valid():
        return ""
    return """
    <div class='card' style='margin-bottom:16px;border:2px solid #d39e00;background:#fff3cd;color:#3b2f00;'>
      <h2 style='margin-top:0;color:#3b2f00;'>⚠ First setup incomplete</h2>
      <p>ZeroTier and at least one endpoint host should be configured.</p>
      <a href='/first_setup'><button style='pointer-events:auto;'>Open Setup Wizard</button></a>
    </div>
    """

def first_setup_page():
    return f"""
    <h1>First Setup Wizard</h1>

    <div class='card'>
      <p>This setup appears until completed.</p>
      <p>You can skip for now and continue using the UI during this boot.</p>
    </div>

    <form method='post' action='/first_setup_save'>

      <div class='card'>
        <h2>ZeroTier</h2>

        <label>Network ID</label>
        <input style='pointer-events:auto;' name='nwid'
               value='{esc(zt_network_id_current())}'
               placeholder='ZeroTier network ID'>

        <label>API Token</label>
        <input style='pointer-events:auto;'
               id='fstoken'
               type='password'
               name='token'
               value='{esc(zt_read_token())}'
               placeholder='ZeroTier API token'>

        <label style='display:block;margin-top:8px;'>
          <input type='checkbox'
                 style='width:auto;'
                 onclick="document.getElementById('fstoken').type=this.checked?'text':'password'">
          Show token
        </label>
      </div>

      <div class='card'>
        <h2>Host Endpoint</h2>

        <label>Host name</label>
        <input style='pointer-events:auto;' name='name'
               placeholder='Mac / Android / QGC'>

        <label>Host IP</label>
        <input style='pointer-events:auto;' name='ip'
               placeholder='192.168.x.x'>
      </div>

      <div class='card'>
        <h2>Optional Additional WiFi</h2>

        <label>SSID</label>
        <input style='pointer-events:auto;' name='ssid'
               placeholder='Optional SSID'>

        <label>Password</label>
        <input style='pointer-events:auto;'
               id='fswifi'
               type='password'
               name='password'
               autocomplete='new-password'
               data-secret-state='new'
               placeholder='Optional new network password'>

        <label style='display:block;margin-top:8px;'>
          <input type='checkbox'
                 style='width:auto;'
                 onclick="document.getElementById('fswifi').type=this.checked?'text':'password'">
          Show password
        </label>
      </div>

      <div class='card'>
        <button style='pointer-events:auto;'>
          Save and Finish Setup
        </button>

        <button style='pointer-events:auto;margin-left:12px;'
                formaction='/first_setup_skip'>
          Skip for now
        </button>
      </div>

    </form>
    """

SERVICES=[
 "siyi-button-bridge",
 "siyi-video-source",
 "siyi-video-dual",
 "mediamtx",
 "mavlink-router",
 "zerotier-one",
 "siyi-rec-proxy",
 "siyi-rec-redirect",
 "siyi-webui",
]



STATUS_LABELS={
    "active":"Running",
    "activating":"Waiting / Starting",
    "failed":"Error",
    "inactive":"Stopped",
    "unknown":"Unknown",
}


SERVICE_GROUPS = {
    "Flight Control": ["mavlink-router"],
    "Video System": ["siyi-video-source", "siyi-video-dual", "mediamtx", "siyi-rec-proxy", "siyi-rec-redirect"],
    "Control System": ["siyi-button-bridge"],
    "Network": ["zerotier-one"],
    "System": ["siyi-webui"],
}

SERVICE_LABELS={
    "siyi-button-bridge":"Button Control Bridge",
    "siyi-video-source":"Selected Video Source",
    "siyi-video-dual":"Video UDP Forwarder",
    "mavlink-router":"MAVLink Router",
    "zerotier-one":"ZeroTier Network",
    "siyi-rec-proxy":"Camera / Recording Proxy",
    "siyi-rec-redirect":"Camera Control Redirect",
    "siyi-webui":"Web Interface",
}

ACTIONS=[
"NO_ACTION","MANUAL","FBWA","AUTOTUNE","CRUISE","AUTO","FLAPS",
"VIDEO_SOURCE","VIDEO_MAP_TOGGLE","PIP_MINIMIZE_TOGGLE","TELEMETRY_TOGGLE","VIDEO_SOURCE_SIYI","VIDEO_SOURCE_HDMI","VIDEO_SOURCE_WIFILINK","LOITER","RTL",
"TAKEOFF","QHOVER","QLOITER","QLAND","QRTL",
"ARM","DISARM","TOGGLE_ARM",
"RECORD_TOGGLE","SNAPSHOT",
"ZOOM_IN","ZOOM_OUT","ZOOM_STOP",
"GIMBAL_YAW_RIGHT","GIMBAL_YAW_LEFT","GIMBAL_PITCH_UP","GIMBAL_PITCH_DOWN",
"GIMBAL_STOP","GIMBAL_CENTER","GIMBAL_CENTER_AND_ZOOM_OUT",
"GIMBAL_LOCK","GIMBAL_FOLLOW"
]

def sh(cmd):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT).strip()
    except subprocess.CalledProcessError as e:
        return e.output.strip()



BATTERY_STATUS_FILE="/tmp/siyi_battery_status.txt"

def battery_status():
    try:
        txt=open(BATTERY_STATUS_FILE).read().strip()
        if txt:
            return txt
    except:
        pass
    return "Bat ?"

def esc(x):
    return html.escape(str(x or ""))

def backup(path):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    if os.path.exists(path):
        dst=f"{BACKUP_DIR}/{os.path.basename(path)}.{time.strftime('%Y%m%d_%H%M%S')}.bak"
        shutil.copy2(path,dst)

def read_file(path):
    try:
        return open(path, encoding="utf-8", errors="replace").read()
    except Exception:
        return ""

def write_file(path, content):
    backup(path)
    open(path, "w", encoding="utf-8").write(content)


# === VIDEO_SOURCE_WEBUI_V1 START ===
def video_source_default_config():
    return {
        "source": "siyi_rtsp",
        "switch_mode": "direct-redirect",
        "output_url": "rtsp://127.0.0.1:8554/main.264",
        "siyi": {
            "enabled": True,
            "name": "SIYI",
            "url": "rtsp://192.168.144.25:8554/main.264",
            "transport": "tcp",
            "latency_ms": 0,
        },
        "hdmi": {
            "enabled": True,
            "name": "HDMI",
            "device": "",
            "input_format": "mjpeg",
            "width": 1280,
            "height": 720,
            "fps": 25,
            "audio_enabled": False,
            "encoder": "auto",
            "bitrate_kbps": 4000,
        },
        "wifilink": {
            "enabled": True,
            "name": "Air Link",
            "url": "rtsp://192.168.191.199:554/stream=0",
            "username": "root",
            "password": "",
            "transport": "tcp",
            "latency_ms": 0,
        },
        "udp": {"enabled": True, "port": 5600, "latency_ms": 0},
        "switch": {
            "verify_timeout_seconds": 15,
            "restore_on_failure": True,
            "debounce_seconds": 2,
        },
    }


def _video_source_merge(base, incoming):
    result = json.loads(json.dumps(base))
    if not isinstance(incoming, dict):
        return result
    for key, value in incoming.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _video_source_merge(result[key], value)
        else:
            result[key] = value
    return result


VIDEO_SOURCE_DEFAULT_NAMES = {
    "siyi_rtsp": "SIYI",
    "hdmi_usb": "HDMI",
    "wifilink_rtsp": "Air Link",
}


def video_source_clean_name(value, default):
    text = " ".join(str(value or "").split())
    text = "".join(ch for ch in text if ch.isprintable())
    if not text:
        return default
    return text[:40]


def video_source_names(cfg):
    return {
        "siyi_rtsp": video_source_clean_name(
            (cfg.get("siyi") or {}).get("name"),
            VIDEO_SOURCE_DEFAULT_NAMES["siyi_rtsp"],
        ),
        "hdmi_usb": video_source_clean_name(
            (cfg.get("hdmi") or {}).get("name"),
            VIDEO_SOURCE_DEFAULT_NAMES["hdmi_usb"],
        ),
        "wifilink_rtsp": video_source_clean_name(
            (cfg.get("wifilink") or {}).get("name"),
            VIDEO_SOURCE_DEFAULT_NAMES["wifilink_rtsp"],
        ),
    }


def video_source_read_config():
    cfg = video_source_default_config()
    try:
        with open(VIDEO_SOURCE_CONFIG, encoding="utf-8") as f:
            raw = json.load(f)
        cfg = _video_source_merge(cfg, raw)
    except Exception:
        pass
    source_sections = {
        "siyi_rtsp": "siyi",
        "hdmi_usb": "hdmi",
        "wifilink_rtsp": "wifilink",
    }
    for source_id, section in source_sections.items():
        cfg[section]["name"] = video_source_clean_name(
            cfg[section].get("name"), VIDEO_SOURCE_DEFAULT_NAMES[source_id]
        )
    enabled = [source for source, section in source_sections.items() if cfg[section].get("enabled", True)]
    if not enabled:
        cfg["siyi"]["enabled"] = True
        enabled = ["siyi_rtsp"]
    if cfg.get("source") not in enabled:
        cfg["source"] = enabled[0]
    return cfg


def video_source_read_status():
    try:
        with open(VIDEO_SOURCE_STATUS, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def video_source_devices():
    try:
        result = subprocess.run(
            ["sudo", "-n", VIDEO_SOURCE_CONTROL, "devices"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            timeout=12, check=False,
        )
        data = json.loads(result.stdout or "{}")
        devices = data.get("devices", [])
        return devices if isinstance(devices, list) else []
    except Exception:
        return []


def video_source_detected_paths():
    paths = set()
    for item in video_source_devices():
        if isinstance(item, dict):
            for key in ("path", "real_path"):
                value = str(item.get(key, ""))
                if value:
                    paths.add(value)
                    try:
                        paths.add(os.path.realpath(value))
                    except Exception:
                        pass
    return paths


def video_source_write_config(cfg):
    os.makedirs(os.path.dirname(VIDEO_SOURCE_CONFIG), exist_ok=True)
    previous = VIDEO_SOURCE_CONFIG + ".previous"
    if os.path.exists(VIDEO_SOURCE_CONFIG):
        shutil.copy2(VIDEO_SOURCE_CONFIG, previous)
    fd, tmp = tempfile.mkstemp(prefix=".video_source.", dir=os.path.dirname(VIDEO_SOURCE_CONFIG))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
            f.write("\n")
        os.chmod(tmp, 0o660)
        os.replace(tmp, VIDEO_SOURCE_CONFIG)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def video_source_int(value, minimum, maximum, label):
    try:
        parsed = int(str(value).strip())
    except Exception:
        raise ValueError(label + " must be a whole number")
    if not minimum <= parsed <= maximum:
        raise ValueError(label + f" must be between {minimum} and {maximum}")
    return parsed


def video_source_config_from_form(data):
    cfg = video_source_read_config()
    source = data.get("source", [cfg["source"]])[0]
    if source not in {"siyi_rtsp", "hdmi_usb", "wifilink_rtsp"}:
        raise ValueError("Invalid video source")
    siyi_enabled = "siyi_enabled" in data
    hdmi_enabled = "hdmi_enabled" in data
    wifilink_enabled = "wifilink_enabled" in data
    enabled_map = {
        "siyi_rtsp": siyi_enabled,
        "hdmi_usb": hdmi_enabled,
        "wifilink_rtsp": wifilink_enabled,
    }
    if not any(enabled_map.values()):
        raise ValueError("At least one video source must be active")
    if not enabled_map[source]:
        raise ValueError("The selected source must also be marked Active")
    siyi_url = data.get("siyi_url", [cfg["siyi"]["url"]])[0].strip()
    parsed = urllib.parse.urlparse(siyi_url)
    if parsed.scheme not in {"rtsp", "rtsps"} or not parsed.hostname:
        raise ValueError("SIYI source must be a valid RTSP URL")
    transport = data.get("transport", [cfg["siyi"].get("transport", "tcp")])[0]
    if transport not in {"tcp", "udp"}:
        raise ValueError("Invalid RTSP transport")
    wifilink_url = data.get("wifilink_url", [cfg["wifilink"]["url"]])[0].strip()
    parsed_wifilink = urllib.parse.urlparse(wifilink_url)
    if parsed_wifilink.scheme not in {"rtsp", "rtsps"} or not parsed_wifilink.hostname:
        raise ValueError("RunCam WiFiLink2 source must be a valid RTSP URL")
    wifilink_transport = data.get("wifilink_transport", [cfg["wifilink"].get("transport", "tcp")])[0]
    if wifilink_transport not in {"tcp", "udp"}:
        raise ValueError("Invalid WiFiLink2 RTSP transport")
    device = data.get("hdmi_device", [cfg["hdmi"].get("device", "")])[0].strip()
    if device and hdmi_enabled:
        allowed = video_source_detected_paths()
        if device not in allowed and os.path.realpath(device) not in allowed:
            raise ValueError("The selected HDMI capture device is not currently detected")
    input_format = data.get("input_format", [cfg["hdmi"].get("input_format", "mjpeg")])[0]
    if input_format not in {"auto", "h264", "mjpeg", "yuyv422", "uyvy422", "nv12"}:
        raise ValueError("Invalid HDMI input format")
    encoder = data.get("encoder", [cfg["hdmi"].get("encoder", "auto")])[0]
    if encoder not in {"auto", "hardware", "software", "h264_v4l2m2m", "libx264"}:
        raise ValueError("Invalid HDMI encoder")
    cfg["source"] = source
    cfg["switch_mode"] = "direct-redirect"
    cfg["siyi"].update({
        "enabled": siyi_enabled,
        "name": video_source_clean_name(
            data.get("siyi_name", [""])[0], VIDEO_SOURCE_DEFAULT_NAMES["siyi_rtsp"]
        ),
        "url": siyi_url,
        "transport": transport,
        "latency_ms": video_source_int(data.get("siyi_latency", ["0"])[0], 0, 5000, "SIYI latency"),
    })
    cfg["hdmi"].update({
        "enabled": hdmi_enabled,
        "name": video_source_clean_name(
            data.get("hdmi_name", [""])[0], VIDEO_SOURCE_DEFAULT_NAMES["hdmi_usb"]
        ),
        "device": device,
        "input_format": input_format,
        "width": video_source_int(data.get("width", ["1280"])[0], 160, 7680, "Width"),
        "height": video_source_int(data.get("height", ["720"])[0], 120, 4320, "Height"),
        "fps": video_source_int(data.get("fps", ["25"])[0], 1, 120, "Frame rate"),
        "encoder": encoder,
        "bitrate_kbps": video_source_int(data.get("bitrate_kbps", ["4000"])[0], 500, 100000, "Bitrate"),
        "audio_enabled": False,
    })
    cfg["wifilink"].update({
        "enabled": wifilink_enabled,
        "name": video_source_clean_name(
            data.get("wifilink_name", [""])[0], VIDEO_SOURCE_DEFAULT_NAMES["wifilink_rtsp"]
        ),
        "url": wifilink_url,
        "username": data.get("wifilink_username", [cfg["wifilink"].get("username", "root")])[0].strip(),
        "transport": wifilink_transport,
        "latency_ms": video_source_int(data.get("wifilink_latency", ["0"])[0], 0, 5000, "WiFiLink2 latency"),
    })
    submitted_password = data.get("wifilink_password", [""])[0]
    if submitted_password:
        cfg["wifilink"]["password"] = submitted_password
    cfg["udp"].update({
        "enabled": "udp_enabled" in data,
        "port": video_source_int(data.get("udp_port", ["5600"])[0], 1, 65535, "UDP port"),
        "latency_ms": video_source_int(data.get("udp_latency", ["0"])[0], 0, 5000, "UDP latency"),
    })
    return cfg


def video_source_control(action, source=""):
    cmd = ["sudo", "-n", VIDEO_SOURCE_CONTROL, action]
    if source:
        cmd.append(source)
    result = subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        timeout=45, check=False,
    )
    output = (result.stdout or "").strip()
    if result.returncode != 0:
        raise RuntimeError(output or "Video source operation failed")
    return output



def video_source_page():
    cfg = video_source_read_config()
    status = video_source_read_status()
    devices = video_source_devices()
    options = ["<option value=''>No HDMI capture device selected</option>"]
    selected_device = str(cfg["hdmi"].get("device", ""))
    for item in devices:
        if not isinstance(item, dict):
            continue
        path = str(item.get("path", ""))
        name = str(item.get("name", "USB video device"))
        formats = ", ".join(str(x) for x in item.get("formats", [])) or "formats unknown"
        selected = "selected" if path == selected_device or os.path.realpath(path) == os.path.realpath(selected_device or "/nonexistent") else ""
        options.append(f"<option value='{esc(path)}' {selected}>{esc(name)} — {esc(path)} — {esc(formats)}</option>")
    if selected_device and not any(selected_device in option for option in options):
        options.append(f"<option value='{esc(selected_device)}' selected>{esc(selected_device)} — currently unavailable</option>")
    device_options = "".join(options)

    source = cfg["source"]
    source_name_map = video_source_names(cfg)
    siyi_name = source_name_map["siyi_rtsp"]
    hdmi_name = source_name_map["hdmi_usb"]
    wifilink_name = source_name_map["wifilink_rtsp"]
    active_label = source_name_map.get(source, siyi_name)
    state = str(status.get("state", "unknown"))
    state_class = "ok" if state == "running" else ("warn" if state in {"starting", "waiting"} else "bad")

    siyi_enabled = bool(cfg["siyi"].get("enabled", True))
    hdmi_enabled = bool(cfg["hdmi"].get("enabled", True))
    wifilink_enabled = bool(cfg["wifilink"].get("enabled", True))
    siyi_enabled_checked = "checked" if siyi_enabled else ""
    hdmi_enabled_checked = "checked" if hdmi_enabled else ""
    wifilink_enabled_checked = "checked" if wifilink_enabled else ""
    siyi_switch_disabled = "" if siyi_enabled else "disabled"
    hdmi_switch_disabled = "" if hdmi_enabled else "disabled"
    wifilink_switch_disabled = "" if wifilink_enabled else "disabled"
    udp_checked = "checked" if cfg["udp"].get("enabled", True) else ""
    fmt = str(cfg["hdmi"].get("input_format", "mjpeg"))
    encoder = str(cfg["hdmi"].get("encoder", "auto"))
    transport = str(cfg["siyi"].get("transport", "tcp"))
    wifilink_transport = str(cfg["wifilink"].get("transport", "tcp"))

    external_ip = ""
    try:
        route_parts = sh("ip -4 route get 1.1.1.1 2>/dev/null").strip().split()
        if "src" in route_parts:
            source_index = route_parts.index("src") + 1
            if source_index < len(route_parts):
                external_ip = route_parts[source_index]
    except Exception:
        external_ip = ""
    if not external_ip:
        external_ip = next((item for item in sh("hostname -I 2>/dev/null").split() if re.match(r"^\d+\.\d+\.\d+\.\d+$", item)), "")
    external_output = "rtsp://" + (external_ip or "127.0.0.1") + ":8554/main.264"
    mediamtx_pid = ""
    try:
        mediamtx_pid = subprocess.check_output(
            ["systemctl", "show", "-p", "MainPID", "--value", "mediamtx.service"],
            text=True, timeout=3,
        ).strip()
    except Exception:
        mediamtx_pid = ""
    mediamtx_running = bool(mediamtx_pid and mediamtx_pid != "0")
    mediamtx_label = "Running" if mediamtx_running else "Unavailable"
    mediamtx_class = "ok" if mediamtx_running else "bad"

    def source_button(source_id, label, enabled):
        active = source_id == source
        button_class = "ui-source-button active" if active else "ui-source-button"
        disabled = "" if enabled else " disabled"
        suffix = " · active" if active else (" · disabled" if not enabled else "")
        return (
            "<form method='post' action='/video_source_select' class='ui-inline-form'>"
            "<input type='hidden' name='source' value='" + esc(source_id) + "'>"
            "<button class='" + button_class + "' style='pointer-events:auto'" + disabled + ">"
            + esc(label + suffix) + "</button></form>"
        )

    siyi_active_lock = "disabled" if source == "siyi_rtsp" else ""
    hdmi_active_lock = "disabled" if source == "hdmi_usb" else ""
    wifilink_active_lock = "disabled" if source == "wifilink_rtsp" else ""
    siyi_hidden = "<input type='hidden' name='siyi_enabled' value='1'>" if source == "siyi_rtsp" else ""
    hdmi_hidden = "<input type='hidden' name='hdmi_enabled' value='1'>" if source == "hdmi_usb" else ""
    wifilink_hidden = "<input type='hidden' name='wifilink_enabled' value='1'>" if source == "wifilink_rtsp" else ""

    return f"""
    <!-- VIDEO_WIFI_UI_RESTRUCTURE_V8 -->
    <style>
      .ui-page-head{{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:16px;flex-wrap:wrap}}
      .ui-page-head h1{{margin:0}}
      .ui-tabbar{{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px}}
      .ui-tabbtn{{background:#1e293b;color:#cbd5e1;border:1px solid #334155;margin:0}}
      .ui-tabbtn.active{{background:#2563eb;color:white;border-color:#3b82f6}}
      .ui-tabpanel{{display:none}}
      .ui-tabpanel.active{{display:block}}
      .ui-source-strip{{display:grid;grid-template-columns:repeat(3,minmax(180px,1fr));gap:10px}}
      .ui-inline-form{{margin:0}}
      .ui-source-button{{width:100%;margin:0;background:#1e293b;border:1px solid #475569;text-align:left}}
      .ui-source-button.active{{background:#166534;border-color:#22c55e}}
      .ui-kpi{{background:#0b1220;border:1px solid #334155;border-radius:10px;padding:13px}}
      .ui-kpi-label{{color:#94a3b8;font-size:12px;margin-bottom:5px}}
      .ui-kpi-value{{font-size:17px;font-weight:700;word-break:break-word}}
      .ui-source-card{{background:#0b1220;border:1px solid #334155;border-radius:12px;padding:15px;margin-bottom:14px}}
      .ui-source-card.active{{border-color:#22c55e;box-shadow:0 0 0 1px rgba(34,197,94,.22)}}
      .ui-card-title{{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:12px;flex-wrap:wrap}}
      .ui-card-title h2,.ui-card-title h3{{margin:0}}
      .ui-copy{{display:flex;gap:8px;align-items:center}}
      .ui-copy code{{background:#020617;border:1px solid #334155;border-radius:7px;padding:9px;display:block;overflow:auto;flex:1}}
      .ui-secondary{{background:#475569}}
      .ui-link-button{{display:inline-block;background:#2563eb;color:white;border-radius:8px;padding:9px 13px;text-decoration:none}}
      details.ui-details{{background:#0b1220;border:1px solid #334155;border-radius:10px;padding:12px;margin-bottom:10px}}
      details.ui-details summary{{cursor:pointer;font-weight:700}}
      @media(max-width:800px){{.ui-source-strip{{grid-template-columns:1fr}}}}
    </style>

    <div class='ui-page-head'>
      <div><h1>Video</h1><div class='small'>Select, configure and monitor the video delivered to QGroundControl.</div></div>
      <a class='ui-link-button ui-secondary' href='/connectivity?tab=airlink' target='_top'>Open Air Link connectivity</a>
    </div>

    <div class='card'>
      <div class='ui-card-title'><h2>Current video output</h2><span id='videoSourceState' class='pill {state_class}'>{esc(state.upper())}</span></div>
      <div class='grid'>
        <div class='ui-kpi'><div class='ui-kpi-label'>Active source</div><div id='videoActiveSource' class='ui-kpi-value'>{esc(active_label)}</div></div>
        <div class='ui-kpi'><div class='ui-kpi-label'>QGC stream</div><div class='ui-kpi-value' style='font-size:14px'>{esc(external_output)}</div></div>
        <div class='ui-kpi'><div class='ui-kpi-label'>MediaMTX</div><div class='ui-kpi-value {mediamtx_class}'>{esc(mediamtx_label)}</div></div>
        <div class='ui-kpi'><div class='ui-kpi-label'>Switching mode</div><div class='ui-kpi-value' style='font-size:14px'>Direct redirect / hot reload</div></div>
      </div>
      <p id='videoSourceMessage' class='small'>{esc(status.get('message', 'Waiting for status'))}</p>
      <p id='videoStandbyMessage' class='small'>{esc(status.get('standby_message', ''))}</p>
      <div class='ui-source-strip'>
        {source_button('siyi_rtsp', siyi_name, siyi_enabled)}
        {source_button('hdmi_usb', hdmi_name, hdmi_enabled)}
        {source_button('wifilink_rtsp', wifilink_name, wifilink_enabled)}
      </div>
      <div style='display:flex;gap:10px;margin-top:12px;flex-wrap:wrap'>
        <form method='post' action='/video_source_toggle' style='margin:0'><button style='pointer-events:auto;margin:0'>Cycle source</button></form>
        <a class='ui-link-button ui-secondary' href='/video'>Refresh status and devices</a>
      </div>
    </div>

    <div class='ui-tabbar' data-tab-group='video'>
      <button type='button' class='ui-tabbtn active' data-tab='sources'>Sources</button>
      <button type='button' class='ui-tabbtn' data-tab='routing'>Output &amp; routing</button>
      <button type='button' class='ui-tabbtn' data-tab='preview'>Preview</button>
      <button type='button' class='ui-tabbtn' data-tab='diagnostics'>Diagnostics</button>
    </div>

    <form method='post' action='/save_video_source' id='videoSettingsForm'>
      <input type='hidden' name='source' value='{esc(source)}'>
      <section class='ui-tabpanel active' data-panel='sources'>
        <div class='ui-source-card {'active' if source == 'siyi_rtsp' else ''}'>
          <div class='ui-card-title'><h2>{esc(siyi_name)}</h2><span class='pill {'active' if source == 'siyi_rtsp' else 'inactive'}'>{'ACTIVE OUTPUT' if source == 'siyi_rtsp' else 'SOURCE'}</span></div>
          {siyi_hidden}<label style='display:flex;gap:8px;align-items:center;margin-bottom:12px'><input style='width:auto;pointer-events:auto' type='checkbox' name='siyi_enabled' value='1' {siyi_enabled_checked} {siyi_active_lock}>Include this source in the source cycle</label>
          <div class='grid'>
            <div><label>Source name and spoken announcement</label><input style='pointer-events:auto' name='siyi_name' maxlength='40' value='{esc(siyi_name)}'></div>
            <div><label>RTSP URL</label><input style='pointer-events:auto' name='siyi_url' value='{esc(cfg['siyi']['url'])}'></div>
            <div><label>Transport</label><select style='pointer-events:auto' name='transport'><option value='tcp' {'selected' if transport == 'tcp' else ''}>TCP</option><option value='udp' {'selected' if transport == 'udp' else ''}>UDP</option></select></div>
            <div><label>Receiver latency (ms)</label><input style='pointer-events:auto' name='siyi_latency' value='{esc(cfg['siyi'].get('latency_ms', 0))}'></div>
          </div>
          <p class='small'>The original SIYI RTSP stream is relayed without video re-encoding.</p>
        </div>

        <div class='ui-source-card {'active' if source == 'hdmi_usb' else ''}'>
          <div class='ui-card-title'><h2>{esc(hdmi_name)}</h2><span class='pill {'active' if source == 'hdmi_usb' else 'inactive'}'>{'ACTIVE OUTPUT' if source == 'hdmi_usb' else 'SOURCE'}</span></div>
          {hdmi_hidden}<label style='display:flex;gap:8px;align-items:center;margin-bottom:12px'><input style='width:auto;pointer-events:auto' type='checkbox' name='hdmi_enabled' value='1' {hdmi_enabled_checked} {hdmi_active_lock}>Include this source in the source cycle</label>
          <div class='grid'>
            <div><label>Source name and spoken announcement</label><input style='pointer-events:auto' name='hdmi_name' maxlength='40' value='{esc(hdmi_name)}'></div>
            <div style='grid-column:1/-1'><label>Capture device</label><select style='pointer-events:auto' name='hdmi_device'>{device_options}</select></div>
            <div><label>Input format</label><select style='pointer-events:auto' name='input_format'>{''.join(f"<option value='{x}' {'selected' if fmt == x else ''}>{x}</option>" for x in ('auto','h264','mjpeg','yuyv422','uyvy422','nv12'))}</select></div>
            <div><label>Encoder</label><select style='pointer-events:auto' name='encoder'>{''.join(f"<option value='{x}' {'selected' if encoder == x else ''}>{x}</option>" for x in ('auto','hardware','software'))}</select></div>
            <div><label>Width</label><input style='pointer-events:auto' name='width' value='{esc(cfg['hdmi'].get('width', 1280))}'></div>
            <div><label>Height</label><input style='pointer-events:auto' name='height' value='{esc(cfg['hdmi'].get('height', 720))}'></div>
            <div><label>Frame rate</label><input style='pointer-events:auto' name='fps' value='{esc(cfg['hdmi'].get('fps', 25))}'></div>
            <div><label>Bitrate (kbps)</label><input style='pointer-events:auto' name='bitrate_kbps' value='{esc(cfg['hdmi'].get('bitrate_kbps', 4000))}'></div>
          </div>
          <p class='small'>HDMI input is captured over USB and encoded to H.264 for the fixed output stream.</p>
        </div>

        <div class='ui-source-card {'active' if source == 'wifilink_rtsp' else ''}'>
          <div class='ui-card-title'><h2>{esc(wifilink_name)}</h2><span class='pill {'active' if source == 'wifilink_rtsp' else 'inactive'}'>{'ACTIVE OUTPUT' if source == 'wifilink_rtsp' else 'SOURCE'}</span></div>
          {wifilink_hidden}<label style='display:flex;gap:8px;align-items:center;margin-bottom:12px'><input style='width:auto;pointer-events:auto' type='checkbox' name='wifilink_enabled' value='1' {wifilink_enabled_checked} {wifilink_active_lock}>Include this source in the source cycle</label>
          <div class='grid'>
            <div><label>Source name and spoken announcement</label><input style='pointer-events:auto' name='wifilink_name' maxlength='40' value='{esc(wifilink_name)}'></div>
            <div><label>RTSP URL</label><input style='pointer-events:auto' name='wifilink_url' value='{esc(cfg['wifilink']['url'])}'></div>
            <div><label>Fallback probe transport</label><select style='pointer-events:auto' name='wifilink_transport'><option value='tcp' {'selected' if wifilink_transport == 'tcp' else ''}>TCP</option><option value='udp' {'selected' if wifilink_transport == 'udp' else ''}>UDP</option></select></div>
            <div><label>Receiver latency (ms)</label><input style='pointer-events:auto' name='wifilink_latency' value='{esc(cfg['wifilink'].get('latency_ms', 0))}'></div>
          </div>
          <p class='small'>QGC is redirected directly to WiFiLink2. Device login and Wi-Fi settings are maintained on the dedicated WiFiLink2 page.</p>
          <a class='ui-link-button' href='/connectivity?tab=airlink' target='_top'>Open Air Link device settings</a>
        </div>
        <div class='card'><button style='pointer-events:auto;margin:0'>Save video-source settings</button></div>
      </section>

      <section class='ui-tabpanel' data-panel='routing'>
        <div class='card'>
          <h2>Output and routing</h2>
          <div class='grid'>
            <div class='ui-kpi'><div class='ui-kpi-label'>Fixed QGC URL</div><div class='ui-kpi-value' style='font-size:14px'>{esc(external_output)}</div></div>
            <div class='ui-kpi'><div class='ui-kpi-label'>Internal MediaMTX path</div><div class='ui-kpi-value' style='font-size:14px'>{esc(cfg.get('output_url'))}</div></div>
            <div class='ui-kpi'><div class='ui-kpi-label'>MediaMTX process</div><div class='ui-kpi-value'>{esc(mediamtx_pid or 'Unavailable')}</div></div>
            <div class='ui-kpi'><div class='ui-kpi-label'>Active routing mode</div><div class='ui-kpi-value' style='font-size:14px'>{esc(cfg.get('switch_mode', 'direct-redirect'))}</div></div>
          </div>
          <div class='ui-copy' style='margin-top:12px'><code id='qgcVideoUrl'>{esc(external_output)}</code><button type='button' class='ui-secondary' onclick="navigator.clipboard.writeText(document.getElementById('qgcVideoUrl').textContent)">Copy</button></div>
        </div>
        <div class='card'>
          <h2>UDP forwarding</h2>
          <label><input style='width:auto;pointer-events:auto' type='checkbox' name='udp_enabled' value='1' {udp_checked}> Forward selected video to hosts enabled for Video on the MAVLink Hosts page</label>
          <div class='grid' style='margin-top:12px'>
            <div><label>UDP port</label><input style='pointer-events:auto' name='udp_port' value='{esc(cfg['udp'].get('port', 5600))}'></div>
            <div><label>UDP receiver latency (ms)</label><input style='pointer-events:auto' name='udp_latency' value='{esc(cfg['udp'].get('latency_ms', 0))}'></div>
          </div>
          <button style='pointer-events:auto;margin-top:14px'>Save routing settings</button>
        </div>
      </section>
    </form>

    <section class='ui-tabpanel' data-panel='preview'>
      <div class='card'>
        <h2>Live preview</h2>
        <p class='small'>On-demand browser preview from MediaMTX. WiFiLink2 redirect mode is intended primarily for RTSP clients such as QGC.</p>
        <div style='display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px'>
          <button type='button' style='pointer-events:auto;margin:0' onclick='startVideoPreview()'>Start preview</button>
          <button type='button' class='ui-secondary' style='pointer-events:auto;margin:0' onclick='stopVideoPreview()'>Stop preview</button>
          <span id='videoPreviewStatus' class='pill warn'>PREVIEW OFF</span>
        </div>
        <div id='videoPreviewBox' style='display:none;border:1px solid #334155;border-radius:10px;overflow:hidden;background:#111'>
          <iframe id='videoPreviewFrame' style='width:100%;height:420px;border:0;background:#111' allow='autoplay; fullscreen'></iframe>
        </div>
      </div>
    </section>

    <section class='ui-tabpanel' data-panel='diagnostics'>
      <div class='card'>
        <h2>Video diagnostics</h2>
        <div class='grid'>
          <div><b>Configured source</b><br>{esc(source)}</div>
          <div><b>Service state</b><br><span class='{state_class}'>{esc(state)}</span></div>
          <div><b>MediaMTX PID</b><br>{esc(mediamtx_pid or 'Unavailable')}</div>
          <div><b>Output path</b><br>{esc(cfg.get('output_url'))}</div>
        </div>
        <details class='ui-details' style='margin-top:14px' open><summary>Current status message</summary><pre>{esc(status.get('message', 'No status message'))}</pre></details>
        <details class='ui-details'><summary>Standby-source status</summary><pre>{esc(status.get('standby_message', 'No standby status'))}</pre></details>
        <a class='ui-link-button ui-secondary' href='/logs'>Open full diagnostics</a>
      </div>
    </section>

    <script>
    function activateUiTab(group, name){{
      document.querySelectorAll(".ui-tabbar[data-tab-group='"+group+"'] .ui-tabbtn").forEach(btn=>btn.classList.toggle('active',btn.dataset.tab===name));
      document.querySelectorAll('.ui-tabpanel').forEach(panel=>panel.classList.toggle('active',panel.dataset.panel===name));
      try{{localStorage.setItem('siyi-tab-'+group,name)}}catch(_e){{}}
    }}
    document.querySelectorAll(".ui-tabbar[data-tab-group='video'] .ui-tabbtn").forEach(btn=>btn.addEventListener('click',()=>activateUiTab('video',btn.dataset.tab)));
    const initialVideoTab=(location.hash||'').replace('#','') || (()=>{{try{{return localStorage.getItem('siyi-tab-video')}}catch(_e){{return ''}}}})() || 'sources';
    if(['sources','routing','preview','diagnostics'].includes(initialVideoTab)) activateUiTab('video',initialVideoTab);
    function startVideoPreview(){{
      const url=location.protocol+'//'+location.hostname+':8889/main.264/';
      document.getElementById('videoPreviewFrame').src=url;
      document.getElementById('videoPreviewBox').style.display='block';
      const st=document.getElementById('videoPreviewStatus');st.textContent='PREVIEW ON';st.className='pill ok';
    }}
    function stopVideoPreview(){{
      document.getElementById('videoPreviewFrame').src='about:blank';
      document.getElementById('videoPreviewBox').style.display='none';
      const st=document.getElementById('videoPreviewStatus');st.textContent='PREVIEW OFF';st.className='pill warn';
    }}
    async function pollVideoSource(){{
      try{{
        const r=await fetch('/video_source_status?ts='+Date.now(),{{cache:'no-store'}});
        const s=await r.json();
        const state=String(s.state||'unknown');
        const pill=document.getElementById('videoSourceState');
        pill.textContent=state.toUpperCase();
        pill.className='pill '+(state==='running'?'ok':((state==='starting'||state==='waiting')?'warn':'bad'));
        const sourceLabels=s.source_names||{{}};
        document.getElementById('videoActiveSource').textContent=sourceLabels[s.active_source]||sourceLabels[s.configured_source]||'SIYI';
        document.getElementById('videoSourceMessage').textContent=s.message||'';
        document.getElementById('videoStandbyMessage').textContent=s.standby_message||'';
      }}catch(_e){{}}
    }}
    setInterval(pollVideoSource,2000);
    </script>"""
# === VIDEO_SOURCE_WEBUI_V8 END ===


# === FLAPS_WEBUI_V1 START ===
FLAPS_CONFIG_FILE = "/etc/siyi/flaps.json"


def flaps_default_config():
    return {
        "enabled": False,
        "left_servo": 9,
        "right_servo": 10,
        "left_reverse": False,
        "right_reverse": False,
        "up_pwm": 1000,
        "takeoff_pwm": 1500,
        "landing_pwm": 2000,
        "current_position": "UP",
    }


def flaps_read_config():
    cfg = flaps_default_config()

    try:
        with open(
            FLAPS_CONFIG_FILE,
            encoding="utf-8",
        ) as f:
            saved = json.load(f)

        if isinstance(saved, dict):
            cfg.update(saved)

    except Exception:
        pass

    return cfg


def flaps_write_config(cfg):
    current = flaps_read_config()

    clean = {
        "enabled": bool(
            cfg.get("enabled", False)
        ),
        "left_servo": int(
            cfg.get("left_servo", 9)
        ),
        "right_servo": int(
            cfg.get("right_servo", 10)
        ),
        "left_reverse": bool(
            cfg.get("left_reverse", False)
        ),
        "right_reverse": bool(
            cfg.get("right_reverse", False)
        ),
        "up_pwm": int(
            cfg.get("up_pwm", 1000)
        ),
        "takeoff_pwm": int(
            cfg.get("takeoff_pwm", 1500)
        ),
        "landing_pwm": int(
            cfg.get("landing_pwm", 2000)
        ),
        "current_position": str(
            current.get(
                "current_position",
                "UP",
            )
        ).upper(),
    }

    if (
        clean["left_servo"]
        == clean["right_servo"]
    ):
        raise ValueError(
            "Left and right outputs must be different"
        )

    if not (
        1 <= clean["left_servo"] <= 16
        and 1 <= clean["right_servo"] <= 16
    ):
        raise ValueError(
            "Outputs must be SERVO1 through SERVO16"
        )

    for key in (
        "up_pwm",
        "takeoff_pwm",
        "landing_pwm",
    ):
        if not 800 <= clean[key] <= 2200:
            raise ValueError(
                "PWM values must be between 800 and 2200"
            )

    os.makedirs(
        os.path.dirname(FLAPS_CONFIG_FILE),
        exist_ok=True,
    )

    tmp = FLAPS_CONFIG_FILE + ".tmp"

    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(clean, f, indent=2)
        f.write("\n")

    os.replace(tmp, FLAPS_CONFIG_FILE)
    os.chmod(FLAPS_CONFIG_FILE, 0o664)

    return clean


def flaps_page():
    cfg = flaps_read_config()

    checked = (
        "checked"
        if cfg.get("enabled")
        else ""
    )

    left_is_reverse = bool(
        cfg.get("left_reverse", False)
    )

    right_is_reverse = bool(
        cfg.get("right_reverse", False)
    )

    left_normal_selected = (
        "" if left_is_reverse else "selected"
    )

    left_reverse_selected = (
        "selected" if left_is_reverse else ""
    )

    right_normal_selected = (
        "" if right_is_reverse else "selected"
    )

    right_reverse_selected = (
        "selected" if right_is_reverse else ""
    )

    position = str(
        cfg.get("current_position", "UP")
    ).upper()

    msg = esc(
        sh(
            "cat /tmp/siyi_webui_last_action "
            "2>/dev/null || true"
        )
    )

    return f"""
    <h1>Flap Control</h1>

    <div class='card'>
      <h2>Status</h2>

      <div class='grid'>
        <div>
          <b>Current commanded position</b><br>
          {esc(position)}
        </div>

        <div>
          <b>Ownership rule</b><br>
          Both configured SERVOx_FUNCTION parameters
          must be Disabled (0).
        </div>
      </div>

      <p class='small'>
        If either output has any ArduPilot function
        other than Disabled, every flap command is blocked.
      </p>
    </div>

    <div class='card'>
      <h2>Configuration</h2>

      <form method='post' action='/save_flaps'>

        <label style='display:flex;align-items:center;
                      gap:8px;margin-bottom:14px;'>

          <input
            style='pointer-events:auto;width:auto;'
            type='checkbox'
            name='enabled'
            value='1'
            {checked}>

          Enable button-controlled flaps
        </label>

        <div class='grid'>

          <div>
            <label>Left flap output</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='1'
              max='16'
              name='left_servo'
              value='{esc(cfg.get("left_servo", 9))}'>
          </div>

          <div>
            <label>Right flap output</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='1'
              max='16'
              name='right_servo'
              value='{esc(cfg.get("right_servo", 10))}'>
          </div>

          <div>
            <label>Left servo direction</label>
            <select
              style='pointer-events:auto;'
              name='left_reverse'>

              <option
                value='0'
                {left_normal_selected}>
                Normal
              </option>

              <option
                value='1'
                {left_reverse_selected}>
                Reversed
              </option>
            </select>
          </div>

          <div>
            <label>Right servo direction</label>
            <select
              style='pointer-events:auto;'
              name='right_reverse'>

              <option
                value='0'
                {right_normal_selected}>
                Normal
              </option>

              <option
                value='1'
                {right_reverse_selected}>
                Reversed
              </option>
            </select>
          </div>

          <div>
            <label>UP PWM</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='800'
              max='2200'
              name='up_pwm'
              value='{esc(cfg.get("up_pwm", 1000))}'>
          </div>

          <div>
            <label>MID PWM</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='800'
              max='2200'
              name='takeoff_pwm'
              value='{esc(cfg.get("takeoff_pwm", 1500))}'>
          </div>

          <div>
            <label>DOWN PWM</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='800'
              max='2200'
              name='landing_pwm'
              value='{esc(cfg.get("landing_pwm", 2000))}'>
          </div>

        </div>

        <button style='pointer-events:auto;'>
          Save flap configuration
        </button>

      </form>
    </div>

    <div class='card'>
      <h2>Button action</h2>

      <p>
        Assign <b>FLAPS</b> on the Buttons page.
        Each activation cycles
        UP → MID → DOWN → UP.
      </p>
    </div>

    <div class='card'>
      <h2>Last action</h2>
      <pre>{msg}</pre>
    </div>
    """

# === FLAPS_WEBUI_V1 END ===

def zt_save_config(cfg):
    try:
        os.makedirs("/etc/siyi", exist_ok=True)
        open(ZT_CONFIG_FILE, "w").write(json.dumps(cfg, indent=2))
        return True
    except Exception as e:
        print("zt_save_config failed:", e)
        return False


def zt_read_config():
    try:
        if os.path.exists(ZT_CONFIG_FILE):
            with open(ZT_CONFIG_FILE, encoding="utf-8") as f:
                data=json.load(f)
                if isinstance(data, dict):
                    return data
    except Exception:
        pass
    return {}

def zt_write_config(data):
    os.makedirs(os.path.dirname(ZT_CONFIG_FILE), exist_ok=True)
    with open(ZT_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    try:
        os.chmod(ZT_CONFIG_FILE, 0o600)
    except Exception:
        pass

def zt_save_token(token):
    token=(token or "").strip()
    if not token:
        return
    os.makedirs(os.path.dirname(ZT_TOKEN_FILE), exist_ok=True)
    with open(ZT_TOKEN_FILE, "w", encoding="utf-8") as f:
        f.write(token + "\n")
    try:
        os.chmod(ZT_TOKEN_FILE, 0o600)
    except Exception:
        pass

def zt_read_token():
    try:
        return open(ZT_TOKEN_FILE, encoding="utf-8").read().strip()
    except Exception:
        return ""

def zt_token_saved():
    return bool(zt_read_token())

def zt_node_id():
    out=sh("sudo zerotier-cli info 2>/dev/null || true")
    parts=out.split()
    if len(parts) >= 3 and parts[0] == "200" and parts[1] == "info":
        return parts[2]
    return ""

def zt_current_ip():
    out=sh("sudo zerotier-cli listnetworks 2>/dev/null || true")
    for line in out.splitlines():
        if " OK " in line and "/" in line:
            parts=line.split()
            for part in reversed(parts):
                if "/" in part and "." in part:
                    return part.split("/")[0]
    out=sh("ip -4 -br addr | awk '/zt/ {print $3}' | head -n1 | cut -d/ -f1")
    return out.strip()

def zt_network_id_current():
    cfg=zt_read_config()
    nwid=(cfg.get("network_id") or "").strip()
    if nwid:
        return nwid
    out=sh("sudo zerotier-cli listnetworks 2>/dev/null || true")
    for line in out.splitlines():
        parts=line.split()
        if len(parts) >= 3 and parts[0] == "200" and parts[1] == "listnetworks" and parts[2] != "<nwid>":
            return parts[2]
    return ""

def zt_api_request(method, path, payload=None):
    token=zt_read_token()
    if not token:
        return False, "No API token saved"
    url="https://api.zerotier.com/api/v1" + path
    data=None
    headers={
        "Authorization": "token " + token,
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "curl/8.0 SIYI-Pi-WebUI",
    }
    if payload is not None:
        data=json.dumps(payload).encode("utf-8")
    req=urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=12) as r:
            body=r.read().decode("utf-8", errors="replace")
            return True, body
    except Exception as e:
        return False, str(e)

def zt_test_token():
    nwid=zt_network_id_current()
    if not nwid:
        return "ZT API test failed: no network ID saved/found"
    ok, body=zt_api_request("GET", "/network/" + nwid)
    if ok:
        return "ZT API token OK for network " + nwid
    return "ZT API token test failed for network " + nwid + ": " + body


def zt_authorize_this_pi(default_name="New_PI"):
    nwid=zt_network_id_current()
    node=zt_node_id()

    if not nwid:
        return "ZT authorize failed: no network ID configured"

    if not node:
        return "ZT authorize failed: no local node ID"

    hostname=sh("hostname").strip() or default_name

    payload={
        "config":{"authorized":True},
        "name":hostname
    }

    ok, body=zt_api_request(
        "POST",
        "/network/" + nwid + "/member/" + node,
        payload
    )

    if not ok:
        return "ZT authorize failed: " + body

    for i in range(1,11):
        time.sleep(2)

        ok2, verify_body=zt_api_request(
            "GET",
            "/network/" + nwid + "/member/" + node
        )

        if ok2:
            try:
                obj=json.loads(verify_body)

                if obj.get("config",{}).get("authorized") is True:
                    return "ZT authorize OK verified for node " + node + " as " + hostname

            except Exception:
                pass

    return "ZT authorize failed verification for node " + node


def zt_update_camera_route():
    nwid=zt_network_id_current()
    ip=zt_current_ip()
    if not nwid:
        return "ZT route update failed: no network ID"
    if not ip:
        return "ZT route update failed: no Pi ZeroTier IP"

    ok, body=zt_api_request("GET", "/network/" + nwid)
    if not ok:
        return "ZT route update failed reading network: " + body

    try:
        obj=json.loads(body)
        cfg=obj.get("config",{})
        routes=cfg.get("routes") or []
        if not isinstance(routes, list):
            routes=[]
    except Exception as e:
        return "ZT route update failed parsing network JSON: " + str(e)

    # Replace only the camera subnet route, preserve all other routes.
    routes=[r for r in routes if not (isinstance(r,dict) and r.get("target")=="192.168.144.0/24")]
    routes.append({"target":"192.168.144.0/24","via":ip})

    payload={"config":{"routes":routes}}
    ok, body=zt_api_request("POST", "/network/" + nwid, payload)
    if ok:
        return "ZT managed route updated OK: 192.168.144.0/24 via " + ip
    return "ZT managed route update failed: " + body

ZT_SETUP_DIAGNOSTIC_LOG="/home/pi/siyi_zerotier_setup.log"


def _zt_finish_setup(lines, summary):
    details="\n".join(str(item) for item in lines if item is not None)
    try:
        with open(ZT_SETUP_DIAGNOSTIC_LOG, "w", encoding="utf-8") as handle:
            handle.write(time.strftime("%Y-%m-%d %H:%M:%S") + "\n")
            handle.write(details.rstrip() + "\n")
        os.chmod(ZT_SETUP_DIAGNOSTIC_LOG, 0o600)
    except Exception as exc:
        print("ZeroTier diagnostic log write failed:", exc, flush=True)
    return summary


def zt_full_setup():
    out=[]

    nwid=zt_network_id_current()

    if not nwid:
        return _zt_finish_setup(
            ["ZT setup failed: no network ID configured"],
            "ZeroTier setup failed: no network ID configured."
        )

    out.append("=== ZT FULL SETUP START ===")
    out.append("Network ID: " + nwid)

    # Step 1: Join network
    out.append("")
    out.append("=== JOIN NETWORK ===")
    join_out=sh(f"sudo zerotier-cli join {nwid}")
    out.append(join_out)

    # Step 2: Authorize/update member through Legacy Central v1.
    out.append("")
    out.append("=== AUTHORIZE MEMBER ===")
    auth_out=zt_authorize_this_pi()
    out.append(auth_out)
    if not auth_out.startswith("ZT authorize OK verified"):
        return _zt_finish_setup(
            out,
            "ZeroTier setup failed: member authorization failed. Check the saved API token."
        )

    # Step 3: Wait for operational state and a managed address.
    out.append("")
    out.append("=== WAIT FOR ZT IP ===")

    zt_ip=None
    status_txt=""

    for i in range(1,16):
        time.sleep(2)

        try:
            status_txt=sh("sudo zerotier-cli listnetworks")
        except Exception as exc:
            status_txt=str(exc)

        out.append(f"TRY {i}/15")
        out.append(status_txt)

        current=zt_current_ip()

        if current:
            zt_ip=current
            break

    # Step 4: Validate operational success.
    if not zt_ip:
        out.append("")
        out.append("ZT SETUP FAILED")
        out.append("No managed ZeroTier IP received.")
        out.append("Current status:")
        out.append(status_txt)

        if "ACCESS_DENIED" in status_txt:
            summary="ZeroTier setup incomplete: this Pi is not authorized in ZeroTier Central."
        elif "REQUESTING_CONFIGURATION" in status_txt:
            summary="ZeroTier setup incomplete: waiting for network authorization or managed IP assignment."
        else:
            summary="ZeroTier setup incomplete: no managed ZeroTier IP was received."

        return _zt_finish_setup(out, summary)

    out.append("")
    out.append("ZT ONLINE OK")
    out.append("Pi ZT IP: " + zt_ip)

    # Step 5: Route update
    out.append("")
    out.append("=== UPDATE CAMERA ROUTE ===")
    route_out=zt_update_camera_route()
    out.append(route_out)

    out.append("")
    out.append("=== ZT SETUP COMPLETE ===")

    if route_out.startswith("ZT managed route updated OK"):
        summary="ZeroTier connected: " + zt_ip + "."
    else:
        summary="ZeroTier connected: " + zt_ip + ". Camera route update needs attention."
    return _zt_finish_setup(out, summary)


def zt_status_html():
    cfg=zt_read_config()
    nwid=zt_network_id_current()
    token_status="saved" if zt_token_saved() else "not saved"
    node=zt_node_id() or "-"
    ip=zt_current_ip() or "-"
    raw=sh("sudo zerotier-cli info; sudo zerotier-cli listnetworks")
    return f"""
    <div class='grid'>
      <div><b>Network ID</b><br><span class='small'>{esc(nwid or "-")}</span></div>
      <div><b>API token</b><br><span class='small'>{esc(token_status)}</span></div>
      <div><b>This Pi node ID</b><br><span class='small'>{esc(node)}</span></div>
      <div><b>This Pi ZeroTier IP</b><br><span class='small'>{esc(ip)}</span></div>
    </div>
    <details style='margin-top:12px;'><summary>Show ZeroTier raw status</summary><pre>{esc(raw)}</pre></details>
    """

def get_video_values():
    txt=read_file(VIDEO_SERVICE)
    vals={"rtsp":"rtsp://"+CAM_IP+":8554/main.264","protocols":"tcp","latency":"0","host1":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","host2":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","port":"5600"}
    m=re.search(r"location=([^ ]+)", txt)
    if m: vals["rtsp"]=m.group(1)
    m=re.search(r"protocols=([^ ]+)", txt)
    if m: vals["protocols"]=m.group(1)
    m=re.search(r"latency=([^ ]+)", txt)
    if m: vals["latency"]=m.group(1)
    hosts=re.findall(r"udpsink host=([^ ]+) port=([0-9]+)", txt)
    if len(hosts)>0:
        vals["host1"], vals["port"]=hosts[0]
    if len(hosts)>1:
        vals["host2"], _=hosts[1]
    return vals

def make_video_service(rtsp, protocols, latency, host1, host2, port):
    return f"""[Unit]
Description=SIYI RTSP to dual UDP forwarder
After=network-online.target zerotier-one.service NetworkManager.service
Wants=network-online.target zerotier-one.service

[Service]
Type=simple
Restart=always
RestartSec=3
ExecStart=/usr/bin/gst-launch-1.0 -e rtspsrc location={rtsp} latency={latency} protocols={protocols} ! rtph265depay ! h265parse ! rtph265pay config-interval=1 pt=96 ! tee name=t t. ! queue ! udpsink host={host1} port={port} t. ! queue ! udpsink host={host2} port={port}
ExecStop=/usr/bin/pkill -f "gst-launch-1.0"
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
"""

def get_mav_values():
    txt=read_file(MAVCONF)
    vals={"device":"/dev/ttyAMA0","baud":"57600","android":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","mac":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","port":"14550","tcp":"5760"}
    m=re.search(r"TcpServerPort=([0-9]+)", txt)
    if m: vals["tcp"]=m.group(1)
    m=re.search(r"Device=(.+)", txt)
    if m: vals["device"]=m.group(1).strip()
    m=re.search(r"Baud=([0-9]+)", txt)
    if m: vals["baud"]=m.group(1)
    m=re.search(r"\[UdpEndpoint android\].*?Address=([0-9.]+).*?Port=([0-9]+)", txt, re.S)
    if m: vals["android"], vals["port"]=m.group(1), m.group(2)
    m=re.search(r"\[UdpEndpoint mac\].*?Address=([0-9.]+)", txt, re.S)
    if m: vals["mac"]=m.group(1)
    return vals

def make_mav_conf(device, baud, android, mac, port, tcp):
    return f"""[General]
TcpServerPort={tcp}
ReportStats=false

[UartEndpoint fc]
Device={device}
Baud={baud}

[UdpEndpoint android]
Mode=Normal
Address={android}
Port={port}

[UdpEndpoint mac]
Mode=Normal
Address={mac}
Port={port}

[UdpEndpoint button_safety]
Mode=Normal
Address=127.0.0.1
Port=14600
"""



def system_summary():
    problems = []
    warnings = []

    for s in SERVICES:
        state = sh(f"systemctl is-active {s} 2>/dev/null || true")
        if state == "failed":
            problems.append(s)
        elif state == "activating":
            warnings.append(s)

    if problems:
        return f"<div style='color:#ef4444;font-weight:bold'>❌ Issues: {', '.join(problems)}</div>"
    if warnings:
        return f"<div style='color:#f59e0b;font-weight:bold'>⚠ Waiting: {', '.join(warnings)}</div>"
    return "<div style='color:#22c55e;font-weight:bold'>✔ All systems running</div>"

def service_rows():
    rows = ""
    for group, services in SERVICE_GROUPS.items():
        rows += f"<tr><td colspan='3' style='padding-top:10px;font-weight:bold;color:#93c5fd'>{group}</td></tr>"
        for s in services:
            active = sh(f"systemctl is-active {s} 2>/dev/null || true")
            cls = "ok" if active == "active" else ("bad" if active in ["failed"] else "")
            disabled = "disabled" if s == "siyi-webui" else ""
            label = SERVICE_LABELS.get(s, s)
            status_label = STATUS_LABELS.get(active, active)
            rows += f"<tr><td><b>{esc(label)}</b><br><span class='small'>{esc(s)}</span></td><td class='{cls}'><b>{esc(status_label)}</b><br><span class='small'>{esc(active)}</span></td><td><form method='post' action='/restart'><input style='pointer-events:auto;' type='hidden' name='service' value='{s}'><button style='pointer-events:auto;' {disabled}>Restart</button></form></td></tr>"
    return rows


def action_select(name, current):
    dyn = []
    try:
        dyn = gimbal_preset_actions()
    except Exception as e:
        print("[GIMBAL_PRESET_ACTIONS_FAIL]", e, flush=True)

    merged = list(ACTIONS)

    for a in dyn:
        if a not in merged:
            merged.append(a)

    return "<select style='pointer-events:auto;' name='%s'>%s</select>" % (
        name,
        "".join([f"<option {'selected' if a==current else ''}>{a}</option>" for a in merged])
    )

def read_button_rows():
    if not os.path.exists(BUTTON_MAP):
        return []
    with open(BUTTON_MAP,encoding="utf-8-sig") as f:
        return list(csv.DictReader(f,delimiter=";"))


def read_button_safety_config():
    default={
        "block_when_armed":["MANUAL","TAKEOFF"],
        "block_disarm_in_air":True,
        "block_toggle_arm_disarm_in_air":True,
    }

    try:
        if os.path.exists(BUTTON_SAFETY_FILE):
            with open(BUTTON_SAFETY_FILE, encoding="utf-8") as f:
                data=json.load(f)

            vals=data.get("block_when_armed", default["block_when_armed"])

            if not isinstance(vals, list):
                vals=default["block_when_armed"]

            allowed=set(FLIGHT_SAFETY_ACTIONS)

            vals=[
                str(v).strip()
                for v in vals
                if str(v).strip() in allowed
            ]

            return {
                "block_when_armed":vals,
                "block_disarm_in_air":bool(data.get("block_disarm_in_air", True)),
                "block_toggle_arm_disarm_in_air":bool(data.get("block_toggle_arm_disarm_in_air", True)),
            }

    except Exception:
        pass

    return default


def write_button_safety_config(vals, block_disarm_in_air=True, block_toggle_arm_disarm_in_air=True):
    allowed=set(FLIGHT_SAFETY_ACTIONS)

    vals=[
        str(v).strip()
        for v in vals
        if str(v).strip() in allowed
    ]

    # Preserve UI/action ordering.
    ordered=[a for a in FLIGHT_SAFETY_ACTIONS if a in vals]

    os.makedirs("/etc/siyi", exist_ok=True)

    with open(BUTTON_SAFETY_FILE, "w", encoding="utf-8") as f:
        json.dump({
            "block_when_armed":ordered,
            "block_disarm_in_air":bool(block_disarm_in_air),
            "block_toggle_arm_disarm_in_air":bool(block_toggle_arm_disarm_in_air),
        }, f, indent=2)

    try:
        os.chmod(BUTTON_SAFETY_FILE, 0o644)
    except Exception:
        pass



def read_gimbal_presets():
    try:
        if os.path.exists(GIMBAL_PRESETS_FILE):
            with open(GIMBAL_PRESETS_FILE, encoding="utf-8") as f:
                data=json.load(f)
            if isinstance(data, list):
                return data
    except Exception as e:
        print("[GIMBAL_PRESETS_READ_FAIL]", e, flush=True)
    return []
def normalize_preset_name(name):
    name=str(name or "").strip()
    out=[]
    for ch in name:
        if ch.isalnum():
            out.append(ch)
        else:
            out.append("_")
    name="".join(out).strip("_")
    while "__" in name:
        name=name.replace("__","_")
    return name or "PRESET"

def write_gimbal_presets(presets):
    clean=[]
    seen=set()
    for r in presets:
        name=normalize_preset_name(r.get("name") or r.get("label") or "PRESET")
        base=name
        n=2
        while name in seen:
            name="%s_%d"%(base,n)
            n+=1
        seen.add(name)
        label=str(r.get("label") or name.replace("_"," ").title()).strip()
        try:
            yaw=float(r.get("yaw",0))
        except Exception:
            yaw=0.0
        try:
            pitch=float(r.get("pitch",0))
        except Exception:
            pitch=0.0
        clean.append({"name":name,"label":label,"yaw":yaw,"pitch":pitch})
    os.makedirs(os.path.dirname(GIMBAL_PRESETS_FILE), exist_ok=True)
    with open(GIMBAL_PRESETS_FILE,"w",encoding="utf-8") as f:
        json.dump(clean,f,indent=2)
    try:
        os.chmod(GIMBAL_PRESETS_FILE,0o644)
    except Exception:
        pass
    return clean

def gimbal_preset_actions():
    return ["GIMBAL_PRESET_"+p.get("name","") for p in read_gimbal_presets() if p.get("name")]


def gimbal_presets_card():
    presets=read_gimbal_presets()
    presets_json=json.dumps(presets)
    return """
    <div class='card'>
      <h2>Gimbal Presets</h2>
      <p class='small'>Create named gimbal preset positions. These become selectable button actions as <b>GIMBAL_PRESET_NAME</b>.</p>

      <div class='small' style='margin:8px 0 12px 0;color:#cbd5e1;'>
        Current zeroed gimbal position:
        Yaw: <b id='gimbalCurrentYaw'>--</b>
        &nbsp; Pitch: <b id='gimbalCurrentPitch'>--</b>
        &nbsp;
<br><button type='button' style='pointer-events:auto;margin-top:8px;' onclick='gimbalSetZero()'>Set current gimbal position as center / zero</button>
      </div>

      <table id='gimbalPresetTable'>
        <tr><th>Preset</th><th>Yaw</th><th>Pitch</th><th></th></tr>
      </table>

      <button type='button' style='pointer-events:auto;' onclick='gimbalPresetAdd()'>Add preset</button>
      <button type='button' style='pointer-events:auto;' onclick='gimbalPresetAddCurrent()'>Add preset from current position</button>
      <div id='gimbalPresetSaveStatus' class='small' style='margin-top:8px;color:#94a3b8;'>Saved automatically</div>
    </div>

    <script>
      let gimbalPresets = __PRESETS_JSON__;
      let gimbalPresetSaveTimer = null;
      window.gimbalLastCurrent = {yaw:0,pitch:0};

      function gimbalPresetNormalizeName(v){
        v=String(v||'').trim().replace(/^_+|_+$/g,'');
        return v || 'PRESET';
      }

      function gimbalPresetRender(){
        const tbl=document.getElementById('gimbalPresetTable');
        if(!tbl) return;
        let html="<tr><th>Preset</th><th>Yaw</th><th>Pitch</th><th></th></tr>";
        gimbalPresets.forEach((p,i)=>{
          html += `
            <tr>
              <td><input style="pointer-events:auto;" value="${p.label||p.name||''}" onchange="gimbalPresetSet(${i},'name',this.value)"></td>
              <td><input style="pointer-events:auto;" type="number" step="0.1" value="${p.yaw||0}" onchange="gimbalPresetSet(${i},'yaw',this.value)"></td>
              <td><input style="pointer-events:auto;" type="number" step="0.1" value="${p.pitch||0}" onchange="gimbalPresetSet(${i},'pitch',this.value)"></td>
              <td><button type="button" class="danger" style="pointer-events:auto;" onclick="gimbalPresetDelete(${i})">Delete</button></td>
            </tr>`;
        });
        tbl.innerHTML=html;
      }

      function gimbalPresetSet(i,k,v){
        if(k==='name') { v=String(v||'').trim(); gimbalPresets[i].label=v; }
        if(k==='yaw' || k==='pitch') v=parseFloat(v||0);
        gimbalPresets[i][k]=v;
        gimbalPresetAutosave();
      }

      function gimbalPresetAdd(){
        gimbalPresets.push({name:'NEW_PRESET',label:'New preset',yaw:0,pitch:0});
        gimbalPresetRender();
        gimbalPresetAutosave();
      }


      function gimbalPresetNudge(i,k,d){
        gimbalPresets[i][k]=parseFloat(gimbalPresets[i][k]||0)+d;
        gimbalPresetRender();
        gimbalPresetAutosave();
      }

      function gimbalPresetDelete(i){
        gimbalPresets.splice(i,1);
        gimbalPresetRender();
        gimbalPresetAutosave();
      }

      async function gimbalCurrentRead(){
        try{
          const r=await fetch('/gimbal_current?ts='+Date.now());
          const j=await r.json();
          const y=document.getElementById('gimbalCurrentYaw');
          const p=document.getElementById('gimbalCurrentPitch');
          if(y) y.textContent=j.yaw;
          if(p) p.textContent=j.pitch;
          window.gimbalLastCurrent=j;
        }catch(e){
          console.log("gimbalCurrentRead fail", e);
        }
      }


      async function gimbalSetZero(){
        try{
          const r=await fetch('/gimbal_set_zero?ts='+Date.now(),{cache:'no-store'});
          const j=await r.json();
          if(!r.ok || !j.ok) throw new Error(j.error || ('HTTP '+r.status));
          let latest=null;
          for(let attempt=0;attempt<16;attempt++){
            const current=await fetch('/gimbal_current?ts='+Date.now(),{cache:'no-store'});
            latest=await current.json();
            const yaw=Math.abs(Number(latest.yaw));
            const pitch=Math.abs(Number(latest.pitch));
            if(Number.isFinite(yaw)&&Number.isFinite(pitch)&&yaw<=1.0&&pitch<=1.0){
              await gimbalCurrentRead();
              alert('Gimbal center/zero saved');
              return;
            }
            await new Promise(resolve=>setTimeout(resolve,250));
          }
          throw new Error('center verification failed; current yaw '+String(latest&&latest.yaw)+' pitch '+String(latest&&latest.pitch));
        }catch(e){
          alert('Failed to set gimbal zero: '+String(e&&e.message||e));
        }
      }

      function gimbalPresetAddCurrent(){
        const j=window.gimbalLastCurrent || {yaw:0,pitch:0};
        const idx=gimbalPresets.length+1;
        gimbalPresets.push({
          name:'Preset '+idx,
          label:'Preset '+idx,
          yaw:parseFloat(j.yaw||0),
          pitch:parseFloat(j.pitch||0)
        });
        gimbalPresetRender();
        gimbalPresetAutosave();
      }

      function gimbalPresetAutosave(){
        clearTimeout(gimbalPresetSaveTimer);
        gimbalPresetSaveTimer=setTimeout(async function(){
          const st=document.getElementById('gimbalPresetSaveStatus');
          try{
            if(st) st.textContent='Saving...';
            const body=new URLSearchParams();
            body.set('presets_json', JSON.stringify(gimbalPresets));
            const r=await fetch('/save_gimbal_presets', {
              method:'POST',
              headers:{'Content-Type':'application/x-www-form-urlencoded'},
              body:body.toString()
            });
            if(!r.ok) throw new Error('HTTP '+r.status);
            if(st) st.textContent='Saved. Refresh page to update button action dropdowns.';
          }catch(e){
            if(st) st.textContent='Save failed: '+e;
          }
        },400);
      }

      gimbalPresetRender();
      gimbalCurrentRead();
      setInterval(gimbalCurrentRead,700);
    </script>
    """.replace("__PRESETS_JSON__", presets_json)


def button_safety_card():
    cfg=read_button_safety_config()
    selected=[a for a in FLIGHT_SAFETY_ACTIONS if a in set(cfg.get("block_when_armed", []))]

    selected_json=json.dumps(selected)
    actions_json=json.dumps(FLIGHT_SAFETY_ACTIONS)

    disarm_checked="checked" if cfg.get("block_disarm_in_air", True) else ""
    toggle_checked="checked" if cfg.get("block_toggle_arm_disarm_in_air", True) else ""

    return f"""
    <div class='card'>
      <h2 style='margin-top:0;'>Flight Safety Blockers</h2>

      <p class='small' style='margin-top:0;'>
        Prevent selected flight actions while the aircraft is armed.
      </p>

      <form method='post' action='/save_button_safety'>

        <label class='small'>Add blocker</label>

        <div style='display:flex;gap:8px;align-items:flex-start;max-width:520px;margin-top:6px;margin-bottom:10px;'>
          <div style='position:relative;max-width:260px;flex:1;'>
            <button id='safetyDropdownButton'
                    type='button'
                    onclick='safetyToggleDropdown()'
                    style='pointer-events:auto;width:100%;margin:0;text-align:left;background:#020617;color:#e5e7eb;border:1px solid #334155;border-radius:6px;padding:7px 32px 7px 10px;min-height:36px;font-size:14px;position:relative;box-sizing:border-box;'>
              Select mode <span style='position:absolute;right:10px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:12px;pointer-events:none;'>▾</span>
            </button>

            <div id='safetyDropdownMenu'
                 style='display:none;position:absolute;left:0;right:0;top:39px;z-index:60;background:#020617;border:1px solid #334155;border-radius:6px;box-shadow:0 10px 22px rgba(0,0,0,.35);overflow:hidden;'>
            </div>
          </div>
        </div>

        <div class='small' style='margin-bottom:6px;'>Active blockers while armed</div>

        <div id='safetySelectedChips'
             style='display:flex;flex-wrap:wrap;gap:8px;min-height:34px;background:#020617;border:1px solid #334155;border-radius:8px;padding:8px;margin-bottom:12px;'>
        </div>

        <input type='hidden' name='block_when_armed_csv' id='blockWhenArmedCsv'>

        <div style='border-top:1px solid #334155;margin-top:12px;padding-top:12px;'>
          <h3 style='font-size:15px;margin:0 0 6px 0;color:#e5e7eb;'>Airborne arm/disarm protection</h3>

          <p class='small' style='margin:0 0 10px 0;'>
            These protections are visible here, but locked by default. Unlock only if you intentionally want to change them.
          </p>

          <label style='display:flex;align-items:center;gap:8px;margin-bottom:10px;font-size:14px;'>
            <input style='pointer-events:auto;width:auto;margin:0;' type='checkbox' id='unlockAirborneSafety'
                   name='unlock_airborne_safety' value='1'
                   onchange='safetyToggleAirborneUnlock()'>
            <span>Unlock advanced airborne safety settings</span>
          </label>

          <div id='airborneWarn' class='small' style='display:none;color:#fbbf24;margin-bottom:10px;'>
            Advanced safety override enabled. Disabling these can allow disarm commands while the aircraft is airborne.
          </div>

          <div style='display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:8px;margin-bottom:12px;'>
            <label style='display:flex;align-items:center;gap:7px;background:#020617;border:1px solid #334155;border-radius:6px;padding:7px 8px;font-size:14px;line-height:1.2;min-height:32px;'>
              <input class='airborneSafety' disabled style='pointer-events:auto;width:auto;margin:0;' type='checkbox' name='block_disarm_in_air' value='1' {disarm_checked}>
              <span>Block DISARM while in air</span>
            </label>

            <label style='display:flex;align-items:center;gap:7px;background:#020617;border:1px solid #334155;border-radius:6px;padding:7px 8px;font-size:14px;line-height:1.2;min-height:32px;'>
              <input class='airborneSafety' disabled style='pointer-events:auto;width:auto;margin:0;' type='checkbox' name='block_toggle_arm_disarm_in_air' value='1' {toggle_checked}>
              <span>Block TOGGLE_ARM disarm while in air</span>
            </label>
          </div>
        </div>

        <div id='safetySaveStatus' class='small' style='min-height:18px;color:#94a3b8;'>Saved automatically</div>

      </form>

      <script>
      const safetyAllActions = {actions_json};
      let safetySelected = {selected_json};
      let safetySaveTimer=null;

      function safetyRender(){{
        const chipBox=document.getElementById('safetySelectedChips');
        const hidden=document.getElementById('blockWhenArmedCsv');
        const menu=document.getElementById('safetyDropdownMenu');
        const btn=document.getElementById('safetyDropdownButton');

        if(!chipBox || !hidden || !menu || !btn) return;

        hidden.value=safetySelected.join(',');
        btn.textContent='Select mode';

        if(safetySelected.length===0){{
          chipBox.innerHTML="<span class='small'>No flight actions are blocked while armed.</span>";
        }} else {{
          chipBox.innerHTML=safetySelected.map(a =>
            "<span style='display:inline-flex;align-items:center;gap:7px;background:#1e293b;border:1px solid #475569;border-radius:999px;padding:5px 9px;font-size:14px;line-height:1;'>" +
            "<span>" + a + "</span>" +
            "<button type='button' onclick=\\"safetyRemoveBlocker('" + a + "')\\" style='pointer-events:auto;background:#334155;color:#e5e7eb;border:0;border-radius:999px;margin:0;padding:1px 6px;font-size:13px;line-height:1.3;'>×</button>" +
            "</span>"
          ).join("");
        }}

        const available=safetyAllActions.filter(a => !safetySelected.includes(a));

        if(available.length===0){{
          menu.innerHTML="<div class='small' style='padding:9px 10px;'>All modes selected</div>";
          btn.textContent='All modes selected';
        }} else {{
          menu.innerHTML=available.map(a =>
            "<button type='button' onclick=\\"safetyAddBlocker('" + a + "')\\" style='display:block;width:100%;text-align:left;margin:0;background:#020617;color:#e5e7eb;border:0;border-bottom:1px solid #1f2937;border-radius:0;padding:8px 10px;font-size:14px;cursor:pointer;'>" +
            a +
            "</button>"
          ).join("");
        }}
      }}

      function safetyToggleDropdown(){{
        const menu=document.getElementById('safetyDropdownMenu');
        if(!menu) return;
        menu.style.display = menu.style.display==='block' ? 'none' : 'block';
      }}

      function safetyAutosave(){{
        clearTimeout(safetySaveTimer);
        safetySaveTimer=setTimeout(async function(){{
          const st=document.getElementById('safetySaveStatus');
          if(st) st.textContent='Saving...';

          const form=document.querySelector("form[action='/save_button_safety']");
          const fd=new FormData(form);

          try {{
            await fetch('/save_button_safety', {{
              method:'POST',
              body:new URLSearchParams(fd)
            }});
            if(st) st.textContent='Saved automatically';
          }} catch(e) {{
            if(st) st.textContent='Save failed';
          }}
        }}, 1200);
      }}

      function safetyAddBlocker(action){{
        if(!action) return;
        if(!safetySelected.includes(action)){{
          safetySelected.push(action);
        }}
        const menu=document.getElementById('safetyDropdownMenu');
        if(menu) menu.style.display='none';
        safetyRender();
        safetyAutosave();
      }}

      function safetyRemoveBlocker(action){{
        safetySelected=safetySelected.filter(a => a!==action);
        safetyRender();
        safetyAutosave();
      }}

      function safetyToggleAirborneUnlock(){{
        const unlock=document.getElementById('unlockAirborneSafety');
        const warn=document.getElementById('airborneWarn');
        document.querySelectorAll('.airborneSafety').forEach(e => e.disabled = !unlock.checked);
        if(warn) warn.style.display = unlock.checked ? 'block' : 'none';
      }}

      document.addEventListener('click', function(e){{
        const menu=document.getElementById('safetyDropdownMenu');
        const btn=document.getElementById('safetyDropdownButton');
        if(!menu || !btn) return;
        if(menu.contains(e.target) || btn.contains(e.target)) return;
        menu.style.display='none';
      }});

      document.addEventListener('change', function(e){{
        if(e.target && e.target.classList && e.target.classList.contains('airborneSafety')) {{
          safetyAutosave();
        }}
      }});

      safetyRender();
      safetyToggleAirborneUnlock();
      </script>
    </div>
    """

def wifi_profiles_cards():
    active_ssid = sh("iwgetid -r 2>/dev/null || true").strip()
    active_conn = sh("nmcli -g GENERAL.CONNECTION dev show wlan0 2>/dev/null || true").strip()

    # --- LIVE SCAN ---
    scan_map = {}
    try:
        sh("timeout 3s sudo -n nmcli dev wifi rescan ifname wlan0 >/dev/null 2>&1 || true")
        scan = sh("nmcli -t -f SSID,SIGNAL dev wifi list ifname wlan0 2>/dev/null")
        for line in scan.splitlines():
            parts = line.rsplit(":", 1)
            if len(parts) == 2:
                ssid = parts[0].replace("\\:", ":").strip()
                sig = int(parts[1]) if parts[1].isdigit() else 0

                if ssid and ssid != "--":
                    scan_map[ssid] = max(sig, scan_map.get(ssid, 0))
    except Exception:
        pass

    lines = sh("nmcli -t -f NAME,TYPE,DEVICE,AUTOCONNECT connection show").splitlines()

    active_list = []
    visible_list = []
    saved_list = []

    for line in lines:
        parts = line.split(":")
        if len(parts) < 4:
            continue

        name, typ, device, autoconnect = parts[0], parts[1], parts[2], parts[3]

        if typ not in ("wifi", "802-11-wireless"):
            continue

        ssid = sh(f"nmcli -g 802-11-wireless.ssid connection show '{name}' 2>/dev/null || true").strip()

        if not ssid and name == active_conn and active_ssid:
            ssid = active_ssid

        if not ssid:
            ssid = "(unknown)"

        prio = sh(f"nmcli -g connection.autoconnect-priority connection show '{name}' 2>/dev/null || true").strip() or "0"
        psk = wifi_pw_get(name)

        active = (name == active_conn or device == "wlan0")
        visible = ssid in scan_map
        signal = scan_map.get(ssid, 0)

        # --- CLASSIFY ---
        if active:
            state = "active"
        elif visible:
            state = "visible"
        else:
            state = "saved"

        entry = (ssid, name, device, autoconnect, prio, signal, state, psk)

        if state == "active":
            active_list.append(entry)
        elif state == "visible":
            visible_list.append(entry)
        else:
            saved_list.append(entry)

    # --- SORT ---
    visible_list.sort(key=lambda x: -x[5])
    saved_list.sort(key=lambda x: -int(x[4]))

    def render_card(e, highlight=False):
        ssid, name, device, autoconnect, prio, signal, state, psk = e

        if state == "active":
            label = "🟢 Connected"
            cls = "ok"
        elif state == "visible":
            label = f"🔵 In range ({signal}%)"
            cls = "warn"
        else:
            label = "🟡 Saved"
            cls = "bad"

        bars = int(signal / 20)
        signal_bar = "▮" * bars + "▯" * (5 - bars)

        is_system = name.startswith("netplan-")

        if is_system:
            controls = "<div class='readonlybox'>System network (read-only)</div>"
        else:
            controls = f"""
            <div class='inlineform'>
              <button style='pointer-events:auto;' class='switchbtn'   onclick="location.href='/wifi_switch?name={esc(name)}'">Connect</button>
              <label>Priority</label>
              <input style='pointer-events:auto;' value='{esc(prio)}' class='smallinput' readonly>
              <label>Auto</label>
              <span>{esc(autoconnect)}</span>
            </div>
            """

        bg = "#0f1b2e" if highlight else "#0b1220"

        try:
            in_range = int(signal) > 0
        except Exception:
            in_range = False

        wifi_actions = ""
        if not highlight:
            if in_range:
                wifi_actions += f"""
<form method='post' action='/wifi_switch' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<button class='switchbtn'>Connect now</button>
</form>"""

            wifi_actions += f"""
<form method='post' action='/wifi_update_password' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<input style='pointer-events:auto;width:170px;' type='password' name='password' value='{esc(psk)}' placeholder='Wi-Fi password'>
<label class='small'>
<input style='pointer-events:auto;width:auto;' type='checkbox' onclick="this.closest('form').querySelector('input[name=password]').type=this.checked?'text':'password'">
Show
</label>
<button style='pointer-events:auto;' type='submit'>Update password</button>
</form>

<form method='post' action='/wifi_delete' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<button class='danger'>Delete</button>
</form>"""

        return f"""
        <div class='ssidcard' style="background:{bg}; border:1px solid #334155;">
          <div class='ssidtop'>
            <div>
              <div class='ssidtitle'>{esc(ssid)} <span class='status-pill {cls}'>{label}</span></div>
              <div class='ssidmeta'>{signal_bar} {signal}%</div>
              <div class='ssidmeta'> {esc(name)}</div>
            </div>
            <div class='ssidfacts'>
              <div><b>Priority</b><br>{esc(prio)}</div>
              <div><b>Auto</b><br>{esc(autoconnect)}</div>
            </div>
          </div>
          <div class='ssidcontrols'>
<form method='post' action='/wifi_update' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<label>Priority</label>
<input name='priority' value='{esc(prio)}' class='smallinput'>
<label>Autoconnect</label>
<select name='autoconnect' class='smallselect'>
<option {'selected' if autoconnect=='yes' else ''}>yes</option>
<option {'selected' if autoconnect=='no' else ''}>no</option>
</select>
<button>Apply</button>
</form>
{wifi_actions}
</div>
        </div>
        """

    html = ""

    if active_list:
        html += "<h2>Connected</h2>"
        for e in active_list:
            html += render_card(e, True)

    if visible_list:
        html += "<h2>Available Networks</h2>"
        for e in visible_list:
            html += render_card(e)

    if saved_list:
        html += "<h2>Saved Networks</h2>"
        for e in saved_list:
            html += render_card(e)

    return html or "<p>No Wi-Fi profiles found</p>"





# === ARDUPLANE PARAMETER IMPORT V1 ===
PARAM_IMPORT_DAEMON_BASE = "http://127.0.0.1:8765"
PARAM_IMPORT_MAX_REQUEST = 8 * 1024 * 1024
PARAM_IMPORT_METADATA_CACHE_FILES = (
    "/etc/siyi/arduplane_param_metadata.json",
    "/etc/siyi/param_metadata_cache.json",
    "/tmp/siyi_param_cache.json",
)
PARAM_IMPORT_METADATA_HOVER_MARKER = "PARAM_IMPORT_METADATA_HOVER_V3"
PARAM_IMPORT_METADATA_EMBED_MARKER = "PARAM_IMPORT_METADATA_EMBED_V1"
_param_import_metadata_lock = threading.Lock()
_param_import_metadata_signature = None
_param_import_metadata_params = {}
_param_import_metadata_sources = []
_param_import_metadata_errors = []


def _param_import_metadata_signature_now():
    signature = []
    for path in PARAM_IMPORT_METADATA_CACHE_FILES:
        try:
            stat = os.stat(path)
            signature.append((path, stat.st_mtime_ns, stat.st_size))
        except OSError:
            continue
    return tuple(signature)


def _param_import_reload_metadata():
    global _param_import_metadata_signature
    global _param_import_metadata_params
    global _param_import_metadata_sources
    global _param_import_metadata_errors

    signature = _param_import_metadata_signature_now()
    if signature == _param_import_metadata_signature:
        return

    merged = {}
    sources = []
    errors = []

    for path, _mtime, _size in signature:
        try:
            with open(path, "r", encoding="utf-8") as handle:
                raw = json.load(handle)
            params = raw.get("params", {}) if isinstance(raw, dict) else {}
            if not isinstance(params, dict):
                raise ValueError("top-level params field is not an object")

            added = 0
            for param_name, meta in params.items():
                normalized = str(param_name or "").strip().upper()
                if not normalized or normalized in merged or not isinstance(meta, dict):
                    continue
                merged[normalized] = meta
                added += 1

            sources.append({"path": path, "entries": len(params), "added": added})
            metadata_error = raw.get("metadata_error") if isinstance(raw, dict) else None
            if metadata_error:
                errors.append(path + ": " + str(metadata_error))
        except Exception as exc:
            errors.append(path + ": " + str(exc))

    _param_import_metadata_params = merged
    _param_import_metadata_sources = sources
    _param_import_metadata_errors = errors
    _param_import_metadata_signature = signature


def param_import_metadata_lookup(name):
    """Return sanitized ArduPilot metadata for one parameter."""
    name = str(name or "").strip().upper()
    if not re.fullmatch(r"[A-Z0-9_]{1,64}", name):
        raise ValueError("Invalid parameter name")

    with _param_import_metadata_lock:
        _param_import_reload_metadata()
        meta = _param_import_metadata_params.get(name)
        sources = list(_param_import_metadata_sources)
        errors = list(_param_import_metadata_errors)

    if not isinstance(meta, dict):
        if not sources:
            message = (
                "Parameter metadata cache is not available. "
                "Run the metadata refresh or perform a full parameter refresh."
            )
        else:
            message = "No ArduPilot metadata is available for this parameter."
        if errors:
            message += " " + errors[-1]
        return {
            "ok": True,
            "name": name,
            "available": False,
            "message": message,
            "sources": sources,
        }

    fields = meta.get("fields") or {}
    values = meta.get("values") or {}
    if not isinstance(fields, dict):
        fields = {}
    if not isinstance(values, dict):
        values = {}

    human_name = str(meta.get("humanName") or "")
    documentation = str(meta.get("documentation") or "")
    user_level = str(meta.get("user") or "")
    descriptive = bool(human_name or documentation or user_level or fields or values)

    if not descriptive:
        message = "The parameter exists in the value cache, but descriptive ArduPilot metadata is missing."
        if errors:
            message += " " + errors[-1]
        return {
            "ok": True,
            "name": name,
            "available": False,
            "message": message,
            "sources": sources,
        }

    return {
        "ok": True,
        "name": name,
        "available": True,
        "humanName": human_name,
        "documentation": documentation,
        "user": user_level,
        "type": meta.get("type"),
        "fields": {str(key): str(value) for key, value in fields.items()},
        "values": {str(key): str(value) for key, value in values.items()},
        "sources": sources,
    }


def param_import_attach_metadata(result):
    """Embed metadata in import preview entries so hover does not need a second request."""
    if not isinstance(result, dict):
        return result
    entries = result.get("entries")
    if not isinstance(entries, list):
        return result

    for entry in entries:
        if not isinstance(entry, dict):
            continue
        name = str(entry.get("name") or "").strip().upper()
        if not name:
            continue
        try:
            entry["metadata"] = param_import_metadata_lookup(name)
        except Exception as exc:
            entry["metadata"] = {
                "ok": False,
                "name": name,
                "available": False,
                "message": "Metadata lookup failed: " + str(exc),
            }
    return result


def param_import_daemon_request(path, method="GET", payload=None, timeout=35):
    url = PARAM_IMPORT_DAEMON_BASE + path
    body = None
    headers = {"Accept": "application/json"}
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read(PARAM_IMPORT_MAX_REQUEST)
    except urllib.error.HTTPError as exc:
        raw = exc.read(PARAM_IMPORT_MAX_REQUEST)
    data = json.loads(raw.decode("utf-8", errors="replace"))
    if not isinstance(data, dict):
        raise ValueError("Parameter daemon returned an invalid response")
    return data


def send_json_response(handler, payload, status=200):
    raw = json.dumps(payload).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def send_param_import_download(handler, daemon_path):
    result = param_import_daemon_request(daemon_path)
    if not result.get("ok"):
        send_json_response(handler, result, 400)
        return
    filename = re.sub(r"[^A-Za-z0-9._-]+", "_", str(result.get("filename", "download.txt")))
    raw = str(result.get("content", "")).encode("utf-8")
    handler.send_response(200)
    handler.send_header("Content-Type", "text/plain; charset=utf-8")
    handler.send_header("Content-Disposition", f'attachment; filename="{filename}"')
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)
# === ARDUPLANE PARAMETER IMPORT V1 END ===

def arduplane_parameters_page():

    import json
    from html import escape as esc

    cache="/etc/siyi/param_metadata_cache.json"

    QGC_LEVELS = {
        "Standard": [
            "ACRO","AHRS","AIRSPEED","ARMING","ARSPD","AUTOTUNE","BATT","BRD",
            "CAM","CHUTE","COMPASS","FBWB","FENCE","FLTMODE","FRSKY","FS",
            "GROUND","KFF","LAND","LGR","LOG","MAN","MIXING","MNT","MSP",
            "NAVL","OSD","PTCH2SRV","PTCH","RC","RLL","SERIAL","SERVO",
            "TECS","THR","TKOFF","YAW","Misc"
        ],
        "Advanced": [
            "AHRS","ARMING","ARSPD","AUTOTUNE","BARO","BATT","BRD","BTN",
            "COMPASS","CRASH","DSPOILER","EK","FLAP","FLTMODE","FRSKY","FS",
            "FWD","GLIDE","GPS","GROUND","INS","KFF","LAND","LOG","MIS",
            "MNT","NAVL","NTF","OSD","PTCH2SRV","PTCH","Q","RALLY","RC",
            "RLL","RNGFND","RNGFNDA","RPM","RSSI","RTL","SERIAL","SERVO",
            "STAT","STEER2SRV","TECS","TERRAIN","THR","TKOFF","TUNE","WP","Misc"
        ],
        "Other": [
            "BARO","CAM","COMPASS","EK","INS","NTF","OSD","PTCH","RELAY","RLL","VTX"
        ],
    }

    try:
        with open(cache) as f:
            raw=json.load(f)
            data=raw.get("params", {})
            received=raw.get("received_count", len(data))
            expected=raw.get("expected_count", "?")
            meta_error=raw.get("metadata_error", "")
    except Exception:
        data={}
        received=0
        expected="?"
        meta_error=""

    # Live paramd fallback: if metadata cache is empty/stale, build page from live /state.
    if not data:
        try:
            import urllib.request
            with urllib.request.urlopen("http://127.0.0.1:8765/state", timeout=5) as r:
                live=json.loads(r.read().decode("utf-8", errors="ignore"))
            live_params=live.get("params", {})
            if live_params:
                data={k: {"value": v.get("value"), "type": v.get("type")} for k,v in live_params.items()}
                received=len(data)
                expected=received
        except Exception as e:
            meta_error = "Live paramd fallback failed: " + repr(e)

    def qgc_group(name):
        special = ["PTCH2SRV", "STEER2SRV", "RNGFNDA", "RNGFND"]
        for sp in special:
            if name.startswith(sp):
                return sp

        first = name.split("_", 1)[0]
        first = re.sub(r"\d+$", "", first)

        if not first:
            first = "Misc"

        return first

    groups={}

    for k,v in sorted(data.items()):
        grp=qgc_group(k)
        groups.setdefault(grp,[]).append((k,v))

    all_groups = sorted(groups.keys())

    def level_for_group(grp):
        levels=[]
        for level, names in QGC_LEVELS.items():
            if grp in names:
                levels.append(level)
        if not levels:
            levels.append("Other")
        return " ".join(levels)

    def group_buttons_for_level(level):
        if level == "All":
            ordered = all_groups
        else:
            ordered = [g for g in QGC_LEVELS.get(level, []) if g in groups]
            extras = [g for g in all_groups if g not in ordered and level in level_for_group(g)]
            ordered += extras

        out = ""
        for grp in ordered:
            safe_grp=esc(grp)
            level_attr=esc(level_for_group(grp))
            out += f"""
            <button type='button'
                    class='paramGroupBtn'
                    data-group='{safe_grp}'
                    data-levels='{level_attr}'
                    onclick="paramFilterGroup('{safe_grp}')">
              {safe_grp}
              <span class='small'>({len(groups.get(grp, []))})</span>
            </button>
            """
        return out

    body=f"""

    <h1>ArduPlane Parameters</h1>

    <div class='card paramTopCompact'>
      <span class='paramTopTitle'>ArduPlane parameter configurator</span>
      <span class='paramTopDivider'></span>
      <span class='small paramTopLoaded'>Loaded parameters: {received}/{expected}</span>
      {("<span class='small' style='color:#f97316;'>Metadata warning: " + esc(meta_error) + "</span>") if meta_error else ""}

      <form onsubmit='return paramManualFullSync(event);' class='paramTopRefreshForm'>
        <button style='pointer-events:auto;'>Refresh Parameters From FC</button>
      </form>

      <a id='fcParamExportBtn'
         class='paramTopRefreshForm'
         href='/fc_parameter_export'
         onclick='return fcParameterExportClick(event);'
         style='pointer-events:auto;display:inline-block;text-decoration:none;background:#2563eb;color:white;border:0;border-radius:8px;padding:9px 13px;margin:4px;cursor:pointer;'>
        FC Parameter Export
      </a>
      <span id='fcExportChromeNote' class='small' style='display:none;color:#94a3b8;margin-left:8px;'>If Chrome blocks the download, open download history and choose Keep.</span>

      <input id='paramImportFileInput'
             type='file'
             accept='.params,.param,.txt,text/plain'
             style='display:none;'
             onchange='paramImportFileSelected(this)'>
      <button type='button'
              class='paramTopRefreshForm'
              style='pointer-events:auto;background:#0f766e;'
              onclick="document.getElementById('paramImportFileInput').click()">
        Import Parameter File
      </button>

      <span class='small paramTopStatus' id='paramRefreshStatus'></span>
    </div>


    <div id='paramImportOverlay' class='paramImportOverlay' aria-hidden='true'>
      <div class='paramImportDialog' role='dialog' aria-modal='true' aria-labelledby='paramImportTitle'>
        <div class='paramImportHeader'>
          <div>
            <h2 id='paramImportTitle'>Import ArduPlane parameters</h2>
            <div id='paramImportSubtitle' class='small'>Select a parameter file to begin.</div>
          </div>
          <button id='paramImportCloseTop' type='button' class='paramImportClose' onclick='paramImportClose()'>&times;</button>
        </div>

        <div id='paramImportLoading' class='paramImportLoading' style='display:none;'>
          <span class='paramImportSpinner'></span>
          <span id='paramImportLoadingText'>Reading and comparing parameters...</span>
        </div>

        <div id='paramImportPreviewPanel' style='display:none;'>
          <div id='paramImportSummary' class='paramImportSummary'></div>
          <div id='paramImportSafety' class='paramImportSafety'></div>
          <div class='paramImportToolbar'>
            <label>Show
              <select id='paramImportFilter' onchange='paramImportApplyFilter()'>
                <option value='changed'>Changed only</option>
                <option value='warnings'>Warnings</option>
                <option value='all'>All parsed parameters</option>
              </select>
            </label>
            <label class='paramImportSelectAll'>
              <input id='paramImportSelectAll' type='checkbox' checked onchange='paramImportToggleAll(this.checked)'>
              Select all applicable changes
            </label>
            <span id='paramImportSelectedCount' class='small'></span>
          </div>
          <div class='paramImportTableWrap'>
            <table class='paramImportTable'>
              <thead><tr><th>Apply</th><th>Parameter</th><th>Current</th><th>Imported</th><th>Status</th><th>Warning</th></tr></thead>
              <tbody id='paramImportRows'></tbody>
            </table>
          </div>
        </div>

        <div id='paramImportProgressPanel' style='display:none;'>
          <div class='paramImportRunStatus'>
            <span id='paramImportRunSpinner' class='paramImportSpinner'></span>
            <div>
              <strong id='paramImportRunTitle'>Applying parameters</strong>
              <div id='paramImportRunMessage' class='small'>Preparing...</div>
            </div>
          </div>
          <div class='paramImportProgressTrack'><div id='paramImportProgressBar'></div></div>
          <div class='paramImportProgressFacts'>
            <span id='paramImportProgressText'>0 of 0 verified</span>
            <strong id='paramImportProgressPercent'>0.0%</strong>
          </div>
          <div id='paramImportCurrentParam' class='paramImportCurrent'></div>
          <div id='paramImportEventLog' class='paramImportEventLog'></div>
        </div>

        <div id='paramImportError' class='paramImportError' style='display:none;'></div>

        <div class='paramImportFooter'>
          <button id='paramImportCancelBtn' type='button' class='danger' style='display:none;' onclick='paramImportCancelJob()'>Cancel operation</button>
          <a id='paramImportBackupBtn' class='paramImportDownload' style='display:none;'>Download pre-import backup</a>
          <a id='paramImportReportBtn' class='paramImportDownload' style='display:none;'>Download result report</a>
          <button id='paramImportRollbackBtn' type='button' class='danger' style='display:none;' onclick='paramImportRollback()'>Restore verified changes</button>
          <button id='paramImportApplyBtn' type='button' style='display:none;' onclick='paramImportApply()'>Apply selected parameters</button>
          <button id='paramImportCloseBtn' type='button' onclick='paramImportClose()'>Close</button>
        </div>
      </div>
      <div id='paramImportMetaPopup'
           class='paramImportMetaPopup'
           role='tooltip'
           aria-hidden='true'>
        <div class='paramImportMetaHeader'>
          <div>
            <div id='paramImportMetaName' class='paramImportMetaName'></div>
            <div id='paramImportMetaHuman' class='paramImportMetaHuman'></div>
          </div>
          <span class='paramImportMetaHint'>Parameter metadata</span>
        </div>
        <div id='paramImportMetaBody' class='paramImportMetaBody'></div>
      </div>
    </div>

    <style>
      .paramImportOverlay{{position:fixed;inset:0;background:rgba(2,6,23,.86);backdrop-filter:blur(4px);z-index:12000;display:none;align-items:center;justify-content:center;padding:24px;}}
      .paramImportOverlay.open{{display:flex;}}
      .paramImportDialog{{width:min(1180px,96vw);height:min(820px,92vh);background:#0f172a;border:1px solid #475569;border-radius:16px;box-shadow:0 24px 80px rgba(0,0,0,.55);display:flex;flex-direction:column;overflow:hidden;}}
      .paramImportHeader{{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;padding:18px 20px;border-bottom:1px solid #334155;background:#111827;}}
      .paramImportHeader h2{{margin:0 0 5px 0;}}
      .paramImportClose{{background:transparent;border:1px solid #475569;font-size:24px;line-height:1;padding:4px 10px;margin:0;}}
      .paramImportLoading{{flex:1;display:flex;align-items:center;justify-content:center;gap:14px;font-size:18px;}}
      .paramImportSpinner{{display:inline-block;width:24px;height:24px;border:3px solid #475569;border-top-color:#38bdf8;border-radius:50%;animation:paramImportSpin .85s linear infinite;flex:0 0 auto;}}
      @keyframes paramImportSpin{{to{{transform:rotate(360deg)}}}}
      #paramImportPreviewPanel,#paramImportProgressPanel{{padding:16px 20px;min-height:0;overflow:hidden;flex:1;}}
      #paramImportPreviewPanel{{display:flex;flex-direction:column;}}
      .paramImportSummary{{display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:8px;margin-bottom:10px;}}
      .paramImportSummaryItem{{background:#111827;border:1px solid #334155;border-radius:9px;padding:9px 11px;}}
      .paramImportSummaryItem strong{{display:block;font-size:20px;}}
      .paramImportSafety{{display:none;background:#451a03;border:1px solid #f97316;color:#fed7aa;border-radius:9px;padding:10px 12px;margin-bottom:10px;}}
      .paramImportToolbar{{display:flex;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:10px;}}
      .paramImportToolbar label{{display:flex;align-items:center;gap:8px;}}
      .paramImportToolbar select{{width:auto;min-width:150px;}}
      .paramImportSelectAll input{{width:auto;}}
      .paramImportTableWrap{{overflow:auto;border:1px solid #334155;border-radius:10px;flex:1;min-height:0;}}
      .paramImportTable{{min-width:920px;}}
      .paramImportTable thead{{position:sticky;top:0;background:#111827;z-index:1;}}
      .paramImportTable input{{width:auto;}}
      .paramImportStatus{{display:inline-block;padding:3px 8px;border-radius:999px;background:#334155;font-size:12px;white-space:nowrap;}}
      .paramImportStatus.changed{{background:#1e3a8a;color:#bfdbfe}}.paramImportStatus.same{{background:#14532d;color:#bbf7d0}}.paramImportStatus.unsupported,.paramImportStatus.duplicate{{background:#7c2d12;color:#fed7aa;}}
      .paramImportWarning{{color:#fbbf24;font-size:12px;max-width:360px;}}
      .paramImportMetaRow{{cursor:help;}}
      .paramImportMetaRow:hover{{background:#172033;}}
      .paramImportMetaParamName{{font-weight:800;color:#bae6fd;text-decoration:underline;text-decoration-style:dotted;text-underline-offset:3px;}}
      .paramImportMetaPopup{{position:fixed;display:none;width:min(480px,calc(100vw - 24px));max-height:min(580px,calc(100vh - 24px));overflow:auto;background:#020617;border:1px solid #64748b;border-radius:12px;box-shadow:0 18px 55px rgba(0,0,0,.72);z-index:12050;padding:0;pointer-events:none;}}
      .paramImportMetaPopup.open{{display:block;}}
      .paramImportMetaHeader{{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;padding:13px 15px;border-bottom:1px solid #334155;background:#111827;position:sticky;top:0;}}
      .paramImportMetaName{{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-weight:900;color:#7dd3fc;font-size:16px;}}
      .paramImportMetaHuman{{font-weight:700;color:#e2e8f0;margin-top:3px;}}
      .paramImportMetaHint{{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#94a3b8;white-space:nowrap;}}
      .paramImportMetaBody{{padding:13px 15px;color:#dbeafe;font-size:13px;line-height:1.45;}}
      .paramImportMetaDescription{{white-space:pre-wrap;margin-bottom:11px;}}
      .paramImportMetaGrid{{display:grid;grid-template-columns:max-content 1fr;gap:5px 12px;margin:8px 0 12px;}}
      .paramImportMetaKey{{color:#94a3b8;font-weight:700;}}
      .paramImportMetaValue{{color:#e2e8f0;overflow-wrap:anywhere;}}
      .paramImportMetaEnums{{border-top:1px solid #334155;padding-top:9px;margin-top:9px;}}
      .paramImportMetaEnumsTitle{{font-weight:800;color:#cbd5e1;margin-bottom:5px;}}
      .paramImportMetaEnumLine{{display:grid;grid-template-columns:minmax(52px,max-content) 1fr;gap:10px;padding:2px 0;}}
      .paramImportMetaEnumCode{{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;color:#7dd3fc;}}
      .paramImportMetaMuted{{color:#94a3b8;font-style:italic;}}
      .paramImportRunStatus{{display:flex;align-items:center;gap:14px;margin-bottom:18px;}}
      .paramImportProgressTrack{{height:18px;border-radius:999px;background:#020617;border:1px solid #334155;overflow:hidden;}}
      #paramImportProgressBar{{height:100%;width:0;background:linear-gradient(90deg,#0284c7,#22c55e);transition:width .3s ease;}}
      .paramImportProgressFacts{{display:flex;justify-content:space-between;margin:9px 0 12px;}}
      .paramImportCurrent{{min-height:24px;color:#bae6fd;font-weight:700;margin-bottom:10px;}}
      .paramImportEventLog{{height:calc(100% - 145px);min-height:220px;overflow:auto;background:#020617;border:1px solid #334155;border-radius:10px;padding:12px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:13px;white-space:pre-wrap;}}
      .paramImportEventLine{{padding:2px 0}}.paramImportEventLine.ok,.paramImportEventLine.complete{{color:#86efac}}.paramImportEventLine.warning{{color:#fbbf24}}.paramImportEventLine.error{{color:#fca5a5;}}
      .paramImportError{{margin:12px 20px 0;padding:10px 12px;background:#450a0a;border:1px solid #ef4444;color:#fecaca;border-radius:9px;}}
      .paramImportFooter{{display:flex;justify-content:flex-end;align-items:center;gap:8px;flex-wrap:wrap;padding:14px 20px;border-top:1px solid #334155;background:#111827;}}
      .paramImportDownload{{display:inline-block;background:#334155;color:white;border-radius:8px;padding:9px 13px;text-decoration:none;cursor:pointer;}}
      @media(max-width:700px){{.paramImportOverlay{{padding:5px}}.paramImportDialog{{width:99vw;height:98vh}}.paramImportHeader{{padding:12px}}.paramImportFooter{{padding:10px}}.paramImportSummary{{grid-template-columns:repeat(2,1fr)}}}}
    </style>

    <div class='paramLayout'>

      <div class='paramSide'>
        <h2>Parameter Groups</h2>

        <div class='paramLevelTabs'>

        </div>

        <div id='paramGroupButtons'>
          <button type='button' class='paramGroupBtn active' data-group='__ALL__' data-levels='All Standard Advanced Other' onclick="paramFilterGroup('__ALL__')">
            All <span class='small'>({len(data)})</span>
          </button>

          {group_buttons_for_level("All")}
        </div>
      </div>

      <div class='paramMain'>
        <div class='card paramToolbar'>
          <div class='paramSearchMainRow'>

            <input id='paramSearch'
                   style='pointer-events:auto;width:100%;'
                   placeholder='Search parameter, e.g. MNT_ or SERIAL4'
                   oninput='paramSaveState(); paramApplyFilter()'>

            <select id='paramSearchMode'
                    style='pointer-events:auto;'
                    onchange='paramSaveState(); paramApplyFilter()'>
              <option value='contains'>Contains</option>
              <option value='startswith' selected>Begins with</option>
            </select>

            <button type='button'
                    onclick='paramClearSearch()'
                    title="Clear search" aria-label="Clear search" style="width:28px;height:28px;min-width:28px;padding:0;display:inline-flex;align-items:center;justify-content:center;font-size:20px;font-weight:800;line-height:1;color:#fca5a5;background:transparent;border:1px solid #c8ccd2;border-radius:6px;cursor:pointer;">&times;</button>

          </div>

          <div class='paramSearchSecondaryRow'>

            <select id='paramQuickSearch'
                    class='paramQuickSearchSelect'
                    onchange='paramApplyQuickSearch(this)'>
              <option value=''>Quick search...</option>
            </select>

            <button type='button'
                    class='paramQuickActionBtn'
                    title='Freeze current search'
                    onclick='paramFreezeCurrentSearch()'>
              ❄ Freeze
            </button>

            <button type='button'
                    class='paramQuickActionBtn'
                    title='Unfreeze current search'
                    onclick='paramUnfreezeCurrentSearch()'>
              ↺ Unfreeze
            </button>

            <button type='button'
                    class='paramQuickActionBtn paramQuickDeleteBtn'
                    title='Delete current search from quick list'
                    onclick='paramDeleteCurrentSearch()'>
              × Remove
            </button>

          </div>

          <div class='paramSearchFooterRow'>
            <p class='small' id='paramResultCount'></p>

            <span class='small paramWildcardHint'>
              * = any chars&nbsp;&nbsp;? = one char
            </span>
          </div>
        </div>
    """

    body += "<div class='paramScrollArea'>"

    for grp in all_groups:

        body += f"""
        <div class='card paramGroupCard' data-group='{esc(grp)}' data-levels='{esc(level_for_group(grp))}'>
          <h2>{esc(grp)}</h2>
          <div class='paramList'>
        """

        for name,val in groups[grp]:

            search_blob = name

            if val is None:
                value_display="<span style='color:#ef4444;'>Missing</span>"
                desc_html="<span class='small'>Timeout reading parameter</span>"
                level="Other"
            else:
                raw_val=str(val.get("value"))
                label=val.get("value_label") or ""
                values=val.get("values") or {}

                if values:
                    opts=""
                    current_key=str(int(float(raw_val))) if str(raw_val).replace(".0","").lstrip("-").isdigit() else str(raw_val)
                    for code,text in sorted(values.items(), key=lambda x: float(x[0]) if str(x[0]).replace(".","",1).lstrip("-").isdigit() else 999999):
                        selected="selected" if str(code)==current_key else ""
                        opts += f"<option value='{esc(str(code))}' {selected}>{esc(str(text))} ({esc(str(code))})</option>"

                    editor=f"""
                    <select name='value' class='paramEditInput'>
                      {opts}
                    </select>
                    """
                else:
                    editor=f"<input name='value' class='paramEditInput' value='{esc(raw_val)}'>"

                if label:
                    value_display=f"<b>{esc(label)}</b> <span class='small'>({esc(raw_val)})</span>"
                else:
                    value_display=f"<b>{esc(raw_val)}</b>"

                value_display += f"""
                <form method='post'
                      action='/param_write'
                      class='paramWriteForm'
                      onsubmit="return confirm('Write parameter {esc(name)} ?');">
                  <input type='hidden' name='name' value='{esc(name)}'>
                  {editor}
                  <button type='submit' class='paramWriteBtn'>Write</button>
                </form>
                """

                human=val.get("humanName") or ""
                doc=val.get("documentation") or ""
                user=val.get("user") or ""

                if human or doc:
                    desc_html=f"<span>{esc(human)}</span><br><span class='small'>{esc(doc)}</span>"
                else:
                    desc_html="<span class='small'>No metadata description</span>"

                level=user or "Other"

                search_blob = " ".join([
                    name,
                    str(label),
                    str(human),
                    str(doc),
                    str(grp),
                    str(level),
                ])

            body += f"""
            <div class='paramRow'
                 data-group='{esc(grp)}'
                 data-levels='{esc(level_for_group(grp))}'
                 data-param='{esc(name)}'
                 data-paramname='{esc(name)}'
                 data-search='{esc(search_blob.lower())}'>
              <div class='paramName'>{esc(name)}</div>
              <div class='paramValue' id='paramValue_{esc(name)}'>{value_display}</div>
              <div class='paramDesc'>{desc_html}</div>
            </div>
            """

        body += "</div></div>"

    body += """
      </div>
      </div>
    </div>

    <style>
      .paramLayout{
        display:grid;
        grid-template-columns:270px 1fr;
        gap:16px;
        align-items:start;
        overflow:visible;
      }
      .paramTopCompact{
        display:flex;
        align-items:center;
        gap:16px;
        flex-wrap:wrap;
        padding:10px 16px;
        margin-bottom:10px;
      }
      .paramTopCompact p,
      .paramTopCompact form{
        margin:0;
      }
      .paramTopTitle{
        font-weight:bold;
      }
      .paramTopDivider{
        width:1px;
        height:24px;
        background:#475569;
      }
      .paramTopRefreshForm{
        display:inline-flex;
        align-items:center;
      }
      .paramTopStatus{
        color:#22c55e;
        font-weight:bold;
      }

      .paramSide{
        height:calc(100vh - var(--paramPaneTop, 190px) - 24px);
        min-height:0;
        overflow:auto;
        box-sizing:border-box;
        background:#0b1220;
        border:1px solid #334155;
        border-radius:10px;
        padding:12px;
      }
      .paramSide h2{
        margin-top:0;
        position:sticky;
        top:-12px;
        z-index:20;
        background:#0b1220;
        padding:4px 0 10px 0;
      }
      .paramLevelTabs{
        display:grid;
        grid-template-columns:1fr 1fr;
        gap:6px;
        margin-bottom:12px;
      }
      .paramLevelBtn{
        margin:0;
        padding:8px 6px;
        background:#374151;
        border:1px solid #4b5563;
        color:#e5e7eb;
      }
      .paramLevelBtn.active{
        background:#fff27a;
        color:#111827;
        border-color:#fde047;
      }
      .paramGroupBtn{
        display:block;
        width:100%;
        text-align:center;
        margin:6px 0;
        padding:10px 8px;
        background:#747484;
        border:1px solid #747484;
        color:white;
        border-radius:5px;
      }
      .paramGroupBtn.active{
        background:#fff27a;
        color:#111827;
        border-color:#fde047;
      }
      .paramMain{
        min-width:0;
        height:calc(100vh - var(--paramPaneTop, 190px) - 24px);
        min-height:0;
        box-sizing:border-box;
        display:flex;
        flex-direction:column;
        overflow:hidden;
      }
      .paramToolbar{
        flex:0 0 auto;
        margin-bottom:0;
      }
      .paramScrollArea{
        flex:1 1 auto;
        overflow-y:auto;
        padding-right:6px;
        min-height:0;
      }
      .paramSearchBar{
        display:grid;
        grid-template-columns:minmax(260px, 1fr) minmax(180px, 260px) auto minmax(220px, auto);
        gap:10px;
        align-items:center;
      }
      .paramSearchMainRow{
        display:grid;
        grid-template-columns:minmax(320px,1fr) 180px auto;
        gap:10px;
        align-items:center;
      }

      .paramSearchSecondaryRow{
        margin-top:8px;
        display:flex;
        align-items:center;
        gap:8px;
        flex-wrap:wrap;
        opacity:.88;
      }

      .paramSearchFooterRow{
        margin-top:8px;
        display:flex;
        justify-content:space-between;
        align-items:center;
        gap:12px;
      }

      .paramQuickSearchSelect{
        min-width:220px;
        max-width:320px;
        pointer-events:auto;
      }

      .paramWildcardHint{
        color:#94a3b8;
        white-space:nowrap;
      }

      .paramQuickActionBtn{
        height:28px;
        padding:0 10px;
        border-radius:999px;
        font-size:12px;
        background:#0f172a;
        color:#94a3b8;
        border:1px solid #334155;
      }

      .paramQuickActionBtn:hover{
        color:#e5e7eb;
        border-color:#64748b;
        background:#111827;
      }

      .paramQuickDeleteBtn{
        color:#fca5a5;
      }

      .paramQuickDeleteBtn:hover{
        color:#fecaca;
      }
      .paramSearchBar input,
      .paramSearchBar select{
        width:100% !important;
        max-width:none !important;
        box-sizing:border-box;
      }
      .paramSearchBar select{
        background:#020617;
        color:#e5e7eb;
        border:1px solid #334155;
        border-radius:8px;
        padding:9px 10px;
      }
      .paramQuickActionBtn{
        pointer-events:auto;
        width:30px;
        height:30px;
        padding:0;
        margin:0;
        border-radius:999px;
        border:1px solid #334155;
        background:#0b1220;
        color:#94a3b8;
        font-size:14px;
        line-height:1;
        opacity:.78;
      }
      .paramQuickActionBtn:hover{
        opacity:1;
        color:#e5e7eb;
        border-color:#64748b;
        background:#111827;
      }
      .paramQuickDeleteBtn{
        color:#fca5a5;
      }
      .paramQuickDeleteBtn:hover{
        color:#fecaca;
        border-color:#7f1d1d;
      }
      .paramToolbar{
        padding:10px 12px;
      }
      #paramResultCount{
        margin:8px 0 0 0;
      }
      .paramList{display:flex;flex-direction:column;}
      .paramRow{
        display:grid;
        grid-template-columns:210px 170px 1fr;
        gap:16px;
        padding:7px 4px;
        border-bottom:1px solid rgba(148,163,184,.18);
        align-items:start;
        cursor:pointer;
      }
      .paramRow:hover{background:#111827;}
      .paramName{
        color:#dbeafe;
        font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size:14px;
      }
      .paramValue{
        color:#e5e7eb;
        font-size:14px;
      }
      .paramDesc{
        color:#cbd5e1;
        font-size:13px;
      }
      .paramWriteForm{
        margin-top:7px;
        display:flex;
        gap:6px;
        align-items:center;
        flex-wrap:wrap;
      }
      .paramEditInput{
        pointer-events:auto;
        width:130px;
        background:#020617;
        color:#e5e7eb;
        border:1px solid #334155;
        border-radius:7px;
        padding:6px 8px;
      }
      .paramWriteBtn{
        pointer-events:auto;
        padding:6px 9px;
        font-size:12px;
        background:#14532d;
      }
      .paramHidden{display:none !important;}
      @media (max-width:1000px){
        .paramLayout{
          grid-template-columns:1fr;
          height:auto;
          overflow:visible;
        }
        .paramSide{position:relative;max-height:none;}
        .paramMain{
          height:auto;
          overflow:visible;
          display:block;
        }
        .paramScrollArea{
          overflow:visible;
        }
        .paramRow{grid-template-columns:1fr;}
      }


      /* ===== PARAM TOOLBAR FINAL POLISH ===== */

      .paramSearchMainRow{
        grid-template-columns:340px 180px auto !important;
        align-items:center !important;
      }

      .paramSearchSecondaryRow{
        margin-top:8px !important;
        display:grid !important;
        grid-template-columns:340px 36px 36px 36px !important;
        gap:8px !important;
        align-items:center !important;
      }

      .paramSearchMainRow input{
        width:340px !important;
        max-width:340px !important;
      }

      .paramQuickSearchSelect{
        width:340px !important;
        max-width:340px !important;
        min-width:340px !important;
      }

      .paramIconBtn,
      .paramQuickActionBtn{
        width:36px !important;
        height:36px !important;
        min-width:36px !important;
        padding:0 !important;
        border-radius:8px !important;

        display:flex !important;
        align-items:center !important;
        justify-content:center !important;

        font-size:16px !important;
        line-height:1 !important;

        background:#0f172a !important;
        border:1px solid #334155 !important;

        overflow:hidden !important;
        text-indent:-9999px !important;
        position:relative !important;
      }

      .paramIconBtn::before,
      .paramQuickActionBtn::before{
        position:absolute;
        inset:0;
        display:flex;
        align-items:center;
        justify-content:center;
        text-indent:0;
        font-size:16px;
      }

      button[onclick*='Freeze']::before{
        content:'❄';
        color:#93c5fd;
      }

      button[onclick*='Unfreeze']::before{
        content:'↺';
        color:#cbd5e1;
      }

      button[onclick*='Delete']::before{
        content:'×';
        color:#fca5a5;
        font-size:18px;
        font-weight:700;
      }

      .paramIconBtn:hover,
      .paramQuickActionBtn:hover{
        border-color:#64748b !important;
        background:#111827 !important;
      }


    </style>

    <script>
      let selectedParamLevel='All';
      let selectedParamGroup='__ALL__';

      function paramUpdatePaneHeights(){
        try{
          const side=document.querySelector('.paramSide');
          const main=document.querySelector('.paramMain');
          const el=side || main;
          if(!el){return;}
          const top=Math.ceil(el.getBoundingClientRect().top);
          document.documentElement.style.setProperty('--paramPaneTop', top + 'px');
        }catch(e){}
      }

      function paramDeleteCurrentSearch(){
        const input=document.getElementById('paramSearch');
        const value=String(input?.value || '').trim();

        if(!value){return;}

        let data=paramHistoryLoad();
        const key=value.toLowerCase();

        data.frozen=data.frozen.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.recent=data.recent.filter(function(v){
          return v.toLowerCase() !== key;
        });

        paramHistorySave(data);
        paramHistoryRender();
      }

      window.addEventListener('load', function(){
        paramUpdatePaneHeights();
        setTimeout(paramUpdatePaneHeights, 50);
      });
      window.addEventListener('resize', paramUpdatePaneHeights);

      function paramSaveState(){
        try{
          localStorage.setItem('siyi_param_level', selectedParamLevel);
          localStorage.setItem('siyi_param_group', selectedParamGroup);
          localStorage.setItem('siyi_param_search', document.getElementById('paramSearch')?.value || '');
          localStorage.setItem('siyi_param_search_mode', document.getElementById('paramSearchMode')?.value || 'startswith');
        }catch(e){}
      }

      function paramRestoreState(){
        try{
          selectedParamLevel = localStorage.getItem('siyi_param_level') || 'All';
          selectedParamGroup = localStorage.getItem('siyi_param_group') || '__ALL__';

          const search=document.getElementById('paramSearch');
          if(search){ search.value = localStorage.getItem('siyi_param_search') || ''; }

          const mode=document.getElementById('paramSearchMode');
          if(mode){ mode.value = localStorage.getItem('siyi_param_search_mode') || 'startswith'; }
        }catch(e){
          selectedParamLevel='All';
          selectedParamGroup='__ALL__';
        }
      }

      function paramFilterLevel(level){
        selectedParamLevel=level;
        selectedParamGroup='__ALL__';
        paramSaveState();

        document.querySelectorAll('.paramLevelBtn').forEach(btn=>{
          btn.classList.toggle('active', btn.dataset.level===level);
        });

        document.querySelectorAll('.paramGroupBtn').forEach(btn=>{
          const g=btn.dataset.group || '';
          const levels=btn.dataset.levels || '';
          let visible = (g==='__ALL__' || level==='All' || levels.split(' ').includes(level));
          btn.classList.toggle('paramHidden', !visible);
          btn.classList.toggle('active', g==='__ALL__');
        });
        paramApplyFilter();
        // paramSyncVisibleAfterFilterChange(); // disabled: live /state polling handles normal updates
      }

      function paramFilterGroup(group){
        selectedParamGroup=group;

        const search=document.getElementById('paramSearch');
        if(search){ search.value=''; }

        paramSaveState();

        document.querySelectorAll('.paramGroupBtn').forEach(btn=>{
          btn.classList.toggle('active', btn.dataset.group===group);
        });
        paramApplyFilter();
        // paramSyncVisibleAfterFilterChange(); // disabled: live /state polling handles normal updates
      }

      const PARAM_SEARCH_HISTORY_KEY='siyi_param_search_history_v2_clean';

      function paramHistoryEmpty(){
        return {frozen:[], recent:[]};
      }

      function paramHistoryNormalize(data){
        let frozen=[];
        let recent=[];

        if(Array.isArray(data)){
          recent=data;
        }else if(data && typeof data === 'object'){
          frozen=Array.isArray(data.frozen) ? data.frozen : [];
          recent=Array.isArray(data.recent) ? data.recent : [];
        }

        frozen=frozen
          .map(function(v){return String(v || '').trim();})
          .filter(function(v){return v.length > 0;});

        recent=recent
          .map(function(v){return String(v || '').trim();})
          .filter(function(v){return v.length > 0;});

        const seen=new Set();

        frozen=frozen.filter(function(v){
          const k=v.toLowerCase();
          if(seen.has(k)){return false;}
          seen.add(k);
          return true;
        });

        recent=recent.filter(function(v){
          const k=v.toLowerCase();
          if(seen.has(k)){return false;}
          seen.add(k);
          return true;
        }).slice(0,10);

        return {frozen:frozen, recent:recent};
      }

      function paramHistoryLoad(){
        try{
          const raw=localStorage.getItem(PARAM_SEARCH_HISTORY_KEY) || '[]';
          return paramHistoryNormalize(JSON.parse(raw));
        }catch(e){
          return paramHistoryEmpty();
        }
      }

      function paramHistorySave(data){
        try{
          localStorage.setItem(
            PARAM_SEARCH_HISTORY_KEY,
            JSON.stringify(paramHistoryNormalize(data))
          );
        }catch(e){}
      }

      function paramHistoryRender(){
        const sel=document.getElementById('paramQuickSearch');
        if(!sel){return;}

        while(sel.options.length > 1){
          sel.remove(1);
        }

        const data=paramHistoryLoad();
        const arr=data.frozen.concat(data.recent);

        arr.forEach(function(v){
          const opt=document.createElement('option');
          opt.value=v;
          opt.textContent=(data.frozen.map(function(x){return x.toLowerCase();}).includes(v.toLowerCase()) ? '❄ ' : '') + v;
          sel.appendChild(opt);
        });
      }

      function paramHistoryRemember(){
        const input=document.getElementById('paramSearch');
        if(!input){return;}

        const value=String(input.value || '').trim();
        if(!value){return;}

        let data=paramHistoryLoad();
        const key=value.toLowerCase();

        if(data.frozen.map(function(v){return v.toLowerCase();}).includes(key)){
          paramHistoryRender();
          return;
        }

        data.recent=data.recent.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.recent.unshift(value);
        data=paramHistoryNormalize(data);

        paramHistorySave(data);
        paramHistoryRender();
      }

      function paramFreezeCurrentSearch(){
        const input=document.getElementById('paramSearch');
        const value=String(input?.value || '').trim();
        if(!value){return;}

        let data=paramHistoryLoad();
        const key=value.toLowerCase();

        data.frozen=data.frozen.filter(function(v){
          return v.toLowerCase() !== key;
        });
        data.recent=data.recent.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.frozen.unshift(value);
        data=paramHistoryNormalize(data);

        paramHistorySave(data);
        paramHistoryRender();
      }

      function paramUnfreezeCurrentSearch(){
        const input=document.getElementById('paramSearch');
        const value=String(input?.value || '').trim();
        if(!value){return;}

        let data=paramHistoryLoad();
        const key=value.toLowerCase();

        data.frozen=data.frozen.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.recent=data.recent.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.recent.unshift(value);
        data=paramHistoryNormalize(data);

        paramHistorySave(data);
        paramHistoryRender();
      }

      window.addEventListener('load', function(){
        paramHistoryRender();

        const input=document.getElementById('paramSearch');
        if(input){
          input.addEventListener('change', paramHistoryRemember);
          input.addEventListener('keydown', function(ev){
            if(ev.key === 'Enter'){
              paramHistoryRemember();
            }
          });
        }
      });

      function paramApplyQuickSearch(sel){
        const search=document.getElementById('paramSearch');
        const value=sel?.value || '';

        if(value && search){
          search.value=value;
          paramSaveState();
          paramApplyFilter();
          // paramSyncVisibleAfterFilterChange(); // disabled: live /state polling handles normal updates
        }

        if(sel){
          sel.value='';
        }
      }

      function paramClearSearch(){
        const search=document.getElementById('paramSearch');
        if(search){ search.value=''; }

        paramSaveState();
        paramApplyFilter(); // auto visible sync disabled; live state polling handles updates

        try{
          localStorage.removeItem('siyi_param_search');
        }catch(e){}
      }

      function paramWildcardMatch(text, pattern){
        text=(text || '').toLowerCase();
        pattern=(pattern || '').toLowerCase();

        let ti=0, pi=0, star=-1, match=0;

        while(ti < text.length){
          if(pi < pattern.length && (pattern[pi] === '?' || pattern[pi] === text[ti])){
            ti++;
            pi++;
          }else if(pi < pattern.length && pattern[pi] === '*'){
            star=pi;
            match=ti;
            pi++;
          }else if(star !== -1){
            pi=star+1;
            match++;
            ti=match;
          }else{
            return false;
          }
        }

        while(pi < pattern.length && pattern[pi] === '*'){
          pi++;
        }

        return pi === pattern.length;
      }

      function paramWildcardContains(text, pattern){
        text=(text || '').toLowerCase();
        pattern=(pattern || '').toLowerCase();

        for(let i=0; i<=text.length; i++){
          if(paramWildcardMatch(text.slice(i), pattern)){
            return true;
          }
        }
        return false;
      }

      function paramApplyFilter(){
        const q=(document.getElementById('paramSearch')?.value || '').toLowerCase().trim();
        const mode=(document.getElementById('paramSearchMode')?.value || 'startswith');
        const hasWildcard=(q.includes('*') || q.includes('?'));
        let visibleRows=0;

        document.querySelectorAll('.paramGroupCard').forEach(card=>{
          const group=card.dataset.group || '';
          const levels=card.dataset.levels || '';
          let groupVisibleRows=0;

          card.querySelectorAll('.paramRow').forEach(row=>{
            const rowGroup=row.dataset.group || '';
            const rowLevels=row.dataset.levels || '';
            const param=row.dataset.param || '';
            const blob=row.dataset.search || '';

            let okLevel=(selectedParamLevel==='All' || rowLevels.split(' ').includes(selectedParamLevel));
            let okGroup=(selectedParamGroup==='__ALL__' || rowGroup===selectedParamGroup);

            let okSearch=true;
            if(q){
              if(hasWildcard){
                if(mode === 'contains'){
                  okSearch = paramWildcardContains(blob, q);
                }else{
                  let pattern=q;

                  if(!pattern.endsWith('*')){
                    pattern += '*';
                  }

                  okSearch = paramWildcardMatch(
                    param.toLowerCase(),
                    pattern
                  );
                }
              }else if(mode === 'contains'){
                okSearch = blob.includes(q);
              }else{
                okSearch = param.toLowerCase().startsWith(q);
              }
            }

            const show=okLevel && okGroup && okSearch;
            row.classList.toggle('paramHidden', !show);

            if(show){
              groupVisibleRows++;
              visibleRows++;
            }
          });

          card.classList.toggle('paramHidden', groupVisibleRows===0);
        });

        const c=document.getElementById('paramResultCount');
        if(c){
          c.textContent = 'Showing ' + visibleRows + ' parameter(s)';
        }
      }

      async function paramPollRefreshState(){
        try{
          const r=await fetch('/param_sync_status?ts=' + Date.now());
          const j=await r.json();
          const el=document.getElementById('paramRefreshStatus');

          if(el){
            el.textContent = j.message || '';
            el.style.color = j.running ? '#facc15' : (j.ok ? '#22c55e' : '#ef4444');
          }

          if(j.running){
            setTimeout(paramPollRefreshState, 1000);
          }else if(j.ok && sessionStorage.getItem('siyi_param_refresh_pending') === '1'){

            // IMPORTANT:
            // Do NOT start additional PARAM_REQUEST_READ traffic immediately
            // after full PARAM_REQUEST_LIST refresh.
            //
            // Multiple concurrent pymavlink param readers can steal
            // PARAM_VALUE messages from each other and corrupt refresh stability.
            //
            // Simply reload once stable full cache completed.
            sessionStorage.removeItem('siyi_param_refresh_pending');
            // Disabled: caused reload loop after paramd sync completed.
            // Cached values are now updated through /param_state polling.
            paramPollVisibleState();
          }
        }catch(e){
          setTimeout(paramPollRefreshState, 2000);
        }
      }

      document.addEventListener('submit', (e)=>{
        if(e.target && e.target.getAttribute('action') === '/params_refresh'){
          sessionStorage.setItem('siyi_param_refresh_pending', '1');
        }
      });

      let paramLiveRefreshRunning=false;
      let paramLiveRefreshGeneration=0;
      let paramLiveRefreshAbortController=null;

      function paramApplyCachedStateUpdate(pname, item){
        try{
          if(!pname || !item || item.missing) return;

          const box=document.getElementById('paramValue_' + pname);
          if(!box) return;

          const row=box.closest('.paramRow');
          if(row && row.classList.contains('paramHidden')) return;

          const val=String(item.value).replace(/\\.0$/, '');
          const input=box.querySelector('.paramEditInput');

          // Do not overwrite a value while the user is actively editing it.
          if(input && document.activeElement === input){
            return;
          }

          if(input){
            input.value=val;
          }

          const b=box.querySelector('b');
          if(b){
            if(input && input.tagName === 'SELECT'){
              const opt=[...input.options].find(o => String(o.value) === val);
              if(opt){
                input.value=opt.value;
                b.textContent=opt.textContent.replace(/ \\([^)]*\\)$/, '');
              }else{
                b.textContent=val;
              }
            }else{
              b.textContent=val;
            }
          }

          box.dataset.liveTs=String(item.ts || Date.now()/1000);
        }catch(e){
          console.log('paramApplyCachedStateUpdate failed', e);
        }
      }

      let paramStatePollRunning=false;

      async function paramPollVisibleState(){
        if(paramStatePollRunning) return;
        paramStatePollRunning=true;

        try{
          let rows=[...document.querySelectorAll('.paramRow')]
            .filter(r => !r.classList.contains('paramHidden'))
            .slice(0,120);

          const names=rows
            .map(r => r.dataset.paramname || r.dataset.param || '')
            .filter(Boolean);

          if(!names.length) return;

          const r=await fetch('/param_state?names=' + encodeURIComponent(names.join(',')) + '&ts=' + Date.now(), {cache:'no-store'});
          const j=await r.json();

          if(j && j.ok && j.params){
            Object.entries(j.params).forEach(([name,item]) => {
              paramApplyCachedStateUpdate(name,item);
            });
          }
        }catch(e){
          console.log('paramPollVisibleState failed', e);
        }finally{
          paramStatePollRunning=false;
        }
      }

      async function paramManualFullSync(event){
        if(event) event.preventDefault();

        const el=document.getElementById('paramRefreshStatus');
        if(el){
          el.textContent='Synchronizing parameters from FC...';
          el.style.color='#facc15';
        }

        try{
          const r=await fetch('/param_trigger_full_sync?ts=' + Date.now(), {cache:'no-store'});
          const j=await r.json();
          if(!j || !j.ok){
            if(el){
              el.textContent='Parameter sync failed';
              el.style.color='#ef4444';
            }
            alert('Parameter sync failed: ' + ((j && j.error) ? j.error : 'unknown error'));
            return false;
          }
          paramPollSyncStatus();
        }catch(e){
          if(el){
            el.textContent='Parameter sync failed';
            el.style.color='#ef4444';
          }
          alert('Parameter sync failed: ' + e.message);
        }

        return false;
      }

      async function paramPollSyncStatus(){
        try{
          const el=document.getElementById('paramRefreshStatus');
          if(!el) return;
          const r=await fetch('/param_sync_status?ts=' + Date.now(), {cache:'no-store'});
          const j=await r.json();
          if(!j || !j.ok) return;

          if(j.running){
            el.textContent=j.message || 'Synchronizing parameters from FC...';
            el.style.color='#facc15';
          }else if(j.last_ok){
            el.textContent='Parameters synchronized from FC';
            el.style.color='#22c55e';
          }
        }catch(e){
          console.log('paramPollSyncStatus failed', e);
        }
      }

      function paramStartSyncStatusPolling(){
        if(window.siyiParamSyncStatusTimer) return;
        window.siyiParamSyncStatusTimer=setInterval(paramPollSyncStatus, 1000);
        setTimeout(paramPollSyncStatus, 250);
      }

      function paramStartStatePolling(){
        if(window.siyiParamStatePollTimer) return;
        window.siyiParamStatePollTimer=setInterval(paramPollVisibleState, 500);
        setTimeout(paramPollVisibleState, 200);
      }

      async function paramLiveReadVisibleSerial(syncGeneration){

        const myGeneration = syncGeneration || paramLiveRefreshGeneration;

        if(paramLiveRefreshRunning){
          return;
        }

        paramLiveRefreshRunning=true;

        const el=document.getElementById('paramRefreshStatus');
        let rows=[...document.querySelectorAll('.paramRow')];

        // Older/restored backups may not consistently preserve .paramRow.
        // Fall back to any element carrying parameter metadata.
        if(!rows.length){
          rows=[...document.querySelectorAll('[data-paramname]')];
        }

        rows = rows
          .filter(r => !r.classList.contains('paramHidden'))
          .slice(0,80);

        if(el){
          el.textContent='Synchronizing parameters from FC...';  // only for explicit/manual sync paths
          el.style.color='#facc15';
        }

        let n=0;
        let failed=[];
        for(const row of rows){

          if(myGeneration !== paramLiveRefreshGeneration){
            break;
          }

          try{
            const pname=row.dataset.paramname;
            if(!pname) continue;

            const controller = new AbortController();
            paramLiveRefreshAbortController = controller;

            const timeout = setTimeout(()=>{
              controller.abort();
            }, 5000);

            let j=null;

            try{
              const r=await fetch(
                '/param_live_read?name=' + encodeURIComponent(pname) + '&ts=' + Date.now(),
                {signal: controller.signal}
              );

              j=await r.json();
            }finally{
              clearTimeout(timeout);
            }

            if(!j){
              failed.push(pname + ': no response');
              continue;
            }

            if(j.ok){
              const box=document.getElementById('paramValue_' + pname);
              if(box){
                const input=box.querySelector('.paramEditInput');
                if(input){ input.value = String(j.value).replace(/\\.0$/, ''); }

                const b=box.querySelector('b');
                if(b){
                  if(input && input.tagName === 'SELECT'){
                    const opt=input.options[input.selectedIndex];
                    b.textContent = opt ? opt.textContent.replace(/ \\([^)]*\\)$/, '') : j.value;
                  }else{
                    b.textContent = j.value;
                  }
                }
              }
              n++;
            }else{
              failed.push(pname + ': ' + (j.error || 'not ok'));
            }
          }catch(e){
            if(myGeneration !== paramLiveRefreshGeneration){
              break;
            }
            failed.push((row && row.dataset ? row.dataset.paramname : '?') + ': ' + e);
          }
        }

        if(el && myGeneration === paramLiveRefreshGeneration){
          el.textContent='Parameters synchronized from FC';
          el.style.color='#22c55e';
        }

        paramLiveRefreshAbortController=null;
        paramLiveRefreshRunning=false;
      }

      document.addEventListener('DOMContentLoaded', ()=>{
        paramRestoreState();

        document.querySelectorAll('.paramLevelBtn').forEach(btn=>{
          btn.classList.toggle('active', btn.dataset.level===selectedParamLevel);
        });

        document.querySelectorAll('.paramGroupBtn').forEach(btn=>{
          const g=btn.dataset.group || '';
          const levels=btn.dataset.levels || '';
          let visible = (g==='__ALL__' || selectedParamLevel==='All' || levels.split(' ').includes(selectedParamLevel));
          btn.classList.toggle('paramHidden', !visible);
          btn.classList.toggle('active', g===selectedParamGroup);
        });

        paramApplyFilter();
        paramStartStatePolling();
        paramStartSyncStatusPolling();
        paramPollRefreshState();

        // Auto live param reads enabled: siyi-paramd serializes MAVLink parameter access safely
        
// setTimeout(paramLiveReadVisibleSerial, 700); // disabled
// setTimeout(paramLiveReadVisibleSerial, 1800); // disabled
// setTimeout(paramLiveReadVisibleSerial, 3200); // disabled

      });

      // window load auto live sync disabled; paramd startup sync + state polling handles normal updates

      // pageshow auto live sync disabled; paramd startup sync + state polling handles normal updates

      // FORCE live FC reads whenever /parameters is opened/refreshed.
      // This avoids relying on stale rendered/cache values.
      let paramFilterSyncTimer=null;

      function fcParameterExportClick(event){
      if(event) event.preventDefault();

      const st=document.getElementById('paramRefreshStatus');
      const n=document.getElementById('fcExportChromeNote');
      const b=document.getElementById('fcParamExportBtn');

      if(st) st.innerText='Synchronizing parameters from FC… export will download when ready';
      if(n) n.style.display='inline';
      if(b) {
        b.innerText='Export running…';
        b.style.opacity='0.75';
        b.style.pointerEvents='none';
      }

      fetch('/fc_parameter_export?ts='+Date.now())
        .then(function(r){
          if(!r.ok){
            return r.text().then(function(t){
              throw new Error(t || ('HTTP '+r.status));
            });
          }
          const cd=r.headers.get('Content-Disposition') || '';
          const m=cd.match(/filename="?([^";]+)"?/);
          const fn=m ? m[1] : 'fc_parameters.params';
          return r.blob().then(function(blob){
            const u=URL.createObjectURL(blob);
            const a=document.createElement('a');
            a.href=u;
            a.download=fn;
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(function(){ URL.revokeObjectURL(u); }, 1000);
          });
        })
        .catch(function(e){
          alert('FC Parameter Export failed: ' + e.message);
        })
        .finally(function(){
          if(st) st.innerText='';
          if(n) n.style.display='none';
          if(b) {
            b.innerText='FC Parameter Export';
            b.style.opacity='1';
            b.style.pointerEvents='auto';
          }
        });

      return false;
    }

    function paramSyncVisibleAfterFilterChange(){
        try{
          // Any page/filter/search/group change invalidates the currently running sync.
          paramLiveRefreshGeneration++;

          if(paramFilterSyncTimer){
            clearTimeout(paramFilterSyncTimer);
            paramFilterSyncTimer=null;
          }

          if(paramLiveRefreshAbortController){
            try{ paramLiveRefreshAbortController.abort(); }catch(e){}
            paramLiveRefreshAbortController=null;
          }

          const thisGeneration = paramLiveRefreshGeneration;

          const el=document.getElementById('paramRefreshStatus');
          if(el){
            el.textContent='Waiting to synchronize parameters from FC...';
            el.style.color='#facc15';
          }

          paramFilterSyncTimer=setTimeout(function(){
            if(typeof paramLiveReadVisibleSerial === 'function'){
              // paramLiveReadVisibleSerial(thisGeneration); // disabled: /state polling handles normal updates
            }
          }, 2500);

        }catch(e){
          console.log('paramSyncVisibleAfterFilterChange failed', e);
        }
      }


      function paramForceRefreshFromFC(){
        try{
          sessionStorage.setItem('siyi_param_refresh_pending', '1');

          if(typeof paramApplyFilter === 'function'){
            paramApplyFilter();
          }

          if(typeof paramLiveReadVisibleSerial === 'function'){
            // setTimeout(paramLiveReadVisibleSerial, 200); // disabled
            // setTimeout(paramLiveReadVisibleSerial, 1200); // disabled
            // setTimeout(paramLiveReadVisibleSerial, 2500); // disabled
          }
        }catch(e){
          console.log('paramForceRefreshFromFC failed', e);
        }
      }

      window.addEventListener('load', paramForceRefreshFromFC);

      window.addEventListener('pageshow', paramForceRefreshFromFC);

      // === ARDUPLANE PARAMETER IMPORT V1 ===
      let paramImportSessionId='';
      let paramImportPreview=null;
      let paramImportStatusTimer=null;
      const paramImportMetadataCache=new Map();
      let paramImportMetaHoverTimer=null;
      let paramImportMetaRequestSerial=0;
      let paramImportMetaLastPointer={x:0,y:0};

      function paramImportMetaHide(){
        clearTimeout(paramImportMetaHoverTimer);
        const popup=document.getElementById('paramImportMetaPopup');
        if(popup){ popup.classList.remove('open'); popup.setAttribute('aria-hidden','true'); }
      }

      function paramImportMetaPosition(clientX,clientY){
        const popup=document.getElementById('paramImportMetaPopup');
        if(!popup) return;
        paramImportMetaLastPointer={x:clientX,y:clientY};
        const gap=18;
        const margin=12;
        const rect=popup.getBoundingClientRect();
        let left=clientX+gap;
        let top=clientY+gap;
        if(left+rect.width+margin>window.innerWidth) left=clientX-rect.width-gap;
        if(top+rect.height+margin>window.innerHeight) top=window.innerHeight-rect.height-margin;
        left=Math.max(margin,left);
        top=Math.max(margin,top);
        popup.style.left=Math.round(left)+'px';
        popup.style.top=Math.round(top)+'px';
      }

      function paramImportMetaText(parent,className,text){
        const node=document.createElement('div');
        if(className) node.className=className;
        node.textContent=text;
        parent.appendChild(node);
        return node;
      }

      function paramImportMetaGridRow(grid,key,value){
        if(value===null || value===undefined || String(value).trim()==='') return;
        paramImportMetaText(grid,'paramImportMetaKey',String(key));
        paramImportMetaText(grid,'paramImportMetaValue',String(value));
      }

      function paramImportRenderMetadata(data,item){
        const name=document.getElementById('paramImportMetaName');
        const human=document.getElementById('paramImportMetaHuman');
        const body=document.getElementById('paramImportMetaBody');
        name.textContent=item.name;
        human.textContent=(data && data.available && data.humanName) ? data.humanName : '';
        body.replaceChildren();

        const grid=document.createElement('div');
        grid.className='paramImportMetaGrid';
        paramImportMetaGridRow(grid,'Current value',item.current===null || item.current===undefined ? 'Not present on FC':item.current);
        paramImportMetaGridRow(grid,'Imported value',item.imported);
        paramImportMetaGridRow(grid,'Import status',item.status);
        if(item.type!==null && item.type!==undefined) paramImportMetaGridRow(grid,'MAVLink type',item.type);

        if(!data || !data.available){
          body.appendChild(grid);
          paramImportMetaText(body,'paramImportMetaMuted',(data && data.message) || 'No ArduPilot metadata is available for this parameter.');
          return;
        }

        if(data.documentation) paramImportMetaText(body,'paramImportMetaDescription',data.documentation);
        paramImportMetaGridRow(grid,'User level',data.user);
        Object.entries(data.fields || {}).forEach(([key,value])=>paramImportMetaGridRow(grid,key,value));
        body.appendChild(grid);

        const entries=Object.entries(data.values || {});
        if(entries.length){
          const enumBox=document.createElement('div');
          enumBox.className='paramImportMetaEnums';
          paramImportMetaText(enumBox,'paramImportMetaEnumsTitle','Allowed / enumerated values');
          entries.slice(0,60).forEach(([code,label])=>{
            const line=document.createElement('div'); line.className='paramImportMetaEnumLine';
            paramImportMetaText(line,'paramImportMetaEnumCode',code);
            paramImportMetaText(line,'',label);
            enumBox.appendChild(line);
          });
          if(entries.length>60) paramImportMetaText(enumBox,'paramImportMetaMuted','+'+(entries.length-60)+' additional values');
          body.appendChild(enumBox);
        }
      }

      async function paramImportMetaShowNow(item,event){
        const popup=document.getElementById('paramImportMetaPopup');
        if(!popup) return;
        popup.classList.add('open');
        popup.setAttribute('aria-hidden','false');
        document.getElementById('paramImportMetaName').textContent=item.name;
        document.getElementById('paramImportMetaHuman').textContent='';
        const body=document.getElementById('paramImportMetaBody');
        body.replaceChildren();
        paramImportMetaText(body,'paramImportMetaMuted','Loading parameter metadata...');
        paramImportMetaPosition(event.clientX,event.clientY);

        const serial=++paramImportMetaRequestSerial;
        try{
          let data=item.metadata || paramImportMetadataCache.get(item.name);
          if(data){
            paramImportMetadataCache.set(item.name,data);
          }else{
            const response=await fetch('/param_metadata?name='+encodeURIComponent(item.name),{cache:'no-store'});
            data=await response.json();
            if(!response.ok || !data.ok) throw new Error(data.error || ('HTTP '+response.status));
            paramImportMetadataCache.set(item.name,data);
          }
          if(serial!==paramImportMetaRequestSerial || !popup.classList.contains('open')) return;
          paramImportRenderMetadata(data,item);
          paramImportMetaPosition(paramImportMetaLastPointer.x,paramImportMetaLastPointer.y);
        }catch(error){
          if(serial!==paramImportMetaRequestSerial) return;
          paramImportRenderMetadata({available:false,message:'Metadata lookup failed: '+error.message},item);
          paramImportMetaPosition(paramImportMetaLastPointer.x,paramImportMetaLastPointer.y);
        }
      }

      function paramImportMetaSchedule(item,event){
        clearTimeout(paramImportMetaHoverTimer);
        paramImportMetaLastPointer={x:event.clientX,y:event.clientY};
        paramImportMetaHoverTimer=setTimeout(()=>paramImportMetaShowNow(item,event),220);
      }

      function paramImportMetaMove(event){
        paramImportMetaLastPointer={x:event.clientX,y:event.clientY};
        const popup=document.getElementById('paramImportMetaPopup');
        if(popup && popup.classList.contains('open')) paramImportMetaPosition(event.clientX,event.clientY);
      }

      function paramImportOpen(){
        const overlay=document.getElementById('paramImportOverlay');
        if(overlay){ overlay.classList.add('open'); overlay.setAttribute('aria-hidden','false'); }
      }

      function paramImportClose(){
        paramImportMetaHide();
        const state=document.getElementById('paramImportOverlay');
        const cancel=document.getElementById('paramImportCancelBtn');
        if(cancel && cancel.style.display!=='none'){
          alert('The parameter operation is still running. Cancel it or wait for completion.');
          return;
        }
        if(state){ state.classList.remove('open'); state.setAttribute('aria-hidden','true'); }
      }

      function paramImportSetError(message){
        const box=document.getElementById('paramImportError');
        if(!box) return;
        box.textContent=message || '';
        box.style.display=message ? 'block' : 'none';
      }

      function paramImportShowLoading(message){
        paramImportMetaHide();
        paramImportOpen();
        paramImportSetError('');
        document.getElementById('paramImportLoadingText').textContent=message || 'Working...';
        document.getElementById('paramImportLoading').style.display='flex';
        document.getElementById('paramImportPreviewPanel').style.display='none';
        document.getElementById('paramImportProgressPanel').style.display='none';
        document.getElementById('paramImportApplyBtn').style.display='none';
        document.getElementById('paramImportCancelBtn').style.display='none';
        document.getElementById('paramImportRollbackBtn').style.display='none';
        document.getElementById('paramImportBackupBtn').style.display='none';
        document.getElementById('paramImportReportBtn').style.display='none';
      }

      async function paramImportFileSelected(input){
        const file=input.files && input.files[0];
        input.value='';
        if(!file) return;
        if(file.size > 2*1024*1024){ alert('Parameter file is larger than 2 MB.'); return; }
        paramImportShowLoading('Reading file and comparing it with the connected flight controller...');
        try{
          const content=await file.text();
          const response=await fetch('/param_import_preview',{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({filename:file.name,content:content}),
            cache:'no-store'
          });
          const result=await response.json();
          if(!response.ok || !result.ok) throw new Error(result.error || ('HTTP '+response.status));
          paramImportPreview=result;
          paramImportSessionId=result.session_id;
          paramImportRenderPreview(result);
        }catch(error){
          document.getElementById('paramImportLoading').style.display='none';
          paramImportSetError('Parameter-file preview failed: '+error.message);
        }
      }

      function paramImportSummaryItem(label,value){
        const box=document.createElement('div');
        box.className='paramImportSummaryItem';
        const strong=document.createElement('strong'); strong.textContent=String(value);
        const text=document.createElement('span'); text.className='small'; text.textContent=label;
        box.append(strong,text); return box;
      }

      function paramImportRenderPreview(result){
        document.getElementById('paramImportLoading').style.display='none';
        const panel=document.getElementById('paramImportPreviewPanel');
        panel.style.display='flex';
        document.getElementById('paramImportSubtitle').textContent=result.filename;
        const summary=document.getElementById('paramImportSummary');
        summary.replaceChildren(
          paramImportSummaryItem('Changed',result.summary.changed),
          paramImportSummaryItem('Already match',result.summary.same),
          paramImportSummaryItem('Unsupported',result.summary.unsupported),
          paramImportSummaryItem('Duplicate',result.summary.duplicates),
          paramImportSummaryItem('Invalid lines',result.summary.invalid_lines),
          paramImportSummaryItem('Critical changes',result.summary.critical_changes)
        );
        const safety=document.getElementById('paramImportSafety');
        const messages=[];
        if(result.summary.flap_conflicts){
          messages.push(result.summary.flap_conflicts+' imported SERVOx_FUNCTION change(s) conflict with the servo outputs currently configured for Pi flap control. They are unselected by default.');
        }
        if(result.summary.critical_changes){
          messages.push('Critical flight-control or hardware parameters are present. Type IMPORT when applying them.');
        }
        safety.textContent=messages.join(' ');
        safety.style.display=messages.length ? 'block' : 'none';
        const body=document.getElementById('paramImportRows');
        body.replaceChildren();
        (result.entries || []).forEach(item=>{
          const row=document.createElement('tr');
          row.dataset.status=item.status;
          row.dataset.warning=(item.warning || item.critical || item.flap_conflict) ? '1':'0';
          row.dataset.name=item.name;
          row.dataset.critical=item.critical ? '1':'0';
          const apply=document.createElement('td');
          const check=document.createElement('input');
          check.type='checkbox'; check.className='paramImportCheck'; check.value=item.name;
          check.checked=!!item.selected; check.disabled=item.status!=='changed';
          check.addEventListener('change',paramImportUpdateSelectedCount);
          apply.appendChild(check);
          const name=document.createElement('td');
          name.textContent=item.name;
          name.className='paramImportMetaParamName';
          name.title='Hover to show ArduPilot parameter metadata';
          row.classList.add('paramImportMetaRow');
          row.tabIndex=0;
          row.addEventListener('mouseenter',event=>paramImportMetaSchedule(item,event));
          row.addEventListener('mousemove',paramImportMetaMove);
          row.addEventListener('mouseleave',paramImportMetaHide);
          row.addEventListener('focus',()=>{
            const rect=row.getBoundingClientRect();
            paramImportMetaSchedule(item,{clientX:Math.min(rect.right,window.innerWidth-20),clientY:Math.min(rect.top+24,window.innerHeight-20)});
          });
          row.addEventListener('blur',paramImportMetaHide);
          const current=document.createElement('td'); current.textContent=item.current===null || item.current===undefined ? '—':String(item.current);
          const imported=document.createElement('td'); imported.textContent=String(item.imported);
          const status=document.createElement('td');
          const pill=document.createElement('span'); pill.className='paramImportStatus '+item.status; pill.textContent=item.status; status.appendChild(pill);
          const warning=document.createElement('td'); warning.className='paramImportWarning'; warning.textContent=item.warning || '';
          row.append(apply,name,current,imported,status,warning);
          body.appendChild(row);
        });
        document.getElementById('paramImportFilter').value='changed';
        document.getElementById('paramImportSelectAll').checked=true;
        document.getElementById('paramImportApplyBtn').style.display='inline-block';
        document.getElementById('paramImportCloseBtn').style.display='inline-block';
        paramImportApplyFilter();
        paramImportUpdateSelectedCount();
      }

      function paramImportApplyFilter(){
        const filter=document.getElementById('paramImportFilter').value;
        document.querySelectorAll('#paramImportRows tr').forEach(row=>{
          let show=true;
          if(filter==='changed') show=row.dataset.status==='changed';
          if(filter==='warnings') show=row.dataset.warning==='1';
          row.style.display=show ? 'table-row':'none';
        });
      }

      function paramImportToggleAll(checked){
        document.querySelectorAll('.paramImportCheck:not(:disabled)').forEach(box=>{ box.checked=checked; });
        paramImportUpdateSelectedCount();
      }

      function paramImportUpdateSelectedCount(){
        const selected=[...document.querySelectorAll('.paramImportCheck:checked:not(:disabled)')];
        document.getElementById('paramImportSelectedCount').textContent=selected.length+' selected';
        document.getElementById('paramImportApplyBtn').textContent='Apply '+selected.length+' parameter'+(selected.length===1?'':'s');
      }

      async function paramImportApply(){
        const selected=[...document.querySelectorAll('.paramImportCheck:checked:not(:disabled)')];
        if(!selected.length){ alert('Select at least one changed parameter.'); return; }
        const critical=selected.some(box=>box.closest('tr').dataset.critical==='1');
        let confirmation='';
        if(critical){
          confirmation=window.prompt('Critical flight-control or hardware parameters are selected. Type IMPORT to continue:') || '';
          if(confirmation!=='IMPORT') return;
        }
        if(!confirm('Apply '+selected.length+' selected parameter changes to the connected flight controller?')) return;
        paramImportShowProgress('Starting parameter import...');
        try{
          const response=await fetch('/param_import_apply',{
            method:'POST',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({session_id:paramImportSessionId,parameters:selected.map(box=>box.value),confirmation:confirmation}),
            cache:'no-store'
          });
          const result=await response.json();
          if(!response.ok || !result.ok) throw new Error(result.error || ('HTTP '+response.status));
          paramImportStartPolling();
        }catch(error){
          paramImportSetError('Unable to start import: '+error.message);
          document.getElementById('paramImportCancelBtn').style.display='none';
        }
      }

      function paramImportShowProgress(message){
        paramImportOpen(); paramImportSetError('');
        document.getElementById('paramImportLoading').style.display='none';
        document.getElementById('paramImportPreviewPanel').style.display='none';
        document.getElementById('paramImportProgressPanel').style.display='block';
        document.getElementById('paramImportRunMessage').textContent=message || '';
        document.getElementById('paramImportApplyBtn').style.display='none';
        document.getElementById('paramImportCancelBtn').style.display='inline-block';
        document.getElementById('paramImportCloseTop').style.display='none';
        document.getElementById('paramImportCloseBtn').style.display='none';
      }

      function paramImportStartPolling(){
        if(paramImportStatusTimer) clearInterval(paramImportStatusTimer);
        paramImportStatusTimer=setInterval(paramImportPollStatus,700);
        paramImportPollStatus();
      }

      async function paramImportPollStatus(){
        try{
          const response=await fetch('/param_import_status?ts='+Date.now(),{cache:'no-store'});
          const state=await response.json();
          if(!state.ok) return;
          if(state.session_id) paramImportSessionId=state.session_id;
          if(state.running || ['applying','rolling_back','complete','failed','cancelled','rolled_back'].includes(state.status)){
            paramImportShowProgress(state.message || state.status);
            const pct=Math.max(0,Math.min(100,Number(state.progress)||0));
            document.getElementById('paramImportProgressBar').style.width=pct+'%';
            document.getElementById('paramImportProgressPercent').textContent=pct.toFixed(1)+'%';
            document.getElementById('paramImportProgressText').textContent=(state.verified||0)+' of '+(state.total||0)+' verified';
            document.getElementById('paramImportCurrentParam').textContent=state.current_parameter ? 'Current parameter: '+state.current_parameter : '';
            document.getElementById('paramImportRunMessage').textContent=state.message || '';
            document.getElementById('paramImportRunTitle').textContent=state.operation==='rollback' ? 'Restoring parameters':'Applying parameters';
            const log=document.getElementById('paramImportEventLog');
            log.replaceChildren();
            (state.events || []).forEach(event=>{
              const line=document.createElement('div'); line.className='paramImportEventLine '+(event.level||'info'); line.textContent=(event.level==='ok'?'✓ ':event.level==='error'?'✕ ':event.level==='warning'?'⚠ ':'→ ')+(event.text||''); log.appendChild(line);
            });
            log.scrollTop=log.scrollHeight;
            const running=!!state.running;
            document.getElementById('paramImportCancelBtn').style.display=running ? 'inline-block':'none';
            document.getElementById('paramImportCloseTop').style.display=running ? 'none':'inline-block';
            document.getElementById('paramImportCloseBtn').style.display=running ? 'none':'inline-block';
            document.getElementById('paramImportRunSpinner').style.display=running ? 'inline-block':'none';
            if(!running){
              if(paramImportStatusTimer){ clearInterval(paramImportStatusTimer); paramImportStatusTimer=null; }
              const sid=encodeURIComponent(paramImportSessionId);
              if(state.backup_file){ const b=document.getElementById('paramImportBackupBtn'); b.href='/param_import_backup?session_id='+sid; b.style.display='inline-block'; }
              const r=document.getElementById('paramImportReportBtn'); r.href='/param_import_report?session_id='+sid; r.style.display='inline-block';
              document.getElementById('paramImportRollbackBtn').style.display=state.can_rollback ? 'inline-block':'none';
              if(state.status==='complete' || state.status==='rolled_back'){
                document.getElementById('paramImportRunTitle').textContent=state.status==='rolled_back' ? 'Rollback complete':'Parameter import complete';
              }else if(state.error){ paramImportSetError(state.error); }
            }
          }
        }catch(error){ console.log('paramImportPollStatus failed',error); }
      }

      async function paramImportCancelJob(){
        if(!confirm('Cancel after the current parameter write finishes?')) return;
        await fetch('/param_import_cancel',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
      }

      async function paramImportRollback(){
        const confirmation=window.prompt('Restore all verified changes from the pre-import backup? Type RESTORE to continue:') || '';
        if(confirmation!=='RESTORE') return;
        paramImportShowProgress('Starting rollback...');
        try{
          const response=await fetch('/param_import_rollback',{
            method:'POST',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({session_id:paramImportSessionId,confirmation:confirmation})
          });
          const result=await response.json();
          if(!response.ok || !result.ok) throw new Error(result.error || ('HTTP '+response.status));
          paramImportStartPolling();
        }catch(error){ paramImportSetError('Unable to start rollback: '+error.message); }
      }

      document.addEventListener('DOMContentLoaded',()=>{
        fetch('/param_import_status?ts='+Date.now(),{cache:'no-store'})
          .then(response=>response.json())
          .then(state=>{ if(state && state.ok && state.running){ paramImportSessionId=state.session_id||''; paramImportStartPolling(); } })
          .catch(()=>{});
      });
      // === ARDUPLANE PARAMETER IMPORT V1 END ===

    </script>
    """

    return page("ArduPlane Parameters", body)

def page(title, body):
    initial_upgrade_state = json.dumps(software_update_status_payload(), ensure_ascii=False)
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>{title}</title>
<style>
body{{margin:0;background:#0f172a;color:#e5e7eb;font-family:Arial}}
header{{background:#020617;padding:10px 20px;font-size:22px;font-weight:bold;border-bottom:1px solid #334155;position:fixed;top:0;left:0;right:0;z-index:2;height:36px}}
nav{{width:180px;background:#020617;height:calc(100vh - 58px);position:fixed;left:0;top:58px;padding:15px;border-right:1px solid #334155;overflow-y:auto}}
nav a{{display:block;color:#cbd5e1;text-decoration:none;padding:11px;border-radius:8px;margin-bottom:4px}}
nav a:hover{{background:#1f2937;color:white}}
main{{margin-left:210px;padding:82px 24px 24px 24px}}
.card{{background:#111827;border:1px solid #334155;border-radius:12px;padding:16px;margin-bottom:16px}}
.grid{{display:grid;grid-template-columns:repeat(2,minmax(220px,1fr));gap:12px}}
table{{border-collapse:collapse;width:100%;font-size:14px}}
td,th{{border-bottom:1px solid #334155;padding:8px;text-align:left;vertical-align:top}}
input,select,textarea{{background:#020617;color:#e5e7eb;border:1px solid #334155;border-radius:6px;padding:7px;width:100%}}
button{{background:#2563eb;color:white;border:0;border-radius:8px;padding:9px 13px;margin:4px;cursor:pointer}}
button.danger{{background:#991b1b}}
pre{{background:#020617;border:1px solid #334155;border-radius:8px;padding:12px;overflow:auto;white-space:pre-wrap}}
.ok{{color:#22c55e}} .bad{{color:#ef4444}} .small{{font-size:13px;color:#94a3b8}}
.pill{{padding:3px 8px;border-radius:999px;font-size:12px;margin-left:8px}}
.pill.active{{background:#14532d;color:#86efac}}
.pill.inactive{{background:#334155;color:#cbd5e1}}
.ssidcard{{border:1px solid #334155;border-radius:10px;padding:14px;margin-bottom:12px;background:#0b1220}}
.ssidtop{{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}}
.ssidtitle{{font-size:18px;font-weight:bold;margin-bottom:6px}}
.ssidmeta{{color:#94a3b8;font-size:13px;line-height:1.5}}
.ssidfacts{{display:flex;gap:18px;margin-top:10px}}
.ssidcontrols{{margin-top:12px;border-top:1px solid #334155;padding-top:10px}}
.inlineform{{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:6px 0}}
.smallinput{{width:80px}}
.smallselect{{width:120px}}
.switchbtn{{background:#16a34a}}
.readonlybox{{color:#94a3b8}}

.statusdotimg{{width:14px;height:14px;margin-left:12px;vertical-align:middle}}
.statuslabel{{font-size:13px;color:#94a3b8;margin-left:6px;font-weight:normal}}

.statusdot{{display:inline-block;width:13px;height:13px;border-radius:50%;background:#ef4444;margin-left:12px;vertical-align:middle;box-shadow:0 0 8px #ef4444}}
.statusdot.ok{{background:#22c55e;box-shadow:0 0 8px #22c55e}}
.statuslabel{{font-size:13px;color:#94a3b8;margin-left:6px;font-weight:normal}}


#top-status-bar{{display:inline-flex;gap:6px;align-items:center;white-space:nowrap}}
.status-pill{{font-size:13px;font-weight:bold;padding:5px 10px;border-radius:999px;color:white;margin-left:6px}}
.status-pill.ok{{background:#166534;color:white}}
.status-pill.bad{{background:#991b1b;color:white}}
.status-pill.warn{{background:#92400e;color:white}}


/* SOFTWARE_UPDATE_MODAL_V1 */
body.siyi-upgrade-locked{{overflow:hidden}}
#siyiUpgradeOverlay{{
  display:none;position:fixed;inset:0;z-index:1000000;
  background:rgba(2,6,23,.88);backdrop-filter:blur(5px);
  align-items:center;justify-content:center;padding:24px;box-sizing:border-box;
}}
#siyiUpgradeOverlay.visible{{display:flex}}
#siyiUpgradeDialog{{
  width:min(920px,94vw);height:min(720px,90vh);box-sizing:border-box;
  background:#0b1220;border:1px solid #475569;border-radius:16px;
  box-shadow:0 24px 80px rgba(0,0,0,.65);padding:22px;
  display:flex;flex-direction:column;gap:14px;
}}
.siyi-upgrade-title-row{{display:flex;align-items:center;justify-content:space-between;gap:16px}}
.siyi-upgrade-title{{font-size:25px;font-weight:800}}
.siyi-upgrade-version{{font-size:14px;color:#94a3b8}}
.siyi-upgrade-running-row{{display:flex;align-items:center;gap:12px;font-size:18px;font-weight:700}}
.siyi-upgrade-spinner{{
  width:28px;height:28px;border:4px solid #334155;border-top-color:#60a5fa;
  border-radius:50%;animation:siyiUpgradeSpin .8s linear infinite;flex:0 0 auto;
}}
@keyframes siyiUpgradeSpin{{to{{transform:rotate(360deg)}}}}
.siyi-upgrade-result-icon{{display:none;font-size:30px;font-weight:900;line-height:1}}
.siyi-upgrade-result-icon.ok{{color:#22c55e}}
.siyi-upgrade-result-icon.bad{{color:#ef4444}}
.siyi-upgrade-progress-shell{{height:18px;border-radius:999px;background:#1e293b;overflow:hidden;border:1px solid #334155}}
.siyi-upgrade-progress-bar{{
  height:100%;width:0%;background:#2563eb;transition:width .45s ease;
  position:relative;overflow:hidden;
}}
.siyi-upgrade-progress-bar.running::after{{
  content:'';position:absolute;inset:0;
  background:linear-gradient(110deg,transparent 0%,rgba(255,255,255,.25) 45%,transparent 70%);
  transform:translateX(-100%);animation:siyiUpgradeSweep 1.2s linear infinite;
}}
@keyframes siyiUpgradeSweep{{to{{transform:translateX(100%)}}}}
.siyi-upgrade-stage{{font-size:16px;font-weight:700;color:#e2e8f0}}
.siyi-upgrade-meta{{display:flex;justify-content:space-between;gap:12px;color:#94a3b8;font-size:13px}}
#siyiUpgradeLog{{
  flex:1;min-height:250px;margin:0;background:#020617;border:1px solid #334155;
  border-radius:10px;padding:14px;overflow:auto;white-space:pre-wrap;
  font:14px/1.55 ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;
}}
.siyi-upgrade-warning{{color:#fbbf24;font-size:14px;font-weight:700}}
.siyi-upgrade-actions{{display:none;gap:10px;justify-content:flex-end;align-items:center}}
.siyi-upgrade-actions.visible{{display:flex}}
.siyi-upgrade-detail{{display:none;border-top:1px solid #334155;padding-top:10px;color:#94a3b8;font-size:13px}}
.siyi-upgrade-detail.visible{{display:block}}
@media(max-width:700px){{
  #siyiUpgradeOverlay{{padding:8px}}
  #siyiUpgradeDialog{{width:98vw;height:96vh;padding:15px}}
  .siyi-upgrade-title{{font-size:21px}}
}}

</style></head>
<body>
<header>
SIYI Pi Control Center {VERSION}<span id="statusbar" style="display:inline-block;margin-left:14px;vertical-align:middle;"></span>
</header>
<nav>
<a href="/">Operations</a>
{'' if setup_is_complete() else '<a href="/first_setup">Wizard</a>'}
<a href="/wifi">WiFi</a>
<a href="/zerotier">ZeroTier</a>
<a href="/endpoints">Hosts</a>
<a href="/mavlink">MAVLink</a>
<a href="/video">Video</a>
<a href="/buttons">Buttons</a>
<a href="/flaps">Flaps</a>
<a href="/parameters">ArduPlane Parameters</a>
<a href="/camera_controls">Camera</a>
<a href="/camera_sd">Camera SD</a>
<a href="/logs">Diagnostics</a>
<a href="/software_update">Software Update</a>
</nav>
<main>{body}</main>

<div id="siyiUpgradeOverlay" role="dialog" aria-modal="true" aria-labelledby="siyiUpgradeTitle" aria-hidden="true">
  <div id="siyiUpgradeDialog">
    <div class="siyi-upgrade-title-row">
      <div>
        <div id="siyiUpgradeTitle" class="siyi-upgrade-title">Software update</div>
        <div id="siyiUpgradeVersion" class="siyi-upgrade-version">Preparing upgrade...</div>
      </div>
      <div id="siyiUpgradePercent" style="font-size:22px;font-weight:800;">0%</div>
    </div>

    <div class="siyi-upgrade-running-row">
      <div id="siyiUpgradeSpinner" class="siyi-upgrade-spinner"></div>
      <div id="siyiUpgradeResultOk" class="siyi-upgrade-result-icon ok">✓</div>
      <div id="siyiUpgradeResultBad" class="siyi-upgrade-result-icon bad">✕</div>
      <div id="siyiUpgradeHeadline">Installing</div>
    </div>

    <div class="siyi-upgrade-progress-shell">
      <div id="siyiUpgradeProgressBar" class="siyi-upgrade-progress-bar running"></div>
    </div>

    <div id="siyiUpgradeStage" class="siyi-upgrade-stage">Starting upgrade</div>
    <div class="siyi-upgrade-meta">
      <span id="siyiUpgradeConnection">Connected to WebUI</span>
      <span id="siyiUpgradeStarted"></span>
    </div>

    <pre id="siyiUpgradeLog">Waiting for upgrade status...</pre>

    <div id="siyiUpgradeWarning" class="siyi-upgrade-warning">
      Do not power off the Raspberry Pi during installation.
    </div>

    <div id="siyiUpgradeDetail" class="siyi-upgrade-detail"></div>

    <div id="siyiUpgradeActions" class="siyi-upgrade-actions">
      <button type="button" onclick="siyiUpgradeToggleDetails()">View details</button>
      <button id="siyiUpgradePrimaryAction" type="button" onclick="siyiUpgradeReload()">Reload WebUI</button>
    </div>
  </div>
</div>

<script>
(function(){{
  const initialState = {initial_upgrade_state};
  const overlay = document.getElementById('siyiUpgradeOverlay');
  const dialog = document.getElementById('siyiUpgradeDialog');
  const spinner = document.getElementById('siyiUpgradeSpinner');
  const okIcon = document.getElementById('siyiUpgradeResultOk');
  const badIcon = document.getElementById('siyiUpgradeResultBad');
  const headline = document.getElementById('siyiUpgradeHeadline');
  const version = document.getElementById('siyiUpgradeVersion');
  const percent = document.getElementById('siyiUpgradePercent');
  const bar = document.getElementById('siyiUpgradeProgressBar');
  const stage = document.getElementById('siyiUpgradeStage');
  const log = document.getElementById('siyiUpgradeLog');
  const connection = document.getElementById('siyiUpgradeConnection');
  const started = document.getElementById('siyiUpgradeStarted');
  const warning = document.getElementById('siyiUpgradeWarning');
  const actions = document.getElementById('siyiUpgradeActions');
  const detail = document.getElementById('siyiUpgradeDetail');
  const primaryAction = document.getElementById('siyiUpgradePrimaryAction');
  let lastState = initialState || {{}};
  let sawRunning = sessionStorage.getItem('siyiUpgradeSawRunning') === '1';
  let logWasNearBottom = true;

  function stateToken(s){{
    return String((s && s.updated_at) || '') + '|' + String((s && s.status) || '');
  }}

  function setLocked(locked){{
    document.body.classList.toggle('siyi-upgrade-locked', locked);
    ['header','nav','main','flightModeMenu'].forEach(function(idOrTag){{
      const el = idOrTag === 'header' || idOrTag === 'nav'
        ? document.querySelector(idOrTag)
        : document.getElementById(idOrTag) || document.querySelector(idOrTag);
      if(!el) return;
      if(locked) el.setAttribute('inert','');
      else el.removeAttribute('inert');
    }});
  }}

  function showOverlay(){{
    overlay.classList.add('visible');
    overlay.setAttribute('aria-hidden','false');
    setLocked(true);
  }}

  function hideOverlay(){{
    overlay.classList.remove('visible');
    overlay.setAttribute('aria-hidden','true');
    setLocked(false);
  }}

  function shouldShowTerminal(s){{
    if(!s || (s.status !== 'complete' && s.status !== 'failed')) return false;
    const dismissed = sessionStorage.getItem('siyiUpgradeDismissed');
    return sawRunning && dismissed !== stateToken(s);
  }}

  function applyState(s){{
    if(!s) return;
    lastState = s;
    const running = !!s.running;
    if(running){{
      sawRunning = true;
      sessionStorage.setItem('siyiUpgradeSawRunning','1');
    }}
    const terminal = shouldShowTerminal(s);
    if(!running && !terminal){{
      hideOverlay();
      return;
    }}

    showOverlay();
    const p = Math.max(0, Math.min(100, Number(s.progress || 0)));
    percent.textContent = running ? p.toFixed(1) + '%' : Math.round(p) + '%';
    bar.style.width = p + '%';
    bar.classList.toggle('running', running);
    stage.textContent = s.stage || (running ? 'Installing update' : 'Upgrade finished');
    const fromV = s.from_version || s.current || '';
    const toV = s.to_version || '';
    version.textContent = toV ? ('Updating ' + fromV + ' → ' + toV) : ('Installed version ' + fromV);
    started.textContent = s.started_at ? ('Started ' + s.started_at) : '';

    const nearBottom = (log.scrollHeight - log.scrollTop - log.clientHeight) < 80;
    log.textContent = s.log || 'Waiting for upgrade status...';
    if(logWasNearBottom || nearBottom) log.scrollTop = log.scrollHeight;
    logWasNearBottom = nearBottom;

    spinner.style.display = running ? 'block' : 'none';
    okIcon.style.display = (!running && s.status === 'complete') ? 'block' : 'none';
    badIcon.style.display = (!running && s.status === 'failed') ? 'block' : 'none';
    actions.classList.toggle('visible', !running);

    if(running){{
      headline.textContent = 'Installing';
      warning.textContent = 'Do not power off the Raspberry Pi during installation.';
    }}else if(s.status === 'complete'){{
      headline.textContent = 'Upgrade complete';
      warning.textContent = 'The new release is installed. Continue to the WebUI.';
      primaryAction.textContent = 'Go to WebUI';
    }}else{{
      headline.textContent = 'Upgrade failed';
      warning.textContent = 'The previous configuration was restored when rollback was required.';
      primaryAction.textContent = 'Reload WebUI';
    }}

    const detailParts = [];
    if(s.error) detailParts.push('Error: ' + s.error);
    if(s.technical_log) detailParts.push('Technical log: ' + s.technical_log);
    detail.textContent = detailParts.join('\\n');
    detail.style.display = 'none';
    detail.classList.remove('visible');
  }}

  async function pollUpgradeState(){{
    try{{
      const response = await fetch('/software_update_status?ts=' + Date.now(), {{cache:'no-store'}});
      if(!response.ok) throw new Error('HTTP ' + response.status);
      const state = await response.json();
      connection.textContent = 'Connected to WebUI';
      applyState(state);
    }}catch(error){{
      if(overlay.classList.contains('visible')){{
        connection.textContent = 'Reconnecting to WebUI...';
        if(lastState && lastState.running){{
          stage.textContent = lastState.stage || 'Installation continues in the background';
        }}
      }}
    }}
  }}

  window.siyiUpgradeShowStarting = function(fromVersion, toVersion){{
    sawRunning = true;
    sessionStorage.setItem('siyiUpgradeSawRunning','1');
    applyState({{
      running:true,status:'starting',progress:2,stage:'Starting upgrade',
      from_version:fromVersion || '',to_version:toVersion || '',
      started_at:'',updated_at:'',technical_log:'',error:'',
      log:'[INFO] Starting software update...'
    }});
  }};

  window.siyiUpgradeToggleDetails = function(){{
    detail.classList.toggle('visible');
    detail.style.display = detail.classList.contains('visible') ? 'block' : 'none';
  }};

  window.siyiUpgradeReload = function(){{
    sessionStorage.setItem('siyiUpgradeDismissed', stateToken(lastState));
    sessionStorage.removeItem('siyiUpgradeSawRunning');
    const destination = lastState && lastState.status === 'complete'
      ? '/'
      : '/software_update';
    window.location.replace(destination);
  }};

  document.addEventListener('keydown', function(event){{
    if(overlay.classList.contains('visible') && event.key === 'Escape'){{
      event.preventDefault();
      event.stopPropagation();
    }}
  }}, true);

  applyState(initialState);
  pollUpgradeState();
  setInterval(pollUpgradeState, 1000);
}})();
</script>


<script>
function setPiStatus(ok){{
  var d=document.getElementById('pidot');
  var l=document.getElementById('pilabel');
  if(!d || !l) return;
  if(ok){{
    d.classList.add('ok');
    l.textContent='Pi connected';
  }} else {{
    d.classList.remove('ok');
    l.textContent='Pi disconnected';
  }}
}}
async function checkPi(){{
  try{{
    const r = await fetch('/health?ts=' + Date.now(), {{cache:'no-store'}});
    setPiStatus(r.ok);
  }} catch(e){{
    setPiStatus(false);
  }}
}}
async function refreshStatusBar(){{
  const el = document.getElementById('statusbar');
  try {{
    const r = await fetch('/status_bar?ts=' + Date.now(), {{cache:'no-store'}});
    if(!r.ok) throw new Error('status fetch failed');
    let statusHtml = await r.text();

    try {{

      const prevHtml = window.__siyiLastStatusHtml || '';
      const prevHadOk = prevHtml.includes('MAVLink OK');
      const newHasDown = statusHtml.includes('MAVLink Down');

      if(prevHadOk && newHasDown){{

        window.__siyiMavDownCount =
          (window.__siyiMavDownCount || 0) + 1;

        if(window.__siyiMavDownCount < 3){{
          statusHtml = prevHtml;
        }}

      }} else {{

        window.__siyiMavDownCount = 0;
      }}

      window.__siyiLastStatusHtml = statusHtml;

    }} catch(e){{}}

    const oldModeText =
      window.__siyiLastGoodModeText || 'MODE: ...';

    el.innerHTML =
      statusHtml +
      '<span id="flightModePill" class="status-pill ok" title="Current FC flight mode">' +
      oldModeText +
      '</span>';
    refreshFlightModePill();
  }} catch(e) {{
    el.innerHTML = '<span style="font-size:13px;font-weight:bold;padding:5px 10px;border-radius:999px;color:white;background:#991b1b">Network Lost / Stale</span>';
  }}
}}



async function refreshFlightModePill(){{
  const pill=document.getElementById('flightModePill');
  if(!pill) return;
  try{{
    const r=await fetch('/flight_mode_state?ts=' + Date.now(), {{cache:'no-store'}});
    if(!r.ok) throw new Error('mode fetch failed');
    const j=await r.json();
    const mode=j.mode || 'UNKNOWN';
    pill.textContent='MODE: ' + mode;
    window.__siyiModeFetchFailCount = 0;

    if(mode !== 'UNKNOWN'){{
      window.__siyiLastGoodModeText = 'MODE: ' + mode;
      pill.textContent = window.__siyiLastGoodModeText;
      pill.className='status-pill ok';
      pill.title='Current FC flight mode';
    }}else{{
      pill.textContent = window.__siyiLastGoodModeText || 'MODE: UNKNOWN';
      pill.className='status-pill warn';
      pill.title='No FC flight mode data yet';
    }}
  }}catch(e){{

    window.__siyiModeFetchFailCount =
      (window.__siyiModeFetchFailCount || 0) + 1;

    if(window.__siyiModeFetchFailCount >= 3){{
      pill.textContent = window.__siyiLastGoodModeText || pill.textContent || 'MODE: UNKNOWN';
      pill.className='status-pill warn';
      pill.title='Flight mode update temporarily unavailable';
    }}

  }}
}}

refreshStatusBar();
setInterval(refreshStatusBar,3000);

refreshFlightModePill();
setInterval(refreshFlightModePill,500);

function closeFlightModeMenu(){{
  const m=document.getElementById('flightModeMenu');
  if(m) m.style.display='none';
}}

function openFlightModeMenu(){{
  const pill=document.getElementById('flightModePill');
  const menu=document.getElementById('flightModeMenu');
  if(!pill || !menu) return;
  const r=pill.getBoundingClientRect();
  menu.style.left=(r.left)+'px';
  menu.style.top=(r.bottom + 8)+'px';
  menu.style.display='block';
}}

async function setFlightMode(mode, el){{
  try{{
    if(window.event){{
      window.event.stopPropagation();
    }}
    const r = await fetch(
      '/set_flight_mode?mode=' + encodeURIComponent(mode),
      {{cache:'no-store'}}
    );

    const j = await r.json();

    if(!j.ok && j.error){{
      alert(j.error);
    }}

  }}catch(e){{
    console.log(e);
  }}

  closeFlightModeMenu();
}}

document.addEventListener('click', function(ev){{
  const pill=document.getElementById('flightModePill');
  const menu=document.getElementById('flightModeMenu');
  if(!pill || !menu) return;

  if(pill.contains(ev.target)){{
    ev.stopPropagation();
    if(menu.style.display==='block') closeFlightModeMenu();
    else openFlightModeMenu();
    return;
  }}

  if(!menu.contains(ev.target)) closeFlightModeMenu();
}});

checkPi();
setInterval(checkPi,3000);
</script>

<div id="flightModeMenu" style="
display:none;
position:fixed;
z-index:99999;
background:#1e293b;
border:1px solid #475569;
border-radius:10px;
padding:6px;
min-width:160px;
box-shadow:0 8px 30px rgba(0,0,0,0.45);
color:#e5e7eb;
font-size:13px;
font-weight:700;
">
<div onclick="setFlightMode('MANUAL', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">MANUAL</div>
<div onclick="setFlightMode('FBWA', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">FBWA</div>
<div onclick="setFlightMode('AUTOTUNE', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">AUTOTUNE</div>
<div onclick="setFlightMode('CRUISE', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">CRUISE</div>
<div onclick="setFlightMode('AUTO', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">AUTO</div>
<div onclick="setFlightMode('RTL', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">RTL</div>
<div onclick="setFlightMode('LOITER', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">LOITER</div>
<div onclick="setFlightMode('TAKEOFF', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">TAKEOFF</div>
<div onclick="setFlightMode('QHOVER', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">QHOVER</div>
<div onclick="setFlightMode('QLOITER', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">QLOITER</div>
<div onclick="setFlightMode('QLAND', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">QLAND</div>
<div onclick="setFlightMode('QRTL', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">QRTL</div>
</div>


</body></html>"""


SERVICE_LABELS = {
    "siyi-button-bridge": "Button Control Bridge",
    "siyi-video-source": "Selected Video Source",
    "siyi-video-dual": "Video UDP Forwarder",
    "mavlink-router": "MAVLink Router (FC ↔ Hosts)",
    "zerotier-one": "ZeroTier Network",
    "siyi-rec-proxy": "Camera / Recording Proxy",
    "siyi-rec-redirect": "Camera Control Redirect",
    "siyi-webui": "Web Interface"
}


CAM_SD_BASE="http://"+CAM_IP+":82"
CAM_SD_DIR="100SIYI_VID"
CAM_SD_MEDIA_TYPE=1
UNIGCS_FIFO="/tmp/siyi_record_proxy"
BYTES_PER_SECOND_2K = int(2.5 * 1024 * 1024)
SD_TOTAL_BYTES = 68719476736

def camera_sd_json(url, timeout=5):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="replace"))


def probe_media_info(url, timeout=8):
    """Return resolution and exact MP4 duration using one range-capable ffprobe."""
    try:
        out = subprocess.check_output([
            "ffprobe", "-v", "error",
            "-select_streams", "v:0",
            "-show_entries", "stream=width,height:format=duration",
            "-of", "json",
            url,
        ], timeout=timeout).decode("utf-8", errors="replace")
        data = json.loads(out)
        streams = data.get("streams") or []
        stream = streams[0] if streams else {}
        width = int(stream.get("width") or 0)
        height = int(stream.get("height") or 0)
        resolution = f"{width}x{height}" if width and height else ""
        duration = float((data.get("format") or {}).get("duration") or 0.0)
        if duration < 0:
            duration = 0.0
        return resolution, duration
    except Exception:
        return "", 0.0


def probe_resolution(url):
    # Backward-compatible wrapper for any older callers.
    return probe_media_info(url, timeout=8)[0]

def camera_sd_files():
    count_url=f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getmediacount?media_type={CAM_SD_MEDIA_TYPE}&path={urllib.parse.quote(CAM_SD_DIR)}"
    count_data=camera_sd_json(count_url)
    count=int(count_data.get("data",{}).get("count",0))
    list_url=f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getmedialist?media_type={CAM_SD_MEDIA_TYPE}&path={urllib.parse.quote(CAM_SD_DIR)}&start=0&count={count}"
    list_data=camera_sd_json(list_url)
    return list_data.get("data",{}).get("list",[])


# GROUNDSTATION_MEDIA_TIMESTAMP_V14_PROVEN_UTC_TO_STOCKHOLM
def camera_sd_head(url, timeout=5):
    """Read camera file metadata and display genuine UTC/GMT in Swedish local time."""
    try:
        req=urllib.request.Request(url, method="HEAD", headers={"Cache-Control":"no-cache"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            size=r.headers.get("Content-Length","")
            mod=r.headers.get("Last-Modified","")
            try:
                dt = parsedate_to_datetime(mod)
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=datetime.timezone.utc)
                mod = dt.astimezone(ZoneInfo("Europe/Stockholm")).strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                pass
            return size, mod
    except Exception:
        return "", ""


def camera_sd_local_date(mod, name="", duration_seconds=0):
    """Return camera file timestamp; never subtract recording duration."""
    try:
        if not mod:
            return "-"
        value = str(mod)
        try:
            # camera_sd_head() has already converted this value to Stockholm.
            return datetime.datetime.strptime(value, "%Y-%m-%d %H:%M:%S").strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            dt = parsedate_to_datetime(value)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=datetime.timezone.utc)
            return dt.astimezone(ZoneInfo("Europe/Stockholm")).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return str(mod or "-")

def human_size(n):
    try:
        n=int(n)
        for unit in ["B","KB","MB","GB"]:
            if n < 1024:
                return f"{n:.1f} {unit}" if unit!="B" else f"{n} {unit}"
            n = n / 1024
        return f"{n:.1f} TB"
    except Exception:
        return "-"


def camera_sd_capacity():
    """
    Try to read SD card capacity from SIYI camera API.
    Returns: total_bytes, free_bytes
    If unknown, returns: None, None
    """
    candidates = [
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getsdinfo",
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getmediainfo",
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getstorageinfo",
    ]

    for url in candidates:
        try:
            with urllib.request.urlopen(url, timeout=3) as r:
                raw = r.read().decode(errors="ignore")
                data = json.loads(raw)

            def find_number(obj, keys):
                if isinstance(obj, dict):
                    for k, v in obj.items():
                        lk = str(k).lower()
                        if lk in keys:
                            try:
                                return int(v)
                            except Exception:
                                pass
                        found = find_number(v, keys)
                        if found is not None:
                            return found
                elif isinstance(obj, list):
                    for item in obj:
                        found = find_number(item, keys)
                        if found is not None:
                            return found
                return None

            total = find_number(data, {"total", "totalsize", "total_size", "capacity", "sd_total", "sdtotal"})
            free = find_number(data, {"free", "freesize", "free_size", "available", "avail", "sd_free", "sdfree"})

            if total and free is not None:
                return total, free

        except Exception:
            pass

    return None, None


def camera_sd_page():
    try:
        files=camera_sd_files()

        # SORT: newest -> oldest by SIYI filename
        try:
            files = sorted(files, key=lambda x: x.get("name",""), reverse=True)
        except Exception:
            pass

        # Fast metadata fetch: get file size/date in parallel instead of slow sequential HEAD calls
        meta = {}
        try:
            from concurrent.futures import ThreadPoolExecutor, as_completed
            urls = [x.get("url","") for x in files if x.get("url","")]
            with ThreadPoolExecutor(max_workers=16) as ex:
                futs = {ex.submit(camera_sd_head, u, 1.5): u for u in urls}
                for fut in as_completed(futs):
                    u = futs[fut]
                    try:
                        meta[u] = fut.result()
                    except Exception:
                        meta[u] = ("", "")
        except Exception:
            meta = {}

        rows=""
        total_used = 0
        for idx, f in enumerate(files):
            name=f.get("name","")
            url=f.get("url","")
            size,lastmod = meta.get(url, ("",""))

            res = ""
            label = name

            if size:
                try:
                    total_used += int(size)
                except Exception:
                    pass
            rows+=f"""<tr>
<td><input style='pointer-events:auto;' type="checkbox" class="sdcheck" name="urls" value="{esc(url)}"></td>
<td><b>{esc(label)}</b><br>
<span class='small'>{esc(url)}</span> <span class="sd-res small" data-url="{esc(url)}"></span><br>
<a href="{esc(url)}" target="_blank">Stream / Open</a>
&nbsp;|&nbsp;
<a href="/camera_sd_download?url={urllib.parse.quote(url)}">Download</a>
&nbsp;|&nbsp;
<a class="danger" href="/camera_sd_delete?url={urllib.parse.quote(url)}" onclick="return confirm('Delete this file from camera SD card?');">Delete</a>
</td>
<td>{esc(human_size(size))}</td>
<td><span class="sd-date" data-url="{esc(url)}" data-end="{esc(lastmod)}">...</span></td>
</tr>"""
        total_cap, free_cap = camera_sd_capacity()
        used_str = human_size(total_used)

        if SD_TOTAL_BYTES:
            total_str = human_size(SD_TOTAL_BYTES)
            free_bytes = SD_TOTAL_BYTES - total_used
            free_bytes = max(0, free_bytes)
            free_str = human_size(free_bytes)
            percent = int((total_used / SD_TOTAL_BYTES) * 100)

            # Estimate recording time left (2K)
            try:
                seconds_left = int(free_bytes / BYTES_PER_SECOND_2K)
                hours = seconds_left // 3600
                minutes = (seconds_left % 3600) // 60
                time_str = f"{hours}h {minutes:02d}m"
            except:
                time_str = "unknown"

            sd_summary = f"Used: {used_str} / {total_str} ({percent}%) | Free: {free_str} | Approx {time_str} 2K recording"
        else:
            sd_summary = f"Used: {used_str}"

        return f"""<h1>Camera SD Card</h1>
<span style="font-size:12px;opacity:.65;margin-left:10px;">v{VERSION}</span>
<div class='card' ><h2>Files on Camera SD</h2>
<p class='small'>Directory: {esc(CAM_SD_DIR)} | Count: {len(files)}<br>{esc(sd_summary)}</p>
<form id="sdform" method="post">
<div style="margin-bottom:10px;display:flex;gap:8px;flex-wrap:wrap;">
<button style='pointer-events:auto;' type="button" onclick="document.querySelectorAll('.sdcheck').forEach(c=>c.checked=true)">Select all</button>
<button style='pointer-events:auto;' type="button" onclick="document.querySelectorAll('.sdcheck').forEach(c=>c.checked=false)">Clear selection</button>
<button style='pointer-events:auto;' type="submit" formaction="/camera_sd_zip">Download selected as ZIP</button>
<button style='pointer-events:auto;' class="danger" type="submit" formaction="/camera_sd_delete_selected" onclick="return confirm('Delete all selected files from camera SD card?');">Delete selected</button>
</div>
<table><tr><th>Select</th><th>File</th><th>Size</th><th>Camera Date</th></tr>{rows}</table>
</form>

<script>
(function(){{
  // GROUNDSTATION_MEDIA_METADATA_V14_ASYNC_RESOLUTION_ONLY
  async function loadSdMediaMeta(){{
    const spans = Array.from(document.querySelectorAll(".sd-res[data-url]"));
    let cursor = 0;
    async function worker(){{
      while(cursor < spans.length){{
        const span = spans[cursor++];
        const url = span.dataset.url || "";
        const dateSpan = document.querySelector('.sd-date[data-url="' + CSS.escape(url) + '"]');
        const end = dateSpan ? (dateSpan.dataset.end || "") : "";
        if(!url){{
          span.textContent = "-";
          if(dateSpan) dateSpan.textContent = "-";
          continue;
        }}
        span.textContent = "...";
        try{{
          const query = "/camera_sd_res?url=" + encodeURIComponent(url) + "&end=" + encodeURIComponent(end);
          const r = await fetch(query, {{cache:"no-store"}});
          const j = await r.json();
          span.textContent = j.res || "-";
          if(dateSpan) dateSpan.textContent = j.date || end || "-";
        }}catch(e){{
          span.textContent = "ERR";
          if(dateSpan) dateSpan.textContent = end || "ERR";
        }}
      }}
    }}
    const workers = Math.min(3, Math.max(1, spans.length));
    await Promise.all(Array.from({{length:workers}}, worker));
  }}

  if(document.readyState === "loading"){{
    document.addEventListener("DOMContentLoaded", function(){{setTimeout(loadSdMediaMeta,120);}});
  }}else{{
    setTimeout(loadSdMediaMeta,120);
  }}
}})();
</script>

</div>"""
    except Exception as e:
        return f"<h1>Camera SD Card</h1><div class='card'><h2 class='bad'>Could not read camera SD</h2><pre>{esc(str(e))}</pre></div>"


def camera_sd_delete_many(urls):
    data=json.dumps({"media_type":CAM_SD_MEDIA_TYPE,"paths":urls}).encode()
    req=urllib.request.Request(
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/deletemedialist",
        data=data,
        headers={"Content-Type":"application/json","Accept":"application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read().decode("utf-8", errors="replace")

def camera_sd_delete(url):
    data=json.dumps({"media_type":CAM_SD_MEDIA_TYPE,"paths":[url]}).encode()
    req=urllib.request.Request(
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/deletemedialist",
        data=data,
        headers={"Content-Type":"application/json","Accept":"application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=8) as r:
        return r.read().decode("utf-8", errors="replace")


def unigcs_controls_page():
    return """<div class="cam-full"><h1>Camera Controls</h1>\n




<style>/* CAMERA_CONTROLS_COMPACT_SAFE_V3 */
.cam-grid{
  display:grid;
  grid-template-columns: repeat(2, minmax(280px, 1fr));
  gap:12px 14px;
  width:100%;
  max-width:none;
  margin:0;
}
.cam-full{
  width:100%;
  max-width:none;
  margin:0 0 10px 0;
}
.card{
  max-width:none;
  width:100%;
  margin:0;
  padding:10px 12px;
  box-sizing:border-box;
}
.card h2{
  margin:0 0 8px 0;
  font-size:18px;
}
.card form{margin:6px 0;}
.gimbal-row{
  display:flex;
  gap:20px;
  align-items:center;
  flex-wrap:wrap;
}
.gimbal-row label{
  display:flex;
  align-items:center;
  gap:6px;
  white-space:nowrap;
}
.cam-grid .card:nth-child(5) form{
  display:inline-block;
  margin-right:4px;
  white-space:nowrap;
}
.cam-grid .card:nth-child(5) button{
  margin-left:0;
  margin-right:6px;
}
.card button{margin:3px 4px 3px 0;padding:6px 10px;}
.card input[type=range]{width:calc(100% - 55px);max-width:none;}
.image-row{
  display:grid;
  grid-template-columns:90px 1fr 38px;
  gap:8px;
  align-items:center;
  margin:4px 0;
}
.image-row label{
  white-space:nowrap;
  color:#cbd5e1;
}
.image-row input[type=range]{
  width:100%;
  max-width:none;
}

.exposure-row{
  display:grid;
  grid-template-columns:110px 1fr;
  gap:8px;
  align-items:center;
  margin:6px 0;
}
.exposure-row label{
  white-space:nowrap;
  color:#cbd5e1;
}
.exposure-row select{
  width:100%;
}

.image-row output{
  text-align:right;
  color:#e5e7eb;
}

.card output{display:inline-block;width:38px;text-align:right;}
.cam-grid .card:first-child button[type=submit]{display:none;}
@media(max-width:900px){
  .cam-grid{grid-template-columns:1fr;}
}
</style>





<script>
function sendSlider(el){
  const data = new URLSearchParams();
  data.append(el.name, el.value);

  fetch('/unigcs_control', {method:'POST', body:data, cache:'no-store', headers:{'X-SIYI-AJAX':'1'}})
    .then(r=>r.json().then(j=>({ok:r.ok,j})))
    .then(({ok,j})=>{ document.getElementById('unigcs_status').innerText=ok?('Sent: '+el.value):('Failed: '+(j.error||'command rejected')); })
    .catch(()=>{ document.getElementById('unigcs_status').innerText='Failed'; });
}

function sendCmd(cmd){
  const data = new URLSearchParams();
  data.append('cmd', cmd);
  fetch('/unigcs_control', {method:'POST', body:data, cache:'no-store', headers:{'X-SIYI-AJAX':'1'}})
    .then(r=>r.json().then(j=>({ok:r.ok,j})))
    .then(({ok,j})=>{ document.getElementById('unigcs_status').innerText=ok?('Sent: '+cmd):('Failed: '+(j.error||cmd)); })
    .catch(()=>{ document.getElementById('unigcs_status').innerText='Failed: '+cmd; });
  return false;
}

function sendForm(form){
  const data = new URLSearchParams(new FormData(form));
  fetch('/unigcs_control', {method:'POST', body:data, cache:'no-store', headers:{'X-SIYI-AJAX':'1'}})
    .then(r=>r.json().then(j=>({ok:r.ok,j})))
    .then(({ok,j})=>{ document.getElementById('unigcs_status').innerText=ok?'Sent':('Failed: '+(j.error||'command rejected')); })
    .catch(()=>{ document.getElementById('unigcs_status').innerText='Failed'; });
  return false;
}

// UI_ACTIVE_STATE_TRACKER_V1
(function(){
  const groups = {
    stream_720p: "stream_res",
    stream_1080p: "stream_res",
    rec_720p: "rec_res",
    rec_1080p: "rec_res",
    rec_2k: "rec_res",
    rec_4k: "rec_res",
    autorecord_on: "auto_rec",
    autorecord_off: "auto_rec",
    gimbal_lock: "gimbal_mode",
    gimbal_follow: "gimbal_mode",
    gimbal_fpv: "gimbal_mode"
  };

  function restoreRadio(group){
    const cmd = localStorage.getItem("siyi_state_" + group);
    if(!cmd) return;
    document.querySelectorAll('input[type="radio"][name="' + group + '"]').forEach(function(r){
      const onclick = r.getAttribute("onclick") || "";
      if(onclick.indexOf(cmd) >= 0) r.checked = true;
    });
  }

  const oldSendCmd = window.sendCmd;
  window.sendCmd = function(cmd){
    const group = groups[cmd];
    if(group) localStorage.setItem("siyi_state_" + group, cmd);
    return oldSendCmd(cmd);
  };

  function restoreValues(){
    ["brightness","contrast","saturation"].forEach(function(name){
      const val = localStorage.getItem("siyi_value_" + name);
      if(val === null) return;
      const el = document.querySelector('input[type="range"][name="' + name + '"]');
      if(el){
        el.value = val;
        const out = el.parentElement ? el.parentElement.querySelector("output") : null;
        if(out) out.value = val;
      }
    });

    ["ev","ss"].forEach(function(name){
      const val = localStorage.getItem("siyi_value_" + name);
      if(val === null) return;
      const el = document.querySelector('select[name="' + name + '"]');
      if(el) el.value = val;
    });
  }

  const oldSendSlider = window.sendSlider;
  window.sendSlider = function(el){
    if(el && el.name){
      localStorage.setItem("siyi_value_" + el.name, el.value);
    }
    return oldSendSlider(el);
  };

  const oldSendForm = window.sendForm;
  window.sendForm = function(form){
    if(form){
      const field = form.querySelector("select[name], input[name]");
      if(field && field.name){
        localStorage.setItem("siyi_value_" + field.name, field.value);
      }
    }
    return oldSendForm(form);
  };

  document.addEventListener("DOMContentLoaded", function(){
    restoreRadio("stream_res");
    restoreRadio("rec_res");
    restoreRadio("auto_rec");
    restoreRadio("gimbal_mode");
    restoreValues();
  });
})();


// PI_SHARED_STATE_SIDECAR_V1
(function(){
  const STATE_URL = "http://" + window.location.hostname + ":8081/ui_state";

  const groups = {
    stream_720p: "stream_res",
    stream_1080p: "stream_res",
    rec_720p: "rec_res",
    rec_1080p: "rec_res",
    rec_2k: "rec_res",
    rec_4k: "rec_res",
    autorecord_on: "auto_rec",
    autorecord_off: "auto_rec",
    gimbal_lock: "gimbal_mode",
    gimbal_follow: "gimbal_mode",
    gimbal_fpv: "gimbal_mode"
  };

  function postState(obj){
    fetch(STATE_URL, {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(obj)
    }).catch(function(){});
  }

  function applyState(st){
    if(!st) return;

    ["stream_res","rec_res","auto_rec","gimbal_mode"].forEach(function(group){
      const cmd = st[group];
      if(!cmd) return;
      document.querySelectorAll('input[type="radio"][name="' + group + '"]').forEach(function(r){
        const onclick = r.getAttribute("onclick") || "";
        if(onclick.indexOf(cmd) >= 0) r.checked = true;
      });
    });

    ["brightness","contrast","saturation"].forEach(function(name){
      const val = st[name];
      if(val === undefined || val === null) return;
      const el = document.querySelector('input[type="range"][name="' + name + '"]');
      if(el){
        el.value = val;
        const out = el.parentElement ? el.parentElement.querySelector("output") : null;
        if(out) out.value = val;
      }
    });

    ["ev","ss"].forEach(function(name){
      const val = st[name];
      if(val === undefined || val === null) return;
      const el = document.querySelector('select[name="' + name + '"]');
      if(el) el.value = val;
    });
  }

  const prevSendCmd = window.sendCmd;
  window.sendCmd = function(cmd){
    const group = groups[cmd];
    if(group){
      const obj = {};
      obj[group] = cmd;
      postState(obj);
    }
    return prevSendCmd(cmd);
  };

  const prevSendSlider = window.sendSlider;
  window.sendSlider = function(el){
    if(el && el.name){
      const obj = {};
      obj[el.name] = el.value;
      postState(obj);
    }
    return prevSendSlider(el);
  };

  const prevSendForm = window.sendForm;
  window.sendForm = function(form){
    if(form){
      const field = form.querySelector("select[name], input[name]");
      if(field && field.name){
        const obj = {};
        obj[field.name] = field.value;
        postState(obj);
      }
    }
    return prevSendForm(form);
  };

  document.addEventListener("DOMContentLoaded", function(){
    setTimeout(function(){
      fetch(STATE_URL, {cache:"no-store"})
        .then(function(r){ return r.json(); })
        .then(applyState)
        .catch(function(){});
    }, 250);
  });
})();

</script>
<div id="unigcs_status" class="small">Ready</div></div>
<div class="cam-grid">
<div class='card'>
<h2>Image</h2>

<form class="image-row" onsubmit="return false;">
<label>Brightness</label>
<input style='pointer-events:auto;' type="range" onchange="sendSlider(this)" name="brightness" min="0" max="100" value="50" oninput="bval.value=this.value">
<output id="bval">50</output>
</form>

<form class="image-row" onsubmit="return false;">
<label>Contrast</label>
<input style='pointer-events:auto;' type="range" onchange="sendSlider(this)" name="contrast" min="0" max="100" value="50" oninput="cval.value=this.value">
<output id="cval">50</output>
</form>

<form class="image-row" onsubmit="return false;">
<label>Saturation</label>
<input style='pointer-events:auto;' type="range" onchange="sendSlider(this)" name="saturation" min="0" max="100" value="50" oninput="sval.value=this.value">
<output id="sval">50</output>
</form>
</div>

<div class='card'>
<h2>Exposure <span style="color:#9ca3af;font-size:11px;font-style:italic;">(currently unsupported)</span></h2>

<form class="exposure-row" onsubmit="return false;">
<label>EV</label>
<select style='pointer-events:auto;' name="ev" onchange="sendForm(this.form)">
<option value="0">Auto</option>
<option value="1">-2.0</option>
<option value="2">-1.5</option>
<option value="3">-1.0</option>
<option value="4">-0.5</option>
<option value="5">0</option>
<option value="6">+0.5</option>
<option value="7">+1.0</option>
<option value="8">+1.5</option>
<option value="9">+2.0</option>
</select>
</form>

<form class="exposure-row" onsubmit="return false;">
<label>Shutter Speed</label>
<select style='pointer-events:auto;' name="ss" onchange="sendForm(this.form)">
<option value="0">Auto</option>
<option value="1">1/30</option>
<option value="2">1/60</option>
<option value="3">1/120</option>
<option value="4">1/250</option>
<option value="5">1/500</option>
<option value="6">1/1000</option>
<option value="7">1/2000</option>
</select>
</form>
</div>

<div class='card'>
<h2>Stream Resolution</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">720p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="stream_res" onclick="sendCmd('stream_720p')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">1080p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="stream_res" onclick="sendCmd('stream_1080p')"></span>
</form>
</div>

<div class='card'>
<h2>Recording Resolution</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">720p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_720p')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">1080p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_1080p')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">2K <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_2k')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">4K <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_4k')"></span>
</form>
</div>

<div class='card'>
<h2>Gimbal Mode</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">Lock <input style='pointer-events:auto;' style="width:auto;" type="radio" name="gimbal_mode" onclick="sendCmd('gimbal_lock')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">Follow <input style='pointer-events:auto;' style="width:auto;" type="radio" name="gimbal_mode" onclick="sendCmd('gimbal_follow')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">FPV <input style='pointer-events:auto;' style="width:auto;" type="radio" name="gimbal_mode" onclick="sendCmd('gimbal_fpv')"></span>
</form>
</div>

<div class='card'>
<h2>Auto Recording</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">On <input style='pointer-events:auto;' style="width:auto;" type="radio" name="auto_rec" onclick="sendCmd('autorecord_on')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">Off <input style='pointer-events:auto;' style="width:auto;" type="radio" name="auto_rec" onclick="sendCmd('autorecord_off')"></span>
</form>
</div>

</div>
<p class="small cam-full"></p>
"""

def send_unigcs_fifo(command):
    command = (command or "").strip()
    if not command:
        return "No command"

    allowed_prefixes = ("brightness:", "saturation:", "contrast:", "ev:", "ss:")
    allowed_exact = {
        "stream_720p", "stream_1080p",
        "rec_720p", "rec_1080p", "rec_2k", "rec_4k",
        "gimbal_lock", "gimbal_follow", "gimbal_fpv",
        "autorecord_on", "autorecord_off",
        "start", "stop",
    }

    commands = [c.strip() for c in command.split(";") if c.strip()]

    for c in commands:
        if c not in allowed_exact and not c.startswith(allowed_prefixes):
            return "Rejected command: " + c

    import os, errno, time

    try:
        # retry open FIFO safely
        fd = None
        for _ in range(20):
            try:
                fd = os.open(UNIGCS_FIFO, os.O_WRONLY | os.O_NONBLOCK)
                break
            except OSError:
                time.sleep(0.05)
        if fd is None:
            return "FIFO not ready"

        try:
            for c in commands:
                os.write(fd, (c + "\n").encode())
                time.sleep(0.05)
        finally:
            os.close(fd)
    except OSError as e:
        if e.errno == errno.ENXIO:
            return "FIFO has no active reader / SIYI proxy not ready"
        return "FIFO write failed: " + str(e)

    return "Sent UniGCS control: " + command



# ENDPOINTS_SHARED_CONFIG_V1
def load_endpoints():
    defaults = [
        {"name":"Host 1","ip":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","video":True,"mavlink":True},
        {"name":"Host 2","ip":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","video":True,"mavlink":True},
    ]
    try:
        if os.path.exists(ENDPOINTS_FILE):
            data=json.loads(read_file(ENDPOINTS_FILE))
            if isinstance(data,list) and data:
                return data
    except Exception:
        pass
    return defaults

def save_endpoints_from_params(data):
    names=data.get("name",[])
    ips=data.get("ip",[])
    delete_on=set(data.get("delete_host",[]))
    endpoints=[]
    for i,ip in enumerate(ips):
        if str(i) in delete_on:
            continue
        ip=(ip or "").strip()
        if not ip:
            continue
        name=(names[i].strip() if i < len(names) and names[i].strip() else f"Host {i+1}")
        endpoints.append({
            "name": name,
            "ip": ip,
            "video": False,
            "mavlink": True,
        })
    if not endpoints:
        try:
            existing = load_endpoints()
            if existing:
                endpoints = existing
        except Exception:
            pass

    if not endpoints:
        endpoints=[
            {"name":"Host 1","ip":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","video":True,"mavlink":True},
            {"name":"Host 2","ip":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","video":True,"mavlink":True},
        ]
    write_file(ENDPOINTS_FILE, json.dumps(endpoints, indent=2))
    apply_siyi_endpoints_now()
    apply_siyi_endpoints_now()


def host_ping_status(ip):
    if not ip:
        return ("bad", "No IP")

    out=sh(f"ping -c 1 -W 1 {ip} 2>/dev/null || true")

    if "1 received" in out or "1 packets received" in out:
        m=re.search(r"time=([0-9.]+)", out)
        return ("ok", "OK" + (f" {m.group(1)} ms" if m else ""))

    return ("bad", "No ping")

def host_mavlink_status(ip):
    if not ip:
        return ("bad", "No IP")

    conf=read_file(MAVCONF)
    configured=(ip in conf)

    if not configured:
        return ("bad", "Not configured")

    # Real MAVLink activity is tracked by background tcpdump monitor.
    # UI should not run tcpdump during page rendering.
    try:
        data=json.loads(read_file("/tmp/siyi_mavlink_host_activity.json") or "{}")
        item=data.get(ip,{})
        last=float(item.get("last_seen",0))
        age=time.time()-last
        if last > 0 and age < 15:
            return ("ok", "ACTIVE")
        if last > 0:
            return ("warn", "STALE")
    except Exception:
        pass

    return ("ok", "MAVLink endpoint configured")
def host_video_status(ip):
    if not ip:
        return ("bad", "No IP")

    # Current architecture: QGC pulls RTSP from MediaMTX on :8554.
    # A host is video-active if it has an established TCP session to local :8554
    # or recent MediaMTX logs show that host reading main.264.
    ss_out=sh("ss -tunap 2>/dev/null | grep ':8554' || true")
    logs=sh("journalctl -u mediamtx.service -n 160 --no-pager 2>/dev/null || true")

    active_tcp=(ip in ss_out and ":8554" in ss_out and "ESTAB" in ss_out)
    active_log=(ip in logs and ("is reading from path" in logs or "session" in logs))

    if active_tcp:
        return ("ok", "ACTIVE")

    if active_log:
        return ("warn", "RECENT")

    mediamtx=sh("systemctl is-active mediamtx.service 2>/dev/null || true").strip()
    if mediamtx=="active":
        return ("warn", "NO CLIENT")

    return ("bad", "OFFLINE")


def host_qgc_status(ip):
    if not ip:
        return ("bad", "No IP")

    ss_out=sh("ss -tunap 2>/dev/null || true")
    medialog=sh("journalctl -u mediamtx.service -n 180 --no-pager 2>/dev/null || true")

    # Strong QGC confirmation signals:
    # 1) Host has active RTSP TCP session to MediaMTX :8554.
    # 2) Host has REC/control TCP session to :37256.
    # 3) Recent MediaMTX log from host reading stream.
    active_rtsp=(ip in ss_out and ":8554" in ss_out and "ESTAB" in ss_out)
    active_control=(ip in ss_out and ":37256" in ss_out and "ESTAB" in ss_out)
    recent_rtsp=(ip in medialog and ("is reading from path" in medialog or "created by" in medialog))

    if active_rtsp and active_control:
        return ("ok", "VIDEO + CTRL")

    if active_rtsp:
        return ("ok", "VIDEO")

    if active_control:
        return ("ok", "CTRL")

    if recent_rtsp:
        return ("warn", "RECENT")

    return ("warn", "NOT CONFIRMED")


def host_operational_table():
    eps=load_endpoints()

    if not eps:
        return "<p class='small'>No endpoint hosts configured.</p>"

    rows=""

    for e in eps:
        name=e.get("name","")
        ip=e.get("ip","")

        ping_cls,ping_txt=host_ping_status(ip)

        if e.get("mavlink",True):
            mav_cls,mav_txt=host_mavlink_status(ip)
        else:
            mav_cls,mav_txt=("warn","Disabled")

        vid_cls,vid_txt=host_video_status(ip)
        qgc_cls,qgc_txt=host_qgc_status(ip)

        # If host is unreachable on network level,
        # suppress stale/recent subsystem activity states.
        if ping_cls == "bad":
            if mav_txt != "Disabled":
                mav_cls,mav_txt=("bad","HOST OFFLINE")
            vid_cls,vid_txt=("bad","HOST OFFLINE")
            qgc_cls,qgc_txt=("bad","HOST OFFLINE")

        rows += f"""
        <tr>
          <td><b>{esc(name)}</b><br><span class='small'>{esc(ip)}</span></td>
          <td><span class='status-pill {ping_cls}'>{esc(ping_txt)}</span></td>
          <td><span class='status-pill {mav_cls}'>{esc(mav_txt)}</span></td>
          <td><span class='status-pill {vid_cls}'>{esc(vid_txt)}</span></td>
          <td><span class='status-pill {qgc_cls}'>{esc(qgc_txt)}</span></td>
        </tr>
        """

    return f"""
    <style>
    .hoststatus table {{
      width:100%;
      table-layout:auto;
    }}

    .hoststatus td,
    .hoststatus th {{
      vertical-align:middle;
      white-space:nowrap;
    }}

    .hoststatus .status-pill {{
      display:inline-block;
      padding:5px 10px;
      border-radius:999px;
      font-size:12px;
      font-weight:700;
      line-height:1.0;
      white-space:nowrap;
    }}

    .hoststatus th:nth-child(2),
    .hoststatus td:nth-child(2),
    .hoststatus th:nth-child(3),
    .hoststatus td:nth-child(3),
    .hoststatus th:nth-child(4),
    .hoststatus td:nth-child(4) {{
      width:120px;
    }}

    .hoststatus th:nth-child(5),
    .hoststatus td:nth-child(5) {{
      width:150px;
    }}
    </style>

    <div class='hoststatus'>
    <table>
      <tr>
        <th>Host</th>
        <th>Network</th>
        <th>MAVLink</th>
        <th>Video</th>
        <th>QGC</th>
      </tr>
      {rows}
    </table>

    <p class='small'>
    Network = ICMP ping reachability only.<br>
    MAVLink sent = Pi has recently sent UDP telemetry packets to this host on port 14550.<br>
    Video = active/recent RTSP client session from this host via MediaMTX.<br>
    QGC = confirmed only by host-side RTSP/control activity back to the Pi.
    </p></div>
    """


def endpoints_summary(kind):
    eps=load_endpoints()
    rows=""
    for e in eps:
        enabled=e.get(kind,False)
        rows+=f"<tr><td>{esc(e.get('name',''))}</td><td>{esc(e.get('ip',''))}</td><td>{'Yes' if enabled else 'No'}</td></tr>"
    return f"<table><tr><th>Host</th><th>IP</th><th>{kind.capitalize()}</th></tr>{rows}</table><p class='small'>Edit hosts on the Endpoints page.</p>"

def endpoints_page():
    eps=load_endpoints()
    rows=""
    for i,e in enumerate(eps):
        rows+=f"""
        <tr>
          <td><input style='pointer-events:auto;' name='name' value='{esc(e.get("name",f"Host {i+1}"))}'></td>
          <td><input style='pointer-events:auto;' name='ip' value='{esc(e.get("ip",""))}'></td>
          <td style='text-align:center'><input style='pointer-events:auto;width:auto;' type='checkbox' name='delete_host' value='{i}'></td>
        </tr>"""
    rows += """
        <tr>
          <td><input style='pointer-events:auto;' name='name' placeholder='Host 3'></td>
          <td><input style='pointer-events:auto;' name='ip' placeholder='192.168.191.xxx'></td>
          <td></td>
        </tr>"""
    return f"""<h1>MAVLink Hosts</h1>

    <div class='card'>
    <h2>Host Operational Status</h2>
    {host_operational_table()}
    </div>

    <div class='card'>
    <div style='display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;'>
      <p class='small' style='margin:0;'>Saved hosts are automatically used as MAVLink destinations.</p>

      <button id='matrixOpenBtn'
              type='button'
              style='pointer-events:auto;background:#1d4ed8;color:white;border:0;border-radius:10px;padding:8px 14px;font-weight:700;cursor:pointer;'>
        Host status reference
      </button>
    </div>

<div id='matrixFloat'
     class='card'
     style='display:none;position:fixed;right:40px;top:90px;width:900px;min-width:340px;max-width:92vw;max-height:88vh;overflow:auto;z-index:50;box-shadow:0 12px 30px rgba(0,0,0,.45);'>

  <h2 id='matrixDragHandle'
      style='cursor:move;margin-top:0;display:flex;justify-content:space-between;align-items:center;gap:12px;'>

    <span>Host status reference</span>

    <button id='matrixCloseBtn'
            type='button'
            style='pointer-events:auto;background:#334155;color:#e5e7eb;border:0;border-radius:999px;margin:0;padding:2px 8px;font-size:14px;line-height:1.3;cursor:pointer;'>
      ×
    </button>
  </h2>

  <img src='/static/mavlink_qgc_matrix.png'
       style='width:100%;height:auto;border-radius:12px;display:block;'>

  <div id='matrixResizeHandle'
       style='position:absolute;left:0;bottom:0;width:26px;height:26px;cursor:nesw-resize;'></div>
</div>

<script>
(function(){{
  const openBtn=document.getElementById('matrixOpenBtn');
  const box=document.getElementById('matrixFloat');
  const handle=document.getElementById('matrixDragHandle');
  const closeBtn=document.getElementById('matrixCloseBtn');
  const resize=document.getElementById('matrixResizeHandle');

  if(!openBtn || !box || !handle || !resize) return;

  openBtn.addEventListener('click', function(){{
    box.style.display='block';
  }});

  if(closeBtn){{
    closeBtn.addEventListener('mousedown', function(e){{
      e.stopPropagation();
    }});

    closeBtn.addEventListener('click', function(e){{
      e.preventDefault();
      e.stopPropagation();
      box.style.display='none';
    }});
  }}

  let dragging=false;
  let startX=0;
  let startY=0;
  let startLeft=0;
  let startTop=0;

  handle.addEventListener('mousedown', function(e){{
    dragging=true;

    const r=box.getBoundingClientRect();

    startX=e.clientX;
    startY=e.clientY;
    startLeft=r.left;
    startTop=r.top;

    box.style.left=r.left+'px';
    box.style.top=r.top+'px';
    box.style.right='auto';

    e.preventDefault();
  }});

  document.addEventListener('mousemove', function(e){{
    if(!dragging) return;

    box.style.left=(startLeft + (e.clientX-startX))+'px';
    box.style.top=(startTop + (e.clientY-startY))+'px';
  }});

  document.addEventListener('mouseup', function(){{
    dragging=false;
    resizing=false;
  }});

  let resizing=false;
  let startWidth=0;
  let startHeight=0;
  let resizeStartX=0;
  let resizeStartY=0;
  let resizeStartLeft=0;

  resize.addEventListener('mousedown', function(e){{
    resizing=true;

    const r=box.getBoundingClientRect();

    startWidth=r.width;
    startHeight=r.height;
    resizeStartX=e.clientX;
    resizeStartY=e.clientY;
    resizeStartLeft=r.left;

    e.preventDefault();
    e.stopPropagation();
  }});

  document.addEventListener('mousemove', function(e){{
    if(!resizing) return;

    let rightEdge=resizeStartLeft + startWidth;

    let newWidth=rightEdge - e.clientX;
    let newHeight=startHeight + (e.clientY-resizeStartY);

    newWidth=Math.max(340,newWidth);
    newHeight=Math.max(260,newHeight);

    box.style.width=newWidth+'px';
    box.style.height=newHeight+'px';
  }});
}})();
</script>


    <form method='post' action='/save_endpoints'>
    <table><tr><th>Preset</th><th>IP</th><th>Delete</th></tr>{rows}</table>
    <button style='pointer-events:auto;'>Save endpoints</button>
    </form>
    </div>"""

def make_video_service_from_endpoints(rtsp, protocols, latency, port):
    eps=[e for e in load_endpoints() if e.get("video",False) and e.get("ip")]
    if not eps:
        eps=[{"ip":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+""},{"ip":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+""}]
    branches=" ".join([f"t. ! queue ! udpsink host={e['ip']} port={port}" for e in eps])
    return f"""[Unit]
Description=SIYI RTSP to UDP forwarder
After=network-online.target zerotier-one.service NetworkManager.service
Wants=network-online.target zerotier-one.service

[Service]
Type=simple
Restart=always
RestartSec=3
ExecStart=/usr/bin/gst-launch-1.0 -e rtspsrc location={rtsp} latency={latency} protocols={protocols} ! rtph265depay ! h265parse ! rtph265pay config-interval=1 pt=96 ! tee name=t {branches}
ExecStop=/usr/bin/pkill -f "gst-launch-1.0"
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
"""

def make_mav_conf_from_endpoints(device, baud, port, tcp):
    eps=[e for e in load_endpoints() if e.get("ip")]

    lines=[f"""[UartEndpoint fc]
Device={device}
Baud={baud}

[UdpEndpoint webui_status_monitor]
Mode=Normal
Address=127.0.0.1
Port=14601

[UdpEndpoint button_safety]
Mode=Normal
Address=127.0.0.1
Port=14600
"""]

    for i,e in enumerate(eps,1):
        lines.append(f"""
[UdpEndpoint host{i}]
Mode=Normal
Address={e['ip']}
Port={port}
""")

    lines.append(f"""
[TcpEndpoint server]
Mode=Server
Address=0.0.0.0
Port={tcp}
""")

    return "".join(lines)

# ENDPOINTS_SHARED_CONFIG_V1_END



def apply_siyi_endpoints_now():
    try:
        subprocess.run(["/home/pi/apply_siyi_endpoints.sh"], timeout=10, check=False)
    except Exception as e:
        print("apply_siyi_endpoints failed:", e)


def fc_parameter_export_handler(self):
    import json, time, subprocess
    from pathlib import Path

    cache_path = Path("/etc/siyi/param_metadata_cache.json")
    fresh_snapshot_path = Path("/tmp/siyi_param_cache.json")
    refresh_script = "/home/pi/siyi_param_full_cache.py"
    log_path = Path("/tmp/fc_parameter_export.log")

    try:
        with open(log_path, "w") as log:
            rc = subprocess.run(
                ["/home/pi/siyi-bridge-venv/bin/python", refresh_script],
                stdout=log,
                stderr=subprocess.STDOUT,
                timeout=180
            ).returncode

        if rc != 0:
            try:
                tail = log_path.read_text(errors="ignore")[-1500:]
            except Exception:
                tail = "unknown error"
            body = ("FC Parameter Export failed: could not synchronize parameters from FC.\n\n" + tail).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if not cache_path.exists():
            body = b"FC Parameter Export failed: parameter cache was not created."
            self.send_response(500)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        # Truth source for export is the fresh full FC snapshot just collected by refresh_script.
        # The WebUI/cache is not the authority for export values.
        data = json.loads(fresh_snapshot_path.read_text())
        params = data.get("params", {})
        expected = int(data.get("expected_count", 0) or 0)
        received = int(data.get("received_count", 0) or 0)

        if not params or expected <= 0 or received <= 0 or expected != received or len(params) != received:
            body = (
                "FC Parameter Export refused: fresh FC parameter snapshot is incomplete.\n"
                f"expected_count={expected}, received_count={received}, params={len(params)}\n"
            ).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        def fmt_value(v):
            try:
                f = float(v)
                if f.is_integer():
                    return str(int(f))
                return ("%.10g" % f)
            except Exception:
                return str(v)

        lines = [
            "# Onboard parameters for Vehicle 1",
            "#",
            "# Stack: ArduPilot",
            "# Vehicle: Fixed wing aircraft",
            "# Version: 4.5.7",
            "# Git Revision: exported-by-siyi-pi",
            "#",
            "# Vehicle-Id Component-Id Name Value Type",
        ]

        def sort_key(item):
            name, info = item
            try:
                return (int(info.get("index", 999999)), name)
            except Exception:
                return (999999, name)

        # Export values directly from the fresh FC snapshot.
        # No WebUI state, no stale metadata value cache, no per-param /get loop.
        for name, info in sorted(params.items(), key=sort_key):
            val = fmt_value(info.get("value", 0))
            ptype = int(info.get("type", 9) or 9)
            lines.append(f"1\t1\t{name}\t{val}\t{ptype}")

        body = ("\n".join(lines) + "\n").encode("utf-8")
        filename = "fc_parameters_" + time.strftime("%Y%m%d_%H%M%S") + ".params"

        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Set-Cookie", "fc_export_done=1; Path=/; Max-Age=20; SameSite=Lax")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    except subprocess.TimeoutExpired:
        body = b"FC Parameter Export failed: FC parameter synchronization timed out."
        self.send_response(504)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    except Exception as e:
        body = ("FC Parameter Export failed: " + repr(e)).encode("utf-8")
        self.send_response(500)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class H(BaseHTTPRequestHandler):

    def do_POST(self):
        # CPU_TEMP_VOICE_PAGE_V1
        if self.path.startswith("/cpu_temp_voice_save"):
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                raw = self.rfile.read(length).decode()
                data = dict(urllib.parse.parse_qsl(raw))

                enabled = data.get("enabled", "") == "1"
                try:
                    interval = float(str(data.get("interval", "5")).replace(",", "."))
                except Exception:
                    interval = 5

                if interval <= 0:
                    enabled = False
                    interval = 5

                if enabled and interval < 0.25:
                    raise ValueError("Minimum enabled interval is 0.25 minutes")

                cfg = {"enabled": enabled, "interval_minutes": interval}
                cfg_path = "/etc/siyi/cpu_temp_voice.json"

                print("[CPU_TEMP_SAVE] writing cfg=%r path=%s" % (cfg, cfg_path), flush=True)

                with open(cfg_path, "w") as f:
                    json.dump(cfg, f)

                print("[CPU_TEMP_SAVE] write complete", flush=True)

                try:
                    with open(cfg_path, "r") as f:
                        verify = f.read()
                    print("[CPU_TEMP_SAVE] verify=%s" % verify, flush=True)
                except Exception as e:
                    print("[CPU_TEMP_SAVE] verify failed: %s" % e, flush=True)

                self.send_response(303)
                self.send_header("Location", "/cpu_temp_voice")
                self.end_headers()
                return

            except Exception as e:
                self.send_error(400, str(e))
                return

        length = int(self.headers.get("Content-Length", 0))
        data = self.rfile.read(length).decode()
        params = dict(parse_qsl(data))

        if self.path == "/unigcs_control":
            cmd = params.get("cmd", "")
            send_unigcs_fifo(cmd)
            self.send_response(303)
            self.send_header("Location", "/camera_controls")
            self.end_headers()
            return

    def do_GET(self):

        request_path = urllib.parse.urlparse(self.path).path
        upgrade_allowed_paths = {
            "/software_update_status",
            "/health",
        }
        if (
            software_update_lock_active()
            and request_path not in upgrade_allowed_paths
            and not request_path.startswith("/static/")
        ):
            body = """
            <h1>Software update in progress</h1>
            <div class='card'>
              <p>The WebUI is locked until the software update finishes.</p>
              <p class='small'>Installation progress is shown in the update dialog.</p>
            </div>
            """
            payload = page("Software update in progress", body).encode("utf-8")
            self.send_response(423)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if self.path.startswith("/static/"):
            path = "/home/pi/siyi-webui" + self.path

            if not os.path.isfile(path):
                self.send_error(404)
                return

            ctype = "application/octet-stream"

            if path.endswith(".png"):
                ctype = "image/png"
            elif path.endswith(".jpg") or path.endswith(".jpeg"):
                ctype = "image/jpeg"

            with open(path, "rb") as f:
                data = f.read()

            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/video_source_status"):
            payload = video_source_read_status()
            cfg = video_source_read_config()
            payload["configured_source"] = cfg.get("source", "siyi_rtsp")
            payload["source_names"] = video_source_names(cfg)
            send_json_response(self, payload, 200)
            return

        if self.path.startswith("/camera_sd_meta"):
            qs = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(self.path).query))
            url = qs.get("url", "")
            size, mod = camera_sd_head(url, timeout=3)
            name = os.path.basename(urllib.parse.urlparse(url).path)
            data = json.dumps({"size": human_size(size), "date": camera_sd_local_date(mod, name)}).encode()
            self.send_response(200)
            self.send_header("Content-Type","application/json")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/camera_sd_res"):
            qs = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(self.path).query))
            url = qs.get("url", "")
            end_time = qs.get("end", "")
            res = ""
            duration = 0.0
            try:
                if url:
                    res, duration = probe_media_info(url, timeout=8)
            except Exception:
                res, duration = "", 0.0
            data = json.dumps({
                "res": res,
                "duration": duration,
                "date": camera_sd_local_date(end_time),
            }).encode()
            self.send_response(200)
            self.send_header("Content-Type","application/json")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/camera_sd_stream"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            url = q.get("url", [""])[0]

            if not url.startswith(CAM_SD_BASE + "/"):
                self.send_error(400, "Invalid camera SD URL")
                return

            try:
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=20) as r:
                    self.send_response(200)
                    self.send_header("Content-Type", "video/mp4")
                    self.send_header("Content-Disposition", "inline")
                    self.end_headers()
                    shutil.copyfileobj(r, self.wfile, length=1024*1024)
                return
            except Exception as e:
                self.send_error(502, "Camera SD stream failed: " + str(e))
                return

        if self.path in ("/camera_controls", "/unigcs_controls"):
            body = page("Camera Controls", unigcs_controls_page())
            self.send_response(200)
            self.send_header("Content-Type","text/html")
            self.end_headers()
            self.wfile.write(body.encode())
            return

        if self.path.startswith("/camera_sd_download"):
            qs=dict(urllib.parse.parse_qsl(urllib.parse.urlparse(self.path).query))
            url=qs.get("url","")
            if not url.startswith(CAM_SD_BASE + "/"):
                self.send_error(400, "Invalid camera SD URL"); return
            filename=os.path.basename(urllib.parse.urlparse(url).path) or "camera_file.mp4"
            try:
                with urllib.request.urlopen(url, timeout=10) as r:
                    data=r.read()
                self.send_response(200)
                self.send_header("Content-Type","video/mp4")
                self.send_header("Content-Disposition",f'attachment; filename="{filename}"')
                self.send_header("Content-Length",str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            except Exception as e:
                self.send_error(502, str(e))
            return

        # CPU_TEMP_VOICE_UI_V1
        # CPU_TEMP_VOICE_PAGE_V1
        if self.path.startswith("/cpu_temp_voice") and not self.path.startswith("/cpu_temp_voice_config"):
            cfg_path = "/etc/siyi/cpu_temp_voice.json"

            def read_cpu_temp_voice_cfg():
                try:
                    with open(cfg_path, "r") as f:
                        d = json.load(f)
                except Exception:
                    d = {"enabled": False, "interval_minutes": 5}
                return {
                    "enabled": bool(d.get("enabled", False)),
                    "interval_minutes": float(d.get("interval_minutes", 5) or 5),
                    "battery_enabled": bool(d.get("battery_enabled", False)),
                    "battery_interval_minutes": float(d.get("battery_interval_minutes", 5) or 5),
                    "battery_low_voltage": float(d.get("battery_low_voltage", 10.5) or 10.5),
                }

            cfg = read_cpu_temp_voice_cfg()
            checked = "checked" if cfg["enabled"] else ""
            interval = cfg["interval_minutes"]
            cfg["battery_enabled_checked"] = "checked" if cfg.get("battery_enabled", False) else ""

            body = f"""
            <h1>Voice Alerts</h1>
            <div class='card'>
              <form method='get' action='/cpu_temp_voice_config'>
                <label style='display:block;margin-bottom:12px;'>
                  <input type='checkbox' name='enabled' value='1' {checked} style='width:auto;'>
                  Enable spoken CPU temperature alerts
                </label>

                <label>Interval in minutes</label>
                <input name='interval' value='{interval}' inputmode='decimal' style='max-width:160px;'>

                <hr style='border-color:#334155;margin:18px 0;'>

                <h2>Battery Voltage</h2>
                <label style='display:block;margin-bottom:12px;'>
                  <input type='checkbox' name='battery_enabled' value='1' {cfg.get("battery_enabled_checked","")} style='width:auto;'>
                  Enable spoken battery voltage alerts
                </label>

                <label>Battery voltage interval in minutes</label>
                <input name='battery_interval' value='{cfg.get("battery_interval_minutes",5)}' inputmode='decimal' style='max-width:160px;'>

                <label>Low voltage threshold</label>
                <input name='battery_low_voltage' value='{cfg.get("battery_low_voltage",10.5)}' inputmode='decimal' style='max-width:160px;'>

                <p class='small'>
                  Enter 0 or uncheck Enable to disable each alert. Low-voltage warning is spoken when current voltage is equal to or below the threshold.
                </p>

                <button type='submit'>Save</button>
                <a class='button' href='/' style='margin-left:8px;text-decoration:none;'>Back</a>
              </form>
            </div>
            """

            html_body = page("Voice Alerts", body)
            self.send_response(200)
            self.send_header("Content-Type","text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(html_body.encode())
            return

        if self.path.startswith("/cpu_temp_voice_config"):
            try:
                cfg_path = "/etc/siyi/cpu_temp_voice.json"
                qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)

                def read_cfg():
                    try:
                        with open(cfg_path, "r") as f:
                            d = json.load(f)
                    except Exception:
                        d = {"enabled": False, "interval_minutes": 5}
                    return {
                        "enabled": bool(d.get("enabled", False)),
                        "interval_minutes": float(d.get("interval_minutes", 5) or 5),
                    }

                cfg = read_cfg()

                if "enabled" in qs or "interval" in qs or "battery_enabled" in qs or "battery_interval" in qs or "battery_low_voltage" in qs:
                    enabled = qs.get("enabled", ["1" if cfg["enabled"] else "0"])[0].strip() in ("1","true","yes","on")
                    try:
                        interval = float(qs.get("interval", [str(cfg["interval_minutes"])])[0])
                    except Exception:
                        interval = cfg["interval_minutes"]

                    if interval <= 0:
                        enabled = False
                        interval = cfg["interval_minutes"] if cfg["interval_minutes"] > 0 else 5

                    if enabled and interval < 0.25:
                        raise ValueError("Minimum enabled interval is 0.25 minutes")

                    battery_enabled = qs.get("battery_enabled", ["1" if cfg.get("battery_enabled", False) else "0"])[0].strip() in ("1","true","yes","on")

                    try:
                        battery_interval = float(qs.get("battery_interval", [str(cfg.get("battery_interval_minutes", 5))])[0])
                    except Exception:
                        battery_interval = cfg.get("battery_interval_minutes", 5)

                    try:
                        battery_low_voltage = float(qs.get("battery_low_voltage", [str(cfg.get("battery_low_voltage", 10.5))])[0])
                    except Exception:
                        battery_low_voltage = cfg.get("battery_low_voltage", 10.5)

                    if battery_interval <= 0:
                        battery_enabled = False
                        battery_interval = 5

                    cfg = {
                        "enabled": enabled,
                        "interval_minutes": interval,
                        "battery_enabled": battery_enabled,
                        "battery_interval_minutes": battery_interval,
                        "battery_low_voltage": battery_low_voltage,
                    }
                    tmp = cfg_path + ".tmp"
                    with open(tmp, "w") as f:
                        json.dump(cfg, f)
                    os.replace(tmp, cfg_path)

                if "enabled" in qs or "interval" in qs or "battery_enabled" in qs or "battery_interval" in qs or "battery_low_voltage" in qs:
                    self.send_response(303)
                    self.send_header("Location", "/cpu_temp_voice")
                    self.end_headers()
                    return

                data = json.dumps({"ok": True, **cfg}).encode()
                self.send_response(200)
                self.send_header("Content-Type","application/json")
                self.send_header("Cache-Control","no-store")
                self.send_header("Content-Length",str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            except Exception as e:
                data = json.dumps({"ok": False, "error": str(e)}).encode()
                self.send_response(500)
                self.send_header("Content-Type","application/json")
                self.send_header("Cache-Control","no-store")
                self.send_header("Content-Length",str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return

        if self.path.startswith("/status_bar"):
            out = sh("/usr/bin/python3 /home/pi/siyi-webui/status_probe.py")
            data = out.encode()
            self.send_response(200)
            self.send_header("Content-Type","text/html; charset=utf-8")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/set_arm_state"):

            try:
                qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                action = qs.get("action", [""])[0].strip().upper()
                out = groundstation_send_arm_state(action)
            except Exception as e:
                out = {
                    "ok": False,
                    "error": str(e)
                }

            data = json.dumps(out).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/set_flight_mode"):

            try:
                qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                mode = qs.get("mode", [""])[0].strip()

                # GROUND_STATION_FLIGHT_MODE_SELECTOR_V2_8_13_CANONICAL_MODES
                # The top-banner selector and button assignments use this same
                # canonical list, preventing their available modes from drifting.
                allowed = set(FLIGHT_SAFETY_ACTIONS)

                if mode not in allowed:
                    out = {
                        "ok": False,
                        "error": "invalid mode",
                        "mode": mode
                    }
                else:
                    blockers = read_pi_ui_mode_safety_blockers()

                    try:
                        st = flight_mode_state_read_once()
                        armed = bool(int(st.get("base_mode", 0) or 0) & 128)
                    except Exception:
                        armed = False

                    if armed and mode in blockers:
                        out = {
                            "ok": False,
                            "blocked": True,
                            "error": "Safety block: %s disabled while armed" % mode,
                            "mode": mode
                        }
                    else:
                        mode_map = {
                            "MANUAL": 0,
                            "FBWA": 5,
                            "CRUISE": 7,
                            "AUTOTUNE": 8,
                            "AUTO": 10,
                            "RTL": 11,
                            "LOITER": 12,
                            "TAKEOFF": 13,
                            "QHOVER": 18,
                            "QLOITER": 19,
                            "QLAND": 20,
                            "QRTL": 21,
                        }

                        mav = mavlink2.MAVLink(None)
                        pkt = mav.set_mode_encode(1, 1, mode_map[mode]).pack(mav)
                        ok = send_mavlink_tcp5760(pkt)

                        try:
                            tmp = FLIGHT_MODE_CACHE_FILE + ".tmp"
                            with open(tmp, "w", encoding="utf-8") as f:
                                json.dump({
                                    "mode": mode,
                                    "custom_mode": mode_map[mode],
                                    "base_mode": 81,
                                    "last_seen": time.time(),
                                    "source": "instant_webui_tx"
                                }, f)
                            os.replace(tmp, FLIGHT_MODE_CACHE_FILE)
                        except Exception as e:
                            print("[INSTANT_MODE_CACHE_FAIL]", repr(e), flush=True)

                        print("[WEBUI_MODE_TCP5760]", mode, "ok=" + str(ok), flush=True)

                        out = {
                            "ok": bool(ok),
                            "mode": mode,
                            "tx": "mavlink_tcp5760"
                        }

            except Exception as e:
                out = {
                    "ok": False,
                    "error": str(e)
                }

            data = json.dumps(out).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/flight_mode_state"):
            data = json.dumps(flight_mode_state_read_once()).encode()
            self.send_response(200)
            self.send_header("Content-Type","application/json")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/software_update_status"):
            payload = json.dumps(software_update_status_payload()).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if self.path.startswith("/health"):
            self.send_response(200)
            self.send_header("Content-type", "text/plain")
            self.end_headers()
            self.wfile.write(b"OK")
            return

        if self.path=="/first_setup":
            body=first_setup_page()

        elif self.path=="/":
            if setup_should_force():
                self.send_response(303)
                self.send_header("Location","/first_setup")
                self.end_headers()
                return

            body=f"""
            <h1>Operations</h1>

            <div class='card'>
              <h2>Operations</h2>
              <p class='small'>Use these controls to restart the main operational areas shown in the top status bar.</p>

              <table>
                <tr><th>System</th><th>Purpose</th><th>Action</th></tr>

                <tr>
                  <td><b>MAVLink</b></td>
                  <td class='small'>Telemetry routing to configured hosts.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='mavlink-router'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart MAVLink</button></form></td>
                </tr>

                <tr>
                  <td><b>Video</b></td>
                  <td class='small'>MediaMTX, selected source publisher and UDP forwarder.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='mediamtx'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart Video</button></form></td>
                </tr>

                

                <tr>
                  <td><b>ZT</b></td>
                  <td class='small'>ZeroTier overlay network.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='zerotier-one'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart ZT</button></form></td>
                </tr>

                <tr>
                  <td><b>Buttons</b></td>
                  <td class='small'>MAVLink button bridge.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='siyi-button-bridge'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart Buttons</button></form></td>
                </tr>

                <tr>
                  <td><b>WebUI</b></td>
                  <td class='small'>This control interface.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='siyi-webui'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart WebUI</button></form></td>
                </tr>
              </table>
            </div>
            """

        elif self.path.startswith("/param_trigger_full_sync"):
            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()
            out=sh("curl -fsS http://127.0.0.1:8765/trigger_full_sync 2>&1")
            try:
                j=json.loads(out.strip())
            except Exception:
                j={"ok":False,"error":out[-300:]}
            self.wfile.write(json.dumps(j).encode())
            return

        elif self.path.startswith("/param_sync_status"):
            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()
            out=sh("curl -fsS http://127.0.0.1:8765/sync_status 2>&1")
            try:
                j=json.loads(out.strip())
            except Exception:
                j={"ok":False,"error":out[-300:]}
            self.wfile.write(json.dumps(j).encode())
            return

        elif self.path.startswith("/param_state?"):
            from urllib.parse import urlparse, parse_qs
            q=parse_qs(urlparse(self.path).query)
            names=q.get("names",[""])[0].strip()

            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()

            if not names:
                self.wfile.write(b'{"ok":true,"params":{}}')
                return

            url="http://127.0.0.1:8765/state?names=" + urllib.parse.quote(names)
            out=sh("curl -fsS " + shlex.quote(url) + " 2>&1")

            try:
                j=json.loads(out.strip())
            except Exception:
                j={"ok":False,"error":out[-300:]}

            self.wfile.write(json.dumps(j).encode())
            return

        elif self.path.startswith("/param_live_read?"):

            from urllib.parse import urlparse, parse_qs

            q=parse_qs(urlparse(self.path).query)
            name=q.get("name",[""])[0].strip()

            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()

            if not name:
                self.wfile.write(b'{"ok":false,"error":"missing name"}')
                return

            url="http://127.0.0.1:8765/get?name=" + urllib.parse.quote(name)
            out=sh("curl -fsS " + shlex.quote(url) + " 2>&1")

            try:
                j=json.loads(out.strip())
            except Exception:
                j={"ok":False,"error":out[-300:]}

            self.wfile.write(json.dumps(j).encode())

        elif self.path.startswith("/param_metadata?"):
            query = parse_qs(urlparse(self.path).query)
            name = query.get("name", [""])[0]
            try:
                send_json_response(self, param_import_metadata_lookup(name), 200)
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 400)
            return

        elif self.path.startswith("/param_import_status"):
            try:
                result = param_import_daemon_request("/import/status")
                send_json_response(self, result, 200 if result.get("ok") else 400)
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 502)
            return

        elif self.path.startswith("/param_import_backup?"):
            query = parse_qs(urlparse(self.path).query)
            session_id = query.get("session_id", [""])[0]
            try:
                send_param_import_download(
                    self,
                    "/import/backup?session_id=" + urllib.parse.quote(session_id),
                )
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 400)
            return

        elif self.path.startswith("/param_import_report?"):
            query = parse_qs(urlparse(self.path).query)
            session_id = query.get("session_id", [""])[0]
            try:
                send_param_import_download(
                    self,
                    "/import/report?session_id=" + urllib.parse.quote(session_id),
                )
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 400)
            return

        elif self.path=="/param_sync_status":
            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()
            try:
                body=open("/etc/siyi/param_refresh_state.json").read()
            except Exception:
                body='{"running":false,"ok":true,"message":"Idle"}'
            self.wfile.write(body.encode())

        elif self.path.startswith("/fc_parameter_export"):
            return fc_parameter_export_handler(self)

        elif self.path=="/parameters":
            self.send_response(200)
            self.send_header("Content-type","text/html")
            self.end_headers()
            self.wfile.write(arduplane_parameters_page().encode())










        elif self.path.startswith("/gimbal_set_zero"):
            try:
                import time

                state_file="/home/pi/siyi_gimbal_state.json"

                with open(state_file,"r",encoding="utf-8") as f:
                    j=json.load(f)

                q=j.get("raw_q")
                if not q:
                    raise Exception("No raw_q in telemetry")

                out={
                    "q_ref": q,
                    "raw_yaw": j.get("raw_yaw",0),
                    "raw_pitch": j.get("raw_pitch",0),
                    "raw_roll": j.get("raw_roll",0),
                    "ts": time.time()
                }

                with open("/etc/siyi/gimbal_zero.json","w",encoding="utf-8") as f:
                    json.dump(out,f,indent=2)

                self.send_response(200)
                self.send_header("Content-Type","application/json")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "ok":True,
                    "yaw":j.get("yaw"),
                    "pitch":j.get("pitch")
                }).encode())
                return

            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type","application/json")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "ok":False,
                    "error":str(e)
                }).encode())
                return

        elif self.path.startswith("/gimbal_current"):
            try:
                if os.path.exists(GIMBAL_STATE_FILE):
                    with open(GIMBAL_STATE_FILE, encoding="utf-8") as f:
                        payload=f.read()
                else:
                    payload=json.dumps({"ok":False,"yaw":0,"pitch":0,"source":"no_state_yet"})
                self.send_response(200)
                self.send_header("Content-Type","application/json")
                self.end_headers()
                self.wfile.write(payload.encode())
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(json.dumps({"ok":False,"error":str(e)}).encode())


        elif self.path=="/software_update":
            body=software_update_page()

        elif self.path=="/flaps":
            body=flaps_page()

        elif self.path=="/buttons":
            body=buttons_workspace_page()

        elif self.path=="/video":
            body=video_source_page()

        elif self.path=="/mavlink":
            m=get_mav_values()
            body=f"""<h1>MAVLink Settings</h1>
            <div class='card'><h2>Telemetry Routing</h2><form method='post' action='/save_mavlink_form'><div class='grid'>
            <div><label>Serial device</label><input style='pointer-events:auto;' name='device' value='{esc(m["device"])}'></div>
            <div><label>Baud</label><input style='pointer-events:auto;' name='baud' value='{esc(m["baud"])}'></div>
            <div><label>UDP MAVLink port</label><input style='pointer-events:auto;' name='port' value='{esc(m["port"])}'></div>
            <div><label>TCP server port</label><input style='pointer-events:auto;' name='tcp' value='{esc(m["tcp"])}'></div>
            </div><button style='pointer-events:auto;'>Save MAVLink config + restart mavlink-router</button></form></div>
            <div class='card'><h2>MAVLink Destination Hosts</h2>{endpoints_summary("mavlink")}<a href='/endpoints'><button style='pointer-events:auto;'>Edit endpoints</button></a></div>"""

        elif self.path=="/endpoints":
            body=endpoints_page()

        elif self.path=="/wifi":
            msg=esc(sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true"))
            body=f"""<h1>WiFi</h1>
            <div class='card'>{wifi_profiles_cards()}</div>
            <div class='card'><h2>Add / Replace Saved Wi-Fi SSID</h2><p class='small'>Saves profile without forcing reconnect.</p>
            <form method='post' action='/wifi_add'><div class='grid'><div><label>SSID</label><input style='pointer-events:auto;' name='ssid'></div><div><label>Password</label><input id='wifi_add_password' style='pointer-events:auto;' name='password' type='password'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="this.closest('div').querySelector('input[name=password]').type=this.checked?'text':'password'"> Show password</label></div><div><label>Priority</label><input style='pointer-events:auto;' name='priority' value='10'></div><div><label>Autoconnect</label><select style='pointer-events:auto;' name='autoconnect'><option selected>yes</option><option>no</option></select></div></div><button style='pointer-events:auto;'>Save Wi-Fi profile only</button></form></div>"""

        elif self.path=="/zerotier":
            msg=esc(sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true"))
            body=f"""<h1>ZeroTier</h1>
            <div class='card'>
            {zt_status_html()}
            <form method='post' action='/zt_save_config'>
              <div class='grid'>
                <div><label>ZeroTier Network ID</label><input style='pointer-events:auto;' name='nwid' value='{esc(zt_network_id_current())}' placeholder='ZeroTier network ID'></div>
                <div><label>ZeroTier API Token</label><input id='zt_token_field' style='pointer-events:auto;' name='token' type='password' value='{esc(zt_read_token())}' placeholder='Paste token to save/update'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="document.getElementById('zt_token_field').type=this.checked?'text':'password'"> Show token</label></div>
              </div>
              <button style='pointer-events:auto;'>Save ZeroTier config</button>
            </form>
            <p class='small'>Saving ZeroTier config also runs setup: join network, authorize/name this Pi, and update camera managed route 192.168.144.0/24 via this Pi.</p>
            </div>"""

        elif self.path=="/network":
            msg=esc(sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true"))
            body=f"""<h1>Network</h1>
            <div class='card'>{wifi_profiles_cards()}</div>
            <div class='card'><h2>Add / Replace Saved Wi-Fi SSID</h2><p class='small'>Saves profile without forcing reconnect.</p>
            <form method='post' action='/wifi_add'><div class='grid'><div><label>SSID</label><input style='pointer-events:auto;' name='ssid'></div><div><label>Password</label><input id='wifi_add_password' style='pointer-events:auto;' name='password' type='password'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="this.closest('div').querySelector('input[name=password]').type=this.checked?'text':'password'"> Show password</label></div><div><label>Priority</label><input style='pointer-events:auto;' name='priority' value='10'></div><div><label>Autoconnect</label><select style='pointer-events:auto;' name='autoconnect'><option selected>yes</option><option>no</option></select></div></div><button style='pointer-events:auto;'>Save Wi-Fi profile only</button></form></div>
            <div class='card'><h2>ZeroTier</h2>
            {zt_status_html()}
            <form method='post' action='/zt_save_config'>
              <div class='grid'>
                <div><label>ZeroTier Network ID</label><input style='pointer-events:auto;' name='nwid' value='{esc(zt_network_id_current())}' placeholder='ZeroTier network ID'></div>
                <div><label>ZeroTier API Token</label><input id='zt_token_field' style='pointer-events:auto;' name='token' type='password' value='{esc(zt_read_token())}' placeholder='Paste token to save/update'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="document.getElementById('zt_token_field').type=this.checked?'text':'password'"> Show token</label></div>
              </div>
              <button style='pointer-events:auto;'>Save ZeroTier config</button>
            </form>
            <p class='small'>Saving ZeroTier config also runs setup: join network, authorize/name this Pi, and update camera managed route 192.168.144.0/24 via this Pi.</p>
            </div>"""

        elif self.path=="/camera_sd":
            body=camera_sd_page()

        elif self.path=="/logs":
            body="<h1>Logs</h1>"
            for s in SERVICES:
                body+=f"<div class='card'><h2>{s}</h2><pre>{esc(sh(f'journalctl -u {s} -n 80 --no-pager -l'))}</pre></div>"

        elif self.path=="/safety":
            body="<h1>Safety / Failsafe</h1><div class='card'><p>The Web UI edits configuration files and restarts services.</p><p>The button bridge remains the runtime executor.</p><p>ArduPlane / FC failsafe remains independent from this UI.</p><form method='post' action='/stop_bridge'><button style='pointer-events:auto;' class='danger'>Disable Button Bridge</button></form></div>"

        else:
            self.send_error(404); return

        if self.path != "/first_setup":
            if 'body' in locals():
                body = setup_banner() + body

        data=page("SIYI Pi Control Center",body).encode()
        self.send_response(200)
        self.send_header("Content-Type","text/html; charset=utf-8")
        self.send_header("Content-Length",str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        if software_update_lock_active():
            payload = json.dumps({
                "error": "Software upgrade in progress"
            }).encode("utf-8")
            self.send_response(423)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if self.path == "/unigcs_control":
            length = int(self.headers.get("Content-Length", "0"))
            data = self.rfile.read(length).decode(errors="ignore")
            q = dict(parse_qsl(data))

            cmd = ""

            if "cmd" in q:
                cmd = q.get("cmd", "")
            elif "brightness" in q:
                cmd = "brightness:" + q.get("brightness", "50")
            elif "saturation" in q:
                cmd = "saturation:" + q.get("saturation", "60")
            elif "contrast" in q:
                cmd = "contrast:" + q.get("contrast", "50")
            elif "ev" in q:
                cmd = "ev:" + q.get("ev", "0")
            elif "ss" in q:
                cmd = "ss:" + q.get("ss", "0")

            try:
                out = send_unigcs_fifo(cmd)
            except Exception as e:
                out = "UniGCS control failed: " + str(e)

            try:
                open("/tmp/siyi_webui_last_action", "w").write(out)
            except Exception:
                pass

            self.send_response(303)
            self.send_header("Location", "/camera_controls")
            self.end_headers()
            return

        if self.path in {
            "/param_import_preview",
            "/param_import_apply",
            "/param_import_cancel",
            "/param_import_rollback",
        }:
            try:
                length = int(self.headers.get("Content-Length", "0") or "0")
                if length > PARAM_IMPORT_MAX_REQUEST:
                    raise ValueError("Parameter import request is too large")
                raw = self.rfile.read(length)
                payload = json.loads(raw.decode("utf-8")) if raw else {}
                if not isinstance(payload, dict):
                    raise ValueError("JSON request must be an object")
                daemon_path = {
                    "/param_import_preview": "/import/preview",
                    "/param_import_apply": "/import/apply",
                    "/param_import_cancel": "/import/cancel",
                    "/param_import_rollback": "/import/rollback",
                }[self.path]
                result = param_import_daemon_request(
                    daemon_path,
                    method="POST",
                    payload=payload,
                    timeout=45 if self.path == "/param_import_preview" else 15,
                )
                if self.path == "/param_import_preview" and result.get("ok"):
                    result = param_import_attach_metadata(result)
                send_json_response(self, result, 200 if result.get("ok") else 400)
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 400)
            return

        length=int(self.headers.get("Content-Length",0))
        data=parse_qs(self.rfile.read(length).decode())


        if self.path=="/save_video_source":
            try:
                cfg = video_source_config_from_form(data)
                video_source_write_config(cfg)
                message = video_source_control("apply")
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(message)
            except Exception as exc:
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(
                    "Video source save failed: " + str(exc)
                )
            self.send_response(303)
            self.send_header("Location", "/video")
            self.end_headers()
            return

        if self.path=="/video_source_select":
            try:
                source = data.get("source", [""])[0]
                if source not in {"siyi_rtsp", "hdmi_usb", "wifilink_rtsp"}:
                    raise ValueError("Invalid video source")
                message = video_source_control("select", source)
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(message)
            except Exception as exc:
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(
                    "Video source switch failed: " + str(exc)
                )
            self.send_response(303)
            self.send_header("Location", "/video")
            self.end_headers()
            return

        if self.path=="/video_source_toggle":
            try:
                message = video_source_control("toggle")
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(message)
            except Exception as exc:
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(
                    "Video source toggle failed: " + str(exc)
                )
            self.send_response(303)
            self.send_header("Location", "/video")
            self.end_headers()
            return

        if self.path=="/software_update_start":
            try:
                current = get_release_version()
                latest = software_update_manifest()["stable"]
                preserve_groups = software_update_validate_preserve_groups(
                    data.get("preserve", [])
                )
                remember_selection = (
                    "1" if data.get("remember", ["0"])[0] == "1" else "0"
                )

                if software_update_running():
                    message = "Upgrade is already running."
                elif not software_update_is_newer(latest, current):
                    message = (
                        "Upgrade blocked: published version " + latest
                        + " is not newer than installed version " + current + "."
                    )
                else:
                    result = subprocess.run(
                        [
                            "sudo", "-n", SOFTWARE_UPDATE_LAUNCHER,
                            "--from", current,
                            "--target", latest,
                            "--preserve", ",".join(preserve_groups),
                            "--remember", remember_selection,
                        ],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                        timeout=15,
                        check=False,
                    )
                    if result.returncode != 0:
                        raise RuntimeError(
                            (result.stdout or "Upgrade launcher failed").strip()
                        )
                    message = (
                        "Upgrade started: " + current + " -> " + latest
                    )
                try:
                    with open("/tmp/siyi_webui_last_action", "w", encoding="utf-8") as f:
                        f.write(message)
                except Exception:
                    pass
            except Exception as exc:
                try:
                    with open(SOFTWARE_UPDATE_LOG_FILE, "a", encoding="utf-8") as f:
                        f.write("\nUpgrade start failed: " + str(exc) + "\n")
                except Exception:
                    pass

            self.send_response(303)
            self.send_header("Location", "/software_update")
            self.end_headers()
            return

        elif self.path=="/first_setup_skip":
            open(SETUP_SKIP_FILE,"w").write("skip\n")

        elif self.path=="/first_setup_save":

            nwid=data.get("nwid",[""])[0].strip()
            token=data.get("token",[""])[0].strip()

            if nwid:
                cfg=zt_read_config()
                cfg["network_id"]=nwid
                zt_save_config(cfg)

            if token:
                zt_save_token(token)

            save_endpoints_from_params(data)

            ssid=data.get("ssid",[""])[0].strip()
            password=data.get("password",[""])[0]

            if ssid:
                sh(f"nmcli connection add type wifi ifname wlan0 con-name webui-wifi-{ssid.replace(' ','_')} ssid {shlex.quote(ssid)} 2>/dev/null || true")
                con_name = "webui-wifi-" + ssid.replace(" ","_")
                sh(f"nmcli connection modify {shlex.quote(con_name)} wifi-sec.key-mgmt wpa-psk wifi-sec.psk {shlex.quote(password)} 2>/dev/null || true")
                wifi_pw_set(con_name, password)

            out=zt_full_setup()

            if setup_config_is_valid() and bool(zt_current_ip()):
                os.makedirs("/etc/siyi",exist_ok=True)
                open(SETUP_COMPLETE_FILE,"w").write(json.dumps({"complete":True},indent=2))
                if os.path.exists(SETUP_SKIP_FILE):
                    os.remove(SETUP_SKIP_FILE)

            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/restart":
            s=data.get("service",[""])[0]
            if s == "mavlink-router":
                sh("sudo -n systemctl stop mavlink-router")
                time.sleep(5)
                sh("sudo -n systemctl start mavlink-router")
                time.sleep(2)
                sh("sudo -n systemctl restart siyi-button-bridge")
            elif s == "zerotier-one":
                sh("sudo -n systemctl stop zerotier-one")
                time.sleep(5)
                sh("sudo -n systemctl start zerotier-one")
                time.sleep(3)

                sh("sudo -n systemctl stop mavlink-router")
                time.sleep(5)
                sh("sudo -n systemctl start mavlink-router")
                time.sleep(2)
                sh("sudo -n systemctl restart siyi-button-bridge")

            elif s == "siyi-webui":
                sh("systemd-run --unit=siyi-webui-delayed-restart --on-active=2 /bin/systemctl restart siyi-webui 2>/dev/null || true")
            elif s == "mediamtx":
                sh("sudo -n systemctl restart mediamtx")
                time.sleep(1)
                sh("sudo -n systemctl restart siyi-video-source")
                sh("sudo -n systemctl restart siyi-video-dual")
            elif s in SERVICES:
                sh(f"sudo -n systemctl restart {s}")

        elif self.path=="/param_write":
            name=data.get("name",[""])[0].strip()
            value=data.get("value",[""])[0].strip()

            if name and value:
                cmd=(
                    "curl -fsS -X POST "
                    "--data-urlencode " + shlex.quote("name=" + name) + " "
                    "--data-urlencode " + shlex.quote("value=" + value) + " "
                    "http://127.0.0.1:8765/set"
                )
                out=sh(cmd + " 2>&1")

                try:
                    j=json.loads(out.strip())
                    if j.get("ok"):
                        msg=f"OK {name} = {j.get('value')}"
                    else:
                        msg=f"FAILED {name}: {j.get('error')}"
                except Exception:
                    msg=f"FAILED {name}: {out[-300:]}"

                try:
                    open("/tmp/siyi_param_write_status.txt","w").write(msg)
                except Exception:
                    pass

            self.send_response(303)
            self.send_header("Location", "/parameters")
            self.end_headers()
            return

        elif self.path=="/params_refresh":

            sh("/home/pi/siyi_param_refresh_wrapper.sh >/tmp/siyi_param_refresh_wrapper.log 2>&1 &")
            self.send_response(303)
            self.send_header("Location", "/parameters")
            self.end_headers()
            return

        elif self.path=="/save_flaps":
            try:
                flaps_write_config({
                    "enabled": "enabled" in data,
                    "left_servo": data.get(
                        "left_servo", ["9"]
                    )[0],
                    "right_servo": data.get(
                        "right_servo", ["10"]
                    )[0],
                    "left_reverse": data.get(
                        "left_reverse", ["0"]
                    )[0] == "1",
                    "right_reverse": data.get(
                        "right_reverse", ["0"]
                    )[0] == "1",
                    "up_pwm": data.get(
                        "up_pwm", ["1000"]
                    )[0],
                    "takeoff_pwm": data.get(
                        "takeoff_pwm", ["1500"]
                    )[0],
                    "landing_pwm": data.get(
                        "landing_pwm", ["2000"]
                    )[0],
                })

                open(
                    "/tmp/siyi_webui_last_action",
                    "w",
                ).write(
                    "Flap configuration saved"
                )

                sh(
                    "sudo -n systemctl restart "
                    "siyi-button-bridge"
                )

            except Exception as e:
                open(
                    "/tmp/siyi_webui_last_action",
                    "w",
                ).write(
                    "Flap configuration save failed: "
                    + str(e)
                )

        elif self.path=="/save_button_safety":

            csv_vals=data.get("block_when_armed_csv", [""])[0]
            vals=[x.strip() for x in csv_vals.split(",") if x.strip()]

            current_safety=read_button_safety_config()

            if "unlock_airborne_safety" in data:
                block_disarm=("block_disarm_in_air" in data)
                block_toggle=("block_toggle_arm_disarm_in_air" in data)
            else:
                block_disarm=current_safety.get("block_disarm_in_air", True)
                block_toggle=current_safety.get("block_toggle_arm_disarm_in_air", True)

            write_button_safety_config(vals, block_disarm, block_toggle)

            sh("sudo -n systemctl restart siyi-button-bridge")
        elif self.path=="/save_gimbal_presets":
            try:
                raw=data.get("presets_json",["[]"])[0]
                presets=json.loads(raw)
                if not isinstance(presets,list):
                    presets=[]
                write_gimbal_presets(presets)
                sh("sudo -n systemctl restart siyi-button-bridge")
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"OK")
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(("ERR: %s"%e).encode())

        elif self.path=="/save_buttons":
            backup(BUTTON_MAP)
            count=int(data.get("count",["0"])[0])
            with open(BUTTON_MAP,"w",encoding="utf-8",newline="") as f:
                w=csv.writer(f,delimiter=";")
                w.writerow(["Button","Tap","Hold","ReleaseAfterTap","ReleaseAfterHold","DoubleTap","Notes"])
                for i in range(count):
                    w.writerow([data.get(f"Button_{i}",[""])[0],data.get(f"Tap_{i}",["NO_ACTION"])[0],data.get(f"Hold_{i}",["NO_ACTION"])[0],data.get(f"ReleaseAfterTap_{i}",["NO_ACTION"])[0],data.get(f"ReleaseAfterHold_{i}",["NO_ACTION"])[0],data.get(f"DoubleTap_{i}",["NO_ACTION"])[0],data.get(f"Notes_{i}",[""])[0]])
            sh("sudo -n systemctl restart siyi-button-bridge")

        elif self.path=="/save_endpoints":
            save_endpoints_from_params(data)

        elif self.path=="/save_video":
            try:
                cfg = video_source_read_config()
                cfg["siyi"]["url"] = data.get("rtsp", [cfg["siyi"]["url"]])[0]
                cfg["siyi"]["transport"] = data.get("protocols", ["tcp"])[0]
                cfg["siyi"]["latency_ms"] = video_source_int(data.get("latency", ["0"])[0], 0, 5000, "Latency")
                cfg["udp"]["port"] = video_source_int(data.get("port", ["5600"])[0], 1, 65535, "UDP port")
                video_source_write_config(cfg)
                video_source_control("apply")
            except Exception as exc:
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write("Video save failed: " + str(exc))

        elif self.path=="/save_mavlink_form":
            write_file(MAVCONF, make_mav_conf_from_endpoints(data.get("device",["/dev/ttyAMA0"])[0],data.get("baud",["57600"])[0],data.get("port",["14550"])[0],data.get("tcp",["5760"])[0]))
            sh("sudo -n systemctl restart mavlink-router")

        elif self.path=="/wifi_add":
            ssid=data.get("ssid",[""])[0].strip()
            pw=data.get("password",[""])[0]
            prio=data.get("priority",["10"])[0].strip() or "10"
            ac=data.get("autoconnect",["yes"])[0].strip()
            if ssid and pw:
                safe="webui-wifi-" + ssid.replace(" ","_")
                out=[]
                out.append(sh(f"sudo -n nmcli connection delete '{safe}' 2>/dev/null || true"))
                out.append(sh(f"sudo nmcli connection add type wifi ifname wlan0 con-name '{safe}' ssid '{ssid}'"))
                out.append(sh(f"sudo nmcli connection modify '{safe}' wifi-sec.key-mgmt wpa-psk wifi-sec.psk '{pw}'"))
                wifi_pw_set(safe, pw)
                out.append(sh(f"sudo nmcli connection modify '{safe}' connection.autoconnect {ac} connection.autoconnect-priority {prio}"))
                out.append("Saved Wi-Fi profile without forcing reconnect: " + safe)
                open("/tmp/siyi_webui_last_action","w").write("\\n".join([x for x in out if x]))

        elif self.path=="/wifi_update":
            name=data.get("name",[""])[0]
            prio=data.get("priority",["0"])[0]
            ac=data.get("autoconnect",["yes"])[0]
            if name and not name.startswith("netplan-"):
                sh(f"sudo -n nmcli connection modify '{name}' connection.autoconnect {ac}")
                sh(f"sudo -n nmcli connection modify '{name}' connection.autoconnect-priority {prio}")
                open("/tmp/siyi_webui_last_action","w").write(f"Updated {name}: priority={prio}, autoconnect={ac}")

        elif self.path=="/wifi_switch":
            name=data.get("name",[""])[0]
            if name:
                out=sh(f"sudo nmcli connection up '{name}'")
                open("/tmp/siyi_webui_last_action","w").write(out or f"Switched to {name}")
                sh("systemd-run --unit=siyi-webui-delayed-restart --on-active=3 /bin/systemctl restart siyi-webui 2>/dev/null || true")

        elif self.path=="/wifi_update_password":
            name=data.get("name",[""])[0]
            pw=data.get("password",[""])[0]
            if name and pw:
                out=sh(f"sudo -n nmcli connection modify '{name}' wifi-sec.psk '{pw}'")
                wifi_pw_set(name, pw)
                open("/tmp/siyi_webui_last_action","w").write(out or f"Updated Wi-Fi password for {name}")

        elif self.path=="/wifi_delete":
            name=data.get("name",[""])[0]
            if name and not name.startswith("netplan-"):
                out=sh(f"sudo -n nmcli connection delete '{name}'")
                wifi_pw_delete(name)
                open("/tmp/siyi_webui_last_action","w").write(out or f"Deleted {name}")



        elif self.path=="/camera_sd_zip":
            urls=data.get("urls",[])
            urls=[u for u in urls if u.startswith(CAM_SD_BASE + "/")]
            if urls:
                tmp=tempfile.NamedTemporaryFile(delete=False,suffix=".zip")
                tmp.close()
                try:
                    with zipfile.ZipFile(tmp.name,"w",compression=zipfile.ZIP_STORED) as z:
                        for url in urls:
                            name=os.path.basename(urllib.parse.urlparse(url).path) or "camera_file.mp4"
                            with urllib.request.urlopen(url, timeout=30) as r:
                                z.writestr(name, r.read())
                    with open(tmp.name,"rb") as f:
                        payload=f.read()
                    os.unlink(tmp.name)
                    self.send_response(200)
                    self.send_header("Content-Type","application/zip")
                    self.send_header("Content-Disposition",'attachment; filename="camera_sd_selected.zip"')
                    self.send_header("Content-Length",str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                    return
                except Exception as e:
                    try:
                        os.unlink(tmp.name)
                    except Exception:
                        pass
                    self.send_error(502, str(e))
                    return


        elif self.path=="/camera_sd_delete_selected":
            urls=data.get("urls",[])
            urls=[u for u in urls if u.startswith(CAM_SD_BASE + "/")]
            if urls:
                out=camera_sd_delete_many(urls)
                open("/tmp/siyi_webui_last_action","w").write("Camera SD batch delete: " + out)

        elif self.path=="/camera_sd_delete":
            url=data.get("url",[""])[0]
            if url.startswith(CAM_SD_BASE + "/"):
                out=camera_sd_delete(url)
                open("/tmp/siyi_webui_last_action","w").write("Camera SD delete: " + out)

        elif self.path=="/zt_save_config":
            nwid=data.get("nwid",[""])[0].strip()
            token=data.get("token",[""])[0].strip()
            cfg=zt_read_config()
            if nwid:
                cfg["network_id"]=nwid
                zt_write_config(cfg)
            if token:
                zt_save_token(token)

            saved_msg="Saved ZeroTier config. Network ID=" + (nwid or cfg.get("network_id",""))
            if token:
                saved_msg += " API token=saved"
            else:
                saved_msg += " API token=unchanged"

            setup_msg=zt_full_setup()
            open("/tmp/siyi_webui_last_action","w").write(saved_msg + "\n\n" + setup_msg)

        elif self.path=="/zt_test_token":
            out=zt_test_token()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_authorize_pi":
            out=zt_authorize_this_pi()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_update_route":
            out=zt_update_camera_route()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_full_setup":
            out=zt_full_setup()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_join":
            nwid=data.get("nwid",[""])[0].strip() or zt_network_id_current()
            if nwid:
                cfg=zt_read_config()
                cfg["network_id"]=nwid
                zt_write_config(cfg)
                out=sh(f"sudo zerotier-cli join {nwid}")
                open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/stop_bridge":
            sh("systemctl stop siyi-button-bridge")

        loc="/"
        if self.path.startswith("/save_video"): loc="/video"
        elif self.path.startswith("/save_mavlink"): loc="/mavlink"
        elif self.path.startswith("/save_endpoints"): loc="/endpoints"
        elif self.path.startswith("/save_buttons"): loc="/buttons"
        elif self.path.startswith("/save_flaps"): loc="/flaps"
        elif self.path.startswith("/wifi") or self.path.startswith("/zt"):
            loc="/wifi" if self.path.startswith("/wifi") else "/zerotier"

        elif self.path == "/unigcs_control":
            length = int(self.headers.get("Content-Length", "0"))
            data = self.rfile.read(length).decode(errors="ignore")
            q = dict(parse_qsl(data))

            cmd = ""

            if "cmd" in q:
                cmd = q.get("cmd", "")
            elif "brightness" in q:
                cmd = "brightness:" + q.get("brightness", "50")
            elif "saturation" in q:
                cmd = "saturation:" + q.get("saturation", "60")
            elif "contrast" in q:
                cmd = "contrast:" + q.get("contrast", "50")
            elif "ev" in q:
                cmd = "ev:" + q.get("ev", "0")
            elif "ss" in q:
                cmd = "ss:" + q.get("ss", "0")

            try:
                out = send_unigcs_fifo(cmd)
            except Exception as e:
                out = "UniGCS control failed: " + str(e)

            try:
                open("/tmp/siyi_webui_last_action", "w").write(out)
            except Exception:
                pass

            self.send_response(303)
            self.send_header("Location", "/camera_controls")
            self.end_headers()
            return

        self.send_response(303)
        self.send_header("Location",loc)
        self.end_headers()


# REAL_HTTP_LOGS_PAGE_FIX_START
def _real_logs_cmd(cmd, timeout=6):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT, timeout=timeout)
    except Exception as e:
        return str(e)

def _log_level(line):
    low = line.lower()
    if any(x in low for x in ["error", "failed", "failure", "traceback", "exception", "critical", "panic"]):
        return "ERROR"
    if any(x in low for x in ["warning", "warn", "denied", "timeout", "unreachable"]):
        return "WARN"
    return "INFO"

def _log_category(line):
    low = line.lower()
    if "mavlink-router" in low or "mavlink" in low or "/dev/ttyama0" in low:
        return "MAVLINK"
    if "siyi-video" in low or "gstreamer" in low or "rtsp" in low or "udp" in low or "video" in low:
        return "VIDEO"
    if "siyi-button" in low or "siyi-rec" in low or "unigcs" in low or "camera" in low:
        return "SIYI"
    if "zerotier" in low or "wlan" in low or "network" in low:
        return "NETWORK"
    if "siyi-webui" in low or "python3" in low or "webui" in low or "get /" in low:
        return "WEBUI"
    return "SYSTEM"

def _noise(line):
    low = line.lower()
    noise_words = [
        "pipewire", "wireplumber", "xdg-desktop", "rtkit", "bluez",
        "bcm2835", "vc_sm_cma", "alsa", "portal", "upower",
        "pam_unix(sudo:session): session opened",
        "pam_unix(sudo:session): session closed",
        "command=/usr/sbin/sudo zerotier-cli info",
        "get /status_bar", "get /health", "get /api/logs",
    ]
    return any(w in low for w in noise_words)

def _simplify(line):
    raw = line.strip()
    msg = raw

    # Remove noisy syslog prefix as much as possible
    m = re.match(r"^([A-Z][a-z]{2}\s+\d+\s+\d\d:\d\d:\d\d)\s+\S+\s+(.*)$", raw)
    ts = ""
    if m:
        ts = m.group(1)
        msg = m.group(2)

    msg = re.sub(r"^\S+\[\d+\]:\s*", "", msg)
    msg = msg.replace('"GET ', "GET ").replace(' HTTP/1.1" 200 -', "")

    low = msg.lower()

    if "opened uart" in low and "/dev/ttyama0" in low:
        msg = "FC serial opened: /dev/ttyAMA0"
    elif "uart" in low and "speed = 57600" in low:
        msg = "FC serial speed: 57600"
    elif "opened udp client" in low and ""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"" in low:
        msg = "MAVLink endpoint opened: Mac "+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+":14550"
    elif "opened udp client" in low and ""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"" in low:
        msg = "MAVLink endpoint opened: Android "+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+":14550"
    elif "started mavlink-router" in low:
        msg = "MAVLink Router started"
    elif "started siyi-webui" in low:
        msg = "Web UI service started"
    elif "get /logs" in low:
        msg = "Logs page opened"
    elif "get /camera_controls" in low:
        msg = "Camera Controls page opened"
    elif "get /safety" in low:
        msg = "Safety page opened"
    elif "permissions for /lib/netplan" in low:
        msg = "Netplan file permissions are too open"
    elif "registration to specific type not supported" in low:
        msg = "WiFi driver capability warning"
    elif "bgscan simple" in low:
        msg = "WiFi background scan warning"

    return ts, msg

def _real_logs_events(mode="important"):
    raw = _real_logs_cmd("journalctl --since '6 hours ago' --no-pager -n 1200")
    events = []

    for line in raw.splitlines():
        if not line.strip():
            continue
        if _noise(line):
            continue

        cat = _log_category(line)
        lvl = _log_level(line)
        ts, msg = _simplify(line)

        keep = False
        if mode == "full":
            keep = True
        elif mode == "important":
            keep = (
                lvl in ("ERROR", "WARN")
                or cat in ("MAVLINK", "VIDEO", "SIYI", "NETWORK")
                or "started" in msg.lower()
                or "opened" in msg.lower()
            )
        else:
            keep = (cat.lower() == mode.lower())

        if keep:
            events.append((ts, lvl, cat, msg))

    # Newest first. journalctl is chronological, so reverse after filtering.
    events = list(reversed(events))[:250]

    if not events:
        return "No important events found. This usually means the system is quiet/healthy."

    lines = []
    for ts, lvl, cat, msg in events:
        lines.append(f"{ts:<15}  {lvl:<5}  {cat:<8}  {msg}")
    return "\n".join(lines)

def _real_logs_text(mode="important"):
    return _real_logs_events(mode)

def _send_bytes(self, data, ctype="text/html; charset=utf-8"):
    if isinstance(data, str):
        data = data.encode("utf-8", "replace")
    self.send_response(200)
    self.send_header("Content-Type", ctype)
    self.send_header("Cache-Control", "no-store")
    self.send_header("Content-Length", str(len(data)))
    self.end_headers()
    self.wfile.write(data)

def _real_logs_page():
    return f"""<style>
.logbar{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;align-items:center}}
.logbtn{{background:#253244;color:#e8eef5;border:1px solid #3c4b5f;border-radius:8px;padding:8px 11px;cursor:pointer}}
.logbtn:hover{{background:#314158}}
.loghint{{opacity:.75;font-size:13px;margin-left:4px}}
#logs{{height:calc(100vh - 230px);min-height:420px;overflow-y:auto;padding:14px;white-space:pre-wrap;word-break:break-word;font-family:Menlo,Consolas,monospace;font-size:12px;line-height:1.4;background:#101418;color:#e8eef5;border-radius:12px;border:1px solid #2b3440}}
.err{{color:#ff9b9b;font-weight:bold}}
.warn{{color:#ffd28a;font-weight:bold}}
.info{{color:#a8ffbf;font-weight:bold}}
</style>

<h2>Logs <span style="font-size:13px;opacity:.65">v{VERSION}</span></h2>
<p style="opacity:.8;margin-top:-4px">Filtered diagnostic timeline. Newest first. Desktop/audio noise is hidden.</p>

<div class="logbar">
  <button class="logbtn" onclick="setMode('important')">Important</button>
  <button class="logbtn" onclick="setMode('mavlink')">MAVLink</button>
  <button class="logbtn" onclick="setMode('video')">Video</button>
  <button class="logbtn" onclick="setMode('siyi')">SIYI</button>
  <button class="logbtn" onclick="setMode('network')">Network</button>
  <button class="logbtn" onclick="setMode('webui')">Web UI</button>
  <button class="logbtn" onclick="setMode('system')">System</button>
  <button class="logbtn" onclick="setMode('full')">Full Filtered</button>
  <button class="logbtn" onclick="copyLogs()">Copy</button>
  <span class="loghint" id="status">Loading…</span>
</div>

<pre id="logs"></pre>

<script>
let mode='important';
let follow=true;

function colorize(t){{
  return t
    .replace(/(ERROR)/g,'<span class="err">$1</span>')
    .replace(/(WARN)/g,'<span class="warn">$1</span>')
    .replace(/(INFO)/g,'<span class="info">$1</span>');
}}

async function loadLogs(){{
  const box=document.getElementById('logs');
  const status=document.getElementById('status');
  try{{
    const r=await fetch('/api/logs?mode='+encodeURIComponent(mode)+'&t='+Date.now(), {{cache:'no-store'}});
    const t=await r.text();
    box.innerHTML=colorize(t);
    status.innerText='Mode: '+mode+' | Updated: '+new Date().toLocaleTimeString();
    if(follow) box.scrollTop=0;
  }}catch(e){{
    status.innerText='Failed to load logs';
  }}
}}

function setMode(m){{
  mode=m;
  loadLogs();
}}

function copyLogs(){{
  navigator.clipboard.writeText(document.getElementById('logs').innerText);
  document.getElementById('status').innerText='Copied diagnostics';
}}

loadLogs();
setInterval(loadLogs,5000);
</script>"""

_old_do_GET = H.do_GET
def _patched_do_GET(self):
    parsed = urlparse(self.path)
    path = parsed.path
    qs = dict(parse_qsl(parsed.query))

    if path == "/logs":
        return _send_bytes(self, page("Logs", _real_logs_page()), "text/html; charset=utf-8")

    if path == "/api/logs":
        mode = qs.get("mode", "important")
        return _send_bytes(self, _real_logs_text(mode), "text/plain; charset=utf-8")

    return _old_do_GET(self)

H.do_GET = _patched_do_GET
# REAL_HTTP_LOGS_PAGE_FIX_END


# WIFILINK2_SETTINGS_PAGE_V1_START
import base64 as _wl2_base64
import secrets as _wl2_secrets
import threading as _wl2_threading
import shlex as _wl2_shlex
from html.parser import HTMLParser as _Wl2HTMLParser

WIFILINK2_MAX_PROFILES = 20
WIFILINK2_STATUS_CACHE_SECONDS = 3.0
_wl2_status_cache = {"at": 0.0, "payload": {"online": False, "temperature_c": None, "error": "Not checked"}}
_wl2_status_lock = _wl2_threading.Lock()


def _wl2_credentials():
    cfg = video_source_read_config()
    item = cfg.get("wifilink") if isinstance(cfg, dict) else {}
    if not isinstance(item, dict):
        item = {}
    raw_url = str(item.get("url") or "rtsp://192.168.191.199:554/stream=0")
    parsed = urllib.parse.urlparse(raw_url)
    host = parsed.hostname or "192.168.191.199"
    username = str(item.get("username") or "root")
    password = str(item.get("password") or "")
    return host, username, password


def _wl2_http_request(path, method="GET", form=None, json_body=None, timeout=4.0, max_bytes=1048576):
    host, username, password = _wl2_credentials()
    url = "http://" + host + path
    headers = {"User-Agent": "SIYI-Pi-WiFiLink2/1", "Cache-Control": "no-cache"}
    token = _wl2_base64.b64encode((username + ":" + password).encode("utf-8")).decode("ascii")
    headers["Authorization"] = "Basic " + token
    body = None
    if form is not None:
        body = urllib.parse.urlencode(form).encode("utf-8")
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    elif json_body is not None:
        body = json.dumps(json_body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=body, headers=headers, method=method)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = response.read(max_bytes + 1)
        if len(payload) > max_bytes:
            raise ValueError("WiFiLink2 response was too large")
        return int(getattr(response, "status", 200) or 200), payload, dict(response.headers)


class _Wl2InputParser(_Wl2HTMLParser):
    """Small tolerant HTML form parser for old and new OpenIPC WebUI builds."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.fields = {}
        self.forms = []
        self._form = None
        self._select_name = ""
        self._select_value = ""
        self._select_first = ""

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        values = {str(k): ("" if v is None else str(v)) for k, v in attrs}

        if tag == "form":
            self._form = {
                "action": values.get("action", ""),
                "method": values.get("method", "GET").upper(),
                "fields": {},
            }
            self.forms.append(self._form)
            return

        if tag == "input":
            name = values.get("name", "")
            if not name:
                return
            input_type = values.get("type", "text").lower()
            if input_type in {"checkbox", "radio"} and "checked" not in values:
                return
            value = values.get("value", "on" if input_type in {"checkbox", "radio"} else "")
            self.fields[name] = value
            if self._form is not None:
                self._form["fields"][name] = value
            return

        if tag == "select":
            self._select_name = values.get("name", "")
            self._select_value = ""
            self._select_first = ""
            return

        if tag == "option" and self._select_name:
            value = values.get("value", "")
            if not self._select_first:
                self._select_first = value
            if "selected" in values:
                self._select_value = value

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag == "select" and self._select_name:
            value = self._select_value if self._select_value != "" else self._select_first
            self.fields[self._select_name] = value
            if self._form is not None:
                self._form["fields"][self._select_name] = value
            self._select_name = ""
            self._select_value = ""
            self._select_first = ""
        elif tag == "form":
            self._form = None


def _wl2_remote_command(command, timeout=10.0, max_bytes=262144):
    """Run a small command through the WiFiLink2 legacy authenticated CGI."""
    encoded = _wl2_base64.b64encode(str(command).encode("utf-8")).decode("ascii")
    # This legacy CGI reads QUERY_STRING with shell eval and does not URL-decode
    # the cmd value. Send the Base64 payload verbatim; percent-encoding breaks it.
    path = "/cgi-bin/j/run.cgi?cmd=" + encoded
    _status, raw, _headers = _wl2_http_request(
        path,
        timeout=timeout,
        max_bytes=max_bytes,
    )
    text = raw.decode("utf-8", errors="replace")
    if "No command!" in text:
        raise ValueError("WiFiLink2 command endpoint rejected the request")
    return text

def _wl2_network_form():
    """Discover the network form exposed by this exact OpenIPC WebUI build."""
    errors = []
    for endpoint in ("/cgi-bin/network.cgi", "/cgi-bin/fw-network.cgi"):
        try:
            _status, raw, _headers = _wl2_http_request(endpoint, timeout=5.0)
        except urllib.error.HTTPError as exc:
            errors.append(endpoint + ": HTTP " + str(exc.code))
            continue
        except Exception as exc:
            errors.append(endpoint + ": " + str(exc))
            continue

        parser = _Wl2InputParser()
        parser.feed(raw.decode("utf-8", errors="replace"))
        forms = parser.forms or [{"action": endpoint, "method": "POST", "fields": dict(parser.fields)}]
        selected = None
        for form in forms:
            names = [str(name).lower() for name in form.get("fields", {})]
            if any("ssid" in name or "wlan" in name or "wifi" in name for name in names):
                selected = form
                break
        if selected is None:
            selected = forms[0] if forms else {
                "action": endpoint,
                "method": "POST",
                "fields": dict(parser.fields),
            }

        fields = dict(selected.get("fields") or {})
        lower_to_actual = {str(name).lower(): str(name) for name in fields}

        def pick(exact, contains):
            for candidate in exact:
                actual = lower_to_actual.get(candidate.lower())
                if actual:
                    return actual
            for actual in fields:
                low = str(actual).lower()
                if all(token in low for token in contains):
                    return str(actual)
            return ""

        ssid_name = pick(
            ("network_wlan_ssid", "wlan_ssid", "wlanssid", "ssid"),
            ("ssid",),
        )
        password_name = pick(
            ("network_wlan_password", "wlan_password", "wlanpass", "password", "psk"),
            ("pass",),
        )
        hostname_name = pick(
            ("network_hostname", "hostname"),
            ("host", "name"),
        )

        action = str(selected.get("action") or endpoint)
        parsed_action = urllib.parse.urlparse(action)
        if parsed_action.scheme or parsed_action.netloc:
            action = parsed_action.path or endpoint
            if parsed_action.query:
                action += "?" + parsed_action.query
        elif not action.startswith("/"):
            action = "/cgi-bin/" + action.rsplit("/", 1)[-1]

        if not ssid_name:
            ssid_name = "network_wlan_ssid"
        if not password_name:
            password_name = "network_wlan_password"

        return {
            "endpoint": endpoint,
            "action": action,
            "method": str(selected.get("method") or "POST").upper(),
            "fields": fields,
            "ssid_name": ssid_name,
            "password_name": password_name,
            "hostname_name": hostname_name,
        }

    raise ValueError("WiFiLink2 network page was not found (" + "; ".join(errors) + ")")


def _wl2_device_network():
    """Read the WiFiLink2 WLAN configuration directly from firmware variables."""
    command = r'''ssid="$(fw_printenv -n wlanssid 2>/dev/null || true)"
password="$(fw_printenv -n wlanpass 2>/dev/null || true)"
hostname_value="$(hostname 2>/dev/null || echo wifilink2)"
active="$(iwgetid -r 2>/dev/null || true)"
if [ -z "$active" ]; then
  active="$(iwconfig wlan0 2>/dev/null | sed -n 's/.*ESSID:"\([^"]*\)".*/\1/p' | head -n1)"
fi
printf '__WL2_SSID_B64__'; printf '%s' "$ssid" | base64; echo
printf '__WL2_PASS_B64__'; printf '%s' "$password" | base64; echo
printf '__WL2_HOST_B64__'; printf '%s' "$hostname_value" | base64; echo
printf '__WL2_ACTIVE_B64__'; printf '%s' "$active" | base64; echo'''
    try:
        output = _wl2_remote_command(command, timeout=8.0)

        def decode_marker(marker):
            match = re.search(r"(?m)^" + re.escape(marker) + r"([^\r\n]*)$", output)
            if not match:
                return ""
            raw = match.group(1).strip()
            try:
                return _wl2_base64.b64decode(raw.encode("ascii"), validate=False).decode("utf-8", errors="replace")
            except Exception:
                return ""

        ssid = decode_marker("__WL2_SSID_B64__").strip()
        password = decode_marker("__WL2_PASS_B64__")
        hostname = decode_marker("__WL2_HOST_B64__").strip() or "wifilink2"
        active_ssid = decode_marker("__WL2_ACTIVE_B64__").strip()
        if not ssid and active_ssid:
            ssid = active_ssid
        if not ssid:
            raise ValueError("WiFiLink2 did not report a configured SSID")
        return {
            "online": True,
            "ssid": ssid,
            "active_ssid": active_ssid,
            "password": password,
            "hostname": hostname,
            "error": "",
        }
    except Exception as direct_error:
        try:
            form = _wl2_network_form()
            fields = form["fields"]
            ssid = str(fields.get(form["ssid_name"], "")).strip()
            password = str(fields.get(form["password_name"], ""))
            hostname = str(fields.get(form["hostname_name"], "")) if form["hostname_name"] else "wifilink2"
            if not ssid:
                raise ValueError("network page contained no SSID")
            return {
                "online": True,
                "ssid": ssid,
                "active_ssid": ssid,
                "password": password,
                "hostname": hostname or "wifilink2",
                "error": "",
                "form": form,
            }
        except Exception as fallback_error:
            error = "Direct read failed: " + str(direct_error) + "; network-page fallback failed: " + str(fallback_error)
    return {
        "online": False,
        "ssid": "",
        "active_ssid": "",
        "password": "",
        "hostname": "wifilink2",
        "error": error,
    }

def _wl2_profiles_default():
    return {"profiles": [], "active_id": "", "last_applied_ssid": ""}


def _wl2_profile_clean(profile):
    if not isinstance(profile, dict):
        return None
    profile_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(profile.get("id") or ""))[:40]
    ssid = str(profile.get("ssid") or "").strip()[:64]
    password = str(profile.get("password") or "")[:128]
    if not profile_id or not ssid:
        return None
    return {"id": profile_id, "ssid": ssid, "password": password}


def _wl2_profiles_read():
    data = _wl2_profiles_default()
    try:
        cfg = video_source_read_config()
        section = cfg.get("wifilink", {}) if isinstance(cfg, dict) else {}
        if not isinstance(section, dict):
            section = {}
        cleaned = []
        seen = set()
        for raw in section.get("saved_networks", []):
            item = _wl2_profile_clean(raw)
            if item and item["id"] not in seen and len(cleaned) < WIFILINK2_MAX_PROFILES:
                cleaned.append(item)
                seen.add(item["id"])
        data["profiles"] = cleaned
        data["active_id"] = str(section.get("active_network_id") or "")
        data["last_applied_ssid"] = str(section.get("last_applied_ssid") or "")[:64]
    except Exception:
        pass
    return data


def _wl2_profiles_write(data):
    clean = _wl2_profiles_default()
    clean["profiles"] = []
    seen = set()
    for raw in data.get("profiles", []):
        item = _wl2_profile_clean(raw)
        if item and item["id"] not in seen and len(clean["profiles"]) < WIFILINK2_MAX_PROFILES:
            clean["profiles"].append(item)
            seen.add(item["id"])
    clean["active_id"] = str(data.get("active_id") or "")
    clean["last_applied_ssid"] = str(data.get("last_applied_ssid") or "")[:64]
    cfg = video_source_read_config()
    section = cfg.get("wifilink")
    if not isinstance(section, dict):
        section = {}
        cfg["wifilink"] = section
    section["saved_networks"] = clean["profiles"]
    section["active_network_id"] = clean["active_id"]
    section["last_applied_ssid"] = clean["last_applied_ssid"]
    video_source_write_config(cfg)


def _wl2_profile_upsert(params):
    data = _wl2_profiles_read()
    profile_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(params.get("id", "")))[:40]
    ssid = str(params.get("ssid", "")).strip()
    password = str(params.get("password", ""))
    if not ssid:
        raise ValueError("SSID cannot be empty")
    if len(ssid) > 64:
        raise ValueError("SSID is too long")
    existing = None
    for item in data["profiles"]:
        if profile_id and item["id"] == profile_id:
            existing = item
            break
    if existing is None:
        if len(data["profiles"]) >= WIFILINK2_MAX_PROFILES:
            raise ValueError("Maximum number of saved networks reached")
        existing = {"id": _wl2_secrets.token_hex(8), "ssid": ssid, "password": ""}
        data["profiles"].append(existing)
    existing["ssid"] = ssid
    if password or not existing.get("password"):
        existing["password"] = password
    if not existing.get("password"):
        raise ValueError("A Wi-Fi password is required")
    _wl2_profiles_write(data)
    return data, existing


def _wl2_profile_delete(profile_id):
    data = _wl2_profiles_read()
    before = len(data["profiles"])
    data["profiles"] = [item for item in data["profiles"] if item["id"] != profile_id]
    if len(data["profiles"]) == before:
        raise ValueError("Saved network was not found")
    if data.get("active_id") == profile_id:
        data["active_id"] = ""
    _wl2_profiles_write(data)


def _wl2_ensure_device_profile(device):
    """Import/update the currently configured WiFiLink2 network in Pi storage."""
    ssid = str(device.get("ssid") or "").strip()
    if not ssid:
        return _wl2_profiles_read()
    password = str(device.get("password") or "")
    data = _wl2_profiles_read()
    match = None
    for item in data["profiles"]:
        if item["ssid"] == ssid:
            match = item
            break
    changed = False
    if match is None:
        match = {
            "id": _wl2_secrets.token_hex(8),
            "ssid": ssid,
            "password": password,
        }
        data["profiles"].append(match)
        changed = True
    elif password and match.get("password") != password:
        match["password"] = password
        changed = True
    if data.get("active_id") != match["id"]:
        data["active_id"] = match["id"]
        changed = True
    if data.get("last_applied_ssid") != ssid:
        data["last_applied_ssid"] = ssid
        changed = True
    if changed:
        _wl2_profiles_write(data)
    return data

def _wl2_apply_network(profile):
    device = _wl2_device_network()
    hostname = str(device.get("hostname") or "wifilink2")[:64]
    ssid_q = _wl2_shlex.quote(profile["ssid"])
    password_q = _wl2_shlex.quote(profile["password"])
    hostname_q = _wl2_shlex.quote(hostname)

    # The older OpenIPC WebUI used by this WiFiLink2 calls setnetiface.sh.
    # Keep a fallback for builds that expose the newer setnetwork helper.
    command = (
        "set -e; "
        "wlandev=\"$(fw_printenv -n wlandev 2>/dev/null || true)\"; "
        "if command -v setnetiface.sh >/dev/null 2>&1; then "
        "  setnetiface.sh -i wlan0 -m dhcp -h " + hostname_q
        + " -r \"$wlandev\" -s " + ssid_q + " -p " + password_q + "; "
        "elif command -v setnetwork >/dev/null 2>&1; then "
        "  setnetwork -i wlan0 -m dhcp -h " + hostname_q
        + " -s " + ssid_q + " -p " + password_q + "; "
        "else "
        "  echo __WL2_NO_NETWORK_HELPER__; exit 127; "
        "fi; "
        "echo __WL2_NETWORK_SENT__"
    )
    try:
        output = _wl2_remote_command(command, timeout=30.0)
        if "__WL2_NO_NETWORK_HELPER__" in output:
            raise ValueError("WiFiLink2 network helper was not found")
        if "__WL2_NETWORK_SENT__" not in output:
            raise ValueError("WiFiLink2 did not confirm the network command")
        detail = "WiFiLink2 accepted the network configuration."
    except (TimeoutError, ConnectionResetError, ConnectionAbortedError, urllib.error.URLError) as exc:
        detail = "The network change was sent. WiFiLink2 disconnected while applying it: " + str(exc)

    data = _wl2_profiles_read()
    data["active_id"] = profile["id"]
    data["last_applied_ssid"] = profile["ssid"]
    _wl2_profiles_write(data)
    return detail

def _wl2_scan_networks():
    command = r'''if command -v iwlist >/dev/null 2>&1; then
  iwlist wlan0 scan 2>&1
elif command -v iw >/dev/null 2>&1; then
  iw dev wlan0 scan 2>&1
else
  echo __WL2_NO_SCANNER__
fi'''
    output = _wl2_remote_command(command, timeout=20.0, max_bytes=524288)
    if "__WL2_NO_SCANNER__" in output:
        return {"networks": [], "error": "Wireless scanning is not available in this firmware."}

    results = {}
    current = {"ssid": "", "signal": -999, "security": "Open"}

    def flush():
        ssid = str(current.get("ssid") or "").strip()
        if not ssid:
            return
        existing = results.get(ssid)
        item = {
            "ssid": ssid[:64],
            "signal": int(current.get("signal", -999)),
            "security": str(current.get("security") or "Open")[:20],
        }
        if existing is None or item["signal"] > existing["signal"]:
            results[ssid] = item

    for raw_line in output.splitlines():
        line = raw_line.strip()
        if line.startswith("Cell " ) or line.startswith("BSS " ):
            flush()
            current = {"ssid": "", "signal": -999, "security": "Open"}
            continue
        match = re.search(r'ESSID:"(.*)"', line)
        if match:
            current["ssid"] = match.group(1)
            continue
        match = re.match(r"SSID:\s*(.*)$", line)
        if match:
            current["ssid"] = match.group(1).strip()
            continue
        match = re.search(r"Signal level[= :](-?[0-9]+)\s*dBm", line, re.I)
        if not match:
            match = re.search(r"signal:\s*(-?[0-9]+(?:\.[0-9]+)?)\s*dBm", line, re.I)
        if match:
            current["signal"] = int(float(match.group(1)))
        low = line.lower()
        if "wpa3" in low or "sae" in low:
            current["security"] = "WPA3"
        elif "wpa2" in low or "802.11i" in low or low.startswith("rsn:"):
            if current.get("security") != "WPA3":
                current["security"] = "WPA2"
        elif "wpa" in low:
            if current.get("security") == "Open":
                current["security"] = "WPA"
        elif "encryption key:on" in low and current.get("security") == "Open":
            current["security"] = "Encrypted"
    flush()

    networks = sorted(results.values(), key=lambda item: item["signal"], reverse=True)
    if not networks:
        message = "No networks were returned by the WiFiLink2 scanner."
        if "resource busy" in output.lower() or "device or resource busy" in output.lower():
            message = "WiFiLink2 could not scan while its wireless interface was busy. Enter the SSID manually."
        return {"networks": [], "error": message}
    return {"networks": networks[:100], "error": ""}

def _wl2_human_label(value):
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(value))
    text = text.replace("_", " ").replace("-", " ")
    return " ".join(part.capitalize() for part in text.split())


def _wl2_get_nested(data, path, default=None):
    current = data
    for part in path.split("."):
        if not isinstance(current, dict) or part not in current:
            return default
        current = current[part]
    return current



# WIFILINK2_SAFE_READONLY_V6

def _wl2_signal_percent(signal_dbm):
    "Convert dBm to an easy-to-read 0-100% Wi-Fi scale."
    try:
        value = float(signal_dbm)
    except (TypeError, ValueError):
        return None
    if value <= -100:
        return 0
    if value >= -50:
        return 100
    return int(round((value + 100.0) * 2.0))



# WIFILINK2_PASSWORD_MANAGEMENT_V7B
# WIFILINK2_PROFILE_ACTION_RESULT_V7D
# VIDEO_WIFI_UI_RESTRUCTURE_V8
WIFILINK2_PROFILE_MANAGER = "/usr/bin/siyi-wifi-profile-manager-v7b"

WIFILINK2_PROFILE_PAYLOAD_DIR = "/usr/local/share/siyi/wifilink2"
WIFILINK2_PROFILE_MANAGER_PAYLOAD = (
    WIFILINK2_PROFILE_PAYLOAD_DIR + "/siyi-wifi-profile-manager-v7b"
)
WIFILINK2_PROFILE_BOOT_HELPER_PAYLOAD = (
    WIFILINK2_PROFILE_PAYLOAD_DIR + "/S96siyi-wifi-profiles-v7b"
)


def _wl2_upload_payload_file(local_path, remote_b64_path):
    try:
        with open(local_path, "rb") as handle:
            payload = handle.read()
    except Exception as exc:
        raise ValueError(
            "WiFiLink2 manager payload is unavailable on the Pi: " + str(exc)
        )

    if not payload:
        raise ValueError("WiFiLink2 manager payload is empty on the Pi")

    encoded = _wl2_base64.b64encode(payload).decode("ascii")
    _wl2_remote_command(
        "rm -f " + _wl2_shlex.quote(remote_b64_path)
        + "; : > " + _wl2_shlex.quote(remote_b64_path),
        timeout=8.0,
        max_bytes=65536,
    )

    # The legacy CGI carries commands in the URL. Send modest chunks so the
    # manager payload works with conservative URL-length limits.
    for offset in range(0, len(encoded), 2048):
        chunk = encoded[offset:offset + 2048]
        _wl2_remote_command(
            "printf '%s' " + _wl2_shlex.quote(chunk)
            + " >> " + _wl2_shlex.quote(remote_b64_path),
            timeout=8.0,
            max_bytes=65536,
        )


def _wl2_install_profile_manager_payload():
    manager_tmp = "/tmp/siyi-wifi-profile-manager-v7b.b64"
    helper_tmp = "/tmp/S96siyi-wifi-profiles-v7b.b64"

    _wl2_upload_payload_file(
        WIFILINK2_PROFILE_MANAGER_PAYLOAD,
        manager_tmp,
    )
    _wl2_upload_payload_file(
        WIFILINK2_PROFILE_BOOT_HELPER_PAYLOAD,
        helper_tmp,
    )

    command = (
        "set -e; "
        "base64 -d " + _wl2_shlex.quote(manager_tmp)
        + " > /usr/bin/siyi-wifi-profile-manager-v7b; "
        "base64 -d " + _wl2_shlex.quote(helper_tmp)
        + " > /etc/init.d/S96siyi-wifi-profiles-v7b; "
        "chmod 0755 /usr/bin/siyi-wifi-profile-manager-v7b "
        "/etc/init.d/S96siyi-wifi-profiles-v7b; "
        "rm -f " + _wl2_shlex.quote(manager_tmp) + " "
        + _wl2_shlex.quote(helper_tmp) + "; "
        "/usr/bin/siyi-wifi-profile-manager-v7b sync "
        ">/tmp/siyi-wifi-profiles-v7b-bootstrap.log 2>&1 || true; "
        "/etc/init.d/S96siyi-wifi-profiles-v7b start "
        ">>/tmp/siyi-wifi-profiles-v7b-bootstrap.log 2>&1 || true; "
        "test -x /usr/bin/siyi-wifi-profile-manager-v7b; "
        "echo __WL2_MANAGER_BOOTSTRAP_OK__"
    )
    output = _wl2_remote_command(command, timeout=20.0, max_bytes=131072)
    if not re.search(
        r"(?m)^[ \t]*__WL2_MANAGER_BOOTSTRAP_OK__[ \t]*\r?$",
        output,
    ):
        raise ValueError("WiFiLink2 profile manager installation was not confirmed")




def _wl2_manager_command(action, args=(), timeout=12.0):
    safe_action = re.sub(r"[^a-z]", "", str(action).lower())
    if safe_action not in {"list", "upsert", "delete", "sync"}:
        raise ValueError("Unsupported WiFiLink2 profile action")
    quoted = " ".join(_wl2_shlex.quote(str(item)) for item in args)
    command = (
        "test -x " + _wl2_shlex.quote(WIFILINK2_PROFILE_MANAGER)
        + " || { echo __WL2_MANAGER_MISSING__; exit 127; }; "
        + _wl2_shlex.quote(WIFILINK2_PROFILE_MANAGER) + " " + safe_action
        + ((" " + quoted) if quoted else "")
    )
    output = _wl2_remote_command(command, timeout=timeout, max_bytes=262144)
    # The legacy run.cgi response can echo the submitted shell command.
    # Therefore the marker text may appear inside the echoed command even
    # when the manager exists and the requested action succeeds. Treat the
    # manager as missing only when the marker is returned as its own line.
    missing_pattern = r"(?m)^[ \t]*__WL2_MANAGER_MISSING__[ \t]*\r?$"
    if re.search(missing_pattern, output):
        _wl2_install_profile_manager_payload()
        output = _wl2_remote_command(command, timeout=timeout, max_bytes=262144)
        if re.search(missing_pattern, output):
            raise ValueError("WiFiLink2 profile manager is not installed")
    if "ERROR:" in output and not any(marker in output for marker in ("UPSERT_OK", "DELETE_OK", "SYNC_OK")):
        message = output.split("ERROR:", 1)[1].splitlines()[0].strip()
        raise ValueError(message or "WiFiLink2 profile manager rejected the change")
    return output


def _wl2_manager_profiles():
    output = _wl2_manager_command("list", timeout=8.0)
    profiles = {}
    current_ssid = ""
    wpa_state = ""
    for raw_line in output.splitlines():
        if raw_line.startswith("__WL2_CURRENT_B64__"):
            raw = raw_line[len("__WL2_CURRENT_B64__"):].strip()
            try:
                current_ssid = _wl2_base64.b64decode(raw.encode("ascii"), validate=False).decode("utf-8", errors="replace")
            except Exception:
                current_ssid = ""
        elif raw_line.startswith("__WL2_WPA_STATE__"):
            wpa_state = raw_line[len("__WL2_WPA_STATE__"):].strip()
        elif raw_line.startswith("__WL2_PROFILE__"):
            payload = raw_line[len("__WL2_PROFILE__"):]
            parts = payload.split("\t")
            if len(parts) != 5:
                continue
            raw_ssid, raw_password, raw_priority, raw_enabled, security = parts
            try:
                ssid = _wl2_base64.b64decode(raw_ssid.encode("ascii"), validate=False).decode("utf-8", errors="replace")
                password = _wl2_base64.b64decode(raw_password.encode("ascii"), validate=False).decode("utf-8", errors="replace") if raw_password else ""
                priority = int(raw_priority)
                enabled = raw_enabled == "1"
            except Exception:
                continue
            profiles[ssid] = {
                "ssid": ssid,
                "password": password,
                "password_known": security in {"wpa", "open"},
                "security": security if security in {"wpa", "open", "unknown"} else "unknown",
                "priority": max(0, min(999, priority)),
                "enabled": enabled,
                "managed": True,
            }
    return {"profiles": profiles, "current_ssid": current_ssid, "wpa_state": wpa_state}


def _wl2_b64_arg(value):
    return _wl2_base64.b64encode(str(value).encode("utf-8")).decode("ascii")


def _wl2_native_network_save(params):
    old_ssid = str(params.get("old_ssid") or "").strip()
    ssid = str(params.get("ssid") or "").strip()
    password = str(params.get("password") or "")
    if not ssid:
        raise ValueError("SSID cannot be empty")
    if len(ssid.encode("utf-8")) > 32:
        raise ValueError("SSID is longer than 32 bytes")
    try:
        priority = int(str(params.get("priority") or "50"))
    except ValueError:
        raise ValueError("Priority must be a number")
    if priority < 0 or priority > 999:
        raise ValueError("Priority must be between 0 and 999")
    enabled = "1" if str(params.get("enabled") or "") in {"1", "true", "on", "yes"} else "0"
    open_network = str(params.get("open_network") or "") in {"1", "true", "on", "yes"}
    current_security = str(params.get("current_security") or "unknown")
    if open_network:
        security = "open"
        password = ""
    elif password:
        security = "wpa"
        length = len(password)
        if not (8 <= length <= 63 or (length == 64 and re.fullmatch(r"[0-9A-Fa-f]{64}", password))):
            raise ValueError("WPA password must be 8-63 characters or 64 hexadecimal characters")
    elif old_ssid and current_security in {"wpa", "unknown"}:
        security = "keep"
    else:
        raise ValueError("Enter a Wi-Fi password or select Open network")

    output = _wl2_manager_command(
        "upsert",
        (
            _wl2_b64_arg(old_ssid),
            _wl2_b64_arg(ssid),
            _wl2_b64_arg(password),
            str(priority),
            enabled,
            security,
        ),
        timeout=15.0,
    )
    if "UPSERT_OK" not in output:
        raise ValueError("WiFiLink2 did not confirm the saved profile")
    return "Saved WiFiLink2 profile: " + ssid


def _wl2_native_network_delete(params):
    ssid = str(params.get("ssid") or "").strip()
    if not ssid:
        raise ValueError("SSID cannot be empty")
    output = _wl2_manager_command("delete", (_wl2_b64_arg(ssid),), timeout=12.0)
    if "DELETE_OK" not in output:
        raise ValueError("WiFiLink2 did not confirm the deleted profile")
    return "Deleted WiFiLink2 profile: " + ssid

def _wl2_native_wifi_inventory():
    "Read all profiles currently loaded by WiFiLink2, without changing WLAN."
    command = r'''wpa_cli_bin="$(command -v wpa_cli 2>/dev/null || echo /usr/sbin/wpa_cli)"
active="$($wpa_cli_bin -i wlan0 status 2>/dev/null | sed -n 's/^ssid=//p' | head -n1)"
signal="$(iwconfig wlan0 2>/dev/null | sed -n 's/.*Signal level=\(-\{0,1\}[0-9][0-9]*\) dBm.*/\1/p' | head -n1)"
quality="$(iwconfig wlan0 2>/dev/null | sed -n 's/.*Link Quality=\([0-9][0-9]*\/[0-9][0-9]*\).*/\1/p' | head -n1)"
printf '__WL2_ACTIVE_B64__'; printf '%s' "$active" | base64; echo
printf '__WL2_SIGNAL_DBM__%s\n' "$signal"
printf '__WL2_QUALITY__%s\n' "$quality"
echo '__WL2_LIST_BEGIN__'
$wpa_cli_bin -i wlan0 list_networks 2>/dev/null || true
echo '__WL2_LIST_END__'
echo '__WL2_SCAN_BEGIN__'
$wpa_cli_bin -i wlan0 scan_results 2>/dev/null || true
echo '__WL2_SCAN_END__' '''
    output = _wl2_remote_command(command, timeout=8.0, max_bytes=262144)

    def marker_value(name):
        match = re.search(r"(?m)^" + re.escape(name) + r"([^\r\n]*)$", output)
        return match.group(1).strip() if match else ""

    active_ssid = ""
    raw_active = marker_value("__WL2_ACTIVE_B64__")
    if raw_active:
        try:
            active_ssid = _wl2_base64.b64decode(raw_active.encode("ascii"), validate=False).decode("utf-8", errors="replace").strip()
        except Exception:
            active_ssid = ""

    signal_dbm = None
    raw_signal = marker_value("__WL2_SIGNAL_DBM__")
    try:
        signal_dbm = int(float(raw_signal)) if raw_signal else None
    except (TypeError, ValueError):
        signal_dbm = None

    quality_text = marker_value("__WL2_QUALITY__")

    list_match = re.search(r"(?s)__WL2_LIST_BEGIN__\s*(.*?)\s*__WL2_LIST_END__", output)
    list_text = list_match.group(1) if list_match else ""
    scan_match = re.search(r"(?s)__WL2_SCAN_BEGIN__\s*(.*?)\s*__WL2_SCAN_END__", output)
    scan_text = scan_match.group(1) if scan_match else ""

    visible = {}
    for raw_line in scan_text.splitlines():
        line = raw_line.strip("\r\n")
        if not line or line.lower().startswith("bssid"):
            continue
        parts = line.split("\t", 4)
        if len(parts) < 5:
            continue
        _bssid, _frequency, raw_dbm, flags, ssid = parts
        ssid = ssid.strip()
        if not ssid:
            continue
        try:
            dbm = int(float(raw_dbm.strip()))
        except (TypeError, ValueError):
            continue
        previous = visible.get(ssid)
        if previous is None or dbm > previous["signal_dbm"]:
            visible[ssid] = {
                "signal_dbm": dbm,
                "signal_percent": _wl2_signal_percent(dbm),
                "scan_flags": flags.strip(),
            }

    profiles = []
    seen = set()
    for raw_line in list_text.splitlines():
        line = raw_line.strip("\r\n")
        if not line or line.lower().startswith("network id"):
            continue
        parts = line.split("\t")
        if len(parts) < 2:
            continue
        network_id = parts[0].strip()
        ssid = parts[1].strip()
        bssid = parts[2].strip() if len(parts) >= 3 else "any"
        flags = parts[3].strip() if len(parts) >= 4 else ""
        if not ssid or ssid in seen:
            continue
        seen.add(ssid)
        current = "[CURRENT]" in flags or (active_ssid and ssid == active_ssid)
        disabled = "[DISABLED]" in flags
        scan_item = visible.get(ssid, {})
        item_signal = signal_dbm if current and signal_dbm is not None else scan_item.get("signal_dbm")
        profiles.append({
            "id": network_id,
            "ssid": ssid,
            "bssid": bssid,
            "flags": flags,
            "current": current,
            "disabled": disabled,
            "visible": current or ssid in visible,
            "signal_dbm": item_signal,
            "signal_percent": _wl2_signal_percent(item_signal),
        })

    if active_ssid and active_ssid not in seen:
        profiles.insert(0, {
            "id": "",
            "ssid": active_ssid,
            "bssid": "any",
            "flags": "[CURRENT]",
            "current": True,
            "disabled": False,
            "visible": True,
            "signal_dbm": signal_dbm,
            "signal_percent": _wl2_signal_percent(signal_dbm),
        })

    try:
        manager = _wl2_manager_profiles()
        stored_profiles = manager.get("profiles", {})
    except Exception:
        manager = {"profiles": {}, "current_ssid": "", "wpa_state": ""}
        stored_profiles = {}

    by_ssid = {item.get("ssid", ""): item for item in profiles}
    for ssid, stored in stored_profiles.items():
        item = by_ssid.get(ssid)
        if item is None:
            item = {
                "id": "",
                "ssid": ssid,
                "bssid": "any",
                "flags": "",
                "current": active_ssid == ssid,
                "disabled": not bool(stored.get("enabled", True)),
                "visible": ssid in visible or active_ssid == ssid,
                "signal_dbm": visible.get(ssid, {}).get("signal_dbm"),
                "signal_percent": visible.get(ssid, {}).get("signal_percent"),
            }
            profiles.append(item)
            by_ssid[ssid] = item
        item.update({
            "password": str(stored.get("password") or ""),
            "password_known": bool(stored.get("password_known")),
            "security": str(stored.get("security") or "unknown"),
            "priority": int(stored.get("priority", 50)),
            "enabled": bool(stored.get("enabled", True)),
            "managed": True,
        })
        item["disabled"] = not item["enabled"]

    for item in profiles:
        item.setdefault("password", "")
        item.setdefault("password_known", False)
        item.setdefault("security", "unknown")
        item.setdefault("priority", 50)
        item.setdefault("enabled", not item.get("disabled", False))
        item.setdefault("managed", False)

    profiles.sort(key=lambda item: (
        0 if item.get("current") else 1,
        0 if item.get("visible") else 1,
        -(item.get("signal_percent") if isinstance(item.get("signal_percent"), int) else -1),
        item.get("ssid", "").lower(),
    ))

    nearby_networks = []
    for ssid, visible_item in visible.items():
        nearby_networks.append({
            "ssid": ssid,
            "signal_dbm": visible_item.get("signal_dbm"),
            "signal_percent": visible_item.get("signal_percent"),
            "scan_flags": visible_item.get("scan_flags", ""),
            "configured": ssid in by_ssid,
        })
    nearby_networks.sort(key=lambda item: (
        0 if item.get("configured") else 1,
        -(item.get("signal_dbm") if isinstance(item.get("signal_dbm"), int) else -999),
        item.get("ssid", "").lower(),
    ))

    return {
        "profiles": profiles,
        "nearby_networks": nearby_networks,
        "active_ssid": active_ssid,
        "signal_dbm": signal_dbm,
        "signal_percent": _wl2_signal_percent(signal_dbm),
        "quality": quality_text,
        "manager_available": bool(stored_profiles),
        "error": "",
    }


def _wl2_camera_active_values(paths):
    "Read active Majestic values through yaml-cli's native config path."
    quoted_paths = " ".join(_wl2_shlex.quote("." + str(path).lstrip(".")) for path in paths)
    command = (
        "for setting in " + quoted_paths + "; do "
        "value=\"$(yaml-cli -g \"$setting\" 2>/dev/null || true)\"; "
        "printf '__WL2_CAMERA_VALUE__%s\\t' \"$setting\"; "
        "printf '%s' \"$value\" | base64; echo; "
        "done"
    )
    output = _wl2_remote_command(command, timeout=8.0, max_bytes=131072)
    values = {}
    for raw_line in output.splitlines():
        if not raw_line.startswith("__WL2_CAMERA_VALUE__"):
            continue
        payload = raw_line[len("__WL2_CAMERA_VALUE__"):]
        if "\t" not in payload:
            continue
        raw_path, raw_value = payload.split("\t", 1)
        path = raw_path.strip().lstrip(".")
        try:
            value = _wl2_base64.b64decode(raw_value.strip().encode("ascii"), validate=False).decode("utf-8", errors="replace")
        except Exception:
            continue
        values[path] = value.strip()
    return values

def _wl2_camera_controls():
    _s1, raw_schema, _h1 = _wl2_http_request("/api/v1/config.schema.json", timeout=5.0)
    _s2, raw_config, _h2 = _wl2_http_request("/api/v1/config.json", timeout=5.0)
    schema = json.loads(raw_schema.decode("utf-8"))
    config = json.loads(raw_config.decode("utf-8"))
    if not isinstance(schema, dict) or not isinstance(config, dict):
        raise ValueError("Invalid Majestic configuration response")

    safe_paths = (
        "isp.antiFlicker",
        "image.contrast",
        "image.hue",
        "image.saturation",
        "image.luminance",
        "image.mirror",
        "image.flip",
        "image.rotate",
    )
    active_values = _wl2_camera_active_values(safe_paths)

    root = schema.get("properties", {})
    if not isinstance(root, dict):
        root = {}
    controls = []
    for path in safe_paths:
        section, key = path.split(".", 1)
        section_schema = root.get(section, {})
        props = section_schema.get("properties", {}) if isinstance(section_schema, dict) else {}
        spec = props.get(key, {}) if isinstance(props, dict) else {}
        if not isinstance(spec, dict):
            spec = {}

        api_section = config.get(section)
        api_value = api_section.get(key) if isinstance(api_section, dict) and key in api_section else None
        raw_active = active_values.get(path)
        if raw_active is None or raw_active == "":
            if api_value is None:
                continue
            value = api_value
        else:
            value_type = str(spec.get("type") or "string")
            if value_type == "boolean":
                value = str(raw_active).strip().lower() in {"1", "true", "yes", "on"}
            elif value_type == "integer":
                try:
                    value = int(float(str(raw_active).strip()))
                except (TypeError, ValueError):
                    value = api_value
            elif value_type == "number":
                try:
                    value = float(str(raw_active).strip())
                except (TypeError, ValueError):
                    value = api_value
            else:
                value = str(raw_active)

        value_type = str(spec.get("type") or ("boolean" if isinstance(value, bool) else "integer" if isinstance(value, int) else "number" if isinstance(value, float) else "string"))
        controls.append({
            "path": path,
            "section": section,
            "key": key,
            "label": str(spec.get("title") or _wl2_human_label(key))[:80],
            "description": str(spec.get("description") or "")[:240],
            "type": value_type,
            "value": value,
            "enum": (spec.get("enum") if isinstance(spec.get("enum"), list) else [])[:100],
            "minimum": spec.get("minimum"),
            "maximum": spec.get("maximum"),
            "default": spec.get("default"),
        })
    return controls

def _wl2_camera_apply(params):
    controls = _wl2_camera_controls()
    allowed = {item["path"]: item for item in controls}
    changed_values = {}

    def normalized(value, spec):
        if spec["type"] == "boolean":
            return "true" if str(value).lower() in {"1", "true", "yes", "on"} else "false"
        if spec["type"] == "integer":
            return str(int(value))
        if spec["type"] == "number":
            number = float(value)
            return str(int(number)) if number.is_integer() else str(number)
        return str(value)

    for key, raw_value in params.items():
        if not key.startswith("camera."):
            continue
        dotted = key[len("camera."):]
        spec = allowed.get(dotted)
        if not spec:
            continue
        value = str(raw_value)
        if spec["type"] in {"integer", "number"}:
            if value.strip() == "":
                continue
            number = float(value) if spec["type"] == "number" else int(value)
            minimum = spec.get("minimum")
            maximum = spec.get("maximum")
            if minimum is not None and number < float(minimum):
                raise ValueError(spec["label"] + " is below the supported minimum")
            if maximum is not None and number > float(maximum):
                raise ValueError(spec["label"] + " is above the supported maximum")
        elif spec.get("enum") and value not in {str(item) for item in spec["enum"]}:
            raise ValueError("Invalid value for " + spec["label"])
        value = normalized(value, spec)
        current = normalized(spec.get("value", ""), spec)
        if value != current:
            changed_values[dotted] = value

    if not changed_values:
        return "No values changed"

    commands = [
        "set -e",
        "tmp=/tmp/siyi-majestic-$$.yaml",
        "cp -f /etc/majestic.yaml \"$tmp\"",
        "trap 'rm -f \"$tmp\"' EXIT",
    ]
    for dotted, value in changed_values.items():
        commands.append(
            "yaml-cli -s " + _wl2_shlex.quote("." + dotted) + " " + _wl2_shlex.quote(value)
            + " -i \"$tmp\" -o \"$tmp\""
        )
    commands.extend([
        "cp -f \"$tmp\" /etc/majestic.yaml",
        "killall -1 majestic",
        "echo __WL2_CAMERA_APPLIED__",
    ])
    output = _wl2_remote_command("; ".join(commands), timeout=20.0)
    if "__WL2_CAMERA_APPLIED__" not in output:
        raise ValueError("WiFiLink2 did not confirm the camera update")
    return "Applied " + str(len(changed_values)) + " camera setting(s)"

def _wl2_temperature_status(force=False):
    now = time.monotonic()
    with _wl2_status_lock:
        if not force and now - float(_wl2_status_cache.get("at", 0.0)) < WIFILINK2_STATUS_CACHE_SECONDS:
            return dict(_wl2_status_cache["payload"])

    try:
        _status, raw, _headers = _wl2_http_request(
            "/metrics/isp",
            timeout=3.0,
            max_bytes=131072,
        )
        metrics = raw.decode("utf-8", errors="replace")
        match = re.search(
            r"(?m)^node_hwmon_temp_celsius(?:\{[^}]*\})?\s+(-?[0-9]+(?:[.,][0-9]+)?)\s*$",
            metrics,
        )
        temperature = float(match.group(1).replace(",", ".")) if match else None
        error = "" if temperature is not None else "Temperature metric was not present"
        payload = {
            "online": True,
            "temperature_c": temperature,
            "error": error,
            "updated": int(time.time()),
        }
    except urllib.error.HTTPError as exc:
        error = "Authentication failed" if exc.code in {401, 403} else "HTTP " + str(exc.code)
        payload = {
            "online": False,
            "temperature_c": None,
            "error": error,
            "updated": int(time.time()),
        }
    except Exception as exc:
        payload = {
            "online": False,
            "temperature_c": None,
            "error": str(exc),
            "updated": int(time.time()),
        }

    with _wl2_status_lock:
        _wl2_status_cache["at"] = now
        _wl2_status_cache["payload"] = dict(payload)
    return payload


def _wl2_camera_field_html(control):
    path = control["path"]
    label = esc(control["label"])
    description = esc(control.get("description") or "")
    value = control.get("value")
    field_name = "camera." + path
    input_html = ""
    enum = control.get("enum") or []
    if enum:
        options = []
        for item in enum:
            selected = " selected" if str(item) == str(value) else ""
            options.append("<option value='" + esc(item) + "'" + selected + ">" + esc(item) + "</option>")
        input_html = "<select style='pointer-events:auto;' name='" + esc(field_name) + "'>" + "".join(options) + "</select>"
    elif control["type"] == "boolean":
        current = str(value).lower() in {"1", "true", "yes", "on"}
        input_html = (
            "<select style='pointer-events:auto;' name='" + esc(field_name) + "'>"
            + "<option value='true'" + (" selected" if current else "") + ">On</option>"
            + "<option value='false'" + ("" if current else " selected") + ">Off</option></select>"
        )
    elif control["type"] in {"integer", "number"}:
        attrs = ""
        if control.get("minimum") is not None:
            attrs += " min='" + esc(control["minimum"]) + "'"
        if control.get("maximum") is not None:
            attrs += " max='" + esc(control["maximum"]) + "'"
        step = "any" if control["type"] == "number" else "1"
        input_html = "<input style='pointer-events:auto;' type='number' step='" + step + "' name='" + esc(field_name) + "' value='" + esc(value) + "'" + attrs + ">"
    else:
        input_html = "<input style='pointer-events:auto;' name='" + esc(field_name) + "' value='" + esc(value) + "'>"
    help_text = ("<div class='small' style='margin-top:5px'>" + description + "</div>") if description else ""
    return "<div><label>" + label + "</label>" + input_html + help_text + "</div>"


def _wl2_last_action():
    try:
        text = open("/tmp/siyi_wifilink2_last_action", encoding="utf-8", errors="replace").read().strip()
        if text.lower().startswith("wifilink2") or "wifilink2" in text.lower():
            return text[:1000]
    except Exception:
        pass
    return ""


def _wl2_signal_bars(percent):
    if not isinstance(percent, int):
        return "▯▯▯▯▯"
    filled = max(0, min(5, int(round(percent / 20.0))))
    return "▮" * filled + "▯" * (5 - filled)


def _wl2_password_toggle(input_id, checkbox_id):
    return (
        "<label class='small' style='display:flex;gap:7px;align-items:center;margin-top:7px'>"
        "<input id='" + esc(checkbox_id) + "' style='width:auto;pointer-events:auto' type='checkbox' "
        "onclick=\"document.getElementById('" + esc(input_id) + "').type=this.checked?'text':'password'\">"
        "Show password</label>"
    )



def _wl2_native_profile_card(item, index):
    ssid = str(item.get("ssid") or "(unknown)")
    current = bool(item.get("current"))
    visible = bool(item.get("visible"))
    enabled = bool(item.get("enabled", not item.get("disabled", False)))
    percent = item.get("signal_percent")
    dbm = item.get("signal_dbm")
    password = str(item.get("password") or "")
    password_known = bool(item.get("password_known"))
    security = str(item.get("security") or "unknown")
    priority = int(item.get("priority", 50))

    if current:
        label = "Connected"
        badge_class = "active"
    elif not enabled:
        label = "Disabled"
        badge_class = "bad"
    elif visible:
        label = "Available"
        badge_class = "warn"
    else:
        label = "Out of range"
        badge_class = "inactive"

    if isinstance(percent, int) and isinstance(dbm, (int, float)):
        signal_text = _wl2_signal_bars(percent) + " " + str(percent) + "% · " + str(int(dbm)) + " dBm"
    elif isinstance(dbm, (int, float)):
        signal_text = str(int(dbm)) + " dBm"
    else:
        signal_text = "Not detected in the latest scan"

    input_id = "wl2-pass-" + str(index)
    checkbox_id = "wl2-show-pass-" + str(index)
    editor_id = "wl2-profile-editor-" + str(index)
    ssid_attr = " readonly" if current else ""
    password_placeholder = "Password unavailable — enter one to manage it" if not password_known else ""
    enabled_control = (
        "<input type='hidden' name='enabled' value='1'><span class='small'>Connected profile stays enabled</span>"
        if current else
        "<label style='display:flex;gap:7px;align-items:center'><input style='width:auto;pointer-events:auto' type='checkbox' name='enabled' value='1'"
        + (" checked" if enabled else "") + ">Enabled</label>"
    )
    delete_html = (
        "<button class='danger' type='button' disabled title='The connected profile cannot be deleted'>Delete</button>"
        if current else
        "<button class='danger' style='pointer-events:auto' type='submit' formaction='/wifilink2/native-network/delete' onclick=\"return confirm('Delete this WiFiLink2 profile?');\">Delete</button>"
    )

    return (
        "<div class='wl2-profile-row'>"
        "<div class='wl2-profile-summary'>"
        "<div><div class='ssidtitle'>" + esc(ssid) + " <span class='pill " + esc(badge_class) + "'>" + esc(label) + "</span></div>"
        "<div class='ssidmeta'>" + esc(signal_text) + " · Priority " + esc(priority) + "</div></div>"
        "<button type='button' class='wl2-secondary' onclick=\"toggleWl2Editor('" + esc(editor_id) + "',this)\">Edit</button>"
        "</div>"
        "<div id='" + esc(editor_id) + "' class='wl2-profile-editor'>"
        "<form method='post' action='/wifilink2/native-network/save'>"
        "<input type='hidden' name='old_ssid' value='" + esc(ssid) + "'>"
        "<input type='hidden' name='current_security' value='" + esc(security) + "'>"
        "<div class='grid'>"
        "<div><label>SSID</label><input style='pointer-events:auto' name='ssid' value='" + esc(ssid) + "'" + ssid_attr + "></div>"
        "<div><label>Password</label><input id='" + esc(input_id) + "' style='pointer-events:auto' type='password' autocomplete='off' name='password' value='" + esc(password) + "' placeholder='" + esc(password_placeholder) + "'>"
        + _wl2_password_toggle(input_id, checkbox_id) + "</div>"
        "<div><label>Priority</label><input style='pointer-events:auto' type='number' min='0' max='999' name='priority' value='" + esc(priority) + "'><div class='small'>Higher number is preferred.</div></div>"
        "<div><label>Network state</label>" + enabled_control + "<label class='small' style='display:flex;gap:7px;align-items:center;margin-top:9px'><input style='width:auto;pointer-events:auto' type='checkbox' name='open_network' value='1'" + (" checked" if security == "open" else "") + ">Open network (no password)</label></div>"
        "</div><div style='display:flex;gap:10px;margin-top:14px'>"
        "<button style='pointer-events:auto' type='submit'>Save changes</button>" + delete_html +
        "</div></form></div></div>"
    )


def _wl2_legacy_profile_card(item, index):
    password = str(item.get("password") or "")
    input_id = "wl2-legacy-pass-" + str(index)
    checkbox_id = "wl2-legacy-show-pass-" + str(index)
    return (
        "<div class='wl2-profile-row'>"
        "<div class='wl2-profile-summary'><div><div class='ssidtitle'>" + esc(item.get("ssid") or "(unknown)") + " <span class='pill warn'>Stored on Pi only</span></div>"
        "<div class='ssidmeta'>Import this legacy profile to WiFiLink2.</div></div></div>"
        "<div style='margin-top:10px'><label>Stored password</label><input id='" + esc(input_id) + "' type='password' readonly value='" + esc(password) + "'>"
        + _wl2_password_toggle(input_id, checkbox_id) + "</div>"
        "<form method='post' action='/wifilink2/native-network/save' style='margin-top:12px'>"
        "<input type='hidden' name='old_ssid' value=''><input type='hidden' name='ssid' value='" + esc(item.get("ssid") or "") + "'>"
        "<input type='hidden' name='password' value='" + esc(password) + "'><input type='hidden' name='priority' value='30'>"
        "<input type='hidden' name='enabled' value='1'><input type='hidden' name='current_security' value='unknown'>"
        "<button style='pointer-events:auto' type='submit'>Import to WiFiLink2</button></form></div>"
    )


def _wl2_add_profile_form():
    return """
    <div id='wl2AddModal' class='wl2-modal' aria-hidden='true'>
      <div class='wl2-modal-dialog'>
        <div class='wl2-modal-head'><h2>Add Wi-Fi network</h2><button type='button' class='wl2-close' onclick='closeWl2Add()'>×</button></div>
        <p class='small'>The profile is stored directly on WiFiLink2 and loaded without restarting WLAN.</p>
        <form method='post' action='/wifilink2/native-network/save'>
          <input type='hidden' name='old_ssid' value=''><input type='hidden' name='current_security' value='unknown'>
          <div class='grid'>
            <div><label>SSID</label><input id='wl2-new-ssid' style='pointer-events:auto' name='ssid' maxlength='32' required></div>
            <div><label>Password</label><input id='wl2-new-pass' style='pointer-events:auto' type='password' autocomplete='off' name='password'><label class='small' style='display:flex;gap:7px;align-items:center;margin-top:7px'><input style='width:auto;pointer-events:auto' type='checkbox' onclick=\"document.getElementById('wl2-new-pass').type=this.checked?'text':'password'\">Show password</label></div>
            <div><label>Priority</label><input style='pointer-events:auto' type='number' min='0' max='999' name='priority' value='30'><div class='small'>Higher number is preferred.</div></div>
            <div><label>Network state</label><label style='display:flex;gap:7px;align-items:center'><input style='width:auto;pointer-events:auto' type='checkbox' name='enabled' value='1' checked>Enabled</label><label class='small' style='display:flex;gap:7px;align-items:center;margin-top:9px'><input id='wl2-new-open' style='width:auto;pointer-events:auto' type='checkbox' name='open_network' value='1'>Open network (no password)</label></div>
          </div>
          <div style='display:flex;justify-content:flex-end;gap:10px;margin-top:16px'><button type='button' class='wl2-secondary' onclick='closeWl2Add()'>Cancel</button><button style='pointer-events:auto' type='submit'>Add network</button></div>
        </form>
      </div>
    </div>
    """


def _wl2_device_runtime_summary():
    command = r"""hostname_value="$(hostname 2>/dev/null || echo wifilink2)"
wpa_state="$(/usr/sbin/wpa_cli -i wlan0 status 2>/dev/null | sed -n 's/^wpa_state=//p' | head -n1)"
lan_ip="$(/usr/sbin/wpa_cli -i wlan0 status 2>/dev/null | sed -n 's/^ip_address=//p' | head -n1)"
uptime_value="$(cut -d. -f1 /proc/uptime 2>/dev/null || echo 0)"
manager_state="$(/etc/init.d/S96siyi-wifi-profiles-v7b status 2>/dev/null | head -n1 || true)"
zt_state="$(zerotier-cli info 2>/dev/null | awk '{print $5}' | head -n1 || true)"
if netstat -lnt 2>/dev/null | grep -q ':554 '; then rtsp_state=online; else rtsp_state=offline; fi
for pair in hostname "$hostname_value" wpa_state "$wpa_state" lan_ip "$lan_ip" uptime "$uptime_value" manager "$manager_state" zerotier "$zt_state" rtsp "$rtsp_state"; do :; done
printf '__WL2_RUNTIME_HOST_B64__'; printf '%s' "$hostname_value" | base64; echo
printf '__WL2_RUNTIME_WPA__%s\n' "$wpa_state"
printf '__WL2_RUNTIME_LAN__%s\n' "$lan_ip"
printf '__WL2_RUNTIME_UPTIME__%s\n' "$uptime_value"
printf '__WL2_RUNTIME_MANAGER_B64__'; printf '%s' "$manager_state" | base64; echo
printf '__WL2_RUNTIME_ZT__%s\n' "$zt_state"
printf '__WL2_RUNTIME_RTSP__%s\n' "$rtsp_state"""
    summary = {
        "hostname": "wifilink2", "wpa_state": "", "lan_ip": "", "uptime_seconds": 0,
        "manager_state": "unknown", "zerotier_state": "", "rtsp_state": "unknown",
    }
    try:
        output = _wl2_remote_command(command, timeout=8.0, max_bytes=131072)
        def marker(name):
            match = re.search(r"(?m)^" + re.escape(name) + r"([^\r\n]*)$", output)
            return match.group(1).strip() if match else ""
        def decoded(name):
            raw = marker(name)
            if not raw:
                return ""
            try:
                return _wl2_base64.b64decode(raw.encode("ascii"), validate=False).decode("utf-8", errors="replace").strip()
            except Exception:
                return ""
        summary["hostname"] = decoded("__WL2_RUNTIME_HOST_B64__") or summary["hostname"]
        summary["wpa_state"] = marker("__WL2_RUNTIME_WPA__")
        summary["lan_ip"] = marker("__WL2_RUNTIME_LAN__")
        try:
            summary["uptime_seconds"] = int(marker("__WL2_RUNTIME_UPTIME__") or 0)
        except Exception:
            summary["uptime_seconds"] = 0
        summary["manager_state"] = decoded("__WL2_RUNTIME_MANAGER_B64__") or "unknown"
        summary["zerotier_state"] = marker("__WL2_RUNTIME_ZT__")
        summary["rtsp_state"] = marker("__WL2_RUNTIME_RTSP__") or "unknown"
    except Exception as exc:
        summary["error"] = str(exc)
    return summary


def _wl2_format_uptime(seconds):
    try:
        seconds = max(0, int(seconds))
    except Exception:
        return "Unavailable"
    days, remainder = divmod(seconds, 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, _seconds = divmod(remainder, 60)
    if days:
        return f"{days}d {hours}h {minutes}m"
    if hours:
        return f"{hours}h {minutes}m"
    return f"{minutes}m"


def _wl2_device_settings_save(params):
    cfg = video_source_read_config()
    section = cfg.get("wifilink") if isinstance(cfg, dict) else None
    if not isinstance(section, dict):
        section = {}
        cfg["wifilink"] = section
    url = str(params.get("wifilink_url") or section.get("url") or "").strip()
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in {"rtsp", "rtsps"} or not parsed.hostname:
        raise ValueError("WiFiLink2 RTSP URL must be a valid RTSP URL")
    username = str(params.get("wifilink_username") or section.get("username") or "root").strip()
    if not username:
        raise ValueError("WiFiLink2 username cannot be empty")
    transport = str(params.get("wifilink_transport") or section.get("transport") or "tcp")
    if transport not in {"tcp", "udp"}:
        raise ValueError("Invalid WiFiLink2 RTSP transport")
    latency = video_source_int(params.get("wifilink_latency", section.get("latency_ms", 0)), 0, 5000, "WiFiLink2 latency")
    password = str(params.get("wifilink_password") or "")
    section.update({"url": url, "username": username, "transport": transport, "latency_ms": latency})
    if password:
        section["password"] = password
    video_source_write_config(cfg)
    if cfg.get("source") == "wifilink_rtsp":
        video_source_control("apply")
        return "WiFiLink2 device settings saved and applied to the active video source"
    return "WiFiLink2 device settings saved"


def _wl2_device_connection_test():
    host, _username, _password = _wl2_credentials()
    _wl2_remote_command("echo __WL2_SSH_OK__", timeout=8.0)
    sock = None
    try:
        sock = socket.create_connection((host, 554), timeout=5.0)
    finally:
        if sock is not None:
            sock.close()
    return "WiFiLink2 SSH and RTSP connection test passed"


def _wl2_nearby_rows(nearby_networks, configured_ssids):
    rows = []
    for item in nearby_networks:
        ssid = str(item.get("ssid") or "")
        if not ssid:
            continue
        percent = item.get("signal_percent")
        dbm = item.get("signal_dbm")
        signal = (str(percent) + "% · " + str(int(dbm)) + " dBm") if isinstance(percent, int) and isinstance(dbm, (int, float)) else "Signal unavailable"
        configured = ssid in configured_ssids
        status = "Configured" if configured else "Nearby"
        action = "<span class='pill active'>Configured</span>" if configured else (
            "<button type='button' class='wl2-secondary' onclick='openWl2Add(" + esc(json.dumps(ssid)) + ",false)'>Add</button>"
        )
        rows.append("<div class='wl2-nearby-row'><div><b>" + esc(ssid) + "</b><div class='small'>" + esc(signal) + "</div></div><div>" + action + "</div></div>")
    if not rows:
        return "<p class='small'>No nearby networks are present in the current scan cache.</p>"
    return "".join(rows)


def wifilink2_settings_page():
    device = _wl2_device_network()
    runtime = _wl2_device_runtime_summary()
    status = _wl2_temperature_status(force=True)
    host, username, password = _wl2_credentials()
    video_cfg = video_source_read_config()
    wl_video = video_cfg.get("wifilink", {}) if isinstance(video_cfg, dict) else {}

    try:
        inventory = _wl2_native_wifi_inventory()
        inventory_error = ""
    except Exception as exc:
        inventory = {
            "profiles": [], "nearby_networks": [],
            "active_ssid": str(device.get("active_ssid") or device.get("ssid") or ""),
            "signal_dbm": None, "signal_percent": None, "quality": "",
        }
        inventory_error = str(exc)

    current_ssid = inventory.get("active_ssid") or device.get("active_ssid") or device.get("ssid") or "Unavailable"
    online_class = "ok" if status.get("online") else "bad"
    online_label = "Online" if status.get("online") else "Unavailable"
    temperature = status.get("temperature_c")
    temperature_text = (f"{temperature:.1f} °C" if isinstance(temperature, (int, float)) else "Unavailable")

    signal_percent = inventory.get("signal_percent")
    signal_dbm = inventory.get("signal_dbm")
    if isinstance(signal_percent, int) and isinstance(signal_dbm, (int, float)):
        signal_text = _wl2_signal_bars(signal_percent) + " " + str(signal_percent) + "% · " + str(int(signal_dbm)) + " dBm"
    elif inventory.get("quality"):
        signal_text = str(inventory.get("quality"))
    else:
        signal_text = "Unavailable"

    native_profiles = list(inventory.get("profiles") or [])
    native_html = "".join(_wl2_native_profile_card(item, index) for index, item in enumerate(native_profiles))
    if not native_html:
        native_html = "<p class='small'>No WiFiLink2 profiles could be read.</p>"

    native_ssids = {str(item.get("ssid") or "") for item in native_profiles}
    current_profile = next((item for item in native_profiles if item.get("current")), None)
    current_priority = current_profile.get("priority", 50) if current_profile else 50
    current_card = (
        "<div class='wl2-current-card'><div><div class='ssidtitle'>" + esc(current_ssid) + " <span class='pill active'>Connected</span></div>"
        "<div class='ssidmeta'>" + esc(signal_text) + " · Priority " + esc(current_priority) + "</div>"
        "<div class='ssidmeta'>LAN address: " + esc(runtime.get("lan_ip") or "Unavailable") + "</div></div>"
        "<button type='button' class='wl2-secondary' onclick=\"activateWl2Tab('wifi');const e=document.querySelector('.wl2-profile-row .ssidtitle');if(e)e.scrollIntoView({behavior:'smooth'});\">Manage profile</button></div>"
    )

    nearby_html = _wl2_nearby_rows(list(inventory.get("nearby_networks") or []), native_ssids)
    legacy_profiles = [item for item in _wl2_profiles_read().get("profiles", []) if str(item.get("ssid") or "") not in native_ssids]
    legacy_html = "".join(_wl2_legacy_profile_card(item, index) for index, item in enumerate(legacy_profiles))

    try:
        camera_controls = _wl2_camera_controls()
        camera_error = ""
    except Exception as exc:
        camera_controls = []
        camera_error = str(exc)
    camera_groups = []
    for section in ("isp", "image", "video0"):
        fields = [_wl2_camera_field_html(item) for item in camera_controls if item["section"] == section]
        if fields:
            camera_groups.append(
                "<section class='wl2-camera-group'><h3>"
                + esc(_wl2_human_label(section))
                + "</h3><div class='wl2-camera-grid'>"
                + "".join(fields)
                + "</div></section>"
            )
    if camera_groups:
        camera_html = (
            "<form method='post' action='/wifilink2/camera/apply' class='wl2-camera-form'>"
            + "".join(camera_groups)
            + "<div class='wl2-camera-actions'><button style='pointer-events:auto'>Apply camera settings</button>"
            + "<a class='wl2-link-button wl2-secondary' href='/wifilink2?reload=1#camera'>Reload active values</a>"
            + "<span class='small'>Sliders and radio choices are applied together.</span></div></form>"
        )
    else:
        camera_html = "<p class='bad'>Camera settings unavailable: " + esc(camera_error or "No supported image controls were reported by this firmware") + "</p>"

    network_error = ""
    if inventory_error:
        network_error = "<p class='bad'>WiFiLink2 profile read failed: " + esc(inventory_error) + "</p>"
    elif not device.get("online"):
        network_error = "<p class='bad'>Device network status unavailable: " + esc(device.get("error") or "Unknown error") + "</p>"

    last_action = _wl2_last_action()
    action_html = ("<div class='wl2-action'><b>Last action:</b> " + esc(last_action) + "</div>") if last_action else ""
    legacy_section = ""
    if legacy_html:
        legacy_section = "<details class='wl2-details'><summary>Profiles stored on the Pi but not WiFiLink2</summary><p class='small'>Import these only when they are still needed.</p>" + legacy_html + "</details>"

    rtsp_online = str(runtime.get("rtsp_state") or "").lower() == "online"
    rtsp_label = "Online" if rtsp_online else "Unavailable"
    rtsp_class = "ok" if rtsp_online else "bad"
    zt_state = str(runtime.get("zerotier_state") or "").upper()
    zt_online = zt_state == "ONLINE" or bool(host)
    zt_label = host + ((" · " + zt_state) if zt_state else "")
    manager_state = str(runtime.get("manager_state") or "unknown")
    wpa_state = str(runtime.get("wpa_state") or "Unavailable")
    password_value = str(wl_video.get("password") or password or "")
    transport = str(wl_video.get("transport") or "tcp")

    body = f"""
    <!-- VIDEO_WIFI_UI_RESTRUCTURE_V8 -->
    <style>
      .wl2-head{{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:16px;flex-wrap:wrap}}
      .wl2-head h1{{margin:0}}
      .wl2-summary{{display:grid;grid-template-columns:repeat(6,minmax(135px,1fr));gap:10px}}
      .wl2-kpi{{background:#0b1220;border:1px solid #334155;border-radius:10px;padding:12px;min-height:62px}}
      .wl2-kpi-label{{font-size:12px;color:#94a3b8;margin-bottom:5px}}
      .wl2-kpi-value{{font-weight:700;word-break:break-word}}
      .wl2-tabbar{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}}
      .wl2-tabbtn{{background:#1e293b;color:#cbd5e1;border:1px solid #334155;margin:0}}
      .wl2-tabbtn.active{{background:#2563eb;color:white;border-color:#3b82f6}}
      .wl2-tabpanel{{display:none}}
      .wl2-tabpanel.active{{display:block}}
      .wl2-action{{background:#172554;border:1px solid #1d4ed8;border-radius:10px;padding:11px 13px;margin-bottom:16px}}
      .wl2-current-card{{display:flex;justify-content:space-between;gap:18px;align-items:center;background:#0b1220;border:1px solid #22c55e;border-radius:12px;padding:15px;flex-wrap:wrap}}
      .wl2-profile-row{{background:#0b1220;border:1px solid #334155;border-radius:10px;padding:13px;margin-bottom:10px}}
      .wl2-profile-summary{{display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}}
      .wl2-profile-editor{{display:none;border-top:1px solid #334155;margin-top:12px;padding-top:12px}}
      .wl2-profile-editor.open{{display:block}}
      .wl2-secondary{{background:#475569}}
      .wl2-link-button{{display:inline-block;background:#2563eb;color:white;border-radius:8px;padding:9px 13px;text-decoration:none}}
      .wl2-nearby-row{{display:flex;justify-content:space-between;gap:16px;align-items:center;padding:10px 0;border-bottom:1px solid #243244}}
      .wl2-nearby-row:last-child{{border-bottom:0}}
      .wl2-details{{background:#0b1220;border:1px solid #334155;border-radius:10px;padding:12px;margin-top:12px}}
      .wl2-details summary{{cursor:pointer;font-weight:700}}
      .wl2-modal{{display:none;position:fixed;inset:0;background:rgba(2,6,23,.82);z-index:10000;align-items:center;justify-content:center;padding:20px}}
      .wl2-modal.open{{display:flex}}
      .wl2-modal-dialog{{width:min(760px,96vw);background:#111827;border:1px solid #475569;border-radius:14px;padding:18px;box-shadow:0 24px 80px rgba(0,0,0,.6)}}
      .wl2-modal-head{{display:flex;justify-content:space-between;align-items:center;gap:12px}}
      .wl2-modal-head h2{{margin:0}}
      .wl2-close{{background:transparent;font-size:28px;padding:0 8px;color:#cbd5e1}}
      .wl2-camera-form{{display:grid;gap:12px}}
      .wl2-camera-group{{background:#0b1220;border:1px solid #334155;border-radius:14px;padding:14px}}
      .wl2-camera-group h3{{margin:0 0 12px;font-size:17px}}
      .wl2-camera-grid{{display:grid;grid-template-columns:repeat(2,minmax(260px,1fr));gap:14px}}
      .wl2-camera-field{{background:#111827;border:1px solid #334155;border-radius:11px;padding:12px}}
      .wl2-camera-field>label{{display:block;margin-bottom:9px;color:#e2e8f0;font-weight:700}}
      .wl2-camera-slider-row{{display:grid;grid-template-columns:1fr 58px;gap:10px;align-items:center}}
      .wl2-camera-slider-row input[type=range]{{width:100%;accent-color:#3b82f6}}
      .wl2-camera-slider-row output{{background:#020617;border:1px solid #334155;border-radius:7px;padding:6px;text-align:center}}
      .wl2-camera-radio-group{{display:flex;gap:8px;flex-wrap:wrap}}
      .wl2-camera-radio{{display:inline-flex;align-items:center;gap:7px;background:#020617;border:1px solid #334155;border-radius:999px;padding:8px 12px;cursor:pointer}}
      .wl2-camera-radio:has(input:checked){{background:#172554;border-color:#3b82f6;color:#dbeafe}}
      .wl2-camera-radio input{{width:auto;margin:0;accent-color:#3b82f6}}
      .wl2-camera-actions{{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:2px}}
      @media(max-width:900px){{.wl2-camera-grid{{grid-template-columns:1fr}}}}
      @media(max-width:1100px){{.wl2-summary{{grid-template-columns:repeat(3,minmax(150px,1fr))}}}}
      @media(max-width:700px){{.wl2-summary{{grid-template-columns:1fr 1fr}}}}
    </style>

    <div class='wl2-head'><div><h1>Air Link</h1><div class='small'>Wireless link, onboard camera and device connection settings.</div></div><a class='wl2-link-button wl2-secondary' href='/media?tab=video' target='_top'>Open Cameras &amp; Video</a></div>
    {action_html}
    <div class='card'>
      <div class='wl2-summary'>
        <div class='wl2-kpi'><div class='wl2-kpi-label'>Device</div><div id='wl2-online' class='wl2-kpi-value {online_class}'>{online_label}</div></div>
        <div class='wl2-kpi'><div class='wl2-kpi-label'>Current network</div><div class='wl2-kpi-value'>{esc(current_ssid)}</div></div>
        <div class='wl2-kpi'><div class='wl2-kpi-label'>Signal</div><div class='wl2-kpi-value' style='font-size:13px'>{esc(signal_text)}</div></div>
        <div class='wl2-kpi'><div class='wl2-kpi-label'>LAN address</div><div class='wl2-kpi-value'>{esc(runtime.get('lan_ip') or 'Unavailable')}</div></div>
        <div class='wl2-kpi'><div class='wl2-kpi-label'>ZeroTier</div><div class='wl2-kpi-value' style='font-size:13px'>{esc(zt_label)}</div></div>
        <div class='wl2-kpi'><div class='wl2-kpi-label'>CPU / RTSP</div><div class='wl2-kpi-value'><span id='wl2-temperature'>{temperature_text}</span> · <span class='{rtsp_class}'>{rtsp_label}</span></div></div>
      </div>
      <p id='wl2-status-error' class='small'>{esc(status.get('error') or '')}</p>{network_error}
    </div>

    <div class='wl2-tabbar'>
      <button type='button' class='wl2-tabbtn active' data-tab='wifi'>Wi-Fi</button>
      <button type='button' class='wl2-tabbtn' data-tab='camera'>Camera</button>
      <button type='button' class='wl2-tabbtn' data-tab='device'>Device</button>
      <button type='button' class='wl2-tabbtn' data-tab='diagnostics'>Diagnostics</button>
    </div>

    <section class='wl2-tabpanel active' data-panel='wifi'>
      <div class='card'><div class='wl2-card-title'><h2>Current connection</h2></div>{current_card}</div>
      <div class='card'>
        <div style='display:flex;justify-content:space-between;gap:14px;align-items:center;flex-wrap:wrap'><div><h2 style='margin-bottom:4px'>Configured networks</h2><div class='small'>Profiles stored directly on WiFiLink2. Higher priority is preferred.</div></div><button type='button' onclick='openWl2Add()'>+ Add Wi-Fi network</button></div>
        <div style='margin-top:14px'>{native_html}</div>{legacy_section}
      </div>
      <div class='card'>
        <div style='display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap'><div><h2 style='margin-bottom:4px'>Nearby networks</h2><div class='small'>Current scan cache from WiFiLink2. Out-of-range saved profiles remain configured.</div></div><button type='button' class='wl2-secondary' onclick='refreshNearbyNetworks(this)'>Scan networks</button></div>
        <div id='wl2NearbyNetworks' style='margin-top:10px'>{nearby_html}</div>
      </div>
    </section>

    <section class='wl2-tabpanel' data-panel='camera'>
      <div class='card'><h2>Air Link Camera</h2><p class='small'>Live image settings read from <code>/etc/majestic.yaml</code>. Use sliders for levels and radio buttons for discrete choices, then apply the group.</p>{camera_html}</div>
    </section>

    <section class='wl2-tabpanel' data-panel='device'>
      <div class='card'>
        <h2>Device connection</h2>
        <p class='small'>This is the authoritative location for WiFiLink2 address, login and RTSP connection settings. The Video page uses the same stored configuration.</p>
        <form method='post' action='/wifilink2/device/save'>
          <div class='grid'>
            <div style='grid-column:1/-1'><label>RTSP URL</label><input name='wifilink_url' value='{esc(wl_video.get('url') or '')}' required></div>
            <div><label>SSH / WebUI username</label><input name='wifilink_username' value='{esc(username)}' required></div>
            <div><label>Password</label><input id='wl2-device-password' type='password' name='wifilink_password' value='{esc(password_value)}' autocomplete='off'>{_wl2_password_toggle('wl2-device-password','wl2-show-device-password')}</div>
            <div><label>RTSP probe transport</label><select name='wifilink_transport'><option value='tcp' {'selected' if transport == 'tcp' else ''}>TCP</option><option value='udp' {'selected' if transport == 'udp' else ''}>UDP</option></select></div>
            <div><label>Receiver latency (ms)</label><input type='number' min='0' max='5000' name='wifilink_latency' value='{esc(wl_video.get('latency_ms',0))}'></div>
          </div>
          <div style='display:flex;gap:10px;margin-top:14px;flex-wrap:wrap'><button type='submit'>Save device settings</button></div>
        </form>
        <form method='post' action='/wifilink2/device/test' style='margin-top:8px'><button type='submit' class='wl2-secondary'>Test saved SSH and RTSP connection</button></form>
      </div>
    </section>

    <section class='wl2-tabpanel' data-panel='diagnostics'>
      <div class='card'>
        <h2>Device diagnostics</h2>
        <div class='grid'>
          <div class='wl2-kpi'><div class='wl2-kpi-label'>Hostname</div><div class='wl2-kpi-value'>{esc(runtime.get('hostname') or 'Unavailable')}</div></div>
          <div class='wl2-kpi'><div class='wl2-kpi-label'>Uptime</div><div class='wl2-kpi-value'>{esc(_wl2_format_uptime(runtime.get('uptime_seconds',0)))}</div></div>
          <div class='wl2-kpi'><div class='wl2-kpi-label'>wpa_supplicant</div><div class='wl2-kpi-value'>{esc(wpa_state)}</div></div>
          <div class='wl2-kpi'><div class='wl2-kpi-label'>Profile manager</div><div class='wl2-kpi-value' style='font-size:13px'>{esc(manager_state)}</div></div>
          <div class='wl2-kpi'><div class='wl2-kpi-label'>ZeroTier state</div><div class='wl2-kpi-value'>{esc(zt_state or 'Unavailable')}</div></div>
          <div class='wl2-kpi'><div class='wl2-kpi-label'>RTSP service</div><div class='wl2-kpi-value {rtsp_class}'>{rtsp_label}</div></div>
        </div>
        <details class='wl2-details' style='margin-top:14px'><summary>Configuration notes</summary><p class='small'>Wi-Fi profiles are maintained by the V7B profile manager. WLAN is not restarted when a profile is added or edited. The currently connected profile cannot be deleted or disabled.</p></details>
        <a class='wl2-link-button wl2-secondary' href='/system?tab=diagnostics' target='_top'>Open full system diagnostics</a>
      </div>
    </section>

    {_wl2_add_profile_form()}

    <script>
    const configuredWl2Ssids=new Set({json.dumps(sorted(native_ssids), ensure_ascii=False)});
    function activateWl2Tab(name){{
      document.querySelectorAll('.wl2-tabbtn').forEach(btn=>btn.classList.toggle('active',btn.dataset.tab===name));
      document.querySelectorAll('.wl2-tabpanel').forEach(panel=>panel.classList.toggle('active',panel.dataset.panel===name));
      if(history.replaceState) history.replaceState(null,'','#'+name);
      try{{localStorage.setItem('siyi-tab-wifilink2',name)}}catch(_e){{}}
    }}
    document.querySelectorAll('.wl2-tabbtn').forEach(btn=>btn.addEventListener('click',()=>activateWl2Tab(btn.dataset.tab)));
    const requestedTab=(location.hash||'').replace('#','') || (()=>{{try{{return localStorage.getItem('siyi-tab-wifilink2')}}catch(_e){{return ''}}}})() || 'wifi';
    if(['wifi','camera','device','diagnostics'].includes(requestedTab)) activateWl2Tab(requestedTab);
    function toggleWl2Editor(id,button){{const editor=document.getElementById(id);const open=editor.classList.toggle('open');button.textContent=open?'Close':'Edit';}}
    function openWl2Add(ssid='',openNetwork=false){{
      document.getElementById('wl2-new-ssid').value=ssid||'';
      document.getElementById('wl2-new-open').checked=Boolean(openNetwork);
      document.getElementById('wl2AddModal').classList.add('open');
      document.getElementById('wl2AddModal').setAttribute('aria-hidden','false');
      setTimeout(()=>document.getElementById(ssid?'wl2-new-pass':'wl2-new-ssid').focus(),50);
    }}
    function closeWl2Add(){{document.getElementById('wl2AddModal').classList.remove('open');document.getElementById('wl2AddModal').setAttribute('aria-hidden','true');}}
    document.getElementById('wl2AddModal').addEventListener('click',event=>{{if(event.target.id==='wl2AddModal')closeWl2Add();}});
    async function refreshNearbyNetworks(button){{
      const old=button.textContent;button.disabled=true;button.textContent='Scanning…';
      const target=document.getElementById('wl2NearbyNetworks');
      try{{
        const response=await fetch('/wifilink2/api/scan?ts='+Date.now(),{{cache:'no-store'}});
        const data=await response.json();
        if(data.error){{target.innerHTML='<p class="bad"></p>';target.querySelector('p').textContent=data.error;return;}}
        target.innerHTML='';
        (data.networks||[]).forEach(item=>{{
          const row=document.createElement('div');row.className='wl2-nearby-row';
          const info=document.createElement('div');const title=document.createElement('b');title.textContent=item.ssid||'(hidden)';const meta=document.createElement('div');meta.className='small';meta.textContent=String(item.signal)+' dBm · '+String(item.security||'Unknown');info.append(title,meta);
          let action;if(configuredWl2Ssids.has(item.ssid||'')){{action=document.createElement('span');action.className='pill active';action.textContent='Configured';}}else{{action=document.createElement('button');action.type='button';action.className='wl2-secondary';action.textContent='Add';action.onclick=()=>openWl2Add(item.ssid||'',String(item.security||'').toLowerCase()==='open');}}
          row.append(info,action);target.appendChild(row);
        }});
        if(!(data.networks||[]).length) target.innerHTML='<p class="small">No nearby networks were returned.</p>';
      }}catch(error){{target.innerHTML='<p class="bad">Scan failed.</p>';}}
      finally{{button.disabled=false;button.textContent=old;}}
    }}
    async function refreshWl2Status(){{
      try{{
        const response=await fetch('/wifilink2/api/status?ts='+Date.now(),{{cache:'no-store'}});const data=await response.json();
        const online=document.getElementById('wl2-online');const temp=document.getElementById('wl2-temperature');const error=document.getElementById('wl2-status-error');
        online.textContent=data.online?'Online':'Unavailable';online.className='wl2-kpi-value '+(data.online?'ok':'bad');
        temp.textContent=(typeof data.temperature_c==='number')?data.temperature_c.toFixed(1)+' °C':'Unavailable';error.textContent=data.error||'';
      }}catch(error){{document.getElementById('wl2-online').textContent='Unavailable';document.getElementById('wl2-temperature').textContent='Unavailable';}}
    }}
    refreshWl2Status();setInterval(refreshWl2Status,5000);
    </script>
    """
    return body


_wl2_original_page = page

def page(title, body):
    document = _wl2_original_page(title, body)
    if 'href="/wifilink2"' not in document:
        document = document.replace('<a href="/video">Video</a>', '<a href="/video">Video</a>\n<a href="/wifilink2">WiFiLink2</a>')
    return document


def _wl2_send_json(handler, payload, status=200):
    raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def _wl2_send_html(handler, body, status=200):
    raw = page("WiFiLink2 Settings", setup_banner() + body).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "text/html; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def _wl2_set_action(message):
    try:
        with open("/tmp/siyi_wifilink2_last_action", "w", encoding="utf-8") as handle:
            handle.write(str(message))
    except Exception:
        pass


def _wl2_redirect(handler, tab="wifi"):
    safe_tab = tab if tab in {"wifi", "camera", "device", "diagnostics"} else "wifi"
    handler.send_response(303)
    handler.send_header("Location", "/wifilink2#" + safe_tab)
    handler.end_headers()


def _wl2_parse_post(handler):
    length = int(handler.headers.get("Content-Length", "0") or "0")
    if length > 262144:
        raise ValueError("Request is too large")
    raw = handler.rfile.read(length).decode("utf-8", errors="replace")
    parsed = urllib.parse.parse_qs(raw, keep_blank_values=True)
    return {key: values[-1] if values else "" for key, values in parsed.items()}


_wl2_previous_get = H.do_GET

def _wl2_do_GET(self):
    path = urllib.parse.urlparse(self.path).path
    if software_update_lock_active():
        return _wl2_previous_get(self)
    if path == "/wifilink2":
        try:
            return _wl2_send_html(self, wifilink2_settings_page())
        except Exception as exc:
            return _wl2_send_html(self, "<h1>WiFiLink2 Settings</h1><div class='card'><p class='bad'>Page failed: " + esc(exc) + "</p></div>", 500)
    if path == "/wifilink2/api/status":
        return _wl2_send_json(self, _wl2_temperature_status())
    if path == "/wifilink2/api/scan":
        try:
            return _wl2_send_json(self, _wl2_scan_networks())
        except Exception as exc:
            return _wl2_send_json(self, {"networks": [], "error": str(exc)}, 502)
    return _wl2_previous_get(self)

H.do_GET = _wl2_do_GET


_wl2_previous_post = H.do_POST

def _wl2_do_POST(self):
    path = urllib.parse.urlparse(self.path).path
    wl2_paths = {
        "/wifilink2/native-network/save",
        "/wifilink2/native-network/delete",
        "/wifilink2/camera/apply",
        "/wifilink2/device/save",
        "/wifilink2/device/test",
    }
    if path not in wl2_paths:
        return _wl2_previous_post(self)
    if software_update_lock_active():
        return _wl2_previous_post(self)
    try:
        params = _wl2_parse_post(self)
        redirect_tab = "wifi"
        if path == "/wifilink2/native-network/save":
            result = _wl2_native_network_save(params)
            _wl2_set_action(result)
        elif path == "/wifilink2/native-network/delete":
            result = _wl2_native_network_delete(params)
            _wl2_set_action(result)
        elif path == "/wifilink2/camera/apply":
            redirect_tab = "camera"
            result = _wl2_camera_apply(params)
            _wl2_set_action("WiFiLink2 camera settings applied" + ((": " + result) if result else ""))
        elif path == "/wifilink2/device/save":
            redirect_tab = "device"
            result = _wl2_device_settings_save(params)
            _wl2_set_action(result)
        elif path == "/wifilink2/device/test":
            redirect_tab = "device"
            result = _wl2_device_connection_test()
            _wl2_set_action(result)
        return _wl2_redirect(self, redirect_tab)
    except Exception as exc:
        failed_tab = "camera" if path == "/wifilink2/camera/apply" else ("device" if path.startswith("/wifilink2/device/") else "wifi")
        _wl2_set_action("WiFiLink2 change failed: " + str(exc))
        return _wl2_redirect(self, failed_tab)

H.do_POST = _wl2_do_POST
# WIFILINK2_SETTINGS_PAGE_V1_END



# CONTROL_CENTER_WORKSPACES_V9_START
# Presentation-only workspace shell. Existing configuration endpoints and services remain unchanged.

_v9_previous_page = page
_v9_previous_get = H.do_GET

def _v9_nav_html():
    wizard = "" if setup_is_complete() else "<a class='v9-nav-link' data-workspace='system' href='/first_setup'><span class='v9-nav-icon'>W</span><span>Setup Wizard</span></a>"
    return f"""
<nav class='v9-sidebar'>
  <div class='v9-nav-label'>Workspaces</div>
  <a class='v9-nav-link' data-workspace='dashboard' href='/'><span class='v9-nav-icon'>O</span><span>Overview</span></a>
  <a class='v9-nav-link' data-workspace='connectivity' href='/connectivity'><span class='v9-nav-icon'>C</span><span>Connectivity</span></a>
  <a class='v9-nav-link' data-workspace='media' href='/media'><span class='v9-nav-icon'>V</span><span>Cameras &amp; Video</span></a>
  <a class='v9-nav-link' data-workspace='aircraft' href='/aircraft'><span class='v9-nav-icon'>A</span><span>Aircraft</span></a>
  <a class='v9-nav-link' data-workspace='system' href='/system'><span class='v9-nav-icon'>S</span><span>System</span></a>
  {wizard}
  <div class='v9-nav-foot'>
    <span>SIYI Pi Control Center</span>
    <span class='small'>Control Center 4.1.0</span>
  </div>
</nav>
"""

def page(title, body):
    document = _v9_previous_page(title, body)
    document = re.sub(r"<nav>.*?</nav>", _v9_nav_html(), document, count=1, flags=re.S)

    v9_css = r"""
/* CONTROL_CENTER_WORKSPACES_V9 */
header{height:42px;padding:12px 22px;display:flex;align-items:center;background:linear-gradient(90deg,#020617,#071226);box-shadow:0 8px 28px rgba(0,0,0,.25)}
.v9-sidebar{width:210px;background:#020617;height:calc(100vh - 66px);position:fixed;left:0;top:66px;padding:16px 13px;border-right:1px solid #334155;overflow-y:auto;box-sizing:border-box}
.v9-nav-label{font-size:11px;text-transform:uppercase;letter-spacing:.12em;color:#64748b;padding:2px 11px 10px}
.v9-nav-link{display:flex!important;align-items:center;gap:11px;color:#cbd5e1!important;text-decoration:none;padding:11px 12px!important;border-radius:10px;margin-bottom:5px!important;border:1px solid transparent}
.v9-nav-link:hover{background:#111827!important;color:white!important;border-color:#334155}
.v9-nav-link.active{background:linear-gradient(135deg,#1d4ed8,#2563eb)!important;color:white!important;border-color:#60a5fa;box-shadow:0 9px 25px rgba(37,99,235,.22)}
.v9-nav-icon{display:grid;place-items:center;width:27px;height:27px;border-radius:8px;background:#111827;border:1px solid #334155;font-size:12px;font-weight:800;flex:0 0 auto}
.v9-nav-link.active .v9-nav-icon{background:rgba(2,6,23,.28);border-color:rgba(255,255,255,.28)}
.v9-nav-foot{position:absolute;left:14px;right:14px;bottom:14px;border-top:1px solid #1e293b;padding-top:12px;color:#64748b;font-size:12px;display:flex;flex-direction:column;gap:4px}
main{margin-left:210px;padding:92px 26px 30px 26px;max-width:1700px}
.v9-hero{display:flex;justify-content:space-between;gap:20px;align-items:flex-start;margin-bottom:18px;padding:20px 22px;border:1px solid #334155;border-radius:16px;background:linear-gradient(135deg,#111827,#0b1220)}
.v9-hero h1{margin:0 0 7px;font-size:29px}
.v9-hero p{margin:0;color:#94a3b8;max-width:850px;line-height:1.5}
.v9-hero-badge{border-radius:999px;padding:7px 11px;background:#172554;color:#bfdbfe;border:1px solid #1d4ed8;font-size:12px;font-weight:700;white-space:nowrap}
.v9-dashboard-grid{display:grid;grid-template-columns:repeat(2,minmax(280px,1fr));gap:16px}
.v9-status-card{background:#111827;border:1px solid #334155;border-radius:15px;padding:18px;min-height:150px;display:flex;flex-direction:column}
.v9-status-card h2{margin:0 0 5px;font-size:19px}
.v9-status-card .v9-card-sub{color:#94a3b8;font-size:13px;margin-bottom:14px}
.v9-status-list{display:grid;grid-template-columns:minmax(120px,.7fr) 1.3fr;gap:8px 13px;font-size:14px}
.v9-status-list .label{color:#94a3b8}
.v9-status-card .v9-card-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:auto;padding-top:16px}
.v9-link-button{display:inline-flex;align-items:center;justify-content:center;background:#2563eb;color:white!important;text-decoration:none;border-radius:9px;padding:9px 13px;font-size:13px;font-weight:700}
.v9-link-button.secondary{background:#1e293b;border:1px solid #475569}
.v9-tabs-shell{background:#0b1220;border:1px solid #334155;border-radius:16px;overflow:hidden}
.v9-tabs{display:flex;gap:6px;flex-wrap:wrap;padding:12px;background:#111827;border-bottom:1px solid #334155}
.v9-tab-button{background:#1e293b;border:1px solid #334155;color:#cbd5e1;padding:9px 13px;border-radius:9px;margin:0}
.v9-tab-button:hover{background:#263449}
.v9-tab-button.active{background:#2563eb;border-color:#60a5fa;color:white}
.v9-tab-tools{margin-left:auto;display:flex;gap:7px}
.v9-frame-panel{display:none;background:#0f172a}
.v9-frame-panel.active{display:block}
.v9-workspace-frame{display:block;width:100%;height:calc(100vh - 225px);min-height:620px;border:0;background:#0f172a}
.v9-native-panel{padding:18px;min-height:620px}
.v9-context-strip{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:-4px 0 14px;padding:10px 13px;border:1px solid #334155;border-radius:10px;background:#0b1220;color:#94a3b8;font-size:13px}
.v9-context-strip a{color:#93c5fd;text-decoration:none;font-weight:700}
body.v9-embedded{background:#0f172a}
body.v9-embedded header,body.v9-embedded .v9-sidebar{display:none!important}
body.v9-embedded main{margin:0!important;padding:12px!important;max-width:none!important}
body.v9-embedded .v9-context-strip{display:none!important}
body.v9-embedded .card:first-child{margin-top:0}
@media(max-width:900px){
  .v9-sidebar{width:74px;padding:14px 9px}
  .v9-nav-link span:last-child,.v9-nav-label,.v9-nav-foot{display:none}
  .v9-nav-link{justify-content:center;padding:9px!important}
  main{margin-left:74px;padding-left:14px;padding-right:14px}
  .v9-dashboard-grid{grid-template-columns:1fr}
  .v9-hero{flex-direction:column}
}
"""
    document = document.replace("</style></head>", v9_css + "\n</style></head>", 1)

    v9_js = r"""
<script>
(function(){
  const params=new URLSearchParams(location.search);
  const embedded=(window.self!==window.top)||params.get('embed')==='1';
  if(embedded) document.body.classList.add('v9-embedded');

  const path=location.pathname;
  let workspace='dashboard';
  if(path==='/connectivity'||['/wifi','/network','/zerotier','/endpoints','/wifilink2'].includes(path)) workspace='connectivity';
  else if(path==='/media'||['/video','/camera_controls','/unigcs_controls','/camera_sd'].includes(path)) workspace='media';
  else if(path==='/aircraft'||['/operations','/mavlink','/buttons','/flaps','/parameters'].includes(path)) workspace='aircraft';
  else if(path==='/system'||['/logs','/software_update','/first_setup','/cpu_temp_voice'].includes(path)) workspace='system';
  document.querySelectorAll('.v9-nav-link').forEach(a=>a.classList.toggle('active',a.dataset.workspace===workspace));

  if(embedded){
    const topMap={
      '/wifi':'/connectivity?tab=pi',
      '/network':'/connectivity?tab=pi',
      '/wifilink2':'/connectivity?tab=airlink',
      '/zerotier':'/connectivity?tab=remote',
      '/endpoints':'/connectivity?tab=hosts',
      '/video':'/media?tab=video',
      '/camera_controls':'/media?tab=siyi-camera',
      '/unigcs_controls':'/media?tab=siyi-camera',
      '/camera_sd':'/media?tab=storage',
      '/mavlink':'/aircraft?tab=mavlink',
      '/buttons':'/aircraft?tab=buttons',
      '/flaps':'/aircraft?tab=flaps',
      '/parameters':'/aircraft?tab=parameters',
      '/logs':'/system?tab=diagnostics',
      '/software_update':'/system?tab=update'
    };
    document.addEventListener('click',event=>{
      const link=event.target.closest('a[href]');
      if(!link||link.target==='_blank')return;
      let url;
      try{url=new URL(link.href,location.origin)}catch(_e){return}
      if(url.origin===location.origin&&topMap[url.pathname]){
        event.preventDefault();
        window.top.location.href=topMap[url.pathname];
      }
    });
  }

  if(!embedded && !['/','/connectivity','/media','/aircraft','/system'].includes(path)){
    const labels={
      '/wifi':['Connectivity','Pi Wi-Fi','/connectivity?tab=pi'],
      '/zerotier':['Connectivity','Remote access','/connectivity?tab=remote'],
      '/endpoints':['Connectivity','Hosts & routing','/connectivity?tab=hosts'],
      '/wifilink2':['Connectivity','Air Link','/connectivity?tab=airlink'],
      '/video':['Cameras & Video','Video sources','/media?tab=video'],
      '/camera_controls':['Cameras & Video','SIYI camera','/media?tab=siyi-camera'],
      '/camera_sd':['Cameras & Video','Camera storage','/media?tab=storage'],
      '/mavlink':['Aircraft','MAVLink','/aircraft?tab=mavlink'],
      '/buttons':['Aircraft','Button mapping','/aircraft?tab=buttons'],
      '/flaps':['Aircraft','Flaps','/aircraft?tab=flaps'],
      '/parameters':['Aircraft','ArduPlane parameters','/aircraft?tab=parameters'],
      '/logs':['System','Diagnostics','/system?tab=diagnostics'],
      '/software_update':['System','Software update','/system?tab=update']
    };
    if(labels[path]){
      const [group,item,back]=labels[path];
      const strip=document.createElement('div');strip.className='v9-context-strip';
      strip.innerHTML='<span>'+group+' / <b style="color:#e2e8f0">'+item+'</b></span><a href="'+back+'">Back to '+group+'</a>';
      const main=document.querySelector('main');if(main)main.prepend(strip);
    }
  }

  const wl2Mode=params.get('workspace');
  if(wl2Mode && typeof activateWl2Tab==='function'){
    const hide=(selector)=>document.querySelectorAll(selector).forEach(el=>el.style.display='none');
    const head=document.querySelector('.wl2-head h1');
    const desc=document.querySelector('.wl2-head .small');
    if(wl2Mode==='camera'){
      hide(".wl2-tabbtn:not([data-tab='camera'])");
      hide(".wl2-tabpanel:not([data-panel='camera'])");
      const tabs=document.querySelector('.wl2-tabs');if(tabs)tabs.style.display='none';
      if(head)head.textContent='Air Link Camera';
      if(desc)desc.textContent='Onboard camera image controls and active values.';
      activateWl2Tab('camera');
    }else if(wl2Mode==='connectivity'){
      hide(".wl2-tabbtn[data-tab='camera']");
      hide(".wl2-tabpanel[data-panel='camera']");
      if(head)head.textContent='Air Link Connectivity';
      if(desc)desc.textContent='Wi-Fi profiles, link credentials and device diagnostics.';
      const requested=(location.hash||'').replace('#','');
      activateWl2Tab(['wifi','device','diagnostics'].includes(requested)?requested:'wifi');
    }
  }
})();
</script>
"""
    document = document.replace("</body>", v9_js + "\n</body>", 1)
    return document


def _v9_redirect_response(handler, location):
    handler.send_response(303)
    handler.send_header("Location", location)
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()


def _v9_is_embedded(handler, query):
    if str(query.get("embed") or "") == "1":
        return True
    return str(handler.headers.get("Sec-Fetch-Dest") or "").lower() == "iframe"


def _v9_safe_text(value, fallback="Unavailable"):
    text = str(value or "").strip()
    return text if text else fallback


def _v9_action_summary(value, fallback):
    text = str(value or "").replace("\\n", " ").replace("\r", " ").replace("\n", " ")
    text = " ".join(text.split())
    if not text:
        return fallback
    return text if len(text) <= 180 else text[:177].rstrip() + "..."


def _v9_dashboard_page():
    cfg = video_source_read_config()
    status = video_source_read_status()
    source_names = video_source_names(cfg)
    active_id = str(cfg.get("source") or "siyi_rtsp")
    active_name = source_names.get(active_id, active_id)
    video_state = _v9_safe_text(status.get("state") or status.get("status"), "Unknown")
    pi_ssid = _v9_safe_text(sh("iwgetid -r 2>/dev/null || true"), "Not connected")
    pi_ip = _v9_safe_text(sh("hostname -I 2>/dev/null | awk '{print $1}'"), "Unavailable")
    zt_ip = _v9_safe_text(zt_current_ip(), "Unavailable")

    wl_ssid = "Unavailable"
    wl_signal = "Unavailable"
    wl_rtsp = "Unknown"
    try:
        inv = _wl2_native_wifi_inventory()
        runtime = _wl2_device_runtime_summary()
        wl_ssid = _v9_safe_text(inv.get("active_ssid"), "Not connected")
        if isinstance(inv.get("signal_dbm"), (int, float)):
            pct = inv.get("signal_percent")
            wl_signal = f"{int(inv['signal_dbm'])} dBm" + (f" · {pct}%" if isinstance(pct, int) else "")
        wl_rtsp = _v9_safe_text(runtime.get("rtsp_state"), "Unknown").title()
    except Exception:
        pass

    mode = "Unavailable"
    try:
        mode_data = flight_mode_state_read_once()
        mode = _v9_safe_text(mode_data.get("mode") if isinstance(mode_data, dict) else "", "Unavailable")
    except Exception:
        pass

    last_action = _v9_action_summary(read_file("/tmp/siyi_webui_last_action"), "No recent system action")
    wl_action = _v9_action_summary(read_file("/tmp/siyi_wifilink2_last_action"), "No recent Air Link action")

    return f"""
<div class='v9-hero'>
  <div><h1>System overview</h1><p>One starting point for connectivity, cameras, aircraft controls and system maintenance. Existing backend functions are unchanged.</p></div>
  <span class='v9-hero-badge'>Control Center 4.1.0</span>
</div>
<div class='v9-dashboard-grid'>
  <section class='v9-status-card'>
    <h2>Connectivity</h2><div class='v9-card-sub'>Raspberry Pi, Air Link and remote access</div>
    <div class='v9-status-list'>
      <span class='label'>Pi Wi-Fi</span><b>{esc(pi_ssid)}</b>
      <span class='label'>Pi address</span><span>{esc(pi_ip)}</span>
      <span class='label'>Air Link network</span><b>{esc(wl_ssid)}</b>
      <span class='label'>Air Link signal</span><span>{esc(wl_signal)}</span>
      <span class='label'>ZeroTier address</span><span>{esc(zt_ip)}</span>
    </div>
    <div class='v9-card-actions'><a class='v9-link-button' href='/connectivity'>Open Connectivity</a></div>
  </section>

  <section class='v9-status-card'>
    <h2>Cameras &amp; Video</h2><div class='v9-card-sub'>Active source, output and onboard cameras</div>
    <div class='v9-status-list'>
      <span class='label'>Active source</span><b>{esc(active_name)}</b>
      <span class='label'>Video state</span><span>{esc(video_state)}</span>
      <span class='label'>QGC URL</span><span>rtsp://{esc(pi_ip)}:8554/main.264</span>
      <span class='label'>Air Link RTSP</span><span>{esc(wl_rtsp)}</span>
    </div>
    <div class='v9-card-actions'><a class='v9-link-button' href='/media'>Open Cameras &amp; Video</a></div>
  </section>

  <section class='v9-status-card'>
    <h2>Aircraft</h2><div class='v9-card-sub'>Operational controls and flight configuration</div>
    <div class='v9-status-list'>
      <span class='label'>Flight mode</span><b>{esc(mode)}</b>
      <span class='label'>Battery</span><span>{esc(battery_status())}</span>
      <span class='label'>Controls</span><span>Buttons, flaps and parameters</span>
      <span class='label'>Operations</span><span>Service restart controls</span>
    </div>
    <div class='v9-card-actions'><a class='v9-link-button' href='/aircraft'>Open Aircraft</a><a class='v9-link-button secondary' href='/aircraft?tab=operations'>Operations</a></div>
  </section>

  <section class='v9-status-card'>
    <h2>System</h2><div class='v9-card-sub'>Health, diagnostics and software lifecycle</div>
    <div>{system_summary()}</div>
    <div class='v9-status-list' style='margin-top:14px'>
      <span class='label'>Last system action</span><span>{esc(last_action)}</span>
      <span class='label'>Last Air Link action</span><span>{esc(wl_action)}</span>
    </div>
    <div class='v9-card-actions'><a class='v9-link-button' href='/system'>Open System</a><a class='v9-link-button secondary' href='/system?tab=diagnostics'>Diagnostics</a></div>
  </section>
</div>
"""


def _v9_workspace_page(title, description, tabs, active):
    valid_ids = [item["id"] for item in tabs]
    if active not in valid_ids:
        active = valid_ids[0]
    buttons = []
    panels = []
    for item in tabs:
        item_id = item["id"]
        selected = item_id == active
        buttons.append(
            "<button type='button' class='v9-tab-button" + (" active" if selected else "") +
            "' data-v9-tab='" + esc(item_id) + "'>" + esc(item["label"]) + "</button>"
        )
        if item.get("html") is not None:
            content = "<div class='v9-native-panel'>" + str(item["html"]) + "</div>"
        else:
            src = str(item.get("src") or "")
            content = (
                "<iframe class='v9-workspace-frame' title='" + esc(item["label"]) +
                "' data-src='" + esc(src) + "'" +
                (" src='" + esc(src) + "'" if selected else "") +
                " loading='eager'></iframe>"
            )
        panels.append(
            "<section class='v9-frame-panel" + (" active" if selected else "") +
            "' data-v9-panel='" + esc(item_id) + "'>" + content + "</section>"
        )

    return f"""
<div class='v9-hero'>
  <div><h1>{esc(title)}</h1><p>{esc(description)}</p></div>
  <span class='v9-hero-badge'>Unified workspace</span>
</div>
<div class='v9-tabs-shell'>
  <div class='v9-tabs'>{''.join(buttons)}
    <div class='v9-tab-tools'><button type='button' class='v9-tab-button' id='v9-refresh-tab'>Reload current tab</button></div>
  </div>
  {''.join(panels)}
</div>
<script>
(function(){{
  const buttons=[...document.querySelectorAll('[data-v9-tab]')];
  const panels=[...document.querySelectorAll('[data-v9-panel]')];
  function selectTab(id,update=true){{
    if(!buttons.some(b=>b.dataset.v9Tab===id))id={__import__('json').dumps(active)};
    buttons.forEach(b=>b.classList.toggle('active',b.dataset.v9Tab===id));
    panels.forEach(panel=>{{
      const on=panel.dataset.v9Panel===id;panel.classList.toggle('active',on);
      if(on){{
        const frame=panel.querySelector('iframe[data-src]');
        if(frame&&!frame.getAttribute('src'))frame.setAttribute('src',frame.dataset.src);
      }}
    }});
    if(update){{
      const url=new URL(location.href);url.searchParams.set('tab',id);history.replaceState(null,'',url);
      try{{localStorage.setItem('siyi-workspace-'+location.pathname,id)}}catch(_e){{}}
    }}
  }}
  buttons.forEach(b=>b.addEventListener('click',()=>selectTab(b.dataset.v9Tab)));
  document.getElementById('v9-refresh-tab').addEventListener('click',()=>{{
    const panel=document.querySelector('.v9-frame-panel.active');const frame=panel&&panel.querySelector('iframe');
    if(frame)frame.contentWindow.location.reload();
    else location.reload();
  }});
  let requested=new URLSearchParams(location.search).get('tab');
  if(!requested){{try{{requested=localStorage.getItem('siyi-workspace-'+location.pathname)}}catch(_e){{}}}}
  selectTab(requested||{__import__('json').dumps(active)},false);
}})();
</script>
"""


def _v9_connectivity_page(active):
    tabs = [
        {"id":"pi","label":"Pi Wi-Fi","src":"/wifi?embed=1"},
        {"id":"airlink","label":"Air Link","src":"/wifilink2?embed=1&workspace=connectivity#wifi"},
        {"id":"remote","label":"Remote access","src":"/zerotier?embed=1"},
        {"id":"hosts","label":"Hosts & routing","src":"/endpoints?embed=1"},
    ]
    return _v9_workspace_page(
        "Connectivity",
        "All network configuration in one place: Raspberry Pi Wi-Fi, Air Link profiles, ZeroTier and destination hosts.",
        tabs, active,
    )


def _v9_media_page(active):
    tabs = [
        {"id":"video","label":"Video output & sources","src":"/video?embed=1"},
        {"id":"siyi-camera","label":"SIYI Camera","src":"/camera_controls?embed=1"},
        {"id":"airlink-camera","label":"Air Link Camera","src":"/wifilink2?embed=1&workspace=camera#camera"},
        {"id":"storage","label":"Camera storage","src":"/camera_sd?embed=1"},
    ]
    return _v9_workspace_page(
        "Cameras & Video",
        "Video selection, stream routing, both camera-control surfaces and camera storage in one workspace.",
        tabs, active,
    )


def _v9_aircraft_page(active):
    tabs = [
        {"id":"operations","label":"Operations","src":"/operations?embed=1"},
        {"id":"mavlink","label":"MAVLink","src":"/mavlink?embed=1"},
        {"id":"buttons","label":"Buttons","src":"/buttons?embed=1"},
        {"id":"flaps","label":"Flaps","src":"/flaps?embed=1"},
        {"id":"parameters","label":"Parameters","src":"/parameters?embed=1"},
    ]
    return _v9_workspace_page(
        "Aircraft",
        "Operational controls, telemetry routing, button actions, flap control and ArduPlane parameters.",
        tabs, active,
    )


def _v9_system_overview():
    return f"""
<div class='card'>
  <h2>System health</h2>
  {system_summary()}
  <p class='small'>The service controls below are the existing live controls. This UI patch does not change service definitions.</p>
  <table><tr><th>Service</th><th>Status</th><th>Action</th></tr>{service_rows()}</table>
</div>
<div class='card'>
  <h2>UI rollback</h2>
  <p>This workspace layout is backed up before installation. Use the supplied Mac rollback script to restore the exact previous V8 interface.</p>
</div>
"""


def _v9_system_page(active):
    tabs = [
        {"id":"health","label":"Health & services","html":_v9_system_overview()},
        {"id":"diagnostics","label":"Diagnostics","src":"/logs?embed=1"},
        {"id":"update","label":"Software update","src":"/software_update?embed=1"},
    ]
    if not setup_is_complete():
        tabs.append({"id":"setup","label":"Setup wizard","src":"/first_setup?embed=1"})
    return _v9_workspace_page(
        "System",
        "Service health, diagnostics, updates and setup—kept separate from flight and media configuration.",
        tabs, active,
    )


def _v9_send_workspace(handler, title, body):
    raw = page(title, setup_banner() + body).encode("utf-8")
    handler.send_response(200)
    handler.send_header("Content-Type", "text/html; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def _v9_do_GET(self):
    parsed = urllib.parse.urlparse(self.path)
    path = parsed.path
    query = dict(urllib.parse.parse_qsl(parsed.query, keep_blank_values=True))
    embedded = _v9_is_embedded(self, query)

    if software_update_lock_active():
        return _v9_previous_get(self)

    if path == "/":
        if setup_should_force():
            return _v9_redirect_response(self, "/first_setup")
        return _v9_send_workspace(self, "Overview", _v9_dashboard_page())

    if path == "/connectivity":
        return _v9_send_workspace(self, "Connectivity", _v9_connectivity_page(query.get("tab","pi")))
    if path == "/media":
        return _v9_send_workspace(self, "Cameras & Video", _v9_media_page(query.get("tab","video")))
    if path == "/aircraft":
        return _v9_send_workspace(self, "Aircraft", _v9_aircraft_page(query.get("tab","operations")))
    if path == "/system":
        return _v9_send_workspace(self, "System", _v9_system_page(query.get("tab","health")))

    if path == "/operations":
        if not embedded:
            return _v9_redirect_response(self, "/aircraft?tab=operations")
        old_path = self.path
        self.path = "/"
        try:
            return _v9_previous_get(self)
        finally:
            self.path = old_path

    legacy_map = {
        "/wifi": "/connectivity?tab=pi",
        "/network": "/connectivity?tab=pi",
        "/wifilink2": "/connectivity?tab=airlink",
        "/zerotier": "/connectivity?tab=remote",
        "/endpoints": "/connectivity?tab=hosts",
        "/video": "/media?tab=video",
        "/camera_controls": "/media?tab=siyi-camera",
        "/unigcs_controls": "/media?tab=siyi-camera",
        "/camera_sd": "/media?tab=storage",
        "/mavlink": "/aircraft?tab=mavlink",
        "/buttons": "/aircraft?tab=buttons",
        "/flaps": "/aircraft?tab=flaps",
        "/parameters": "/aircraft?tab=parameters",
        "/logs": "/system?tab=diagnostics",
        "/software_update": "/system?tab=update",
    }
    if path in legacy_map and not embedded and not query.get("workspace"):
        return _v9_redirect_response(self, legacy_map[path])

    exact_embedded_paths = set(legacy_map) | {"/first_setup"}
    if embedded and path in exact_embedded_paths and path != "/wifilink2":
        old_path = self.path
        self.path = path
        try:
            return _v9_previous_get(self)
        finally:
            self.path = old_path

    return _v9_previous_get(self)


H.do_GET = _v9_do_GET


def _wl2_redirect(handler, tab="wifi"):
    if tab == "camera":
        location = "/wifilink2?workspace=camera#camera"
    else:
        safe_tab = tab if tab in {"wifi", "device", "diagnostics"} else "wifi"
        location = "/wifilink2?workspace=connectivity#" + safe_tab
    handler.send_response(303)
    handler.send_header("Location", location)
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()

# CONTROL_CENTER_WORKSPACES_V9_END



# CONTROL_CENTER_HARMONIZATION_V10_START
# Unified service operations, harmonized Pi/Air Link Wi-Fi, and single-scroll workspace frames.

_v10_previous_page = page
_v10_previous_get = H.do_GET
_v10_previous_dashboard_page = _v9_dashboard_page


def _v10_nmcli_split(line):
    fields = []
    current = []
    escaped = False
    for char in str(line or ""):
        if escaped:
            current.append(char)
            escaped = False
        elif char == "\\":
            escaped = True
        elif char == ":":
            fields.append("".join(current))
            current = []
        else:
            current.append(char)
    if escaped:
        current.append("\\")
    fields.append("".join(current))
    return fields


def _v10_pi_wifi_scan(refresh=False):
    def read_scan():
        raw = sh("nmcli -t -f IN-USE,SSID,SIGNAL,SECURITY dev wifi list ifname wlan0 2>/dev/null")
        networks = {}
        for raw_line in raw.splitlines():
            parts = _v10_nmcli_split(raw_line)
            if len(parts) < 4:
                continue
            in_use = parts[0]
            ssid = parts[1].strip()
            signal_text = parts[2]
            security = parts[3].strip()
            if not ssid or ssid == "--":
                continue
            try:
                signal = max(0, min(100, int(signal_text)))
            except Exception:
                signal = 0
            item = networks.get(ssid)
            if item is None or signal > item["signal"]:
                networks[ssid] = {
                    "ssid": ssid,
                    "signal": signal,
                    "security": "Open" if security in {"", "--"} else security,
                    "current": in_use.strip() == "*",
                }
            elif in_use.strip() == "*":
                item["current"] = True

        return sorted(
            networks.values(),
            key=lambda item: (
                not item["current"],
                -int(item["signal"]),
                item["ssid"].lower(),
            ),
        )

    if not refresh:
        return read_scan()

    # NetworkManager rescan is asynchronous. Waiting only one second can
    # return the currently connected SSID before the new scan is complete.
    before_stamp = sh(
        "nmcli -g GENERAL.LAST-SCAN device show wlan0 2>/dev/null || true"
    ).strip()
    sh(
        "timeout 12s sudo -n nmcli device wifi rescan ifname wlan0 "
        ">/dev/null 2>&1 || true"
    )

    deadline = time.monotonic() + 10.0
    best = read_scan()
    previous_signature = None
    stable_polls = 0

    while time.monotonic() < deadline:
        time.sleep(0.75)
        current = read_scan()
        if len(current) > len(best):
            best = current

        signature = tuple(
            (item.get("ssid"), item.get("signal"), item.get("security"))
            for item in current
        )
        if signature and signature == previous_signature:
            stable_polls += 1
        else:
            previous_signature = signature
            stable_polls = 0

        after_stamp = sh(
            "nmcli -g GENERAL.LAST-SCAN device show wlan0 2>/dev/null || true"
        ).strip()
        stamp_changed = bool(
            after_stamp
            and after_stamp not in {"0", "--"}
            and after_stamp != before_stamp
        )
        has_non_current = any(not item.get("current") for item in current)

        if stamp_changed:
            time.sleep(0.5)
            final = read_scan()
            return final if len(final) >= len(best) else best

        if has_non_current and stable_polls >= 1:
            return current if len(current) >= len(best) else best

    return best or read_scan()


def _v10_pi_wifi_current_signal_dbm():
    text = sh("iw dev wlan0 link 2>/dev/null | sed -n 's/^[[:space:]]*signal:[[:space:]]*\\(-\\?[0-9][0-9]*\\).*/\\1/p' | head -n1")
    try:
        return int(text.strip())
    except Exception:
        return None


def _v10_pi_wifi_inventory(refresh=False):
    scan = _v10_pi_wifi_scan(refresh=refresh)
    scan_map = {item["ssid"]: item for item in scan}

    active_ssid = sh("iwgetid -r 2>/dev/null || true").strip()
    active_conn = sh("nmcli -g GENERAL.CONNECTION dev show wlan0 2>/dev/null || true").strip()
    ip_address = sh("ip -4 -o addr show dev wlan0 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -n1").strip()
    manager_state = sh("systemctl is-active NetworkManager 2>/dev/null || true").strip() or "unknown"
    current_dbm = _v10_pi_wifi_current_signal_dbm()

    raw_profiles = sh("nmcli -t -f NAME,TYPE,DEVICE,AUTOCONNECT connection show 2>/dev/null")
    profiles = []
    for raw_line in raw_profiles.splitlines():
        parts = _v10_nmcli_split(raw_line)
        if len(parts) < 4:
            continue
        name, kind, device, autoconnect = parts[:4]
        if kind not in {"wifi", "802-11-wireless"}:
            continue

        quoted_name = shlex.quote(name)
        ssid = sh(
            "nmcli -g 802-11-wireless.ssid connection show "
            + quoted_name
            + " 2>/dev/null || true"
        ).strip()
        if not ssid and (name == active_conn or device == "wlan0"):
            ssid = active_ssid
        if not ssid:
            ssid = name

        priority_text = sh(
            "nmcli -g connection.autoconnect-priority connection show "
            + quoted_name
            + " 2>/dev/null || true"
        ).strip()
        try:
            priority = int(priority_text or "0")
        except Exception:
            priority = 0

        visible_item = scan_map.get(ssid) or {}
        current = bool(name == active_conn or device == "wlan0" or visible_item.get("current"))
        enabled = str(autoconnect).lower() == "yes"
        password = str(wifi_pw_get(name) or "")
        profiles.append(
            {
                "ssid": ssid,
                "name": name,
                "current": current,
                "enabled": enabled,
                "visible": bool(visible_item),
                "signal": int(visible_item.get("signal") or 0),
                "security": str(visible_item.get("security") or "Unknown"),
                "priority": priority,
                "password": password,
                "password_known": bool(password),
                "system": name.startswith("netplan-"),
            }
        )

    profiles.sort(
        key=lambda item: (
            not item["current"],
            not item["enabled"],
            -int(item["priority"]),
            item["ssid"].lower(),
        )
    )

    current_signal = None
    if active_ssid and active_ssid in scan_map:
        current_signal = int(scan_map[active_ssid].get("signal") or 0)

    return {
        "active_ssid": active_ssid,
        "active_connection": active_conn,
        "ip_address": ip_address,
        "manager_state": manager_state,
        "signal_percent": current_signal,
        "signal_dbm": current_dbm,
        "profiles": profiles,
        "scan": scan,
    }


def _v10_wifi_signal_bars(percent):
    try:
        value = max(0, min(100, int(percent)))
    except Exception:
        return "▯▯▯▯▯"
    filled = max(0, min(5, int(round(value / 20.0))))
    return "▮" * filled + "▯" * (5 - filled)


def _v10_pi_wifi_profile_card(item, index):
    current = bool(item.get("current"))
    visible = bool(item.get("visible"))
    enabled = bool(item.get("enabled"))
    system = bool(item.get("system"))
    signal = int(item.get("signal") or 0)

    if current:
        label, badge = "Connected", "active"
    elif not enabled:
        label, badge = "Disabled", "bad"
    elif visible:
        label, badge = "Available", "warn"
    else:
        label, badge = "Out of range", "inactive"

    signal_text = (
        _v10_wifi_signal_bars(signal) + " " + str(signal) + "%"
        if visible or current
        else "Not detected in the latest scan"
    )
    editor_id = "piwifi-editor-" + str(index)
    password_id = "piwifi-password-" + str(index)

    # SIYI_4_1_1_WIFI_SWITCH_UI_FIX_V3
    # Keep switching visible on the row. NetworkManager itself reports failure
    # if an inactive saved network is temporarily out of range.
    summary_connect_button = ""
    if not current and not system:
        summary_connect_button = (
            "<form method='post' action='/wifi_switch' class='piwifi-connect-form' "
            "data-piwifi-connect-form='1' "
            "onsubmit=\"const b=this.querySelector('button');b.disabled=true;b.textContent='Switching…';\">"
            "<input type='hidden' name='name' value='" + esc(item["name"]) + "'>"
            "<button type='submit' class='piwifi-connect-button'>Connect</button></form>"
        )

    if system:
        system_password = str(item.get("password") or "")
        system_password_known = bool(item.get("password_known"))
        editor = (
            "<div id='" + esc(editor_id) + "' class='piwifi-profile-editor'>"
            "<div class='piwifi-readonly'>This is a system-managed NetworkManager profile. "
            "Its password can be viewed, but profile editing and deletion remain disabled.</div>"
            "<div style='margin-top:12px'><label>Password</label><input id='" + esc(password_id)
            + "' type='password' autocomplete='off' readonly data-secret-state='"
            + ("known" if system_password_known else "unknown") + "' value='" + esc(system_password)
            + "' placeholder='" + ("Password unavailable" if not system_password_known else "")
            + "'><label class='small piwifi-checkbox'><input type='checkbox' "
            "onclick=\"document.getElementById('" + esc(password_id)
            + "').type=this.checked?'text':'password'\">Show password</label></div></div>"
        )
    else:
        connect_button = ""
        if visible and not current:
            connect_button = (
                "<form method='post' action='/wifi_switch'>"
                "<input type='hidden' name='name' value='" + esc(item["name"]) + "'>"
                "<button type='submit' class='piwifi-secondary'>Connect now</button></form>"
            )

        delete_button = ""
        if not current:
            delete_button = (
                "<form method='post' action='/wifi_delete' "
                "onsubmit=\"return confirm('Delete this Pi Wi-Fi profile?');\">"
                "<input type='hidden' name='name' value='" + esc(item["name"]) + "'>"
                "<button type='submit' class='danger'>Delete</button></form>"
            )

        editor = (
            "<div id='" + esc(editor_id) + "' class='piwifi-profile-editor'>"
            "<div class='grid'>"
            "<form method='post' action='/wifi_update' class='piwifi-editor-form'>"
            "<input type='hidden' name='name' value='" + esc(item["name"]) + "'>"
            "<div><label>Priority</label><input type='number' name='priority' value='"
            + esc(item["priority"]) + "'><div class='small'>Higher number is preferred.</div></div>"
            "<div><label>Automatic connection</label><select name='autoconnect'>"
            "<option value='yes'" + (" selected" if enabled else "") + ">Enabled</option>"
            "<option value='no'" + ("" if enabled else " selected") + ">Disabled</option>"
            "</select></div><div class='piwifi-form-actions'><button type='submit'>Save profile settings</button></div>"
            "</form>"
            "<form method='post' action='/wifi_update_password' class='piwifi-editor-form'>"
            "<input type='hidden' name='name' value='" + esc(item["name"]) + "'>"
            "<div style='grid-column:1/-1'><label>Password</label><input id='" + esc(password_id)
            + "' type='password' autocomplete='off' name='password' data-secret-state='"
            + ("known" if item.get("password_known") else "unknown") + "' value='" + esc(item.get("password") or "")
            + "' placeholder='" + ("Password unavailable — enter a new one" if not item.get("password_known") else "")
            + "'><label class='small piwifi-checkbox'><input type='checkbox' "
            "onclick=\"document.getElementById('" + esc(password_id)
            + "').type=this.checked?'text':'password'\">Show password</label></div>"
            "<div class='piwifi-form-actions'><button type='submit'>Update password</button></div>"
            "</form></div>"
            "<div class='piwifi-row-actions'>" + connect_button + delete_button + "</div></div>"
        )

    return (
        "<div class='piwifi-profile-row'>"
        "<div class='piwifi-profile-summary'><div>"
        "<div class='ssidtitle'>" + esc(item.get("ssid") or "(unknown)")
        + " <span class='pill " + esc(badge) + "'>" + esc(label) + "</span></div>"
        "<div class='ssidmeta'>" + esc(signal_text) + " · Priority " + esc(item.get("priority", 0))
        + " · " + esc(item.get("name") or "") + "</div></div>"
        "<div class='piwifi-profile-summary-actions'>" + summary_connect_button
        + "<button type='button' class='piwifi-secondary' data-system='" + ("1" if system else "0") + "' "
        "onclick=\"togglePiWifiEditor('" + esc(editor_id) + "',this)\">"
        + ("Details" if system else "Edit") + "</button></div></div>"
        + editor + "</div>"
    )


def _v10_pi_wifi_nearby_html(networks, configured_ssids):
    if not networks:
        return "<p class='small'>No nearby networks were returned by NetworkManager.</p>"

    networks = sorted(
        networks,
        key=lambda item: (
            str(item.get("ssid") or "") in configured_ssids,
            not bool(item.get("current")),
            -int(item.get("signal") or 0),
            str(item.get("ssid") or "").lower(),
        ),
    )

    rows = []
    for item in networks:
        ssid = str(item.get("ssid") or "")
        configured = ssid in configured_ssids
        action = (
            "<span class='pill active'>Configured</span>"
            if configured else
            "<button type='button' class='piwifi-secondary' data-piwifi-add='"
            + esc(ssid) + "' data-piwifi-open='" + ("1" if str(item.get("security")) == "Open" else "0")
            + "'>Add</button>"
        )
        status = "Connected · " if item.get("current") else ""
        rows.append(
            "<div class='piwifi-nearby-row'><div><b>" + esc(ssid)
            + "</b><div class='small'>" + esc(status + _v10_wifi_signal_bars(item.get("signal"))
            + " " + str(item.get("signal") or 0) + "% · " + str(item.get("security") or "Unknown"))
            + "</div></div>" + action + "</div>"
        )
    return "".join(rows)


def _v10_pi_wifi_page():
    inventory = _v10_pi_wifi_inventory(refresh=False)
    profiles = inventory["profiles"]
    configured_ssids = {str(item.get("ssid") or "") for item in profiles}
    active_ssid = inventory.get("active_ssid") or "Not connected"
    active_ip = inventory.get("ip_address") or "Unavailable"
    active_signal = inventory.get("signal_percent")
    active_dbm = inventory.get("signal_dbm")

    signal_text = "Unavailable"
    if isinstance(active_signal, int):
        signal_text = _v10_wifi_signal_bars(active_signal) + " " + str(active_signal) + "%"
    if isinstance(active_dbm, int):
        signal_text += " · " + str(active_dbm) + " dBm"

    current_profile = next((item for item in profiles if item.get("current")), None)
    if current_profile:
        current_card = (
            "<div class='piwifi-current'><div><div class='ssidtitle'>"
            + esc(current_profile.get("ssid") or active_ssid)
            + " <span class='pill active'>Connected</span></div>"
            + "<div class='ssidmeta'>" + esc(signal_text)
            + " · " + esc(active_ip) + "</div></div>"
            + "<div class='small'>Priority " + esc(current_profile.get("priority", 0))
            + "</div></div>"
        )
    else:
        current_card = "<p class='bad'>The Raspberry Pi is not currently connected through wlan0.</p>"

    profile_html = "".join(
        _v10_pi_wifi_profile_card(item, index)
        for index, item in enumerate(profiles)
    ) or "<p class='small'>No saved Pi Wi-Fi profiles were found.</p>"

    nearby_html = _v10_pi_wifi_nearby_html(inventory["scan"], configured_ssids)
    visible_count = len(inventory["scan"])
    addable_count = sum(
        1
        for item in inventory["scan"]
        if str(item.get("ssid") or "") not in configured_ssids
    )
    scan_summary = (
        str(addable_count)
        + " available to add · "
        + str(visible_count)
        + " visible total"
    )
    last_action = sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true").strip()
    action_html = (
        "<div class='piwifi-notice'>" + esc(last_action[:1200]) + "</div>"
        if last_action else ""
    )

    return f"""
    <div data-siyi-wifi-switch-ui-fix-v3='1' hidden></div>
    <div class='piwifi-head'>
      <div><h1>Pi Wi-Fi</h1><div class='small'>NetworkManager profiles used by the Raspberry Pi control system.</div></div>
      <a class='piwifi-link-button piwifi-secondary' href='/connectivity?tab=airlink' target='_top'>Open Air Link Wi-Fi</a>
    </div>

    <div class='piwifi-summary'>
      <div class='piwifi-kpi'><div class='piwifi-kpi-label'>Connection</div><div class='piwifi-kpi-value'>{esc(active_ssid)}</div></div>
      <div class='piwifi-kpi'><div class='piwifi-kpi-label'>Signal</div><div class='piwifi-kpi-value'>{esc(signal_text)}</div></div>
      <div class='piwifi-kpi'><div class='piwifi-kpi-label'>wlan0 address</div><div class='piwifi-kpi-value'>{esc(active_ip)}</div></div>
      <div class='piwifi-kpi'><div class='piwifi-kpi-label'>NetworkManager</div><div class='piwifi-kpi-value'>{esc(str(inventory.get('manager_state') or 'unknown').title())}</div></div>
    </div>

    {action_html}

    <div class='card'><div class='piwifi-card-title'><h2>Current connection</h2></div>{current_card}</div>

    <div class='card'>
      <div class='piwifi-section-head'><div><h2>Configured networks</h2><div class='small'>Profiles stored on the Pi. Higher priority is preferred.</div></div>
      <button type='button' onclick='openPiWifiAdd()'>+ Add Wi-Fi network</button></div>
      <div style='margin-top:14px'>{profile_html}</div>
    </div>

    <div class='card'>
      <div class='piwifi-section-head'><div><h2>Nearby networks</h2><div class='small'>Fresh scan from the Raspberry Pi wireless adapter. Networks available to add are shown first.</div></div>
      <button id='piwifiScanButton' type='button' class='piwifi-secondary' onclick='refreshPiWifiNetworks(this)'>Scan networks</button></div>
      <div id='piwifiScanSummary' class='small' style='margin-top:10px'>{esc(scan_summary)}</div>
      <div id='piwifiNearbyNetworks' style='margin-top:6px'>{nearby_html}</div>
    </div>

    <div id='piwifiAddModal' class='piwifi-modal' aria-hidden='true'>
      <div class='piwifi-modal-dialog'>
        <div class='piwifi-modal-head'><h2>Add Pi Wi-Fi network</h2><button type='button' class='piwifi-close' onclick='closePiWifiAdd()'>×</button></div>
        <p class='small'>The profile is saved without forcing the Pi to disconnect from its current network.</p>
        <form method='post' action='/wifi_add'>
          <div class='grid'>
            <div><label>SSID</label><input id='piwifi-new-ssid' name='ssid' maxlength='32' required></div>
            <div><label>Password</label><input id='piwifi-new-pass' name='password' type='password' autocomplete='new-password' data-secret-state='new' required>
              <label class='small piwifi-checkbox'><input type='checkbox' onclick="document.getElementById('piwifi-new-pass').type=this.checked?'text':'password'">Show password</label>
            </div>
            <div><label>Priority</label><input name='priority' type='number' value='10'></div>
            <div><label>Automatic connection</label><select name='autoconnect'><option value='yes' selected>Enabled</option><option value='no'>Disabled</option></select></div>
          </div>
          <div class='piwifi-form-actions'><button type='submit'>Save network</button><button type='button' class='piwifi-secondary' onclick='closePiWifiAdd()'>Cancel</button></div>
        </form>
      </div>
    </div>

    <script>
    const configuredPiWifiSsids=new Set({json.dumps(sorted(configured_ssids), ensure_ascii=False)});
    function togglePiWifiEditor(id,button){{
      const editor=document.getElementById(id);const open=editor.classList.toggle('open');button.textContent=open?'Close':(button.dataset.system==='1'?'Details':'Edit');
      window.dispatchEvent(new Event('resize'));
    }}
    function openPiWifiAdd(ssid=''){{
      document.getElementById('piwifi-new-ssid').value=ssid||'';
      document.getElementById('piwifiAddModal').classList.add('open');
      document.getElementById('piwifiAddModal').setAttribute('aria-hidden','false');
      setTimeout(()=>document.getElementById(ssid?'piwifi-new-pass':'piwifi-new-ssid').focus(),50);
    }}
    function closePiWifiAdd(){{
      document.getElementById('piwifiAddModal').classList.remove('open');
      document.getElementById('piwifiAddModal').setAttribute('aria-hidden','true');
    }}
    document.getElementById('piwifiAddModal').addEventListener('click',event=>{{if(event.target.id==='piwifiAddModal')closePiWifiAdd();}});
    document.querySelectorAll('[data-piwifi-add]').forEach(button=>button.addEventListener('click',()=>openPiWifiAdd(button.dataset.piwifiAdd||'')));
    let piWifiScanRunning=false;
    async function refreshPiWifiNetworks(button){{
      if(piWifiScanRunning)return;
      piWifiScanRunning=true;
      const target=document.getElementById('piwifiNearbyNetworks');
      const summary=document.getElementById('piwifiScanSummary');
      const old=button?button.textContent:'Scan networks';
      if(button){{button.disabled=true;button.textContent='Scanning…';}}
      if(summary)summary.textContent='Scanning… this can take several seconds.';
      try{{
        const response=await fetch('/wifi/api/scan?ts='+Date.now(),{{cache:'no-store'}});
        const data=await response.json();
        if(data.error)throw new Error(data.error);
        const networks=[...(data.networks||[])];
        networks.sort((a,b)=>{{
          const aConfigured=configuredPiWifiSsids.has(a.ssid||'')?1:0;
          const bConfigured=configuredPiWifiSsids.has(b.ssid||'')?1:0;
          return aConfigured-bConfigured
            || Number(Boolean(b.current))-Number(Boolean(a.current))
            || Number(b.signal||0)-Number(a.signal||0)
            || String(a.ssid||'').localeCompare(String(b.ssid||''));
        }});
        target.innerHTML='';
        let addable=0;
        networks.forEach(item=>{{
          const row=document.createElement('div');row.className='piwifi-nearby-row';
          const info=document.createElement('div');
          const title=document.createElement('b');title.textContent=item.ssid||'(hidden)';
          const meta=document.createElement('div');meta.className='small';
          meta.textContent=(item.current?'Connected · ':'')+String(item.signal||0)+'% · '+String(item.security||'Unknown');
          info.append(title,meta);
          let action;
          if(configuredPiWifiSsids.has(item.ssid||'')){{
            action=document.createElement('span');
            action.className='pill active';
            action.textContent='Configured';
          }}else{{
            addable+=1;
            action=document.createElement('button');
            action.type='button';
            action.className='piwifi-secondary';
            action.textContent='Add';
            action.onclick=()=>openPiWifiAdd(item.ssid||'');
          }}
          row.append(info,action);
          target.appendChild(row);
        }});
        if(!networks.length)target.innerHTML='<p class="small">No nearby networks were returned.</p>';
        if(summary)summary.textContent=String(addable)+' available to add · '+String(networks.length)+' visible total';
      }}catch(error){{
        target.innerHTML='<p class="bad"></p>';
        target.querySelector('p').textContent='Scan failed: '+error.message;
        if(summary)summary.textContent='Scan failed.';
      }}finally{{
        piWifiScanRunning=false;
        if(button){{button.disabled=false;button.textContent=old;}}
        window.dispatchEvent(new Event('resize'));
      }}
    }}
    setTimeout(()=>{{
      const button=document.getElementById('piwifiScanButton');
      if(button)refreshPiWifiNetworks(button);
    }},250);
    </script>
    """


def _v10_service_operations_html():
    purposes = {
        "siyi-button-bridge": "Joystick and button actions sent to the aircraft.",
        "siyi-video-source": "Publishes the selected local or relayed video source.",
        "siyi-video-dual": "Maintains dual-source video support and forwarding.",
        "mediamtx": "RTSP routing and the fixed QGC video endpoint.",
        "mavlink-router": "Routes aircraft telemetry to configured destinations.",
        "zerotier-one": "Remote overlay connectivity for the Pi and Air Link.",
        "siyi-rec-proxy": "Camera recording proxy functions.",
        "siyi-rec-redirect": "Camera recording redirect functions.",
        "siyi-webui": "This control interface.",
    }

    rows = []
    for group, services in SERVICE_GROUPS.items():
        rows.append(
            "<tr class='v10-service-group'><td colspan='4'>" + esc(group) + "</td></tr>"
        )
        for service in services:
            active = sh("systemctl is-active " + shlex.quote(service) + " 2>/dev/null || true").strip() or "unknown"
            cls = "ok" if active == "active" else ("bad" if active == "failed" else "warn")
            label = SERVICE_LABELS.get(service, service)
            status_label = STATUS_LABELS.get(active, active.title())
            action_html = (
                "<form method='post' action='/restart'><input type='hidden' name='service' value='"
                + esc(service) + "'><button type='submit'>Restart</button></form>"
            )
            if service == "siyi-button-bridge":
                action_html += (
                    "<form method='post' action='/stop_bridge' style='margin-top:7px' "
                    "onsubmit=\"return confirm('Disable the Button Bridge service?')\">"
                    "<button type='submit' class='danger'>Disable</button></form>"
                )
            rows.append(
                "<tr><td><b>" + esc(label) + "</b><div class='small'>" + esc(service) + "</div></td>"
                "<td class='" + esc(cls) + "'><b>" + esc(status_label) + "</b><div class='small'>" + esc(active) + "</div></td>"
                "<td class='small'>" + esc(purposes.get(service, "System service.")) + "</td>"
                "<td>" + action_html + "</td></tr>"
            )

    return f"""
    <div class='v10-operations-head'>
      <div><h2>Operations &amp; services</h2><p class='small'>One authoritative page for operational restarts and service health. Aircraft configuration is kept in the Aircraft workspace.</p></div>
      <div>{system_summary()}</div>
    </div>
    <div class='card'>
      <table class='v10-service-table'>
        <tr><th>Service</th><th>Status</th><th>Purpose</th><th>Action</th></tr>
        {''.join(rows)}
      </table>
    </div>
    """


def _v9_aircraft_page(active):
    tabs = [
        {"id":"mavlink","label":"MAVLink","src":"/mavlink?embed=1"},
        {"id":"buttons","label":"Buttons","src":"/buttons?embed=1"},
        {"id":"flaps","label":"Flaps","src":"/flaps?embed=1"},
        {"id":"parameters","label":"Parameters","src":"/parameters?embed=1"},
    ]
    return _v9_workspace_page(
        "Aircraft",
        "Aircraft-facing telemetry, button actions, flap control and ArduPlane parameters. Service operations are maintained under System.",
        tabs, active if active in {"mavlink","buttons","flaps","parameters"} else "mavlink",
    )


def _v9_system_page(active):
    tabs = [
        {"id":"operations","label":"Operations & Services","html":_v10_service_operations_html()},
        {"id":"diagnostics","label":"Diagnostics","src":"/logs?embed=1"},
        {"id":"update","label":"Software update","src":"/software_update?embed=1"},
    ]
    if not setup_is_complete():
        tabs.append({"id":"setup","label":"Setup wizard","src":"/first_setup?embed=1"})
    valid = {item["id"] for item in tabs}
    return _v9_workspace_page(
        "System",
        "Operational restarts, service health, diagnostics, updates and setup in one workspace.",
        tabs, active if active in valid else "operations",
    )


def _v9_dashboard_page():
    html = _v10_previous_dashboard_page()
    html = html.replace(
        "<a class='v9-link-button secondary' href='/aircraft?tab=operations'>Operations</a>",
        "<a class='v9-link-button secondary' href='/system?tab=operations'>Operations &amp; Services</a>",
    )
    return html.replace("Control Center 4.1.0", "Control Center 4.1.0")


def _v9_workspace_page(title, description, tabs, active):
    valid_ids = [item["id"] for item in tabs]
    if active not in valid_ids:
        active = valid_ids[0]

    buttons = []
    panels = []
    for item in tabs:
        item_id = item["id"]
        selected = item_id == active
        buttons.append(
            "<button type='button' class='v9-tab-button" + (" active" if selected else "")
            + "' data-v9-tab='" + esc(item_id) + "'>" + esc(item["label"]) + "</button>"
        )
        if item.get("html") is not None:
            content = "<div class='v9-native-panel'>" + str(item["html"]) + "</div>"
        else:
            src = str(item.get("src") or "")
            content = (
                "<iframe class='v9-workspace-frame v10-auto-frame' title='" + esc(item["label"])
                + "' data-src='" + esc(src) + "' scrolling='no'"
                + (" src='" + esc(src) + "'" if selected else "")
                + " loading='eager'></iframe>"
            )
        panels.append(
            "<section class='v9-frame-panel" + (" active" if selected else "")
            + "' data-v9-panel='" + esc(item_id) + "'>" + content + "</section>"
        )

    return f"""
<div class='v9-hero'>
  <div><h1>{esc(title)}</h1><p>{esc(description)}</p></div>
  <span class='v9-hero-badge'>Unified workspace</span>
</div>
<div class='v9-tabs-shell'>
  <div class='v9-tabs'>{''.join(buttons)}
    <div class='v9-tab-tools'><button type='button' class='v9-tab-button' id='v9-refresh-tab'>Reload current tab</button></div>
  </div>
  {''.join(panels)}
</div>
<script>
(function(){{
  const buttons=[...document.querySelectorAll('[data-v9-tab]')];
  const panels=[...document.querySelectorAll('[data-v9-panel]')];
  const frameObservers=new WeakMap();
  const frameListeners=new WeakSet();

  function resizeWorkspaceFrame(frame){{
    if(!frame||!frame.contentDocument)return;
    try{{
      const doc=frame.contentDocument;
      doc.documentElement.style.overflow='hidden';
      if(doc.body)doc.body.style.overflow='hidden';
      const height=Math.max(
        doc.body?doc.body.scrollHeight:0,
        doc.documentElement?doc.documentElement.scrollHeight:0,
        480
      );
      frame.style.height=(height+4)+'px';
    }}catch(_error){{}}
  }}

  function attachWorkspaceDocument(frame){{
    try{{
      const previous=frameObservers.get(frame)||[];
      previous.forEach(observer=>{{try{{observer.disconnect()}}catch(_error){{}}}});
      const doc=frame.contentDocument;
      if(!doc||!doc.body)return;
      let resizePending=false;
      const scheduleResize=()=>{{
        if(resizePending)return;
        resizePending=true;
        requestAnimationFrame(()=>{{resizePending=false;resizeWorkspaceFrame(frame);}});
      }};
      resizeWorkspaceFrame(frame);
      const resizeObserver=new ResizeObserver(scheduleResize);
      resizeObserver.observe(doc.body);
      frameObservers.set(frame,[resizeObserver]);
      setTimeout(scheduleResize,250);
      setTimeout(scheduleResize,1000);
    }}catch(_error){{}}
  }}

  function bindWorkspaceFrame(frame){{
    if(!frame)return;
    if(!frameListeners.has(frame)){{
      frame.addEventListener('load',()=>attachWorkspaceDocument(frame));
      frameListeners.add(frame);
    }}
    if(frame.contentDocument&&frame.contentDocument.readyState==='complete')attachWorkspaceDocument(frame);
  }}

  function selectTab(id,update=true){{
    if(!buttons.some(button=>button.dataset.v9Tab===id))id={json.dumps(active)};
    buttons.forEach(button=>button.classList.toggle('active',button.dataset.v9Tab===id));
    panels.forEach(panel=>{{
      const on=panel.dataset.v9Panel===id;
      panel.classList.toggle('active',on);
      if(on){{
        const frame=panel.querySelector('iframe[data-src]');
        if(frame){{
          if(!frame.getAttribute('src'))frame.setAttribute('src',frame.dataset.src);
          bindWorkspaceFrame(frame);
          setTimeout(()=>resizeWorkspaceFrame(frame),100);
        }}
      }}
    }});
    if(update){{
      const url=new URL(location.href);url.searchParams.set('tab',id);history.replaceState(null,'',url);
      try{{localStorage.setItem('siyi-workspace-'+location.pathname,id)}}catch(_error){{}}
    }}
  }}

  buttons.forEach(button=>button.addEventListener('click',()=>selectTab(button.dataset.v9Tab)));
  document.querySelectorAll('iframe.v10-auto-frame').forEach(bindWorkspaceFrame);
  document.getElementById('v9-refresh-tab').addEventListener('click',()=>{{
    const panel=document.querySelector('.v9-frame-panel.active');
    const frame=panel&&panel.querySelector('iframe');
    if(frame)frame.contentWindow.location.reload();
    else location.reload();
  }});

  let requested=new URLSearchParams(location.search).get('tab');
  if(!requested){{try{{requested=localStorage.getItem('siyi-workspace-'+location.pathname)}}catch(_error){{}}}}
  selectTab(requested||{json.dumps(active)},false);
  window.addEventListener('resize',()=>document.querySelectorAll('iframe.v10-auto-frame').forEach(resizeWorkspaceFrame));
}})();
</script>
"""


def page(title, body):
    document = _v10_previous_page(title, body)
    v10_css = r"""
/* CONTROL_CENTER_HARMONIZATION_V10 */
.v9-workspace-frame{height:480px;min-height:480px;overflow:hidden;background:#0f172a}
.v9-frame-panel{overflow:visible}
.v9-native-panel{min-height:0}
body.v9-embedded,body.v9-embedded main{min-height:0!important}
.piwifi-head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:16px;flex-wrap:wrap}
.piwifi-head h1{margin:0}
.piwifi-link-button{display:inline-flex;align-items:center;justify-content:center;background:#2563eb;color:white!important;text-decoration:none;border-radius:9px;padding:9px 13px;font-size:13px;font-weight:700}
.piwifi-secondary{background:#1e293b!important;border:1px solid #475569!important;color:#e2e8f0!important}
.piwifi-summary{display:grid;grid-template-columns:repeat(4,minmax(150px,1fr));gap:12px;margin-bottom:16px}
.piwifi-kpi{background:#111827;border:1px solid #334155;border-radius:12px;padding:14px}
.piwifi-kpi-label{font-size:12px;color:#94a3b8;margin-bottom:6px}
.piwifi-kpi-value{font-size:16px;font-weight:800;word-break:break-word}
.piwifi-section-head,.piwifi-card-title{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
.piwifi-section-head h2,.piwifi-card-title h2{margin:0 0 4px}
.piwifi-profile-row{border:1px solid #334155;background:#0b1220;border-radius:12px;padding:14px;margin-top:10px}
/* SIYI_4_1_1_WIFI_SWITCH_UI_FIX_V3 */
.piwifi-profile-summary{display:flex;justify-content:space-between;align-items:center;gap:14px}
.piwifi-profile-summary-actions{display:flex;gap:9px;align-items:center;flex-wrap:wrap}.piwifi-profile-summary-actions form{margin:0}.piwifi-connect-button{background:#2563eb}
.piwifi-profile-editor{display:none;border-top:1px solid #334155;margin-top:12px;padding-top:13px}
.piwifi-profile-editor.open{display:block}
.piwifi-editor-form{display:grid;grid-template-columns:repeat(2,minmax(160px,1fr));gap:12px;border:1px solid #253247;border-radius:10px;padding:12px;margin-bottom:10px}
.piwifi-form-actions,.piwifi-row-actions{display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin-top:12px}
.piwifi-row-actions form{margin:0}
.piwifi-checkbox{display:flex;gap:7px;align-items:center;margin-top:7px}
.piwifi-checkbox input{width:auto}
.piwifi-readonly{padding:11px;border-radius:9px;background:#111827;border:1px solid #334155;color:#94a3b8}
.piwifi-current{display:flex;justify-content:space-between;align-items:center;gap:14px}
.piwifi-nearby-row{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:11px 0;border-bottom:1px solid #253247}
.piwifi-nearby-row:last-child{border-bottom:0}
.piwifi-notice{margin-bottom:14px;padding:10px 12px;border-radius:9px;background:#172554;border:1px solid #1d4ed8;color:#bfdbfe;font-size:13px}
.piwifi-modal{display:none;position:fixed;inset:0;background:rgba(2,6,23,.82);z-index:10000;align-items:center;justify-content:center;padding:20px}
.piwifi-modal.open{display:flex}
.piwifi-modal-dialog{width:min(760px,96vw);background:#111827;border:1px solid #475569;border-radius:14px;padding:18px;box-shadow:0 24px 80px rgba(0,0,0,.6)}
.piwifi-modal-head{display:flex;justify-content:space-between;align-items:center;gap:12px}
.piwifi-modal-head h2{margin:0}
.piwifi-close{background:transparent!important;border:0!important;font-size:27px!important;padding:0 5px!important}
.v10-operations-head{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;flex-wrap:wrap;margin-bottom:14px}
.v10-operations-head h2{margin:0 0 6px}
.v10-service-table td{vertical-align:middle}
.v10-service-table .v10-service-group td{padding-top:16px;color:#93c5fd;font-weight:800;background:#0b1220}
@media(max-width:900px){
  .piwifi-summary{grid-template-columns:repeat(2,minmax(140px,1fr))}
  .piwifi-editor-form{grid-template-columns:1fr}
}
@media(max-width:560px){
  .piwifi-summary{grid-template-columns:1fr}
  .piwifi-profile-summary,.piwifi-current{align-items:flex-start;flex-direction:column}
}
"""
    document = document.replace("</style></head>", v10_css + "\n</style></head>", 1)
    document = document.replace("Control Center 4.1.0", "Control Center 4.1.0")
    return document


def _v10_send_json(handler, payload, status=200):
    raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def _v10_do_GET(self):
    parsed = urllib.parse.urlparse(self.path)
    path = parsed.path
    query = dict(urllib.parse.parse_qsl(parsed.query, keep_blank_values=True))

    if path == "/wifi/api/scan":
        if software_update_lock_active():
            return _v10_previous_get(self)
        try:
            return _v10_send_json(self, {"networks": _v10_pi_wifi_scan(refresh=True), "error": ""})
        except Exception as exc:
            return _v10_send_json(self, {"networks": [], "error": str(exc)}, 500)

    if path == "/wifi":
        if software_update_lock_active():
            return _v10_previous_get(self)
        if not _v9_is_embedded(self, query):
            return _v9_redirect_response(self, "/connectivity?tab=pi")
        return _v9_send_workspace(self, "Pi Wi-Fi", _v10_pi_wifi_page())

    if path == "/operations":
        return _v9_redirect_response(self, "/system?tab=operations")

    return _v10_previous_get(self)


H.do_GET = _v10_do_GET

# CONTROL_CENTER_HARMONIZATION_V10_END


# CONTROL_CENTER_PASSWORD_PRESERVATION_V11
# Configured Pi Wi-Fi passwords use the local display store first and then
# NetworkManager's saved secret. New-network fields intentionally stay blank.
# Upgrade preservation also covers the password display store and MAVLink main.conf.



# PI_WIFI_FRESH_SCAN_V12
# Waits for NetworkManager's asynchronous scan to finish, refreshes when the
# page opens, and shows networks available to add before configured networks.




# BUTTON_CAMERA_WORKSPACE_V13_START

def _v13_buttons_assignment_rows():
    rows = read_button_rows()
    html_rows = []
    mapping = []
    for index, row in enumerate(rows):
        button = str(row.get("Button", ""))
        tap = str(row.get("Tap", "NO_ACTION") or "NO_ACTION")
        hold = str(row.get("Hold", "NO_ACTION") or "NO_ACTION")
        release_hold = str(row.get("ReleaseAfterHold", "NO_ACTION") or "NO_ACTION")
        release_tap = str(row.get("ReleaseAfterTap", "NO_ACTION") or "NO_ACTION")
        double_tap = str(row.get("DoubleTap", "NO_ACTION") or "NO_ACTION")
        notes = str(row.get("Notes", "") or "")
        mapping.append({
            "button": button,
            "Tap": tap,
            "Hold": hold,
            "ReleaseAfterHold": release_hold,
        })
        html_rows.append(
            "<tr data-v15-button-row='" + esc(button.upper()) + "'>"
            "<td class='v15-button-placeholder' data-v15-button='" + esc(button.upper()) + "'>"
            "<span class='v15-button-label'><span class='v15-button-led'></span><b>" + esc(button) + "</b></span>"
            "<input type='hidden' name='Button_" + str(index) + "' value='" + esc(button) + "'>"
            "<input type='hidden' name='ReleaseAfterTap_" + str(index) + "' value='" + esc(release_tap) + "'>"
            "<input type='hidden' name='DoubleTap_" + str(index) + "' value='" + esc(double_tap) + "'>"
            "<input type='hidden' name='Notes_" + str(index) + "' value='" + esc(notes) + "'>"
            "</td>"
            "<td>" + action_select("Tap_" + str(index), tap) + "</td>"
            "<td>" + action_select("Hold_" + str(index), hold) + "</td>"
            "<td class='v13-advanced-column'>" + action_select("ReleaseAfterHold_" + str(index), release_hold) + "</td>"
            "</tr>"
        )
    return rows, "".join(html_rows), mapping


def buttons_workspace_page():
    rows, assignment_rows, mapping = _v13_buttons_assignment_rows()
    bridge_state = sh(
        "systemctl is-active siyi-button-bridge.service 2>/dev/null || true"
    ).strip() or "unknown"
    bridge_class = "ok" if bridge_state == "active" else (
        "bad" if bridge_state == "failed" else "warn"
    )
    try:
        mode_payload = flight_mode_state_read_once()
        current_mode = str(
            mode_payload.get("mode")
            or mode_payload.get("flight_mode")
            or "Unavailable"
        ) if isinstance(mode_payload, dict) else "Unavailable"
    except Exception:
        current_mode = "Unavailable"

    safety = read_button_safety_config()
    blocked = list(safety.get("block_when_armed") or [])
    mapping_json = json.dumps(mapping, ensure_ascii=False)

    return f"""
    <style>
      .v13-button-head{{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;flex-wrap:wrap;margin-bottom:16px}}
      .v13-button-head h1{{margin:0}}
      .v13-button-summary{{display:flex;gap:8px;flex-wrap:wrap}}
      .v13-summary-pill{{background:#0b1220;border:1px solid #334155;border-radius:999px;padding:7px 11px;font-size:13px}}
      .v13-button-tabs{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}}
      .v13-button-tab{{background:#1e293b;color:#cbd5e1;border:1px solid #334155;margin:0}}
      .v13-button-tab.active{{background:#2563eb;color:white;border-color:#60a5fa}}
      .v13-button-panel{{display:none}}
      .v13-button-panel.active{{display:block}}
      .v13-assignment-toolbar{{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px}}
      .v13-segmented{{display:inline-flex;border:1px solid #334155;border-radius:9px;overflow:hidden;background:#0b1220}}
      .v13-segmented button{{margin:0;border:0;border-right:1px solid #334155;border-radius:0;background:transparent;color:#cbd5e1;padding:8px 12px}}
      .v13-segmented button:last-child{{border-right:0}}
      .v13-segmented button.active{{background:#2563eb;color:white}}
      .v13-button-table-wrap{{overflow-x:auto}}
      .v13-button-table select{{min-width:160px}}
      .v15-button-placeholder{{
        min-width:96px;
        transition:background-color 35ms linear,border-color 35ms linear,box-shadow 35ms linear,color 35ms linear;
      }}
      .v15-button-label{{display:inline-flex;align-items:center;gap:9px}}
      .v15-button-led{{
        width:10px;height:10px;border-radius:50%;
        background:#334155;border:1px solid #64748b;
        box-shadow:inset 0 0 0 2px rgba(2,6,23,.35);
        transition:all 35ms linear;
      }}
      .v15-button-placeholder.v15-held{{
        color:#dcfce7;
        background:linear-gradient(135deg,#14532d,#166534);
        box-shadow:inset 0 0 0 2px #4ade80,0 0 18px rgba(34,197,94,.42);
      }}
      .v15-button-placeholder.v15-held .v15-button-led{{
        background:#4ade80;border-color:#bbf7d0;
        box-shadow:0 0 12px rgba(74,222,128,.95);
      }}
      .v15-live-input-pill{{
        display:inline-flex;align-items:center;gap:7px;
        border:1px solid #334155;border-radius:999px;
        background:#0b1220;color:#94a3b8;
        padding:7px 11px;font-size:12px;
      }}
      .v15-live-input-pill.connected{{color:#bbf7d0;border-color:#166534;background:#052e16}}
      .v15-live-input-pill.reconnecting{{color:#fde68a;border-color:#92400e;background:#451a03}}
      .v13-simple .v13-advanced-column{{display:none}}
      .v13-radio-row{{display:flex;gap:8px;flex-wrap:wrap}}
      .v13-radio-option{{display:inline-flex;align-items:center;gap:7px;background:#0b1220;border:1px solid #334155;border-radius:999px;padding:8px 12px;cursor:pointer}}
      .v13-radio-option:has(input:checked){{background:#172554;border-color:#3b82f6;color:#dbeafe}}
      .v13-radio-option input{{width:auto;margin:0;accent-color:#3b82f6}}
      .v13-test-grid{{display:grid;grid-template-columns:repeat(2,minmax(240px,1fr));gap:14px}}
      .v13-test-result{{background:#0b1220;border:1px solid #334155;border-radius:12px;padding:16px;min-height:96px}}
      .v13-test-action{{font-size:24px;font-weight:800;margin-top:8px;color:#bfdbfe}}
      .v13-drawer-backdrop{{display:none;position:fixed;inset:0;background:rgba(2,6,23,.62);z-index:12000}}
      .v13-drawer-backdrop.open{{display:block}}
      .v13-gamepad-drawer{{position:fixed;right:0;top:0;height:100vh;width:min(520px,92vw);background:#0f172a;border-left:1px solid #475569;box-shadow:-18px 0 55px rgba(0,0,0,.45);transform:translateX(102%);transition:transform .2s ease;z-index:12001;padding:20px;box-sizing:border-box;overflow:auto}}
      .v13-gamepad-drawer.open{{transform:translateX(0)}}
      .v13-drawer-head{{display:flex;justify-content:space-between;align-items:center;gap:12px}}
      .v13-drawer-head h2{{margin:0}}
      .v14-drawer-actions{{display:flex;gap:8px;align-items:center}}
      .v13-close-drawer,.v14-float-button{{background:#334155;color:white;border-radius:999px;padding:6px 12px;margin:0}}
      .v14-float-button{{background:#2563eb;border-color:#60a5fa}}
      .v13-gamepad-drawer img{{width:100%;border-radius:14px;margin-top:18px}}
      @media(max-width:760px){{.v13-test-grid{{grid-template-columns:1fr}}}}
    </style>

    <div class='v13-button-head'>
      <div>
        <h1>Button controls</h1>
        <div class='small'>Assignments, flight-safety protection and a safe mapping test in one place.</div>
      </div>
      <div class='v13-button-summary'>
        <span class='v13-summary-pill'>Bridge: <b class='{bridge_class}'>{esc(bridge_state.title())}</b></span>
        <span class='v13-summary-pill'>Mappings: <b>{len(rows)}</b></span>
        <span class='v13-summary-pill'>Current mode: <b>{esc(current_mode)}</b></span>
      </div>
    </div>

    <div class='v13-button-tabs'>
      <button type='button' class='v13-button-tab active' data-v13-button-tab='assignments'>Assignments</button>
      <button type='button' class='v13-button-tab' data-v13-button-tab='safety'>Safety</button>
      <button type='button' class='v13-button-tab' data-v13-button-tab='test'>Live test</button>
    </div>

    <section class='v13-button-panel active' data-v13-button-panel='assignments'>
      <div class='card'>
        <div class='v13-assignment-toolbar'>
          <div>
            <h2 style='margin:0 0 4px'>Button assignments</h2>
            <div class='small'>Simple view shows Tap and Hold. Advanced view also shows Release after hold.</div>
          </div>
          <div style='display:flex;gap:10px;align-items:center;flex-wrap:wrap'>
            <div class='v13-segmented'>
              <button id='v13SimpleButton' type='button' class='active' onclick="setV13ButtonView('simple')">Simple</button>
              <button id='v13AdvancedButton' type='button' onclick="setV13ButtonView('advanced')">Advanced</button>
            </div>
            <span id='v15LiveInputStatus' class='v15-live-input-pill'>Live input: connecting…</span>
            <button type='button' class='secondary' onclick='openV13GamepadDrawer()'>Gamepad reference</button>
          </div>
        </div>

        <form id='buttonMapForm' method='post' action='/save_buttons' class='v13-simple'>
          <input type='hidden' name='count' value='{len(rows)}'>
          <div class='v13-button-table-wrap'>
            <table class='v13-button-table'>
              <tr><th>Button</th><th>Tap</th><th>Hold</th><th class='v13-advanced-column'>Release after hold</th></tr>
              {assignment_rows}
            </table>
          </div>
          <div style='display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;margin-top:10px'>
            <div id='buttonMapSaveStatus' class='small' style='color:#94a3b8'>Saved automatically</div>
            <a class='v9-link-button secondary' href='/media?tab=siyi-camera' target='_top'>Manage gimbal presets</a>
          </div>
        </form>
      </div>
    </section>

    <section class='v13-button-panel' data-v13-button-panel='safety'>
      <div style='margin-bottom:10px' class='small'>Protection status: <b>{len(blocked)} armed-flight blocker(s)</b>. Airborne disarm protection remains locked by default.</div>
      {button_safety_card()}
    </section>

    <section class='v13-button-panel' data-v13-button-panel='test'>
      <div class='card'>
        <h2>Safe assignment test</h2>
        <p class='small'>Select a button and interaction to verify the configured action. This test does not send commands to the aircraft.</p>
        <div class='v13-test-grid'>
          <div>
            <label>Button</label>
            <select id='v13TestButton'></select>
            <label style='margin-top:14px'>Interaction</label>
            <div class='v13-radio-row'>
              <label class='v13-radio-option'><input type='radio' name='v13TestType' value='Tap' checked><span>Tap</span></label>
              <label class='v13-radio-option'><input type='radio' name='v13TestType' value='Hold'><span>Hold</span></label>
              <label class='v13-radio-option'><input type='radio' name='v13TestType' value='ReleaseAfterHold'><span>Release after hold</span></label>
            </div>
          </div>
          <div class='v13-test-result'>
            <div class='small'>Configured result</div>
            <div id='v13TestAction' class='v13-test-action'>NO_ACTION</div>
            <div id='v13TestSafety' class='small' style='margin-top:8px'></div>
          </div>
        </div>
      </div>
      <div class='card'>
        <h2>Button bridge</h2>
        <p>Service state: <b class='{bridge_class}'>{esc(bridge_state)}</b></p>
        <p class='small'>Service restart and disable controls are maintained under System → Operations &amp; Services.</p>
        <a class='v9-link-button secondary' href='/system?tab=operations' target='_top'>Open Operations &amp; Services</a>
      </div>
    </section>

    <div id='v13DrawerBackdrop' class='v13-drawer-backdrop' onclick='closeV13GamepadDrawer()'></div>
    <aside id='v13GamepadDrawer' class='v13-gamepad-drawer' aria-hidden='true'>
      <div class='v13-drawer-head'>
        <h2>Gamepad reference</h2>
        <div class='v14-drawer-actions'>
          <button type='button' class='v14-float-button' onclick='floatV14GamepadReference()'>Release to floating</button>
          <button type='button' class='v13-close-drawer' onclick='closeV13GamepadDrawer()'>×</button>
        </div>
      </div>
      <img src='/static/gamepad_reference.png' alt='Standard gamepad button reference'>
      <p class='small'>Release the reference into a movable, resizable panel that remains above the whole Control Center workspace.</p>
    </aside>

    <script>
    (function(){{
      const mapping={mapping_json};
      const blockedActions=new Set({json.dumps(blocked, ensure_ascii=False)});

      function selectPanel(name){{
        document.querySelectorAll('[data-v13-button-tab]').forEach(button=>button.classList.toggle('active',button.dataset.v13ButtonTab===name));
        document.querySelectorAll('[data-v13-button-panel]').forEach(panel=>panel.classList.toggle('active',panel.dataset.v13ButtonPanel===name));
        try{{localStorage.setItem('siyi-buttons-inner-tab',name)}}catch(_error){{}}
        window.dispatchEvent(new Event('resize'));
      }}
      document.querySelectorAll('[data-v13-button-tab]').forEach(button=>button.addEventListener('click',()=>selectPanel(button.dataset.v13ButtonTab)));
      let savedTab='assignments';
      try{{savedTab=localStorage.getItem('siyi-buttons-inner-tab')||savedTab}}catch(_error){{}}
      if(['assignments','safety','test'].includes(savedTab))selectPanel(savedTab);

      window.setV13ButtonView=function(mode){{
        const form=document.getElementById('buttonMapForm');
        const advanced=mode==='advanced';
        form.classList.toggle('v13-simple',!advanced);
        document.getElementById('v13SimpleButton').classList.toggle('active',!advanced);
        document.getElementById('v13AdvancedButton').classList.toggle('active',advanced);
        try{{localStorage.setItem('siyi-buttons-view',mode)}}catch(_error){{}}
        window.dispatchEvent(new Event('resize'));
      }};
      let savedView='simple';
      try{{savedView=localStorage.getItem('siyi-buttons-view')||savedView}}catch(_error){{}}
      setV13ButtonView(savedView==='advanced'?'advanced':'simple');

      const form=document.getElementById('buttonMapForm');
      const status=document.getElementById('buttonMapSaveStatus');
      let timer=null;
      async function saveButtonMap(){{
        clearTimeout(timer);
        timer=setTimeout(async()=>{{
          if(status)status.textContent='Saving…';
          try{{
            const response=await fetch('/save_buttons',{{method:'POST',body:new URLSearchParams(new FormData(form))}});
            if(!response.ok)throw new Error('HTTP '+response.status);
            if(status)status.textContent='Saved automatically';
          }}catch(error){{
            if(status)status.textContent='Save failed';
          }}
        }},300);
      }}
      form.querySelectorAll('select,input').forEach(element=>element.addEventListener('change',saveButtonMap));

      const testButton=document.getElementById('v13TestButton');
      mapping.forEach(item=>{{
        const option=document.createElement('option');
        option.value=item.button;
        option.textContent='Button '+item.button;
        testButton.appendChild(option);
      }});
      function updateTest(){{
        const item=mapping.find(row=>row.button===testButton.value)||mapping[0]||{{}};
        const type=(document.querySelector('input[name="v13TestType"]:checked')||{{value:'Tap'}}).value;
        const action=item[type]||'NO_ACTION';
        document.getElementById('v13TestAction').textContent=action;
        document.getElementById('v13TestSafety').textContent=blockedActions.has(action)
          ? 'This action is configured to be blocked while armed.'
          : 'No armed-flight blocker is configured for this action.';
      }}
      testButton.addEventListener('change',updateTest);
      document.querySelectorAll('input[name="v13TestType"]').forEach(element=>element.addEventListener('change',updateTest));
      updateTest();

      const v15LiveStatus=document.getElementById('v15LiveInputStatus');
      const v15ButtonCells=new Map(
        [...document.querySelectorAll('[data-v15-button]')]
          .map(cell=>[String(cell.dataset.v15Button||'').toUpperCase(),cell])
      );
      let v15HeldButtons=new Set();
      let v15ButtonStream=null;

      function v15ApplyHeldButtons(buttons){{
        const next=new Set(
          (Array.isArray(buttons)?buttons:[])
            .map(button=>String(button||'').trim().toUpperCase())
            .filter(Boolean)
        );
        for(const [name,cell] of v15ButtonCells){{
          cell.classList.toggle('v15-held',next.has(name));
        }}
        v15HeldButtons=next;
      }}

      function v15SetLiveStatus(state,text){{
        if(!v15LiveStatus)return;
        v15LiveStatus.classList.remove('connected','reconnecting');
        if(state)v15LiveStatus.classList.add(state);
        v15LiveStatus.textContent=text;
      }}

      function v15ConnectLiveButtons(){{
        if(v15ButtonStream)v15ButtonStream.close();
        v15SetLiveStatus('','Live input: connecting…');
        v15ButtonStream=new EventSource('/button_live_stream?ts='+Date.now());
        v15ButtonStream.onopen=()=>v15SetLiveStatus('connected','Live input: connected');
        v15ButtonStream.onmessage=event=>{{
          try{{
            const data=JSON.parse(event.data||'{{}}');
            v15ApplyHeldButtons(data.held||[]);
            v15SetLiveStatus('connected','Live input: connected');
          }}catch(_error){{}}
        }};
        v15ButtonStream.onerror=()=>{{
          v15SetLiveStatus('reconnecting','Live input: reconnecting…');
        }};
      }}

      v15ConnectLiveButtons();
      window.addEventListener('pagehide',()=>{{
        if(v15ButtonStream)v15ButtonStream.close();
      }});

      const v14FloatId='v14GamepadFloatingPanel';
      const v14FloatStyleId='v14GamepadFloatingStyle';

      function v14TopWindow(){{
        try{{
          if(window.top&&window.top.document)return window.top;
        }}catch(_error){{}}
        return window;
      }}

      function v14EnsureFloatingStyle(topWindow){{
        const topDocument=topWindow.document;
        if(topDocument.getElementById(v14FloatStyleId))return;
        const style=topDocument.createElement('style');
        style.id=v14FloatStyleId;
        style.textContent=`
          #${{v14FloatId}}{{
            position:fixed;
            left:calc(100vw - 560px);
            top:92px;
            width:520px;
            height:560px;
            min-width:320px;
            min-height:260px;
            max-width:calc(100vw - 24px);
            max-height:calc(100vh - 24px);
            z-index:50000;
            display:flex;
            flex-direction:column;
            overflow:hidden;
            resize:both;
            box-sizing:border-box;
            color:#e5e7eb;
            background:#0f172a;
            border:1px solid #64748b;
            border-radius:15px;
            box-shadow:0 22px 70px rgba(0,0,0,.55);
          }}
          #${{v14FloatId}} .v14-float-head{{
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:10px;
            padding:11px 12px;
            cursor:move;
            user-select:none;
            background:linear-gradient(135deg,#172554,#1e3a8a);
            border-bottom:1px solid #475569;
          }}
          #${{v14FloatId}} .v14-float-title{{font-weight:800}}
          #${{v14FloatId}} .v14-float-actions{{display:flex;gap:7px}}
          #${{v14FloatId}} button{{
            width:auto;
            margin:0;
            padding:6px 10px;
            border-radius:8px;
            border:1px solid #64748b;
            background:#1e293b;
            color:white;
            cursor:pointer;
          }}
          #${{v14FloatId}} button:hover{{background:#334155}}
          #${{v14FloatId}} .v14-float-body{{
            flex:1;
            overflow:auto;
            padding:13px;
          }}
          #${{v14FloatId}} img{{
            display:block;
            width:100%;
            height:auto;
            border-radius:12px;
          }}
          #${{v14FloatId}} .v14-float-help{{
            margin:10px 0 0;
            color:#94a3b8;
            font:13px/1.45 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
          }}
        `;
        topDocument.head.appendChild(style);
      }}

      function v14ReadFloatGeometry(){{
        try{{
          const parsed=JSON.parse(localStorage.getItem('siyi-gamepad-floating-geometry')||'null');
          return parsed&&typeof parsed==='object'?parsed:null;
        }}catch(_error){{
          return null;
        }}
      }}

      function v14SaveFloatGeometry(panel){{
        try{{
          localStorage.setItem('siyi-gamepad-floating-geometry',JSON.stringify({{
            left:panel.style.left,
            top:panel.style.top,
            width:panel.style.width,
            height:panel.style.height
          }}));
        }}catch(_error){{}}
      }}

      function v14ClampPanel(panel,topWindow){{
        const rect=panel.getBoundingClientRect();
        const maxLeft=Math.max(8,topWindow.innerWidth-Math.min(rect.width,topWindow.innerWidth-16)-8);
        const maxTop=Math.max(8,topWindow.innerHeight-Math.min(rect.height,topWindow.innerHeight-16)-8);
        panel.style.left=Math.min(Math.max(8,rect.left),maxLeft)+'px';
        panel.style.top=Math.min(Math.max(8,rect.top),maxTop)+'px';
      }}

      function v14BringToFront(panel){{
        panel.style.zIndex=String(50000+Math.floor(Date.now()%10000));
      }}

      function v14CreateFloatingPanel(){{
        const topWindow=v14TopWindow();
        const topDocument=topWindow.document;
        v14EnsureFloatingStyle(topWindow);

        let panel=topDocument.getElementById(v14FloatId);
        if(panel){{
          v14BringToFront(panel);
          return panel;
        }}

        panel=topDocument.createElement('section');
        panel.id=v14FloatId;
        panel.setAttribute('role','dialog');
        panel.setAttribute('aria-label','Floating gamepad reference');
        panel.innerHTML=`
          <div class="v14-float-head">
            <span class="v14-float-title">Gamepad reference</span>
            <div class="v14-float-actions">
              <button type="button" data-v14-dock>Dock</button>
              <button type="button" data-v14-close>×</button>
            </div>
          </div>
          <div class="v14-float-body">
            <img src="${{new URL('/static/gamepad_reference.png',location.origin).href}}" alt="Standard gamepad button reference">
            <p class="v14-float-help">Drag the title bar to move. Drag the lower-right edge to resize. Dock returns the reference to the side drawer.</p>
          </div>
        `;
        topDocument.body.appendChild(panel);

        const geometry=v14ReadFloatGeometry();
        if(geometry){{
          if(geometry.left)panel.style.left=geometry.left;
          if(geometry.top)panel.style.top=geometry.top;
          if(geometry.width)panel.style.width=geometry.width;
          if(geometry.height)panel.style.height=geometry.height;
        }}

        requestAnimationFrame(()=>v14ClampPanel(panel,topWindow));
        v14BringToFront(panel);

        const head=panel.querySelector('.v14-float-head');
        let dragging=false;
        let startX=0,startY=0,startLeft=0,startTop=0;

        head.addEventListener('pointerdown',event=>{{
          if(event.target.closest('button'))return;
          dragging=true;
          const rect=panel.getBoundingClientRect();
          startX=event.clientX;
          startY=event.clientY;
          startLeft=rect.left;
          startTop=rect.top;
          head.setPointerCapture(event.pointerId);
          v14BringToFront(panel);
          event.preventDefault();
        }});

        head.addEventListener('pointermove',event=>{{
          if(!dragging)return;
          panel.style.left=(startLeft+event.clientX-startX)+'px';
          panel.style.top=(startTop+event.clientY-startY)+'px';
          v14ClampPanel(panel,topWindow);
        }});

        function finishDrag(){{
          if(!dragging)return;
          dragging=false;
          v14SaveFloatGeometry(panel);
        }}
        head.addEventListener('pointerup',finishDrag);
        head.addEventListener('pointercancel',finishDrag);

        panel.addEventListener('pointerdown',()=>v14BringToFront(panel));
        panel.querySelector('[data-v14-close]').addEventListener('click',()=>{{
          v14SaveFloatGeometry(panel);
          panel.remove();
        }});
        panel.querySelector('[data-v14-dock]').addEventListener('click',()=>{{
          v14SaveFloatGeometry(panel);
          panel.remove();
          openV13GamepadDrawer();
        }});

        if('ResizeObserver' in topWindow){{
          const observer=new topWindow.ResizeObserver(()=>{{
            v14ClampPanel(panel,topWindow);
            v14SaveFloatGeometry(panel);
          }});
          observer.observe(panel);
        }}
        topWindow.addEventListener('resize',()=>v14ClampPanel(panel,topWindow));

        return panel;
      }}

      window.openV13GamepadDrawer=function(){{
        const topWindow=v14TopWindow();
        const floating=topWindow.document.getElementById(v14FloatId);
        if(floating){{
          v14BringToFront(floating);
          return;
        }}
        document.getElementById('v13DrawerBackdrop').classList.add('open');
        document.getElementById('v13GamepadDrawer').classList.add('open');
        document.getElementById('v13GamepadDrawer').setAttribute('aria-hidden','false');
      }};

      window.closeV13GamepadDrawer=function(){{
        document.getElementById('v13DrawerBackdrop').classList.remove('open');
        document.getElementById('v13GamepadDrawer').classList.remove('open');
        document.getElementById('v13GamepadDrawer').setAttribute('aria-hidden','true');
      }};

      window.floatV14GamepadReference=function(){{
        closeV13GamepadDrawer();
        v14CreateFloatingPanel();
      }};

      document.addEventListener('keydown',event=>{{
        if(event.key==='Escape')closeV13GamepadDrawer();
      }});
    }})();
    </script>
    """


_v13_original_unigcs_controls_page = unigcs_controls_page

def unigcs_controls_page():
    html = _v13_original_unigcs_controls_page()
    html = html.replace(
        "<div class=\"cam-full\"><h1>Camera Controls</h1>",
        "<div class=\"cam-full\"><h1>SIYI Camera</h1><p class='small'>Live image, stream, recording and gimbal controls. Sliders and radio choices apply immediately.</p>",
        1,
    )
    common_css = r"""
    /* CAMERA_UI_HARMONIZATION_V13 */
    .cam-grid .card{border-radius:14px;border-color:#334155;background:#111827}
    .cam-grid .card h2{font-size:17px}
    .cam-grid input[type=range]{accent-color:#3b82f6}
    .cam-grid input[type=radio]{accent-color:#3b82f6;width:18px;height:18px}
    .cam-grid form:has(input[type=radio]) span{background:#0b1220;border:1px solid #334155;border-radius:999px;padding:8px 12px}
    .cam-grid form:has(input[type=radio]) span:has(input:checked){background:#172554;border-color:#3b82f6;color:#dbeafe}
    """
    html = html.replace("</style>", common_css + "\n</style>", 1)
    html += (
        "<div class='cam-full' style='margin-top:14px'>"
        "<div style='display:flex;justify-content:space-between;align-items:end;gap:12px;flex-wrap:wrap;margin-bottom:8px'>"
        "<div><h2 style='margin:0'>Gimbal presets</h2><div class='small'>Preset positions are available as button actions.</div></div>"
        "<a class='v9-link-button secondary' href='/aircraft?tab=buttons' target='_top'>Open button assignments</a>"
        "</div>"
        + gimbal_presets_card()
        + "</div>"
    )
    return html


def _wl2_camera_field_html(control):
    path = str(control["path"])
    label = esc(control["label"])
    description = esc(control.get("description") or "")
    value = control.get("value")
    field_name = "camera." + path
    field_id = "wl2-camera-" + re.sub(r"[^a-zA-Z0-9_-]+", "-", path)
    enum = list(control.get("enum") or [])
    input_html = ""

    if enum:
        choices = []
        for index, item in enumerate(enum):
            checked = " checked" if str(item) == str(value) else ""
            choices.append(
                "<label class='wl2-camera-radio'><input type='radio' name='"
                + esc(field_name) + "' value='" + esc(item) + "'" + checked
                + "><span>" + esc(_wl2_human_label(str(item))) + "</span></label>"
            )
        input_html = "<div class='wl2-camera-radio-group'>" + "".join(choices) + "</div>"
    elif control["type"] == "boolean":
        current = str(value).lower() in {"1", "true", "yes", "on"}
        input_html = (
            "<div class='wl2-camera-radio-group'>"
            "<label class='wl2-camera-radio'><input type='radio' name='" + esc(field_name)
            + "' value='true'" + (" checked" if current else "") + "><span>On</span></label>"
            "<label class='wl2-camera-radio'><input type='radio' name='" + esc(field_name)
            + "' value='false'" + ("" if current else " checked") + "><span>Off</span></label>"
            "</div>"
        )
    elif control["type"] in {"integer", "number"} and control.get("minimum") is not None and control.get("maximum") is not None:
        minimum = control.get("minimum")
        maximum = control.get("maximum")
        step = "any" if control["type"] == "number" else "1"
        input_html = (
            "<div class='wl2-camera-slider-row'><input id='" + esc(field_id)
            + "' type='range' step='" + step + "' min='" + esc(minimum)
            + "' max='" + esc(maximum) + "' name='" + esc(field_name)
            + "' value='" + esc(value) + "' oninput=\"document.getElementById('"
            + esc(field_id) + "-value').value=this.value\">"
            "<output id='" + esc(field_id) + "-value'>" + esc(value) + "</output></div>"
        )
    elif control["type"] in {"integer", "number"}:
        step = "any" if control["type"] == "number" else "1"
        input_html = (
            "<input type='number' step='" + step + "' name='" + esc(field_name)
            + "' value='" + esc(value) + "'>"
        )
    else:
        input_html = "<input name='" + esc(field_name) + "' value='" + esc(value) + "'>"

    help_text = (
        "<div class='small' style='margin-top:6px'>" + description + "</div>"
        if description else ""
    )
    return (
        "<div class='wl2-camera-field'><label>" + label + "</label>"
        + input_html + help_text + "</div>"
    )

# BUTTON_CAMERA_WORKSPACE_V13_END



# GAMEPAD_FLOATING_REFERENCE_V14
# The gamepad reference can be released from the side drawer into a draggable,
# resizable overlay in the top-level Control Center workspace and docked again.




# BUTTON_LIVE_ASSIGNMENT_HIGHLIGHT_V15
_BUTTON_LIVE_STATE_FILE = "/tmp/siyi_button_live.json"


def _v15_read_button_live_state():
    now = time.time()
    payload = {}
    try:
        with open(_BUTTON_LIVE_STATE_FILE, "r", encoding="utf-8") as handle:
            loaded = json.load(handle)
        if isinstance(loaded, dict):
            payload = loaded
    except Exception:
        payload = {}

    try:
        source_ts = float(payload.get("ts") or 0.0)
    except Exception:
        source_ts = 0.0

    held = payload.get("held")
    if not isinstance(held, list):
        held = []

    normalized = []
    for value in held:
        name = str(value or "").strip().upper()
        if name and name not in normalized:
            normalized.append(name)

    # Clear the display quickly if input traffic stops or the bridge state file
    # becomes stale. This prevents a button remaining green after disconnect.
    age = max(0.0, now - source_ts) if source_ts else 999.0
    if age > 0.45:
        normalized = []

    return {
        "held": normalized,
        "source_ts": source_ts,
        "age_ms": int(age * 1000) if age < 999.0 else None,
        "fresh": age <= 0.45,
    }


_v15_previous_get = H.do_GET


def _v15_do_GET(self):
    parsed = urllib.parse.urlparse(self.path)

    if parsed.path == "/button_live_state":
        send_json_response(self, _v15_read_button_live_state(), 200)
        return

    if parsed.path == "/button_live_stream":
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()

        last_serialized = None
        last_heartbeat = 0.0
        try:
            while True:
                state = _v15_read_button_live_state()
                serialized = json.dumps(state, separators=(",", ":"))
                now = time.monotonic()

                if serialized != last_serialized:
                    self.wfile.write(("data: " + serialized + "\n\n").encode("utf-8"))
                    self.wfile.flush()
                    last_serialized = serialized
                    last_heartbeat = now
                elif now - last_heartbeat >= 10.0:
                    self.wfile.write(b": keepalive\n\n")
                    self.wfile.flush()
                    last_heartbeat = now

                # 20 ms sampling, with no deliberate UI debounce.
                time.sleep(0.02)
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            pass
        except Exception:
            pass
        return

    return _v15_previous_get(self)


H.do_GET = _v15_do_GET
# BUTTON_LIVE_ASSIGNMENT_HIGHLIGHT_V15_END



# SIYI_CONTROL_CENTER_RELEASE_4_0_1
# Release UI baseline: V15 cumulative interface.
# Missing Air Link profile-manager components are installed on demand from
# the packaged, non-user-specific payload under /usr/local/share/siyi/wifilink2.



# GROUND_STATION_MONITOR_POC_V1_START
# Read-only Ground Station proof of concept: dedicated telemetry daemon proxy,
# responsive HUD, vector navigation view, messages, and browser video using the
# existing MediaMTX main.264 path. No vehicle command endpoint is exposed.
GROUNDSTATION_INTERNAL_BASE = "http://127.0.0.1:18765"


def _groundstation_fetch(path, timeout=3.0):
    request = urllib.request.Request(
        GROUNDSTATION_INTERNAL_BASE + path,
        headers={"User-Agent": "SIYI-WebUI-GroundStation/1"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read(4 * 1024 * 1024)


def _groundstation_send_json(handler, path):
    try:
        raw = _groundstation_fetch(path)
        json.loads(raw.decode("utf-8"))
        status = 200
    except Exception as exc:
        raw = json.dumps(
            {
                "ok": False,
                "error": "Ground Station backend unavailable",
                "detail": str(exc),
            },
            ensure_ascii=False,
        ).encode("utf-8")
        status = 503
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


_GROUNDSTATION_MAPTILER_CONFIG = "/etc/siyi/maptiler.json"


def _groundstation_maptiler_api_key():
    try:
        with open(_GROUNDSTATION_MAPTILER_CONFIG, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        key = str(data.get("api_key") or "").strip()
        return key
    except Exception:
        return ""


def _groundstation_page(app_mode=False):
    template = '<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover">\n<meta name="theme-color" content="#020617">\n<meta name="mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-capable" content="yes">\n<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">\n<meta name="screen-orientation" content="landscape">\n<link rel="manifest" href="/groundstation.webmanifest?v=16">\n<title>SIYI Ground Station</title>\n<script>\n(function(){\n  // GROUNDSTATION_V15_UNCONDITIONAL_PORTRAIT_HARD_BLOCK\n  // This script runs on the Ground Station page in every launch mode. It does\n  // not depend on PWA/display-mode detection, which is inconsistent on Android.\n  const root=document.documentElement;\n  let portraitQuery=null;\n  try{portraitQuery=window.matchMedia(\'(orientation: portrait)\');}catch(_e){}\n\n  function viewportIsPortrait(){\n    const viewport=window.visualViewport;\n    const width=Math.round(viewport&&viewport.width?viewport.width:(window.innerWidth||root.clientWidth||0));\n    const height=Math.round(viewport&&viewport.height?viewport.height:(window.innerHeight||root.clientHeight||0));\n    const mediaPortrait=Boolean(portraitQuery&&portraitQuery.matches);\n    return mediaPortrait||height>width;\n  }\n\n  function applyPortraitBlock(){\n    const blocked=viewportIsPortrait();\n    root.classList.toggle(\'gs-portrait-blocked\',blocked);\n    const app=document.getElementById(\'gsApp\');\n    if(app){\n      app.toggleAttribute(\'inert\',blocked);\n      if(blocked){app.setAttribute(\'aria-hidden\',\'true\');}\n      else{app.removeAttribute(\'aria-hidden\');}\n    }\n    const warning=document.getElementById(\'orientationGuard\');\n    if(warning){warning.setAttribute(\'aria-hidden\',blocked?\'false\':\'true\');}\n    return blocked;\n  }\n\n  async function lockLandscapeOrientation(){\n    applyPortraitBlock();\n    try{\n      if(screen.orientation&&typeof screen.orientation.lock===\'function\'){\n        await screen.orientation.lock(\'landscape\');\n      }\n    }catch(error){\n      console.debug(\'Landscape orientation lock was not available:\',error);\n    }\n    applyPortraitBlock();\n  }\n\n  function startOrientationProtection(){\n    applyPortraitBlock();\n    lockLandscapeOrientation();\n  }\n\n  window.__siyiGroundStationLockLandscape=lockLandscapeOrientation;\n  window.__siyiGroundStationApplyPortraitBlock=applyPortraitBlock;\n\n  if(document.readyState===\'loading\'){\n    document.addEventListener(\'DOMContentLoaded\',applyPortraitBlock,{once:true});\n  }else{\n    applyPortraitBlock();\n  }\n  window.addEventListener(\'load\',startOrientationProtection,{once:true});\n  window.addEventListener(\'resize\',applyPortraitBlock,{passive:true});\n  window.addEventListener(\'orientationchange\',()=>setTimeout(applyPortraitBlock,40),{passive:true});\n  window.addEventListener(\'pageshow\',applyPortraitBlock,{passive:true});\n  if(window.visualViewport){\n    window.visualViewport.addEventListener(\'resize\',applyPortraitBlock,{passive:true});\n  }\n  if(portraitQuery){\n    if(typeof portraitQuery.addEventListener===\'function\')portraitQuery.addEventListener(\'change\',applyPortraitBlock);\n    else if(typeof portraitQuery.addListener===\'function\')portraitQuery.addListener(applyPortraitBlock);\n  }\n  document.addEventListener(\'fullscreenchange\',()=>{\n    applyPortraitBlock();\n    if(document.fullscreenElement)lockLandscapeOrientation();\n  });\n  document.addEventListener(\'visibilitychange\',()=>{\n    if(!document.hidden)lockLandscapeOrientation();\n  });\n})();\n</script>\n<style>\n:root{--bg:#020617;--panel:rgba(7,18,38,.88);--line:#334155;--text:#f8fafc;--muted:#94a3b8;--ok:#22c55e;--warn:#f59e0b;--bad:#ef4444;--blue:#38bdf8}\n*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden;background:var(--bg);color:var(--text);font-family:Arial,Helvetica,sans-serif}\nbutton{font:inherit}.gs-app{height:100vh;display:grid;grid-template-rows:auto 1fr auto;background:radial-gradient(circle at 50% 0,#0b1d38 0,#020617 45%)}\n.gs-top{display:flex;align-items:center;gap:8px;padding:7px 9px;background:#020617;border-bottom:1px solid var(--line);min-height:52px;overflow-x:auto;white-space:nowrap;z-index:30}\n.gs-brand{display:flex;align-items:center;gap:8px;font-weight:800;margin-right:4px}.gs-logo{width:31px;height:31px;border:1px solid #60a5fa;border-radius:8px;display:grid;place-items:center;color:#7dd3fc;background:#0b1930}\n.gs-chip{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--line);background:#0b1220;padding:7px 9px;border-radius:9px;font-size:12px;font-weight:700}.gs-chip strong{font-size:13px}.gs-dot{width:9px;height:9px;border-radius:50%;background:#64748b}.gs-dot.ok{background:var(--ok);box-shadow:0 0 9px var(--ok)}.gs-dot.warn{background:var(--warn);box-shadow:0 0 9px var(--warn)}.gs-dot.bad{background:var(--bad);box-shadow:0 0 9px var(--bad)}\n.gs-spacer{flex:1}.gs-btn{border:1px solid #475569;background:#111c31;color:var(--text);border-radius:9px;padding:8px 11px;cursor:pointer;font-weight:700}.gs-btn:hover,.gs-btn.active{background:#1d4ed8;border-color:#60a5fa}.gs-btn.warn{background:#78350f;border-color:#f59e0b}.gs-btn.compact{padding:6px 8px;font-size:12px}\n.gs-main{min-height:0;display:grid;grid-template-columns:minmax(0,1fr) 300px;grid-template-rows:minmax(0,1fr);gap:8px;padding:8px}.gs-stage{min-width:0;min-height:0;position:relative;border:1px solid var(--line);border-radius:12px;overflow:hidden;background:#000}.gs-side{min-height:0;display:flex;flex-direction:column;gap:8px;overflow:auto}.gs-panel{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:10px}.gs-panel-title{font-size:12px;text-transform:uppercase;letter-spacing:.12em;color:#a5b4fc;margin-bottom:8px;font-weight:800}\n.gs-view{position:absolute;inset:0;display:none}.gs-view.active{display:block}.gs-split{display:none;position:absolute;inset:0;grid-template-columns:1fr 1fr;gap:6px;background:#020617;padding:6px}.gs-split.active{display:grid}.gs-split>div{position:relative;min-width:0;min-height:0;border:1px solid #334155;border-radius:9px;overflow:hidden;background:#000}\n.gs-video-frame{width:100%;height:100%;border:0;background:#000}.gs-video-overlay{position:absolute;inset:0;pointer-events:none}.gs-video-controls{position:absolute;left:10px;bottom:10px;display:flex;gap:6px;pointer-events:auto}.gs-video-state{position:absolute;top:10px;left:10px;background:rgba(2,6,23,.74);border:1px solid #475569;border-radius:8px;padding:6px 9px;font-size:12px}.gs-video-protocol{color:#7dd3fc;font-weight:800}\n/* GROUNDSTATION_V15_LAYERED_LANDSCAPE_ONLY */\n.gs-orientation-guard{display:none;position:fixed;inset:0;z-index:999999;background:#000;color:#fff;align-items:center;justify-content:center;text-align:center;padding:24px;pointer-events:auto;touch-action:none}\n.gs-orientation-card{max-width:430px;border:1px solid #475569;border-radius:18px;background:#0b1220;padding:28px;box-shadow:0 24px 70px rgba(0,0,0,.55)}\n.gs-orientation-icon{font-size:52px;line-height:1;margin-bottom:14px}.gs-orientation-card strong{font-size:22px;display:block;margin-bottom:8px}.gs-orientation-card span{color:#cbd5e1;line-height:1.45}\nhtml.gs-portrait-blocked .gs-app{visibility:hidden!important;pointer-events:none!important;user-select:none!important}\nhtml.gs-portrait-blocked .gs-orientation-guard{display:flex!important;visibility:visible!important}\n@media (orientation:portrait){\n  .gs-app{visibility:hidden!important;pointer-events:none!important;user-select:none!important}\n  .gs-orientation-guard{display:flex!important;visibility:visible!important}\n}\n.gs-round-hud{display:none;position:absolute;left:18px;top:68px;width:220px;height:220px;z-index:14;touch-action:none;user-select:none;pointer-events:auto;container-type:inline-size}\n.gs-round-hud.show{display:block}.gs-round-hud.dragging,.gs-round-hud.resizing{transition:none!important}\n.gs-round-face{position:absolute;inset:0;border-radius:50%;overflow:hidden;border:1px solid rgba(226,232,240,.78);background:#111827;box-shadow:0 2px 8px rgba(0,0,0,.38);cursor:move}\n.gs-round-horizon-wrap{position:absolute;inset:1px;overflow:hidden;border-radius:50%}\n.gs-round-horizon{position:absolute;left:-60%;top:-60%;width:220%;height:220%;background:linear-gradient(to bottom,#2387cf 0 49.72%,rgba(241,245,249,.92) 49.72% 50.28%,#31934a 50.28% 100%);transform-origin:50% 50%;transition:transform .07s linear}\n.gs-round-shade{position:absolute;inset:0;border-radius:50%;background:radial-gradient(circle at 50% 45%,transparent 0 66%,rgba(2,6,23,.18) 100%);pointer-events:none}\n.gs-round-bank{position:absolute;left:50%;top:5%;width:0;height:0;border-left:4px solid transparent;border-right:4px solid transparent;border-top:7px solid rgba(248,250,252,.92);transform:translateX(-50%);filter:drop-shadow(0 1px 1px #000)}\n.gs-round-aircraft{position:absolute;left:50%;top:50%;width:40%;height:12px;transform:translate(-50%,-50%);pointer-events:none}\n.gs-round-aircraft:before,.gs-round-aircraft:after{content:"";position:absolute;top:5px;width:42%;height:1.5px;background:#fde047;box-shadow:0 1px 2px rgba(0,0,0,.8)}.gs-round-aircraft:before{left:0}.gs-round-aircraft:after{right:0}\n.gs-round-aircraft span{position:absolute;left:50%;top:1px;width:6px;height:9px;transform:translateX(-50%);border:1.5px solid #fde047;border-top:0;border-radius:0 0 3px 3px}\n.gs-round-home{position:absolute;left:50%;top:12%;width:15px;height:15px;transform:translate(-50%,-50%);pointer-events:none;opacity:0;transition:left .07s linear,top .07s linear,opacity .15s ease}.gs-round-home.show{opacity:1}\n.gs-round-home .roof{position:absolute;left:50%;top:1px;width:9px;height:9px;transform:translateX(-50%) rotate(45deg);background:rgba(248,250,252,.95);border-radius:1px;box-shadow:0 1px 2px rgba(0,0,0,.55)}\n.gs-round-home .body{position:absolute;left:50%;bottom:1px;width:8px;height:6px;transform:translateX(-50%);background:#111827;border:1.5px solid rgba(248,250,252,.95);border-top:0;border-radius:0 0 2px 2px;box-sizing:border-box}\n.gs-round-home .door{position:absolute;left:50%;bottom:1px;width:2.4px;height:3.2px;transform:translateX(-50%);background:rgba(248,250,252,.95);border-radius:1px 1px 0 0}\n.gs-round-stale{display:none;position:absolute;left:50%;top:30%;transform:translateX(-50%);background:rgba(127,29,29,.85);border:1px solid rgba(252,165,165,.8);border-radius:4px;padding:2px 4px;font-size:clamp(6px,5cqw,9px);font-weight:800;pointer-events:none}.gs-round-stale.show{display:block}\n.gs-round-resize{position:absolute;width:24px;height:24px;border:0;background:transparent;z-index:6;touch-action:none;opacity:0}\n.gs-round-resize.nw{left:-2px;top:-2px;cursor:nwse-resize}.gs-round-resize.ne{right:-2px;top:-2px;cursor:nesw-resize}.gs-round-resize.sw{left:-2px;bottom:-2px;cursor:nesw-resize}.gs-round-resize.se{right:-2px;bottom:-2px;cursor:nwse-resize}\n.gs-hud{position:absolute;inset:0;overflow:hidden;pointer-events:none}.gs-horizon-wrap{position:absolute;left:50%;top:50%;width:140%;height:140%;transform:translate(-50%,-50%);overflow:hidden}.gs-horizon{position:absolute;left:0;top:-50%;width:100%;height:200%;background:linear-gradient(to bottom,#2276a5 0,#4ca7d0 46%,#f1f5f9 49.6%,#334155 50%,#78552f 53%,#3d2b1d 100%);transform-origin:50% 50%;transition:transform .09s linear}.gs-hud-mask{position:absolute;inset:0;background:radial-gradient(circle,transparent 0,transparent 44%,rgba(0,0,0,.08) 70%,rgba(0,0,0,.36) 100%)}\n.gs-aircraft-symbol{position:absolute;left:50%;top:50%;width:96px;height:22px;transform:translate(-50%,-50%)}.gs-aircraft-symbol:before,.gs-aircraft-symbol:after{content:"";position:absolute;top:9px;width:39px;height:3px;background:#ffd54a;box-shadow:0 0 3px #000}.gs-aircraft-symbol:before{left:0}.gs-aircraft-symbol:after{right:0}.gs-aircraft-symbol span{position:absolute;left:45px;top:3px;width:7px;height:15px;border:3px solid #ffd54a;border-top:0;border-radius:0 0 5px 5px}\n.gs-heading{position:absolute;top:10px;left:50%;transform:translateX(-50%);background:rgba(2,6,23,.75);border:1px solid #64748b;border-radius:8px;padding:7px 13px;font-size:18px;font-weight:900}.gs-tape{position:absolute;top:19%;bottom:16%;width:92px;background:rgba(2,6,23,.58);border:1px solid rgba(148,163,184,.55);border-radius:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-shadow:0 2px 4px #000}.gs-tape.left{left:10px}.gs-tape.right{right:10px}.gs-tape .label{font-size:11px;color:#cbd5e1;text-transform:uppercase}.gs-tape .value{font-size:27px;font-weight:900}.gs-tape .secondary{font-size:12px;color:#bae6fd}.gs-mode-overlay{position:absolute;left:50%;bottom:12px;transform:translateX(-50%);background:rgba(2,6,23,.78);border:1px solid #64748b;border-radius:9px;padding:7px 13px;font-weight:900}.gs-data-lost{display:none;position:absolute;left:50%;top:24%;transform:translateX(-50%);background:#7f1d1d;border:1px solid #fca5a5;padding:8px 14px;border-radius:9px;font-weight:900}.gs-data-lost.show{display:block}\n/* GROUNDSTATION_V17_MAPTILER_SATELLITE_HYBRID */\n.gs-map-host{position:absolute;inset:0;overflow:hidden;background:#07111f}.gs-map-live{position:absolute;inset:0;z-index:1}.gs-map-placeholder{position:absolute;inset:0;display:grid;place-items:center;padding:24px;text-align:center;color:#94a3b8;background:radial-gradient(circle at 50% 40%,#10233d 0,#07111f 58%,#020617 100%);font-size:13px}.gs-map-placeholder strong{display:block;color:#e2e8f0;font-size:15px;margin-bottom:6px}.gs-map-status{position:absolute;left:10px;top:10px;z-index:6;background:rgba(2,6,23,.82);border:1px solid #334155;padding:6px 9px;border-radius:8px;font-size:11px;color:#cbd5e1;max-width:min(58%,420px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;pointer-events:none}.gs-map-status.ok{border-color:#166534;color:#bbf7d0}.gs-map-status.warn{border-color:#92400e;color:#fde68a}.gs-map-status.bad{border-color:#991b1b;color:#fecaca}.gs-map-toolbar{position:absolute;right:10px;top:10px;z-index:7;display:flex;align-items:flex-start;gap:6px}.gs-map-style-switch{display:flex;gap:4px;background:rgba(2,6,23,.82);border:1px solid #64748b;border-radius:8px;padding:4px}.gs-map-style-switch button{height:28px;border:1px solid transparent;border-radius:5px;background:transparent;color:#cbd5e1;padding:0 8px;font-size:10px;font-weight:900;cursor:pointer}.gs-map-style-switch button.active{background:#1d4ed8;border-color:#60a5fa;color:white}.gs-map-controls{display:flex;flex-direction:column;gap:5px}.gs-map-controls button{width:34px;height:34px;border:1px solid #64748b;border-radius:8px;background:rgba(2,6,23,.82);color:white;font-size:18px;cursor:pointer}.gs-map-controls button:hover{background:#1e3a8a}.gs-map-aircraft-marker{width:28px;height:32px;filter:drop-shadow(0 2px 3px rgba(0,0,0,.9));transform-origin:50% 50%}.gs-map-aircraft-marker svg{display:block;width:100%;height:100%}.gs-map-aircraft-marker.stale path{fill:#ef4444}.gs-map-home-marker{width:30px;height:30px;border-radius:50%;display:grid;place-items:center;background:rgba(5,46,22,.92);border:2px solid #4ade80;color:white;font-size:17px;line-height:1;box-shadow:0 2px 7px rgba(0,0,0,.75)}.gs-map-home-marker span{transform:translateY(-1px)}.maplibregl-ctrl-attrib,.maptiler-ctrl-attrib{font-size:9px!important;background:rgba(255,255,255,.78)!important}.maplibregl-canvas{outline:none}.leaflet-container{position:absolute!important;inset:0;background:#07111f;font:12px/1.5 Arial,sans-serif;touch-action:none}.leaflet-pane,.leaflet-tile,.leaflet-marker-icon,.leaflet-marker-shadow,.leaflet-tile-container,.leaflet-pane>svg,.leaflet-pane>canvas{position:absolute;left:0;top:0}.leaflet-map-pane,.leaflet-tile-pane,.leaflet-overlay-pane,.leaflet-shadow-pane,.leaflet-marker-pane,.leaflet-tooltip-pane,.leaflet-popup-pane{position:absolute;left:0;top:0}.leaflet-tile{visibility:hidden}.leaflet-tile-loaded{visibility:inherit}.leaflet-zoom-animated{transform-origin:0 0}.leaflet-control-container{position:absolute;inset:0;pointer-events:none;z-index:800}.leaflet-control{position:relative;z-index:800;pointer-events:auto}.leaflet-bottom{position:absolute;bottom:0}.leaflet-right{position:absolute;right:0}.leaflet-control-attribution{margin:0!important;padding:1px 5px!important;background:rgba(255,255,255,.78)!important;color:#111!important;font-size:9px!important}.leaflet-control-attribution a{color:#0645ad}.gs-map-marker-shell{background:transparent!important;border:0!important}.gs-map-aircraft-marker{transition:transform .12s linear}.gs-map-aircraft-marker.stale path{fill:#ef4444}.gs-split-map-pane .gs-map-status{max-width:50%;font-size:9px;padding:4px 6px}.gs-split-map-pane .gs-map-toolbar{top:6px;right:6px;gap:4px}.gs-split-map-pane .gs-map-style-switch{padding:3px}.gs-split-map-pane .gs-map-style-switch button{height:24px;padding:0 6px;font-size:9px}.gs-split-map-pane .gs-map-controls button{width:30px;height:30px;font-size:16px}\n.gs-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}.gs-tile{background:#081427;border:1px solid #334155;border-radius:9px;padding:8px}.gs-tile .k{font-size:10px;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em}.gs-tile .v{font-size:19px;font-weight:900;margin-top:3px}.gs-tile .s{font-size:10px;color:#64748b;margin-top:2px}.gs-attitude{height:110px;position:relative;overflow:hidden;border-radius:9px;border:1px solid #334155;background:#111827}.gs-mini-horizon{position:absolute;left:-25%;top:-100%;width:150%;height:300%;background:linear-gradient(#3184b5 0,#54a8cf 48.5%,#e2e8f0 49.5%,#6b4a2d 50.5%,#362516 100%);transform-origin:50% 50%;transition:transform .09s linear}.gs-mini-symbol{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);color:#fde047;font-size:30px;font-weight:900;text-shadow:0 1px 4px #000}.gs-mission-line{font-size:13px;line-height:1.55}.gs-message-list{height:126px;overflow:auto;font-size:12px}.gs-message{border-left:3px solid #64748b;padding:5px 7px;margin-bottom:5px;background:#07111f}.gs-message.Warning{border-color:var(--warn)}.gs-message.Error,.gs-message.Critical,.gs-message.Emergency,.gs-message.Alert{border-color:var(--bad)}.gs-message-time{color:#64748b;margin-right:6px}\n.gs-bottom{display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:8px;padding:7px 9px;border-top:1px solid var(--line);background:#020617;min-height:48px}.gs-layout-buttons,.gs-source-buttons{display:flex;gap:5px;flex-wrap:wrap}.gs-alert{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#cbd5e1;font-size:12px}.gs-monitor{color:#86efac;border:1px solid #166534;background:#052e16;padding:6px 9px;border-radius:8px;font-size:11px;font-weight:900}\n.gs-pip{position:absolute;right:14px;bottom:14px;width:min(32%,360px);height:min(30%,230px);border:2px solid #94a3b8;border-radius:10px;overflow:hidden;z-index:15;box-shadow:0 12px 35px rgba(0,0,0,.5);cursor:pointer;background:#020617}.gs-pip .gs-video-frame{pointer-events:none}.gs-pip-label{position:absolute;left:6px;top:6px;background:rgba(2,6,23,.78);padding:4px 7px;border-radius:6px;font-size:10px;z-index:4;max-width:calc(100% - 12px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.gs-pip-sourcebar{position:absolute;left:6px;right:6px;bottom:6px;z-index:6;display:grid;grid-template-columns:1fr 1fr;gap:5px;pointer-events:auto;background:rgba(2,6,23,.72);border:1px solid rgba(100,116,139,.8);border-radius:8px;padding:5px;cursor:default}.gs-pip-sourcebar .gs-btn{min-width:0;padding:5px 6px;font-size:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.gs-pip-sourcebar .gs-btn:disabled{opacity:.52;cursor:wait}.gs-pip-switching{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:7;display:none;background:rgba(2,6,23,.9);border:1px solid #60a5fa;border-radius:8px;padding:7px 10px;font-size:11px;font-weight:900;color:#bae6fd;pointer-events:none}.gs-pip-switching.show{display:block}\n@media(max-width:1000px){.gs-main{grid-template-columns:minmax(0,1fr) 250px}.gs-tape{width:77px}.gs-tape .value{font-size:23px}}\n@media(max-width:760px){.gs-main{grid-template-columns:1fr;padding:4px}.gs-side{position:absolute;right:6px;top:59px;bottom:55px;width:min(84vw,310px);z-index:40;transform:translateX(110%);transition:transform .2s;background:#020617;padding:5px;border-left:1px solid #334155}.gs-side.open{transform:translateX(0)}.gs-top{min-height:48px}.gs-brand span:last-child{display:none}.gs-chip.optional{display:none}.gs-bottom{grid-template-columns:1fr auto}.gs-source-buttons{display:none}.gs-alert{grid-column:1/-1}.gs-pip{width:42%;height:30%;right:8px;bottom:8px}.gs-pip-sourcebar{left:4px;right:4px;bottom:4px;padding:3px;gap:3px}.gs-pip-sourcebar .gs-btn{padding:4px 3px;font-size:9px}.gs-tape{top:24%;bottom:20%;width:68px}.gs-tape .value{font-size:21px}.gs-tape.left{left:5px}.gs-tape.right{right:5px}.gs-split.active{grid-template-columns:1fr;grid-template-rows:1fr 1fr}}\n.gs-camera-label{position:absolute;left:7px;top:7px;z-index:8;background:rgba(2,6,23,.84);border:1px solid rgba(100,116,139,.8);border-radius:7px;padding:5px 8px;font-size:11px;font-weight:900;max-width:calc(100% - 14px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;pointer-events:none}\n#splitSecondaryPane .gs-video-frame{pointer-events:none}.gs-audio-controls{display:flex;align-items:center;gap:5px}.gs-volume{width:76px;accent-color:#38bdf8}.gs-btn.audio-on{background:#14532d;border-color:#4ade80}.gs-btn.audio-muted{background:#78350f;border-color:#f59e0b}.gs-dual-status{display:flex;align-items:center;gap:7px;min-width:0;font-size:11px;color:#bae6fd}.gs-dual-status span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n@media(max-width:760px){.gs-volume{display:none}.gs-audio-controls .audio-secondary{display:none}.gs-camera-label{font-size:9px;padding:4px 6px}}\n.gs-video-frame{object-fit:cover;background:#000}\n.gs-dual-status #airlinkBufferState{color:#94a3b8}\n.gs-dual-status #airlinkBufferState.warn{color:#fbbf24}\n.gs-dual-status #airlinkBufferState.bad{color:#f87171}\n.gs-btn.resyncing{opacity:.65;cursor:wait}\n@media(max-width:760px){#airlinkBufferState{max-width:125px}.gs-dual-status{gap:4px}.gs-dual-status .gs-btn{padding:5px 6px;font-size:9px}}\n\n/* GROUND_STATION_FULLSCREEN_FLIGHT_UI_V6 */\n:root{--gs-top-clear:58px;--gs-bottom-clear:54px}\n.gs-app{position:relative;height:100dvh;min-height:100vh;display:block;background:#000;isolation:isolate}\n.gs-main{position:absolute;inset:0;display:block;min-height:0;padding:0;z-index:1}\n.gs-stage{position:absolute;inset:0;min-width:0;min-height:0;border:0;border-radius:0;overflow:hidden;background:#000}\n.gs-view,.gs-split{z-index:1}\n#videoView>.gs-video-frame{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}\n.gs-top{position:absolute;left:0;right:0;top:0;z-index:70;min-height:var(--gs-top-clear);padding:7px 9px;background:linear-gradient(to bottom,rgba(2,6,23,.90),rgba(2,6,23,.66));border-bottom:1px solid rgba(148,163,184,.38);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px)}\n.gs-bottom{position:absolute;left:0;right:0;bottom:0;z-index:70;min-height:var(--gs-bottom-clear);padding:7px 9px;background:linear-gradient(to top,rgba(2,6,23,.92),rgba(2,6,23,.62));border-top:1px solid rgba(148,163,184,.38);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px)}\n.gs-side{position:absolute;right:8px;top:calc(var(--gs-top-clear) + 8px);bottom:calc(var(--gs-bottom-clear) + 8px);width:min(360px,92vw);z-index:85;display:flex;transform:translateX(calc(100% + 24px));transition:transform .2s ease;background:rgba(2,6,23,.86);border:1px solid rgba(100,116,139,.75);border-radius:12px;padding:7px;overflow:auto;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);box-shadow:0 18px 50px rgba(0,0,0,.45)}\n.gs-side.open{transform:translateX(0)}\n.gs-panel{background:rgba(7,18,38,.70)}\n.gs-video-overlay{z-index:18}\n.gs-video-state{top:calc(var(--gs-top-clear) + 8px);background:rgba(2,6,23,.58);backdrop-filter:blur(4px)}\n.gs-video-controls{bottom:calc(var(--gs-bottom-clear) + 8px)}\n.gs-hud{z-index:22;overflow:visible}\n.gs-attitude-overlay{position:absolute;left:50%;top:50%;width:clamp(250px,36vw,370px);height:clamp(140px,21vw,205px);transform:translate(-50%,-50%);border:1px solid rgba(226,232,240,.68);border-radius:16px;overflow:hidden;background:rgba(2,6,23,.16);box-shadow:0 10px 34px rgba(0,0,0,.26),inset 0 0 26px rgba(2,6,23,.22);backdrop-filter:blur(1.5px);-webkit-backdrop-filter:blur(1.5px);transition:opacity .15s ease,border-color .15s ease}\n.gs-attitude-overlay.stale{border-color:rgba(248,113,113,.78)}\n.gs-attitude-overlay .gs-horizon-wrap{position:absolute;inset:0;width:100%;height:100%;transform:none;overflow:hidden}\n.gs-attitude-overlay .gs-horizon{left:-25%;top:-50%;width:150%;height:200%;background:linear-gradient(to bottom,rgba(34,118,165,.46) 0,rgba(76,167,208,.38) 46%,rgba(241,245,249,.78) 49.3%,rgba(241,245,249,.88) 50%,rgba(120,85,47,.40) 52%,rgba(61,43,29,.46) 100%);transition:transform .08s linear}\n.gs-attitude-overlay:before{content:"";position:absolute;left:50%;top:12%;bottom:12%;width:1px;background:linear-gradient(transparent,rgba(226,232,240,.55),transparent);z-index:2}\n.gs-attitude-overlay:after{content:"";position:absolute;top:50%;left:8%;right:8%;height:1px;background:rgba(226,232,240,.66);box-shadow:0 -24px 0 rgba(226,232,240,.28),0 24px 0 rgba(226,232,240,.28);z-index:2}\n.gs-attitude-overlay .gs-hud-mask{position:absolute;inset:0;background:radial-gradient(circle,transparent 0,rgba(2,6,23,.04) 54%,rgba(2,6,23,.34) 100%);z-index:3}\n.gs-attitude-overlay .gs-aircraft-symbol{z-index:6}\n.gs-attitude-overlay .gs-heading{z-index:7;top:7px;padding:4px 10px;font-size:15px;background:rgba(2,6,23,.52)}\n.gs-attitude-numbers{position:absolute;left:8px;right:8px;bottom:7px;z-index:7;display:flex;justify-content:center;gap:12px;font-size:11px;font-weight:800;color:#e2e8f0;text-shadow:0 1px 3px #000}\n.gs-attitude-overlay .gs-data-lost{left:50%;top:auto;bottom:31px;z-index:9;padding:5px 9px;font-size:10px;white-space:nowrap;background:rgba(127,29,29,.82)}\n.gs-telemetry-overlay{position:absolute;left:10px;bottom:calc(var(--gs-bottom-clear) + 10px);z-index:24;width:min(250px,31vw);display:grid;grid-template-columns:repeat(2,minmax(92px,1fr));gap:7px}\n.gs-telemetry-box{min-width:0;padding:8px 9px;border:1px solid rgba(148,163,184,.48);border-radius:10px;background:rgba(2,6,23,.52);box-shadow:0 6px 20px rgba(0,0,0,.18);backdrop-filter:blur(5px);-webkit-backdrop-filter:blur(5px);text-shadow:0 2px 4px rgba(0,0,0,.9)}\n.gs-telemetry-box .label{display:block;font-size:9px;letter-spacing:.10em;color:#cbd5e1;text-transform:uppercase}\n.gs-telemetry-box .reading{display:flex;align-items:baseline;gap:4px;margin-top:2px;white-space:nowrap}\n.gs-telemetry-box strong{font-size:22px;line-height:1;font-weight:900;overflow:hidden;text-overflow:ellipsis}\n.gs-telemetry-box em{font-size:9px;color:#bae6fd;font-style:normal}\n.gs-pip{right:10px;bottom:calc(var(--gs-bottom-clear) + 10px);z-index:36;touch-action:none;user-select:none;-webkit-user-select:none;will-change:left,top;cursor:grab}\n.gs-pip.dragging{cursor:grabbing;box-shadow:0 14px 42px rgba(0,0,0,.62);border-color:#7dd3fc}\n.gs-pip-label{cursor:grab}\n.gs-mode-overlay,.gs-tape{display:none!important}\n@media(max-width:1000px){.gs-main{display:block}.gs-side{width:min(340px,92vw)}.gs-telemetry-overlay{width:min(240px,34vw)}}\n@media(max-width:760px){\n :root{--gs-top-clear:52px;--gs-bottom-clear:50px}\n .gs-main{padding:0}.gs-stage{border:0;border-radius:0}\n .gs-side{right:5px;top:calc(var(--gs-top-clear) + 5px);bottom:calc(var(--gs-bottom-clear) + 5px);width:min(330px,92vw);padding:5px}\n .gs-top{min-height:var(--gs-top-clear)}.gs-bottom{min-height:var(--gs-bottom-clear)}\n .gs-attitude-overlay{width:min(58vw,330px);height:min(33vw,185px)}\n .gs-telemetry-overlay{left:7px;bottom:calc(var(--gs-bottom-clear) + 7px);width:min(230px,42vw);gap:5px}\n .gs-telemetry-box{padding:6px 7px}.gs-telemetry-box strong{font-size:19px}\n .gs-pip{width:38%;height:27%;right:7px;bottom:calc(var(--gs-bottom-clear) + 7px)}\n .gs-video-state{top:calc(var(--gs-top-clear) + 5px);left:7px}.gs-video-controls{left:7px;bottom:calc(var(--gs-bottom-clear) + 7px)}\n}\n\n/* GROUND_STATION_PHONE_HUD_UI_V7 */\n:root{--gs-top-clear:40px;--gs-bottom-clear:34px}\n.gs-top,.gs-bottom{\n  background:transparent!important;\n  border:0!important;\n  box-shadow:none!important;\n  backdrop-filter:none!important;\n  -webkit-backdrop-filter:none!important;\n  min-height:0!important;\n  max-height:none;\n  white-space:nowrap;\n}\n.gs-top{\n  height:var(--gs-top-clear);\n  padding:2px 5px!important;\n  gap:4px!important;\n  overflow-x:auto;\n  overflow-y:hidden;\n  scrollbar-width:none;\n}\n.gs-top::-webkit-scrollbar,.gs-bottom::-webkit-scrollbar{display:none}\n.gs-bottom{\n  height:var(--gs-bottom-clear);\n  padding:2px 5px!important;\n  gap:4px!important;\n  display:flex!important;\n  align-items:center;\n  overflow-x:auto;\n  overflow-y:hidden;\n}\n.gs-brand,.gs-chip,.gs-monitor,.gs-video-state,.gs-pip-label,.gs-camera-label{\n  background:transparent!important;\n  box-shadow:none!important;\n  backdrop-filter:none!important;\n  -webkit-backdrop-filter:none!important;\n}\n.gs-chip,.gs-monitor{\n  border-color:rgba(226,232,240,.34)!important;\n  padding:3px 6px!important;\n  border-radius:6px!important;\n  text-shadow:0 1px 3px rgba(0,0,0,.95);\n}\n.gs-btn,\n.gs-btn:hover,\n.gs-btn:focus,\n.gs-btn.active,\n.gs-btn.warn,\n.gs-btn.audio-on,\n.gs-btn.audio-muted{\n  background:transparent!important;\n  box-shadow:none!important;\n  backdrop-filter:none!important;\n  -webkit-backdrop-filter:none!important;\n  border-color:rgba(226,232,240,.38)!important;\n  color:#f8fafc!important;\n  text-shadow:0 1px 3px rgba(0,0,0,.95);\n}\n.gs-btn.active,.gs-btn:focus-visible{\n  border-color:#7dd3fc!important;\n  color:#bae6fd!important;\n  outline:none;\n}\n.gs-btn.compact{padding:4px 7px!important;font-size:10px!important;border-radius:6px!important}\n.gs-layout-buttons,.gs-source-buttons,.gs-dual-status,.gs-audio-controls{flex-wrap:nowrap!important;flex:0 0 auto}\n.gs-alert{flex:1 0 180px;text-shadow:0 1px 3px #000}\n.gs-monitor{flex:0 0 auto;font-size:9px!important}\n\n/* Only the moving level line and the small orange aircraft remain. */\n.gs-attitude-overlay{\n  position:absolute;\n  left:50%;\n  top:50%;\n  width:clamp(200px,34vw,340px)!important;\n  height:clamp(72px,12vw,112px)!important;\n  transform:translate(-50%,-50%);\n  overflow:visible!important;\n  border:0!important;\n  border-radius:0!important;\n  background:transparent!important;\n  box-shadow:none!important;\n  backdrop-filter:none!important;\n  -webkit-backdrop-filter:none!important;\n  pointer-events:none;\n}\n.gs-attitude-overlay.stale{border:0!important;opacity:.55}\n.gs-attitude-overlay:before,.gs-attitude-overlay:after,\n.gs-attitude-overlay .gs-hud-mask,\n.gs-attitude-overlay .gs-heading,\n.gs-attitude-overlay .gs-attitude-numbers,\n.gs-attitude-overlay .gs-data-lost{display:none!important}\n.gs-attitude-overlay .gs-horizon-wrap{position:absolute;inset:0;overflow:visible!important}\n.gs-attitude-overlay .gs-horizon{\n  position:absolute!important;\n  left:-15%!important;\n  top:50%!important;\n  width:130%!important;\n  height:0!important;\n  background:none!important;\n  border:0!important;\n  border-top:2px solid rgba(248,250,252,.94)!important;\n  box-shadow:0 1px 3px rgba(0,0,0,.95)!important;\n  transform-origin:50% 0!important;\n  transition:transform .08s linear;\n}\n.gs-attitude-overlay .gs-horizon:before,\n.gs-attitude-overlay .gs-horizon:after{\n  content:"";\n  position:absolute;\n  top:-5px;\n  width:1px;\n  height:9px;\n  background:rgba(248,250,252,.94);\n  box-shadow:0 1px 2px #000;\n}\n.gs-attitude-overlay .gs-horizon:before{left:34%}\n.gs-attitude-overlay .gs-horizon:after{right:34%}\n.gs-attitude-overlay .gs-aircraft-symbol{\n  z-index:6;\n  width:72px!important;\n  height:18px!important;\n}\n.gs-attitude-overlay .gs-aircraft-symbol:before,\n.gs-attitude-overlay .gs-aircraft-symbol:after{\n  top:8px!important;\n  width:28px!important;\n  height:3px!important;\n  background:#ff8a00!important;\n  box-shadow:0 0 3px rgba(0,0,0,.95)!important;\n}\n.gs-attitude-overlay .gs-aircraft-symbol span{\n  left:33px!important;\n  top:3px!important;\n  width:6px!important;\n  height:12px!important;\n  border-color:#ff8a00!important;\n  border-width:3px!important;\n  box-shadow:0 1px 2px rgba(0,0,0,.75);\n}\n\n/* Telemetry retains grouping but has no fill, border, blur or box shadow. */\n.gs-telemetry-overlay{\n  left:6px!important;\n  bottom:calc(var(--gs-bottom-clear) + 5px)!important;\n  width:min(244px,34vw)!important;\n  gap:4px!important;\n}\n.gs-telemetry-box{\n  padding:3px 5px!important;\n  border:0!important;\n  border-radius:0!important;\n  background:transparent!important;\n  box-shadow:none!important;\n  backdrop-filter:none!important;\n  -webkit-backdrop-filter:none!important;\n  text-shadow:0 2px 4px rgba(0,0,0,1)!important;\n}\n.gs-telemetry-box .label{font-size:8px!important;color:#e2e8f0!important}\n.gs-telemetry-box .reading{margin-top:0!important;gap:3px!important}\n.gs-telemetry-box strong{font-size:19px!important}\n.gs-telemetry-box em{font-size:8px!important;color:#e0f2fe!important}\n.gs-mode-overlay{background:transparent!important;border:0!important;box-shadow:none!important;text-shadow:0 1px 4px #000}\n\n/* Movable and touch-resizable PiP. */\n.gs-pip{\n  min-width:120px;\n  min-height:76px;\n  max-width:72vw;\n  max-height:64vh;\n  border:1px solid rgba(226,232,240,.58)!important;\n  box-shadow:0 7px 20px rgba(0,0,0,.38)!important;\n}\n.gs-pip-resize{\n  position:absolute;\n  right:0;\n  bottom:0;\n  z-index:12;\n  width:28px;\n  height:28px;\n  padding:0;\n  border:0;\n  border-radius:10px 0 0 0;\n  background:linear-gradient(135deg,transparent 0 44%,rgba(255,138,0,.95) 45% 54%,transparent 55% 66%,rgba(255,138,0,.95) 67% 76%,transparent 77%)!important;\n  cursor:nwse-resize;\n  touch-action:none;\n  opacity:.88;\n}\n.gs-pip.resizing{cursor:nwse-resize!important;border-color:#ff8a00!important}\n\n@media(max-width:760px), (max-height:560px){\n  :root{--gs-top-clear:32px;--gs-bottom-clear:29px}\n  .gs-top{height:var(--gs-top-clear);padding:1px 3px!important;gap:3px!important}\n  .gs-bottom{height:var(--gs-bottom-clear);padding:1px 3px!important;gap:3px!important}\n  .gs-logo{width:23px!important;height:23px!important;font-size:9px!important;border-radius:5px!important}\n  .gs-brand{gap:2px!important}\n  .gs-brand span{display:none!important}\n  .gs-chip{padding:2px 4px!important;font-size:9px!important;border-radius:5px!important}\n  .gs-chip.optional{display:none!important}\n  .gs-btn.compact{height:25px;padding:2px 5px!important;font-size:9px!important;border-radius:5px!important}\n  .gs-audio-controls{gap:3px!important}\n  #audioMuteBtn,#audioTestBtn,#audioVolume{display:none!important}\n  .gs-monitor{padding:2px 4px!important;font-size:8px!important}\n  .gs-alert{display:none!important}\n  .gs-dual-status{gap:3px!important;font-size:9px!important}\n  #dualVideoSummary{display:none!important}\n  #airlinkBufferState{max-width:92px!important}\n  .gs-side{top:calc(var(--gs-top-clear) + 3px)!important;bottom:calc(var(--gs-bottom-clear) + 3px)!important}\n  .gs-video-state{top:calc(var(--gs-top-clear) + 3px)!important;left:4px!important;padding:2px 4px!important;font-size:8px!important}\n  .gs-video-controls{left:4px!important;bottom:calc(var(--gs-bottom-clear) + 3px)!important;gap:3px!important}\n  .gs-attitude-overlay{width:min(48vw,235px)!important;height:min(21vw,78px)!important}\n  .gs-attitude-overlay .gs-aircraft-symbol{width:64px!important}\n  .gs-attitude-overlay .gs-aircraft-symbol:before,.gs-attitude-overlay .gs-aircraft-symbol:after{width:24px!important}\n  .gs-attitude-overlay .gs-aircraft-symbol span{left:29px!important}\n  .gs-telemetry-overlay{\n    left:3px!important;\n    bottom:calc(var(--gs-bottom-clear) + 3px)!important;\n    width:auto!important;\n    max-width:52vw;\n    grid-template-columns:repeat(2,minmax(72px,1fr))!important;\n    gap:2px 7px!important;\n  }\n  .gs-telemetry-box{padding:1px 2px!important}\n  .gs-telemetry-box .label{font-size:7px!important;letter-spacing:.06em!important}\n  .gs-telemetry-box strong{font-size:16px!important}\n  .gs-telemetry-box em{font-size:7px!important}\n  .gs-pip{\n    width:34vw;\n    height:24vh;\n    min-width:110px;\n    min-height:68px;\n    max-width:68vw;\n    max-height:58vh;\n    right:4px;\n    bottom:calc(var(--gs-bottom-clear) + 4px);\n    border-radius:7px!important;\n  }\n  .gs-camera-label{font-size:8px!important;padding:2px 4px!important}\n  .gs-pip-resize{width:30px;height:30px}\n}\n\n/* GROUND_STATION_PHONE_HUD_CLEANUP_V8 */\n\n/* Remove duplicate lower-left telemetry and diagnostic clutter. */\n.gs-telemetry-overlay{display:none!important}\n.gs-dual-status,.gs-monitor{display:none!important}\n#airlinkBufferState,#resyncAirlinkBtn,#swapCamerasBtn{display:none!important}\n\n/* Split means navigation map plus the currently selected main camera. */\n.gs-split{\n  grid-template-columns:1fr 1fr!important;\n  gap:1px!important;\n  padding:0!important;\n  background:transparent!important;\n}\n.gs-split>div{\n  border:0!important;\n  border-radius:0!important;\n  background:#000!important;\n}\n.gs-split-map-pane{position:relative;min-width:0;min-height:0}\n.gs-split-video-pane{position:relative;min-width:0;min-height:0}\n.gs-split-video-pane .gs-video-frame{position:absolute;inset:0;object-fit:cover}\n\n/* Instruments: only text and values remain visible. */\n.gs-side{\n  --instrument-scale:1;\n  right:auto!important;\n  bottom:auto!important;\n  width:min(330px,92vw)!important;\n  height:min(72vh,520px)!important;\n  min-width:180px!important;\n  min-height:140px!important;\n  max-width:96vw!important;\n  max-height:calc(100dvh - var(--gs-top-clear) - var(--gs-bottom-clear) - 6px)!important;\n  padding:0!important;\n  overflow:hidden!important;\n  background:transparent!important;\n  border:0!important;\n  border-radius:0!important;\n  box-shadow:none!important;\n  backdrop-filter:none!important;\n  -webkit-backdrop-filter:none!important;\n  touch-action:none;\n}\n.gs-side.open{transform:none!important}\n.gs-instruments-drag{\n  position:absolute;\n  left:0;\n  right:0;\n  top:0;\n  z-index:5;\n  height:22px;\n  display:flex;\n  align-items:center;\n  justify-content:center;\n  color:#e2e8f0;\n  font-size:calc(10px * var(--instrument-scale));\n  font-weight:900;\n  letter-spacing:.12em;\n  text-shadow:0 2px 4px #000;\n  cursor:grab;\n  touch-action:none;\n  user-select:none;\n  -webkit-user-select:none;\n}\n.gs-side.instrument-dragging .gs-instruments-drag{cursor:grabbing}\n.gs-instruments-content{\n  position:absolute;\n  left:0;\n  right:0;\n  top:22px;\n  bottom:0;\n  overflow:auto;\n  padding:0;\n  scrollbar-width:none;\n  touch-action:pan-y;\n}\n.gs-instruments-content::-webkit-scrollbar{display:none}\n.gs-side .gs-panel,\n.gs-side .gs-tile,\n.gs-side .gs-message{\n  background:transparent!important;\n  border:0!important;\n  border-radius:0!important;\n  box-shadow:none!important;\n  backdrop-filter:none!important;\n  -webkit-backdrop-filter:none!important;\n}\n.gs-side .gs-panel{padding:calc(5px * var(--instrument-scale))!important}\n.gs-side .gs-panel-title{\n  margin-bottom:calc(5px * var(--instrument-scale))!important;\n  font-size:calc(10px * var(--instrument-scale))!important;\n  color:#c7d2fe!important;\n  text-shadow:0 2px 4px #000;\n}\n.gs-side .gs-grid{gap:calc(4px * var(--instrument-scale))!important}\n.gs-side .gs-tile{padding:calc(4px * var(--instrument-scale))!important;text-shadow:0 2px 4px #000}\n.gs-side .gs-tile .k{\n  font-size:calc(8px * var(--instrument-scale))!important;\n  color:#cbd5e1!important;\n}\n.gs-side .gs-tile .v{\n  font-size:calc(16px * var(--instrument-scale))!important;\n  margin-top:calc(1px * var(--instrument-scale))!important;\n}\n.gs-side .gs-tile .s{\n  font-size:calc(8px * var(--instrument-scale))!important;\n  color:#cbd5e1!important;\n}\n.gs-side .gs-mission-line{\n  font-size:calc(11px * var(--instrument-scale))!important;\n  line-height:1.4!important;\n  text-shadow:0 2px 4px #000;\n}\n.gs-side .gs-message-list{\n  height:calc(120px * var(--instrument-scale))!important;\n  font-size:calc(10px * var(--instrument-scale))!important;\n}\n.gs-side .gs-message{\n  padding:calc(3px * var(--instrument-scale))!important;\n  margin-bottom:calc(2px * var(--instrument-scale))!important;\n  text-shadow:0 2px 4px #000;\n}\n.gs-instruments-resize{\n  position:absolute;\n  z-index:9;\n  width:34px;\n  height:34px;\n  padding:0;\n  border:0;\n  background:transparent;\n  opacity:.01;\n  touch-action:none;\n}\n.gs-instruments-resize.nw{left:0;top:0;cursor:nwse-resize}\n.gs-instruments-resize.ne{right:0;top:0;cursor:nesw-resize}\n.gs-instruments-resize.sw{left:0;bottom:0;cursor:nesw-resize}\n.gs-instruments-resize.se{right:0;bottom:0;cursor:nwse-resize}\n\n/* PiP can be resized from every corner. */\n.gs-pip-resize{\n  width:32px!important;\n  height:32px!important;\n  border:0!important;\n  border-radius:0!important;\n  background:transparent!important;\n  opacity:1!important;\n  touch-action:none!important;\n}\n.gs-pip-resize.nw{left:0!important;right:auto!important;top:0!important;bottom:auto!important;cursor:nwse-resize!important}\n.gs-pip-resize.ne{right:0!important;left:auto!important;top:0!important;bottom:auto!important;cursor:nesw-resize!important}\n.gs-pip-resize.sw{left:0!important;right:auto!important;bottom:0!important;top:auto!important;cursor:nesw-resize!important}\n.gs-pip-resize.se{right:0!important;left:auto!important;bottom:0!important;top:auto!important;cursor:nwse-resize!important}\n/* V20_PIP_CORNER_CLEANUP_ONLY\n   Keep all four invisible resize hit zones; render no corner artwork. */\n.gs-pip-resize:before{content:none!important;display:none!important}\n\n/* Phone-first vertical efficiency. */\n@media(max-width:760px), (max-height:560px){\n  :root{--gs-top-clear:28px;--gs-bottom-clear:24px}\n  .gs-top{height:var(--gs-top-clear)!important;padding:1px 2px!important;gap:2px!important}\n  .gs-bottom{height:var(--gs-bottom-clear)!important;padding:1px 2px!important;gap:2px!important}\n  .gs-logo{width:21px!important;height:21px!important}\n  .gs-chip{padding:1px 3px!important;font-size:8px!important}\n  .gs-btn.compact{height:21px!important;padding:1px 4px!important;font-size:8px!important}\n  .gs-layout-buttons{gap:2px!important}\n  .gs-side{\n    max-height:calc(100dvh - var(--gs-top-clear) - var(--gs-bottom-clear) - 4px)!important;\n  }\n  .gs-instruments-drag{height:19px}\n  .gs-instruments-content{top:19px}\n  .gs-pip-resize{width:34px!important;height:34px!important}\n}\n\n\n/* GROUND_STATION_PHONE_HUD_REFINEMENT_V9 */\n\n/* Remove obsolete/diagnostic text without touching the WebRTC sessions. */\n#heartbeatAge,.gs-video-protocol,.gs-video-controls{display:none!important}\n.gs-video-state{display:block!important}\n.gs-video-state span{display:inline!important}\n#controlCenterBtn{display:inline-flex;align-items:center;justify-content:center;text-decoration:none}\n\n/* Instruments disappear completely when closed. */\n.gs-side:not(.open){\n  display:none!important;\n  visibility:hidden!important;\n  pointer-events:none!important;\n}\n.gs-side.open{\n  display:block!important;\n  visibility:visible!important;\n  pointer-events:auto!important;\n  transform:none!important;\n}\n.gs-side{\n  --instrument-scale:1;\n  position:fixed!important;\n  z-index:90!important;\n  left:auto;\n  right:2px!important;\n  top:calc(var(--gs-top-clear) + 2px)!important;\n  bottom:auto!important;\n  width:min(300px,46vw)!important;\n  height:min(70vh,480px)!important;\n  min-width:150px!important;\n  min-height:120px!important;\n  max-width:calc(100vw - 4px)!important;\n  max-height:calc(100dvh - var(--gs-top-clear) - var(--gs-bottom-clear) - 4px)!important;\n  margin:0!important;\n  padding:0!important;\n  overflow:hidden!important;\n  background:transparent!important;\n  border:0!important;\n  border-radius:0!important;\n  box-shadow:none!important;\n  backdrop-filter:none!important;\n  -webkit-backdrop-filter:none!important;\n  transition:none!important;\n  touch-action:none!important;\n}\n.gs-instruments-drag{\n  height:22px!important;\n  cursor:grab;\n  touch-action:none!important;\n}\n.gs-side.instrument-dragging .gs-instruments-drag{cursor:grabbing}\n.gs-instruments-content{top:22px!important;touch-action:pan-y!important}\n.gs-side .gs-grid{\n  display:grid!important;\n  grid-template-columns:repeat(auto-fit,minmax(105px,1fr))!important;\n  align-items:start!important;\n  gap:calc(4px * var(--instrument-scale))!important;\n}\n.gs-side .gs-tile{min-width:0!important}\n.gs-instruments-resize{\n  width:48px!important;\n  height:48px!important;\n  opacity:0!important;\n  pointer-events:auto!important;\n  touch-action:none!important;\n}\n\n/* Long-hold PiP minimises it to an edge control while the video stays attached. */\n.gs-pip-edge-button{display:none}\n.gs-pip.pip-minimized{\n  left:auto!important;\n  top:auto!important;\n  right:0!important;\n  bottom:var(--gs-bottom-clear)!important;\n  width:38px!important;\n  height:48px!important;\n  min-width:38px!important;\n  min-height:48px!important;\n  border:1px solid rgba(255,138,0,.92)!important;\n  border-right:0!important;\n  border-radius:10px 0 0 10px!important;\n  overflow:hidden!important;\n  background:rgba(2,6,23,.22)!important;\n  box-shadow:none!important;\n  cursor:pointer!important;\n}\n.gs-pip.pip-minimized .gs-video-frame{\n  position:absolute!important;\n  left:0!important;\n  top:0!important;\n  width:1px!important;\n  height:1px!important;\n  opacity:0!important;\n  pointer-events:none!important;\n}\n.gs-pip.pip-minimized .gs-camera-label,\n.gs-pip.pip-minimized .gs-pip-resize{display:none!important}\n.gs-pip.pip-minimized .gs-pip-edge-button{\n  position:absolute;\n  inset:0;\n  z-index:20;\n  display:flex!important;\n  align-items:center;\n  justify-content:center;\n  padding:0;\n  border:0;\n  background:transparent;\n  color:#ff9b28;\n  font-size:9px;\n  font-weight:900;\n  letter-spacing:.08em;\n  text-shadow:0 1px 3px #000;\n  touch-action:manipulation;\n}\n\n@media(max-width:760px), (max-height:560px){\n  .gs-side{\n    width:min(280px,46vw)!important;\n    height:min(72dvh,430px)!important;\n    min-width:145px!important;\n    min-height:110px!important;\n  }\n  .gs-instruments-drag{height:19px!important;font-size:calc(9px * var(--instrument-scale))!important}\n  .gs-instruments-content{top:19px!important}\n  .gs-side .gs-grid{grid-template-columns:repeat(auto-fit,minmax(92px,1fr))!important}\n  .gs-instruments-resize{width:50px!important;height:50px!important}\n}\n\n\n/* GROUND_STATION_PHONE_HUD_TELEMETRY_V10 */\n\n/* Stream name only: protocol text is removed from the DOM in V10. */\n.gs-video-state{display:block!important}\n.gs-video-protocol{display:none!important}\n\n/* The connection chip also opens the vehicle-message viewer. */\n.gs-connection-chip{\n  appearance:none;\n  -webkit-appearance:none;\n  font:inherit;\n  color:inherit;\n  cursor:pointer;\n  touch-action:manipulation;\n}\n.gs-connection-chip:active{opacity:.72}\n\n/* Telemetry-only panel. No heading, frame or background. */\n.gs-side{\n  --instrument-scale:1;\n  left:var(--telemetry-left,calc(100vw - var(--telemetry-width,156px) - 2px))!important;\n  top:var(--telemetry-top,calc(100dvh - var(--telemetry-height,300px) - 2px))!important;\n  right:auto!important;\n  bottom:auto!important;\n  width:var(--telemetry-width,156px)!important;\n  height:var(--telemetry-height,300px)!important;\n  min-width:112px!important;\n  min-height:76px!important;\n  max-width:calc(100vw - 4px)!important;\n  max-height:calc(100dvh - var(--gs-top-clear) - 4px)!important;\n  z-index:96!important;\n  overflow:hidden!important;\n  padding:0!important;\n  margin:0!important;\n  background:transparent!important;\n  border:0!important;\n  border-radius:0!important;\n  box-shadow:none!important;\n  backdrop-filter:none!important;\n  -webkit-backdrop-filter:none!important;\n  touch-action:none!important;\n  user-select:none;\n  -webkit-user-select:none;\n}\n.gs-side.open{display:block!important;visibility:visible!important;pointer-events:auto!important}\n.gs-side:not(.open){display:none!important;visibility:hidden!important;pointer-events:none!important}\n.gs-telemetry-content{\n  position:absolute;\n  inset:0;\n  overflow:hidden;\n  padding:0;\n  touch-action:none;\n}\n.gs-side #telemetryGrid{\n  display:grid!important;\n  grid-template-columns:repeat(auto-fit,minmax(min(106px,100%),1fr))!important;\n  grid-auto-flow:row!important;\n  align-content:start!important;\n  align-items:stretch!important;\n  gap:calc(2px * var(--instrument-scale))!important;\n  width:100%!important;\n  height:100%!important;\n  padding:0!important;\n  margin:0!important;\n}\n.gs-side .gs-tile{\n  min-width:0!important;\n  min-height:calc(23px * var(--instrument-scale))!important;\n  display:grid!important;\n  grid-template-columns:minmax(0,1fr) auto!important;\n  grid-template-areas:\'label value\'!important;\n  align-items:center!important;\n  column-gap:calc(5px * var(--instrument-scale))!important;\n  padding:calc(2px * var(--instrument-scale)) calc(3px * var(--instrument-scale))!important;\n  margin:0!important;\n  overflow:hidden!important;\n  background:transparent!important;\n  border:0!important;\n  border-radius:0!important;\n  box-shadow:none!important;\n  text-shadow:0 2px 4px #000!important;\n}\n.gs-side .gs-tile .k{\n  grid-area:label;\n  overflow:hidden;\n  text-overflow:ellipsis;\n  white-space:nowrap;\n  font-size:calc(8px * var(--instrument-scale))!important;\n  color:#dbeafe!important;\n  line-height:1.05!important;\n}\n.gs-side .gs-tile .v{\n  grid-area:value;\n  margin:0!important;\n  white-space:nowrap;\n  text-align:right;\n  font-size:calc(12px * var(--instrument-scale))!important;\n  line-height:1!important;\n}\n.gs-side .gs-tile .s{display:none!important}\n.gs-side.instrument-dragging{cursor:grabbing!important}\n.gs-side.instrument-resizing{cursor:nwse-resize!important}\n\n/* Large invisible corner targets keep the panel visually transparent. */\n.gs-instruments-resize{\n  position:absolute!important;\n  z-index:15!important;\n  width:42px!important;\n  height:42px!important;\n  padding:0!important;\n  border:0!important;\n  background:transparent!important;\n  opacity:0!important;\n  pointer-events:auto!important;\n  touch-action:none!important;\n}\n.gs-instruments-resize.nw{left:0!important;top:0!important}\n.gs-instruments-resize.ne{right:0!important;top:0!important}\n.gs-instruments-resize.sw{left:0!important;bottom:0!important}\n.gs-instruments-resize.se{right:0!important;bottom:0!important}\n\n/* Messages open by tapping CONNECTED / connection state. */\n.gs-message-popover{\n  position:fixed;\n  z-index:110;\n  left:2px;\n  top:calc(var(--gs-top-clear) + 2px);\n  width:min(420px,calc(100vw - 4px));\n  max-height:calc(100dvh - var(--gs-top-clear) - 4px);\n  display:none;\n  overflow:hidden;\n  padding:4px;\n  background:rgba(2,6,23,.82);\n  border:1px solid rgba(148,163,184,.32);\n  border-radius:7px;\n  box-shadow:0 8px 26px rgba(0,0,0,.38);\n  backdrop-filter:blur(4px);\n  -webkit-backdrop-filter:blur(4px);\n}\n.gs-message-popover.open{display:block}\n.gs-message-popover-head{\n  display:flex;\n  align-items:center;\n  justify-content:space-between;\n  gap:8px;\n  padding:2px 3px 5px;\n  font-size:10px;\n  color:#e2e8f0;\n}\n.gs-message-popover-close{\n  width:24px;\n  height:22px;\n  padding:0;\n  border:0;\n  background:transparent;\n  color:#fff;\n  font-size:18px;\n  line-height:1;\n}\n.gs-message-popover .gs-message-list{\n  max-height:calc(100dvh - var(--gs-top-clear) - 42px);\n  overflow:auto;\n  padding:0;\n  background:transparent!important;\n  border:0!important;\n}\n.gs-message-popover .gs-message{\n  padding:4px 3px!important;\n  margin:0 0 2px!important;\n  background:transparent!important;\n  border:0!important;\n  text-shadow:0 1px 3px #000;\n}\n\n@media(max-width:760px), (max-height:560px){\n  .gs-side{\n    --telemetry-width:148px;\n    --telemetry-height:292px;\n    min-width:108px!important;\n    min-height:70px!important;\n  }\n  .gs-side #telemetryGrid{\n    grid-template-columns:repeat(auto-fit,minmax(min(96px,100%),1fr))!important;\n  }\n  .gs-instruments-resize{width:46px!important;height:46px!important}\n  .gs-message-popover{\n    width:min(360px,calc(100vw - 4px));\n    padding:3px;\n  }\n}\n\n\n\n\n/* GROUND_STATION_PHONE_VIEWPORT_V11 */\n/* GROUND_STATION_PHONE_VIEWPORT_V12 */\n/* GROUND_STATION_PHONE_UI_V13 */\n/* GROUND_STATION_PHONE_UI_V14 */\n\nhtml,body{width:100%!important;height:100%!important;margin:0!important;overflow:hidden!important;overscroll-behavior:none}\n:root{--gs-vv-width:100vw;--gs-vv-height:100dvh}\n.gs-app{position:fixed!important;inset:0!important;width:var(--gs-vv-width)!important;height:var(--gs-vv-height)!important;max-width:none!important;max-height:none!important;overflow:hidden!important}\n\n.gs-top,.gs-bottom{position:absolute!important;left:0!important;right:0!important;width:auto!important;min-width:0!important;max-width:none!important;box-sizing:border-box!important;overflow-y:hidden!important;direction:ltr!important;scrollbar-width:none}\n.gs-top::-webkit-scrollbar,.gs-bottom::-webkit-scrollbar,.gs-top-left::-webkit-scrollbar,.gs-telemetry-content::-webkit-scrollbar{display:none}\n.gs-top{top:0!important;display:flex!important;align-items:center!important;gap:4px!important}\n.gs-bottom{bottom:0!important}\n\n/* Independent left and right groups prevent GS, MODE and DISARMED overlap. */\n.gs-top-left{display:flex;align-items:center;gap:4px;min-width:0;flex:1 1 auto;overflow-x:auto;overflow-y:hidden;white-space:nowrap;scrollbar-width:none}\n.gs-top-right{display:flex;align-items:center;justify-content:flex-end;gap:3px;flex:0 0 auto;white-space:nowrap}\n.gs-top-left>*{position:static!important;transform:none!important;flex:0 0 auto!important}\n.gs-top-left .gs-brand{margin-right:1px!important;gap:4px!important}\n.gs-top-left .gs-chip{margin:0!important}\n.gs-top-right .gs-audio-controls{display:flex;align-items:center;gap:3px;flex:0 0 auto!important}\n.gs-top-right>.gs-btn,.gs-top-right .gs-btn{flex:0 0 auto!important}\n\n.gs-layout-buttons{display:flex!important;flex:0 0 auto!important;margin:0!important;padding:0!important}\n\n/* Telemetry panel: content scrolls, panel moves from its invisible edge band. */\n.gs-side{position:fixed!important;left:var(--telemetry-left,auto)!important;top:var(--telemetry-top,auto)!important;right:auto!important;bottom:auto!important;width:var(--telemetry-width,230px)!important;height:var(--telemetry-height,250px)!important;min-width:110px!important;min-height:80px!important;max-width:none!important;max-height:none!important;contain:none!important;overflow:hidden!important;padding:10px!important;box-sizing:border-box!important;touch-action:auto!important}\n.gs-side.open{transform:none!important}\n.gs-telemetry-content{position:absolute;inset:10px;overflow:auto!important;overscroll-behavior:contain;scrollbar-width:none;touch-action:pan-x pan-y!important}\n.gs-side #telemetryGrid{display:grid!important;grid-template-columns:repeat(var(--telemetry-cols,2),var(--telemetry-cell-width,104px))!important;grid-template-rows:repeat(var(--telemetry-rows,6),var(--telemetry-cell-height,42px))!important;grid-auto-columns:var(--telemetry-cell-width,104px)!important;grid-auto-rows:var(--telemetry-cell-height,42px)!important;grid-auto-flow:row!important;align-content:start!important;align-items:stretch!important;gap:var(--telemetry-gap,3px)!important;width:max(100%,var(--telemetry-grid-width,210px))!important;min-height:max(100%,var(--telemetry-grid-height,267px))!important}\n.gs-side .gs-tile{min-width:0!important;min-height:0!important;display:grid!important;grid-template-columns:minmax(0,1fr)!important;grid-template-rows:auto 1fr auto!important;grid-template-areas:\'label\' \'value\' \'description\'!important;align-content:center!important;gap:1px!important;padding:3px 5px!important;overflow:hidden!important;background:transparent!important;border:0!important;box-shadow:none!important}\n.gs-side .gs-tile .k{grid-area:label;font-size:calc(var(--telemetry-font-size,16px) * .62)!important;line-height:1.05!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;color:#cbd5e1!important}\n.gs-side .gs-tile .v{grid-area:value;font-size:var(--telemetry-font-size,16px)!important;line-height:1.05!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;color:#f8fafc!important}\n.gs-side .gs-tile .s{grid-area:description;display:none!important;font-size:calc(var(--telemetry-font-size,16px) * .55)!important;line-height:1.05!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;color:#94a3b8!important}\n.gs-side.show-descriptions .gs-tile .s{display:block!important}\n\n/* V14 has no visible resize corners. Size is set in the hold menu. */\n.gs-instruments-resize,.gs-telemetry-layout-badge{display:none!important}\n\n.gs-telemetry-settings-backdrop{position:fixed;inset:0;z-index:119;display:none;background:rgba(0,0,0,.42)}\n.gs-telemetry-settings-backdrop.open{display:block}\n.gs-telemetry-settings{position:fixed;left:50%;top:50%;z-index:120;display:none;width:min(340px,calc(100vw - 24px));max-height:calc(100dvh - 24px);overflow:auto;transform:translate(-50%,-50%);padding:12px;border:1px solid #64748b;border-radius:12px;background:rgba(2,6,23,.96);box-shadow:0 18px 60px rgba(0,0,0,.65);color:#e2e8f0}\n.gs-telemetry-settings.open{display:block}\n.gs-telemetry-settings-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;font-weight:900}\n.gs-telemetry-settings-close{border:0;background:transparent;color:#e2e8f0;font-size:22px;line-height:1;padding:2px 5px}\n.gs-telemetry-settings-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}\n.gs-telemetry-setting{display:grid;gap:4px;font-size:11px;font-weight:800;color:#cbd5e1}\n.gs-telemetry-setting input[type=number]{width:100%;box-sizing:border-box;border:1px solid #475569;border-radius:7px;background:#0f172a;color:#f8fafc;padding:7px 8px;font-size:14px}\n.gs-telemetry-setting.wide{grid-column:1/-1}\n.gs-telemetry-check{grid-column:1/-1;display:flex;align-items:center;gap:8px;font-size:13px;font-weight:800}\n.gs-telemetry-settings-note{grid-column:1/-1;font-size:10px;line-height:1.35;color:#94a3b8}\n.gs-telemetry-settings-actions{display:flex;justify-content:flex-end;gap:7px;margin-top:11px}\n.gs-telemetry-settings-actions .gs-btn{padding:7px 10px}\n\n@media(max-width:1000px),(pointer:coarse){\n  html.gs-phone-host .gs-top{padding-left:max(14px,env(safe-area-inset-left))!important;padding-right:max(8px,env(safe-area-inset-right))!important;overflow:hidden!important}\n  html.gs-phone-host .gs-bottom{display:flex!important;align-items:center!important;justify-content:flex-start!important;padding-left:max(14px,env(safe-area-inset-left))!important;padding-right:max(8px,env(safe-area-inset-right))!important;padding-bottom:max(1px,env(safe-area-inset-bottom))!important;overflow-x:hidden!important}\n  html.gs-phone-host .gs-top-left{gap:3px;flex:1 1 auto!important}\n  html.gs-phone-host .gs-top-right{gap:2px;flex:0 0 auto!important}\n  html.gs-phone-host .gs-logo{width:24px!important;height:24px!important;border-radius:6px!important;font-size:10px!important}\n  html.gs-phone-host .gs-brand span:last-child{display:none!important}\n  html.gs-phone-host .gs-top-left .gs-chip{padding:2px 4px!important;font-size:8px!important;border-radius:6px!important}\n  html.gs-phone-host .gs-top-left .gs-chip strong{font-size:9px!important}\n  html.gs-phone-host #connectionChip{max-width:90px;overflow:hidden;text-overflow:ellipsis}\n  html.gs-phone-host .gs-top-right .gs-btn{height:21px!important;padding:1px 4px!important;font-size:8px!important;border-radius:6px!important}\n  html.gs-phone-host .gs-top-right .gs-audio-controls{gap:2px!important}\n  html.gs-phone-host .gs-top-right .audio-secondary,html.gs-phone-host .gs-top-right .gs-volume{display:none!important}\n}\n\nhtml.gs-phone-host.gs-native-fullscreen #fullscreenBtn{display:none!important}\n\n\n/* GROUND_STATION_PHONE_UI_V15 */\n\n/* Movement is explicit: settings -> Move box -> drag anywhere. */\n.gs-side.telemetry-move-mode{\n  cursor:move!important;\n  touch-action:none!important;\n  box-shadow:0 0 0 2px rgba(255,155,40,.92),0 10px 30px rgba(0,0,0,.42)!important;\n}\n.gs-side.telemetry-move-mode .gs-telemetry-content{\n  pointer-events:none!important;\n  touch-action:none!important;\n}\n.gs-telemetry-move-hint{\n  position:absolute;\n  left:50%;\n  top:50%;\n  z-index:30;\n  display:none;\n  transform:translate(-50%,-50%);\n  padding:7px 10px;\n  border:1px solid rgba(255,155,40,.9);\n  border-radius:8px;\n  background:rgba(2,6,23,.88);\n  color:#ffb45e;\n  font-size:11px;\n  font-weight:900;\n  white-space:nowrap;\n  text-shadow:0 1px 2px #000;\n  pointer-events:none;\n}\n.gs-side.telemetry-move-mode .gs-telemetry-move-hint{display:block}\n#telemetryMoveBtn{margin-right:auto}\n\n/* GROUND_STATION_ANDROID_JOYSTICK_CONTROL_STAGE2_V10_RECORD_INDICATOR */\n@keyframes gs-record-blink{0%,44%{opacity:1;box-shadow:0 0 0 0 rgba(239,68,68,.75)}50%,100%{opacity:.24;box-shadow:0 0 0 5px rgba(239,68,68,0)}}\n.gs-record-chip{display:none!important;border-color:rgba(248,113,113,.72)!important;background:rgba(127,29,29,.52)!important;color:#fecaca!important}\n.gs-record-chip.active{display:inline-flex!important}\n.gs-record-dot{width:9px;height:9px;border-radius:999px;background:#ef4444;animation:gs-record-blink 1s steps(1,end) infinite;flex:0 0 auto}\n.gs-joystick-backdrop{position:fixed;inset:0;z-index:180;display:none;background:rgba(0,0,0,.60);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px)}\n.gs-joystick-backdrop.open{display:block}\n.gs-joystick-panel{position:fixed;z-index:181;left:50%;top:50%;display:none;transform:translate(-50%,-50%);width:min(980px,96vw);height:min(780px,94dvh);overflow:auto;border:1px solid #64748b;border-radius:14px;background:#061124;color:#f8fafc;box-shadow:0 24px 80px rgba(0,0,0,.72);padding:12px}\n.gs-joystick-panel.open{display:block}\n.gs-joystick-head{position:sticky;top:-12px;z-index:3;display:flex;align-items:center;gap:8px;padding:10px 4px;background:#061124;border-bottom:1px solid #334155}\n.gs-joystick-head strong{font-size:17px}.gs-joystick-close{margin-left:auto;border:1px solid #64748b;background:#111c31;color:#fff;border-radius:8px;width:34px;height:34px;font-size:22px}\n.gs-joystick-banner{margin:10px 0;padding:9px 11px;border:1px solid #f59e0b;border-radius:9px;background:#451a03;color:#fde68a;font-weight:900;text-align:center}\n.gs-joystick-banner.test{border-color:#38bdf8;background:#082f49;color:#bae6fd}\n.gs-joystick-banner.control-active{border-color:#f97316;background:#7c2d12;color:#ffedd5}\n.gs-joystick-control-state{font-size:11px;font-weight:800;color:#fbbf24}\n.gs-joystick-control-state.ready{color:#86efac}\n.gs-joystick-control-state.active{color:#fb923c}\n.gs-joystick-control-button.active{background:#9a3412!important;border-color:#fb923c!important;color:#fff7ed!important}\n.gs-joystick-active{color:#fb923c!important;border-color:rgba(251,146,60,.8)!important;background:transparent!important;box-shadow:none!important;font-weight:800}\n.gs-joystick-sections{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.gs-joystick-card{min-width:0;border:1px solid #334155;border-radius:11px;background:#081427;padding:10px}.gs-joystick-card.wide{grid-column:1/-1}.gs-joystick-title{font-size:11px;letter-spacing:.11em;text-transform:uppercase;color:#a5b4fc;font-weight:900;margin-bottom:8px}\n.gs-joystick-row{display:flex;align-items:center;gap:7px;flex-wrap:wrap;margin:6px 0}.gs-joystick-row label{font-size:11px;color:#cbd5e1}.gs-joystick-select,.gs-joystick-input{min-height:34px;border:1px solid #475569;border-radius:7px;background:#0b1220;color:#fff;padding:5px 7px}.gs-joystick-select{min-width:180px;max-width:100%}.gs-joystick-kv{display:grid;grid-template-columns:130px minmax(0,1fr);gap:5px 8px;font-size:12px}.gs-joystick-kv span:nth-child(odd){color:#94a3b8}.gs-joystick-kv span:nth-child(even){overflow-wrap:anywhere;font-weight:700}\n.gs-axis-list{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.gs-axis-item{border:1px solid #334155;border-radius:8px;padding:7px;background:#050d1a}.gs-axis-head{display:flex;justify-content:space-between;gap:8px;font-size:11px}.gs-axis-bar{position:relative;height:12px;margin:6px 0;border:1px solid #475569;border-radius:999px;background:#111827;overflow:hidden}.gs-axis-bar i{position:absolute;left:50%;top:0;bottom:0;width:2px;background:#94a3b8}.gs-axis-bar b{position:absolute;top:1px;bottom:1px;left:50%;width:0;background:#38bdf8;border-radius:999px}.gs-axis-meta{font-size:9px;color:#94a3b8;display:flex;justify-content:space-between;gap:5px}\n.gs-button-grid{display:flex;gap:5px;flex-wrap:wrap}.gs-button-dot{border:1px solid #475569;border-radius:7px;padding:5px 7px;background:#0b1220;color:#94a3b8;font-size:10px}.gs-button-dot.on{border-color:#4ade80;background:#14532d;color:#dcfce7;box-shadow:0 0 8px rgba(74,222,128,.55)}\n.gs-map-table{width:100%;border-collapse:collapse;font-size:11px}.gs-map-table th,.gs-map-table td{padding:5px;border-bottom:1px solid #334155;text-align:left}.gs-map-table input[type=number]{width:72px}.gs-map-table select{width:150px;max-width:34vw}.gs-joystick-status-ok{color:#4ade80}.gs-joystick-status-warn{color:#fbbf24}.gs-joystick-status-bad{color:#f87171}\n.gs-joystick-ready{color:var(--ok)!important;border-color:rgba(226,232,240,.38)!important;background:transparent!important;box-shadow:none!important;font-weight:700}\n@media(max-width:760px){.gs-joystick-panel{width:100vw;height:100dvh;border:0;border-radius:0;padding:8px}.gs-joystick-head{top:-8px}.gs-joystick-sections{grid-template-columns:1fr}.gs-axis-list{grid-template-columns:1fr}.gs-joystick-kv{grid-template-columns:102px minmax(0,1fr)}.gs-map-table{font-size:9px}.gs-map-table th,.gs-map-table td{padding:3px}.gs-map-table select{width:105px}.gs-map-table input[type=number]{width:55px}}\n\n/* GROUNDSTATION_V19_VIDEO_MAP_TOGGLE_FLOATING_MAP_PIP_COMPASS */\n.gs-map-status{top:calc(var(--gs-top-clear) + 6px)!important;left:7px!important;max-width:min(46vw,420px)!important}\n.gs-map-toolbar{top:calc(var(--gs-top-clear) + 6px)!important;right:7px!important}\n.gs-map-video-pip{z-index:45!important;cursor:grab!important;touch-action:none!important;user-select:none!important;-webkit-user-select:none!important;will-change:left,top,width,height}\n.gs-map-video-pip.dragging{cursor:grabbing!important;border-color:#7dd3fc!important;box-shadow:0 14px 42px rgba(0,0,0,.62)!important}\n.gs-map-video-pip.resizing{border-color:#7dd3fc!important}\n.gs-round-compass{position:absolute;inset:0;pointer-events:none}\n.gs-round-cardinal{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);min-width:1.1em;text-align:center;color:rgba(248,250,252,.96);font-size:clamp(8px,7cqw,14px);font-weight:900;line-height:1;text-shadow:0 1px 3px #000,0 0 3px #000;opacity:0;transition:left .07s linear,top .07s linear,opacity .15s ease}\n.gs-round-cardinal.show{opacity:1}\n/* GROUND_STATION_ROUND_HUD_V2_8_9_UI_REDESIGN */\n/* GROUND_STATION_ROUND_HUD_V2_8_10_SIMPLIFIED_ADAPTIVE_LADDER */\n.gs-round-hud{\n  filter:drop-shadow(0 14px 34px rgba(0,0,0,.55));\n}\n.gs-round-hud.dragging .gs-round-face,\n.gs-round-hud.resizing .gs-round-face{\n  border-color:#7dd3fc!important;\n  box-shadow:\n    0 0 0 3px rgba(56,189,248,.16),\n    0 18px 45px rgba(0,0,0,.58)!important;\n}\n.gs-round-face{\n  border:1px solid rgba(96,165,250,.82)!important;\n  background:#06101f!important;\n  box-shadow:\n    0 0 0 3px rgba(2,6,23,.86),\n    0 0 0 4px rgba(148,163,184,.32),\n    0 18px 45px rgba(0,0,0,.52),\n    inset 0 0 0 1px rgba(255,255,255,.05)!important;\n}\n.gs-round-face:before{\n  content:"";\n  position:absolute;\n  inset:3px;\n  z-index:12;\n  border-radius:50%;\n  border:1px solid rgba(186,230,253,.14);\n  pointer-events:none;\n}\n.gs-round-horizon-wrap{\n  inset:8px!important;\n  border-radius:50%!important;\n  background:#07111f;\n  box-shadow:\n    inset 0 0 24px rgba(2,6,23,.58),\n    inset 0 0 0 1px rgba(148,163,184,.18);\n}\n.gs-round-horizon{\n  background:\n    linear-gradient(\n      to bottom,\n      #0d4f88 0%,\n      #1478b5 35%,\n      #38a2d0 49.18%,\n      rgba(226,232,240,.94) 49.18% 49.72%,\n      #0f172a 49.72% 50.28%,\n      rgba(226,232,240,.94) 50.28% 50.82%,\n      #33724a 50.82%,\n      #1b4b32 66%,\n      #102d21 100%\n    )!important;\n}\n.gs-round-pitch-ladder{\n  position:absolute;\n  inset:0;\n  pointer-events:none;\n}\n.gs-round-pitch-ladder span{\n  position:absolute;\n  left:50%;\n  top:var(--pitch-y);\n  width:18%;\n  height:1px;\n  transform:translate(-50%,-50%);\n  background:rgba(248,250,252,.72);\n  box-shadow:0 1px 2px rgba(0,0,0,.7);\n}\n.gs-round-pitch-ladder span.major{width:27%}\n.gs-round-pitch-ladder span:before,\n.gs-round-pitch-ladder span:after{\n  content:attr(data-pitch);\n  position:absolute;\n  top:50%;\n  transform:translateY(-50%);\n  color:rgba(248,250,252,.78);\n  font-size:clamp(6px,2.8cqw,9px);\n  font-weight:800;\n  line-height:1;\n  text-shadow:0 1px 2px #000;\n}\n.gs-round-pitch-ladder span:before{right:calc(100% + 2.5cqw)}\n.gs-round-pitch-ladder span:after{left:calc(100% + 2.5cqw)}\n/* Adaptive pitch-ladder density for small Round HUD sizes. */\n#roundHud[data-pitch-density="compact"] .gs-round-pitch-ladder span[data-pitch="+10"],\n#roundHud[data-pitch-density="compact"] .gs-round-pitch-ladder span[data-pitch="-10"]{\n  display:none;\n}\n#roundHud[data-pitch-density="minimal"] .gs-round-pitch-ladder span{\n  display:none;\n}\n#roundHud[data-pitch-density="minimal"] .gs-round-pitch-ladder span[data-pitch="+20"],\n#roundHud[data-pitch-density="minimal"] .gs-round-pitch-ladder span[data-pitch="-20"]{\n  display:block;\n  width:24%;\n}\n#roundHud[data-pitch-density="minimal"] .gs-round-pitch-ladder span:before,\n#roundHud[data-pitch-density="minimal"] .gs-round-pitch-ladder span:after{\n  display:none;\n}\n.gs-round-shade{\n  z-index:4;\n  background:\n    linear-gradient(to bottom,rgba(255,255,255,.05),transparent 24%,transparent 72%,rgba(2,6,23,.18)),\n    radial-gradient(circle at 50% 45%,transparent 0 58%,rgba(2,6,23,.12) 72%,rgba(2,6,23,.55) 100%)!important;\n}\n.gs-round-glass{\n  position:absolute;\n  inset:8px;\n  z-index:5;\n  border-radius:50%;\n  background:\n    linear-gradient(145deg,rgba(255,255,255,.10),transparent 25%,transparent 68%,rgba(255,255,255,.025)),\n    radial-gradient(circle at 35% 20%,rgba(186,230,253,.08),transparent 35%);\n  pointer-events:none;\n}\n.gs-round-inner-ring{\n  position:absolute;\n  inset:8px;\n  z-index:10;\n  border:1px solid rgba(148,163,184,.42);\n  border-radius:50%;\n  box-shadow:\n    inset 0 0 0 2px rgba(2,6,23,.34),\n    inset 0 0 18px rgba(2,6,23,.34);\n  pointer-events:none;\n}\n.gs-round-bank-scale{\n  position:absolute;\n  inset:0;\n  z-index:8;\n  pointer-events:none;\n}\n.gs-round-bank-scale span{\n  position:absolute;\n  left:50%;\n  top:50%;\n  width:1.2px;\n  height:4.5cqw;\n  border-radius:2px;\n  background:rgba(203,213,225,.74);\n  transform:translate(-50%,-50%) rotate(var(--bank-angle)) translateY(-43cqw);\n  transform-origin:center;\n  box-shadow:0 1px 2px rgba(0,0,0,.7);\n}\n.gs-round-bank-scale span.major{\n  width:1.8px;\n  height:6.5cqw;\n  background:#bae6fd;\n}\n.gs-round-bank{\n  z-index:9!important;\n  left:50%!important;\n  top:4.2%!important;\n  border-left:4.5cqw solid transparent!important;\n  border-right:4.5cqw solid transparent!important;\n  border-top:0!important;\n  border-bottom:5.5cqw solid #7dd3fc!important;\n  filter:drop-shadow(0 1px 2px rgba(0,0,0,.9))!important;\n}\n.gs-round-aircraft{\n  z-index:9;\n  width:45%!important;\n  height:12cqw!important;\n}\n.gs-round-aircraft:before,\n.gs-round-aircraft:after{\n  top:5.2cqw!important;\n  width:39%!important;\n  height:1.5px!important;\n  background:#fbbf24!important;\n  box-shadow:\n    0 1px 2px rgba(0,0,0,.92),\n    0 0 4px rgba(251,191,36,.24)!important;\n}\n.gs-round-aircraft span{\n  top:2.2cqw!important;\n  width:7cqw!important;\n  height:7cqw!important;\n  border:1.6px solid #fbbf24!important;\n  border-top:0!important;\n  border-radius:0 0 4cqw 4cqw!important;\n  box-shadow:0 1px 2px rgba(0,0,0,.8);\n}\n.gs-round-aircraft i{\n  position:absolute;\n  left:50%;\n  top:5.2cqw;\n  width:3.4cqw;\n  height:3.4cqw;\n  transform:translate(-50%,-50%);\n  border-radius:50%;\n  background:#fbbf24;\n  box-shadow:0 0 0 1.2cqw rgba(2,6,23,.68),0 1px 2px #000;\n}\n.gs-round-cardinal{\n  z-index:8;\n  min-width:1.55em!important;\n  padding:1.2cqw 1.6cqw;\n  border:1px solid rgba(100,116,139,.56);\n  border-radius:4px;\n  background:rgba(2,6,23,.58);\n  color:#e2e8f0!important;\n  font-size:clamp(7px,5.5cqw,12px)!important;\n  text-shadow:0 1px 2px #000!important;\n  box-shadow:0 2px 7px rgba(0,0,0,.24);\n}\n.gs-round-cardinal[data-bearing="0"]{\n  color:#7dd3fc!important;\n  border-color:rgba(56,189,248,.7);\n  background:rgba(7,30,55,.78);\n}\n.gs-round-home{\n  z-index:10;\n  width:8cqw!important;\n  height:8cqw!important;\n  filter:drop-shadow(0 2px 3px rgba(0,0,0,.75));\n}\n.gs-round-home .roof{\n  width:5cqw!important;\n  height:5cqw!important;\n  background:#7dd3fc!important;\n  border-radius:1.2cqw!important;\n}\n.gs-round-home .body{\n  bottom:.5cqw!important;\n  width:5.5cqw!important;\n  height:4.2cqw!important;\n  background:#0b1220!important;\n  border:1.2px solid #7dd3fc!important;\n  border-top:0!important;\n}\n.gs-round-home .door{\n  bottom:.6cqw!important;\n  width:1.6cqw!important;\n  height:2.6cqw!important;\n  background:#7dd3fc!important;\n}\n.gs-round-stale{\n  z-index:12;\n  top:28%!important;\n  border-color:rgba(248,113,113,.72)!important;\n  border-radius:6px!important;\n  background:rgba(69,10,10,.88)!important;\n  padding:1.6cqw 3cqw!important;\n  color:#fecaca;\n  font-size:clamp(6px,3.5cqw,10px)!important;\n  letter-spacing:.05em;\n  box-shadow:0 4px 14px rgba(0,0,0,.28);\n}\n@media(max-width:760px),(max-height:560px){\n  .gs-map-status{top:calc(var(--gs-top-clear) + 4px)!important;left:4px!important;max-width:42vw!important;padding:4px 6px!important;font-size:9px!important}\n  .gs-map-toolbar{top:calc(var(--gs-top-clear) + 4px)!important;right:4px!important;gap:3px!important}\n  .gs-map-style-switch{padding:2px!important;gap:2px!important}\n  .gs-map-style-switch button{height:24px!important;padding:0 5px!important;font-size:8px!important}\n  .gs-map-controls{gap:3px!important}\n  .gs-map-controls button{width:28px!important;height:28px!important;font-size:15px!important}\n}\n\n/* GROUNDSTATION_V20_THREE_STATE_VIDEO_MAP_PIP */\n#cameraPip{display:none}\n.gs-app[data-layout-state="video_dual"] #cameraPip{display:block}\n.gs-video-map-pip{display:none;z-index:45!important;cursor:default!important;touch-action:none!important;user-select:none!important;-webkit-user-select:none!important;will-change:left,top,width,height}\n.gs-app[data-layout-state="video_map"] .gs-video-map-pip{display:block}\n.gs-video-map-pip.dragging{border-color:#7dd3fc!important;box-shadow:0 14px 42px rgba(0,0,0,.62)!important}\n.gs-video-map-pip.resizing{border-color:#7dd3fc!important}\n.gs-video-map-pip .gs-map-pip-content{position:absolute;inset:0;overflow:hidden;background:#07111f}\n.gs-video-map-pip .gs-map-host{position:absolute!important;inset:0!important}\n.gs-video-map-pip .gs-map-status,.gs-video-map-pip .gs-map-toolbar{display:none!important}\n.gs-video-map-pip .gs-camera-label{cursor:grab;pointer-events:auto}\n.gs-video-map-pip.dragging .gs-camera-label{cursor:grabbing}\n.gs-video-map-pip.pip-minimized .gs-map-pip-content{display:none!important}\n.gs-video-map-pip.pip-minimized .gs-camera-label,.gs-video-map-pip.pip-minimized .gs-pip-resize{display:none!important}\n.gs-map-video-pip.pip-minimized .gs-video-frame{display:block!important}\n.gs-map-video-pip .gs-pip-edge-button,.gs-video-map-pip .gs-pip-edge-button{z-index:60}\n@media(max-width:760px),(max-height:560px){\n  .gs-video-map-pip{width:42%;height:30%}\n}\n\n\n\n/* GROUND_STATION_TELEMETRY_CANVAS_V2 */\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_SETUP_BUTTON */\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_ARRANGE_MODE */\n#telemetryArrangeBtn{white-space:nowrap}\n.gs-side{background:transparent!important;border:0!important;box-shadow:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;padding:4px!important;overflow:visible!important}\n.gs-telemetry-content{inset:4px!important;overflow:auto!important}\n.gs-side #telemetryGrid{width:100%!important;height:100%!important;min-height:0!important;align-content:stretch!important;gap:var(--telemetry-gap,4px)!important}\n.gs-side[data-flow="row"] #telemetryGrid{grid-template-columns:repeat(var(--telemetry-cols,2),minmax(0,1fr))!important;grid-template-rows:none!important;grid-auto-flow:row!important;grid-auto-rows:minmax(36px,1fr)!important}\n.gs-side[data-flow="column"] #telemetryGrid{grid-template-columns:none!important;grid-template-rows:repeat(var(--telemetry-rows,6),minmax(0,1fr))!important;grid-auto-flow:column!important;grid-auto-columns:minmax(90px,1fr)!important}\n.gs-side .gs-tile{display:flex!important;flex-direction:column!important;justify-content:center!important;align-items:var(--telemetry-align,flex-start)!important;padding:3px 5px!important;min-width:0!important;min-height:34px!important;background:transparent!important;border:0!important;border-radius:0!important;box-shadow:none!important;text-shadow:0 2px 4px rgba(0,0,0,.96)!important}\n.gs-side .gs-tile .k{display:block!important;width:100%;font-size:calc(var(--telemetry-font-size,17px)*.58)!important;line-height:1.05!important;color:#dbeafe!important;text-transform:uppercase;letter-spacing:.06em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.gs-side.hide-labels .gs-tile .k{display:none!important}\n.gs-side .gs-tile .v{display:flex!important;align-items:baseline;gap:4px;width:100%;font-size:var(--telemetry-font-size,17px)!important;line-height:1.05!important;font-weight:900;color:#fff!important;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}\n.gs-side .gs-tile .v .unit{font-size:calc(var(--telemetry-font-size,17px)*.55);font-weight:700;color:#bae6fd}\n.gs-side.hide-units .gs-tile .v .unit{display:none!important}\n.gs-side .gs-tile.stale{opacity:.5}\n.gs-side .gs-tile.unavailable{opacity:.38}\n.gs-side.telemetry-move-mode{outline:2px dashed #fb923c!important;outline-offset:2px;background:rgba(2,6,23,.12)!important;cursor:move!important}\n.gs-telemetry-resize-handle{display:none;position:absolute;right:-6px;bottom:-6px;z-index:40;width:28px;height:28px;border:2px solid #fb923c;border-left:0;border-top:0;background:transparent;cursor:nwse-resize;touch-action:none}\n.gs-side.telemetry-move-mode .gs-telemetry-resize-handle{display:block}\n.gs-telemetry-move-hint{top:auto!important;bottom:2px!important;font-size:9px!important;padding:3px 6px!important}\n.gs-telemetry-settings-backdrop.open{display:none!important}\n.gs-telemetry-settings{left:auto!important;right:6px!important;top:calc(var(--gs-top-clear) + 6px)!important;bottom:calc(var(--gs-bottom-clear) + 6px)!important;transform:none!important;width:min(430px,46vw)!important;max-height:none!important;padding:10px!important;overflow:hidden!important;display:none!important;grid-template-rows:auto auto 1fr auto;background:rgba(2,6,23,.96)!important}\n.gs-telemetry-settings.open{display:grid!important}\n.gs-telemetry-tabs{display:flex;gap:5px;margin-bottom:8px}.gs-telemetry-tab{flex:1;border:1px solid #475569;border-radius:8px;background:#0f172a;color:#cbd5e1;padding:7px;font-weight:800}.gs-telemetry-tab.active{background:#1d4ed8;border-color:#60a5fa;color:#fff}\n.gs-telemetry-pane{display:none;min-height:0;overflow:auto}.gs-telemetry-pane.active{display:block}\n.gs-telemetry-settings-grid select,.gs-telemetry-settings-grid input[type=text]{width:100%;box-sizing:border-box;border:1px solid #475569;border-radius:7px;background:#0f172a;color:#f8fafc;padding:7px 8px;font-size:13px}\n.gs-telemetry-search-row{display:grid;grid-template-columns:1fr auto;gap:6px;margin-bottom:7px}.gs-telemetry-filterbar{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:7px}.gs-telemetry-filterbar button{border:1px solid #475569;border-radius:7px;background:#0f172a;color:#cbd5e1;padding:5px 7px;font-size:10px;font-weight:800}.gs-telemetry-filterbar button.active{background:#1d4ed8;color:#fff;border-color:#60a5fa}\n.gs-telemetry-field-list{display:grid;gap:3px;max-height:calc(100dvh - 250px);overflow:auto;padding-right:2px}.gs-telemetry-field{display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:center;gap:7px;padding:6px 7px;border:1px solid rgba(71,85,105,.65);border-radius:7px;background:rgba(15,23,42,.72);font-size:11px}.gs-telemetry-field strong{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.gs-telemetry-field small{display:block;color:#94a3b8;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.gs-telemetry-field .live{color:#86efac;font-size:9px;font-weight:900}.gs-telemetry-field .defined{color:#64748b;font-size:9px;font-weight:900}\n.gs-telemetry-selected-list{display:grid;gap:3px;margin-top:8px}.gs-telemetry-selected-item{display:grid;grid-template-columns:minmax(0,1fr) auto auto auto;align-items:center;gap:4px;padding:5px 6px;border:1px solid #334155;border-radius:7px;background:#07111f;font-size:11px}.gs-telemetry-selected-item button{width:25px;height:24px;border:1px solid #475569;border-radius:6px;background:#111c31;color:#fff;padding:0}\n.gs-telemetry-result-note{font-size:10px;color:#94a3b8;margin:5px 0}\n.gs-telemetry-save-state{margin-right:auto;font-size:10px;color:#86efac}\n@media(max-width:760px),(max-height:560px){.gs-telemetry-settings{width:min(420px,55vw)!important;right:3px!important;top:calc(var(--gs-top-clear) + 3px)!important;bottom:calc(var(--gs-bottom-clear) + 3px)!important;padding:7px!important}.gs-telemetry-field-list{max-height:calc(100dvh - 205px)}}\n\n\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_STRICT_CONTENT_DOUBLE_TAP */\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_7_2_INPUT_CONTENT_FIXES */\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_7_3_OCCUPIED_CONTENT_ONLY */\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_7_4_GESTURE_SWAP_AUTO_CLOSE */\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_7_5_RELIABLE_HOLD_MOVE */\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_7_6_COLUMNS_ONLY_COMPACT_EDITOR */\n.gs-side{\n  box-sizing:content-box!important;\n  width:var(--telemetry-width,max-content)!important;\n  height:var(--telemetry-height,max-content)!important;\n  min-width:0!important;\n  min-height:0!important;\n  max-width:none!important;\n  max-height:none!important;\n  padding:0!important;\n  margin:0!important;\n  border:0!important;\n  border-radius:0!important;\n  box-shadow:none!important;\n  overflow:visible!important;\n  touch-action:manipulation!important;\n}\n.gs-side{\n  -webkit-touch-callout:none!important;\n}\n.gs-side.telemetry-move-mode{\n  touch-action:none!important;\n}\n.gs-telemetry-content{\n  position:static!important;\n  inset:auto!important;\n  width:max-content!important;\n  height:max-content!important;\n  min-width:0!important;\n  min-height:0!important;\n  max-width:none!important;\n  max-height:none!important;\n  padding:0!important;\n  margin:0!important;\n  overflow:visible!important;\n}\n.gs-side #telemetryGrid{\n  display:grid!important;\n  width:max-content!important;\n  height:max-content!important;\n  min-width:0!important;\n  min-height:0!important;\n  max-width:none!important;\n  max-height:none!important;\n  padding:0!important;\n  margin:0!important;\n  gap:0!important;\n  column-gap:0!important;\n  row-gap:0!important;\n  align-content:start!important;\n  justify-content:start!important;\n  grid-template-columns:var(--telemetry-strict-columns,max-content)!important;\n  grid-template-rows:var(--telemetry-strict-rows,max-content)!important;\n  grid-auto-columns:max-content!important;\n  grid-auto-rows:max-content!important;\n}\n.gs-side .gs-tile{\n  box-sizing:content-box!important;\n  display:flex!important;\n  flex-direction:column!important;\n  justify-content:flex-start!important;\n  align-items:flex-start!important;\n  width:max-content!important;\n  height:max-content!important;\n  min-width:0!important;\n  min-height:0!important;\n  max-width:none!important;\n  max-height:none!important;\n  padding:0!important;\n  margin:0!important;\n  gap:0!important;\n  row-gap:0!important;\n  column-gap:0!important;\n  white-space:nowrap!important;\n  overflow:visible!important;\n}\n.gs-side .gs-tile .k,\n.gs-side .gs-tile .v,\n.gs-side .gs-tile .v > *{\n  box-sizing:content-box!important;\n  width:max-content!important;\n  height:max-content!important;\n  min-width:0!important;\n  min-height:0!important;\n  max-width:none!important;\n  max-height:none!important;\n  padding:0!important;\n  margin:0!important;\n  white-space:nowrap!important;\n  overflow:visible!important;\n  text-overflow:clip!important;\n  line-height:1!important;\n}\n.gs-side .gs-tile .v{\n  display:flex!important;\n  align-items:baseline!important;\n  gap:0!important;\n  column-gap:0!important;\n}\n\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_TEXT_SHADOWS_V2_7_1 */\n\n/* Ensure every telemetry text fragment has dark separation from light video. */\n#sidePanel #telemetryGrid,\n#sidePanel #telemetryGrid *,\n.gs-side #telemetryGrid,\n.gs-side #telemetryGrid *{\n  text-shadow:\n    -1px -1px 1px rgba(0,0,0,.98),\n     0   -1px 1px rgba(0,0,0,1),\n     1px -1px 1px rgba(0,0,0,.98),\n    -1px  0   1px rgba(0,0,0,1),\n     1px  0   1px rgba(0,0,0,1),\n    -1px  1px 1px rgba(0,0,0,.98),\n     0    1px 1px rgba(0,0,0,1),\n     1px  1px 1px rgba(0,0,0,.98),\n     0    0   4px rgba(0,0,0,.92)!important;\n}\n\n/* Values receive the strongest outline and halo. */\n#sidePanel #telemetryGrid .v,\n#sidePanel #telemetryGrid .v *,\n#sidePanel #telemetryGrid .value,\n#sidePanel #telemetryGrid [data-value],\n.gs-side #telemetryGrid .v,\n.gs-side #telemetryGrid .v *,\n.gs-side #telemetryGrid .value,\n.gs-side #telemetryGrid [data-value]{\n  text-shadow:\n    -1px -1px 0 rgba(0,0,0,1),\n     0   -1px 0 rgba(0,0,0,1),\n     1px -1px 0 rgba(0,0,0,1),\n    -1px  0   0 rgba(0,0,0,1),\n     1px  0   0 rgba(0,0,0,1),\n    -1px  1px 0 rgba(0,0,0,1),\n     0    1px 0 rgba(0,0,0,1),\n     1px  1px 0 rgba(0,0,0,1),\n     0    0   3px rgba(0,0,0,1),\n     0    0   7px rgba(0,0,0,.92)!important;\n}\n\n/* Labels, units, placeholders and LIVE/DEFINED status text. */\n#sidePanel #telemetryGrid .k,\n#sidePanel #telemetryGrid .label,\n#sidePanel #telemetryGrid .unit,\n#sidePanel #telemetryGrid .u,\n#sidePanel #telemetryGrid .placeholder,\n#sidePanel #telemetryGrid .status,\n#sidePanel #telemetryGrid .live,\n#sidePanel #telemetryGrid .defined,\n#sidePanel #telemetryGrid [data-label],\n#sidePanel #telemetryGrid [data-unit],\n#sidePanel #telemetryGrid [data-status],\n.gs-side #telemetryGrid .k,\n.gs-side #telemetryGrid .label,\n.gs-side #telemetryGrid .unit,\n.gs-side #telemetryGrid .u,\n.gs-side #telemetryGrid .placeholder,\n.gs-side #telemetryGrid .status,\n.gs-side #telemetryGrid .live,\n.gs-side #telemetryGrid .defined,\n.gs-side #telemetryGrid [data-label],\n.gs-side #telemetryGrid [data-unit],\n.gs-side #telemetryGrid [data-status]{\n  text-shadow:\n    -1px -1px 1px rgba(0,0,0,.96),\n     0   -1px 1px rgba(0,0,0,.98),\n     1px -1px 1px rgba(0,0,0,.96),\n    -1px  0   1px rgba(0,0,0,.98),\n     1px  0   1px rgba(0,0,0,.98),\n    -1px  1px 1px rgba(0,0,0,.96),\n     0    1px 1px rgba(0,0,0,.98),\n     1px  1px 1px rgba(0,0,0,.96),\n     0    0   5px rgba(0,0,0,.84)!important;\n}\n\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_7_6_COMPACT_EDITOR */\n.gs-telemetry-settings{\n  width:min(360px,42vw)!important;\n  padding:6px!important;\n  border-radius:9px!important;\n  grid-template-rows:auto auto minmax(0,1fr) auto!important;\n}\n.gs-telemetry-settings-head{\n  min-height:24px!important;\n  margin-bottom:4px!important;\n  font-size:12px!important;\n}\n.gs-telemetry-settings-close{\n  width:26px!important;\n  height:24px!important;\n  padding:0!important;\n  font-size:18px!important;\n}\n.gs-telemetry-tabs{\n  gap:3px!important;\n  margin-bottom:4px!important;\n}\n.gs-telemetry-tab{\n  padding:4px 6px!important;\n  border-radius:6px!important;\n  font-size:10px!important;\n}\n.gs-telemetry-settings-grid{\n  grid-template-columns:1fr 1fr!important;\n  gap:5px!important;\n}\n.gs-telemetry-setting{\n  gap:2px!important;\n  font-size:9px!important;\n}\n.gs-telemetry-setting input[type=number]{\n  min-height:30px!important;\n  padding:4px 6px!important;\n  border-radius:6px!important;\n  font-size:13px!important;\n}\n.gs-telemetry-check{\n  grid-column:auto!important;\n  gap:4px!important;\n  font-size:10px!important;\n  min-height:24px!important;\n}\n.gs-telemetry-settings-note{\n  margin-top:1px!important;\n  font-size:8px!important;\n  line-height:1.25!important;\n}\n.gs-telemetry-settings-actions{\n  gap:4px!important;\n  margin-top:5px!important;\n  align-items:center!important;\n}\n.gs-telemetry-settings-actions .gs-btn{\n  padding:4px 6px!important;\n  font-size:9px!important;\n}\n.gs-telemetry-search-row{\n  gap:4px!important;\n  margin-bottom:4px!important;\n}\n.gs-telemetry-search-row input{\n  min-height:28px!important;\n  padding:4px 6px!important;\n  font-size:10px!important;\n}\n.gs-telemetry-filterbar{\n  gap:3px!important;\n  margin-bottom:4px!important;\n}\n.gs-telemetry-filterbar button{\n  padding:3px 5px!important;\n  font-size:8px!important;\n}\n.gs-telemetry-result-note{\n  margin:2px 0!important;\n  font-size:8px!important;\n}\n.gs-telemetry-field-list{\n  gap:2px!important;\n  max-height:calc(100dvh - 155px)!important;\n}\n.gs-telemetry-field{\n  gap:4px!important;\n  padding:3px 5px!important;\n  border-radius:5px!important;\n  font-size:9px!important;\n}\n.gs-telemetry-field small,\n.gs-telemetry-field .live,\n.gs-telemetry-field .defined{\n  font-size:7px!important;\n}\n.gs-telemetry-selected-list{\n  gap:2px!important;\n  margin-top:4px!important;\n}\n.gs-telemetry-selected-item{\n  gap:3px!important;\n  padding:3px 4px!important;\n  font-size:9px!important;\n}\n.gs-telemetry-selected-item button{\n  width:22px!important;\n  height:21px!important;\n}\n@media(max-width:760px),(max-height:560px){\n  .gs-telemetry-settings{\n    width:min(350px,50vw)!important;\n    top:calc(var(--gs-top-clear) + 2px)!important;\n    right:2px!important;\n    bottom:calc(var(--gs-bottom-clear) + 2px)!important;\n    padding:5px!important;\n  }\n}\n\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_8_INDEPENDENT_GROUPS */\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_8_1_NAVIGABLE_GROUP_EDITOR */\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_8_2_CUSTOM_FIELD_LABELS */\n/* GROUND_STATION_OVERLAY_CLEANUP_V2_8_3_PERSISTENT_STICKY_EDGES */\n/* GROUND_STATION_OVERLAY_CLEANUP_V2_8_4_FULLSCREEN_TRANSITION_SAFE */\n/* GROUND_STATION_OVERLAY_CLEANUP_V2_8_5_EXACT_LOCAL_XY_PERSISTENCE */\n/* GROUND_STATION_OVERLAY_CLEANUP_V2_8_6_DEFER_PORTRAIT_GEOMETRY */\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_8_7_VALUE_SPACING */\n/* GROUND_STATION_BUTTON_ACTION_V2_8_8_TELEMETRY_TOGGLE */\n.gs-telemetry-groups-host{\n  position:fixed!important;\n  inset:0!important;\n  z-index:96!important;\n  pointer-events:none!important;\n  overflow:visible!important;\n}\n.gs-telemetry-group{\n  position:fixed!important;\n  z-index:97!important;\n  display:block;\n  width:max-content!important;\n  height:max-content!important;\n  min-width:0!important;\n  min-height:0!important;\n  max-width:none!important;\n  max-height:none!important;\n  padding:0!important;\n  margin:0!important;\n  overflow:visible!important;\n  background:transparent!important;\n  border:0!important;\n  border-radius:0!important;\n  box-shadow:none!important;\n  touch-action:none!important;\n  user-select:none!important;\n  -webkit-user-select:none!important;\n  -webkit-touch-callout:none!important;\n  pointer-events:auto!important;\n}\n.gs-telemetry-group-grid{\n  display:grid!important;\n  width:max-content!important;\n  height:max-content!important;\n  min-width:0!important;\n  min-height:0!important;\n  padding:0!important;\n  margin:0!important;\n  gap:0!important;\n  row-gap:var(--telemetry-row-gap,0px)!important;\n  column-gap:var(--telemetry-column-gap,0px)!important;\n  grid-auto-flow:row!important;\n  grid-auto-columns:max-content!important;\n  grid-auto-rows:max-content!important;\n  align-content:start!important;\n  justify-content:start!important;\n}\n.gs-telemetry-group .gs-tile{\n  box-sizing:content-box!important;\n  display:flex!important;\n  flex-direction:column!important;\n  justify-content:flex-start!important;\n  align-items:flex-start!important;\n  width:max-content!important;\n  height:max-content!important;\n  min-width:0!important;\n  min-height:0!important;\n  max-width:none!important;\n  max-height:none!important;\n  padding:0!important;\n  margin:0!important;\n  gap:0!important;\n  border:0!important;\n  border-radius:0!important;\n  background:transparent!important;\n  box-shadow:none!important;\n  overflow:visible!important;\n  white-space:nowrap!important;\n}\n.gs-telemetry-group .gs-tile .k,\n.gs-telemetry-group .gs-tile .v,\n.gs-telemetry-group .gs-tile .v>*{\n  box-sizing:content-box!important;\n  display:block;\n  width:max-content!important;\n  height:max-content!important;\n  min-width:0!important;\n  min-height:0!important;\n  max-width:none!important;\n  max-height:none!important;\n  padding:0!important;\n  margin:0!important;\n  overflow:visible!important;\n  text-overflow:clip!important;\n  white-space:nowrap!important;\n  line-height:1!important;\n}\n.gs-telemetry-group .gs-tile .k{\n  font-size:calc(var(--telemetry-font-size,17px)*.58)!important;\n  color:#dbeafe!important;\n  text-transform:uppercase!important;\n  letter-spacing:.06em!important;\n}\n.gs-telemetry-group .gs-tile .v{\n  display:flex!important;\n  align-items:baseline!important;\n  gap:0!important;\n  font-size:var(--telemetry-font-size,17px)!important;\n  font-weight:900!important;\n  color:#fff!important;\n}\n.gs-telemetry-group .gs-tile .unit{\n  font-size:calc(var(--telemetry-font-size,17px)*.55)!important;\n  font-weight:700!important;\n  color:#bae6fd!important;\n}\n.gs-telemetry-group.hide-labels .gs-tile .k{display:none!important}\n.gs-telemetry-group.hide-units .gs-tile .unit{display:none!important}\n.gs-telemetry-group .gs-tile.stale{opacity:.5}\n.gs-telemetry-group .gs-tile.unavailable{opacity:.38}\n.gs-telemetry-group-grid,\n.gs-telemetry-group-grid *,\n.gs-telemetry-group .gs-tile,\n.gs-telemetry-group .gs-tile *{\n  text-shadow:\n    -1px -1px 1px rgba(0,0,0,.98),\n     0 -1px 1px rgba(0,0,0,1),\n     1px -1px 1px rgba(0,0,0,.98),\n    -1px 0 1px rgba(0,0,0,1),\n     1px 0 1px rgba(0,0,0,1),\n    -1px 1px 1px rgba(0,0,0,.98),\n     0 1px 1px rgba(0,0,0,1),\n     1px 1px 1px rgba(0,0,0,.98),\n     0 0 5px rgba(0,0,0,.92)!important;\n}\n.gs-telemetry-group.telemetry-move-mode{\n  outline:2px dashed #fb923c!important;\n  outline-offset:2px!important;\n  cursor:move!important;\n}\n.gs-telemetry-group-resize-handle{\n  display:none;\n  position:absolute!important;\n  right:-7px!important;\n  bottom:-7px!important;\n  z-index:40!important;\n  width:30px!important;\n  height:30px!important;\n  padding:0!important;\n  border:2px solid #fb923c!important;\n  border-left:0!important;\n  border-top:0!important;\n  background:transparent!important;\n  cursor:nwse-resize!important;\n  touch-action:none!important;\n}\n.gs-telemetry-group.telemetry-move-mode .gs-telemetry-group-resize-handle{\n  display:block!important;\n}\n.gs-telemetry-group-move-hint{\n  display:none;\n  position:absolute;\n  left:50%;\n  bottom:-22px;\n  transform:translateX(-50%);\n  padding:3px 6px;\n  border:1px solid rgba(251,146,60,.92);\n  border-radius:6px;\n  background:rgba(2,6,23,.9);\n  color:#fdba74;\n  font-size:8px;\n  font-weight:900;\n  white-space:nowrap;\n  pointer-events:none;\n}\n.gs-telemetry-group.telemetry-move-mode .gs-telemetry-group-move-hint{\n  display:block;\n}\n.gs-telemetry-groupbar{\n  display:grid;\n  grid-template-columns:minmax(0,1fr) auto auto auto;\n  gap:3px;\n  margin-bottom:4px;\n}\n.gs-telemetry-groupbar select{\n  min-width:0;\n  width:100%;\n  min-height:27px;\n  border:1px solid #475569;\n  border-radius:6px;\n  background:#0f172a;\n  color:#f8fafc;\n  padding:3px 5px;\n  font-size:10px;\n  font-weight:800;\n}\n.gs-telemetry-groupbar .gs-btn{\n  min-height:27px!important;\n  padding:3px 5px!important;\n  font-size:8px!important;\n  white-space:nowrap;\n}\n.gs-telemetry-groupbar .gs-btn:disabled{opacity:.42}\n.gs-telemetry-settings-head span:after{\n  content:" · independent groups";\n  color:#94a3b8;\n  font-size:8px;\n  font-weight:700;\n}\n@media(max-width:760px),(max-height:560px){\n  .gs-telemetry-groupbar{\n    grid-template-columns:minmax(0,1fr) auto auto;\n  }\n  #telemetryGroupDelete{grid-column:3}\n}\n\n\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_8_2_CUSTOM_LABEL_EDITOR */\n.gs-telemetry-selected-note{\n  margin:6px 1px 3px;\n  color:#94a3b8;\n  font-size:9px;\n  line-height:1.15;\n}\n.gs-telemetry-selected-item{\n  grid-template-columns:minmax(90px,1fr) auto auto auto!important;\n  padding:3px 4px!important;\n  gap:3px!important;\n}\n.gs-telemetry-label-input{\n  min-width:0;\n  width:100%;\n  height:24px;\n  box-sizing:border-box;\n  border:1px solid #475569;\n  border-radius:5px;\n  background:#0f172a;\n  color:#f8fafc;\n  padding:2px 5px;\n  font-size:10px;\n  font-weight:800;\n}\n.gs-telemetry-label-input::placeholder{color:#64748b;opacity:1}\n.gs-telemetry-label-input:focus{outline:1px solid #60a5fa;border-color:#60a5fa}\n/* GROUND_STATION_TELEMETRY_CANVAS_V2_8_1_EDITOR_NAVIGATION */\n.gs-telemetry-settings-backdrop.open{\n  display:block!important;\n  pointer-events:auto!important;\n  touch-action:none!important;\n  background:rgba(0,0,0,.22)!important;\n}\n.gs-telemetry-settings{\n  width:clamp(390px,52vw,540px)!important;\n  min-width:0!important;\n  max-width:calc(100vw - 8px)!important;\n  overflow:hidden!important;\n  touch-action:auto!important;\n}\n.gs-telemetry-settings.open{\n  display:flex!important;\n  flex-direction:column!important;\n}\n.gs-telemetry-settings-head,\n.gs-telemetry-groupbar,\n.gs-telemetry-tabs,\n.gs-telemetry-settings-actions{\n  flex:0 0 auto!important;\n}\n.gs-telemetry-settings-head{\n  margin-bottom:4px!important;\n}\n.gs-telemetry-groupbar{\n  display:flex!important;\n  flex-wrap:wrap!important;\n  align-items:center!important;\n  gap:4px!important;\n  margin-bottom:4px!important;\n  min-width:0!important;\n}\n.gs-telemetry-groupbar select{\n  flex:1 1 150px!important;\n  min-width:120px!important;\n}\n.gs-telemetry-groupbar .gs-btn{\n  flex:0 0 auto!important;\n}\n.gs-telemetry-tabs{\n  margin-bottom:4px!important;\n}\n.gs-telemetry-pane{\n  flex:1 1 auto!important;\n  min-height:0!important;\n  max-height:none!important;\n  overflow:hidden!important;\n}\n.gs-telemetry-pane.active{\n  display:block!important;\n  overflow-y:auto!important;\n  overflow-x:hidden!important;\n  touch-action:pan-y!important;\n  overscroll-behavior:contain!important;\n  -webkit-overflow-scrolling:touch!important;\n  scrollbar-width:thin!important;\n  padding-right:3px!important;\n}\n.gs-telemetry-pane.active::-webkit-scrollbar{\n  width:7px;\n}\n.gs-telemetry-pane.active::-webkit-scrollbar-thumb{\n  background:#475569;\n  border-radius:8px;\n}\n.gs-telemetry-settings-grid{\n  align-content:start!important;\n}\n.gs-telemetry-field-list{\n  max-height:none!important;\n  overflow:visible!important;\n  touch-action:auto!important;\n}\n.gs-telemetry-selected-list{\n  padding-bottom:4px!important;\n}\n.gs-telemetry-settings-actions{\n  margin-top:4px!important;\n  padding-top:4px!important;\n  border-top:1px solid rgba(71,85,105,.65)!important;\n  background:rgba(2,6,23,.98)!important;\n}\n.gs-telemetry-settings input,\n.gs-telemetry-settings select,\n.gs-telemetry-settings button,\n.gs-telemetry-settings label{\n  touch-action:manipulation!important;\n}\n@media(max-width:760px),(max-height:560px){\n  .gs-telemetry-settings{\n    width:min(560px,66vw)!important;\n    max-width:calc(100vw - 6px)!important;\n    left:auto!important;\n    right:2px!important;\n    top:calc(var(--gs-top-clear) + 2px)!important;\n    bottom:calc(var(--gs-bottom-clear) + 2px)!important;\n    padding:5px!important;\n  }\n  .gs-telemetry-groupbar{\n    flex-wrap:nowrap!important;\n    overflow-x:auto!important;\n    overflow-y:hidden!important;\n    scrollbar-width:none!important;\n  }\n  .gs-telemetry-groupbar::-webkit-scrollbar{display:none!important}\n  .gs-telemetry-groupbar select{\n    flex:1 0 150px!important;\n  }\n  .gs-telemetry-groupbar .gs-btn{\n    flex:0 0 auto!important;\n  }\n}\n\n\n/* GROUND_STATION_OVERLAY_CLEANUP_V2_8_3_ABSOLUTE_BOTTOM */\n:root{--gs-bottom-clear:0px!important}\n.gs-bottom{display:none!important;height:0!important;min-height:0!important}\n#gsLegacyBottomControls{display:none!important}\n.gs-telemetry-settings{\n  bottom:0!important;\n  max-height:calc(100dvh - var(--gs-top-clear))!important;\n}\n@media(max-width:760px),(max-height:560px){\n  :root{--gs-bottom-clear:0px!important}\n  .gs-telemetry-settings{bottom:0!important}\n}\n\n\n/* GROUND_STATION_FLY_VIEW_V2_8_11_TELEMETRY_CANVAS_SHADOW_STANDARD */\n:root{\n  --gs-fly-canvas-text-shadow:\n    -1px -1px 1px rgba(0,0,0,.98),\n     0 -1px 1px rgba(0,0,0,1),\n     1px -1px 1px rgba(0,0,0,.98),\n    -1px 0 1px rgba(0,0,0,1),\n     1px 0 1px rgba(0,0,0,1),\n    -1px 1px 1px rgba(0,0,0,.98),\n     0 1px 1px rgba(0,0,0,1),\n     1px 1px 1px rgba(0,0,0,.98),\n     0 0 5px rgba(0,0,0,.92);\n  --gs-fly-canvas-line-shadow:\n     0 1px 1px rgba(0,0,0,1),\n     0 0 3px rgba(0,0,0,.94);\n  --gs-fly-canvas-panel-shadow:\n     0 0 0 1px rgba(0,0,0,.92),\n     0 2px 7px rgba(0,0,0,.82);\n  --gs-fly-canvas-panel-shadow-active:\n     0 0 0 2px rgba(56,189,248,.48),\n     0 2px 9px rgba(0,0,0,.9);\n}\n\n/* Flight-view text follows the exact telemetry-canvas outline and halo. */\n.gs-top .gs-brand,\n.gs-top .gs-brand *,\n.gs-top .gs-chip,\n.gs-top .gs-chip *,\n.gs-top .gs-monitor,\n.gs-top .gs-monitor *,\n.gs-top .gs-btn,\n.gs-top .gs-btn *,\n.gs-video-state,\n.gs-video-state *,\n.gs-pip-label,\n.gs-pip-label *,\n.gs-camera-label,\n.gs-camera-label *,\n.gs-mode-overlay,\n.gs-mode-overlay *,\n.gs-attitude-numbers,\n.gs-map-status,\n.gs-map-status *,\n.gs-map-controls button,\n.gs-map-controls button *,\n.gs-map-style-switch,\n.gs-map-style-switch *,\n.gs-pip-edge-button,\n.gs-pip-edge-button *,\n.gs-round-cardinal,\n.gs-round-stale,\n.gs-round-stale *,\n.gs-map-home-marker,\n.gs-message{\n  text-shadow:var(--gs-fly-canvas-text-shadow)!important;\n}\n\n/* Remove the previous large, soft floating shadows. */\n.gs-round-hud{\n  filter:none!important;\n}\n.gs-pip,\n.gs-map-video-pip,\n.gs-video-map-pip{\n  box-shadow:var(--gs-fly-canvas-panel-shadow)!important;\n}\n.gs-pip.dragging,\n.gs-map-video-pip.dragging,\n.gs-video-map-pip.dragging,\n.gs-pip.resizing,\n.gs-map-video-pip.resizing,\n.gs-video-map-pip.resizing{\n  box-shadow:var(--gs-fly-canvas-panel-shadow-active)!important;\n}\n.gs-pip.pip-minimized{\n  box-shadow:none!important;\n}\n\n/* Round HUD outer depth now matches the compact telemetry-canvas separation. */\n.gs-round-face{\n  box-shadow:\n    var(--gs-fly-canvas-panel-shadow),\n    inset 0 0 0 1px rgba(255,255,255,.04)!important;\n}\n.gs-round-hud.dragging .gs-round-face,\n.gs-round-hud.resizing .gs-round-face{\n  box-shadow:\n    var(--gs-fly-canvas-panel-shadow-active),\n    inset 0 0 0 1px rgba(255,255,255,.05)!important;\n}\n.gs-round-horizon-wrap{\n  box-shadow:\n    inset 0 0 0 1px rgba(148,163,184,.18),\n    inset 0 0 7px rgba(0,0,0,.58)!important;\n}\n.gs-round-inner-ring{\n  box-shadow:\n    inset 0 0 0 1px rgba(2,6,23,.64),\n    inset 0 0 6px rgba(0,0,0,.48)!important;\n}\n.gs-round-cardinal{\n  box-shadow:none!important;\n}\n\n/* Flight-reference line work uses the same compact black separation. */\n.gs-round-pitch-ladder span,\n.gs-round-bank-scale span,\n.gs-round-aircraft:before,\n.gs-round-aircraft:after,\n.gs-round-aircraft span,\n.gs-attitude-overlay .gs-horizon,\n.gs-attitude-overlay .gs-horizon:before,\n.gs-attitude-overlay .gs-horizon:after,\n.gs-attitude-overlay .gs-aircraft-symbol:before,\n.gs-attitude-overlay .gs-aircraft-symbol:after,\n.gs-attitude-overlay .gs-aircraft-symbol span{\n  box-shadow:var(--gs-fly-canvas-line-shadow)!important;\n}\n.gs-round-pitch-ladder span:before,\n.gs-round-pitch-ladder span:after{\n  text-shadow:var(--gs-fly-canvas-text-shadow)!important;\n}\n\n/* Icons and map markers use a tight two-stage dark halo, not a broad blur. */\n.gs-round-bank,\n.gs-round-home,\n.gs-map-aircraft-marker{\n  filter:\n    drop-shadow(0 1px 1px rgba(0,0,0,1))\n    drop-shadow(0 0 2px rgba(0,0,0,.92))!important;\n}\n.gs-map-home-marker,\n.gs-round-stale{\n  box-shadow:var(--gs-fly-canvas-panel-shadow)!important;\n}\n\n\n/* GROUND_STATION_FLIGHT_MODE_SELECTOR_V2_8_13_TOP_PILL */\n/* GROUND_STATION_FLIGHT_MODE_SELECTOR_V2_8_14_COMPACT_SCROLL_LIST */\n.gs-mode-chip{\n  appearance:none;\n  color:var(--text);\n  font:inherit;\n  cursor:pointer;\n  white-space:nowrap;\n  transition:border-color .14s ease,background .14s ease,opacity .14s ease;\n}\n.gs-mode-chip:hover,\n.gs-mode-chip:focus-visible,\n.gs-mode-chip[aria-expanded="true"]{\n  border-color:#60a5fa;\n  background:#111c31;\n}\n.gs-mode-chip.pending{\n  border-color:#f59e0b;\n}\n.gs-mode-chip.mode-error{\n  border-color:#ef4444;\n}\n.gs-mode-chip .gs-mode-chevron{\n  color:#7dd3fc;\n  font-size:10px;\n  margin-left:1px;\n  transform:translateY(-1px);\n}\n.gs-mode-menu-backdrop{\n  position:fixed;\n  inset:0;\n  z-index:340;\n  background:rgba(2,6,23,.12);\n}\n.gs-mode-menu{\n  position:fixed;\n  z-index:341;\n  width:min(238px,calc(100vw - 16px));\n  max-height:min(350px,calc(100vh - 60px));\n  overflow:hidden;\n  padding:6px;\n  border:1px solid #475569;\n  border-radius:11px;\n  background:rgba(7,18,38,.98);\n  box-shadow:var(--gs-fly-canvas-panel-shadow-active);\n  color:var(--text);\n}\n.gs-mode-menu[hidden],\n.gs-mode-menu-backdrop[hidden]{\n  display:none!important;\n}\n.gs-mode-grid{\n  display:flex;\n  flex-direction:column;\n  gap:5px;\n  max-height:min(338px,calc(100vh - 72px));\n  overflow-x:hidden;\n  overflow-y:auto;\n  padding:0 2px 0 0;\n  overscroll-behavior:contain;\n  scrollbar-width:thin;\n  scrollbar-color:#475569 transparent;\n}\n.gs-mode-grid::-webkit-scrollbar{\n  width:6px;\n}\n.gs-mode-grid::-webkit-scrollbar-thumb{\n  border-radius:99px;\n  background:#475569;\n}\n.gs-mode-option{\n  position:relative;\n  min-height:46px;\n  flex:0 0 46px;\n  display:flex;\n  align-items:center;\n  justify-content:space-between;\n  width:100%;\n  padding:9px 14px;\n  border:1px solid #475569;\n  border-radius:9px;\n  background:#111c31;\n  color:#f8fafc;\n  cursor:pointer;\n  font-weight:800;\n  font-size:14px;\n  text-align:left;\n  text-shadow:var(--gs-fly-canvas-text-shadow);\n}\n.gs-mode-option:hover,\n.gs-mode-option:focus-visible{\n  border-color:#60a5fa;\n  background:#172554;\n}\n.gs-mode-option.current{\n  border-color:#38bdf8;\n  background:#0c4a6e;\n  box-shadow:inset 0 0 0 1px rgba(125,211,252,.4);\n}\n.gs-mode-option.current:after{\n  content:"✓";\n  color:#bae6fd;\n  font-size:18px;\n  line-height:1;\n}\n.gs-mode-option:disabled{\n  cursor:wait;\n  opacity:.48;\n}\n\n/* GROUND_STATION_ARM_SELECTOR_V2_8_15_TOP_PILL */\n.gs-arm-chip{\n  min-width:92px;\n}\n.gs-arm-chip strong{\n  min-width:65px;\n  text-align:center;\n}\n.gs-arm-option[data-arm-state="ARM"]{\n  color:#fecaca;\n}\n.gs-arm-option[data-arm-state="DISARM"]{\n  color:#bbf7d0;\n}\n.gs-arm-option[data-arm-state="ARM"].current{\n  border-color:#f87171;\n  background:#7f1d1d;\n}\n.gs-arm-option[data-arm-state="DISARM"].current{\n  border-color:#4ade80;\n  background:#14532d;\n}\n\n\n/* GROUND_STATION_GPS_STATUS_V2_8_16_TOP_BANNER_PILL */\n.gs-top-status-cluster{\n  display:inline-flex;\n  align-items:center;\n  gap:5px;\n  flex:0 0 auto;\n  min-width:max-content;\n  position:relative;\n  isolation:isolate;\n}\n.gs-top-status-cluster .gs-chip{\n  position:relative!important;\n  inset:auto!important;\n  transform:none!important;\n  flex:0 0 auto!important;\n}\n.gs-gps-chip{\n  min-width:116px;\n  max-width:174px;\n  justify-content:flex-start;\n  border-color:#475569;\n  background:#0b1220;\n  overflow:hidden;\n}\n.gs-gps-chip strong{\n  min-width:0;\n  overflow:hidden;\n  text-overflow:ellipsis;\n  white-space:nowrap;\n}\n.gs-gps-dot{\n  width:8px;\n  height:8px;\n  flex:0 0 8px;\n  border-radius:999px;\n  background:#64748b;\n  box-shadow:0 0 0 1px rgba(0,0,0,.72);\n}\n.gs-gps-chip.ok{\n  border-color:rgba(74,222,128,.68);\n  background:rgba(20,83,45,.48);\n  color:#dcfce7;\n}\n.gs-gps-chip.ok .gs-gps-dot{\n  background:#22c55e;\n  box-shadow:0 0 7px rgba(34,197,94,.8);\n}\n.gs-gps-chip.warn{\n  border-color:rgba(245,158,11,.72);\n  background:rgba(120,53,15,.48);\n  color:#fef3c7;\n}\n.gs-gps-chip.warn .gs-gps-dot{\n  background:#f59e0b;\n  box-shadow:0 0 7px rgba(245,158,11,.76);\n}\n.gs-gps-chip.bad{\n  border-color:rgba(248,113,113,.7);\n  background:rgba(127,29,29,.42);\n  color:#fee2e2;\n}\n.gs-gps-chip.bad .gs-gps-dot{\n  background:#ef4444;\n  box-shadow:0 0 7px rgba(239,68,68,.76);\n}\n.gs-gps-chip.stale{\n  border-color:#475569;\n  background:#111827;\n  color:#cbd5e1;\n  opacity:.78;\n}\n.gs-gps-chip.stale .gs-gps-dot{\n  background:#64748b;\n  box-shadow:none;\n}\n/* GPS and REC are separate flex cells with a permanent visual gap. */\n.gs-top-status-cluster .gs-record-chip{\n  flex:0 0 auto!important;\n  margin:0!important;\n  z-index:1;\n}\n@media(max-width:760px){\n  .gs-gps-chip{\n    min-width:106px;\n    max-width:150px;\n    padding-left:7px;\n    padding-right:7px;\n  }\n}\n\n\n/* GROUND_STATION_TOP_BANNER_V2_8_17_COMPACT_STATE_CONTROLS */\n.gs-brand{\n  margin-right:0!important;\n  gap:0!important;\n}\n.gs-brand span{\n  white-space:nowrap;\n}\n/* GROUND_STATION_TOP_BANNER_V2_8_18_ALIGNED_SELECTOR_PILLS */\n.gs-status-select-pill{\n  min-height:0!important;\n  height:auto!important;\n  padding:7px 9px!important;\n  gap:6px!important;\n  border-radius:9px!important;\n  box-sizing:border-box;\n  align-items:center!important;\n}\n.gs-status-select-pill strong{\n  font-size:13px!important;\n  line-height:normal!important;\n}\n#modePill{\n  min-width:50px;\n  justify-content:center;\n}\n/* GROUND_STATION_TOP_BANNER_V2_8_19_ARM_STATE_TEXT_ONLY */\n#armStatePill{\n  min-width:70px;\n  justify-content:center;\n  gap:0!important;\n}\n.gs-top-toggle{\n  border-color:#475569!important;\n  background:#111827!important;\n  color:#cbd5e1!important;\n  box-shadow:none!important;\n}\n.gs-top-toggle:hover,\n.gs-top-toggle:focus-visible{\n  border-color:#64748b!important;\n  background:#1f2937!important;\n}\n.gs-top-toggle.gs-state-on{\n  border-color:#4ade80!important;\n  background:#14532d!important;\n  color:#dcfce7!important;\n}\n.gs-top-toggle.gs-state-on:hover,\n.gs-top-toggle.gs-state-on:focus-visible{\n  border-color:#86efac!important;\n  background:#166534!important;\n}\n.gs-top-toggle:disabled{\n  opacity:.66;\n  cursor:not-allowed;\n}\n#audioMuteBtn,\n#audioTestBtn,\n#audioVolume{\n  display:none!important;\n}\n.gs-audio-controls{\n  display:inline-flex!important;\n}\n@media(max-width:760px){\n  #modePill{min-width:42px}\n  #armStatePill{min-width:58px}\n}\n\n\n/* GROUND_STATION_QGC_GROUPED_SELECTOR_V4_1_0 */\n.gs-telemetry-scopebar{display:grid;grid-template-columns:1fr 1fr;gap:4px;margin-bottom:4px}\n.gs-telemetry-scopebar button{border:1px solid #475569;border-radius:7px;background:#0f172a;color:#cbd5e1;padding:5px 7px;font-size:9px;font-weight:900}\n.gs-telemetry-scopebar button.active{background:#14532d;color:#dcfce7;border-color:#4ade80}\n.gs-telemetry-count-card{display:flex;flex-wrap:wrap;gap:4px 8px;margin:3px 0 5px;padding:5px 6px;border:1px solid rgba(71,85,105,.72);border-radius:7px;background:rgba(7,17,31,.82);font-size:8px;line-height:1.3;color:#cbd5e1}\n.gs-telemetry-count-stat{white-space:nowrap}.gs-telemetry-count-stat strong{color:#f8fafc;font-size:9px}\n.gs-telemetry-count-help{flex-basis:100%;color:#94a3b8}\n.gs-telemetry-category{display:grid;gap:2px;margin-bottom:4px}\n.gs-telemetry-category-head{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:6px;width:100%;padding:5px 7px;border:1px solid rgba(71,85,105,.78);border-radius:6px;background:#111c31;color:#f8fafc;text-align:left;font-size:9px;font-weight:900;cursor:pointer}\n.gs-telemetry-category-head .category-name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.gs-telemetry-category-head .category-count{color:#93c5fd;font-size:7px;font-weight:800;white-space:nowrap}\n.gs-telemetry-category-head[aria-expanded="false"] .category-name:before{content:"▸ ";color:#94a3b8}\n.gs-telemetry-category-head[aria-expanded="true"] .category-name:before{content:"▾ ";color:#94a3b8}\n.gs-telemetry-category-body{display:grid;gap:2px;padding-left:3px}\n.gs-telemetry-category-body[hidden]{display:none!important}\n.gs-telemetry-field .seen{color:#fbbf24;font-size:7px;font-weight:900}\n.gs-telemetry-load-more-wrap{display:flex;justify-content:center;padding:5px 0 2px}\n.gs-telemetry-load-more-wrap[hidden]{display:none!important}\n.gs-telemetry-load-more-wrap .gs-btn{min-width:130px}\n@media(max-width:760px),(max-height:560px){\n  .gs-telemetry-scopebar button{padding:3px 5px;font-size:8px}\n  .gs-telemetry-count-card{padding:3px 5px;font-size:7px;gap:2px 6px}\n  .gs-telemetry-count-stat strong{font-size:8px}\n  .gs-telemetry-category-head{padding:3px 5px;font-size:8px}\n  .gs-telemetry-category-head .category-count{font-size:6px}\n}\n\n</style>\n</head>\n<body>\n<div class="gs-orientation-guard" id="orientationGuard" role="alert" aria-live="assertive" aria-hidden="true"><div class="gs-orientation-card"><div class="gs-orientation-icon">↻</div><strong>Rotate device to landscape</strong><span>The Ground Station is available in landscape orientation only.</span></div></div>\n<div class="gs-mode-menu-backdrop" id="flightModeMenuBackdrop" hidden aria-hidden="true"></div>\n<section class="gs-mode-menu" id="flightModeMenu" role="dialog" aria-modal="true" aria-label="Flight mode" hidden>\n  <div class="gs-mode-grid" id="flightModeGrid" role="listbox" aria-label="Flight mode"></div>\n</section>\n<div class="gs-mode-menu-backdrop" id="armStateMenuBackdrop" hidden aria-hidden="true"></div>\n<section class="gs-mode-menu" id="armStateMenu" role="dialog" aria-modal="true" aria-label="Arm state" hidden>\n  <div class="gs-mode-grid" id="armStateGrid" role="listbox" aria-label="Arm state"></div>\n</section>\n<div class="gs-app" id="gsApp">\n  <div class="gs-top">\n    <div class="gs-top-left">\n      <div class="gs-brand"><span>Ground Station</span></div>\n      <button class="gs-chip gs-connection-chip" id="connectionChip" type="button" aria-label="Show vehicle messages"><span class="gs-dot" id="connDot"></span><strong id="connState">CONNECTING</strong><span id="heartbeatAge">—</span></button>\n      <button class="gs-chip gs-mode-chip gs-status-select-pill" id="modePill" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="flightModeMenu" title="Select flight mode" aria-label="Select flight mode"><strong id="modeValue">—</strong></button>\n      <button class="gs-chip gs-mode-chip gs-arm-chip gs-status-select-pill" id="armStatePill" type="button" aria-haspopup="dialog" aria-expanded="false" aria-controls="armStateMenu" title="Select arm state" aria-label="Select arm state"><strong id="armedValue">UNKNOWN</strong></button>\n      <div class="gs-top-status-cluster" id="gpsRecordStatusCluster">\n        <div class="gs-chip gs-gps-chip bad" id="gpsStatusPill" role="status" aria-live="polite" aria-label="GPS unavailable"><span class="gs-gps-dot" aria-hidden="true"></span><strong id="gpsValue">NO GPS</strong></div>\n        <div class="gs-chip gs-record-chip" id="recordingChip" role="status" aria-live="polite" aria-label="Camera recording active"><span class="gs-record-dot" aria-hidden="true"></span><strong>REC</strong></div>\n      </div>\n      <div class="gs-chip optional"><span>BAT</span><strong id="batteryTop">—</strong></div>\n      <div class="gs-chip optional"><span>LINK</span><strong id="linkTop">—</strong></div>\n      <div class="gs-chip optional"><span>FLIGHT</span><strong id="flightTime">00:00:00</strong></div>\n    </div>\n    <div class="gs-top-right">\n      <!-- GROUND_STATION_DUAL_VIDEO_AUDIO_V3 -->\n      <div class="gs-audio-controls">\n        <button class="gs-btn compact gs-top-toggle" id="audioEnableBtn" type="button" aria-pressed="false">Audio</button>\n        <button class="gs-btn compact audio-secondary" id="audioMuteBtn" disabled>Mute</button>\n        <input class="gs-volume" id="audioVolume" type="range" min="0" max="1" step="0.05" value="0.85" aria-label="Flight audio volume">\n        <button class="gs-btn compact audio-secondary" id="audioTestBtn" disabled>Test</button>\n      </div>\n      <button class="gs-btn compact gs-top-toggle" id="drawerBtn" type="button" aria-pressed="false">Telemetry</button>\n      <button class="gs-btn compact gs-top-toggle" id="hudBtn" type="button" aria-pressed="false">HUD</button>\n      <button class="gs-btn compact" id="fullscreenBtn">Full screen</button>\n      <button class="gs-btn compact gs-top-toggle" id="joystickBtn" type="button" aria-pressed="false">Joystick</button>\n      <button class="gs-btn compact" id="controlCenterBtn" type="button">Control center</button>\n    </div>\n  </div>\n\n  <div class="gs-main">\n    <div class="gs-stage" id="stage">\n      <div class="gs-view active" id="videoView">\n        <video class="gs-video-frame" id="videoFrame" autoplay muted playsinline disablepictureinpicture title="Live aircraft video"></video>\n        <div class="gs-video-overlay">\n          <div class="gs-video-state"><span id="videoSourceName">Video</span></div>\n          <div class="gs-video-controls">\n            <button class="gs-btn compact" id="videoReconnect">Reconnect</button>\n            <button class="gs-btn compact" id="videoFallback">Use HLS</button>\n          </div>\n        </div>\n        <div class="gs-hud" id="hud">\n          <div class="gs-attitude-overlay" id="attitudeOverlay" aria-label="Attitude level indicator">\n            <div class="gs-horizon-wrap"><div class="gs-horizon" id="mainHorizon"></div></div>\n            <div class="gs-aircraft-symbol"><span></span></div>\n          </div>\n          <div class="gs-telemetry-overlay" aria-label="Primary flight telemetry">\n            <div class="gs-telemetry-box"><span class="label">Airspeed</span><span class="reading"><strong id="hudAirspeed">—</strong><em>km/h</em></span></div>\n            <div class="gs-telemetry-box"><span class="label">Groundspeed</span><span class="reading"><strong id="hudGroundspeed">—</strong><em>km/h</em></span></div>\n            <div class="gs-telemetry-box"><span class="label">Altitude</span><span class="reading"><strong id="hudAltitude">—</strong><em>m</em></span></div>\n            <div class="gs-telemetry-box"><span class="label">Throttle</span><span class="reading"><strong id="hudThrottle">—</strong><em>%</em></span></div>\n          </div>\n          <div class="gs-mode-overlay" id="hudMode">MONITOR ONLY · —</div>\n          <span id="hudVspeed" hidden>—</span>\n        </div>\n        <div class="gs-round-hud" id="roundHud" aria-label="Floating circular attitude HUD">\n          <div class="gs-round-face" id="roundHudFace">\n            <div class="gs-round-horizon-wrap">\n              <div class="gs-round-horizon" id="roundHorizon">\n                <div class="gs-round-pitch-ladder" aria-hidden="true">\n                  <span class="major" style="--pitch-y:35%" data-pitch="+30"></span>\n                  <span style="--pitch-y:40%" data-pitch="+20"></span>\n                  <span style="--pitch-y:45%" data-pitch="+10"></span>\n                  <span style="--pitch-y:55%" data-pitch="-10"></span>\n                  <span style="--pitch-y:60%" data-pitch="-20"></span>\n                  <span class="major" style="--pitch-y:65%" data-pitch="-30"></span>\n                </div>\n              </div>\n            </div>\n            <div class="gs-round-shade"></div>\n            <div class="gs-round-glass"></div>\n            <div class="gs-round-inner-ring"></div>\n            <div class="gs-round-bank-scale" aria-hidden="true">\n              <span class="major" style="--bank-angle:-60deg"></span>\n              <span style="--bank-angle:-45deg"></span>\n              <span class="major" style="--bank-angle:-30deg"></span>\n              <span style="--bank-angle:-20deg"></span>\n              <span style="--bank-angle:-10deg"></span>\n              <span class="major" style="--bank-angle:0deg"></span>\n              <span style="--bank-angle:10deg"></span>\n              <span style="--bank-angle:20deg"></span>\n              <span class="major" style="--bank-angle:30deg"></span>\n              <span style="--bank-angle:45deg"></span>\n              <span class="major" style="--bank-angle:60deg"></span>\n            </div>\n            <div class="gs-round-bank"></div>\n            <div class="gs-round-aircraft"><span></span><i></i></div>\n            <div class="gs-round-compass" id="roundHudCompass" aria-hidden="true">\n              <span class="gs-round-cardinal" data-bearing="0">N</span>\n              <span class="gs-round-cardinal" data-bearing="90">E</span>\n              <span class="gs-round-cardinal" data-bearing="180">S</span>\n              <span class="gs-round-cardinal" data-bearing="270">W</span>\n            </div>\n            <div class="gs-round-home" id="roundHudHome" aria-hidden="true"><span class="roof"></span><span class="body"></span><span class="door"></span></div>\n            <div class="gs-round-stale" id="roundHudLost">ATTITUDE DATA</div>\n          </div>\n          <button class="gs-round-resize nw" data-round-corner="nw" type="button" aria-label="Resize circular HUD from top left"></button>\n          <button class="gs-round-resize ne" data-round-corner="ne" type="button" aria-label="Resize circular HUD from top right"></button>\n          <button class="gs-round-resize sw" data-round-corner="sw" type="button" aria-label="Resize circular HUD from bottom left"></button>\n          <button class="gs-round-resize se" data-round-corner="se" type="button" aria-label="Resize circular HUD from bottom right"></button>\n        </div>\n        <div class="gs-pip" id="cameraPip" title="Tap to swap cameras; drag to move">\n          <div class="gs-camera-label" id="secondaryVideoLabel">SECOND CAMERA — TAP TO SWAP</div>\n          <video class="gs-video-frame" id="videoFrameSecondary" autoplay muted playsinline disablepictureinpicture title="Secondary live aircraft video"></video>\n          <button class="gs-pip-resize nw" data-corner="nw" type="button" aria-label="Resize picture in picture from top left" title="Drag to resize"></button>\n          <button class="gs-pip-resize ne" data-corner="ne" type="button" aria-label="Resize picture in picture from top right" title="Drag to resize"></button>\n          <button class="gs-pip-resize sw" data-corner="sw" type="button" aria-label="Resize picture in picture from bottom left" title="Drag to resize"></button>\n          <button class="gs-pip-resize se" data-corner="se" type="button" aria-label="Resize picture in picture from bottom right" title="Drag to resize"></button>\n          <button class="gs-pip-edge-button" id="pipRestoreButton" type="button" aria-label="Restore picture in picture"><span>CAM</span></button>\n        </div>\n        <div class="gs-pip gs-video-map-pip" id="mapPip" title="Map picture in picture">\n          <div class="gs-map-pip-content" id="mapPipContent"></div>\n          <div class="gs-camera-label" id="videoMapPipLabel">MAP — TAP FOR FULL MAP · DRAG TO MOVE</div>\n          <button class="gs-pip-resize nw" data-video-map-pip-corner="nw" type="button" aria-label="Resize map picture in picture from top left" title="Drag to resize"></button>\n          <button class="gs-pip-resize ne" data-video-map-pip-corner="ne" type="button" aria-label="Resize map picture in picture from top right" title="Drag to resize"></button>\n          <button class="gs-pip-resize sw" data-video-map-pip-corner="sw" type="button" aria-label="Resize map picture in picture from bottom left" title="Drag to resize"></button>\n          <button class="gs-pip-resize se" data-video-map-pip-corner="se" type="button" aria-label="Resize map picture in picture from bottom right" title="Drag to resize"></button>\n          <button class="gs-pip-edge-button" id="mapPipRestoreButton" type="button" aria-label="Restore map picture in picture"><span>MAP</span></button>\n        </div>\n      </div>\n\n      <div class="gs-view" id="mapView">\n        <div class="gs-map-host" id="mapHostMain">\n          <div class="gs-map-placeholder"><div><strong>Satellite map</strong>Select Map or Split to load MapTiler. Vehicle, Home and track appear when telemetry provides coordinates.</div></div>\n          <div class="gs-map-status">Map not loaded</div>\n          <div class="gs-map-toolbar">\n            <div class="gs-map-style-switch"><button type="button" data-map-style="hybrid">HYBRID</button><button type="button" data-map-style="satellite">SATELLITE</button></div>\n            <div class="gs-map-controls"><button type="button" data-map="plus" title="Zoom in">+</button><button type="button" data-map="minus" title="Zoom out">−</button><button type="button" data-map="follow" title="Follow aircraft">⌖</button><button type="button" data-map="fit" title="Fit Home, aircraft and track">⤢</button></div>\n          </div>\n        </div>\n        <div class="gs-pip gs-map-video-pip" id="videoPip" title="Tap for Video view; drag to move; drag a corner to resize">\n          <div class="gs-camera-label" id="mapVideoLabel">PRIMARY CAMERA — TAP FOR VIDEO VIEW</div>\n          <video class="gs-video-frame" id="videoFramePip" autoplay muted playsinline disablepictureinpicture title="Primary live aircraft video picture in picture"></video>\n          <button class="gs-pip-resize nw" data-map-pip-corner="nw" type="button" aria-label="Resize map video from top left" title="Drag to resize"></button>\n          <button class="gs-pip-resize ne" data-map-pip-corner="ne" type="button" aria-label="Resize map video from top right" title="Drag to resize"></button>\n          <button class="gs-pip-resize sw" data-map-pip-corner="sw" type="button" aria-label="Resize map video from bottom left" title="Drag to resize"></button>\n          <button class="gs-pip-resize se" data-map-pip-corner="se" type="button" aria-label="Resize map video from bottom right" title="Drag to resize"></button>\n          <button class="gs-pip-edge-button" id="videoPipRestoreButton" type="button" aria-label="Restore video picture in picture"><span>CAM</span></button>\n        </div>\n      </div>\n\n    </div>\n\n    <div class="gs-telemetry-groups-host" id="sidePanel" aria-label="Telemetry groups"></div>\n\n    <div class="gs-telemetry-settings-backdrop" id="telemetrySettingsBackdrop" aria-hidden="true"></div>\n    <section class="gs-telemetry-settings" id="telemetrySettings" aria-hidden="true" role="dialog" aria-label="Telemetry Canvas settings">\n      <div class="gs-telemetry-settings-head"><span>Telemetry Groups</span><button class="gs-telemetry-settings-close" id="telemetrySettingsClose" type="button" aria-label="Close telemetry settings">×</button></div>\n      <div class="gs-telemetry-groupbar">\n        <select id="telemetryGroupSelect" aria-label="Telemetry group"></select>\n        <button class="gs-btn compact" id="telemetryGroupAdd" type="button">+ Group</button>\n        <button class="gs-btn compact" id="telemetryGroupRename" type="button">Rename</button>\n        <button class="gs-btn compact" id="telemetryGroupDelete" type="button">Delete</button>\n      </div>\n      <div class="gs-telemetry-tabs"><button class="gs-telemetry-tab active" type="button" data-telemetry-tab="layout">Layout</button><button class="gs-telemetry-tab" type="button" data-telemetry-tab="data">Data</button></div>\n      <div class="gs-telemetry-pane active" data-telemetry-pane="layout">\n        <div class="gs-telemetry-settings-grid">\n          <label class="gs-telemetry-setting">Columns<input id="telemetryColsInput" type="number" min="1" max="24" step="1" value="2"></label>\n          <label class="gs-telemetry-setting">Value size (px)<input id="telemetryFontInput" type="number" min="10" max="40" step="1" value="17"></label>\n          <label class="gs-telemetry-check"><input id="telemetryLabelInput" type="checkbox" checked>Show labels</label>\n          <label class="gs-telemetry-check"><input id="telemetryUnitInput" type="checkbox" checked>Show units</label>\n          <div class="gs-telemetry-settings-note">Each group is an independent overlay. Choose a group above, select its values and columns, then place it anywhere on screen. Double-tap a group to edit it. Hold a group to move or resize it.</div>\n        </div>\n      </div>\n      <div class="gs-telemetry-pane" data-telemetry-pane="data">\n        <div class="gs-telemetry-search-row"><input id="telemetrySearchInput" type="text" placeholder="Search telemetry value or advanced MAVLink field"><button class="gs-btn compact" id="telemetryClearSearch" type="button">Clear</button></div>\n        <div class="gs-telemetry-scopebar" aria-label="Telemetry catalogue scope"><button class="active" type="button" data-telemetry-scope="qgc">Telemetry Categories</button><button type="button" data-telemetry-scope="advanced">Advanced MAVLink</button></div>\n        <div class="gs-telemetry-filterbar"><button class="active" type="button" data-telemetry-filter="available">Received this session</button><button type="button" data-telemetry-filter="selected">Selected</button><button type="button" data-telemetry-filter="all">All in scope</button></div>\n        <div class="gs-telemetry-count-card" id="telemetryCountCard">Loading catalogue counts…</div>\n        <div class="gs-telemetry-result-note" id="telemetryResultNote">Loading the telemetry catalogue…</div>\n        <div class="gs-telemetry-field-list" id="telemetryFieldList"></div>\n        <div class="gs-telemetry-load-more-wrap" id="telemetryLoadMoreWrap" hidden><button class="gs-btn compact" id="telemetryLoadMore" type="button">Load 300 more</button></div>\n        <div class="gs-telemetry-selected-note">Selected values · custom label (blank = original)</div>\n        <div class="gs-telemetry-selected-list" id="telemetrySelectedList"></div>\n      </div>\n      <div class="gs-telemetry-settings-actions"><span class="gs-telemetry-save-state" id="telemetrySaveState"></span><button class="gs-btn compact" id="telemetryArrangeBtn" type="button">Move / resize group</button><button class="gs-btn compact" id="telemetrySettingsReset" type="button">Defaults</button><button class="gs-btn compact active" id="telemetrySettingsApply" type="button">Done</button></div>\n    </section>\n\n\n    <div class="gs-joystick-backdrop" id="joystickBackdrop" aria-hidden="true"></div>\n    <section class="gs-joystick-panel" id="joystickPanel" aria-hidden="true" role="dialog" aria-label="Android USB joystick setup">\n      <div class="gs-joystick-head"><strong>Android USB joystick</strong><span id="joystickHeadState">CONTROL DISABLED</span><button class="gs-joystick-close" id="joystickClose" type="button" aria-label="Close joystick panel">×</button></div>\n      <div class="gs-joystick-banner" id="joystickSafetyBanner">JOYSTICK CONTROL DISABLED</div>\n      <div class="gs-joystick-sections">\n        <div class="gs-joystick-card">\n          <div class="gs-joystick-title">Android controller</div>\n          <div class="gs-joystick-row"><select class="gs-joystick-select" id="joystickDeviceSelect"></select><button class="gs-btn compact" id="joystickUseDevice" type="button">Use controller</button></div>\n          <div class="gs-joystick-kv" id="joystickDeviceInfo"><span>Status</span><span>Waiting for Android browser…</span></div>\n          <div class="gs-joystick-row"><button class="gs-btn compact" id="joystickTestBtn" type="button">Start live test</button><button class="gs-btn compact" id="joystickRefreshBtn" type="button">Refresh</button></div>\n        </div>\n        <div class="gs-joystick-card">\n          <div class="gs-joystick-title">Calibration</div>\n          <div id="joystickCalibrationState" class="gs-joystick-status-warn">Not running</div>\n          <p style="font-size:11px;color:#94a3b8">Start with centered controls, then move every axis through its full range and press every button. Calibration never transmits aircraft control.</p>\n          <div class="gs-joystick-row"><button class="gs-btn compact" id="joystickCalStart" type="button">Start calibration</button><button class="gs-btn compact" id="joystickCalSave" type="button">Save</button><button class="gs-btn compact" id="joystickCalCancel" type="button">Cancel</button></div>\n        </div>\n        <div class="gs-joystick-card wide">\n          <div class="gs-joystick-title">Live axes</div>\n          <div class="gs-axis-list" id="joystickAxisList"><span>Waiting for controller…</span></div>\n        </div>\n        <div class="gs-joystick-card wide">\n          <div class="gs-joystick-title">Axis mapping preview</div>\n          <table class="gs-map-table"><thead><tr><th>Function</th><th>Axis</th><th>Reverse</th><th>Dead-zone</th><th>Expo</th><th>Processed</th></tr></thead><tbody id="joystickMappingBody"></tbody></table>\n          <div class="gs-joystick-row"><button class="gs-btn compact active" id="joystickSaveMapping" type="button">Save mapping</button><span id="joystickSaveState"></span></div>\n        </div>\n        <div class="gs-joystick-card wide"><div class="gs-joystick-title">Buttons and D-pad</div><div class="gs-button-grid" id="joystickButtonGrid"><span>Waiting for controller…</span></div></div>\n      </div>\n    </section>\n\n    <aside class="gs-message-popover" id="messagePopover" aria-hidden="true">\n      <div class="gs-message-popover-head"><strong>Vehicle messages</strong><button class="gs-message-popover-close" id="messagePopoverClose" type="button" aria-label="Close vehicle messages">×</button></div>\n      <div class="gs-message-list" id="messageList"><div class="g  <!-- GROUND_STATION_BOTTOM_BANNER_REMOVED_V2_8_3 -->\n  <div id="gsLegacyBottomControls" hidden aria-hidden="true">\n    <div class="gs-layout-buttons"><button class="gs-btn compact active" data-layout="video">Video</button><button class="gs-btn compact" data-layout="map">Map</button></div>\n    <div class="gs-dual-status">\n      <span id="dualVideoSummary">Primary: SIYI · PiP: Air Link</span>\n      <span id="airlinkBufferState">Air Link: starting</span>\n      <button class="gs-btn compact" id="resyncAirlinkBtn">Resync Air Link</button>\n      <button class="gs-btn compact" id="swapCamerasBtn">Swap cameras</button>\n    </div>\n    <div class="gs-monitor">MONITOR ONLY</div>\n    <div class="gs-alert" id="statusMessage">Ground Station backend is connecting. Vehicle commands are not available in this patch.</div>\n  </div>\ng. Vehicle commands are not available in this patch.</div>\n  </div>\n</div>\n<script>\n\'use strict\';\nconst GS={state:null,layout:\'video_dual\',protocol:\'webrtc\',hudMode:\'full\',mapScale:1,map:null,mapElement:null,mapSdkPromise:null,mapReady:false,mapStyle:\'hybrid\',mapTileLayer:null,mapTrackLine:null,mapAircraftMarker:null,mapHomeMarker:null,mapFollow:true,mapInitialPosition:false,mapLastFollowAt:0,mapTrackSignature:\'\',sourceNames:{siyi_rtsp:\'SIYI\',hdmi_usb:\'HDMI\',wifilink_rtsp:\'Air Link\'},primarySource:\'siyi_rtsp\',secondarySource:\'wifilink_rtsp\',videoPaths:{siyi_rtsp:\'gs_siyi\',wifilink_rtsp:\'gs_wifilink\'},players:{},audioEnabled:true,audioMuted:false,audioUnlocked:false,audioVolume:.85,audioContext:null,audioQueue:[],audioPlaying:false,audioSource:null,audioElement:null,lastMessageTs:0,lastSpoken:{},lastConnection:null,lastMode:null,lastArmed:null,lastOperationalVideoSource:null,lastUiEventId:null,lastVoiceEventId:null,recording:null,hiddenAt:0};\nconst GS_FLIGHT_MODE_ACTIONS=__GS_FLIGHT_MODE_ACTIONS_JSON__;\nconst FLIGHT_MODE_SELECTOR={\n  open:false,\n  pending:false,\n  requestedMode:\'\',\n  requestedAt:0\n};\nconst ARM_STATE_ACTIONS=[\'ARM\',\'DISARM\'];\nconst ARM_STATE_SELECTOR={\n  open:false,\n  pending:false,\n  requestedAction:\'\',\n  requestedAt:0\n};\nconst LEAFLET_VERSION=\'1.9.4\';\nconst MAPTILER_STYLE_KEY=\'siyi-groundstation-map-style-v18\';\nconst $=id=>document.getElementById(id);\nconst number=(value,digits=0)=>typeof value===\'number\'&&Number.isFinite(value)?value.toFixed(digits):\'—\';\nconst kmh=value=>typeof value===\'number\'?value*3.6:null;\nconst clock=seconds=>{seconds=Math.max(0,Math.floor(Number(seconds)||0));const h=String(Math.floor(seconds/3600)).padStart(2,\'0\');const m=String(Math.floor((seconds%3600)/60)).padStart(2,\'0\');const s=String(seconds%60).padStart(2,\'0\');return h+\':\'+m+\':\'+s;};\nconst ageFresh=(key,limit)=>GS.state&&GS.state.field_age_s&&typeof GS.state.field_age_s[key]===\'number\'&&GS.state.field_age_s[key]<=limit;\nfunction setText(id,value){const node=$(id);if(node)node.textContent=value;}\nfunction setTopBannerToggleState(\n  buttonOrId,\n  enabled,\n  label\n){\n  const button=typeof buttonOrId===\'string\'\n    ?$(buttonOrId)\n    :buttonOrId;\n  if(!button)return;\n  if(label!==undefined)button.textContent=String(label);\n  const on=Boolean(enabled);\n  button.classList.toggle(\'gs-state-on\',on);\n  button.classList.remove(\'active\',\'audio-on\',\'audio-muted\',\n    \'gs-joystick-ready\',\'gs-joystick-active\');\n  button.setAttribute(\'aria-pressed\',on?\'true\':\'false\');\n}\nfunction gpsFixPresentation(rawFix){\n  const numeric=Number(rawFix);\n  if(\n    rawFix!==null&&rawFix!==undefined&&rawFix!==\'\'&&\n    Number.isFinite(numeric)\n  ){\n    const labels={\n      0:[\'NO GPS\',\'bad\'],\n      1:[\'NO FIX\',\'warn\'],\n      2:[\'2D\',\'warn\'],\n      3:[\'3D\',\'ok\'],\n      4:[\'DGPS\',\'ok\'],\n      5:[\'RTK FLOAT\',\'ok\'],\n      6:[\'RTK FIX\',\'ok\'],\n      7:[\'STATIC\',\'ok\'],\n      8:[\'PPP\',\'ok\']\n    };\n    if(labels[Math.trunc(numeric)]){\n      const item=labels[Math.trunc(numeric)];\n      return {label:item[0],level:item[1]};\n    }\n  }\n  const text=String(rawFix==null?\'\':rawFix)\n    .trim()\n    .toUpperCase()\n    .replace(/[_-]+/g,\' \')\n    .replace(/\\s+/g,\' \');\n  if(!text||text===\'—\'||text===\'UNKNOWN\'||text===\'N/A\'){\n    return {label:\'NO GPS\',level:\'bad\'};\n  }\n  if(\n    text.includes(\'NO GPS\')||\n    text.includes(\'NO RECEIVER\')||\n    text.includes(\'GPS DISABLED\')\n  )return {label:\'NO GPS\',level:\'bad\'};\n  if(text.includes(\'NO FIX\')||text===\'NONE\'){\n    return {label:\'NO FIX\',level:\'warn\'};\n  }\n  if(text.includes(\'RTK\')&&text.includes(\'FIX\')){\n    return {label:\'RTK FIX\',level:\'ok\'};\n  }\n  if(text.includes(\'RTK\')&&text.includes(\'FLOAT\')){\n    return {label:\'RTK FLOAT\',level:\'ok\'};\n  }\n  if(text.includes(\'DGPS\')||text.includes(\'DIFFERENTIAL\')){\n    return {label:\'DGPS\',level:\'ok\'};\n  }\n  if(text.includes(\'3D\'))return {label:\'3D\',level:\'ok\'};\n  if(text.includes(\'2D\'))return {label:\'2D\',level:\'warn\'};\n  if(text.includes(\'PPP\'))return {label:\'PPP\',level:\'ok\'};\n  if(text.includes(\'STATIC\'))return {label:\'STATIC\',level:\'ok\'};\n  const cleaned=text\n    .replace(/^GPS\\s+/,\'\')\n    .replace(/\\s+FIX$/,\'\')\n    .slice(0,18);\n  return {label:cleaned||\'NO GPS\',level:\'warn\'};\n}\nfunction gpsSatelliteCount(gps){\n  const candidates=[\n    gps&&gps.satellites,\n    gps&&gps.satellites_visible,\n    gps&&gps.sats,\n    gps&&gps.sat_count\n  ];\n  for(const value of candidates){\n    const count=Number(value);\n    if(Number.isFinite(count)&&count>=0&&count<255){\n      return Math.round(count);\n    }\n  }\n  return null;\n}\nfunction updateGpsStatusPill(connection,gps){\n  const pill=$(\'gpsStatusPill\');\n  if(!pill)return;\n  const state=String(connection&&connection.state||\'\').toUpperCase();\n  const satellites=gpsSatelliteCount(gps||{});\n  let fix=gpsFixPresentation(gps&&gps.fix);\n  if(\n    state===\'NO_VEHICLE\'||\n    (fix.label===\'NO GPS\'&&satellites===null)\n  ){\n    fix={label:\'NO GPS\',level:\'bad\'};\n  }\n  const satelliteText=satellites!==null&&satellites>0\n    ?\' · \'+satellites+\' SAT\'\n    :\'\';\n  const text=fix.label===\'NO GPS\'\n    ?\'NO GPS\'\n    :\'GPS \'+fix.label+satelliteText;\n  setText(\'gpsValue\',text);\n  pill.classList.remove(\'ok\',\'warn\',\'bad\',\'stale\');\n  const stale=state===\'LINK_LOST\';\n  pill.classList.add(stale?\'stale\':fix.level);\n  const fixSpeech=fix.label===\'NO GPS\'\n    ?\'GPS unavailable\'\n    :\'GPS \'+fix.label+\' fix\';\n  const satelliteSpeech=satellites!==null&&satellites>0\n    ?\', \'+satellites+\' satellites locked\'\n    :\'\';\n  const staleSpeech=stale?\', telemetry stale\':\'\';\n  pill.setAttribute(\n    \'aria-label\',\n    fixSpeech+satelliteSpeech+staleSpeech\n  );\n  pill.title=fixSpeech+satelliteSpeech+staleSpeech;\n}\nfunction flightModeName(value){\n  return String(value||\'\').trim().toUpperCase();\n}\nfunction flightModeCurrent(){\n  return flightModeName(\n    GS.state&&GS.state.vehicle&&GS.state.vehicle.mode\n  )||\'—\';\n}\nfunction flightModeSignalError(message){\n  const pill=$(\'modePill\');\n  if(!pill)return;\n  pill.classList.add(\'mode-error\');\n  pill.title=String(message||\'Flight-mode request failed\');\n  if(navigator.vibrate)navigator.vibrate(90);\n  window.setTimeout(()=>{\n    pill.classList.remove(\'mode-error\');\n    if(!FLIGHT_MODE_SELECTOR.pending)pill.title=\'Select flight mode\';\n  },1400);\n}\nfunction flightModeRenderOptions(){\n  const grid=$(\'flightModeGrid\');\n  if(!grid)return;\n  if(grid.childElementCount!==GS_FLIGHT_MODE_ACTIONS.length){\n    const fragment=document.createDocumentFragment();\n    for(const mode of GS_FLIGHT_MODE_ACTIONS){\n      const button=document.createElement(\'button\');\n      button.type=\'button\';\n      button.className=\'gs-mode-option\';\n      button.dataset.flightMode=mode;\n      button.setAttribute(\'role\',\'option\');\n      button.setAttribute(\'aria-selected\',\'false\');\n      button.textContent=mode;\n      button.addEventListener(\'click\',()=>requestFlightMode(mode));\n      fragment.appendChild(button);\n    }\n    grid.replaceChildren(fragment);\n  }\n  flightModeUpdateState();\n}\nfunction flightModePositionMenu(){\n  const pill=$(\'modePill\'),menu=$(\'flightModeMenu\');\n  if(!pill||!menu||menu.hidden)return;\n  const rect=pill.getBoundingClientRect();\n  const viewport=window.visualViewport;\n  const vw=Math.round(viewport&&viewport.width?viewport.width:window.innerWidth);\n  const vh=Math.round(viewport&&viewport.height?viewport.height:window.innerHeight);\n  const gap=6;\n  const menuRect=menu.getBoundingClientRect();\n  let left=Math.min(Math.max(8,rect.left),Math.max(8,vw-menuRect.width-8));\n  let top=rect.bottom+gap;\n  if(top+menuRect.height>vh-8){\n    top=Math.max(8,rect.top-menuRect.height-gap);\n  }\n  menu.style.left=Math.round(left)+\'px\';\n  menu.style.top=Math.round(top)+\'px\';\n}\nfunction flightModeUpdateState(){\n  const current=flightModeCurrent();\n  document.querySelectorAll(\'.gs-mode-option\').forEach(button=>{\n    const mode=flightModeName(button.dataset.flightMode);\n    const isCurrent=mode===current;\n    button.classList.toggle(\'current\',isCurrent);\n    button.setAttribute(\'aria-selected\',isCurrent?\'true\':\'false\');\n    button.disabled=FLIGHT_MODE_SELECTOR.pending;\n  });\n  const pill=$(\'modePill\');\n  if(pill){\n    pill.classList.toggle(\'pending\',FLIGHT_MODE_SELECTOR.pending);\n    const pendingMode=FLIGHT_MODE_SELECTOR.requestedMode;\n    pill.title=FLIGHT_MODE_SELECTOR.pending&&pendingMode\n      ?\'Requested \'+pendingMode+\' — waiting for flight controller\'\n      :\'Select flight mode\';\n  }\n  if(\n    FLIGHT_MODE_SELECTOR.pending&&\n    FLIGHT_MODE_SELECTOR.requestedMode===current\n  ){\n    FLIGHT_MODE_SELECTOR.pending=false;\n    FLIGHT_MODE_SELECTOR.requestedMode=\'\';\n    FLIGHT_MODE_SELECTOR.requestedAt=0;\n    if(pill)pill.classList.remove(\'pending\');\n    document.querySelectorAll(\'.gs-mode-option\').forEach(\n      button=>button.disabled=false\n    );\n  }\n}\nfunction setFlightModeMenuOpen(open){\n  const menu=$(\'flightModeMenu\');\n  const backdrop=$(\'flightModeMenuBackdrop\');\n  const pill=$(\'modePill\');\n  if(!menu||!backdrop||!pill)return;\n  FLIGHT_MODE_SELECTOR.open=Boolean(open);\n  menu.hidden=!FLIGHT_MODE_SELECTOR.open;\n  backdrop.hidden=!FLIGHT_MODE_SELECTOR.open;\n  backdrop.setAttribute(\n    \'aria-hidden\',\n    FLIGHT_MODE_SELECTOR.open?\'false\':\'true\'\n  );\n  pill.setAttribute(\n    \'aria-expanded\',\n    FLIGHT_MODE_SELECTOR.open?\'true\':\'false\'\n  );\n  if(FLIGHT_MODE_SELECTOR.open){\n    if(ARM_STATE_SELECTOR.open)setArmStateMenuOpen(false,false);\n    setMessagesOpen(false);\n    flightModeRenderOptions();\n    requestAnimationFrame(()=>{\n      flightModePositionMenu();\n      const current=menu.querySelector(\'.gs-mode-option.current\');\n      const target=current||menu.querySelector(\'.gs-mode-option\');\n      if(current)current.scrollIntoView({block:\'center\'});\n      target?.focus({preventScroll:true});\n    });\n  }else{\n    pill.focus({preventScroll:true});\n  }\n}\nfunction toggleFlightModeMenu(){\n  setFlightModeMenuOpen(!FLIGHT_MODE_SELECTOR.open);\n}\nasync function requestFlightMode(mode){\n  mode=flightModeName(mode);\n  if(\n    FLIGHT_MODE_SELECTOR.pending||\n    !GS_FLIGHT_MODE_ACTIONS.includes(mode)\n  )return;\n  if(mode===flightModeCurrent()){\n    setFlightModeMenuOpen(false);\n    return;\n  }\n  FLIGHT_MODE_SELECTOR.pending=true;\n  FLIGHT_MODE_SELECTOR.requestedMode=mode;\n  FLIGHT_MODE_SELECTOR.requestedAt=Date.now();\n  flightModeUpdateState();\n  try{\n    const response=await fetch(\n      \'/set_flight_mode?mode=\'+encodeURIComponent(mode)+\'&ts=\'+Date.now(),\n      {cache:\'no-store\',credentials:\'same-origin\'}\n    );\n    const payload=await response.json().catch(()=>({}));\n    if(!response.ok||!payload.ok){\n      const message=String(\n        payload.error||\n        (payload.blocked?\'Mode change blocked by the armed-state safety rules\':\n          \'Flight-mode request failed\')\n      );\n      throw new Error(message);\n    }\n    setText(\'modeValue\',mode);\n    if(FLIGHT_MODE_SELECTOR.open)setFlightModeMenuOpen(false);\n    window.setTimeout(()=>{\n      if(\n        FLIGHT_MODE_SELECTOR.pending&&\n        Date.now()-FLIGHT_MODE_SELECTOR.requestedAt>3500\n      ){\n        FLIGHT_MODE_SELECTOR.pending=false;\n        flightModeUpdateState();\n      }\n    },3700);\n  }catch(error){\n    FLIGHT_MODE_SELECTOR.pending=false;\n    FLIGHT_MODE_SELECTOR.requestedMode=\'\';\n    FLIGHT_MODE_SELECTOR.requestedAt=0;\n    flightModeUpdateState();\n    flightModeSignalError(\n      String(error&&error.message?error.message:error)\n    );\n  }\n}\n\nfunction armStateCurrent(){\n  const armed=GS.state&&GS.state.vehicle&&GS.state.vehicle.armed;\n  return armed===true?\'ARM\':armed===false?\'DISARM\':\'\';\n}\nfunction armStateSignalError(message){\n  const pill=$(\'armStatePill\');\n  if(!pill)return;\n  pill.classList.add(\'mode-error\');\n  pill.title=String(message||\'Arm-state request failed\');\n  if(navigator.vibrate)navigator.vibrate([90,45,90]);\n  window.setTimeout(()=>{\n    pill.classList.remove(\'mode-error\');\n    if(!ARM_STATE_SELECTOR.pending)pill.title=\'Select arm state\';\n  },1600);\n}\nfunction armStateRenderOptions(){\n  const grid=$(\'armStateGrid\');\n  if(!grid)return;\n  if(grid.childElementCount!==ARM_STATE_ACTIONS.length){\n    const fragment=document.createDocumentFragment();\n    for(const action of ARM_STATE_ACTIONS){\n      const button=document.createElement(\'button\');\n      button.type=\'button\';\n      button.className=\'gs-mode-option gs-arm-option\';\n      button.dataset.armState=action;\n      button.setAttribute(\'role\',\'option\');\n      button.setAttribute(\'aria-selected\',\'false\');\n      button.textContent=action;\n      button.addEventListener(\'click\',()=>requestArmState(action));\n      fragment.appendChild(button);\n    }\n    grid.replaceChildren(fragment);\n  }\n  armStateUpdateState();\n}\nfunction armStatePositionMenu(){\n  const pill=$(\'armStatePill\'),menu=$(\'armStateMenu\');\n  if(!pill||!menu||menu.hidden)return;\n  const rect=pill.getBoundingClientRect();\n  const viewport=window.visualViewport;\n  const vw=Math.round(viewport&&viewport.width?viewport.width:window.innerWidth);\n  const vh=Math.round(viewport&&viewport.height?viewport.height:window.innerHeight);\n  const gap=6;\n  const menuRect=menu.getBoundingClientRect();\n  let left=Math.min(Math.max(8,rect.left),Math.max(8,vw-menuRect.width-8));\n  let top=rect.bottom+gap;\n  if(top+menuRect.height>vh-8){\n    top=Math.max(8,rect.top-menuRect.height-gap);\n  }\n  menu.style.left=Math.round(left)+\'px\';\n  menu.style.top=Math.round(top)+\'px\';\n}\nfunction armStateUpdateState(){\n  const current=armStateCurrent();\n  document.querySelectorAll(\'.gs-arm-option\').forEach(button=>{\n    const action=String(button.dataset.armState||\'\').toUpperCase();\n    const isCurrent=action===current;\n    button.classList.toggle(\'current\',isCurrent);\n    button.setAttribute(\'aria-selected\',isCurrent?\'true\':\'false\');\n    button.disabled=ARM_STATE_SELECTOR.pending;\n  });\n  const pill=$(\'armStatePill\');\n  if(pill){\n    pill.classList.toggle(\'pending\',ARM_STATE_SELECTOR.pending);\n    pill.classList.toggle(\'armed\',current===\'ARM\');\n    pill.classList.toggle(\'disarmed\',current===\'DISARM\');\n    pill.setAttribute(\n      \'aria-label\',\n      current===\'ARM\'?\'Aircraft armed. Select arm state\':\n      current===\'DISARM\'?\'Aircraft disarmed. Select arm state\':\n      \'Arm state unknown. Select arm state\'\n    );\n    const requested=ARM_STATE_SELECTOR.requestedAction;\n    pill.title=ARM_STATE_SELECTOR.pending&&requested\n      ?\'Requested \'+requested+\' — waiting for flight controller\'\n      :\'Select arm state\';\n  }\n  if(\n    ARM_STATE_SELECTOR.pending&&\n    ARM_STATE_SELECTOR.requestedAction===current\n  ){\n    ARM_STATE_SELECTOR.pending=false;\n    ARM_STATE_SELECTOR.requestedAction=\'\';\n    ARM_STATE_SELECTOR.requestedAt=0;\n    if(pill)pill.classList.remove(\'pending\');\n    document.querySelectorAll(\'.gs-arm-option\').forEach(\n      button=>button.disabled=false\n    );\n  }\n}\nfunction setArmStateMenuOpen(open,returnFocus=true){\n  const menu=$(\'armStateMenu\');\n  const backdrop=$(\'armStateMenuBackdrop\');\n  const pill=$(\'armStatePill\');\n  if(!menu||!backdrop||!pill)return;\n  ARM_STATE_SELECTOR.open=Boolean(open);\n  menu.hidden=!ARM_STATE_SELECTOR.open;\n  backdrop.hidden=!ARM_STATE_SELECTOR.open;\n  backdrop.setAttribute(\n    \'aria-hidden\',\n    ARM_STATE_SELECTOR.open?\'false\':\'true\'\n  );\n  pill.setAttribute(\n    \'aria-expanded\',\n    ARM_STATE_SELECTOR.open?\'true\':\'false\'\n  );\n  if(ARM_STATE_SELECTOR.open){\n    if(FLIGHT_MODE_SELECTOR.open)setFlightModeMenuOpen(false);\n    setMessagesOpen(false);\n    armStateRenderOptions();\n    requestAnimationFrame(()=>{\n      armStatePositionMenu();\n      const current=menu.querySelector(\'.gs-arm-option.current\');\n      const target=current||menu.querySelector(\'.gs-arm-option\');\n      if(current)current.scrollIntoView({block:\'center\'});\n      target?.focus({preventScroll:true});\n    });\n  }else if(returnFocus){\n    pill.focus({preventScroll:true});\n  }\n}\nfunction toggleArmStateMenu(){\n  setArmStateMenuOpen(!ARM_STATE_SELECTOR.open);\n}\nasync function requestArmState(action){\n  action=String(action||\'\').trim().toUpperCase();\n  if(\n    ARM_STATE_SELECTOR.pending||\n    !ARM_STATE_ACTIONS.includes(action)\n  )return;\n  if(action===armStateCurrent()){\n    setArmStateMenuOpen(false);\n    return;\n  }\n  ARM_STATE_SELECTOR.pending=true;\n  ARM_STATE_SELECTOR.requestedAction=action;\n  ARM_STATE_SELECTOR.requestedAt=Date.now();\n  armStateUpdateState();\n  try{\n    const response=await fetch(\n      \'/set_arm_state?action=\'+encodeURIComponent(action)+\'&ts=\'+Date.now(),\n      {cache:\'no-store\',credentials:\'same-origin\'}\n    );\n    const payload=await response.json().catch(()=>({}));\n    if(!response.ok||!payload.ok){\n      throw new Error(\n        String(\n          payload.error||\n          (payload.blocked?\'Arm-state action blocked by safety rules\':\n            \'Arm-state request failed\')\n        )\n      );\n    }\n    if(ARM_STATE_SELECTOR.open)setArmStateMenuOpen(false);\n    window.setTimeout(()=>{\n      if(\n        ARM_STATE_SELECTOR.pending&&\n        Date.now()-ARM_STATE_SELECTOR.requestedAt>4800\n      ){\n        ARM_STATE_SELECTOR.pending=false;\n        ARM_STATE_SELECTOR.requestedAction=\'\';\n        ARM_STATE_SELECTOR.requestedAt=0;\n        armStateUpdateState();\n        armStateSignalError(\n          action+\' was not confirmed by the flight controller\'\n        );\n      }\n    },5000);\n  }catch(error){\n    ARM_STATE_SELECTOR.pending=false;\n    ARM_STATE_SELECTOR.requestedAction=\'\';\n    ARM_STATE_SELECTOR.requestedAt=0;\n    armStateUpdateState();\n    armStateSignalError(\n      String(error&&error.message?error.message:error)\n    );\n  }\n}\nclass GroundStationWhepPlayer{\n  constructor(source,path){this.source=source;this.path=path;this.pc=null;this.stream=null;this.resourceUrl=null;this.etag=null;this.connecting=false;this.lastStats=null;this.badSamples=0;this.lastReconnect=0;this.statsTimer=null;this.retryTimer=null;}\n  endpoint(){return \'http://\'+window.location.hostname+\':8889/\'+encodeURIComponent(this.path)+\'/whep\';}\n  async waitForIce(pc){if(pc.iceGatheringState===\'complete\')return;await new Promise(resolve=>{const timeout=setTimeout(resolve,1800);const handler=()=>{if(pc.iceGatheringState===\'complete\'){clearTimeout(timeout);pc.removeEventListener(\'icegatheringstatechange\',handler);resolve();}};pc.addEventListener(\'icegatheringstatechange\',handler);});}\n  async start(reason=\'startup\'){\n    if(this.connecting)return;\n    this.connecting=true;\n    if(this.retryTimer){clearTimeout(this.retryTimer);this.retryTimer=null;}\n    try{\n      await this.close(true);\n      const pc=new RTCPeerConnection({bundlePolicy:\'max-bundle\'});\n      this.pc=pc;\n      pc.addTransceiver(\'video\',{direction:\'recvonly\'});\n      pc.ontrack=event=>{this.stream=event.streams[0]||new MediaStream([event.track]);applyVideo(false);};\n      pc.onconnectionstatechange=()=>{if(this.source===\'wifilink_rtsp\'&&[\'failed\',\'disconnected\'].includes(pc.connectionState))this.reconnect(\'connection \'+pc.connectionState);};\n      const offer=await pc.createOffer();\n      await pc.setLocalDescription(offer);\n      await this.waitForIce(pc);\n      const response=await fetch(this.endpoint(),{method:\'POST\',headers:{\'Content-Type\':\'application/sdp\'},body:pc.localDescription.sdp});\n      if(!response.ok)throw new Error(\'WHEP HTTP \'+response.status);\n      const location=response.headers.get(\'Location\');\n      this.resourceUrl=location?new URL(location,this.endpoint()).toString():null;\n      this.etag=response.headers.get(\'ETag\');\n      await pc.setRemoteDescription({type:\'answer\',sdp:await response.text()});\n      this.lastStats=null;\n      this.badSamples=0;\n      this.beginStats();\n      if(this.source===\'wifilink_rtsp\')setAirlinkState(\'Air Link: live\',\'\');\n    }catch(error){\n      if(this.source===\'wifilink_rtsp\')setAirlinkState(\'Air Link: \'+error.message,\'bad\');\n      this.retryTimer=setTimeout(()=>this.reconnect(\'retry\'),2500);\n    }finally{this.connecting=false;}\n  }\n  async close(deleteResource=true){\n    if(this.statsTimer){clearInterval(this.statsTimer);this.statsTimer=null;}\n    const resource=this.resourceUrl,etag=this.etag;\n    this.resourceUrl=null;this.etag=null;\n    if(this.pc){try{this.pc.close();}catch(_e){}this.pc=null;}\n    this.stream=null;\n    if(deleteResource&&resource){try{const headers={};if(etag)headers[\'If-Match\']=etag;await fetch(resource,{method:\'DELETE\',headers});}catch(_e){}}\n  }\n  async reconnect(reason=\'manual\'){\n    const now=Date.now();\n    if(this.connecting||now-this.lastReconnect<5000)return;\n    this.lastReconnect=now;\n    if(this.source===\'wifilink_rtsp\'){setAirlinkState(\'Air Link: resyncing…\',\'warn\');$(\'resyncAirlinkBtn\').classList.add(\'resyncing\');}\n    await this.start(reason);\n    if(this.source===\'wifilink_rtsp\')$(\'resyncAirlinkBtn\').classList.remove(\'resyncing\');\n  }\n  async sampleStats(){\n    if(!this.pc||this.pc.connectionState!==\'connected\')return;\n    const stats=await this.pc.getStats();\n    let inbound=null;\n    stats.forEach(report=>{if(report.type===\'inbound-rtp\'&&report.kind===\'video\')inbound=report;});\n    if(!inbound)return;\n    const current={time:performance.now(),framesDecoded:Number(inbound.framesDecoded||0),framesReceived:Number(inbound.framesReceived||0),framesDropped:Number(inbound.framesDropped||0),jitterDelay:Number(inbound.jitterBufferDelay||0),jitterCount:Number(inbound.jitterBufferEmittedCount||0),jitterTarget:Number(inbound.jitterBufferTargetDelay||0),freezeCount:Number(inbound.freezeCount||0),fps:Number(inbound.framesPerSecond||0)};\n    if(this.lastStats){\n      const elapsed=(current.time-this.lastStats.time)/1000;\n      const decoded=current.framesDecoded-this.lastStats.framesDecoded;\n      const received=current.framesReceived-this.lastStats.framesReceived;\n      const emitted=current.jitterCount-this.lastStats.jitterCount;\n      const jitterDelta=current.jitterDelay-this.lastStats.jitterDelay;\n      const targetDelta=current.jitterTarget-this.lastStats.jitterTarget;\n      const measuredFps=current.fps||((elapsed>0)?decoded/elapsed:0);\n      const bufferSeconds=(emitted>0)?jitterDelta/emitted:0;\n      const targetSeconds=(emitted>0)?targetDelta/emitted:0;\n      const backlog=Math.max(0,received-decoded);\n      const froze=current.freezeCount>this.lastStats.freezeCount;\n      if(this.source===\'wifilink_rtsp\'){\n        const shownMs=Math.round(Math.max(bufferSeconds,targetSeconds)*1000);\n        setAirlinkState(\'Air Link: \'+measuredFps.toFixed(0)+\' fps · \'+shownMs+\' ms buffer\',shownMs>550?\'bad\':shownMs>300?\'warn\':\'\');\n        const unhealthy=bufferSeconds>.55||targetSeconds>.55||froze||(received>4&&decoded<2)||backlog>18;\n        if(unhealthy)this.badSamples++;else this.badSamples=Math.max(0,this.badSamples-1);\n        if(this.badSamples>=3&&Date.now()-this.lastReconnect>20000){this.badSamples=0;this.reconnect(\'automatic receiver recovery\');}\n      }\n    }\n    this.lastStats=current;\n  }\n  beginStats(){if(this.statsTimer)clearInterval(this.statsTimer);this.statsTimer=setInterval(()=>this.sampleStats().catch(()=>{}),2000);}\n}\nfunction setAirlinkState(text,level){setText(\'airlinkBufferState\',text);const element=$(\'airlinkBufferState\');if(!element)return;element.classList.remove(\'warn\',\'bad\');if(level)element.classList.add(level);}\nfunction ensurePlayers(){if(!GS.players.siyi_rtsp){GS.players.siyi_rtsp=new GroundStationWhepPlayer(\'siyi_rtsp\',\'gs_siyi\');GS.players.siyi_rtsp.start();}if(!GS.players.wifilink_rtsp){GS.players.wifilink_rtsp=new GroundStationWhepPlayer(\'wifilink_rtsp\',\'gs_wifilink\');GS.players.wifilink_rtsp.start();}}\nfunction setNativeFrame(id,source,active){const video=$(id);if(!video)return;video.style.display=active?\'block\':\'none\';const player=GS.players[source],stream=player&&player.stream;if(active&&stream&&video.srcObject!==stream){video.srcObject=stream;video.play().catch(()=>{});}if(!active&&video.srcObject)video.srcObject=null;}\nfunction applyVideo(force=false){ensurePlayers();if(force){GS.players.siyi_rtsp.reconnect(\'manual all\');GS.players.wifilink_rtsp.reconnect(\'manual all\');}const fullVideo=GS.layout===\'video_dual\'||GS.layout===\'video_map\',dualVideo=GS.layout===\'video_dual\',mapVideo=GS.layout===\'map_video\';setNativeFrame(\'videoFrame\',GS.primarySource,fullVideo);setNativeFrame(\'videoFrameSecondary\',GS.secondarySource,dualVideo);setNativeFrame(\'videoFramePip\',GS.primarySource,mapVideo);updateCameraLabels();}\nfunction normalizeGroundStationLayout(layout){if(layout===\'map\'||layout===\'map_video\')return \'map_video\';if(layout===\'video_map\')return \'video_map\';return \'video_dual\';}\nfunction placeGroundStationMap(layout){const host=$(\'mapHostMain\'),mapView=$(\'mapView\'),mapPipContent=$(\'mapPipContent\'),videoPip=$(\'videoPip\');if(!host||!mapView||!mapPipContent)return;if(layout===\'video_map\'){if(host.parentElement!==mapPipContent)mapPipContent.appendChild(host);}else if(host.parentElement!==mapView){mapView.insertBefore(host,videoPip||null);}}\nfunction setLayout(layout){layout=normalizeGroundStationLayout(layout);GS.layout=layout;placeGroundStationMap(layout);$(\'videoView\').classList.toggle(\'active\',layout===\'video_dual\'||layout===\'video_map\');$(\'mapView\').classList.toggle(\'active\',layout===\'map_video\');$(\'gsApp\').dataset.layoutState=layout;document.querySelectorAll(\'[data-layout]\').forEach(button=>button.classList.toggle(\'active\',(button.dataset.layout===\'map\'&&layout===\'map_video\')||(button.dataset.layout===\'video\'&&layout!==\'map_video\')));applyVideo(false);if(layout===\'map_video\'||layout===\'video_map\')setTimeout(()=>ensureGroundStationMap(),40);requestAnimationFrame(()=>{if(layout===\'map_video\')clampMapVideoPip(false);if(layout===\'video_map\')clampVideoMapPip(false);if((layout===\'map_video\'||layout===\'video_map\')&&GS.map&&GS.mapReady)GS.map.invalidateSize({pan:false,animate:false});});try{localStorage.setItem(\'siyi-groundstation-layout\',layout);}catch(_e){}}\nfunction toggleVideoMap(){const next={video_dual:\'map_video\',map_video:\'video_map\',video_map:\'video_dual\'}[GS.layout]||\'video_dual\';setLayout(next);}\nfunction horizonTransform(roll,pitch){roll=Number(roll)||0;pitch=Math.max(-45,Math.min(45,Number(pitch)||0));return \'translateY(\'+(pitch*3.2)+\'px) rotate(\'+(-roll)+\'deg)\';}\n// GROUNDSTATION_V16_ROUND_HUD_HOME_MARKER\nfunction normalizeDegrees360(value){const n=Number(value);if(!Number.isFinite(n))return null;return ((n%360)+360)%360;}\nfunction updateRoundHudPitchDensity(size){\n  const hud=$(\'roundHud\');\n  if(!hud)return;\n  const pixels=Number(size)||hud.getBoundingClientRect().height||0;\n  hud.dataset.pitchDensity=pixels<126?\'minimal\':pixels<180?\'compact\':\'full\';\n}\nfunction updateRoundHudCompass(heading){\n  const hud=$(\'roundHud\');\n  if(!hud)return;\n  const currentHeading=normalizeDegrees360(heading);\n  const markers=[...hud.querySelectorAll(\'.gs-round-cardinal\')];\n  if(currentHeading===null){markers.forEach(marker=>marker.classList.remove(\'show\'));return;}\n  const size=Math.max(1,hud.getBoundingClientRect().height);\n  const radius=Math.max(22,size*.34);\n  markers.forEach(marker=>{\n    const bearing=normalizeDegrees360(marker.dataset.bearing);\n    if(bearing===null){marker.classList.remove(\'show\');return;}\n    const relative=((bearing-currentHeading+540)%360)-180;\n    const radians=relative*Math.PI/180;\n    marker.style.left=(size/2+Math.sin(radians)*radius)+\'px\';\n    marker.style.top=(size/2-Math.cos(radians)*radius)+\'px\';\n    marker.classList.add(\'show\');\n  });\n}\nfunction updateRoundHudHome(state,heading){\n  const marker=$(\'roundHudHome\'),hud=$(\'roundHud\');\n  if(!marker||!hud)return;\n  const navigation=state.navigation||{};\n  const homeBearing=normalizeDegrees360(navigation.home_bearing_deg);\n  const currentHeading=normalizeDegrees360(heading);\n  if(homeBearing===null||currentHeading===null){marker.classList.remove(\'show\');return;}\n  const size=Math.max(1,hud.getBoundingClientRect().height);\n  const radius=Math.max(18,size*.29);\n  const relative=((homeBearing-currentHeading+540)%360)-180;\n  const radians=relative*Math.PI/180;\n  const x=size/2 + Math.sin(radians)*radius;\n  const y=size/2 - Math.cos(radians)*radius;\n  marker.style.left=x+\'px\';\n  marker.style.top=y+\'px\';\n  marker.classList.add(\'show\');\n}\nfunction updateHud(state){\n  const attitude=state.attitude||{},speed=state.speed||{},position=state.position||{};\n  const roll=(typeof attitude.roll_deg===\'number\'&&Number.isFinite(attitude.roll_deg))?attitude.roll_deg:null;\n  const pitch=(typeof attitude.pitch_deg===\'number\'&&Number.isFinite(attitude.pitch_deg))?attitude.pitch_deg:null;\n  const heading=(typeof attitude.heading_deg===\'number\'&&Number.isFinite(attitude.heading_deg))?attitude.heading_deg:null;\n  const hasAttitude=roll!==null&&pitch!==null;\n  const attitudeAge=state.field_age_s&&Number(state.field_age_s.attitude);\n  const fresh=hasAttitude&&Number.isFinite(attitudeAge)&&attitudeAge<=5;\n  const transform=horizonTransform(roll,pitch);\n  if($(\'mainHorizon\'))$(\'mainHorizon\').style.transform=transform;\n  const round=$(\'roundHorizon\'),roundHud=$(\'roundHud\');\n  if(roundHud){\n    const size=Math.max(1,roundHud.getBoundingClientRect().height);\n    updateRoundHudPitchDensity(size);\n    if(round&&hasAttitude){\n      const pitchPx=Math.max(-size*.42,Math.min(size*.42,pitch*(size/92)));\n      round.style.transform=\'translateY(\'+pitchPx+\'px) rotate(\'+(-roll)+\'deg)\';\n    }\n  }\n  const headingText=(Number.isFinite(heading)?number(heading,0).padStart(3,\'0\'):\'—\')+\'°\';\n  const rollText=Number.isFinite(roll)?number(roll,1)+\'°\':\'—\';\n  const pitchText=Number.isFinite(pitch)?number(pitch,1)+\'°\':\'—\';\n  setText(\'hudHeading\',headingText);\n  updateRoundHudCompass(heading);\n  updateRoundHudHome(state,heading);\n  setText(\'hudRoll\',\'R \'+rollText);\n  setText(\'hudPitch\',\'P \'+pitchText);\n  setText(\'hudAirspeed\',number(kmh(speed.airspeed_m_s),0));\n  setText(\'hudGroundspeed\',number(kmh(speed.groundspeed_m_s),0));\n  setText(\'hudAltitude\',number(position.relative_alt_m,0));\n  setText(\'hudThrottle\',number(speed.throttle_pct,0));\n  setText(\'hudVspeed\',number(speed.vertical_speed_m_s,1));\n  setText(\'hudMode\',\'MONITOR ONLY · \'+((state.vehicle||{}).mode||\'—\'));\n  const lost=$(\'attitudeLost\'),overlay=$(\'attitudeOverlay\'),roundLost=$(\'roundHudLost\');\n  if(lost)lost.classList.toggle(\'show\',!fresh);\n  if(overlay)overlay.classList.toggle(\'stale\',!fresh);\n  if(roundLost)roundLost.classList.toggle(\'show\',!fresh);\n}\nfunction updateTelemetry(_state){telemetryCanvasRender();}\nfunction updateMessages(state){const items=(state.messages||[]).slice(-25).reverse();if(!items.length){$(\'messageList\').innerHTML=\'<div class="gs-message">No vehicle messages received.</div>\';return;}$(\'messageList\').innerHTML=items.map(item=>{const date=new Date((item.ts||0)*1000);return \'<div class="gs-message \'+String(item.severity||\'Info\')+\'"><span class="gs-message-time">\'+date.toLocaleTimeString()+\'</span><b>\'+String(item.severity||\'Info\')+\'</b> \'+escapeHtml(item.text||\'\')+\'</div>\';}).join(\'\');}\nfunction escapeHtml(text){return String(text).replace(/[&<>"\']/g,char=>({\'&\':\'&amp;\',\'<\':\'&lt;\',\'>\':\'&gt;\',\'"\':\'&quot;\',"\'":\'&#39;\'}[char]));}\nfunction updateTop(state){const c=state.connection||{},v=state.vehicle||{},g=state.gps||{},b=state.battery||{},l=state.link||{};setText(\'connState\',c.state||\'NO VEHICLE\');setText(\'heartbeatAge\',typeof c.heartbeat_age_s===\'number\'?c.heartbeat_age_s.toFixed(1)+\'s\':\'—\');const dot=$(\'connDot\');dot.className=\'gs-dot \'+(c.state===\'CONNECTED\'?\'ok\':c.state===\'DEGRADED\'?\'warn\':\'bad\');setText(\'modeValue\',v.mode||\'—\');const modePill=$(\'modePill\');if(modePill)modePill.setAttribute(\'aria-label\',\'Flight mode \'+String(v.mode||\'unknown\')+\'. Select mode\');flightModeUpdateState();setText(\'armedValue\',v.armed===true?\'ARMED\':v.armed===false?\'DISARMED\':\'UNKNOWN\');$(\'armedValue\').style.color=v.armed===true?\'#f87171\':v.armed===false?\'#86efac\':\'#cbd5e1\';armStateUpdateState();updateGpsStatusPill(c,g);setText(\'batteryTop\',number(b.voltage_v,1)+\'V / \'+number(b.remaining_pct,0)+\'%\');setText(\'linkTop\',l.rssi==null?\'—\':\'RSSI \'+l.rssi);setText(\'flightTime\',clock((state.timers||{}).armed_s));let message=\'Monitor-only telemetry\';if(c.multiple_vehicles)message=\'Multiple flight controllers detected — state selection blocked\';else if(c.state===\'NO_VEHICLE\')message=\'Waiting for flight-controller heartbeat\';else if(c.state===\'LINK_LOST\')message=\'Telemetry link lost — last values are stale\';else if(c.state===\'DEGRADED\')message=\'Telemetry degraded — heartbeat age \'+number(c.heartbeat_age_s,1)+\' s\';else message=\'Connected to vehicle \'+c.system_id+\'/\'+c.component_id+\' · \'+(v.mode||\'unknown mode\');setText(\'statusMessage\',message);}\nfunction updateState(state){processFlightAudio(state);GS.state=state;updateTop(state);updateHud(state);updateTelemetry(state);updateMessages(state);drawMaps();}\n// GROUNDSTATION_V18_LEAFLET_PI_TILE_PROXY\nfunction mapSetStatus(text,level=\'\'){\n  document.querySelectorAll(\'.gs-map-status\').forEach(element=>{\n    element.textContent=text;\n    element.classList.remove(\'ok\',\'warn\',\'bad\');\n    if(level)element.classList.add(level);\n  });\n}\nfunction mapUpdateStyleButtons(){\n  document.querySelectorAll(\'[data-map-style]\').forEach(button=>button.classList.toggle(\'active\',button.dataset.mapStyle===GS.mapStyle));\n}\nfunction mapValidCoordinate(value,min,max){const n=Number(value);return Number.isFinite(n)&&n>=min&&n<=max?n:null;}\nfunction mapCoordinate(lat,lon){\n  const y=mapValidCoordinate(lat,-90,90),x=mapValidCoordinate(lon,-180,180);\n  if(y===null||x===null)return null;\n  if(Math.abs(y)<1e-8&&Math.abs(x)<1e-8)return null;\n  return [y,x];\n}\nfunction mapStatePoints(state){\n  const s=state||{},p=s.position||{},n=s.navigation||{};\n  const points=[];\n  const home=mapCoordinate(n.home_lat,n.home_lon),aircraft=mapCoordinate(p.lat,p.lon);\n  if(home)points.push(home);\n  (s.track||[]).forEach(point=>{const q=mapCoordinate(point.lat,point.lon);if(q)points.push(q);});\n  if(aircraft)points.push(aircraft);\n  return points;\n}\nfunction mapActiveHost(){return $(\'mapHostMain\');}\nfunction mapMountElement(){\n  const host=mapActiveHost();\n  if(!host)return null;\n  if(!GS.mapElement){GS.mapElement=document.createElement(\'div\');GS.mapElement.id=\'mapLeafletLive\';GS.mapElement.className=\'gs-map-live\';}\n  if(GS.mapElement.parentElement!==host)host.appendChild(GS.mapElement);\n  if(GS.map)setTimeout(()=>GS.map.invalidateSize({pan:false,animate:false}),0);\n  return GS.mapElement;\n}\nfunction loadLeafletSdk(){\n  if(window.L&&window.L.map)return Promise.resolve(window.L);\n  if(GS.mapSdkPromise)return GS.mapSdkPromise;\n  GS.mapSdkPromise=new Promise((resolve,reject)=>{\n    let css=document.querySelector(\'link[data-siyi-leaflet]\');\n    if(!css){css=document.createElement(\'link\');css.rel=\'stylesheet\';css.href=\'/groundstation/vendor/leaflet.css?v=\'+LEAFLET_VERSION;css.dataset.siyiLeaflet=\'1\';document.head.appendChild(css);}\n    let script=document.querySelector(\'script[data-siyi-leaflet]\');\n    const loaded=()=>window.L&&window.L.map?resolve(window.L):reject(new Error(\'Leaflet did not initialize\'));\n    if(script){\n      if(window.L&&window.L.map)return resolve(window.L);\n      script.addEventListener(\'load\',loaded,{once:true});\n      script.addEventListener(\'error\',()=>reject(new Error(\'Local Leaflet library failed to load\')),{once:true});\n      return;\n    }\n    script=document.createElement(\'script\');\n    script.src=\'/groundstation/vendor/leaflet.js?v=\'+LEAFLET_VERSION;\n    script.async=true;\n    script.dataset.siyiLeaflet=\'1\';\n    script.addEventListener(\'load\',loaded,{once:true});\n    script.addEventListener(\'error\',()=>reject(new Error(\'Local Leaflet library failed to load\')),{once:true});\n    document.head.appendChild(script);\n  }).catch(error=>{GS.mapSdkPromise=null;throw error;});\n  return GS.mapSdkPromise;\n}\nfunction mapAircraftIcon(){\n  return L.divIcon({className:\'gs-map-marker-shell\',iconSize:[30,34],iconAnchor:[15,17],html:\'<div class="gs-map-aircraft-marker"><svg viewBox="0 0 28 32" aria-hidden="true"><path d="M14 1 L25 29 L14 23 L3 29 Z" fill="#fde047" stroke="#020617" stroke-width="2" stroke-linejoin="round"/></svg></div>\'});\n}\nfunction mapHomeIcon(){\n  return L.divIcon({className:\'gs-map-marker-shell\',iconSize:[30,30],iconAnchor:[15,15],html:\'<div class="gs-map-home-marker"><span aria-hidden="true">⌂</span></div>\'});\n}\nfunction mapTileUrl(style){return \'/api/groundstation/maptile/\'+style+\'/{z}/{x}/{y}.jpg\';}\nfunction mapInstallTileLayer(style){\n  if(!GS.map||!window.L)return;\n  if(GS.mapTileLayer){GS.map.removeLayer(GS.mapTileLayer);GS.mapTileLayer=null;}\n  let tileErrors=0;\n  const layer=L.tileLayer(mapTileUrl(style),{\n    minZoom:0,maxZoom:20,maxNativeZoom:20,tileSize:256,keepBuffer:3,updateWhenIdle:false,\n    attribution:\'© MapTiler © OpenStreetMap contributors\'\n  });\n  layer.on(\'loading\',()=>mapSetStatus(\'Loading \'+(style===\'hybrid\'?\'Hybrid\':\'Satellite\')+\' tiles through Pi…\',\'warn\'));\n  layer.on(\'load\',()=>mapSetStatus((style===\'hybrid\'?\'HYBRID\':\'SATELLITE\')+\' · live through Pi\',\'ok\'));\n  layer.on(\'tileerror\',event=>{\n    tileErrors++;\n    const status=event&&event.error&&event.error.status;\n    mapSetStatus(\'Map tile failed\'+(status?\' · HTTP \'+status:\'\')+\' · Pi proxy\',\'bad\');\n  });\n  GS.mapTileLayer=layer.addTo(GS.map);\n}\nfunction mapUpdateTrack(state){\n  if(!GS.map||!GS.mapReady||!window.L)return;\n  const coordinates=(state.track||[]).map(point=>mapCoordinate(point.lat,point.lon)).filter(Boolean);\n  const signature=coordinates.length+\':\'+(coordinates.length?coordinates[coordinates.length-1].join(\',\'):\'\');\n  if(signature===GS.mapTrackSignature)return;\n  GS.mapTrackSignature=signature;\n  if(!GS.mapTrackLine)GS.mapTrackLine=L.polyline([],{color:\'#38bdf8\',weight:3,opacity:.95,lineCap:\'round\',lineJoin:\'round\',interactive:false}).addTo(GS.map);\n  GS.mapTrackLine.setLatLngs(coordinates);\n}\nfunction mapUpdateMarkers(state){\n  if(!GS.map||!GS.mapReady||!window.L)return null;\n  const p=state.position||{},n=state.navigation||{},attitude=state.attitude||{};\n  const aircraft=mapCoordinate(p.lat,p.lon),home=mapCoordinate(n.home_lat,n.home_lon);\n  if(!GS.mapAircraftMarker)GS.mapAircraftMarker=L.marker([0,0],{icon:mapAircraftIcon(),interactive:false,keyboard:false,opacity:0}).addTo(GS.map);\n  if(!GS.mapHomeMarker)GS.mapHomeMarker=L.marker([0,0],{icon:mapHomeIcon(),interactive:false,keyboard:false,opacity:0}).addTo(GS.map);\n  if(aircraft){\n    GS.mapAircraftMarker.setLatLng(aircraft).setOpacity(1);\n    const heading=Number(attitude.heading_deg);\n    const element=GS.mapAircraftMarker.getElement();\n    const icon=element&&element.querySelector(\'.gs-map-aircraft-marker\');\n    if(icon){icon.style.transform=\'rotate(\'+(Number.isFinite(heading)?heading:0)+\'deg)\';icon.classList.toggle(\'stale\',!ageFresh(\'position\',3));}\n  }else GS.mapAircraftMarker.setOpacity(0);\n  if(home)GS.mapHomeMarker.setLatLng(home).setOpacity(1);else GS.mapHomeMarker.setOpacity(0);\n  return aircraft;\n}\nfunction mapUpdateFollow(aircraft){\n  if(!GS.map||!GS.mapReady||!aircraft)return;\n  if(!GS.mapInitialPosition){GS.mapInitialPosition=true;GS.map.setView(aircraft,Math.max(15,GS.map.getZoom()),{animate:false});return;}\n  const now=Date.now();\n  if(GS.mapFollow&&now-GS.mapLastFollowAt>=700){GS.mapLastFollowAt=now;GS.map.panTo(aircraft,{animate:true,duration:.3,noMoveStart:true});}\n}\nfunction updateGroundStationMap(state){\n  if(!GS.map||!GS.mapReady||!state)return;\n  mapUpdateTrack(state);\n  const aircraft=mapUpdateMarkers(state);\n  mapUpdateFollow(aircraft);\n}\nfunction mapApplyStyle(style){\n  const normalized=style===\'satellite\'?\'satellite\':\'hybrid\';\n  GS.mapStyle=normalized;\n  mapUpdateStyleButtons();\n  try{localStorage.setItem(MAPTILER_STYLE_KEY,normalized);}catch(_e){}\n  if(GS.map&&window.L){mapSetStatus(\'Switching to \'+(normalized===\'hybrid\'?\'Hybrid\':\'Satellite\')+\'…\',\'warn\');mapInstallTileLayer(normalized);}\n}\nfunction mapFitAll(){\n  if(!GS.map||!GS.mapReady||!window.L)return;\n  const points=mapStatePoints(GS.state);\n  GS.mapFollow=false;\n  if(!points.length){GS.map.setView([62,15],5,{animate:true});return;}\n  if(points.length===1){GS.map.setView(points[0],16,{animate:true});return;}\n  GS.map.fitBounds(L.latLngBounds(points),{padding:[55,55],maxZoom:17,animate:true,duration:.5});\n}\nfunction mapFollowAircraft(){\n  GS.mapFollow=true;\n  if(!GS.map||!GS.mapReady)return;\n  const p=(GS.state&&GS.state.position)||{},aircraft=mapCoordinate(p.lat,p.lon);\n  if(aircraft)GS.map.setView(aircraft,Math.max(14,GS.map.getZoom()),{animate:true});\n}\nasync function ensureGroundStationMap(){\n  if(GS.layout!==\'map_video\'&&GS.layout!==\'video_map\')return;\n  const container=mapMountElement();\n  mapUpdateStyleButtons();\n  if(GS.map){GS.map.invalidateSize({pan:false,animate:false});updateGroundStationMap(GS.state);return;}\n  mapSetStatus(\'Loading local map engine…\',\'warn\');\n  try{\n    const leaflet=await loadLeafletSdk();\n    if(GS.layout!==\'map_video\'&&GS.layout!==\'video_map\')return;\n    mapMountElement();\n    try{const saved=localStorage.getItem(MAPTILER_STYLE_KEY);if(saved===\'satellite\'||saved===\'hybrid\')GS.mapStyle=saved;}catch(_e){}\n    mapUpdateStyleButtons();\n    GS.map=leaflet.map(container,{zoomControl:false,attributionControl:true,preferCanvas:true,zoomAnimation:true,fadeAnimation:false,markerZoomAnimation:false,worldCopyJump:false,maxBoundsViscosity:.2}).setView([62,15],5);\n    GS.mapReady=true;\n    mapInstallTileLayer(GS.mapStyle);\n    GS.map.on(\'dragstart\',()=>{GS.mapFollow=false;});\n    GS.map.on(\'zoomstart\',()=>{});\n    setTimeout(()=>GS.map.invalidateSize({pan:false,animate:false}),50);\n    updateGroundStationMap(GS.state);\n  }catch(error){mapSetStatus(\'Map unavailable: \'+String(error&&error.message||error),\'bad\');}\n}\nfunction drawMaps(){if(GS.map&&GS.mapReady)updateGroundStationMap(GS.state);}\n// GROUND_STATION_DUAL_VIDEO_AUDIO_V3\nfunction sourceLabel(source){return GS.sourceNames[source]||({siyi_rtsp:\'SIYI\',wifilink_rtsp:\'Air Link\'}[source])||source||\'Video\';}\nfunction updateCameraLabels(){const primary=sourceLabel(GS.primarySource),secondary=sourceLabel(GS.secondarySource);setText(\'videoSourceName\',primary);setText(\'secondaryVideoLabel\',secondary+\' — TAP TO SWAP\');setText(\'mapVideoLabel\',primary+\' — TAP FOR VIDEO + MAP PIP\');setText(\'dualVideoSummary\',\'Primary: \'+primary+\' · PiP: \'+secondary);}\nfunction swapCameras(){const previous=GS.primarySource;GS.primarySource=GS.secondarySource;GS.secondarySource=previous;updateCameraLabels();applyVideo(false);try{localStorage.setItem(\'siyi-groundstation-primary-camera\',GS.primarySource);}catch(_e){}}\nasync function refreshVideoSource(){\n  try{\n    const response=await fetch(\'/video_source_status?ts=\'+Date.now(),{cache:\'no-store\'});\n    if(!response.ok)return;\n    const data=await response.json();\n    GS.sourceNames=data.source_names||GS.sourceNames;\n    updateCameraLabels();\n  }catch(_e){}\n}\nlet GS_UI_EVENT_STREAM=null;\nlet GS_UI_EVENT_FALLBACK_TIMER=0;\nfunction applyGroundStationUiEvent(event){\n  const eventId=String(event&&event.event_id||\'\');\n  if(!eventId)return;\n  if(GS.lastUiEventId===null){GS.lastUiEventId=eventId;return;}\n  if(eventId===GS.lastUiEventId)return;\n  GS.lastUiEventId=eventId;\n  if(event.action===\'swap_cameras\')swapCameras();\n  else if(event.action===\'toggle_pip_minimized\')toggleActivePipMinimized();\n  else if(event.action===\'toggle_video_map\')toggleVideoMap();\n  else if(event.action===\'toggle_telemetry\')toggleInstruments();\n}\nasync function refreshGroundStationUiEvents(){\n  try{\n    const response=await fetch(\'/api/groundstation/ui-events?ts=\'+Date.now(),{cache:\'no-store\'});\n    if(!response.ok)return;\n    applyGroundStationUiEvent(await response.json());\n  }catch(_e){}\n}\nfunction startGroundStationUiEventFallback(){\n  if(GS_UI_EVENT_FALLBACK_TIMER)return;\n  refreshGroundStationUiEvents();\n  GS_UI_EVENT_FALLBACK_TIMER=setInterval(refreshGroundStationUiEvents,250);\n}\nfunction stopGroundStationUiEventFallback(){\n  if(!GS_UI_EVENT_FALLBACK_TIMER)return;\n  clearInterval(GS_UI_EVENT_FALLBACK_TIMER);\n  GS_UI_EVENT_FALLBACK_TIMER=0;\n}\nfunction connectGroundStationUiEvents(){\n  if(!(\'EventSource\' in window)){\n    startGroundStationUiEventFallback();return;}\n  if(GS_UI_EVENT_STREAM)GS_UI_EVENT_STREAM.close();\n  const events=new EventSource(\'/api/groundstation/ui-events/stream?ts=\'+Date.now());\n  GS_UI_EVENT_STREAM=events;\n  let opened=false;\n  const fallbackDelay=setTimeout(()=>{\n    if(!opened)startGroundStationUiEventFallback();\n  },700);\n  events.onopen=()=>{\n    opened=true;clearTimeout(fallbackDelay);stopGroundStationUiEventFallback();};\n  events.onmessage=message=>{\n    try{applyGroundStationUiEvent(JSON.parse(message.data||\'{}\'));}catch(_e){}};\n  events.onerror=()=>{\n    if(!opened)startGroundStationUiEventFallback();\n    else setTimeout(()=>{\n      if(events.readyState!==EventSource.OPEN)startGroundStationUiEventFallback();\n    },700);};\n}\nasync function refreshGroundStationVoiceEvent(){\n  try{\n    const response=await fetch(\'/api/groundstation/voice-event?ts=\'+Date.now(),{cache:\'no-store\'});\n    if(!response.ok)return;\n    const event=await response.json();\n    const eventId=String(event.event_id||\'\');\n    const text=String(event.text||\'\').trim();\n    if(!eventId||!text)return;\n    if(GS.lastVoiceEventId===null){GS.lastVoiceEventId=eventId;return;}\n    if(eventId===GS.lastVoiceEventId)return;\n    GS.lastVoiceEventId=eventId;\n    const upper=text.toUpperCase();\n    if(upper===\'REC STARTED\'||upper===\'REC STOPPED\')return;\n    const urgent=upper.startsWith(\'SAFETY BLOCK:\')||upper.includes(\'LOW BATTERY\')||upper.includes(\'BATTERY CRITICAL\');\n    speakFlight(flightMessageText(text),\'notice-\'+text.toLowerCase(),false,urgent);\n  }catch(_e){}\n}\nfunction applyRecordingState(active,announce){\n  active=Boolean(active);\n  const previous=GS.recording;\n  GS.recording=active;\n  const chip=$(\'recordingChip\');\n  if(chip){chip.classList.toggle(\'active\',active);chip.setAttribute(\'aria-label\',active?\'Camera recording active\':\'Camera recording stopped\');}\n  if(announce&&previous!==null&&previous!==active)speakFlight(active?\'Recording started\':\'Recording stopped\',\'recording-state\',true,true);\n}\nasync function refreshRecordingState(){\n  try{\n    const response=await fetch(\'/api/groundstation/recording-state?ts=\'+Date.now(),{cache:\'no-store\'});\n    if(!response.ok)return;\n    const state=await response.json();\n    applyRecordingState(Boolean(state.recording),GS.recording!==null);\n  }catch(_e){}\n}\n\n/* GROUND_STATION_FLY_VIEW_GEOMETRY_V2_8_20_PLATFORM_PROFILES */\nconst GS_FLY_VIEW_PLATFORM_PROFILE=\n  isPhoneGroundStationHost()?\'phone\':\'desktop\';\nfunction groundStationPlatformStorageKey(baseKey){\n  const base=String(baseKey||\'\');\n  const scoped=base+\'--\'+GS_FLY_VIEW_PLATFORM_PROFILE;\n  try{\n    if(localStorage.getItem(scoped)===null){\n      const legacy=localStorage.getItem(base);\n      if(legacy!==null)localStorage.setItem(scoped,legacy);\n    }\n  }catch(_error){}\n  return scoped;\n}\nconst GS_HUD_MODE_KEY=\'siyi-groundstation-hud-mode-v11\';\nconst GS_ROUND_HUD_GEOMETRY_KEY=groundStationPlatformStorageKey(\'siyi-groundstation-round-hud-geometry-v12-exact-local\');\nfunction applyHudMode(mode,save=true){\n  if(![\'full\',\'round\',\'off\'].includes(mode))mode=\'full\';\n  GS.hudMode=mode;\n  const full=$(\'hud\'),round=$(\'roundHud\'),button=$(\'hudBtn\');\n  if(full)full.style.display=mode===\'full\'?\'block\':\'none\';\n  if(round)round.classList.toggle(\'show\',mode===\'round\');\n  if(button){setTopBannerToggleState(button,mode!==\'off\',\'HUD\');button.title=mode===\'full\'?\'HUD on — full\':mode===\'round\'?\'HUD on — round\':\'HUD off\';button.dataset.hudMode=mode;}\n  if(save){try{localStorage.setItem(GS_HUD_MODE_KEY,mode);}catch(_e){}}\n  if(mode===\'round\')requestAnimationFrame(()=>clampRoundHud(false));\n}\nfunction cycleHudMode(){const order=[\'full\',\'round\',\'off\'];applyHudMode(order[(order.indexOf(GS.hudMode)+1)%order.length]);}\nfunction roundHudParent(){return $(\'videoView\');}\nfunction saveRoundHudGeometry(){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,true);return;}\nconst hud=$(\'roundHud\');\nif(!hud||GS_VIEWPORT_TRANSITION_STATE.active)return;\nconst record=overlayGeometryRecord(\'roundHud\',hud);\nif(!record)return;\ntry{localStorage.setItem(GS_ROUND_HUD_GEOMETRY_KEY,JSON.stringify(record));}\ncatch(_error){}\nTELEMETRY_CANVAS.overlayGeometry.roundHud=record;\ntelemetryRememberOverlayGeometry(\'roundHud\',hud,true);}\nfunction clampRoundHud(save=false){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,Boolean(save));return;}\nconst hud=$(\'roundHud\');\nif(!hud||GS_VIEWPORT_TRANSITION_STATE.active)return;\nconst bounds=overlayElementBounds(hud),local=overlayElementLocalRect(hud),\nminSize=80,maxSize=Math.max(minSize,\nMath.min(bounds.right-bounds.left,bounds.bottom-bounds.top)*.72),\nsize=Math.max(minSize,Math.min(local.width,maxSize)),\nleft=Number.isFinite(parseFloat(hud.style.left))?parseFloat(hud.style.left):local.left,\ntop=Number.isFinite(parseFloat(hud.style.top))?parseFloat(hud.style.top):local.top,\nsnapped=stickyOverlayRect(left,top,size,size,bounds);\nhud.style.width=snapped.width+\'px\';hud.style.height=snapped.height+\'px\';\nhud.style.left=snapped.left+\'px\';hud.style.top=snapped.top+\'px\';\nif(save)saveRoundHudGeometry();}\nfunction restoreRoundHudGeometry(){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return;}\nconst hud=$(\'roundHud\');if(!hud)return;\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingRestore=true;return;}\nlet restored=telemetryRestoreOverlayGeometry(\'roundHud\',hud);\nif(!restored){\ntry{\nconst saved=JSON.parse(localStorage.getItem(GS_ROUND_HUD_GEOMETRY_KEY)||\'null\');\nif(saved&&Number(saved.v)===2&&\n[saved.x,saved.y,saved.w,saved.h].every(value=>Number.isFinite(Number(value)))){\nrestored=applyOverlayGeometryRecord(hud,saved);\nif(restored)TELEMETRY_CANVAS.overlayGeometry.roundHud={k:\'roundHud\',...saved};\n}}catch(_error){}}\nrequestAnimationFrame(()=>clampRoundHud(false));}\nfunction initRoundHud(){\nconst hud=$(\'roundHud\'),face=$(\'roundHudFace\');if(!hud||!face)return;\nconst handles=[...hud.querySelectorAll(\'[data-round-corner]\')];let action=null;\nconst start=(event,type,corner=\'se\')=>{\nif(!groundStationGeometryViewportUsable()||GS_VIEWPORT_TRANSITION_STATE.active||\n(event.button!==undefined&&event.button!==0))return;\nconst rect=overlayElementLocalRect(hud);\naction={id:event.pointerId,type,corner,startX:event.clientX,startY:event.clientY,\nleft:rect.left,top:rect.top,size:rect.width,\nright:rect.left+rect.width,bottom:rect.top+rect.height};\nhud.classList.add(type===\'move\'?\'dragging\':\'resizing\');\ntry{hud.setPointerCapture(event.pointerId);}catch(_e){}\nevent.stopPropagation();event.preventDefault();};\nface.addEventListener(\'pointerdown\',event=>start(event,\'move\'));\nhandles.forEach(handle=>handle.addEventListener(\'pointerdown\',event=>\nstart(event,\'resize\',handle.dataset.roundCorner||\'se\')));\nhud.addEventListener(\'pointermove\',event=>{\nif(!action||event.pointerId!==action.id)return;\nconst bounds=overlayElementBounds(hud),dx=event.clientX-action.startX,\ndy=event.clientY-action.startY;\nif(action.type===\'move\'){\nconst snapped=stickyOverlayRect(\naction.left+dx,action.top+dy,action.size,action.size,bounds);\nhud.style.left=snapped.left+\'px\';hud.style.top=snapped.top+\'px\';\n}else{\nlet size=action.size,left=action.left,top=action.top;\nconst delta=action.corner===\'se\'?Math.max(dx,dy):\naction.corner===\'nw\'?Math.max(-dx,-dy):\naction.corner===\'ne\'?Math.max(dx,-dy):Math.max(-dx,dy);\nsize=Math.max(80,Math.min(action.size+delta,\nMath.min(bounds.right-bounds.left,bounds.bottom-bounds.top)*.72));\nif(action.corner.includes(\'w\'))left=action.right-size;\nif(action.corner.includes(\'n\'))top=action.bottom-size;\nconst snapped=stickyOverlayRect(left,top,size,size,bounds);\nhud.style.width=snapped.width+\'px\';hud.style.height=snapped.height+\'px\';\nhud.style.left=snapped.left+\'px\';hud.style.top=snapped.top+\'px\';}\nevent.preventDefault();});\nconst finish=event=>{\nif(!action||event.pointerId!==action.id)return;\ntry{hud.releasePointerCapture(event.pointerId);}catch(_e){}\naction=null;hud.classList.remove(\'dragging\',\'resizing\');\nclampRoundHud(true);event.preventDefault();};\nhud.addEventListener(\'pointerup\',finish);\nhud.addEventListener(\'pointercancel\',finish);\nrestoreRoundHudGeometry();\nwindow.addEventListener(\'resize\',()=>clampRoundHud(false));}\nconst GS_PIP_GEOMETRY_KEY=groundStationPlatformStorageKey(\'siyi-groundstation-pip-geometry-v8-exact-local\');\nfunction pipBounds(pip){\nconst bounds=overlayElementBounds(pip);\nreturn{...bounds,width:pip.offsetWidth,height:pip.offsetHeight,\navailableWidth:Math.max(1,bounds.right-bounds.left),\navailableHeight:Math.max(1,bounds.bottom-bounds.top)};}\nfunction savePipGeometry(){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,true);return;}\nconst pip=$(\'cameraPip\');if(!pip||GS_VIEWPORT_TRANSITION_STATE.active)return;\nconst record=overlayGeometryRecord(\'cameraPip\',pip);\nif(!record)return;\ntry{\nlocalStorage.setItem(GS_PIP_GEOMETRY_KEY,JSON.stringify(record));\n}catch(_error){}\nTELEMETRY_CANVAS.overlayGeometry.cameraPip=record;\ntelemetryRememberOverlayGeometry(\'cameraPip\',pip,true);}\nfunction clampPipPosition(save=false){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,Boolean(save));return;}\nconst pip=$(\'cameraPip\');if(!pip||GS_VIEWPORT_TRANSITION_STATE.active)return;\nconst bounds=pipBounds(pip),phone=window.matchMedia(\n\'(max-width:760px), (max-height:560px)\').matches,\nminWidth=phone?110:120,minHeight=phone?68:76,\nmaxWidth=Math.max(minWidth,Math.min(bounds.availableWidth*.72,bounds.availableWidth)),\nmaxHeight=Math.max(minHeight,Math.min(bounds.availableHeight*.72,bounds.availableHeight)),\nlocal=overlayElementLocalRect(pip);\nlet width=Math.max(minWidth,Math.min(local.width,maxWidth)),\nheight=Math.max(minHeight,Math.min(local.height,maxHeight)),\nleft=Number.isFinite(parseFloat(pip.style.left))?parseFloat(pip.style.left):local.left,\ntop=Number.isFinite(parseFloat(pip.style.top))?parseFloat(pip.style.top):local.top;\nconst snapped=stickyOverlayRect(left,top,width,height,bounds);\npip.style.right=\'auto\';pip.style.bottom=\'auto\';\npip.style.left=snapped.left+\'px\';pip.style.top=snapped.top+\'px\';\npip.style.width=snapped.width+\'px\';pip.style.height=snapped.height+\'px\';\nif(save)savePipGeometry();}\nfunction restorePipPosition(){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return;}\nconst pip=$(\'cameraPip\');if(!pip)return;\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingRestore=true;return;}\nlet restored=telemetryRestoreOverlayGeometry(\'cameraPip\',pip);\nif(!restored){\ntry{\nconst saved=JSON.parse(localStorage.getItem(GS_PIP_GEOMETRY_KEY)||\'null\');\nif(saved&&Number(saved.v)===2&&\n[saved.x,saved.y,saved.w,saved.h].every(value=>Number.isFinite(Number(value)))){\nrestored=applyOverlayGeometryRecord(pip,saved);\nif(restored)TELEMETRY_CANVAS.overlayGeometry.cameraPip={k:\'cameraPip\',...saved};\n}}catch(_error){}}\nrequestAnimationFrame(()=>clampPipPosition(false));}\n\nconst GS_PIP_MINIMIZED_KEY=groundStationPlatformStorageKey(\'siyi-groundstation-pip-minimized-v9\');\n\nfunction pipIsMinimized(){\n  const pip=$(\'cameraPip\');\n  return Boolean(pip&&pip.classList.contains(\'pip-minimized\'));\n}\n\nfunction setPipMinimized(minimized){\n  const pip=$(\'cameraPip\');\n  if(!pip)return;\n  if(minimized){\n    savePipGeometry();\n    pip.classList.add(\'pip-minimized\');\n    pip.setAttribute(\'aria-label\',\'Minimized second camera. Tap to restore.\');\n  }else{\n    pip.classList.remove(\'pip-minimized\');\n    pip.removeAttribute(\'aria-label\');\n    restorePipPosition();\n  }\n  try{localStorage.setItem(GS_PIP_MINIMIZED_KEY,minimized?\'1\':\'0\');}catch(_error){}\n}\n\nfunction restorePipMinimizedState(){\n  let minimized=false;\n  try{minimized=localStorage.getItem(GS_PIP_MINIMIZED_KEY)===\'1\';}catch(_error){}\n  if(minimized)setPipMinimized(true);\n}\n\n\nconst GS_MAP_VIDEO_PIP_GEOMETRY_KEY=groundStationPlatformStorageKey(\'siyi-groundstation-map-video-pip-geometry-v21-exact-local\');\nconst GS_MAP_VIDEO_PIP_MINIMIZED_KEY=groundStationPlatformStorageKey(\'siyi-groundstation-map-video-pip-minimized-v20\');\nfunction mapVideoPipIsMinimized(){const pip=$(\'videoPip\');return Boolean(pip&&pip.classList.contains(\'pip-minimized\'));}\nfunction setMapVideoPipMinimized(minimized){const pip=$(\'videoPip\');if(!pip)return;if(minimized){saveMapVideoPipGeometry();pip.classList.add(\'pip-minimized\');}else{pip.classList.remove(\'pip-minimized\');restoreMapVideoPipGeometry();}try{localStorage.setItem(GS_MAP_VIDEO_PIP_MINIMIZED_KEY,minimized?\'1\':\'0\');}catch(_error){}}\nfunction saveMapVideoPipGeometry(){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,true);return;}\nconst pip=$(\'videoPip\');\nif(!pip||mapVideoPipIsMinimized()||GS_VIEWPORT_TRANSITION_STATE.active)return;\nconst record=overlayGeometryRecord(\'mapVideoPip\',pip);\nif(!record)return;\ntry{localStorage.setItem(GS_MAP_VIDEO_PIP_GEOMETRY_KEY,JSON.stringify(record));}\ncatch(_error){}\nTELEMETRY_CANVAS.overlayGeometry.mapVideoPip=record;\ntelemetryRememberOverlayGeometry(\'mapVideoPip\',pip,true);}\nfunction clampMapVideoPip(save=false){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,Boolean(save));return;}\nconst pip=$(\'videoPip\');\nif(!pip||mapVideoPipIsMinimized()||GS_VIEWPORT_TRANSITION_STATE.active)return;\nconst limits=pipBounds(pip),phone=window.matchMedia(\n\'(max-width:760px), (max-height:560px)\').matches,\nminWidth=phone?110:140,minHeight=phone?68:86,\nmaxWidth=Math.max(minWidth,Math.min(limits.availableWidth*.82,limits.availableWidth)),\nmaxHeight=Math.max(minHeight,Math.min(limits.availableHeight*.82,limits.availableHeight)),\nlocal=overlayElementLocalRect(pip);\nlet width=Math.max(minWidth,Math.min(local.width,maxWidth)),\nheight=Math.max(minHeight,Math.min(local.height,maxHeight)),\nleft=Number.isFinite(parseFloat(pip.style.left))?parseFloat(pip.style.left):local.left,\ntop=Number.isFinite(parseFloat(pip.style.top))?parseFloat(pip.style.top):local.top;\nconst snapped=stickyOverlayRect(left,top,width,height,limits);\npip.style.right=\'auto\';pip.style.bottom=\'auto\';\npip.style.left=snapped.left+\'px\';pip.style.top=snapped.top+\'px\';\npip.style.width=snapped.width+\'px\';pip.style.height=snapped.height+\'px\';\nif(save)saveMapVideoPipGeometry();}\nfunction restoreMapVideoPipGeometry(){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return;}\nconst pip=$(\'videoPip\');if(!pip)return;\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingRestore=true;return;}\nlet restored=telemetryRestoreOverlayGeometry(\'mapVideoPip\',pip);\nif(!restored){\ntry{\nconst saved=JSON.parse(localStorage.getItem(\nGS_MAP_VIDEO_PIP_GEOMETRY_KEY)||\'null\');\nif(saved&&Number(saved.v)===2&&\n[saved.x,saved.y,saved.w,saved.h].every(value=>Number.isFinite(Number(value)))){\nrestored=applyOverlayGeometryRecord(pip,saved);\nif(restored)TELEMETRY_CANVAS.overlayGeometry.mapVideoPip={k:\'mapVideoPip\',...saved};\n}}catch(_error){}}\nif(restored&&!mapVideoPipIsMinimized())requestAnimationFrame(()=>{\nif(GS.layout===\'map_video\')clampMapVideoPip(false);});}\nfunction initMapVideoPip(){\nconst pip=$(\'videoPip\'),restoreButton=$(\'videoPipRestoreButton\');if(!pip)return;\nconst handles=[...pip.querySelectorAll(\'[data-map-pip-corner]\')];let action=null;\nconst setLocal=rect=>{\npip.style.right=\'auto\';pip.style.bottom=\'auto\';\npip.style.left=rect.left+\'px\';pip.style.top=rect.top+\'px\';\npip.style.width=rect.width+\'px\';pip.style.height=rect.height+\'px\';};\nconst finish=event=>{\nif(!action||event.pointerId!==action.id)return;\nconst wasTap=action.type===\'pending\'&&!action.moved&&Date.now()-action.started<650;\ntry{pip.releasePointerCapture(event.pointerId);}catch(_error){}\npip.classList.remove(\'dragging\',\'resizing\');\nconst changed=action.type===\'move\'||action.type===\'resize\';action=null;\nif(changed)clampMapVideoPip(true);if(wasTap)setLayout(\'video_map\');\nevent.preventDefault();};\nhandles.forEach(handle=>handle.addEventListener(\'pointerdown\',event=>{\nif(!groundStationGeometryViewportUsable()||GS_VIEWPORT_TRANSITION_STATE.active||mapVideoPipIsMinimized()||\n(event.button!==undefined&&event.button!==0))return;\nconst rect=overlayElementLocalRect(pip);\naction={type:\'resize\',corner:handle.dataset.mapPipCorner||\'se\',\nid:event.pointerId,startX:event.clientX,startY:event.clientY,\nleft:rect.left,top:rect.top,right:rect.left+rect.width,\nbottom:rect.top+rect.height,moved:true,started:Date.now()};\nsetLocal(rect);pip.classList.add(\'resizing\');\ntry{pip.setPointerCapture(event.pointerId);}catch(_error){}\nevent.stopPropagation();event.preventDefault();}));\nif(restoreButton){\nrestoreButton.addEventListener(\'pointerdown\',event=>event.stopPropagation());\nrestoreButton.addEventListener(\'click\',event=>{\nevent.stopPropagation();setMapVideoPipMinimized(false);});}\npip.addEventListener(\'pointerdown\',event=>{\nif(!groundStationGeometryViewportUsable()||GS_VIEWPORT_TRANSITION_STATE.active||mapVideoPipIsMinimized()||\n(event.target.closest&&event.target.closest(\n\'[data-map-pip-corner],.gs-pip-edge-button\'))||\n(event.button!==undefined&&event.button!==0))return;\nconst rect=overlayElementLocalRect(pip);\naction={type:\'pending\',id:event.pointerId,startX:event.clientX,startY:event.clientY,\nleft:rect.left,top:rect.top,width:rect.width,height:rect.height,\nmoved:false,started:Date.now()};\ntry{pip.setPointerCapture(event.pointerId);}catch(_error){}\nevent.preventDefault();});\npip.addEventListener(\'pointermove\',event=>{\nif(!action||event.pointerId!==action.id)return;\nlet dx=event.clientX-action.startX,dy=event.clientY-action.startY;\nif(action.type===\'pending\'&&Math.hypot(dx,dy)>8){\nconst rect=overlayElementLocalRect(pip);\naction.type=\'move\';action.moved=true;action.left=rect.left;action.top=rect.top;\naction.width=rect.width;action.height=rect.height;\naction.startX=event.clientX;action.startY=event.clientY;\nsetLocal(rect);pip.classList.add(\'dragging\');return;}\nif(action.type===\'pending\')return;\nconst limits=pipBounds(pip),phone=window.matchMedia(\n\'(max-width:760px), (max-height:560px)\').matches,\nminWidth=phone?110:140,minHeight=phone?68:86,\nmaxWidth=Math.max(minWidth,Math.min(limits.availableWidth*.82,limits.availableWidth)),\nmaxHeight=Math.max(minHeight,Math.min(limits.availableHeight*.82,limits.availableHeight));\nif(action.type===\'resize\'){\nlet left=action.left,top=action.top,right=action.right,bottom=action.bottom,\ncorner=action.corner;\nif(corner.includes(\'w\'))left=Math.max(limits.left,Math.min(action.left+dx,right-minWidth));\nif(corner.includes(\'e\'))right=Math.min(limits.right,Math.max(action.right+dx,left+minWidth));\nif(corner.includes(\'n\'))top=Math.max(limits.top,Math.min(action.top+dy,bottom-minHeight));\nif(corner.includes(\'s\'))bottom=Math.min(limits.bottom,Math.max(action.bottom+dy,top+minHeight));\nif(right-left>maxWidth){if(corner.includes(\'w\'))left=right-maxWidth;else right=left+maxWidth;}\nif(bottom-top>maxHeight){if(corner.includes(\'n\'))top=bottom-maxHeight;else bottom=top+maxHeight;}\npip.style.left=left+\'px\';pip.style.top=top+\'px\';\npip.style.width=(right-left)+\'px\';pip.style.height=(bottom-top)+\'px\';\n}else{\nconst snapped=stickyOverlayRect(\naction.left+(event.clientX-action.startX),\naction.top+(event.clientY-action.startY),\naction.width,action.height,limits);\npip.style.left=snapped.left+\'px\';pip.style.top=snapped.top+\'px\';}\nevent.preventDefault();});\npip.addEventListener(\'pointerup\',finish);pip.addEventListener(\'pointercancel\',finish);\nrestoreMapVideoPipGeometry();\ntry{if(localStorage.getItem(GS_MAP_VIDEO_PIP_MINIMIZED_KEY)===\'1\')\nsetMapVideoPipMinimized(true);}catch(_error){}\nwindow.addEventListener(\'resize\',()=>{\nif(GS.layout===\'map_video\')clampMapVideoPip(false);},{passive:true});}\n\nconst GS_VIDEO_MAP_PIP_GEOMETRY_KEY=groundStationPlatformStorageKey(\'siyi-groundstation-video-map-pip-geometry-v21-exact-local\');\nconst GS_VIDEO_MAP_PIP_MINIMIZED_KEY=groundStationPlatformStorageKey(\'siyi-groundstation-video-map-pip-minimized-v20\');\nfunction videoMapPipIsMinimized(){const pip=$(\'mapPip\');return Boolean(pip&&pip.classList.contains(\'pip-minimized\'));}\nfunction setVideoMapPipMinimized(minimized){const pip=$(\'mapPip\');if(!pip)return;if(minimized){saveVideoMapPipGeometry();pip.classList.add(\'pip-minimized\');}else{pip.classList.remove(\'pip-minimized\');restoreVideoMapPipGeometry();if(GS.map&&GS.mapReady)setTimeout(()=>GS.map.invalidateSize({pan:false,animate:false}),0);}try{localStorage.setItem(GS_VIDEO_MAP_PIP_MINIMIZED_KEY,minimized?\'1\':\'0\');}catch(_error){}}\nfunction saveVideoMapPipGeometry(){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,true);return;}\nconst pip=$(\'mapPip\');\nif(!pip||videoMapPipIsMinimized()||GS_VIEWPORT_TRANSITION_STATE.active)return;\nconst record=overlayGeometryRecord(\'videoMapPip\',pip);\nif(!record)return;\ntry{localStorage.setItem(GS_VIDEO_MAP_PIP_GEOMETRY_KEY,JSON.stringify(record));}\ncatch(_error){}\nTELEMETRY_CANVAS.overlayGeometry.videoMapPip=record;\ntelemetryRememberOverlayGeometry(\'videoMapPip\',pip,true);}\nfunction clampVideoMapPip(save=false){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,Boolean(save));return;}\nconst pip=$(\'mapPip\');\nif(!pip||videoMapPipIsMinimized()||GS_VIEWPORT_TRANSITION_STATE.active)return;\nconst limits=pipBounds(pip),phone=window.matchMedia(\n\'(max-width:760px), (max-height:560px)\').matches,\nminWidth=phone?120:160,minHeight=phone?78:100,\nmaxWidth=Math.max(minWidth,Math.min(limits.availableWidth*.82,limits.availableWidth)),\nmaxHeight=Math.max(minHeight,Math.min(limits.availableHeight*.82,limits.availableHeight)),\nlocal=overlayElementLocalRect(pip);\nlet width=Math.max(minWidth,Math.min(local.width,maxWidth)),\nheight=Math.max(minHeight,Math.min(local.height,maxHeight)),\nleft=Number.isFinite(parseFloat(pip.style.left))?parseFloat(pip.style.left):local.left,\ntop=Number.isFinite(parseFloat(pip.style.top))?parseFloat(pip.style.top):local.top;\nconst snapped=stickyOverlayRect(left,top,width,height,limits);\npip.style.right=\'auto\';pip.style.bottom=\'auto\';\npip.style.left=snapped.left+\'px\';pip.style.top=snapped.top+\'px\';\npip.style.width=snapped.width+\'px\';pip.style.height=snapped.height+\'px\';\nif(save)saveVideoMapPipGeometry();\nif(GS.map&&GS.mapReady)setTimeout(()=>\nGS.map.invalidateSize({pan:false,animate:false}),0);}\nfunction restoreVideoMapPipGeometry(){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return;}\nconst pip=$(\'mapPip\');if(!pip)return;\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingRestore=true;return;}\nlet restored=telemetryRestoreOverlayGeometry(\'videoMapPip\',pip);\nif(!restored){\ntry{\nconst saved=JSON.parse(localStorage.getItem(\nGS_VIDEO_MAP_PIP_GEOMETRY_KEY)||\'null\');\nif(saved&&Number(saved.v)===2&&\n[saved.x,saved.y,saved.w,saved.h].every(value=>Number.isFinite(Number(value)))){\nrestored=applyOverlayGeometryRecord(pip,saved);\nif(restored)TELEMETRY_CANVAS.overlayGeometry.videoMapPip={k:\'videoMapPip\',...saved};\n}}catch(_error){}}\nif(restored&&!videoMapPipIsMinimized())requestAnimationFrame(()=>{\nif(GS.layout===\'video_map\')clampVideoMapPip(false);});}\nfunction initVideoMapPip(){\nconst pip=$(\'mapPip\'),label=$(\'videoMapPipLabel\'),\nrestoreButton=$(\'mapPipRestoreButton\');if(!pip||!label)return;\nconst handles=[...pip.querySelectorAll(\'[data-video-map-pip-corner]\')];let action=null;\nconst setLocal=rect=>{\npip.style.right=\'auto\';pip.style.bottom=\'auto\';\npip.style.left=rect.left+\'px\';pip.style.top=rect.top+\'px\';\npip.style.width=rect.width+\'px\';pip.style.height=rect.height+\'px\';};\nconst finish=event=>{\nif(!action||event.pointerId!==action.id)return;\nconst wasTap=action.type===\'pending\'&&!action.moved&&Date.now()-action.started<650;\ntry{label.releasePointerCapture(event.pointerId);}catch(_error){}\npip.classList.remove(\'dragging\',\'resizing\');\nconst changed=action.type===\'move\'||action.type===\'resize\';action=null;\nif(changed)clampVideoMapPip(true);if(wasTap)setLayout(\'map_video\');\nevent.preventDefault();};\nhandles.forEach(handle=>handle.addEventListener(\'pointerdown\',event=>{\nif(!groundStationGeometryViewportUsable()||GS_VIEWPORT_TRANSITION_STATE.active||videoMapPipIsMinimized()||\n(event.button!==undefined&&event.button!==0))return;\nconst rect=overlayElementLocalRect(pip);\naction={type:\'resize\',corner:handle.dataset.videoMapPipCorner||\'se\',\nid:event.pointerId,startX:event.clientX,startY:event.clientY,\nleft:rect.left,top:rect.top,right:rect.left+rect.width,\nbottom:rect.top+rect.height,moved:true,started:Date.now()};\nsetLocal(rect);pip.classList.add(\'resizing\');\ntry{handle.setPointerCapture(event.pointerId);}catch(_error){}\nevent.stopPropagation();event.preventDefault();}));\nif(restoreButton){\nrestoreButton.addEventListener(\'pointerdown\',event=>event.stopPropagation());\nrestoreButton.addEventListener(\'click\',event=>{\nevent.stopPropagation();setVideoMapPipMinimized(false);});}\nlabel.addEventListener(\'pointerdown\',event=>{\nif(!groundStationGeometryViewportUsable()||GS_VIEWPORT_TRANSITION_STATE.active||videoMapPipIsMinimized()||\n(event.button!==undefined&&event.button!==0))return;\nconst rect=overlayElementLocalRect(pip);\naction={type:\'pending\',id:event.pointerId,startX:event.clientX,startY:event.clientY,\nleft:rect.left,top:rect.top,width:rect.width,height:rect.height,\nmoved:false,started:Date.now()};\ntry{label.setPointerCapture(event.pointerId);}catch(_error){}\nevent.preventDefault();});\nlabel.addEventListener(\'pointermove\',event=>{\nif(!action||event.pointerId!==action.id)return;\nlet dx=event.clientX-action.startX,dy=event.clientY-action.startY;\nif(action.type===\'pending\'&&Math.hypot(dx,dy)>8){\nconst rect=overlayElementLocalRect(pip);\naction.type=\'move\';action.moved=true;action.left=rect.left;action.top=rect.top;\naction.width=rect.width;action.height=rect.height;\naction.startX=event.clientX;action.startY=event.clientY;\nsetLocal(rect);pip.classList.add(\'dragging\');return;}\nif(action.type===\'pending\')return;\nconst limits=pipBounds(pip),snapped=stickyOverlayRect(\naction.left+(event.clientX-action.startX),\naction.top+(event.clientY-action.startY),\naction.width,action.height,limits);\npip.style.left=snapped.left+\'px\';pip.style.top=snapped.top+\'px\';\nevent.preventDefault();});\nhandles.forEach(handle=>handle.addEventListener(\'pointermove\',event=>{\nif(!action||event.pointerId!==action.id||action.type!==\'resize\')return;\nconst dx=event.clientX-action.startX,dy=event.clientY-action.startY,\nlimits=pipBounds(pip),phone=window.matchMedia(\n\'(max-width:760px), (max-height:560px)\').matches,\nminWidth=phone?120:160,minHeight=phone?78:100,\nmaxWidth=Math.max(minWidth,Math.min(limits.availableWidth*.82,limits.availableWidth)),\nmaxHeight=Math.max(minHeight,Math.min(limits.availableHeight*.82,limits.availableHeight));\nlet left=action.left,top=action.top,right=action.right,bottom=action.bottom,\ncorner=action.corner;\nif(corner.includes(\'w\'))left=Math.max(limits.left,Math.min(action.left+dx,right-minWidth));\nif(corner.includes(\'e\'))right=Math.min(limits.right,Math.max(action.right+dx,left+minWidth));\nif(corner.includes(\'n\'))top=Math.max(limits.top,Math.min(action.top+dy,bottom-minHeight));\nif(corner.includes(\'s\'))bottom=Math.min(limits.bottom,Math.max(action.bottom+dy,top+minHeight));\nif(right-left>maxWidth){if(corner.includes(\'w\'))left=right-maxWidth;else right=left+maxWidth;}\nif(bottom-top>maxHeight){if(corner.includes(\'n\'))top=bottom-maxHeight;else bottom=top+maxHeight;}\npip.style.left=left+\'px\';pip.style.top=top+\'px\';\npip.style.width=(right-left)+\'px\';pip.style.height=(bottom-top)+\'px\';\nif(GS.map&&GS.mapReady)setTimeout(()=>\nGS.map.invalidateSize({pan:false,animate:false}),0);\nevent.preventDefault();}));\nlabel.addEventListener(\'pointerup\',finish);label.addEventListener(\'pointercancel\',finish);\nhandles.forEach(handle=>{\nhandle.addEventListener(\'pointerup\',finish);\nhandle.addEventListener(\'pointercancel\',finish);});\nrestoreVideoMapPipGeometry();\ntry{if(localStorage.getItem(GS_VIDEO_MAP_PIP_MINIMIZED_KEY)===\'1\')\nsetVideoMapPipMinimized(true);}catch(_error){}\nwindow.addEventListener(\'resize\',()=>{\nif(GS.layout===\'video_map\')clampVideoMapPip(false);},{passive:true});}\nfunction toggleActivePipMinimized(){if(GS.layout===\'map_video\')setMapVideoPipMinimized(!mapVideoPipIsMinimized());else if(GS.layout===\'video_map\')setVideoMapPipMinimized(!videoMapPipIsMinimized());else setPipMinimized(!pipIsMinimized());}\n\nfunction initMovablePip(){\nconst pip=$(\'cameraPip\'),restoreButton=$(\'pipRestoreButton\');if(!pip)return;\nconst handles=[...pip.querySelectorAll(\'.gs-pip-resize\')];\nlet action=null,holdTimer=null;\nconst clearHold=()=>{if(holdTimer){clearTimeout(holdTimer);holdTimer=null;}};\nconst setLocalGeometry=rect=>{\npip.style.right=\'auto\';pip.style.bottom=\'auto\';\npip.style.left=rect.left+\'px\';pip.style.top=rect.top+\'px\';\npip.style.width=rect.width+\'px\';pip.style.height=rect.height+\'px\';};\nconst finish=event=>{\nif(!action||event.pointerId!==action.id)return;\nclearHold();\nconst wasTap=action.type===\'pending\'&&!action.moved&&!action.longPressed&&\nDate.now()-action.started<700;\ntry{pip.releasePointerCapture(event.pointerId);}catch(_error){}\npip.classList.remove(\'dragging\',\'resizing\');\nconst shouldClamp=action.type===\'move\'||action.type===\'resize\';\naction=null;\nif(shouldClamp)clampPipPosition(true);\nif(wasTap)swapCameras();\nevent.preventDefault();};\nhandles.forEach(handle=>handle.addEventListener(\'pointerdown\',event=>{\nif(!groundStationGeometryViewportUsable()||GS_VIEWPORT_TRANSITION_STATE.active||pipIsMinimized()||\n(event.button!==undefined&&event.button!==0))return;\nclearHold();const rect=overlayElementLocalRect(pip);\naction={type:\'resize\',corner:handle.dataset.corner||\'se\',id:event.pointerId,\nstartX:event.clientX,startY:event.clientY,left:rect.left,top:rect.top,\nright:rect.left+rect.width,bottom:rect.top+rect.height,\nwidth:rect.width,height:rect.height,moved:true,longPressed:false,started:Date.now()};\nsetLocalGeometry(rect);pip.classList.add(\'resizing\');\ntry{pip.setPointerCapture(event.pointerId);}catch(_error){}\nevent.stopPropagation();event.preventDefault();}));\nif(restoreButton){\nrestoreButton.addEventListener(\'pointerdown\',event=>event.stopPropagation());\nrestoreButton.addEventListener(\'click\',event=>{\nevent.stopPropagation();setPipMinimized(false);});}\npip.addEventListener(\'pointerdown\',event=>{\nif(GS_VIEWPORT_TRANSITION_STATE.active||\n(event.target.closest&&event.target.closest(\'.gs-pip-resize,.gs-pip-edge-button\'))||\npipIsMinimized()||(event.button!==undefined&&event.button!==0))return;\nconst rect=overlayElementLocalRect(pip);\naction={type:\'pending\',id:event.pointerId,startX:event.clientX,startY:event.clientY,\nleft:rect.left,top:rect.top,width:rect.width,height:rect.height,\nmoved:false,longPressed:false,started:Date.now()};\ntry{pip.setPointerCapture(event.pointerId);}catch(_error){}\nholdTimer=setTimeout(()=>{\nif(!action||action.id!==event.pointerId||action.moved)return;\naction.longPressed=true;clearHold();setPipMinimized(true);\ntry{navigator.vibrate&&navigator.vibrate(25);}catch(_error){}},700);\nevent.preventDefault();});\npip.addEventListener(\'pointermove\',event=>{\nif(!action||event.pointerId!==action.id)return;\nlet dx=event.clientX-action.startX,dy=event.clientY-action.startY;\nif(action.type===\'pending\'&&Math.hypot(dx,dy)>8){\nclearHold();action.type=\'move\';action.moved=true;\nconst rect=overlayElementLocalRect(pip);\naction.left=rect.left;action.top=rect.top;\naction.width=rect.width;action.height=rect.height;\naction.startX=event.clientX;action.startY=event.clientY;\nsetLocalGeometry(rect);pip.classList.add(\'dragging\');return;}\nif(action.longPressed||action.type===\'pending\')return;\nconst limits=pipBounds(pip),phone=window.matchMedia(\n\'(max-width:760px), (max-height:560px)\').matches,\nminWidth=phone?110:120,minHeight=phone?68:76,\nmaxWidth=Math.max(minWidth,Math.min(limits.availableWidth*.82,limits.availableWidth)),\nmaxHeight=Math.max(minHeight,Math.min(limits.availableHeight*.82,limits.availableHeight));\nif(action.type===\'resize\'){\nlet left=action.left,top=action.top,right=action.right,bottom=action.bottom,\ncorner=action.corner;\nif(corner.includes(\'w\'))left=Math.max(limits.left,Math.min(action.left+dx,right-minWidth));\nif(corner.includes(\'e\'))right=Math.min(limits.right,Math.max(action.right+dx,left+minWidth));\nif(corner.includes(\'n\'))top=Math.max(limits.top,Math.min(action.top+dy,bottom-minHeight));\nif(corner.includes(\'s\'))bottom=Math.min(limits.bottom,Math.max(action.bottom+dy,top+minHeight));\nif(right-left>maxWidth){if(corner.includes(\'w\'))left=right-maxWidth;else right=left+maxWidth;}\nif(bottom-top>maxHeight){if(corner.includes(\'n\'))top=bottom-maxHeight;else bottom=top+maxHeight;}\npip.style.left=left+\'px\';pip.style.top=top+\'px\';\npip.style.width=(right-left)+\'px\';pip.style.height=(bottom-top)+\'px\';\n}else{\ndx=event.clientX-action.startX;dy=event.clientY-action.startY;\nconst snapped=stickyOverlayRect(\naction.left+dx,action.top+dy,action.width,action.height,limits);\npip.style.left=snapped.left+\'px\';pip.style.top=snapped.top+\'px\';}\nevent.preventDefault();});\npip.addEventListener(\'pointerup\',finish);\npip.addEventListener(\'pointercancel\',finish);\nrestorePipPosition();restorePipMinimizedState();}\n\n\n\n\n\n\n\nconst GS_INSTRUMENT_GEOMETRY_KEY=groundStationPlatformStorageKey(\'siyi-groundstation-telemetry-groups-v2-platform\');\nconst TELEMETRY_GROUP_PREFIX=\'raw.__tc_group__.v2.\';\nconst TELEMETRY_LABEL_PREFIX=\'raw.__tc_label__.v1.\';\nconst TELEMETRY_OVERLAY_PREFIX=\'raw.__gs_overlay__.v1.\';\nconst GS_EDGE_SNAP_PX=16;\nconst TELEMETRY_CANVAS={\nconfig:null,groups:[],visible:true,activeGroupId:null,moveGroupId:null,\ncatalog:[],catalogByKey:new Map(),values:{},filter:\'available\',scope:\'qgc\',search:\'\',renderLimit:300,collapsedGroups:new Set(),\noverlayGeometry:{},\nsaveTimer:null,pollTimer:null,valuePollInFlight:false,valueMeasureRaf:new Map(),\neditorOpen:false,editorBlockedUntil:0,initialized:false\n};\n/* GROUND_STATION_TELEMETRY_GROUP_SIZE_V2_8_21_PLATFORM_LOCAL */\nfunction telemetryReadPlatformGroupGeometry(){\n  try{\n    const parsed=JSON.parse(\n      localStorage.getItem(GS_INSTRUMENT_GEOMETRY_KEY)||\'null\'\n    );\n    if(\n      parsed&&Number(parsed.v)>=1&&Number(parsed.v)<=2&&\n      parsed.platform===GS_FLY_VIEW_PLATFORM_PROFILE&&\n      parsed.groups&&typeof parsed.groups===\'object\'\n    )return parsed.groups;\n  }catch(_error){}\n  return{};\n}\nfunction telemetryWritePlatformGroupGeometry(groupsById){\n  try{\n    localStorage.setItem(\n      GS_INSTRUMENT_GEOMETRY_KEY,\n      JSON.stringify({\n        v:2,\n        platform:GS_FLY_VIEW_PLATFORM_PROFILE,\n        groups:groupsById||{}\n      })\n    );\n  }catch(_error){}\n}\nfunction telemetryApplyPlatformGroupGeometry(groups){\n  const saved=telemetryReadPlatformGroupGeometry();\n  const next={};\n  let changed=false;\n  for(const [index,group] of (groups||[]).entries()){\n    const record=saved[group.id];\n    const hasPosition=Boolean(\n      record&&\n      Number.isFinite(Number(record.x))&&\n      Number.isFinite(Number(record.y))\n    );\n    const hasColumns=Boolean(\n      record&&Number.isFinite(Number(record.c))\n    );\n    const hasFontSize=Boolean(\n      record&&Number.isFinite(Number(record.f))\n    );\n\n    if(hasPosition){\n      group.left=Number(record.x);\n      group.top=Number(record.y);\n      group.anchorX=null;\n      group.anchorY=null;\n      group.anchorEdges=String(record.e||\'\')\n        .replace(/[^lrtb]/g,\'\').slice(0,4);\n    }else if(!group.sharedGeometryNeutral){\n      // One-time migration from the pre-V2.8.20 shared position.\n      changed=true;\n    }else{\n      // A new platform profile starts from platform defaults, never from\n      // coordinates last saved by the other platform.\n      const fallback=telemetryDefaultGroup(index);\n      group.left=fallback.left;\n      group.top=fallback.top;\n      group.anchorX=null;\n      group.anchorY=null;\n      group.anchorEdges=\'\';\n      changed=true;\n    }\n\n    if(hasColumns){\n      group.cols=Math.round(clampNumber(record.c,1,24,group.cols));\n    }else{\n      // Migrate the V2.8.20 shared size once into this platform profile.\n      group.cols=Math.round(clampNumber(group.cols,1,24,2));\n      changed=true;\n    }\n    if(hasFontSize){\n      group.fontSize=Math.round(\n        clampNumber(record.f,10,40,group.fontSize)\n      );\n    }else{\n      group.fontSize=Math.round(\n        clampNumber(group.fontSize,10,40,17)\n      );\n      changed=true;\n    }\n\n    next[group.id]={\n      x:Number(group.left)||0,\n      y:Number(group.top)||0,\n      e:String(group.anchorEdges||\'\')\n        .replace(/[^lrtb]/g,\'\').slice(0,4),\n      c:group.cols,\n      f:group.fontSize\n    };\n  }\n  if(\n    changed||\n    Object.keys(saved).length!==Object.keys(next).length\n  ){\n    telemetryWritePlatformGroupGeometry(next);\n  }\n}\nfunction telemetrySavePlatformGroupGeometry(){\n  if(!groundStationGeometryViewportUsable())return;\n  const payload={};\n  for(const group of TELEMETRY_CANVAS.groups){\n    const element=telemetryGroupElement(group.id);\n    if(element&&!GS_VIEWPORT_TRANSITION_STATE.active){\n      telemetryCaptureGroupAnchor(group,element);\n    }\n    payload[group.id]={\n      x:Number(group.left)||0,\n      y:Number(group.top)||0,\n      e:String(group.anchorEdges||\'\')\n        .replace(/[^lrtb]/g,\'\').slice(0,4),\n      c:Math.round(clampNumber(group.cols,1,24,2)),\n      f:Math.round(clampNumber(group.fontSize,10,40,17))\n    };\n  }\n  telemetryWritePlatformGroupGeometry(payload);\n}\nconst GS_VIEWPORT_TRANSITION_STATE={\nsnapshot:null,lastLandscapeSnapshot:null,active:false,timer:null,\nlastSignature:\'\',stableSamples:0,startedAt:0,pendingPersist:false,\npendingRestore:false,sequence:0,orientationDeferred:false\n};\n\nfunction visualViewportRect(){\nconst viewport=window.visualViewport;\nreturn{left:0,top:0,\nwidth:viewport?(Number(viewport.width)||window.innerWidth):window.innerWidth,\nheight:viewport?(Number(viewport.height)||window.innerHeight):window.innerHeight};}\nfunction groundStationGeometryViewportUsable(){\nconst rect=visualViewportRect(),\nlandscapeBySize=rect.width>rect.height+8,\nlandscapeByMedia=!window.matchMedia||\nwindow.matchMedia(\'(orientation: landscape)\').matches,\nportraitBlocked=document.documentElement.classList.contains(\'gs-portrait-blocked\');\nreturn landscapeBySize&&landscapeByMedia&&!portraitBlocked&&\nrect.width>=320&&rect.height>=180;}\nfunction deferGroundStationGeometryUntilLandscape(restore=true,persist=false){\nconst state=GS_VIEWPORT_TRANSITION_STATE;\nstate.orientationDeferred=true;state.active=true;state.sequence+=1;\nif(state.timer){clearTimeout(state.timer);state.timer=null;}\nif(restore)state.pendingRestore=true;\nif(persist)state.pendingPersist=true;\nstate.timer=setTimeout(()=>scheduleViewportLayoutRestore(\'landscape-wait\'),180);}\nfunction overlayViewportBounds(){\nconst viewport=visualViewportRect(),top=document.querySelector(\'.gs-top\'),\ntopLimit=top?Math.max(0,top.getBoundingClientRect().bottom):0;\nreturn{left:0,top:Math.min(topLimit,viewport.height),\nright:viewport.width,bottom:viewport.height,\nwidth:viewport.width,height:Math.max(1,viewport.height-topLimit)};}\nfunction stickyOverlayRect(left,top,width,height,bounds=overlayViewportBounds()){\nwidth=Math.max(1,Number(width)||1);height=Math.max(1,Number(height)||1);\nconst maxLeft=Math.max(bounds.left,bounds.right-width),\nmaxTop=Math.max(bounds.top,bounds.bottom-height);\nleft=clampNumber(left,bounds.left,maxLeft,bounds.left);\ntop=clampNumber(top,bounds.top,maxTop,bounds.top);\nif(Math.abs(left-bounds.left)<=GS_EDGE_SNAP_PX)left=bounds.left;\nelse if(Math.abs((left+width)-bounds.right)<=GS_EDGE_SNAP_PX)left=maxLeft;\nif(Math.abs(top-bounds.top)<=GS_EDGE_SNAP_PX)top=bounds.top;\nelse if(Math.abs((top+height)-bounds.bottom)<=GS_EDGE_SNAP_PX)top=maxTop;\nreturn{left,top,width,height};}\nfunction overlayEdgeFlags(left,top,width,height,bounds){\nconst snapped=stickyOverlayRect(left,top,width,height,bounds),flags=[];\nif(Math.abs(snapped.left-bounds.left)<1)flags.push(\'l\');\nif(Math.abs((snapped.left+snapped.width)-bounds.right)<1)flags.push(\'r\');\nif(Math.abs(snapped.top-bounds.top)<1)flags.push(\'t\');\nif(Math.abs((snapped.top+snapped.height)-bounds.bottom)<1)flags.push(\'b\');\nreturn flags.join(\'\');}\nfunction overlayCoordinateRoot(element){\nif(!element)return null;\nconst style=getComputedStyle(element);\nif(style.position===\'fixed\'||element.classList.contains(\'gs-telemetry-group\'))return null;\nconst parent=element.offsetParent||element.parentElement,\nparentRect=parent&&parent.getBoundingClientRect?parent.getBoundingClientRect():null;\nif(parent&&parentRect&&parentRect.width>=2&&parentRect.height>=2)return parent;\nreturn $(\'stage\')||parent||null;}\nfunction overlayElementBounds(element){\nconst root=overlayCoordinateRoot(element);\nif(!root)return overlayViewportBounds();\nconst rect=root.getBoundingClientRect(),\nwidth=Math.max(1,root.clientWidth||rect.width||1),\nheight=Math.max(1,root.clientHeight||rect.height||1);\nreturn{left:0,top:0,right:width,bottom:height,width,height,root};}\nfunction overlayElementLocalRect(element){\nif(!element)return{left:0,top:0,width:1,height:1};\nconst rect=element.getBoundingClientRect(),root=overlayCoordinateRoot(element);\nif(!root)return{left:rect.left,top:rect.top,width:rect.width,height:rect.height};\nconst rootRect=root.getBoundingClientRect();\nreturn{left:rect.left-rootRect.left,top:rect.top-rootRect.top,\nwidth:rect.width,height:rect.height};}\nfunction exactPlacementRecord(left,top,width,height,bounds,edges=\'\'){\nconst snapped=stickyOverlayRect(left,top,width,height,bounds),\nsavedEdges=String(edges||overlayEdgeFlags(\nsnapped.left,snapped.top,snapped.width,snapped.height,bounds))\n.replace(/[^lrtb]/g,\'\').slice(0,4);\nreturn{v:2,x:Number(snapped.left.toFixed(3)),y:Number(snapped.top.toFixed(3)),\nw:Number(snapped.width.toFixed(3)),h:Number(snapped.height.toFixed(3)),e:savedEdges};}\nfunction exactPlacementRect(record,bounds,widthOverride=null,heightOverride=null){\nconst width=Math.max(1,widthOverride!==null&&Number.isFinite(Number(widthOverride))?\nNumber(widthOverride):(Number(record&&record.w)||Number(record&&record.pw)||1)),\nheight=Math.max(1,heightOverride!==null&&Number.isFinite(Number(heightOverride))?\nNumber(heightOverride):(Number(record&&record.h)||Number(record&&record.ph)||1)),\nedges=String(record&&record.e||\'\').replace(/[^lrtb]/g,\'\').slice(0,4);\nlet left=Number(record&&record.x),top=Number(record&&record.y);\nif(!Number.isFinite(left))left=bounds.left;\nif(!Number.isFinite(top))top=bounds.top;\nif(edges.includes(\'l\'))left=bounds.left;\nelse if(edges.includes(\'r\'))left=bounds.right-width;\nif(edges.includes(\'t\'))top=bounds.top;\nelse if(edges.includes(\'b\'))top=bounds.bottom-height;\nreturn stickyOverlayRect(left,top,width,height,bounds);}\nfunction legacyPlacementRect(record,bounds){\nif([record&&record.rx,record&&record.ry,record&&record.pw,record&&record.ph]\n.every(Number.isFinite)){\nconst width=Math.max(1,Number(record.pw)),height=Math.max(1,Number(record.ph)),\ntravelX=Math.max(0,(bounds.right-bounds.left)-width),\ntravelY=Math.max(0,(bounds.bottom-bounds.top)-height);\nreturn exactPlacementRect({v:2,x:bounds.left+clampNumber(record.rx,0,1,0)*travelX,\ny:bounds.top+clampNumber(record.ry,0,1,0)*travelY,w:width,h:height,e:record.e||\'\'},bounds);}\nif([record&&record.x,record&&record.y,record&&record.w,record&&record.h]\n.every(Number.isFinite)){\nconst width=Math.max(1,Number(record.w)*(bounds.right-bounds.left)),\nheight=Math.max(1,Number(record.h)*(bounds.bottom-bounds.top));\nreturn exactPlacementRect({v:2,x:bounds.left+Number(record.x)*(bounds.right-bounds.left),\ny:bounds.top+Number(record.y)*(bounds.bottom-bounds.top),\nw:width,h:height,e:record.e||\'\'},bounds);}\nreturn null;}\nfunction overlayGeometryRecord(kind,element,edges=\'\'){\nif(!element)return null;\nconst rect=overlayElementLocalRect(element),bounds=overlayElementBounds(element);\nif(rect.width<2||rect.height<2)return null;\nreturn{k:String(kind),...exactPlacementRecord(\nrect.left,rect.top,rect.width,rect.height,bounds,edges)};}\nfunction telemetryOverlayToken(record){\nif(!record||!record.k)return\'\';\nconst payload={p:2,k:String(record.k).slice(0,16),\nx:Math.round(Number(record.x)||0),y:Math.round(Number(record.y)||0),\nw:Math.round(Number(record.w)||Number(record.pw)||1),\nh:Math.round(Number(record.h)||Number(record.ph)||1),\ne:String(record.e||\'\').replace(/[^lrtb]/g,\'\').slice(0,4)};\nreturn TELEMETRY_OVERLAY_PREFIX+\ntelemetryUtf8ToBase64Url(JSON.stringify(payload));}\nfunction telemetryParseOverlayToken(token){\ntry{\nif(!String(token).startsWith(TELEMETRY_OVERLAY_PREFIX))return null;\nconst payload=JSON.parse(telemetryBase64UrlToUtf8(\nString(token).slice(TELEMETRY_OVERLAY_PREFIX.length)));\nif(!payload||!payload.k)return null;\nconst key=String(payload.k).slice(0,16),\nedges=String(payload.e||\'\').replace(/[^lrtb]/g,\'\').slice(0,4);\nif(Number(payload.p)===2&&[payload.x,payload.y,payload.w,payload.h]\n.every(value=>Number.isFinite(Number(value)))){\nreturn{k:key,v:2,x:Number(payload.x),y:Number(payload.y),\nw:Number(payload.w),h:Number(payload.h),e:edges};}\nconst compact=Number(payload.p)===1||\n(Number.isFinite(Number(payload.a))&&Number.isFinite(Number(payload.b))),\nrecord={k:key,v:1,x:compact?NaN:Number(payload.x),y:compact?NaN:Number(payload.y),\nw:compact?NaN:Number(payload.w),h:compact?NaN:Number(payload.h),\nrx:compact?Number(payload.a)/10000:Number(payload.rx),\nry:compact?Number(payload.b)/10000:Number(payload.ry),\npw:compact?Number(payload.w):Number(payload.pw),\nph:compact?Number(payload.h):Number(payload.ph),e:edges};\nif(![record.x,record.y,record.w,record.h].every(Number.isFinite)&&\n![record.rx,record.ry,record.pw,record.ph].every(Number.isFinite))return null;\nreturn record;\n}catch(_error){return null;}}\nfunction telemetryOverlayGeometryFromConfig(config){\nconst result={},selected=Array.isArray(config&&config.selected_fields)?\nconfig.selected_fields:[];\nfor(const token of selected){\nconst parsed=telemetryParseOverlayToken(token);\nif(parsed)result[parsed.k]=parsed;}\nreturn result;}\nfunction applyOverlayGeometryRecord(element,record){\nif(!element||!record)return false;\nconst bounds=overlayElementBounds(element),\nsnapped=Number(record.v)===2?\nexactPlacementRect(record,bounds):legacyPlacementRect(record,bounds);\nif(!snapped)return false;\nelement.style.right=\'auto\';element.style.bottom=\'auto\';\nelement.style.left=snapped.left+\'px\';element.style.top=snapped.top+\'px\';\nelement.style.width=snapped.width+\'px\';element.style.height=snapped.height+\'px\';\nreturn true;}\nfunction telemetryRememberOverlayGeometry(kind,element,schedule=true){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,true);return;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingPersist=true;return;}\nconst record=overlayGeometryRecord(kind,element);\nif(!record)return;\nTELEMETRY_CANVAS.overlayGeometry[kind]=record;\nrememberStableViewportLayout();\nif(schedule&&TELEMETRY_CANVAS.initialized)telemetryScheduleSave(false);}\nfunction telemetryRestoreOverlayGeometry(kind,element){\nconst record=TELEMETRY_CANVAS.overlayGeometry&&\nTELEMETRY_CANVAS.overlayGeometry[kind];\nif(!record||!element)return false;\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return false;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingRestore=true;return false;}\nconst restored=applyOverlayGeometryRecord(element,record);\nif(restored&&Number(record.v)!==2){\nconst migrated=overlayGeometryRecord(kind,element,record.e);\nif(migrated){TELEMETRY_CANVAS.overlayGeometry[kind]=migrated;\nGS_VIEWPORT_TRANSITION_STATE.pendingPersist=true;}}\nreturn restored;}\nfunction telemetryCaptureAllOverlayGeometry(schedule=false){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,Boolean(schedule));return;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingPersist=true;return;}\ntelemetryRememberOverlayGeometry(\'cameraPip\',$(\'cameraPip\'),false);\ntelemetryRememberOverlayGeometry(\'mapVideoPip\',$(\'videoPip\'),false);\ntelemetryRememberOverlayGeometry(\'videoMapPip\',$(\'mapPip\'),false);\ntelemetryRememberOverlayGeometry(\'roundHud\',$(\'roundHud\'),false);\nrememberStableViewportLayout();\nif(schedule&&TELEMETRY_CANVAS.initialized)telemetryScheduleSave(false);}\nfunction telemetryRestoreAllOverlayGeometry(){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingRestore=true;return;}\nconst camera=$(\'cameraPip\'),mapVideo=$(\'videoPip\'),\nvideoMap=$(\'mapPip\'),round=$(\'roundHud\');\nif(telemetryRestoreOverlayGeometry(\'cameraPip\',camera))clampPipPosition(false);\nif(telemetryRestoreOverlayGeometry(\'mapVideoPip\',mapVideo))clampMapVideoPip(false);\nif(telemetryRestoreOverlayGeometry(\'videoMapPip\',videoMap))clampVideoMapPip(false);\nif(telemetryRestoreOverlayGeometry(\'roundHud\',round))clampRoundHud(false);}\nfunction telemetryPersistAllGeometry(){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,false);return;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingPersist=true;return;}\ntelemetryCaptureAllOverlayGeometry(false);\nfor(const group of TELEMETRY_CANVAS.groups){\ntelemetryClampGroup(group,false);\nconst element=telemetryGroupElement(group.id);\nif(element)telemetryCaptureGroupAnchor(group,element);}\ntelemetrySavePlatformGroupGeometry();\nrememberStableViewportLayout();\nif(!TELEMETRY_CANVAS.config)return;\nTELEMETRY_CANVAS.config=telemetryConfigFromGroups();\ntry{\nfetch(\'/api/groundstation/telemetry/layout\',{\nmethod:\'POST\',cache:\'no-store\',keepalive:true,\nheaders:{\'Content-Type\':\'application/json\'},\nbody:JSON.stringify(TELEMETRY_CANVAS.config)}).catch(()=>{});\n}catch(_error){}}\n\nfunction viewportLayoutElementMap(){\nreturn{cameraPip:$(\'cameraPip\'),mapVideoPip:$(\'videoPip\'),\nvideoMapPip:$(\'mapPip\'),roundHud:$(\'roundHud\')};}\nfunction captureStableViewportLayout(){\nconst state=GS_VIEWPORT_TRANSITION_STATE;\nif(!groundStationGeometryViewportUsable())\nreturn state.lastLandscapeSnapshot||state.snapshot||null;\nconst previous=state.lastLandscapeSnapshot||state.snapshot||{},\noverlays={...(previous.overlays||{})},groups={...(previous.groups||{})};\nfor(const [kind,element] of Object.entries(viewportLayoutElementMap())){\nif(!element)continue;\nconst rect=overlayElementLocalRect(element),\nexisting=TELEMETRY_CANVAS.overlayGeometry&&TELEMETRY_CANVAS.overlayGeometry[kind];\nif(rect.width>=2&&rect.height>=2&&getComputedStyle(element).display!==\'none\'){\nconst record=overlayGeometryRecord(kind,element,existing&&existing.e);\nif(record)overlays[kind]=record;}}\nfor(const group of TELEMETRY_CANVAS.groups){\nconst element=telemetryGroupElement(group.id);if(!element)continue;\nconst rect=element.getBoundingClientRect(),bounds=instrumentViewportBounds();\nif(rect.width>=1&&rect.height>=1)\ngroups[group.id]=exactPlacementRecord(\nrect.left,rect.top,rect.width,rect.height,bounds,group.anchorEdges||\'\');}\nreturn{overlays,groups};}\nfunction rememberStableViewportLayout(){\nconst state=GS_VIEWPORT_TRANSITION_STATE;\nif(state.active||!groundStationGeometryViewportUsable())return;\nconst snapshot=captureStableViewportLayout();\nif(!snapshot)return;\nstate.snapshot=snapshot;state.lastLandscapeSnapshot=snapshot;}\nfunction applyStableViewportLayout(snapshot=GS_VIEWPORT_TRANSITION_STATE.snapshot){\nif(!snapshot||!groundStationGeometryViewportUsable())return;\nconst elements=viewportLayoutElementMap();\nfor(const [kind,record] of Object.entries(snapshot.overlays||{})){\nconst element=elements[kind];if(element)applyOverlayGeometryRecord(element,record);}\nconst bounds=instrumentViewportBounds();\nfor(const group of TELEMETRY_CANVAS.groups){\nconst element=telemetryGroupElement(group.id),\nrecord=snapshot.groups&&snapshot.groups[group.id];\nif(!element||!record)continue;\nconst rect=element.getBoundingClientRect(),\nsnapped=exactPlacementRect(record,bounds,rect.width,rect.height);\ngroup.left=snapped.left;group.top=snapped.top;\ngroup.width=rect.width;group.height=rect.height;\ngroup.anchorX=null;group.anchorY=null;group.anchorEdges=record.e||\'\';\ntelemetrySetGroupGeometry(group,element);}\nif(GS.map&&GS.mapReady)setTimeout(()=>GS.map.invalidateSize({pan:false,animate:false}),0);\ndrawMaps();}\nfunction applyGroundStationViewportMetrics(){\nconst rect=visualViewportRect(),root=document.documentElement;\nroot.style.setProperty(\'--gs-vv-width\',rect.width+\'px\');\nroot.style.setProperty(\'--gs-vv-height\',rect.height+\'px\');\nconst app=$(\'gsApp\');if(app){app.style.width=rect.width+\'px\';app.style.height=rect.height+\'px\';}\nconst top=document.querySelector(\'.gs-top-left\');if(top)top.scrollLeft=0;}\nfunction viewportTransitionSignature(){\nconst rect=visualViewportRect(),stage=$(\'stage\'),\nstageRect=stage&&stage.getBoundingClientRect?stage.getBoundingClientRect():{width:0,height:0};\nreturn[Math.round(rect.width),Math.round(rect.height),\nMath.round(stageRect.width),Math.round(stageRect.height),\ndocument.fullscreenElement?\'1\':\'0\'].join(\':\');}\nfunction scheduleViewportLayoutRestore(_reason=\'viewport\'){\nconst state=GS_VIEWPORT_TRANSITION_STATE;\ntry{if(window.__siyiGroundStationApplyPortraitBlock)\nwindow.__siyiGroundStationApplyPortraitBlock();}catch(_error){}\napplyGroundStationViewportMetrics();\nif(!groundStationGeometryViewportUsable()){\nif(!state.orientationDeferred&&state.lastLandscapeSnapshot)\nstate.snapshot=state.lastLandscapeSnapshot;\ndeferGroundStationGeometryUntilLandscape(true,false);\nreturn;}\nconst resumedFromPortrait=state.orientationDeferred;\nstate.orientationDeferred=false;\nif(resumedFromPortrait){\nstate.snapshot=state.lastLandscapeSnapshot||null;\n}else if(!state.active){\nconst snapshot=captureStableViewportLayout();\nif(snapshot){state.snapshot=snapshot;state.lastLandscapeSnapshot=snapshot;}}\nstate.active=true;state.startedAt=performance.now();\nstate.lastSignature=\'\';state.stableSamples=0;state.sequence+=1;\nconst sequence=state.sequence;\nif(state.timer){clearTimeout(state.timer);state.timer=null;}\nconst probe=()=>{\nif(sequence!==state.sequence)return;\napplyGroundStationViewportMetrics();\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return;}\nconst signature=viewportTransitionSignature();\nif(signature===state.lastSignature)state.stableSamples+=1;\nelse{state.lastSignature=signature;state.stableSamples=0;}\nif(state.stableSamples>=4||performance.now()-state.startedAt>2600){\nstate.timer=null;\nrequestAnimationFrame(()=>requestAnimationFrame(()=>{\nif(sequence!==state.sequence)return;\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return;}\napplyGroundStationViewportMetrics();\napplyStableViewportLayout(state.snapshot||state.lastLandscapeSnapshot);\nstate.active=false;\nstate.pendingRestore=false;\ntelemetryRestoreAllPersistentGeometry();\nrememberStableViewportLayout();\nconst persistRequested=state.pendingPersist;\nstate.pendingPersist=false;\nif(persistRequested)telemetryScheduleSave(false);}));\nreturn;}\nstate.timer=setTimeout(probe,100);};\nstate.timer=setTimeout(probe,100);}\nfunction syncGroundStationViewport(){\nscheduleViewportLayoutRestore(\'viewport\');}\nfunction isPhoneGroundStationHost(){\nconst mobileUa=/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent||\'\'),\ncoarse=window.matchMedia&&window.matchMedia(\'(pointer:coarse)\').matches,\nnoHover=window.matchMedia&&window.matchMedia(\'(hover:none)\').matches,\ncompact=Math.min(screen.width||9999,screen.height||9999)<=1000;\nreturn mobileUa||(coarse&&noHover&&compact);}\nfunction requestGroundStationFullscreen(){\nif(document.fullscreenElement)return Promise.resolve(true);\nrememberStableViewportLayout();\nconst target=document.documentElement;\nif(!target.requestFullscreen)return Promise.resolve(false);\ntry{return Promise.resolve(target.requestFullscreen({navigationUI:\'hide\'}))\n.then(()=>Boolean(document.fullscreenElement)).catch(()=>{\ntry{return Promise.resolve(target.requestFullscreen())\n.then(()=>Boolean(document.fullscreenElement)).catch(()=>false);}\ncatch(_error){return false;}});}\ncatch(_error){return Promise.resolve(false);}}\nfunction updateFullscreenUi(){\nconst state=GS_VIEWPORT_TRANSITION_STATE;\nif(groundStationGeometryViewportUsable()&&!state.active){\nconst snapshot=captureStableViewportLayout();\nif(snapshot){state.snapshot=snapshot;state.lastLandscapeSnapshot=snapshot;}}\ndocument.documentElement.classList.toggle(\n\'gs-native-fullscreen\',Boolean(document.fullscreenElement));\nscheduleViewportLayoutRestore(\'fullscreenchange\');}\nfunction initPhoneGroundStationViewport(){\nconst phone=isPhoneGroundStationHost();\ndocument.documentElement.classList.toggle(\'gs-phone-host\',phone);\napplyGroundStationViewportMetrics();\nconst orientationRefresh=()=>{\ntry{if(window.__siyiGroundStationApplyPortraitBlock)\nwindow.__siyiGroundStationApplyPortraitBlock();}catch(_error){}\nscheduleViewportLayoutRestore(\'orientationchange\');\nsetTimeout(()=>scheduleViewportLayoutRestore(\'orientation-settle\'),140);};\nif(window.visualViewport){\nwindow.visualViewport.addEventListener(\'resize\',syncGroundStationViewport);\nwindow.visualViewport.addEventListener(\'scroll\',syncGroundStationViewport);}\nwindow.addEventListener(\'resize\',syncGroundStationViewport,{passive:true});\nwindow.addEventListener(\'orientationchange\',orientationRefresh,{passive:true});\ntry{\nif(screen.orientation&&typeof screen.orientation.addEventListener===\'function\')\nscreen.orientation.addEventListener(\'change\',orientationRefresh);\n}catch(_error){}\ndocument.addEventListener(\'fullscreenchange\',updateFullscreenUi);\nif(!groundStationGeometryViewportUsable())\ndeferGroundStationGeometryUntilLandscape(true,false);\nelse rememberStableViewportLayout();\nif(phone&&!document.fullscreenElement){\nrequestGroundStationFullscreen();\nlet requesting=false;\nconst enterFullscreen=()=>{\nif(requesting||document.fullscreenElement)return;\nrequesting=true;requestGroundStationFullscreen().finally(()=>{requesting=false;});};\ndocument.addEventListener(\'pointerdown\',enterFullscreen,true);\ndocument.addEventListener(\'touchstart\',enterFullscreen,true);\ndocument.addEventListener(\'click\',enterFullscreen,true);}}\n\nfunction instrumentViewportBounds(){\nconst bounds=overlayViewportBounds();\nreturn{left:bounds.left,top:bounds.top,right:bounds.right,bottom:bounds.bottom};}\nfunction clampNumber(value,min,max,fallback){\nconst parsed=Number(value);\nreturn Number.isFinite(parsed)?Math.max(min,Math.min(max,parsed)):fallback;}\nfunction telemetryGroupId(){\nreturn\'g\'+Date.now().toString(36)+Math.random().toString(36).slice(2,7);}\nfunction telemetryDefaultGroup(index=0){\nconst bounds=instrumentViewportBounds(),phone=isPhoneGroundStationHost(),\nleft=index%2===0?8:Math.max(8,bounds.right-(phone?220:280)),\ntop=Math.max(bounds.top+8,bounds.top+8+(index%4)*34);\nreturn{id:telemetryGroupId(),name:\'Group \'+(index+1),left,top,\ncols:2,fontSize:17,sizeBaselineCols:2,sizeBaselineFontSize:17,\nshowLabels:true,showUnits:true,fields:[],labels:{},\nwidth:1,height:1,sharedGeometryNeutral:true};}\nfunction telemetryNormaliseGroup(group,index=0){\nconst fallback=telemetryDefaultGroup(index),bounds=instrumentViewportBounds(),\nwidth=Math.max(1,Number(group&&group.width)||1),\nheight=Math.max(1,Number(group&&group.height)||1),labels={},\nnormalCols=Math.round(clampNumber(group&&group.cols,1,24,2)),\nnormalFontSize=Math.round(clampNumber(group&&group.fontSize,10,40,17)),\nbaselineCols=Math.round(clampNumber(\ngroup&&group.sizeBaselineCols,1,24,normalCols)),\nbaselineFontSize=Math.round(clampNumber(\ngroup&&group.sizeBaselineFontSize,10,40,normalFontSize)),\nrawAnchorX=group&&group.anchorX,rawAnchorY=group&&group.anchorY,\nanchorX=rawAnchorX===null||rawAnchorX===undefined?NaN:Number(rawAnchorX),\nanchorY=rawAnchorY===null||rawAnchorY===undefined?NaN:Number(rawAnchorY),\nanchorEdges=String(group&&group.anchorEdges||\'\').replace(/[^lrtb]/g,\'\').slice(0,4);\nif(group&&group.labels&&typeof group.labels===\'object\'){\nfor(const [key,value] of Object.entries(group.labels)){\nconst cleanKey=String(key||\'\');\nconst cleanLabel=telemetryNormaliseCustomLabel(value);\nif(cleanKey&&!cleanKey.startsWith(TELEMETRY_GROUP_PREFIX)&&\n!cleanKey.startsWith(TELEMETRY_LABEL_PREFIX)&&\n!cleanKey.startsWith(TELEMETRY_OVERLAY_PREFIX)&&cleanLabel)\nlabels[cleanKey]=cleanLabel;}}\nreturn{id:String(group&&group.id||fallback.id).replace(/[^A-Za-z0-9_-]/g,\'\').slice(0,32)||fallback.id,\nname:String(group&&group.name||fallback.name).slice(0,48),\nleft:clampNumber(group&&group.left,bounds.left,\nMath.max(bounds.left,bounds.right-width),fallback.left),\ntop:clampNumber(group&&group.top,bounds.top,\nMath.max(bounds.top,bounds.bottom-height),fallback.top),\ncols:normalCols,fontSize:normalFontSize,\nsizeBaselineCols:baselineCols,sizeBaselineFontSize:baselineFontSize,\nshowLabels:group&&typeof group.showLabels===\'boolean\'?group.showLabels:true,\nshowUnits:group&&typeof group.showUnits===\'boolean\'?group.showUnits:true,\nfields:Array.isArray(group&&group.fields)?group.fields.filter(key=>\ntypeof key===\'string\'&&!key.startsWith(TELEMETRY_GROUP_PREFIX)&&\n!key.startsWith(TELEMETRY_LABEL_PREFIX)&&\n!key.startsWith(TELEMETRY_OVERLAY_PREFIX)):[],labels,width,height,\nanchorX:Number.isFinite(anchorX)?clampNumber(anchorX,0,1,0):null,\nanchorY:Number.isFinite(anchorY)?clampNumber(anchorY,0,1,0):null,\nanchorEdges,anchorPending:Boolean(group&&group.anchorPending),\nsharedGeometryNeutral:Boolean(group&&group.sharedGeometryNeutral)};}\nfunction telemetryUtf8ToBase64Url(text){\nconst bytes=new TextEncoder().encode(text);let binary=\'\';\nfor(const value of bytes)binary+=String.fromCharCode(value);\nreturn btoa(binary).replace(/\\+/g,\'-\').replace(/\\//g,\'_\').replace(/=+$/,\'\');}\nfunction telemetryBase64UrlToUtf8(text){\nlet value=String(text||\'\').replace(/-/g,\'+\').replace(/_/g,\'/\');\nwhile(value.length%4)value+=\'=\';\nconst binary=atob(value),bytes=new Uint8Array(binary.length);\nfor(let index=0;index<binary.length;index++)bytes[index]=binary.charCodeAt(index);\nreturn new TextDecoder().decode(bytes);}\nfunction telemetryNormaliseCustomLabel(value){\nreturn String(value==null?\'\':value).replace(/\\s+/g,\' \').trim().slice(0,48);}\nfunction telemetryLabelToken(label){\nlet chars=Array.from(telemetryNormaliseCustomLabel(label)).slice(0,48);\nwhile(chars.length){\nconst token=TELEMETRY_LABEL_PREFIX+telemetryUtf8ToBase64Url(chars.join(\'\'));\nif(token.length<=175)return token;\nchars.pop();}\nreturn\'\';}\nfunction telemetryParseLabelToken(token){\nif(!String(token).startsWith(TELEMETRY_LABEL_PREFIX))return null;\ntry{return telemetryNormaliseCustomLabel(telemetryBase64UrlToUtf8(\nString(token).slice(TELEMETRY_LABEL_PREFIX.length)));}\ncatch(_error){return\'\';}}\nfunction telemetryDisplayLabel(group,key,meta=null){\nconst custom=telemetryNormaliseCustomLabel(group&&group.labels&&group.labels[key]);\nreturn custom||String(meta&&meta.label||key);}\nfunction telemetryCaptureGroupAnchor(\ngroup,element=telemetryGroupElement(group&&group.id)){\nif(!group||!element)return null;\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,true);return null;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingPersist=true;return null;}\nconst rect=element.getBoundingClientRect(),bounds=instrumentViewportBounds();\nif(rect.width<1||rect.height<1)return null;\nconst record=exactPlacementRecord(\nrect.left,rect.top,rect.width,rect.height,bounds);\ngroup.left=record.x;group.top=record.y;\ngroup.anchorX=null;group.anchorY=null;group.anchorEdges=record.e;\nreturn record;}\nfunction telemetryRestoreAllGroupGeometry(){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingRestore=true;return;}\nfor(const group of TELEMETRY_CANVAS.groups){\nconst element=telemetryGroupElement(group.id);\nif(element)telemetryRestoreGroupAnchor(group,element);}}\nfunction telemetryRestoreAllPersistentGeometry(){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingRestore=true;return;}\ntelemetryRestoreAllOverlayGeometry();\ntelemetryRestoreAllGroupGeometry();}\n\nfunction telemetryRestoreGroupAnchor(\ngroup,element=telemetryGroupElement(group&&group.id)){\nif(!group||!element)return false;\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return false;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingRestore=true;return false;}\nconst rect=element.getBoundingClientRect(),bounds=instrumentViewportBounds();\nif(group.anchorX!==null&&group.anchorX!==undefined&&\ngroup.anchorY!==null&&group.anchorY!==undefined&&\nNumber.isFinite(Number(group.anchorX))&&Number.isFinite(Number(group.anchorY))){\nconst legacy={rx:Number(group.anchorX),ry:Number(group.anchorY),\ne:String(group.anchorEdges||\'\'),pw:rect.width,ph:rect.height},\nsnapped=legacyPlacementRect(legacy,bounds);\nif(!snapped)return false;\ngroup.left=snapped.left;group.top=snapped.top;\ngroup.width=rect.width;group.height=rect.height;\ngroup.anchorX=null;group.anchorY=null;\ngroup.anchorEdges=snapped.e||group.anchorEdges||\'\';\ntelemetrySetGroupGeometry(group,element);\nGS_VIEWPORT_TRANSITION_STATE.pendingPersist=true;return true;}\nconst snapped=exactPlacementRect({v:2,x:group.left,y:group.top,\nw:rect.width,h:rect.height,e:group.anchorEdges||\'\'},bounds,\nrect.width,rect.height);\ngroup.left=snapped.left;group.top=snapped.top;\ngroup.width=rect.width;group.height=rect.height;\ntelemetrySetGroupGeometry(group,element);return true;}\nfunction telemetryGroupToken(group){\nlet name=String(group.name||\'Group\').slice(0,48),token=\'\';\nconst baselineCols=Math.round(clampNumber(\ngroup.sizeBaselineCols,1,24,2));\nconst baselineFontSize=Math.round(clampNumber(\ngroup.sizeBaselineFontSize,10,40,17));\ndo{\nconst payload={p:4,i:group.id,n:name,\nbc:baselineCols,bf:baselineFontSize,\nl:group.showLabels?1:0,u:group.showUnits?1:0};\ntoken=TELEMETRY_GROUP_PREFIX+\ntelemetryUtf8ToBase64Url(JSON.stringify(payload));\nif(token.length<=175)return token;\nname=name.slice(0,-1);\n}while(name.length);\nconst payload={p:4,i:group.id,n:\'Group\',\nbc:baselineCols,bf:baselineFontSize,\nl:group.showLabels?1:0,u:group.showUnits?1:0};\nreturn TELEMETRY_GROUP_PREFIX+\ntelemetryUtf8ToBase64Url(JSON.stringify(payload));}\nfunction telemetryParseGroupToken(token,index){\ntry{\nif(!String(token).startsWith(TELEMETRY_GROUP_PREFIX))return null;\nconst payload=JSON.parse(telemetryBase64UrlToUtf8(\nString(token).slice(TELEMETRY_GROUP_PREFIX.length))),\nexact=Number(payload.p)===2&&\nNumber.isFinite(Number(payload.x))&&Number.isFinite(Number(payload.y)),\nbaselineCols=Number(payload.p)>=4?payload.bc:payload.c,\nbaselineFontSize=Number(payload.p)>=4?payload.bf:payload.f,\nhasCompactAnchor=Number.isFinite(Number(payload.a))&&Number.isFinite(Number(payload.b)),\nhasLegacyAnchor=Number.isFinite(Number(payload.rx))&&Number.isFinite(Number(payload.ry)),\nhasAnchor=hasCompactAnchor||hasLegacyAnchor;\nconst group=telemetryNormaliseGroup({\nid:payload.i,name:payload.n,left:payload.x,top:payload.y,\nanchorX:exact?null:(hasCompactAnchor?Number(payload.a)/10000:\n(hasLegacyAnchor?Number(payload.rx):null)),\nanchorY:exact?null:(hasCompactAnchor?Number(payload.b)/10000:\n(hasLegacyAnchor?Number(payload.ry):null)),\nanchorEdges:String(payload.e||\'\'),anchorPending:!exact&&hasAnchor,\ncols:baselineCols,fontSize:baselineFontSize,\nsizeBaselineCols:baselineCols,sizeBaselineFontSize:baselineFontSize,\nshowLabels:Boolean(payload.l),showUnits:Boolean(payload.u),\nfields:[],labels:{},sharedGeometryNeutral:Number(payload.p)>=3},index);\nreturn group;\n}catch(_error){return null;}}\nfunction telemetryGroupsFromConfig(config){\nconst selected=Array.isArray(config&&config.selected_fields)?\nconfig.selected_fields:[],groups=[];let current=null,sawToken=false,pendingLabel=\'\';\nfor(const key of selected){\nif(telemetryParseOverlayToken(key)){pendingLabel=\'\';continue;}\nconst parsed=telemetryParseGroupToken(key,groups.length);\nif(parsed){sawToken=true;current=parsed;groups.push(current);pendingLabel=\'\';continue;}\nconst label=telemetryParseLabelToken(key);\nif(label!==null){pendingLabel=label;continue;}\nif(String(key).startsWith(TELEMETRY_GROUP_PREFIX)||\nString(key).startsWith(TELEMETRY_LABEL_PREFIX)||\nString(key).startsWith(TELEMETRY_OVERLAY_PREFIX)){pendingLabel=\'\';continue;}\nif(current){current.fields.push(key);if(pendingLabel)current.labels[key]=pendingLabel;}\nelse if(groups.length){groups[0].fields.push(key);if(pendingLabel)groups[0].labels[key]=pendingLabel;}\npendingLabel=\'\';}\nif(sawToken&&groups.length)return groups.map(telemetryNormaliseGroup);\nconst layout=config&&config.layout||{},legacy=telemetryNormaliseGroup({\nid:\'g1\',name:\'Group 1\',left:layout.left,top:layout.top,\ncols:layout.columns,fontSize:layout.font_size,\nsizeBaselineCols:layout.columns,sizeBaselineFontSize:layout.font_size,\nshowLabels:layout.show_labels,showUnits:layout.show_units,\nfields:selected.filter(key=>!String(key).startsWith(TELEMETRY_GROUP_PREFIX)&&\n!String(key).startsWith(TELEMETRY_LABEL_PREFIX)&&\n!String(key).startsWith(TELEMETRY_OVERLAY_PREFIX)),labels:{}},0);\nlegacy.sharedGeometryNeutral=false;return[legacy];}\nfunction telemetryConfigFromGroups(){\nconst groups=TELEMETRY_CANVAS.groups.length?\nTELEMETRY_CANVAS.groups:[telemetryDefaultGroup(0)],first=groups[0],\nsharedCols=Math.round(clampNumber(first.sizeBaselineCols,1,24,2)),\nsharedFontSize=Math.round(clampNumber(\nfirst.sizeBaselineFontSize,10,40,17)),\nrows=Math.max(1,Math.ceil(\nMath.max(1,first.fields.length)/Math.max(1,sharedCols))),\nselected=[];\n// Floating overlay geometry is platform-local from V2.8.20 onward.\nfor(const group of groups){\nselected.push(telemetryGroupToken(group));\nfor(const key of group.fields){\nconst labelToken=telemetryLabelToken(group.labels&&group.labels[key]);\nif(labelToken)selected.push(labelToken);\nselected.push(key);}}\nreturn{schema_version:1,visible:Boolean(TELEMETRY_CANVAS.visible),\nlayout:{left:first.left,top:first.top,columns:sharedCols,rows,flow:\'row\',\nfont_size:sharedFontSize,show_labels:first.showLabels,show_units:first.showUnits},\nselected_fields:selected};}\nfunction telemetryGroupById(id){\nreturn TELEMETRY_CANVAS.groups.find(group=>group.id===id)||null;}\nfunction telemetryActiveGroup(){\nreturn telemetryGroupById(TELEMETRY_CANVAS.activeGroupId)||\nTELEMETRY_CANVAS.groups[0]||null;}\nfunction telemetryFieldOwner(key){\nreturn TELEMETRY_CANVAS.groups.find(group=>group.fields.includes(key))||null;}\nfunction telemetrySetActiveGroup(id,refresh=true){\nconst group=telemetryGroupById(id)||TELEMETRY_CANVAS.groups[0];\nif(!group)return;\nTELEMETRY_CANVAS.activeGroupId=group.id;\nif(refresh){\ntelemetryRenderGroupManager();telemetrySyncInputs(true);\ntelemetryRenderFieldList();telemetryRenderSelectedList();\ntelemetryCanvasRender();}}\nfunction telemetryGroupElement(id){\nreturn document.querySelector(\'.gs-telemetry-group[data-group-id="\'+CSS.escape(id)+\'"]\');}\nfunction telemetrySetGroupGeometry(group,element){\nelement.style.left=Math.round(group.left)+\'px\';\nelement.style.top=Math.round(group.top)+\'px\';\nelement.style.setProperty(\'--telemetry-font-size\',group.fontSize+\'px\');\nelement.classList.toggle(\'hide-labels\',!group.showLabels);\nelement.classList.toggle(\'hide-units\',!group.showUnits);\nelement.classList.toggle(\'telemetry-move-mode\',\nTELEMETRY_CANVAS.moveGroupId===group.id);}\nfunction telemetryClampGroup(group,save=false){\nconst element=telemetryGroupElement(group.id);\nif(!element)return;\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,Boolean(save));return;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nif(save)GS_VIEWPORT_TRANSITION_STATE.pendingPersist=true;return;}\nconst bounds=instrumentViewportBounds(),rect=element.getBoundingClientRect(),\nwidth=Math.max(1,rect.width),height=Math.max(1,rect.height),\nrecord=exactPlacementRecord(group.left,group.top,width,height,bounds);\ngroup.width=width;group.height=height;\ngroup.left=record.x;group.top=record.y;\ngroup.anchorEdges=record.e;\ntelemetrySetGroupGeometry(group,element);\nif(save){\ntelemetryCaptureGroupAnchor(group,element);\nrememberStableViewportLayout();telemetryScheduleSave(true);}}\nfunction clampInstrumentGeometry(save=false){\nfor(const group of TELEMETRY_CANVAS.groups)telemetryClampGroup(group,false);\nif(save)telemetryScheduleSave(true);}\nfunction syncTelemetryGridLayout(){telemetryCanvasRender();}\n\nasync function telemetryApi(path,options={}){\nconst response=await fetch(\'/api/groundstation/telemetry/\'+path,{\ncache:\'no-store\',...options,\nheaders:{\'Content-Type\':\'application/json\',...(options.headers||{})}});\nif(!response.ok)throw new Error(\'HTTP \'+response.status);\nreturn await response.json();}\nfunction telemetrySaveStatus(text,bad=false){\nconst node=$(\'telemetrySaveState\');if(!node)return;\nnode.textContent=text||\'\';node.style.color=bad?\'#fca5a5\':\'#86efac\';}\nasync function telemetrySaveNow(){\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(false,true);return;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingPersist=true;return;}\nif(!TELEMETRY_CANVAS.config)return;\nrememberStableViewportLayout();\ntelemetrySavePlatformGroupGeometry();\nTELEMETRY_CANVAS.config=telemetryConfigFromGroups();\ntelemetrySaveStatus(\'Saving…\');\ntry{\nconst payload=await telemetryApi(\'layout\',{\nmethod:\'POST\',body:JSON.stringify(TELEMETRY_CANVAS.config)});\nTELEMETRY_CANVAS.config=payload.config||TELEMETRY_CANVAS.config;\ntelemetrySaveStatus(\'Saved\');\nsetTimeout(()=>telemetrySaveStatus(\'\'),900);\n}catch(error){\ntelemetrySaveStatus(\'Save failed\',true);console.error(error);}}\nfunction telemetryScheduleSave(immediate=false){\nif(TELEMETRY_CANVAS.saveTimer){\nclearTimeout(TELEMETRY_CANVAS.saveTimer);TELEMETRY_CANVAS.saveTimer=null;}\nif(immediate){telemetrySaveNow();return;}\nTELEMETRY_CANVAS.saveTimer=setTimeout(()=>{\nTELEMETRY_CANVAS.saveTimer=null;telemetrySaveNow();},250);}\nfunction telemetryApplyConfig(config){\nTELEMETRY_CANVAS.config=config||{};\n// Ignore legacy shared overlay tokens so desktop and phone cannot overwrite\n// each other\'s floating PiP/HUD geometry.\nTELEMETRY_CANVAS.overlayGeometry={};\nTELEMETRY_CANVAS.groups=telemetryGroupsFromConfig(config);\ntelemetryApplyPlatformGroupGeometry(TELEMETRY_CANVAS.groups);\nTELEMETRY_CANVAS.visible=config&&config.visible!==false;\nif(!telemetryGroupById(TELEMETRY_CANVAS.activeGroupId))\nTELEMETRY_CANVAS.activeGroupId=TELEMETRY_CANVAS.groups[0].id;\ntelemetryCanvasRender();telemetryRenderGroupManager();\ntelemetrySyncInputs(true);telemetryRenderSelectedList();\nconst button=$(\'drawerBtn\');\nif(button)button.classList.toggle(\'active\',TELEMETRY_CANVAS.visible);\nrequestAnimationFrame(()=>{\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingRestore=true;return;}\nif(Object.keys(TELEMETRY_CANVAS.overlayGeometry).length)\ntelemetryRestoreAllPersistentGeometry();\nelse telemetryCaptureAllOverlayGeometry(false);\nrequestAnimationFrame(()=>rememberStableViewportLayout());});}\nfunction telemetryFormat(item,meta){\nif(!item||item.value===null||item.value===undefined)return\'—\';\nconst value=item.value;\nif(typeof value===\'boolean\')return value?\'YES\':\'NO\';\nif(typeof value===\'number\'){\nif(!Number.isFinite(value))return\'—\';\nconst configured=Number(meta&&meta.digits);\nconst digits=Number.isInteger(configured)?configured:\n(Math.abs(value)>=100?0:Math.abs(value)>=10?1:2);\nreturn value.toFixed(digits);}\nif(Array.isArray(value))return value.join(\', \');\nreturn String(value);}\n\nfunction telemetryTileState(key,group){\nconst meta=TELEMETRY_CANVAS.catalogByKey.get(key)||\n{key,label:key.split(\'.\').pop(),unit:\'\',message:\'\'},\nitem=TELEMETRY_CANVAS.values[key],age=item&&Number(item.age_s),\nstale=Number.isFinite(age)&&age>3,\nunavailable=!item||(!Number.isFinite(age)&&item.value==null)||\n(Number.isFinite(age)&&age>10);\nreturn{meta,item,stale,unavailable,\nlabel:telemetryDisplayLabel(group,key,meta),\nvalue:unavailable?\'—\':telemetryFormat(item,meta),\nunit:String(meta.unit||\'\')};}\nfunction telemetryUpdateTile(tile,key,group){\nconst state=telemetryTileState(key,group),\nlabel=tile.querySelector(\'.k\'),\nvalue=tile.querySelector(\'.v\');\nlet changed=false;\ntile.dataset.key=key;\ntile.classList.toggle(\'stale\',state.stale);\ntile.classList.toggle(\'unavailable\',state.unavailable);\nif(label&&label.textContent!==state.label){\nlabel.textContent=state.label;changed=true;}\nlet valueText=value&&value.querySelector(\'.value-text\');\nif(value&&!valueText){\nvalueText=value.querySelector(\'span:not(.unit)\')||document.createElement(\'span\');\nvalueText.className=\'value-text\';\nif(!valueText.parentNode)value.prepend(valueText);}\nif(valueText&&valueText.textContent!==state.value){\nvalueText.textContent=state.value;changed=true;}\nlet unit=value&&value.querySelector(\'.unit\');\nif(state.unit){\nif(!unit){\nunit=document.createElement(\'span\');unit.className=\'unit\';\nvalue.appendChild(unit);changed=true;}\nif(unit.textContent!==state.unit){unit.textContent=state.unit;changed=true;}}\nelse if(unit){unit.remove();changed=true;}\nreturn changed;}\nfunction telemetryCreateTile(key,group){\nconst tile=document.createElement(\'div\');\ntile.className=\'gs-tile\';tile.dataset.key=key;\nconst label=document.createElement(\'span\');label.className=\'k\';\nconst value=document.createElement(\'span\');value.className=\'v\';\nconst valueText=document.createElement(\'span\');\nvalueText.className=\'value-text\';value.appendChild(valueText);\ntile.append(label,value);telemetryUpdateTile(tile,key,group);return tile;}\nfunction telemetryEnsureGroupElement(group){\nconst host=$(\'sidePanel\');let element=telemetryGroupElement(group.id);\nif(element)return element;\nelement=document.createElement(\'aside\');\nelement.className=\'gs-telemetry-group\';\nelement.dataset.groupId=group.id;\nelement.setAttribute(\'aria-label\',\'Telemetry group \'+group.name);\nconst grid=document.createElement(\'div\');\ngrid.className=\'gs-telemetry-group-grid\';\nconst hint=document.createElement(\'div\');\nhint.className=\'gs-telemetry-group-move-hint\';\nhint.textContent=\'DRAG TO MOVE · CORNER TO RESIZE\';\nconst handle=document.createElement(\'button\');\nhandle.type=\'button\';handle.className=\'gs-telemetry-group-resize-handle\';\nhandle.setAttribute(\'aria-label\',\'Resize telemetry group\');\nelement.append(grid,hint,handle);host.appendChild(element);\ntelemetryAttachGroupGestures(element);return element;}\nfunction telemetryMeasureAndClamp(group,element){\nrequestAnimationFrame(()=>requestAnimationFrame(()=>{\nif(!document.body.contains(element))return;\nconst rect=element.getBoundingClientRect();\ngroup.width=Math.max(1,rect.width);group.height=Math.max(1,rect.height);\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingRestore=true;return;}\ntelemetryRestoreGroupAnchor(group,element);\ngroup.anchorPending=false;\nrememberStableViewportLayout();}));}\nfunction telemetryScheduleValueGeometry(group,element){\nif(!group||!element||TELEMETRY_CANVAS.valueMeasureRaf.has(group.id))return;\nconst frame=requestAnimationFrame(()=>{\nTELEMETRY_CANVAS.valueMeasureRaf.delete(group.id);\nif(!document.body.contains(element))return;\nconst rect=element.getBoundingClientRect(),\nwidth=Math.max(1,rect.width),height=Math.max(1,rect.height);\nif(Math.abs(width-(Number(group.width)||0))<.5&&\nMath.abs(height-(Number(group.height)||0))<.5)return;\ngroup.width=width;group.height=height;\nif(!groundStationGeometryViewportUsable()){\ndeferGroundStationGeometryUntilLandscape(true,false);return;}\nif(GS_VIEWPORT_TRANSITION_STATE.active){\nGS_VIEWPORT_TRANSITION_STATE.pendingRestore=true;return;}\ntelemetryRestoreGroupAnchor(group,element);\nrememberStableViewportLayout();});\nTELEMETRY_CANVAS.valueMeasureRaf.set(group.id,frame);}\nfunction telemetryRenderGroup(group){\nconst element=telemetryEnsureGroupElement(group),\ngrid=element.querySelector(\'.gs-telemetry-group-grid\'),\ncount=Math.max(1,group.fields.length),\ncolumns=Math.max(1,Math.min(group.cols,count)),\nrows=Math.max(1,Math.ceil(count/columns)),\ncolumnGap=columns>1?\nMath.round(clampNumber(group.fontSize*.72,10,24,12)):0,\nrowGap=rows>1?\nMath.round(clampNumber(group.fontSize*.38,6,14,7)):0;\nelement.style.display=TELEMETRY_CANVAS.visible?\'block\':\'none\';\nelement.setAttribute(\'aria-label\',\'Telemetry group \'+group.name);\ntelemetrySetGroupGeometry(group,element);\ngrid.style.gridTemplateColumns=\'repeat(\'+columns+\',max-content)\';\ngrid.style.setProperty(\'--telemetry-column-gap\',columnGap+\'px\');\ngrid.style.setProperty(\'--telemetry-row-gap\',rowGap+\'px\');\nconst fragment=document.createDocumentFragment();\nfor(const key of group.fields)fragment.appendChild(telemetryCreateTile(key,group));\ngrid.replaceChildren(fragment);\ntelemetryMeasureAndClamp(group,element);}\nfunction telemetryRefreshGroupValues(group){\nconst element=telemetryGroupElement(group.id),\ngrid=element&&element.querySelector(\'.gs-telemetry-group-grid\');\nif(!element||!grid)return;\nconst tiles=[...grid.children],\nstructureMatches=tiles.length===group.fields.length&&\ngroup.fields.every((key,index)=>tiles[index]&&tiles[index].dataset.key===key);\nif(!structureMatches){telemetryRenderGroup(group);return;}\nlet changed=false;\ngroup.fields.forEach((key,index)=>{\nif(telemetryUpdateTile(tiles[index],key,group))changed=true;});\nif(changed)telemetryScheduleValueGeometry(group,element);}\nfunction telemetryRefreshDisplayedValues(){\nfor(const group of TELEMETRY_CANVAS.groups)telemetryRefreshGroupValues(group);}\nfunction telemetryCanvasRender(){\nsetTopBannerToggleState(\'drawerBtn\',Boolean(TELEMETRY_CANVAS.visible),\'Telemetry\');\nconst host=$(\'sidePanel\');\nif(!host||!TELEMETRY_CANVAS.config)return;\nconst valid=new Set(TELEMETRY_CANVAS.groups.map(group=>group.id));\nhost.querySelectorAll(\'.gs-telemetry-group\').forEach(element=>{\nif(!valid.has(element.dataset.groupId))element.remove();});\nfor(const group of TELEMETRY_CANVAS.groups)telemetryRenderGroup(group);}\nasync function telemetryPollValues(){\nif(TELEMETRY_CANVAS.valuePollInFlight)return;\nTELEMETRY_CANVAS.valuePollInFlight=true;\ntry{\nconst payload=await telemetryApi(\'values\');\nTELEMETRY_CANVAS.values=payload.values||{};\ntelemetryRefreshDisplayedValues();\nif(TELEMETRY_CANVAS.editorOpen)telemetryRenderFieldList();\n}catch(error){console.debug(\'Telemetry values unavailable\',error);}\nfinally{TELEMETRY_CANVAS.valuePollInFlight=false;}}\n/* GROUND_STATION_CANONICAL_QGC_TELEMETRY_V4_1_0 */\nfunction telemetryCanonicalSort(left,right){\nconst leftNormalized=String(left.key||\'\').startsWith(\'norm.\');\nconst rightNormalized=String(right.key||\'\').startsWith(\'norm.\');\nif(leftNormalized!==rightNormalized)return leftNormalized?-1:1;\nconst categoryCompare=String(left.category||\'\').localeCompare(String(right.category||\'\'),undefined,{sensitivity:\'base\'});\nif(categoryCompare)return categoryCompare;\nreturn String(left.label||\'\').localeCompare(String(right.label||\'\'),undefined,{sensitivity:\'base\'});\n}\nasync function telemetryLoadCatalog(){\nif(TELEMETRY_CANVAS.catalog.length)return;\nconst payload=await telemetryApi(\'catalog\');\nTELEMETRY_CANVAS.catalog=(Array.isArray(payload.fields)?payload.fields:[]).slice().sort(telemetryCanonicalSort);\nTELEMETRY_CANVAS.catalogByKey=new Map(TELEMETRY_CANVAS.catalog.map(item=>[item.key,item]));\ntelemetryCanvasRender();telemetryRenderFieldList();telemetryRenderSelectedList();}\n\nfunction telemetryFieldSelected(key){\nconst group=telemetryActiveGroup();\nreturn Boolean(group&&group.fields.includes(key));}\nfunction telemetryToggleField(key,enabled){\nconst active=telemetryActiveGroup();if(!active)return;\nlet preservedLabel=\'\';\nfor(const group of TELEMETRY_CANVAS.groups){\nconst index=group.fields.indexOf(key);\nif(index>=0){\nif(!preservedLabel)preservedLabel=telemetryNormaliseCustomLabel(\ngroup.labels&&group.labels[key]);\ngroup.fields.splice(index,1);}\nif(group.labels)delete group.labels[key];}\nif(enabled){active.fields.push(key);if(preservedLabel)active.labels[key]=preservedLabel;}\ntelemetryCanvasRender();telemetryRenderFieldList();\ntelemetryRenderSelectedList();telemetryScheduleSave();}\nconst TELEMETRY_QGC_CATEGORY_ORDER=[\'Flight\',\'Navigation\',\'Attitude\',\'Battery\',\'GPS\',\'Wind\',\'Radio\',\'Vehicle\'];\nconst TELEMETRY_ADVANCED_PAGE_SIZE=300;\nconst TELEMETRY_LIVE_AGE_SECONDS=5;\nfunction telemetryIsQgcField(meta){return String(meta&&meta.key||\'\').startsWith(\'norm.\');}\nfunction telemetryValueState(key){\nconst entry=TELEMETRY_CANVAS.values&&TELEMETRY_CANVAS.values[key];\nif(!entry)return\'defined\';\nif(entry.age_s===null||entry.age_s===undefined)return\'seen\';\nconst age=Number(entry.age_s);\nreturn Number.isFinite(age)&&age<=TELEMETRY_LIVE_AGE_SECONDS?\'live\':\'seen\';}\nfunction telemetryFieldMatches(meta,query){\nif(!query)return true;\nconst values=TELEMETRY_CANVAS.scope===\'qgc\'?\n[meta.label,meta.category]:\n[meta.label,meta.category,meta.message,meta.field,meta.key];\nreturn values.some(value=>String(value||\'\').toLowerCase().includes(query));}\nfunction telemetryCategoryName(meta){\nif(TELEMETRY_CANVAS.scope===\'qgc\')return String(meta.category||\'Other\');\nreturn String(meta.category||meta.message||\'Other MAVLink\');}\nfunction telemetryCategoryOrder(names){\nif(TELEMETRY_CANVAS.scope!==\'qgc\')return names.sort((a,b)=>a.localeCompare(b,undefined,{sensitivity:\'base\'}));\nreturn names.sort((a,b)=>{\nconst ai=TELEMETRY_QGC_CATEGORY_ORDER.indexOf(a),bi=TELEMETRY_QGC_CATEGORY_ORDER.indexOf(b);\nif(ai!==bi)return(ai<0?999:ai)-(bi<0?999:bi);\nreturn a.localeCompare(b,undefined,{sensitivity:\'base\'});});}\nfunction telemetryCreateCountStat(label,value){\nconst span=document.createElement(\'span\');span.className=\'gs-telemetry-count-stat\';\nspan.append(document.createTextNode(label+\' \'));\nconst strong=document.createElement(\'strong\');strong.textContent=String(value);span.append(strong);\nreturn span;}\nfunction telemetryUpdateCountCard(){\nconst card=$(\'telemetryCountCard\');if(!card)return;\nconst catalog=TELEMETRY_CANVAS.catalog||[],availableSet=new Set(Object.keys(TELEMETRY_CANVAS.values||{}));\nconst qgcCount=catalog.filter(telemetryIsQgcField).length,\nadvancedCount=catalog.length-qgcCount,\nreceivedCount=catalog.filter(meta=>availableSet.has(meta.key)).length,\nliveCount=catalog.filter(meta=>telemetryValueState(meta.key)===\'live\').length;\nconst help=document.createElement(\'span\');help.className=\'gs-telemetry-count-help\';\nhelp.textContent=\'Received this session means the Ground Station currently holds a value; yellow SEEN values may be stale. All defined is the full installed ArduPilot MAVLink dialect, including array elements—most aircraft never transmit all of it.\';\ncard.replaceChildren(\ntelemetryCreateCountStat(\'Categorized values\',qgcCount),\ntelemetryCreateCountStat(\'Received\',receivedCount+\' / \'+catalog.length),\ntelemetryCreateCountStat(\'Live ≤5 s\',liveCount),\ntelemetryCreateCountStat(\'Advanced\',advancedCount),\ntelemetryCreateCountStat(\'All defined\',catalog.length),help);}\nfunction telemetryCreateFieldRow(meta,active,selectedSet){\nconst owner=telemetryFieldOwner(meta.key),row=document.createElement(\'label\');\nrow.className=\'gs-telemetry-field\';\nconst checkbox=document.createElement(\'input\');\ncheckbox.type=\'checkbox\';checkbox.checked=selectedSet.has(meta.key);\ncheckbox.addEventListener(\'change\',()=>telemetryToggleField(meta.key,checkbox.checked));\nconst text=document.createElement(\'span\'),title=document.createElement(\'strong\'),detail=document.createElement(\'small\');\ntitle.textContent=meta.label||meta.field||meta.key;\nif(TELEMETRY_CANVAS.scope===\'qgc\')detail.textContent=[meta.category,meta.unit].filter(Boolean).join(\' · \');\nelse detail.textContent=[meta.category,meta.field,meta.unit].filter(Boolean).join(\' · \');\ntext.append(title,detail);\nconst status=document.createElement(\'span\');\nif(owner&&owner.id!==active.id){status.className=\'defined\';status.textContent=\'IN \'+owner.name.toUpperCase();}\nelse{\nconst state=telemetryValueState(meta.key);status.className=state;\nstatus.textContent=state===\'live\'?\'LIVE\':state===\'seen\'?\'SEEN\':\'DEFINED\';\nconst entry=TELEMETRY_CANVAS.values&&TELEMETRY_CANVAS.values[meta.key];\nif(entry&&entry.age_s!==null&&entry.age_s!==undefined&&Number.isFinite(Number(entry.age_s)))status.title=\'Last update \'+Number(entry.age_s).toFixed(1)+\' seconds ago\';}\nrow.append(checkbox,text,status);return row;}\nfunction telemetryRenderFieldList(){\nconst list=$(\'telemetryFieldList\'),note=$(\'telemetryResultNote\'),loadWrap=$(\'telemetryLoadMoreWrap\'),\nactive=telemetryActiveGroup();if(!list||!note||!active)return;\ntelemetryUpdateCountCard();\nconst query=TELEMETRY_CANVAS.search.trim().toLowerCase(),selectedSet=new Set(active.fields),\navailableSet=new Set(Object.keys(TELEMETRY_CANVAS.values||{})),qgcScope=TELEMETRY_CANVAS.scope===\'qgc\';\nlet fields=TELEMETRY_CANVAS.catalog.filter(meta=>telemetryIsQgcField(meta)===qgcScope).filter(meta=>{\nif(TELEMETRY_CANVAS.filter===\'available\'&&!availableSet.has(meta.key))return false;\nif(TELEMETRY_CANVAS.filter===\'selected\'&&!selectedSet.has(meta.key))return false;\nreturn telemetryFieldMatches(meta,query);});\nconst total=fields.length,limit=qgcScope?total:Math.max(TELEMETRY_ADVANCED_PAGE_SIZE,Number(TELEMETRY_CANVAS.renderLimit)||TELEMETRY_ADVANCED_PAGE_SIZE),shown=fields.slice(0,limit);\nconst allScopeCount=TELEMETRY_CANVAS.catalog.filter(meta=>telemetryIsQgcField(meta)===qgcScope).length,\nreceivedScopeCount=TELEMETRY_CANVAS.catalog.filter(meta=>telemetryIsQgcField(meta)===qgcScope&&availableSet.has(meta.key)).length;\nif(qgcScope)note.textContent=total+\' categorized values in grouped sections · \'+receivedScopeCount+\' of \'+allScopeCount+\' received this session · editing \'+active.name;\nelse note.textContent=(shown.length<total?\'Showing \'+shown.length+\' of \'+total:\'Showing \'+total)+\' advanced MAVLink fields · \'+receivedScopeCount+\' of \'+allScopeCount+\' received this session · editing \'+active.name;\nconst fullCounts=new Map();for(const meta of fields){const name=telemetryCategoryName(meta);fullCounts.set(name,(fullCounts.get(name)||0)+1);}\nconst groups=new Map();for(const meta of shown){const name=telemetryCategoryName(meta);if(!groups.has(name))groups.set(name,[]);groups.get(name).push(meta);}\nconst fragment=document.createDocumentFragment();\nfor(const name of telemetryCategoryOrder([...groups.keys()])){\nconst metas=groups.get(name),section=document.createElement(\'section\');section.className=\'gs-telemetry-category\';\nconst header=document.createElement(\'button\');header.type=\'button\';header.className=\'gs-telemetry-category-head\';\nconst collapseKey=TELEMETRY_CANVAS.scope+\':\'+name,collapsed=!query&&TELEMETRY_CANVAS.collapsedGroups.has(collapseKey);\nheader.setAttribute(\'aria-expanded\',collapsed?\'false\':\'true\');\nconst title=document.createElement(\'span\');title.className=\'category-name\';title.textContent=name;\nconst count=document.createElement(\'span\');count.className=\'category-count\';\nconst received=metas.filter(meta=>availableSet.has(meta.key)).length,live=metas.filter(meta=>telemetryValueState(meta.key)===\'live\').length,full=fullCounts.get(name)||metas.length;\ncount.textContent=full+\' values · \'+received+\' received · \'+live+\' live\';header.append(title,count);\nconst body=document.createElement(\'div\');body.className=\'gs-telemetry-category-body\';body.hidden=collapsed;\nfor(const meta of metas)body.appendChild(telemetryCreateFieldRow(meta,active,selectedSet));\nheader.addEventListener(\'click\',()=>{if(TELEMETRY_CANVAS.collapsedGroups.has(collapseKey))TELEMETRY_CANVAS.collapsedGroups.delete(collapseKey);else TELEMETRY_CANVAS.collapsedGroups.add(collapseKey);body.hidden=!body.hidden;header.setAttribute(\'aria-expanded\',body.hidden?\'false\':\'true\');});\nsection.append(header,body);fragment.appendChild(section);}\nif(!shown.length){const empty=document.createElement(\'div\');empty.className=\'gs-telemetry-result-note\';empty.textContent=\'No fields match this scope, filter and search.\';fragment.appendChild(empty);}\nlist.replaceChildren(fragment);\nif(loadWrap){loadWrap.hidden=qgcScope||shown.length>=total;const button=$(\'telemetryLoadMore\');if(button)button.textContent=\'Load \'+Math.min(TELEMETRY_ADVANCED_PAGE_SIZE,total-shown.length)+\' more\';}}\n\nfunction telemetryRenderSelectedList(){\nconst host=$(\'telemetrySelectedList\'),active=telemetryActiveGroup();\nif(!host||!active)return;\nconst fragment=document.createDocumentFragment();\nactive.fields.forEach((key,index)=>{\nconst meta=TELEMETRY_CANVAS.catalogByKey.get(key)||{label:key},\nrow=document.createElement(\'div\');\nrow.className=\'gs-telemetry-selected-item\';\nconst input=document.createElement(\'input\');\ninput.type=\'text\';input.className=\'gs-telemetry-label-input\';\ninput.maxLength=48;input.value=active.labels&&active.labels[key]||\'\';\ninput.placeholder=String(meta.label||key);input.title=String(meta.label||key);\ninput.setAttribute(\'aria-label\',\'Custom telemetry label for \'+String(meta.label||key));\ninput.addEventListener(\'input\',()=>{\nconst value=telemetryNormaliseCustomLabel(input.value);\nif(value)active.labels[key]=value;else delete active.labels[key];\ntelemetryCanvasRender();telemetryScheduleSave();});\ninput.addEventListener(\'blur\',()=>{\nconst value=telemetryNormaliseCustomLabel(input.value);\ninput.value=value;if(value)active.labels[key]=value;else delete active.labels[key];\ntelemetryCanvasRender();telemetryScheduleSave(true);});\nconst up=document.createElement(\'button\');up.type=\'button\';up.textContent=\'↑\';\nup.disabled=index===0;up.title=\'Move value up\';\nup.addEventListener(\'click\',()=>telemetryMoveSelected(index,-1));\nconst down=document.createElement(\'button\');down.type=\'button\';down.textContent=\'↓\';\ndown.disabled=index===active.fields.length-1;down.title=\'Move value down\';\ndown.addEventListener(\'click\',()=>telemetryMoveSelected(index,1));\nconst remove=document.createElement(\'button\');remove.type=\'button\';\nremove.textContent=\'×\';remove.title=\'Remove value\';\nremove.addEventListener(\'click\',()=>telemetryToggleField(key,false));\nrow.append(input,up,down,remove);fragment.appendChild(row);});\nhost.replaceChildren(fragment);}\nfunction telemetryMoveSelected(index,delta){\nconst active=telemetryActiveGroup();if(!active)return;\nconst target=index+delta;\nif(target<0||target>=active.fields.length)return;\n[active.fields[index],active.fields[target]]=\n[active.fields[target],active.fields[index]];\ntelemetryCanvasRender();telemetryRenderSelectedList();telemetryScheduleSave();}\nfunction telemetryRenderGroupManager(){\nconst select=$(\'telemetryGroupSelect\');if(!select)return;\nconst active=telemetryActiveGroup();select.replaceChildren();\nfor(const group of TELEMETRY_CANVAS.groups){\nconst option=document.createElement(\'option\');\noption.value=group.id;option.textContent=group.name;\nselect.appendChild(option);}\nif(active)select.value=active.id;\nconst deleteButton=$(\'telemetryGroupDelete\');\nif(deleteButton)deleteButton.disabled=TELEMETRY_CANVAS.groups.length<=1;}\nfunction telemetryAddGroup(){\nconst group=telemetryDefaultGroup(TELEMETRY_CANVAS.groups.length);\ngroup.name=\'Group \'+(TELEMETRY_CANVAS.groups.length+1);\nTELEMETRY_CANVAS.groups.push(group);TELEMETRY_CANVAS.visible=true;\ntelemetrySetActiveGroup(group.id);telemetryScheduleSave(true);}\nfunction telemetryRenameGroup(){\nconst group=telemetryActiveGroup();if(!group)return;\nconst name=prompt(\'Group name\',group.name);\nif(name===null)return;\nconst cleaned=String(name).trim().slice(0,48);\nif(cleaned)group.name=cleaned;\ntelemetryRenderGroupManager();telemetryCanvasRender();telemetryScheduleSave(true);}\nfunction telemetryDeleteGroup(){\nconst group=telemetryActiveGroup();if(!group||TELEMETRY_CANVAS.groups.length<=1)return;\nif(!confirm(\'Delete "\'+group.name+\'" and remove its telemetry values?\'))return;\nconst index=TELEMETRY_CANVAS.groups.indexOf(group);\nTELEMETRY_CANVAS.groups.splice(index,1);\nTELEMETRY_CANVAS.activeGroupId=\nTELEMETRY_CANVAS.groups[Math.max(0,index-1)].id;\nif(TELEMETRY_CANVAS.moveGroupId===group.id)TELEMETRY_CANVAS.moveGroupId=null;\ntelemetryCanvasRender();telemetryRenderGroupManager();telemetrySyncInputs(true);\ntelemetryRenderFieldList();telemetryRenderSelectedList();telemetryScheduleSave(true);}\nfunction telemetrySetTab(name){\ndocument.querySelectorAll(\'[data-telemetry-tab]\').forEach(button=>\nbutton.classList.toggle(\'active\',button.dataset.telemetryTab===name));\ndocument.querySelectorAll(\'[data-telemetry-pane]\').forEach(pane=>\npane.classList.toggle(\'active\',pane.dataset.telemetryPane===name));\nif(name===\'data\')telemetryLoadCatalog()\n.catch(()=>telemetrySaveStatus(\'Catalogue failed\',true));}\nfunction telemetrySetNumericInputValue(id,value,force=false){\nconst node=$(id);if(!node)return;\nif(!force&&document.activeElement===node&&\nnode.dataset.telemetryEditing===\'1\')return;\nnode.value=String(value);}\nfunction telemetrySyncInputs(force=false){\nconst group=telemetryActiveGroup();if(!group)return;\ntelemetrySetNumericInputValue(\'telemetryColsInput\',group.cols,force);\ntelemetrySetNumericInputValue(\'telemetryFontInput\',group.fontSize,force);\n$(\'telemetryLabelInput\').checked=group.showLabels;\n$(\'telemetryUnitInput\').checked=group.showUnits;}\nfunction telemetryEditableInteger(id,min,max,fallback,commit=false){\nconst node=$(id),raw=String(node&&node.value!=null?node.value:\'\').trim();\nif(raw===\'\'||raw===\'-\'||raw===\'+\'||raw===\'.\'||raw===\'-.\'||raw===\'+.\' ){\nif(commit&&node)node.value=String(fallback);return commit?fallback:null;}\nconst parsed=Number(raw);\nif(!Number.isFinite(parsed)){\nif(commit&&node)node.value=String(fallback);return commit?fallback:null;}\nif(!commit&&(parsed<min||parsed>max))return null;\nconst value=Math.round(clampNumber(parsed,min,max,fallback));\nif(commit&&node)node.value=String(value);return value;}\nfunction telemetryReadInputs(_event=null,commit=false){\nconst group=telemetryActiveGroup();if(!group)return;\nconst cols=telemetryEditableInteger(\n\'telemetryColsInput\',1,24,group.cols,commit),\nfontSize=telemetryEditableInteger(\n\'telemetryFontInput\',10,40,group.fontSize,commit);\nif(cols!==null)group.cols=cols;if(fontSize!==null)group.fontSize=fontSize;\ngroup.showLabels=$(\'telemetryLabelInput\').checked;\ngroup.showUnits=$(\'telemetryUnitInput\').checked;\ntelemetryCanvasRender();telemetryScheduleSave();\nif(commit)telemetrySyncInputs(true);}\nfunction telemetryCommitNumericInputs(){\nfor(const id of[\'telemetryColsInput\',\'telemetryFontInput\']){\nconst node=$(id);if(node)delete node.dataset.telemetryEditing;}\ntelemetryReadInputs(null,true);}\nfunction setTelemetryMoveMode(groupId){\nTELEMETRY_CANVAS.moveGroupId=groupId&&telemetryGroupById(groupId)?groupId:null;\ntelemetryCanvasRender();\nif(!TELEMETRY_CANVAS.moveGroupId)telemetryScheduleSave(true);}\nfunction setTelemetrySettingsOpen(open,groupId=null){\nif(open&&performance.now()<TELEMETRY_CANVAS.editorBlockedUntil)return;\nif(!open&&TELEMETRY_CANVAS.editorOpen)telemetryCommitNumericInputs();\nif(open&&groupId)telemetrySetActiveGroup(groupId,false);\nTELEMETRY_CANVAS.editorOpen=Boolean(open);\nconst settings=$(\'telemetrySettings\');\nsettings.classList.toggle(\'open\',open);\nsettings.setAttribute(\'aria-hidden\',open?\'false\':\'true\');\nif(open){\nsetTelemetryMoveMode(null);telemetryRenderGroupManager();\ntelemetrySyncInputs(true);telemetrySetTab(\'layout\');\ntelemetryLoadCatalog().catch(()=>telemetrySaveStatus(\'Catalogue failed\',true));\ntelemetryRenderFieldList();telemetryRenderSelectedList();}\nelse telemetryScheduleSave(true);}\nfunction toggleInstruments(){\nTELEMETRY_CANVAS.visible=!TELEMETRY_CANVAS.visible;\nif(!TELEMETRY_CANVAS.visible){\nsetTelemetrySettingsOpen(false);setTelemetryMoveMode(null);}\ntelemetryCanvasRender();\nsetTopBannerToggleState(\'drawerBtn\',TELEMETRY_CANVAS.visible,\'Telemetry\');\ntelemetryScheduleSave(true);}\nfunction telemetryResetDefaults(){\nif(!confirm(\'Restore one default telemetry group and default fields?\'))return;\nconst group=telemetryDefaultGroup(0);\ngroup.id=\'g1\';group.name=\'Group 1\';\ngroup.fields=[\'norm.speed.airspeed_kmh\',\'norm.speed.groundspeed_kmh\',\n\'norm.position.relative_alt_m\',\'norm.speed.vertical_speed_m_s\',\n\'norm.battery.voltage_v\',\'norm.battery.remaining_pct\',\n\'norm.battery.consumed_mah\',\'norm.attitude.heading_deg\',\n\'norm.speed.throttle_pct\',\'norm.gps.satellites\',\n\'norm.navigation.home_distance_m\',\'norm.wind.speed_m_s\'];\nTELEMETRY_CANVAS.groups=[group];TELEMETRY_CANVAS.activeGroupId=group.id;\nTELEMETRY_CANVAS.visible=true;telemetryCanvasRender();\ntelemetryRenderGroupManager();telemetrySyncInputs(true);\ntelemetryRenderSelectedList();telemetryScheduleSave(true);}\nfunction initTelemetryButton(){\nconst button=$(\'drawerBtn\');\nbutton.addEventListener(\'click\',toggleInstruments);\nbutton.addEventListener(\'contextmenu\',event=>event.preventDefault());}\n\nfunction telemetryAttachGroupGestures(element){\nif(element.dataset.groupGestureReady===\'1\')return;\nelement.dataset.groupGestureReady=\'1\';\nconst handle=element.querySelector(\'.gs-telemetry-group-resize-handle\');\nlet pointerId=null,start=null,holdTimer=null,holdTriggered=false,action=null,\nlastTapTime=0,lastTapX=0,lastTapY=0;\nconst HOLD_MS=600,HOLD_TOLERANCE_PX=24;\nconst group=()=>telemetryGroupById(element.dataset.groupId);\nconst clearHold=()=>{\nif(holdTimer){clearTimeout(holdTimer);holdTimer=null;}};\nconst release=()=>{\nif(pointerId===null)return;\ntry{if(element.hasPointerCapture(pointerId))\nelement.releasePointerCapture(pointerId);}catch(_error){}\npointerId=null;start=null;holdTriggered=false;action=null;clearHold();};\nconst beginAction=(event,type,fromHold=false)=>{\nconst current=group();if(!current)return;\npointerId=event.pointerId;\nstart={x:event.clientX,y:event.clientY};\naction={type,fromHold,moved:false,left:current.left,top:current.top,\nfontSize:current.fontSize,width:Math.max(1,current.width),\nheight:Math.max(1,current.height)};\ntry{element.setPointerCapture(pointerId);}catch(_error){}\nevent.preventDefault();event.stopPropagation();};\nelement.addEventListener(\'pointerdown\',event=>{\nconst current=group();if(!current||\n(event.button!==undefined&&event.button!==0))return;\nTELEMETRY_CANVAS.activeGroupId=current.id;\nif(TELEMETRY_CANVAS.editorOpen)return;\nif(TELEMETRY_CANVAS.moveGroupId===current.id){\nbeginAction(event,event.target===handle?\'resize\':\'move\',false);return;}\npointerId=event.pointerId;\nstart={x:event.clientX,y:event.clientY,\ncurrentX:event.clientX,currentY:event.clientY};\nholdTriggered=false;\ntry{element.setPointerCapture(pointerId);}catch(_error){}\nholdTimer=setTimeout(()=>{\nif(!start||pointerId!==event.pointerId)return;\nholdTimer=null;holdTriggered=true;\nTELEMETRY_CANVAS.editorBlockedUntil=performance.now()+1400;\nsetTelemetrySettingsOpen(false);setTelemetryMoveMode(current.id);\naction={type:\'move\',fromHold:true,moved:false,left:current.left,top:current.top,\nfontSize:current.fontSize,width:Math.max(1,current.width),\nheight:Math.max(1,current.height)};\nstart={x:start.currentX,y:start.currentY,\ncurrentX:start.currentX,currentY:start.currentY};\nif(navigator.vibrate)navigator.vibrate(25);},HOLD_MS);\nevent.preventDefault();\n},{passive:false});\nelement.addEventListener(\'pointermove\',event=>{\nif(event.pointerId!==pointerId||!start)return;\nif(!action){\nstart.currentX=event.clientX;start.currentY=event.clientY;\nif(holdTimer&&Math.hypot(\nevent.clientX-start.x,event.clientY-start.y)>HOLD_TOLERANCE_PX)release();\nreturn;}\nconst current=group();if(!current)return;\nconst dx=event.clientX-start.x,dy=event.clientY-start.y;\nif(Math.hypot(dx,dy)>3)action.moved=true;\nif(!action.moved)return;\nif(action.type===\'move\'){\ncurrent.left=action.left+dx;current.top=action.top+dy;\ntelemetrySetGroupGeometry(current,element);telemetryClampGroup(current,false);\n}else{\nconst denominator=action.width*action.width+action.height*action.height,\nscale=denominator>0?\n((action.width*(action.width+dx))+\n(action.height*(action.height+dy)))/denominator:1;\ncurrent.fontSize=Math.round(clampNumber(\naction.fontSize*scale,10,40,action.fontSize));\ntelemetrySetGroupGeometry(current,element);\ntelemetryRenderGroup(current);telemetrySyncInputs();}\nevent.preventDefault();\n},{passive:false});\nelement.addEventListener(\'pointerup\',event=>{\nif(event.pointerId!==pointerId||!start)return;\nconst current=group(),now=performance.now(),wasHold=holdTriggered,\nwasAction=Boolean(action),wasMoved=Boolean(action&&action.moved),\nfromHold=Boolean(action&&action.fromHold),\ntapX=event.clientX,tapY=event.clientY,\ntravel=Math.hypot(tapX-start.x,tapY-start.y);\nclearHold();\ntry{element.releasePointerCapture(pointerId);}catch(_error){}\npointerId=null;start=null;holdTriggered=false;action=null;\nif(current&&wasAction){\ntelemetryClampGroup(current,false);telemetryScheduleSave(true);\nif(!wasMoved&&!fromHold)setTelemetryMoveMode(null);\nreturn;}\nif(wasHold||travel>HOLD_TOLERANCE_PX)return;\nconst isDouble=lastTapTime>0&&now-lastTapTime<=360&&\nMath.hypot(tapX-lastTapX,tapY-lastTapY)<=24;\nif(isDouble){\nlastTapTime=0;setTelemetryMoveMode(null);\nsetTelemetrySettingsOpen(true,current&&current.id);\nif(navigator.vibrate)navigator.vibrate(18);\n}else{lastTapTime=now;lastTapX=tapX;lastTapY=tapY;}\n},{passive:false});\nelement.addEventListener(\'pointercancel\',release,{passive:true});\nelement.addEventListener(\'contextmenu\',event=>event.preventDefault());}\n\nfunction initMovableInstruments(){\nconst settings=$(\'telemetrySettings\');\nfor(const type of [\'pointerdown\',\'pointermove\',\'pointerup\',\'click\',\'wheel\',\'touchstart\',\'touchmove\']){\nsettings.addEventListener(type,event=>event.stopPropagation(),{passive:type!==\'touchmove\'});}\n$(\'telemetrySettingsClose\').addEventListener(\'click\',()=>\nsetTelemetrySettingsOpen(false));\n$(\'telemetrySettingsApply\').addEventListener(\'click\',()=>\nsetTelemetrySettingsOpen(false));\n$(\'telemetrySettingsReset\').addEventListener(\'click\',telemetryResetDefaults);\n$(\'telemetryArrangeBtn\').addEventListener(\'click\',event=>{\nevent.preventDefault();event.stopPropagation();\nconst group=telemetryActiveGroup();if(!group)return;\nTELEMETRY_CANVAS.visible=true;$(\'drawerBtn\').classList.add(\'active\');\nsetTelemetrySettingsOpen(false);setTelemetryMoveMode(group.id);});\n$(\'telemetryGroupSelect\').addEventListener(\'change\',event=>\ntelemetrySetActiveGroup(event.target.value));\n$(\'telemetryGroupAdd\').addEventListener(\'click\',telemetryAddGroup);\n$(\'telemetryGroupRename\').addEventListener(\'click\',telemetryRenameGroup);\n$(\'telemetryGroupDelete\').addEventListener(\'click\',telemetryDeleteGroup);\ndocument.querySelectorAll(\'[data-telemetry-tab]\').forEach(button=>\nbutton.addEventListener(\'click\',()=>telemetrySetTab(button.dataset.telemetryTab)));\ndocument.querySelectorAll(\'[data-telemetry-scope]\').forEach(button=>\nbutton.addEventListener(\'click\',()=>{\nTELEMETRY_CANVAS.scope=button.dataset.telemetryScope===\'advanced\'?\'advanced\':\'qgc\';\nTELEMETRY_CANVAS.renderLimit=TELEMETRY_ADVANCED_PAGE_SIZE;\ndocument.querySelectorAll(\'[data-telemetry-scope]\').forEach(item=>\nitem.classList.toggle(\'active\',item===button));\ntelemetryRenderFieldList();}));\ndocument.querySelectorAll(\'[data-telemetry-filter]\').forEach(button=>\nbutton.addEventListener(\'click\',()=>{\nTELEMETRY_CANVAS.filter=button.dataset.telemetryFilter;\nTELEMETRY_CANVAS.renderLimit=TELEMETRY_ADVANCED_PAGE_SIZE;\ndocument.querySelectorAll(\'[data-telemetry-filter]\').forEach(item=>\nitem.classList.toggle(\'active\',item===button));\ntelemetryRenderFieldList();}));\n$(\'telemetrySearchInput\').addEventListener(\'input\',event=>{\nTELEMETRY_CANVAS.search=event.target.value;TELEMETRY_CANVAS.renderLimit=TELEMETRY_ADVANCED_PAGE_SIZE;telemetryRenderFieldList();});\n$(\'telemetryClearSearch\').addEventListener(\'click\',()=>{\n$(\'telemetrySearchInput\').value=\'\';TELEMETRY_CANVAS.search=\'\';\nTELEMETRY_CANVAS.renderLimit=TELEMETRY_ADVANCED_PAGE_SIZE;telemetryRenderFieldList();});\n$(\'telemetryLoadMore\').addEventListener(\'click\',()=>{\nTELEMETRY_CANVAS.renderLimit=(Number(TELEMETRY_CANVAS.renderLimit)||TELEMETRY_ADVANCED_PAGE_SIZE)+TELEMETRY_ADVANCED_PAGE_SIZE;\ntelemetryRenderFieldList();});\nfor(const id of[\'telemetryLabelInput\',\'telemetryUnitInput\'])\n$(id).addEventListener(\'input\',event=>telemetryReadInputs(event,true));\nfor(const id of[\'telemetryColsInput\',\'telemetryFontInput\']){\nconst node=$(id);\nnode.addEventListener(\'focus\',()=>{node.dataset.telemetryEditing=\'1\';});\nnode.addEventListener(\'input\',event=>telemetryReadInputs(event,false));\nnode.addEventListener(\'blur\',event=>{\ndelete node.dataset.telemetryEditing;telemetryReadInputs(event,true);});\nnode.addEventListener(\'keydown\',event=>{\nif(event.key===\'Enter\'){event.preventDefault();node.blur();}});}\ndocument.addEventListener(\'pointerdown\',event=>{\nif(TELEMETRY_CANVAS.editorOpen&&!settings.contains(event.target)){\nsetTelemetrySettingsOpen(false);return;}\nconst moving=telemetryGroupById(TELEMETRY_CANVAS.moveGroupId),\nmovingElement=moving&&telemetryGroupElement(moving.id);\nif(movingElement&&!movingElement.contains(event.target))setTelemetryMoveMode(null);\n},true);\ndocument.addEventListener(\'keydown\',event=>{\nif(event.key!==\'Escape\')return;\nif(TELEMETRY_CANVAS.editorOpen)setTelemetrySettingsOpen(false);\nelse if(TELEMETRY_CANVAS.moveGroupId)setTelemetryMoveMode(null);});\ninitTelemetryButton();\nif(document.documentElement.dataset.overlayPersistenceReady!==\'1\'){\ndocument.documentElement.dataset.overlayPersistenceReady=\'1\';\nwindow.addEventListener(\'pagehide\',telemetryPersistAllGeometry,{capture:true});\nwindow.addEventListener(\'beforeunload\',telemetryPersistAllGeometry,{capture:true});\ndocument.addEventListener(\'visibilitychange\',()=>{\nif(document.visibilityState===\'hidden\')telemetryPersistAllGeometry();});}\n(async()=>{\ntry{\nconst payload=await telemetryApi(\'layout\');\ntelemetryApplyConfig(payload.config);\nawait telemetryLoadCatalog();await telemetryPollValues();\nTELEMETRY_CANVAS.pollTimer=setInterval(telemetryPollValues,750);\nTELEMETRY_CANVAS.initialized=true;\nconst selected=payload.config&&Array.isArray(payload.config.selected_fields)?\npayload.config.selected_fields:[],\nhasGroups=selected.some(key=>String(key).startsWith(TELEMETRY_GROUP_PREFIX)),\nhasOverlayGeometry=selected.some(key=>\nString(key).startsWith(TELEMETRY_OVERLAY_PREFIX));\nif(!hasGroups||!hasOverlayGeometry){\ntelemetryCaptureAllOverlayGeometry(false);\ntelemetryScheduleSave(true);}\n}catch(error){\nconsole.error(\'Telemetry groups initialization failed\',error);\ntelemetrySaveStatus(\'Telemetry unavailable\',true);}})();}\n\n\nfunction setMessagesOpen(open){\n  const popover=$(\'messagePopover\');\n  if(!popover)return;\n  popover.classList.toggle(\'open\',open);\n  popover.setAttribute(\'aria-hidden\',open?\'false\':\'true\');\n  $(\'connectionChip\').classList.toggle(\'active\',open);\n}\n\nfunction toggleMessages(){\n  const popover=$(\'messagePopover\');\n  setMessagesOpen(!popover.classList.contains(\'open\'));\n}\n\n\n// GROUND_STATION_BUTTON_LATENCY_V2_8_12_PRIORITY_INPUT_AND_LIGHTWEIGHT_TELEMETRY\n// GROUND_STATION_ANDROID_USB_JOYSTICK_STAGE1_V4\n// Browsers intentionally hide an already-connected gamepad until a real\n// controller gesture is observed in the current page. V4 keeps an aggressive\n// acquisition loop active around page startup and input events so one button\n// press is sufficient; unplugging or reopening the page is not required.\nconst JOYSTICK_STORAGE_KEY=\'siyi-android-joystick-stage1-v3\';\nconst JOYSTICK_SELECTED_ID_KEY=\'siyi-android-joystick-selected-id-v3\';\nconst JOYSTICK_PROFILE_NAME=\'GameSir X5 Lite — confirmed 4-axis / 17-button layout\';\nconst JOYSTICK_STARTUP_ACQUIRE_MS=15000;\nconst JOYSTICK_WAKE_ACQUIRE_MS=6000;\nconst JOYSTICK_AXIS_NAMES={\n  axis_0:\'Left stick horizontal · YAW\',\n  axis_1:\'Left stick vertical · THROTTLE\',\n  axis_2:\'Right stick horizontal · ROLL\',\n  axis_3:\'Right stick vertical · PITCH\'\n};\nconst JOYSTICK={\n  state:null,\n  config:null,\n  open:false,\n  raf:0,\n  acquireRaf:0,\n  acquireUntil:0,\n  acquireReason:\'startup\',\n  reconnectTimer:0,\n  selectedIndex:null,\n  preferredId:\'\',\n  testMode:false,\n  calibration:null,\n  lastInputAt:0,\n  lastSnapshot:\'\',\n  mappingSignature:\'\',\n  disconnectCount:0,\n  scanCount:0,\n  wakeCount:0,\n  lastWakeSource:\'startup\',\n  connectedOnce:false,\n  controlEnabled:false,\n  controlSession:(globalThis.crypto&&typeof globalThis.crypto.randomUUID===\'function\'?globalThis.crypto.randomUUID():(\'gs-\'+Date.now().toString(36)+\'-\'+Math.random().toString(36).slice(2))),\n  controlSeq:0,\n  controlInFlight:false,\n  controlFlushRequested:false,\n  controlPriorityPending:false,\n  controlAbortController:null,\n  controlAbortForPriority:false,\n  controlReleasePending:false,\n  controlTimer:0,\n  inputTimer:0,\n  inputRaf:0,\n  controlLastOk:0,\n  controlFailures:0,\n  controlStatus:\'Waiting for joystick\',\n  buttonMask:0,\n  buttonCaptureArmed:false,\n  buttonEventSeq:0,\n  buttonEvents:[],\n  buttonPressSeq:0,\n  buttonPresses:{},\n  buttonEventProtocol:2,\n  directActionSeq:0,\n  directActions:[],\n  recordHoldStart:0,\n  recordHoldFired:false,\n  controlSocket:null,\n  controlSocketReady:false,\n  controlSocketReconnectTimer:0,\n  controlSocketLastAck:0,\n  controlSocketLastSend:0\n};\nconst JOYSTICK_CONTROL_INTERVAL_MS=20;\nconst JOYSTICK_CONTROL_WS_PATH=\'/api/groundstation/joystick/ws\';\nconst JOYSTICK_CONTROL_WS_MAX_BUFFERED=0;\nconst JOYSTICK_CONTROL_CENTER_LIMIT=0.12;\n// GROUND_STATION_BROWSER_EXPLICIT_BUTTON_EVENTS_V1\n// Tap/hold classification is measured at the Android input source with performance.now().\nconst JOYSTICK_BUTTON_DEFS=[\n  {bit:0x0001,name:\'A\',hold_ms:450},\n  {bit:0x0002,name:\'B\',hold_ms:450},\n  {bit:0x1000,name:\'X\',hold_ms:450},\n  {bit:0x2000,name:\'Y\',hold_ms:450},\n  {bit:0x0008,name:\'LB\',hold_ms:450},\n  {bit:0x0020,name:\'RB\',hold_ms:450},\n  {bit:0x0010,name:\'LT\',hold_ms:450},\n  {bit:0x0040,name:\'RT\',hold_ms:450},\n  {bit:0x0100,name:\'BACK\',hold_ms:450},\n  {bit:0x0200,name:\'START\',hold_ms:750},\n  {bit:0x0400,name:\'L3\',hold_ms:450},\n  {bit:0x0800,name:\'R3\',hold_ms:450},\n  {bit:0x0004,name:\'DPAD_UP\',hold_ms:180,continuous:true},\n  {bit:0x0080,name:\'DPAD_DOWN\',hold_ms:180,continuous:true},\n  {bit:0x4000,name:\'DPAD_LEFT\',hold_ms:180,continuous:true},\n  {bit:0x8000,name:\'DPAD_RIGHT\',hold_ms:180,continuous:true}\n];\n\nfunction joystickDefaultConfig(){\n  return {\n    version:3,\n    input_source:\'android_browser_gamepad_api\',\n    profile:\'gamesir_x5_lite_confirmed_4axis_17button\',\n    axes:{\n      roll:{source:\'axis_2\',invert:false,deadzone:0.04,expo:0.20},\n      pitch:{source:\'axis_3\',invert:true,deadzone:0.04,expo:0.20},\n      yaw:{source:\'axis_0\',invert:false,deadzone:0.04,expo:0.15},\n      throttle:{source:\'axis_1\',invert:true,deadzone:0.04,expo:0}\n    },\n    axis_calibration:{\n      axis_0:{minimum:-1,center:0.0039,maximum:1},\n      axis_1:{minimum:-1,center:0.0039,maximum:1},\n      axis_2:{minimum:-1,center:0.0039,maximum:1},\n      axis_3:{minimum:-1,center:0.0039,maximum:1}\n    }\n  };\n}\n\nfunction joystickLoadConfig(){\n  try{\n    const saved=JSON.parse(localStorage.getItem(JOYSTICK_STORAGE_KEY)||\'null\');\n    JOYSTICK.config=saved&&saved.axes&&Number(saved.version)===3?saved:joystickDefaultConfig();\n  }catch(_error){\n    JOYSTICK.config=joystickDefaultConfig();\n  }\n  try{JOYSTICK.preferredId=String(localStorage.getItem(JOYSTICK_SELECTED_ID_KEY)||\'\');}catch(_error){}\n  joystickRenderMapping(true);\n}\n\nfunction joystickSaveConfig(){\n  try{\n    localStorage.setItem(JOYSTICK_STORAGE_KEY,JSON.stringify(JOYSTICK.config));\n    if(JOYSTICK.preferredId)localStorage.setItem(JOYSTICK_SELECTED_ID_KEY,JOYSTICK.preferredId);\n    return true;\n  }catch(_error){\n    return false;\n  }\n}\n\nfunction joystickPads(){\n  JOYSTICK.scanCount+=1;\n  if(typeof navigator.getGamepads!==\'function\')return [];\n  try{return Array.from(navigator.getGamepads()||[]).filter(item=>item&&item.connected!==false);}catch(_error){return [];}\n}\n\nfunction joystickUpdateLauncher(){\n  const button=$(\'joystickBtn\');\n  const connected=Boolean(JOYSTICK.state&&JOYSTICK.state.connected);\n  if(button){\n    setTopBannerToggleState(button,connected,\'Joystick\');\n    button.title=connected?\'Joystick connected\':\'Joystick not connected\';\n  }\n}\n\nfunction joystickStopAcquireLoop(){\n  if(JOYSTICK.acquireRaf){cancelAnimationFrame(JOYSTICK.acquireRaf);JOYSTICK.acquireRaf=0;}\n  JOYSTICK.acquireUntil=0;\n}\n\nfunction joystickAcquireBurst(reason=\'startup\',duration=JOYSTICK_WAKE_ACQUIRE_MS){\n  JOYSTICK.acquireReason=String(reason||\'startup\');\n  JOYSTICK.lastWakeSource=JOYSTICK.acquireReason;\n  JOYSTICK.acquireUntil=Math.max(JOYSTICK.acquireUntil,performance.now()+Math.max(1000,Number(duration)||0));\n  if(JOYSTICK.acquireRaf)return;\n  const tick=()=>{\n    JOYSTICK.acquireRaf=0;\n    const state=joystickRefresh(JOYSTICK.open);\n    joystickUpdateLauncher();\n    if(state&&state.connected){JOYSTICK.connectedOnce=true;JOYSTICK.acquireUntil=0;return;}\n    if(document.visibilityState===\'visible\'&&performance.now()<JOYSTICK.acquireUntil){JOYSTICK.acquireRaf=requestAnimationFrame(tick);}\n  };\n  JOYSTICK.acquireRaf=requestAnimationFrame(tick);\n  joystickUpdateLauncher();\n}\n\nfunction joystickWakeSequence(source){\n  JOYSTICK.wakeCount+=1;\n  JOYSTICK.lastWakeSource=String(source||\'input\');\n  joystickAcquireBurst(JOYSTICK.lastWakeSource,JOYSTICK_WAKE_ACQUIRE_MS);\n  // Chrome may expose the Gamepad object on a task queued just after the\n  // controller-generated key event. These delayed reads remove the timing race.\n  [0,40,120,300,750].forEach(delay=>window.setTimeout(()=>{\n    joystickRefresh(JOYSTICK.open);\n    joystickUpdateLauncher();\n  },delay));\n}\n\nfunction joystickSelectedPad(pads){\n  let pad=pads.find(item=>item.index===JOYSTICK.selectedIndex)||null;\n  if(!pad&&JOYSTICK.preferredId)pad=pads.find(item=>String(item.id||\'\')===JOYSTICK.preferredId)||null;\n  if(!pad&&pads.length)pad=pads[0];\n  if(pad){\n    JOYSTICK.selectedIndex=pad.index;\n    JOYSTICK.preferredId=String(pad.id||(\'Gamepad \'+pad.index));\n  }else{\n    JOYSTICK.selectedIndex=null;\n  }\n  return pad;\n}\n\nfunction joystickButtonName(index){\n  const standard={0:\'A / Button 0\',1:\'B / Button 1\',2:\'X / Button 2\',3:\'Y / Button 3\',4:\'LB / Button 4\',5:\'RB / Button 5\',6:\'LT / Button 6\',7:\'RT / Button 7\',8:\'Select / Button 8\',9:\'Start / Button 9\',10:\'L3 / Button 10\',11:\'R3 / Button 11\',12:\'D-pad Up / Button 12\',13:\'D-pad Down / Button 13\',14:\'D-pad Left / Button 14\',15:\'D-pad Right / Button 15\',16:\'Home / Button 16\'};\n  return standard[index]||(\'Button \'+index);\n}\n\nfunction joystickAxisName(name){return JOYSTICK_AXIS_NAMES[name]||name;}\nfunction joystickClamp(value,minimum=-1,maximum=1){return Math.max(minimum,Math.min(maximum,Number(value)||0));}\n\nfunction joystickNormalisedAxis(name,raw){\n  const calibration=(JOYSTICK.config&&JOYSTICK.config.axis_calibration&&JOYSTICK.config.axis_calibration[name])||null;\n  if(!calibration)return joystickClamp(raw);\n  const minimum=Number(calibration.minimum),maximum=Number(calibration.maximum),center=Number(calibration.center);\n  if(!Number.isFinite(minimum)||!Number.isFinite(maximum)||!Number.isFinite(center)||maximum<=minimum)return joystickClamp(raw);\n  const span=raw>=center?maximum-center:center-minimum;\n  if(span<=0.0001)return 0;\n  return joystickClamp((raw-center)/span);\n}\n\nfunction joystickProcessedValues(axes){\n  const processed={};\n  const cfg=JOYSTICK.config||joystickDefaultConfig();\n  for(const role of [\'roll\',\'pitch\',\'yaw\',\'throttle\']){\n    const item=(cfg.axes&&cfg.axes[role])||{};\n    const axis=axes[item.source];\n    if(!axis){processed[role]=null;continue;}\n    let value=joystickNormalisedAxis(item.source,axis.raw);\n    if(item.invert)value=-value;\n    const deadzone=Math.max(0,Math.min(.4,Number(item.deadzone)||0));\n    if(Math.abs(value)<=deadzone)value=0;\n    else value=Math.sign(value)*((Math.abs(value)-deadzone)/(1-deadzone));\n    const expo=Math.max(0,Math.min(1,Number(item.expo)||0));\n    value=(1-expo)*value+expo*value*value*value;\n    processed[role]=joystickClamp(value);\n  }\n  return processed;\n}\n\nfunction joystickUpdateCalibration(axes){\n  if(!JOYSTICK.calibration)return;\n  for(const [name,axis] of Object.entries(axes)){\n    const raw=Number(axis.raw)||0;\n    const current=JOYSTICK.calibration[name]||{minimum:raw,maximum:raw,center:raw};\n    current.minimum=Math.min(current.minimum,raw);\n    current.maximum=Math.max(current.maximum,raw);\n    JOYSTICK.calibration[name]=current;\n  }\n}\n\nfunction joystickReadState(){\n  const supported=typeof navigator.getGamepads===\'function\';\n  const pads=supported?joystickPads():[];\n  const previousIndex=JOYSTICK.selectedIndex;\n  const pad=joystickSelectedPad(pads);\n  if(previousIndex!==null&&!pad)JOYSTICK.disconnectCount+=1;\n  const devices=pads.map(item=>({index:item.index,id:item.id||(\'Gamepad \'+item.index),mapping:item.mapping||\'none\',axes_count:item.axes.length,buttons_count:item.buttons.length,connected:item.connected!==false}));\n  const axes={},buttons={};\n  if(pad){\n    pad.axes.forEach((value,index)=>{\n      const name=\'axis_\'+index;\n      axes[name]={raw:joystickClamp(value),normalised:joystickNormalisedAxis(name,value),minimum:-1,maximum:1,label:joystickAxisName(name)};\n    });\n    pad.buttons.forEach((button,index)=>{buttons[String(index)]={pressed:Boolean(button.pressed),touched:Boolean(button.touched),value:Number(button.value)||0,name:joystickButtonName(index)};});\n  }\n  joystickUpdateCalibration(axes);\n  const snapshot=pad?JSON.stringify({axes:Object.values(axes).map(item=>Number(item.raw).toFixed(4)),buttons:Object.values(buttons).map(item=>[item.pressed,Number(item.value).toFixed(3)])}):\'\';\n  if(snapshot&&snapshot!==JOYSTICK.lastSnapshot){JOYSTICK.lastInputAt=Date.now();JOYSTICK.lastSnapshot=snapshot;}\n  const profileConfirmed=Boolean(pad&&pad.axes.length===4&&pad.buttons.length===17);\n  if(pad)JOYSTICK.connectedOnce=true;\n  JOYSTICK.state={\n    marker:\'GROUND_STATION_ANDROID_JOYSTICK_CONTROL_STAGE2_V9_RECORD_ACTION\',\n    supported,\n    secure_context:Boolean(window.isSecureContext),\n    connected:Boolean(pad),\n    configured:Boolean(pad),\n    activation_needed:Boolean(supported&&!pad),\n    acquisition_active:Boolean(JOYSTICK.acquireRaf||JOYSTICK.acquireUntil>performance.now()),\n    acquisition_reason:JOYSTICK.acquireReason,\n    scan_count:JOYSTICK.scanCount,\n    wake_count:JOYSTICK.wakeCount,\n    last_wake_source:JOYSTICK.lastWakeSource,\n    profile_confirmed:profileConfirmed,\n    profile_name:profileConfirmed?JOYSTICK_PROFILE_NAME:\'Unknown controller layout\',\n    devices,\n    device:pad?devices.find(item=>item.index===pad.index):null,\n    axes,\n    buttons,\n    processed:joystickProcessedValues(axes),\n    test_mode:JOYSTICK.testMode,\n    calibration:Boolean(JOYSTICK.calibration),\n    disconnect_count:JOYSTICK.disconnectCount,\n    last_input_ms:JOYSTICK.lastInputAt?Date.now()-JOYSTICK.lastInputAt:null,\n    aircraft_control:Boolean(JOYSTICK.controlEnabled),\n    mavlink_output:Boolean(JOYSTICK.controlEnabled),\n    control_status:JOYSTICK.controlStatus,\n    control_last_ok_ms:JOYSTICK.controlLastOk?Date.now()-JOYSTICK.controlLastOk:null\n  };\n  joystickCaptureButtonState(JOYSTICK.state);\n  joystickCaptureDirectActions(JOYSTICK.state);\n  return JOYSTICK.state;\n}\n\nfunction joystickButtonMask(buttons){\n  const pressed=index=>{\n    const item=buttons&&buttons[String(index)];\n    return Boolean(item&&(item.pressed||Number(item.value)>.5));\n  };\n  let mask=0;\n  if(pressed(0))mask|=0x0001;   // A\n  if(pressed(1))mask|=0x0002;   // B\n  if(pressed(2))mask|=0x1000;   // X — preserve existing bridge bit\n  if(pressed(3))mask|=0x2000;   // Y — preserve existing bridge bit\n  if(pressed(4))mask|=0x0008;   // LB\n  if(pressed(5))mask|=0x0020;   // RB\n  if(pressed(6))mask|=0x0010;   // LT\n  if(pressed(7))mask|=0x0040;   // RT\n  if(pressed(8))mask|=0x0100;   // BACK\n  if(pressed(9))mask|=0x0200;   // START\n  if(pressed(10))mask|=0x0400;  // L3\n  if(pressed(11))mask|=0x0800;  // R3\n  if(pressed(12))mask|=0x0004;  // DPAD_UP — new free bridge bit\n  if(pressed(13))mask|=0x0080;  // DPAD_DOWN — new free bridge bit\n  if(pressed(14))mask|=0x4000;  // DPAD_LEFT — new free bridge bit\n  if(pressed(15))mask|=0x8000;  // DPAD_RIGHT — new free bridge bit\n  return mask>>>0;\n}\n\nfunction joystickRequestPriorityFlush(){\n  JOYSTICK.controlFlushRequested=true;\n  JOYSTICK.controlPriorityPending=true;\n  if(!JOYSTICK.controlEnabled||document.visibilityState!==\'visible\')return;\n  if(JOYSTICK.controlInFlight){\n    const controller=JOYSTICK.controlAbortController;\n    if(controller&&!controller.signal.aborted){\n      JOYSTICK.controlAbortForPriority=true;\n      try{controller.abort();}catch(_error){}\n    }\n    return;\n  }\n  queueMicrotask(()=>joystickSendControl(true,true));\n}\n\nfunction joystickQueueExplicitButtonEvent(button,event,press,durationMs=0){\n  const item={\n    id:++JOYSTICK.buttonEventSeq,\n    protocol:2,\n    press_id:Number(press&&press.id)||0,\n    button:String(button||\'\').toUpperCase(),\n    event:String(event||\'\').toLowerCase(),\n    duration_ms:Math.max(0,Math.round(Number(durationMs)||0)),\n    client_ms:Date.now()\n  };\n  JOYSTICK.buttonEvents.push(item);\n  if(JOYSTICK.buttonEvents.length>128){\n    JOYSTICK.controlStatus=\'Button event queue overflow — control cancelled\';\n    JOYSTICK.buttonEvents=[];\n    JOYSTICK.buttonPresses={};\n    JOYSTICK.buttonCaptureArmed=false;\n    JOYSTICK.controlEnabled=false;\n    return;\n  }\n  joystickRequestPriorityFlush();\n}\n\nfunction joystickCancelAllButtonPresses(reason=\'input_cancelled\'){\n  const now=performance.now();\n  Object.entries(JOYSTICK.buttonPresses||{}).forEach(([button,press])=>{\n    joystickQueueExplicitButtonEvent(button,\'button_cancel\',press,now-Number(press.started||now));\n  });\n  JOYSTICK.buttonPresses={};\n  JOYSTICK.buttonMask=0;\n}\n\nfunction joystickCaptureButtonState(state){\n  const connected=Boolean(state&&state.connected);\n  const mask=connected?joystickButtonMask(state.buttons||{}):0;\n  if(!connected){\n    if(Object.keys(JOYSTICK.buttonPresses||{}).length)joystickCancelAllButtonPresses(\'disconnect\');\n    JOYSTICK.buttonCaptureArmed=false;\n    return;\n  }\n  if(!JOYSTICK.buttonCaptureArmed){\n    JOYSTICK.buttonMask=mask;\n    JOYSTICK.buttonPresses={};\n    if(mask===0)JOYSTICK.buttonCaptureArmed=true;\n    return;\n  }\n  const now=performance.now();\n  for(const def of JOYSTICK_BUTTON_DEFS){\n    const down=Boolean(mask&def.bit);\n    let press=JOYSTICK.buttonPresses[def.name];\n    if(down&&!press){\n      press={id:++JOYSTICK.buttonPressSeq,started:now,hold_sent:false,continuous:Boolean(def.continuous)};\n      JOYSTICK.buttonPresses[def.name]=press;\n      joystickQueueExplicitButtonEvent(def.name,\'button_down\',press,0);\n    }else if(down&&press&&!press.hold_sent&&now-press.started>=def.hold_ms){\n      press.hold_sent=true;\n      joystickQueueExplicitButtonEvent(def.name,\'button_hold_start\',press,now-press.started);\n    }else if(!down&&press){\n      const duration=now-press.started;\n      if(!press.hold_sent)joystickQueueExplicitButtonEvent(def.name,\'button_tap\',press,duration);\n      joystickQueueExplicitButtonEvent(def.name,\'button_up\',press,duration);\n      delete JOYSTICK.buttonPresses[def.name];\n    }\n  }\n  JOYSTICK.buttonMask=mask;\n}\n\nfunction joystickQueueDirectAction(action){\n  action=String(action||\'\').trim().toUpperCase();\n  if(action!==\'RECORD_TOGGLE\')return;\n  JOYSTICK.directActions.push({id:++JOYSTICK.directActionSeq,action,client_ms:Date.now()});\n  if(JOYSTICK.directActions.length>32){\n    JOYSTICK.controlStatus=\'Action queue overflow — reconnect joystick\';\n    JOYSTICK.directActions=[];\n    return;\n  }\n  joystickRequestPriorityFlush();\n}\n\nfunction joystickCaptureDirectActions(_state){/* Explicit START events replace Pi-timed record holds. */}\n\nfunction joystickControlPayload(enabled=JOYSTICK.controlEnabled){\n  const state=JOYSTICK.state||{};\n  const processed=state.processed||{};\n  const axis=name=>joystickClamp(processed[name]===null||processed[name]===undefined?0:processed[name]);\n  return {\n    version:2,\n    session:String(JOYSTICK.controlSession),\n    seq:++JOYSTICK.controlSeq,\n    client_ms:Date.now(),\n    enabled:Boolean(enabled),\n    connected:Boolean(state.connected),\n    axes:{roll:axis(\'roll\'),pitch:axis(\'pitch\'),yaw:axis(\'yaw\'),throttle:axis(\'throttle\')},\n    buttons:enabled&&state.connected?joystickButtonMask(state.buttons||{}):0,\n    button_events:JOYSTICK.buttonEvents.filter(item=>\n      (enabled&&state.connected)||[\'button_up\',\'button_cancel\'].includes(String(item.event||\'\'))\n    ).slice(0,64),\n    direct_actions:enabled&&state.connected?JOYSTICK.directActions.slice(0,16):[]\n  };\n}\n\n\n// GROUND_STATION_STICK_WEBSOCKET_LATENCY_FIX_V1\n// Persistent latest-state transport. HTTP remains as an automatic fallback.\nfunction joystickControlSocketUrl(){\n  const scheme=location.protocol===\'https:\'?\'wss:\':\'ws:\';\n  return scheme+\'//\'+location.host+JOYSTICK_CONTROL_WS_PATH;\n}\n\nfunction joystickScheduleControlSocketReconnect(delay=500){\n  if(JOYSTICK.controlSocketReconnectTimer||document.visibilityState!==\'visible\')return;\n  JOYSTICK.controlSocketReconnectTimer=window.setTimeout(()=>{\n    JOYSTICK.controlSocketReconnectTimer=0;\n    joystickConnectControlSocket();\n  },Math.max(100,Number(delay)||500));\n}\n\nfunction joystickHandleControlSocketAck(event){\n  let result={};\n  try{result=JSON.parse(String(event.data||\'{}\'));}catch(_error){return;}\n  if(result.ok===false){\n    if(Number(result.status)===409)return;\n    JOYSTICK.controlFailures+=1;\n    JOYSTICK.controlStatus=\'Control link error\';\n    return;\n  }\n  const ackSeq=Number(result.seq);\n  if(!Number.isFinite(ackSeq)){\n    if(result.ready&&!JOYSTICK.controlEnabled)\n      JOYSTICK.controlStatus=\'Joystick transport ready\';\n    return;\n  }\n  const eventId=Number(result.last_event_id);\n  const actionId=Number(result.last_action_id);\n  if(Number.isFinite(eventId)&&eventId>=0)\n    JOYSTICK.buttonEvents=JOYSTICK.buttonEvents.filter(item=>Number(item.id)>eventId);\n  if(Number.isFinite(actionId)&&actionId>=0)\n    JOYSTICK.directActions=JOYSTICK.directActions.filter(item=>Number(item.id)>actionId);\n  if(!JOYSTICK.buttonEvents.length&&!JOYSTICK.directActions.length)\n    JOYSTICK.controlPriorityPending=false;\n  JOYSTICK.controlSocketLastAck=Date.now();\n  JOYSTICK.controlLastOk=JOYSTICK.controlSocketLastAck;\n  JOYSTICK.controlFailures=0;\n  JOYSTICK.controlStatus=JOYSTICK.controlEnabled?\'Joystick control active\':\'Joystick disconnected\';\n  if(JOYSTICK.controlFlushRequested&&JOYSTICK.controlEnabled&&\n      document.visibilityState===\'visible\'){\n    JOYSTICK.controlFlushRequested=false;\n    queueMicrotask(()=>joystickSendControl(true,false));\n  }\n}\n\nfunction joystickConnectControlSocket(){\n  if(document.visibilityState!==\'visible\')return;\n  const current=JOYSTICK.controlSocket;\n  if(current&&(current.readyState===WebSocket.OPEN||\n      current.readyState===WebSocket.CONNECTING))return;\n  if(JOYSTICK.controlSocketReconnectTimer){\n    clearTimeout(JOYSTICK.controlSocketReconnectTimer);\n    JOYSTICK.controlSocketReconnectTimer=0;\n  }\n  let socket;\n  try{socket=new WebSocket(joystickControlSocketUrl());}\n  catch(_error){joystickScheduleControlSocketReconnect(750);return;}\n  JOYSTICK.controlSocket=socket;\n  JOYSTICK.controlSocketReady=false;\n  socket.onopen=()=>{\n    if(JOYSTICK.controlSocket!==socket)return;\n    JOYSTICK.controlSocketReady=true;\n    JOYSTICK.controlFailures=0;\n    JOYSTICK.controlStatus=JOYSTICK.controlEnabled?\n      \'Joystick control active\':\'Joystick transport ready\';\n    if(JOYSTICK.controlEnabled&&document.visibilityState===\'visible\')\n      queueMicrotask(()=>joystickSendControl(true,true));\n  };\n  socket.onmessage=joystickHandleControlSocketAck;\n  socket.onerror=()=>{};\n  socket.onclose=()=>{\n    if(JOYSTICK.controlSocket!==socket)return;\n    JOYSTICK.controlSocket=null;\n    JOYSTICK.controlSocketReady=false;\n    if(JOYSTICK.controlEnabled)\n      JOYSTICK.controlStatus=\'Joystick transport reconnecting\';\n    joystickScheduleControlSocketReconnect(350);\n  };\n}\n\nasync function joystickSendControl(enabled=JOYSTICK.controlEnabled,force=false){\n  const socket=JOYSTICK.controlSocket;\n  if(socket&&socket.readyState===WebSocket.OPEN&&JOYSTICK.controlSocketReady){\n    const priority=Boolean(force||JOYSTICK.buttonEvents.length||\n      JOYSTICK.directActions.length||JOYSTICK.controlPriorityPending||!enabled);\n    if(socket.bufferedAmount>65536){\n      try{socket.close(1011,\'control buffer reset\');}catch(_error){}\n      joystickScheduleControlSocketReconnect(100);\n      return joystickSendControlHttp(enabled,force);\n    }\n    // Never create an obsolete-axis backlog. Keep at most one ordinary state\n    // waiting in the browser socket and send the newest state on the next tick.\n    if(!priority&&socket.bufferedAmount>JOYSTICK_CONTROL_WS_MAX_BUFFERED){\n      JOYSTICK.controlFlushRequested=true;\n      return false;\n    }\n    const payload=joystickControlPayload(enabled);\n    try{\n      socket.send(JSON.stringify(payload));\n      JOYSTICK.controlSocketLastSend=Date.now();\n      JOYSTICK.controlStatus=enabled?\'Joystick control active\':\'Joystick disconnected\';\n      return true;\n    }catch(_error){\n      try{socket.close();}catch(_closeError){}\n      joystickScheduleControlSocketReconnect(100);\n    }\n  }else{\n    joystickConnectControlSocket();\n  }\n  return joystickSendControlHttp(enabled,force);\n}\n\nasync function joystickSendControlHttp(enabled=JOYSTICK.controlEnabled,force=false){\n  const pendingPriority=force||JOYSTICK.buttonEvents.length>0||\n    JOYSTICK.directActions.length>0||JOYSTICK.controlPriorityPending;\n  if(JOYSTICK.controlInFlight){\n    if(!enabled)JOYSTICK.controlReleasePending=true;\n    if(pendingPriority){\n      JOYSTICK.controlFlushRequested=true;\n      JOYSTICK.controlPriorityPending=true;\n      const controller=JOYSTICK.controlAbortController;\n      if(controller&&!controller.signal.aborted){\n        JOYSTICK.controlAbortForPriority=true;\n        try{controller.abort();}catch(_error){}\n      }\n    }\n    return false;\n  }\n  const payload=joystickControlPayload(enabled);\n  const sentEventId=payload.button_events.length?\n    Number(payload.button_events[payload.button_events.length-1].id)||0:0;\n  const sentActionId=payload.direct_actions.length?\n    Number(payload.direct_actions[payload.direct_actions.length-1].id)||0:0;\n  const priority=Boolean(force||sentEventId||sentActionId||\n    JOYSTICK.controlPriorityPending);\n  const controller=new AbortController();\n  JOYSTICK.controlAbortController=controller;\n  JOYSTICK.controlAbortForPriority=false;\n  JOYSTICK.controlInFlight=true;\n  try{\n    const response=await fetch(\'/api/groundstation/joystick/control\',{\n      method:\'POST\',\n      headers:{\n        \'Content-Type\':\'application/json\',\n        \'X-SIYI-Control-Priority\':priority?\'1\':\'0\'\n      },\n      cache:\'no-store\',\n      signal:controller.signal,\n      body:JSON.stringify(payload)\n    });\n    const result=await response.json().catch(()=>({}));\n    if(!response.ok||result.ok===false)\n      throw new Error(result.error||(\'HTTP \'+response.status));\n    if(sentEventId)\n      JOYSTICK.buttonEvents=JOYSTICK.buttonEvents.filter(\n        item=>Number(item.id)>sentEventId);\n    if(sentActionId)\n      JOYSTICK.directActions=JOYSTICK.directActions.filter(\n        item=>Number(item.id)>sentActionId);\n    if(!JOYSTICK.buttonEvents.length&&!JOYSTICK.directActions.length)\n      JOYSTICK.controlPriorityPending=false;\n    JOYSTICK.controlLastOk=Date.now();\n    JOYSTICK.controlFailures=0;\n    JOYSTICK.controlStatus=enabled?\'Joystick control active\':\'Joystick disconnected\';\n    return true;\n  }catch(error){\n    const preempted=Boolean(error&&error.name===\'AbortError\'&&\n      JOYSTICK.controlAbortForPriority);\n    if(!preempted){\n      JOYSTICK.controlFailures+=1;\n      JOYSTICK.controlStatus=\'Control link error\';\n      if(JOYSTICK.controlFailures>=3&&JOYSTICK.controlEnabled){\n        JOYSTICK.controlEnabled=false;\n        joystickUpdateLauncher();\n      }\n    }\n    return false;\n  }finally{\n    const preempted=JOYSTICK.controlAbortForPriority;\n    JOYSTICK.controlInFlight=false;\n    JOYSTICK.controlAbortController=null;\n    JOYSTICK.controlAbortForPriority=false;\n    const release=JOYSTICK.controlReleasePending;\n    const priorityFlush=JOYSTICK.controlPriorityPending||\n      JOYSTICK.buttonEvents.length>0||JOYSTICK.directActions.length>0;\n    const flush=JOYSTICK.controlFlushRequested||priorityFlush;\n    JOYSTICK.controlReleasePending=false;\n    JOYSTICK.controlFlushRequested=false;\n    if(release)setTimeout(()=>joystickSendControl(false,true),0);\n    else if(priorityFlush&&JOYSTICK.controlEnabled&&\n      document.visibilityState===\'visible\')\n      queueMicrotask(()=>joystickSendControl(true,true));\n    else if(flush&&JOYSTICK.controlEnabled&&\n      document.visibilityState===\'visible\')\n      setTimeout(()=>joystickSendControl(true,false),0);\n    if(preempted&&JOYSTICK.controlEnabled&&\n      document.visibilityState===\'visible\'&&!priorityFlush)\n      queueMicrotask(()=>joystickSendControl(true,false));\n    if(JOYSTICK.open)joystickRender();\n  }\n}\n\nfunction joystickStopControl(reason=\'Joystick disconnected\',sendRelease=true){\n  const wasEnabled=JOYSTICK.controlEnabled;\n  JOYSTICK.controlEnabled=false;\n  JOYSTICK.controlStatus=String(reason||\'Joystick disconnected\');\n  joystickCancelAllButtonPresses(String(reason||\'control_stopped\'));\n  JOYSTICK.directActions=[];\n  JOYSTICK.recordHoldStart=0;\n  JOYSTICK.recordHoldFired=false;\n  JOYSTICK.controlFlushRequested=false;\n  JOYSTICK.controlPriorityPending=false;\n  if(sendRelease&&(wasEnabled||JOYSTICK.controlLastOk))joystickSendControl(false,true);\n  joystickUpdateLauncher();\n  if(JOYSTICK.open)joystickRender();\n}\n\nfunction joystickInputTick(){\n  JOYSTICK.inputRaf=0;\n  if(document.visibilityState===\'visible\')joystickRefresh(false);\n  JOYSTICK.inputRaf=requestAnimationFrame(joystickInputTick);\n}\nfunction joystickStartInputLoop(){\n  if(!JOYSTICK.inputRaf)JOYSTICK.inputRaf=requestAnimationFrame(joystickInputTick);\n}\n\nfunction joystickControlTick(){\n  if(document.visibilityState!==\'visible\'){\n    if(JOYSTICK.controlEnabled)joystickStopControl(\'Joystick paused: page hidden\',true);\n    return;\n  }\n  if(!(JOYSTICK.state&&JOYSTICK.state.connected)){\n    if(JOYSTICK.controlEnabled||JOYSTICK.controlLastOk)joystickStopControl(\'Waiting for joystick\',true);\n    else JOYSTICK.controlStatus=\'Waiting for joystick\';\n    return;\n  }\n  if(!JOYSTICK.controlEnabled){\n    JOYSTICK.controlEnabled=true;\n    JOYSTICK.controlFailures=0;\n    JOYSTICK.controlStatus=\'Joystick control active\';\n    joystickUpdateLauncher();\n    if(JOYSTICK.open)joystickRender();\n  }\n  joystickSendControl(true,false);\n}\n\nfunction joystickSetOpen(open){\n  JOYSTICK.open=Boolean(open);\n  $(\'joystickPanel\').classList.toggle(\'open\',JOYSTICK.open);\n  $(\'joystickBackdrop\').classList.toggle(\'open\',JOYSTICK.open);\n  $(\'joystickPanel\').setAttribute(\'aria-hidden\',JOYSTICK.open?\'false\':\'true\');\n  $(\'joystickBackdrop\').setAttribute(\'aria-hidden\',JOYSTICK.open?\'false\':\'true\');\n  $(\'joystickBtn\').classList.toggle(\'active\',JOYSTICK.open);\n  if(JOYSTICK.open){\n    if(!JOYSTICK.config)joystickLoadConfig();\n    joystickStartLoop();\n  }else{\n    joystickStopLoop();\n  }\n}\n\nfunction joystickStartLoop(){\n  joystickStopLoop();\n  const tick=()=>{\n    if(!JOYSTICK.open)return;\n    joystickRefresh(true);\n    JOYSTICK.raf=requestAnimationFrame(tick);\n  };\n  tick();\n}\n\nfunction joystickStopLoop(){if(JOYSTICK.raf){cancelAnimationFrame(JOYSTICK.raf);JOYSTICK.raf=0;}}\nfunction joystickConnectStream(){joystickStartLoop();}\nfunction joystickRefresh(render=true){joystickReadState();if(render&&JOYSTICK.open)joystickRender();return JOYSTICK.state;}\n\nfunction joystickDeviceKey(item){return String(item.index);}\n\nfunction joystickRender(){\n  const s=JOYSTICK.state||{};\n  const connected=Boolean(s.connected),supported=Boolean(s.supported);\n  let head=\'PRESS ANY CONTROLLER BUTTON ONCE\';\n  let headClass=\'gs-joystick-status-warn\';\n  if(!supported){head=s.secure_context?\'GAMEPAD API UNAVAILABLE\':\'GAMEPAD API NEEDS SECURE CONTEXT\';headClass=\'gs-joystick-status-bad\';}\n  else if(connected){head=JOYSTICK.testMode?\'ANDROID INPUT LIVE\':\'ANDROID CONTROLLER CONNECTED\';headClass=\'gs-joystick-status-ok\';}\n  $(\'joystickHeadState\').textContent=head;\n  $(\'joystickHeadState\').className=headClass;\n\n  const select=$(\'joystickDeviceSelect\'),current=String(JOYSTICK.selectedIndex===null?\'\':JOYSTICK.selectedIndex);\n  select.innerHTML=\'\';\n  const devices=s.devices||[];\n  if(!devices.length){\n    const option=document.createElement(\'option\');\n    option.value=\'\';\n    option.textContent=supported?\'Controller hidden by browser until one controller-button press — no USB reconnect needed\':\'Android browser Gamepad API unavailable\';\n    select.appendChild(option);\n  }else{\n    devices.forEach(item=>{\n      const option=document.createElement(\'option\');\n      option.value=joystickDeviceKey(item);\n      option.textContent=item.id+\' — index \'+item.index;\n      select.appendChild(option);\n    });\n  }\n  if(current&&[...select.options].some(option=>option.value===current))select.value=current;\n  else if(devices.length)select.value=String(devices[0].index);\n\n  const d=s.device||{};\n  const contextText=s.secure_context?\'Secure\':\'Not secure (HTTP)\';\n  $(\'joystickDeviceInfo\').innerHTML=\n    \'<span>Connection</span><span class="\'+(connected?\'gs-joystick-status-ok\':\'gs-joystick-status-warn\')+\'">\'+(connected?\'Connected to Android\':\'Waiting for one controller-button press\')+\'</span>\'+\n    \'<span>Input source</span><span>Android browser Gamepad API</span>\'+\n    \'<span>Profile</span><span class="\'+(s.profile_confirmed?\'gs-joystick-status-ok\':\'gs-joystick-status-warn\')+\'">\'+escapeHtml(s.profile_name||\'—\')+\'</span>\'+\n    \'<span>Controller</span><span>\'+escapeHtml(d.id||\'USB may stay connected — press A/B/X/Y once after opening the page\')+\'</span>\'+\n    \'<span>Index / Mapping</span><span>\'+(d.index===undefined?\'—\':d.index)+\' / \'+escapeHtml(d.mapping||\'—\')+\'</span>\'+\n    \'<span>Axes / Buttons</span><span>\'+Number(d.axes_count||0)+\' / \'+Number(d.buttons_count||0)+\'</span>\'+\n    \'<span>Browser context</span><span>\'+contextText+\'</span>\'+\n    \'<span>Last change</span><span>\'+(s.last_input_ms===null||s.last_input_ms===undefined?\'—\':Math.round(s.last_input_ms)+\' ms\')+\'</span>\'+\n    \'<span>Startup acquisition</span><span>\'+(s.acquisition_active?\'Active · \'+escapeHtml(s.acquisition_reason||\'startup\'):\'Idle\')+\'</span>\'+ \n    \'<span>Wake events / scans</span><span>\'+Number(s.wake_count||0)+\' / \'+Number(s.scan_count||0)+\'</span>\'+ \n    \'<span>Last wake trigger</span><span>\'+escapeHtml(s.last_wake_source||\'startup\')+\'</span>\'+ \n    \'<span>Disconnects seen</span><span>\'+Number(s.disconnect_count||0)+\'</span>\';\n\n  $(\'joystickTestBtn\').textContent=JOYSTICK.testMode?\'Stop live test\':\'Start live test\';\n  const banner=$(\'joystickSafetyBanner\');\n  banner.classList.toggle(\'test\',JOYSTICK.testMode&&!JOYSTICK.controlEnabled);\n  banner.classList.toggle(\'control-active\',JOYSTICK.controlEnabled);\n  banner.textContent=JOYSTICK.controlEnabled?\'JOYSTICK READY — STICKS, BUTTONS AND D-PAD ARE LIVE\':connected?\'JOYSTICK READY — STARTING AUTOMATIC CONTROL\':\'JOYSTICK DISCONNECTED\';\n  $(\'joystickCalibrationState\').textContent=JOYSTICK.calibration?\'Calibration active — move every axis through its full range\':\'Confirmed centre 0.0039 loaded; optional calibration not running\';\n  $(\'joystickCalibrationState\').className=JOYSTICK.calibration?\'gs-joystick-status-ok\':\'gs-joystick-status-warn\';\n  joystickRenderAxes();\n  joystickRenderButtons();\n  joystickRenderMapping(false);\n}\n\nfunction joystickRenderAxes(){\n  const root=$(\'joystickAxisList\'),axes=(JOYSTICK.state&&JOYSTICK.state.axes)||{};\n  const names=Object.keys(axes);\n  if(!names.length){root.innerHTML=\'<span>Controller already connected to Android? Keep USB connected and press A, B, X or Y once after this page is visible. The browser will then expose it immediately.</span>\';return;}\n  root.innerHTML=names.map(name=>{\n    const raw=joystickClamp(axes[name].raw),normalised=joystickClamp(axes[name].normalised),left=normalised<0?(50+normalised*50):50,width=Math.abs(normalised)*50;\n    return \'<div class="gs-axis-item"><div class="gs-axis-head"><strong>\'+escapeHtml(name+\' · \'+joystickAxisName(name))+\'</strong><span>\'+raw.toFixed(4)+\'</span></div><div class="gs-axis-bar"><i></i><b style="left:\'+left+\'%;width:\'+width+\'%"></b></div><div class="gs-axis-meta"><span>-1.000</span><span>raw \'+raw.toFixed(4)+\' · calibrated \'+normalised.toFixed(4)+\'</span><span>+1.000</span></div></div>\';\n  }).join(\'\');\n}\n\nfunction joystickRenderButtons(){\n  const root=$(\'joystickButtonGrid\'),buttons=(JOYSTICK.state&&JOYSTICK.state.buttons)||{};\n  const names=Object.keys(buttons);\n  root.innerHTML=names.length?names.map(index=>{\n    const item=buttons[index];\n    const active=item.pressed||item.value>.05;\n    return \'<span class="gs-button-dot \'+(active?\'on\':\'\')+\'">\'+escapeHtml(item.name)+\' · \'+Number(item.value).toFixed(2)+\'</span>\';\n  }).join(\'\'):\'<span>Waiting for Android controller buttons…</span>\';\n}\n\nfunction joystickAxisOptions(selected){\n  const axes=Object.keys((JOYSTICK.state&&JOYSTICK.state.axes)||{});\n  return [\'\'].concat(axes).map(name=>\'<option value="\'+escapeHtml(name)+\'" \'+(name===selected?\'selected\':\'\')+\'>\'+(name?name+\' · \'+joystickAxisName(name):\'Unused\')+\'</option>\').join(\'\');\n}\n\nfunction joystickRenderMapping(force=false){\n  if(!JOYSTICK.config)return;\n  const axes=Object.keys((JOYSTICK.state&&JOYSTICK.state.axes)||{});\n  const signature=axes.join(\'|\')+\'|\'+JSON.stringify(JOYSTICK.config.axes||{});\n  const body=$(\'joystickMappingBody\');\n  if(force||!body.children.length||signature!==JOYSTICK.mappingSignature){\n    JOYSTICK.mappingSignature=signature;\n    body.innerHTML=[\'roll\',\'pitch\',\'yaw\',\'throttle\'].map(role=>{\n      const item=(JOYSTICK.config.axes&&JOYSTICK.config.axes[role])||{};\n      return \'<tr data-role="\'+role+\'"><td>\'+role.toUpperCase()+\'</td><td><select class="gs-joystick-select map-source">\'+joystickAxisOptions(item.source||\'\')+\'</select></td><td><input class="map-invert" type="checkbox" \'+(item.invert?\'checked\':\'\')+\'></td><td><input class="gs-joystick-input map-deadzone" type="number" min="0" max="0.4" step="0.01" value="\'+Number(item.deadzone||0).toFixed(2)+\'"></td><td><input class="gs-joystick-input map-expo" type="number" min="0" max="1" step="0.05" value="\'+Number(item.expo||0).toFixed(2)+\'"></td><td class="map-processed">—</td></tr>\';\n    }).join(\'\');\n  }\n  const processed=(JOYSTICK.state&&JOYSTICK.state.processed)||{};\n  body.querySelectorAll(\'tr\').forEach(row=>{\n    const value=processed[row.dataset.role],cell=row.querySelector(\'.map-processed\');\n    if(cell)cell.textContent=value===null||value===undefined?\'—\':Number(value).toFixed(3);\n  });\n}\n\nfunction joystickUseSelected(){\n  const value=Number($(\'joystickDeviceSelect\').value);\n  if(!Number.isInteger(value)||value<0)return;\n  JOYSTICK.selectedIndex=value;\n  const pad=joystickPads().find(item=>item.index===value)||null;\n  if(pad)JOYSTICK.preferredId=String(pad.id||(\'Gamepad \'+pad.index));\n  joystickSaveConfig();\n  joystickRefresh(true);\n}\n\nfunction joystickAction(action){\n  if(action===\'test-toggle\'){\n    JOYSTICK.testMode=!JOYSTICK.testMode;\n  }else if(action===\'calibration-start\'){\n    const axes=(JOYSTICK.state&&JOYSTICK.state.axes)||{};\n    JOYSTICK.calibration={};\n    for(const [name,axis] of Object.entries(axes)){\n      const raw=Number(axis.raw)||0;\n      JOYSTICK.calibration[name]={minimum:raw,maximum:raw,center:raw};\n    }\n  }else if(action===\'calibration-save\'){\n    if(JOYSTICK.calibration){\n      JOYSTICK.config.axis_calibration=JSON.parse(JSON.stringify(JOYSTICK.calibration));\n      const saved=joystickSaveConfig();\n      JOYSTICK.calibration=null;\n      $(\'joystickSaveState\').textContent=saved?\'Calibration saved on this Android device\':\'Browser storage unavailable\';\n      setTimeout(()=>{$(\'joystickSaveState\').textContent=\'\';},1800);\n    }\n  }else if(action===\'calibration-cancel\'){\n    JOYSTICK.calibration=null;\n  }\n  joystickRefresh(true);\n}\n\nfunction joystickSaveMapping(){\n  if(!JOYSTICK.config)return;\n  document.querySelectorAll(\'#joystickMappingBody tr\').forEach(row=>{\n    const role=row.dataset.role,item=JOYSTICK.config.axes[role];\n    item.source=row.querySelector(\'.map-source\').value;\n    item.invert=row.querySelector(\'.map-invert\').checked;\n    item.deadzone=Number(row.querySelector(\'.map-deadzone\').value)||0;\n    item.expo=Number(row.querySelector(\'.map-expo\').value)||0;\n  });\n  const saved=joystickSaveConfig();\n  $(\'joystickSaveState\').textContent=saved?\'Saved on this Android device\':\'Browser storage unavailable\';\n  JOYSTICK.mappingSignature=\'\';\n  setTimeout(()=>{$(\'joystickSaveState\').textContent=\'\';},1800);\n  joystickRefresh(true);\n}\n\nfunction joystickBackgroundScan(){joystickRefresh(false);joystickUpdateLauncher();if(JOYSTICK.open)joystickRender();}\n\nfunction initJoystickUi(){\n  joystickLoadConfig();\n  $(\'joystickBtn\').addEventListener(\'click\',()=>{joystickWakeSequence(\'joystick panel opened\');joystickSetOpen(!JOYSTICK.open);});\n  $(\'joystickClose\').addEventListener(\'click\',()=>joystickSetOpen(false));\n  $(\'joystickBackdrop\').addEventListener(\'click\',()=>joystickSetOpen(false));\n  $(\'joystickRefreshBtn\').addEventListener(\'click\',()=>joystickWakeSequence(\'manual refresh\'));\n  $(\'joystickUseDevice\').addEventListener(\'click\',joystickUseSelected);\n  $(\'joystickTestBtn\').addEventListener(\'click\',()=>joystickAction(\'test-toggle\'));\n  $(\'joystickCalStart\').addEventListener(\'click\',()=>joystickAction(\'calibration-start\'));\n  $(\'joystickCalSave\').addEventListener(\'click\',()=>joystickAction(\'calibration-save\'));\n  $(\'joystickCalCancel\').addEventListener(\'click\',()=>joystickAction(\'calibration-cancel\'));\n  $(\'joystickSaveMapping\').addEventListener(\'click\',joystickSaveMapping);\n  window.addEventListener(\'gamepadconnected\',event=>{\n    JOYSTICK.selectedIndex=event.gamepad.index;\n    JOYSTICK.preferredId=String(event.gamepad.id||(\'Gamepad \'+event.gamepad.index));\n    JOYSTICK.connectedOnce=true;\n    joystickSaveConfig();\n    joystickStopAcquireLoop();\n    joystickBackgroundScan();\n  });\n  window.addEventListener(\'gamepaddisconnected\',event=>{\n    joystickStopControl(\'Control disabled: joystick disconnected\',true);\n    if(JOYSTICK.selectedIndex===event.gamepad.index)JOYSTICK.selectedIndex=null;\n    JOYSTICK.disconnectCount+=1;\n    joystickBackgroundScan();\n    joystickAcquireBurst(\'USB controller disconnected\',JOYSTICK_STARTUP_ACQUIRE_MS);\n  });\n  document.addEventListener(\'visibilitychange\',()=>{\n    if(document.visibilityState===\'visible\')joystickWakeSequence(\'page became visible\');\n    else joystickStopControl(\'Control disabled: page hidden\',true);\n  });\n  window.addEventListener(\'pagehide\',()=>joystickStopControl(\'Control disabled: page closed\',true));\n  window.addEventListener(\'beforeunload\',()=>joystickStopControl(\'Control disabled: page closing\',true));\n  window.addEventListener(\'focus\',()=>joystickWakeSequence(\'window focused\'));\n  window.addEventListener(\'pageshow\',()=>joystickWakeSequence(\'page shown\'));\n  document.addEventListener(\'pointerup\',()=>joystickWakeSequence(\'screen tap\'),{passive:true});\n  document.addEventListener(\'touchend\',()=>joystickWakeSequence(\'screen touch\'),{passive:true});\n  document.addEventListener(\'keydown\',event=>{\n    if(event.key===\'Escape\'&&ARM_STATE_SELECTOR.open){\n      event.preventDefault();\n      setArmStateMenuOpen(false);\n    }else if(event.key===\'Escape\'&&FLIGHT_MODE_SELECTOR.open){\n      event.preventDefault();\n      setFlightModeMenuOpen(false);\n    }else if(event.key===\'Escape\'&&JOYSTICK.open){\n      joystickSetOpen(false);\n    }\n    joystickWakeSequence(\'controller/button keydown\');\n  },true);\n  document.addEventListener(\'keyup\',()=>joystickWakeSequence(\'controller/button keyup\'),true);\n  joystickRefresh(false);\n  joystickUpdateLauncher();\n  joystickAcquireBurst(\'page startup\',JOYSTICK_STARTUP_ACQUIRE_MS);\n  JOYSTICK.reconnectTimer=window.setInterval(joystickBackgroundScan,750);\n  joystickStartInputLoop();\n  joystickConnectControlSocket();\n  JOYSTICK.controlTimer=window.setInterval(joystickControlTick,JOYSTICK_CONTROL_INTERVAL_MS);\n}\n\nfunction speechSupported(){return \'speechSynthesis\' in window&&\'SpeechSynthesisUtterance\' in window;}\nfunction flightAudioSupported(){return Boolean(window.AudioContext||window.webkitAudioContext||window.Audio||speechSupported());}\nfunction flightAudioContext(){\n  if(GS.audioContext)return GS.audioContext;\n  const Context=window.AudioContext||window.webkitAudioContext;\n  if(!Context)return null;\n  try{GS.audioContext=new Context();}catch(error){console.warn(\'Flight AudioContext creation failed\',error);GS.audioContext=null;}\n  return GS.audioContext;\n}\nfunction flightAudioPrime(){\n  const context=flightAudioContext();\n  if(!context)return false;\n  try{\n    const resumed=context.state===\'suspended\'?context.resume():Promise.resolve();\n    Promise.resolve(resumed).catch(error=>console.warn(\'Flight audio resume failed\',error));\n    const buffer=context.createBuffer(1,1,22050);\n    const source=context.createBufferSource();\n    source.buffer=buffer;\n    source.connect(context.destination);\n    source.start(0);\n    return true;\n  }catch(error){console.warn(\'Flight audio prime failed\',error);return false;}\n}\nfunction stopFlightAudio(clearQueue=true){\n  if(clearQueue)GS.audioQueue=[];\n  if(GS.audioSource){try{GS.audioSource.stop(0);}catch(_e){}GS.audioSource=null;}\n  if(GS.audioElement){try{GS.audioElement.pause();}catch(_e){}GS.audioElement=null;}\n  if(speechSupported()){try{window.speechSynthesis.cancel();}catch(_e){}}\n  GS.audioPlaying=false;\n}\nfunction audioUi(){const enable=$(\'audioEnableBtn\'),mute=$(\'audioMuteBtn\'),test=$(\'audioTestBtn\'),volume=$(\'audioVolume\');const supported=flightAudioSupported(),active=supported&&GS.audioEnabled&&GS.audioUnlocked&&!GS.audioMuted;enable.disabled=!supported;setTopBannerToggleState(enable,active,\'Audio\');enable.title=!supported?\'Audio is not supported by this browser\':(!GS.audioUnlocked?\'Tap once to enable flight audio\':(active?\'Audio on\':\'Audio off\'));mute.disabled=!GS.audioEnabled||!GS.audioUnlocked;test.disabled=!GS.audioEnabled||!GS.audioUnlocked;mute.textContent=GS.audioMuted?\'Unmute\':\'Mute\';mute.classList.toggle(\'audio-muted\',GS.audioMuted);volume.value=String(GS.audioVolume);}\nasync function playServerFlightVoice(text){\n  const response=await fetch(\'/api/groundstation/tts?text=\'+encodeURIComponent(text)+\'&ts=\'+Date.now(),{cache:\'no-store\'});\n  if(!response.ok)throw new Error(\'TTS HTTP \'+response.status);\n  const bytes=await response.arrayBuffer();\n  const context=flightAudioContext();\n  if(context){\n    if(context.state===\'suspended\')await context.resume();\n    const decoded=await context.decodeAudioData(bytes.slice(0));\n    await new Promise((resolve,reject)=>{\n      const source=context.createBufferSource();\n      const gain=context.createGain();\n      gain.gain.value=Math.max(0,Math.min(1,GS.audioVolume));\n      source.buffer=decoded;\n      source.connect(gain);\n      gain.connect(context.destination);\n      GS.audioSource=source;\n      source.onended=()=>{if(GS.audioSource===source)GS.audioSource=null;resolve();};\n      try{source.start(0);}catch(error){if(GS.audioSource===source)GS.audioSource=null;reject(error);}\n    });\n    return;\n  }\n  const blob=new Blob([bytes],{type:\'audio/wav\'});\n  const url=URL.createObjectURL(blob);\n  try{\n    const audio=new Audio(url);\n    audio.volume=Math.max(0,Math.min(1,GS.audioVolume));\n    GS.audioElement=audio;\n    await audio.play();\n    await new Promise((resolve,reject)=>{audio.onended=resolve;audio.onerror=()=>reject(new Error(\'HTML audio playback failed\'));});\n  }finally{\n    GS.audioElement=null;\n    URL.revokeObjectURL(url);\n  }\n}\nfunction playBrowserSpeechFallback(text){\n  if(!speechSupported())return Promise.reject(new Error(\'No browser speech fallback\'));\n  return new Promise((resolve,reject)=>{\n    const utterance=new SpeechSynthesisUtterance(text);\n    utterance.volume=Math.max(0,Math.min(1,GS.audioVolume));\n    utterance.rate=1;\n    utterance.pitch=1;\n    utterance.onend=resolve;\n    utterance.onerror=event=>reject(new Error(\'Browser speech failed: \'+String(event&&event.error||\'unknown\')));\n    try{if(window.speechSynthesis.paused)window.speechSynthesis.resume();window.speechSynthesis.speak(utterance);}catch(error){reject(error);}\n  });\n}\nasync function flightAudioDrain(){\n  if(GS.audioPlaying||!GS.audioQueue.length||!GS.audioEnabled||!GS.audioUnlocked||GS.audioMuted)return;\n  const item=GS.audioQueue.shift();\n  GS.audioPlaying=true;\n  try{await playServerFlightVoice(item.text);}\n  catch(serverError){\n    console.warn(\'Server flight voice failed; using browser fallback\',serverError);\n    try{await playBrowserSpeechFallback(item.text);}catch(browserError){console.error(\'Flight audio failed\',browserError);}\n  }finally{\n    GS.audioPlaying=false;\n    if(GS.audioEnabled&&GS.audioUnlocked&&!GS.audioMuted&&GS.audioQueue.length)setTimeout(flightAudioDrain,20);\n  }\n}\nfunction speakFlight(text,key=\'\',force=false,interrupt=false){text=String(text||\'\').trim();if(!text||!GS.audioEnabled||!GS.audioUnlocked||GS.audioMuted||!flightAudioSupported())return;const now=Date.now(),dedupeKey=key||text.toLowerCase();if(!force&&GS.lastSpoken[dedupeKey]&&now-GS.lastSpoken[dedupeKey]<30000)return;GS.lastSpoken[dedupeKey]=now;if(interrupt)stopFlightAudio(true);GS.audioQueue.push({text:text,key:dedupeKey});flightAudioDrain();}\nfunction unlockFlightAudio(announce=true){if(!flightAudioSupported())return false;GS.audioEnabled=true;GS.audioMuted=false;flightAudioPrime();GS.audioUnlocked=true;audioUi();if(announce)speakFlight(\'Flight audio enabled\',\'audio-enabled\',true,true);return true;}\nfunction enableFlightAudio(){if(!unlockFlightAudio(false))return;const messages=(GS.state&&GS.state.messages)||[];GS.lastMessageTs=messages.reduce((latest,item)=>Math.max(latest,Number(item.ts)||0),GS.lastMessageTs);speakFlight(\'Flight audio enabled\',\'audio-enabled\',true,true);}\nfunction flightModeSpeech(mode){const text=String(mode||\'\').trim();if(!text)return\'\';return text.replace(/_/g,\' \').toLowerCase().replace(/\\b\\w/g,char=>char.toUpperCase());}\nfunction flightMessageSeverity(item){return String((item&&item.severity)||\'\').trim().toLowerCase();}\nfunction flightMessageText(text){const raw=String(text||\'\').replace(/\\s+/g,\' \').trim();if(!raw)return\'\';const upper=raw.toUpperCase();if(upper===\'REC STARTED\')return\'Recording started\';if(upper===\'REC STOPPED\')return\'Recording stopped\';if(upper===\'REC COMMAND FAILED\')return\'Record command failed\';return raw;}\nfunction shouldSpeakFlightMessage(item){const severity=flightMessageSeverity(item);if([\'emergency\',\'alert\',\'critical\',\'error\',\'warning\',\'warn\'].includes(severity))return true;const text=String((item&&item.text)||\'\').trim().toUpperCase();return text.startsWith(\'VIDEO SOURCE \')||text.startsWith(\'VIDEO SWITCH \')||text.startsWith(\'SAFETY BLOCK:\')||text.startsWith(\'FLAPS \')||text.startsWith(\'BATTERY VOLTAGE \')||text.startsWith(\'PI CPU TEMPERATURE \');}\nfunction processFlightAudio(state){if(!GS.audioEnabled)return;const c=state.connection||{},v=state.vehicle||{};if(GS.lastConnection!==null&&c.state!==GS.lastConnection){if(c.state===\'LINK_LOST\'||c.state===\'NO_VEHICLE\')speakFlight(\'Telemetry lost\',\'telemetry-lost\');else if(c.state===\'CONNECTED\'&&(GS.lastConnection===\'LINK_LOST\'||GS.lastConnection===\'NO_VEHICLE\'||GS.lastConnection===\'DEGRADED\'))speakFlight(\'Telemetry restored\',\'telemetry-restored\');}if(GS.lastMode!==null&&v.mode&&v.mode!==GS.lastMode){const modeText=flightModeSpeech(v.mode);speakFlight(modeText,\'mode-change\',true,true);}if(GS.lastArmed!==null&&typeof v.armed===\'boolean\'&&v.armed!==GS.lastArmed)speakFlight(v.armed?\'Aircraft armed\':\'Aircraft disarmed\',v.armed?\'armed\':\'disarmed\');const messages=(state.messages||[]).slice().sort((a,b)=>(Number(a.ts)||0)-(Number(b.ts)||0));for(const item of messages){const ts=Number(item.ts)||0;if(ts<=GS.lastMessageTs)continue;GS.lastMessageTs=Math.max(GS.lastMessageTs,ts);if(!shouldSpeakFlightMessage(item))continue;const spoken=flightMessageText(item.text);if(spoken)speakFlight(spoken,\'notice-\'+spoken.toLowerCase());}GS.lastConnection=c.state||null;GS.lastMode=v.mode||null;GS.lastArmed=typeof v.armed===\'boolean\'?v.armed:null;}\nfunction connectTelemetry(){const events=new EventSource(\'/api/groundstation/stream?ts=\'+Date.now());events.onmessage=event=>{try{updateState(JSON.parse(event.data));}catch(_e){}};events.onerror=()=>{setText(\'statusMessage\',\'Ground Station telemetry stream disconnected — reconnecting automatically\');};}\ndocument.querySelectorAll(\'[data-layout]\').forEach(button=>button.addEventListener(\'click\',()=>setLayout(button.dataset.layout===\'map\'?\'map_video\':\'video_dual\')));\ninitPhoneGroundStationViewport();\ninitMovablePip();\ninitMapVideoPip();\ninitVideoMapPip();\ninitRoundHud();\ninitMovableInstruments();\n$(\'resyncAirlinkBtn\').addEventListener(\'click\',()=>{const player=GS.players.wifilink_rtsp;if(player)player.reconnect(\'manual button\');});\n$(\'swapCamerasBtn\').addEventListener(\'click\',swapCameras);\n$(\'videoReconnect\').addEventListener(\'click\',()=>applyVideo(true));\n$(\'videoFallback\').addEventListener(\'click\',()=>setText(\'statusMessage\',\'HLS is disabled in Android low-latency mode\'));\n$(\'hudBtn\').addEventListener(\'click\',cycleHudMode);\n$(\'fullscreenBtn\').addEventListener(\'click\',async()=>{try{if(!document.fullscreenElement)await requestGroundStationFullscreen();else{rememberStableViewportLayout();await document.exitFullscreen();}}catch(_e){}});\n$(\'controlCenterBtn\').addEventListener(\'click\',()=>{window.location.href=\'/\';});\n$(\'modePill\').addEventListener(\'click\',event=>{\n  event.stopPropagation();\n  toggleFlightModeMenu();\n});\n$(\'flightModeMenuBackdrop\').addEventListener(\n  \'click\',\n  ()=>setFlightModeMenuOpen(false)\n);\n$(\'flightModeGrid\').addEventListener(\'keydown\',event=>{\n  const options=Array.from(\n    $(\'flightModeGrid\').querySelectorAll(\'.gs-mode-option:not(:disabled)\')\n  );\n  if(!options.length)return;\n  const index=Math.max(0,options.indexOf(document.activeElement));\n  let target=null;\n  if(event.key===\'ArrowDown\')target=options[(index+1)%options.length];\n  else if(event.key===\'ArrowUp\')target=options[(index-1+options.length)%options.length];\n  else if(event.key===\'Home\')target=options[0];\n  else if(event.key===\'End\')target=options[options.length-1];\n  if(target){\n    event.preventDefault();\n    target.focus({preventScroll:true});\n    target.scrollIntoView({block:\'nearest\'});\n  }\n});\n\n$(\'armStatePill\').addEventListener(\'click\',event=>{\n  event.stopPropagation();\n  toggleArmStateMenu();\n});\n$(\'armStateMenuBackdrop\').addEventListener(\n  \'click\',\n  ()=>setArmStateMenuOpen(false)\n);\n$(\'armStateGrid\').addEventListener(\'keydown\',event=>{\n  const options=Array.from(\n    $(\'armStateGrid\').querySelectorAll(\'.gs-arm-option:not(:disabled)\')\n  );\n  if(!options.length)return;\n  const index=Math.max(0,options.indexOf(document.activeElement));\n  let target=null;\n  if(event.key===\'ArrowDown\')target=options[(index+1)%options.length];\n  else if(event.key===\'ArrowUp\')target=options[(index-1+options.length)%options.length];\n  else if(event.key===\'Home\')target=options[0];\n  else if(event.key===\'End\')target=options[options.length-1];\n  if(target){\n    event.preventDefault();\n    target.focus({preventScroll:true});\n    target.scrollIntoView({block:\'nearest\'});\n  }\n});\n/* Telemetry button is initialized by initMovableInstruments(). */\n$(\'connectionChip\').addEventListener(\'click\',event=>{event.stopPropagation();toggleMessages();});\n$(\'messagePopoverClose\').addEventListener(\'click\',()=>setMessagesOpen(false));\ndocument.addEventListener(\'pointerdown\',event=>{const popover=$(\'messagePopover\');if(popover.classList.contains(\'open\')&&!popover.contains(event.target)&&!$(\'connectionChip\').contains(event.target))setMessagesOpen(false);});\ndocument.querySelectorAll(\'[data-map]\').forEach(button=>button.addEventListener(\'click\',()=>{if(!GS.map||!GS.mapReady){ensureGroundStationMap();return;}if(button.dataset.map===\'plus\')GS.map.zoomIn(1);else if(button.dataset.map===\'minus\')GS.map.zoomOut(1);else if(button.dataset.map===\'follow\')mapFollowAircraft();else mapFitAll();}));\ndocument.querySelectorAll(\'[data-map-style]\').forEach(button=>button.addEventListener(\'click\',()=>mapApplyStyle(button.dataset.mapStyle)));\n$(\'audioEnableBtn\').addEventListener(\'click\',()=>{if(!GS.audioUnlocked||!GS.audioEnabled){enableFlightAudio();}else{GS.audioEnabled=false;stopFlightAudio(true);audioUi();}});\n$(\'audioMuteBtn\').addEventListener(\'click\',()=>{if(!GS.audioUnlocked)unlockFlightAudio(false);GS.audioMuted=!GS.audioMuted;if(GS.audioMuted)stopFlightAudio(true);audioUi();try{localStorage.setItem(\'siyi-groundstation-audio-muted\',GS.audioMuted?\'1\':\'0\');}catch(_e){}});\n$(\'audioTestBtn\').addEventListener(\'click\',()=>{if(!GS.audioUnlocked)unlockFlightAudio(false);speakFlight(\'Ground Station flight audio test\',\'audio-test\',true,true);});\n$(\'audioVolume\').addEventListener(\'input\',event=>{GS.audioVolume=Number(event.target.value)||0;try{localStorage.setItem(\'siyi-groundstation-audio-volume\',String(GS.audioVolume));}catch(_e){}});\nwindow.addEventListener(\'resize\',syncGroundStationViewport);\nwindow.addEventListener(\'resize\',()=>{if(FLIGHT_MODE_SELECTOR.open)flightModePositionMenu();},{passive:true});\nwindow.addEventListener(\'resize\',()=>{if(ARM_STATE_SELECTOR.open)armStatePositionMenu();},{passive:true});\nwindow.addEventListener(\'resize\',()=>{if(GS.map)setTimeout(()=>GS.map.invalidateSize({pan:false,animate:false}),0);},{passive:true});\ndocument.addEventListener(\'visibilitychange\',()=>{if(document.hidden){GS.hiddenAt=Date.now();}else if(GS.hiddenAt&&Date.now()-GS.hiddenAt>4000){const player=GS.players.wifilink_rtsp;if(player)player.reconnect(\'Android page resumed\');GS.hiddenAt=0;}});\nwindow.addEventListener(\'pageshow\',event=>{if(event.persisted){const player=GS.players.wifilink_rtsp;if(player)player.reconnect(\'page restored\');}});\nwindow.addEventListener(\'beforeunload\',()=>{\n  setArmStateMenuOpen(false,false);\n  setFlightModeMenuOpen(false);\n  if(GS_UI_EVENT_STREAM)GS_UI_EVENT_STREAM.close();\n  stopGroundStationUiEventFallback();\n  Object.values(GS.players).forEach(player=>player.close(false));});\ntry{const savedPrimary=localStorage.getItem(\'siyi-groundstation-primary-camera\');if(savedPrimary===\'wifilink_rtsp\'){GS.primarySource=\'wifilink_rtsp\';GS.secondarySource=\'siyi_rtsp\';}const savedVolume=Number(localStorage.getItem(\'siyi-groundstation-audio-volume\'));if(Number.isFinite(savedVolume))GS.audioVolume=Math.max(0,Math.min(1,savedVolume));GS.audioEnabled=true;GS.audioMuted=false;GS.audioUnlocked=false;setLayout(localStorage.getItem(\'siyi-groundstation-layout\')||\'video_dual\');applyHudMode(localStorage.getItem(GS_HUD_MODE_KEY)||\'full\',false);}catch(_e){GS.audioEnabled=true;GS.audioMuted=false;GS.audioUnlocked=false;setLayout(\'video_dual\');applyHudMode(\'full\',false);}\nfunction unlockFlightAudioFromTrustedInteraction(event){if(!event||!event.isTrusted||GS.audioUnlocked||!GS.audioEnabled)return;const target=event.target;if(target&&target.closest&&target.closest(\'#audioEnableBtn,#audioMuteBtn,#audioTestBtn\'))return;unlockFlightAudio(false);}\ndocument.addEventListener(\'pointerdown\',unlockFlightAudioFromTrustedInteraction,{capture:true,passive:true});\ndocument.addEventListener(\'keydown\',unlockFlightAudioFromTrustedInteraction,{capture:true});\ninitJoystickUi();audioUi();refreshVideoSource();connectGroundStationUiEvents();refreshGroundStationVoiceEvent();refreshRecordingState();setInterval(refreshVideoSource,1000);setInterval(refreshGroundStationVoiceEvent,250);setInterval(refreshRecordingState,250);connectTelemetry();\n</script>\n</body>\n</html>'
    template = template.replace("__MAPTILER_API_KEY_JSON__", json.dumps(""))
    template = template.replace(
        "__GS_FLIGHT_MODE_ACTIONS_JSON__",
        json.dumps(FLIGHT_SAFETY_ACTIONS, separators=(",", ":")),
    )
    if app_mode:
        # GROUNDSTATION_V14_DEDICATED_APP_ROUTE
        # Mark the installed-app document before CSS is evaluated. Portrait
        # blocking therefore does not depend on display-mode/referrer detection.
        template = template.replace(
            '<html lang="en">',
            '<html lang="en" class="gs-installed-pwa" data-groundstation-app="1">',
            1,
        )
    return template


_groundstation_previous_nav_html = _v9_nav_html


def _v9_nav_html():
    navigation = _groundstation_previous_nav_html()
    if "href='/groundstation'" not in navigation:
        target = "  <a class='v9-nav-link' data-workspace='connectivity' href='/connectivity'>"
        entry = "  <a class='v9-nav-link' data-workspace='groundstation' href='/groundstation'><span class='v9-nav-icon'>G</span><span>Ground Station</span></a>\n"
        navigation = navigation.replace(target, entry + target, 1)
    return navigation


_groundstation_previous_get = H.do_GET


def _groundstation_do_GET(self):
    parsed = urllib.parse.urlparse(self.path)
    path = parsed.path
    if software_update_lock_active() and path.startswith("/api/groundstation"):
        _groundstation_send_json(self, "/health")
        return
    if software_update_lock_active() and path in ("/groundstation", "/groundstation-app"):
        return _groundstation_previous_get(self)
    if path in ("/groundstation", "/groundstation-app"):
        query = urllib.parse.parse_qs(parsed.query)
        source = (query.get("source") or [""])[0]
        app_mode = path == "/groundstation-app" or source == "pwa"
        raw = _groundstation_page(app_mode=app_mode).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)
        return
    if path == "/api/groundstation/health":
        _groundstation_send_json(self, "/health")
        return
    if path == "/api/groundstation/state":
        _groundstation_send_json(self, "/state")
        return
    if path == "/api/groundstation/messages":
        _groundstation_send_json(self, "/messages")
        return
    if path == "/api/groundstation/stream":
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        request = urllib.request.Request(
            GROUNDSTATION_INTERNAL_BASE + "/stream",
            headers={"User-Agent": "SIYI-WebUI-GroundStation/1"},
        )
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                while True:
                    line = response.readline()
                    if not line:
                        break
                    self.wfile.write(line)
                    self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            pass
        except Exception as exc:
            try:
                payload = json.dumps({"error": str(exc)}, separators=(",", ":"))
                self.wfile.write(("event: error\ndata: " + payload + "\n\n").encode("utf-8"))
                self.wfile.flush()
            except Exception:
                pass
        return
    return _groundstation_previous_get(self)


H.do_GET = _groundstation_do_GET
# GROUND_STATION_MONITOR_POC_V1_END


# GROUND_STATION_USB_JOYSTICK_STAGE1_V1_BACKEND
JOYSTICK_INTERNAL_BASE = "http://127.0.0.1:18766"


def _joystick_internal_request(path, method="GET", body=None, timeout=5.0):
    data = None if body is None else body
    request = urllib.request.Request(
        JOYSTICK_INTERNAL_BASE + path,
        data=data,
        method=method,
        headers={"User-Agent": "SIYI-WebUI-Joystick/1", "Content-Type": "application/json"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.status, response.read(4 * 1024 * 1024)


def _joystick_proxy_json(handler, path, method="GET", body=None):
    try:
        status, raw = _joystick_internal_request(path, method=method, body=body)
        json.loads(raw.decode("utf-8"))
    except urllib.error.HTTPError as exc:
        status = exc.code
        raw = exc.read(4 * 1024 * 1024)
    except Exception as exc:
        status = 503
        raw = json.dumps({"ok": False, "error": "Joystick backend unavailable", "detail": str(exc)}, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def _joystick_read_body(handler):
    length = min(1024 * 1024, int(handler.headers.get("Content-Length", "0") or 0))
    return handler.rfile.read(length) if length else b"{}"


_joystick_previous_get = H.do_GET


def _joystick_do_GET(self):
    parsed = urllib.parse.urlparse(self.path)
    path = parsed.path
    if path == "/api/joystick/health":
        return _joystick_proxy_json(self, "/health")
    if path == "/api/joystick/status":
        return _joystick_proxy_json(self, "/status")
    if path == "/api/joystick/config":
        return _joystick_proxy_json(self, "/config")
    if path == "/api/joystick/stream":
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        request = urllib.request.Request(JOYSTICK_INTERNAL_BASE + "/stream", headers={"User-Agent": "SIYI-WebUI-Joystick/1"})
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                while True:
                    line = response.readline()
                    if not line:
                        break
                    self.wfile.write(line)
                    self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            pass
        except Exception as exc:
            try:
                payload = json.dumps({"error": str(exc)}, separators=(",", ":"))
                self.wfile.write(("event: error\ndata: " + payload + "\n\n").encode("utf-8"))
                self.wfile.flush()
            except Exception:
                pass
        return
    return _joystick_previous_get(self)


H.do_GET = _joystick_do_GET
_joystick_previous_post = H.do_POST


def _joystick_do_POST(self):
    path = urllib.parse.urlparse(self.path).path
    routes = {
        "/api/joystick/device/select": "/device/select",
        "/api/joystick/calibration/start": "/calibration/start",
        "/api/joystick/calibration/save": "/calibration/save",
        "/api/joystick/calibration/cancel": "/calibration/cancel",
        "/api/joystick/test/start": "/test/start",
        "/api/joystick/test/stop": "/test/stop",
    }
    if path in routes:
        return _joystick_proxy_json(self, routes[path], method="POST", body=_joystick_read_body(self))
    return _joystick_previous_post(self)


H.do_POST = _joystick_do_POST


def _joystick_do_PUT(self):
    path = urllib.parse.urlparse(self.path).path
    if path == "/api/joystick/config":
        return _joystick_proxy_json(self, "/config", method="PUT", body=_joystick_read_body(self))
    self.send_error(404)


H.do_PUT = _joystick_do_PUT
# GROUND_STATION_USB_JOYSTICK_STAGE1_V1_BACKEND_END

# GROUND_STATION_ANDROID_JOYSTICK_CONTROL_STAGE2_V10_RECORD_INDICATOR_BACKEND
# GROUNDSTATION_V12_OPEN_ITEMS_ROUND_HUD_TIMESTAMP_PWA
_GS_JOYSTICK_BRIDGE_ADDRESS = ("127.0.0.1", 18767)
_GS_GROUNDSTATION_UI_EVENT_FILE = "/tmp/siyi_groundstation_ui_event.json"
_GS_GROUNDSTATION_RECORD_STATE_FILE = "/tmp/siyi_groundstation_recording.json"
_GS_JOYSTICK_CONTROL_SOCKET = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
_GS_JOYSTICK_CONTROL_LOCK = threading.Lock()
_GS_JOYSTICK_CONTROL_SESSIONS = {}
_GS_JOYSTICK_BUTTON_EVENT_IDS = {}
_GS_JOYSTICK_DIRECT_ACTION_IDS = {}
_GS_JOYSTICK_CONTROL_STATUS = {
    "last_rx": 0.0,
    "last_client": "",
    "session": "",
    "seq": -1,
    "enabled": False,
}


def _gs_joystick_send_json(handler, payload, status=200):
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def _gs_joystick_control_post(handler):
    try:
        length = int(handler.headers.get("Content-Length", "0") or 0)
        if length < 2 or length > 8192:
            return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid body length"}, 400)
        payload = json.loads(handler.rfile.read(length).decode("utf-8"))
        if not isinstance(payload, dict) or int(payload.get("version", 0)) != 1:
            return _gs_joystick_send_json(handler, {"ok": False, "error": "Unsupported control payload"}, 400)

        session = str(payload.get("session") or "").strip()
        if not session or len(session) > 96 or not re.fullmatch(r"[A-Za-z0-9._:-]+", session):
            return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid session"}, 400)
        seq = int(payload.get("seq", -1))
        if seq < 0 or seq > 2147483647:
            return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid sequence"}, 400)

        axes_in = payload.get("axes") or {}
        if not isinstance(axes_in, dict):
            return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid axes"}, 400)
        axes = {}
        for name in ("roll", "pitch", "yaw", "throttle"):
            value = float(axes_in.get(name, 0.0))
            if not math.isfinite(value):
                return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid axis " + name}, 400)
            axes[name] = max(-1.0, min(1.0, value))

        buttons = int(payload.get("buttons", 0)) & 0xFFFF
        enabled = bool(payload.get("enabled"))
        connected = bool(payload.get("connected"))
        raw_events = payload.get("button_events") or []
        if not isinstance(raw_events, list) or len(raw_events) > 64:
            return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid button events"}, 400)
        parsed_events = []
        for item in raw_events:
            if not isinstance(item, dict):
                return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid button event"}, 400)
            event_id = int(item.get("id", -1))
            event_mask = int(item.get("mask", 0)) & 0xFFFF
            event_client_ms = int(item.get("client_ms", 0) or 0)
            if event_id < 0 or event_id > 2147483647:
                return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid button event id"}, 400)
            if event_client_ms < 0 or event_client_ms > 9999999999999:
                return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid button event time"}, 400)
            parsed_events.append({"id": event_id, "mask": event_mask, "client_ms": event_client_ms})

        raw_actions = payload.get("direct_actions") or []
        if not isinstance(raw_actions, list) or len(raw_actions) > 16:
            return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid direct actions"}, 400)
        parsed_actions = []
        for item in raw_actions:
            if not isinstance(item, dict):
                return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid direct action"}, 400)
            action_id = int(item.get("id", -1))
            action_name = str(item.get("action", "")).strip().upper()
            action_client_ms = int(item.get("client_ms", 0) or 0)
            if action_id < 0 or action_id > 2147483647:
                return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid direct action id"}, 400)
            if action_name not in {"RECORD_TOGGLE"}:
                return _gs_joystick_send_json(handler, {"ok": False, "error": "Unsupported direct action"}, 400)
            if action_client_ms < 0 or action_client_ms > 9999999999999:
                return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid direct action time"}, 400)
            parsed_actions.append({"id": action_id, "action": action_name, "client_ms": action_client_ms})

        if not enabled or not connected:
            buttons = 0
            parsed_events = []
            parsed_actions = []
            enabled = False

        now = time.monotonic()
        with _GS_JOYSTICK_CONTROL_LOCK:
            previous = _GS_JOYSTICK_CONTROL_SESSIONS.get(session, -1)
            if seq <= previous:
                return _gs_joystick_send_json(handler, {"ok": False, "error": "Stale sequence"}, 409)
            _GS_JOYSTICK_CONTROL_SESSIONS[session] = seq
            if len(_GS_JOYSTICK_CONTROL_SESSIONS) > 16:
                _GS_JOYSTICK_CONTROL_SESSIONS.clear()
                _GS_JOYSTICK_BUTTON_EVENT_IDS.clear()
                _GS_JOYSTICK_DIRECT_ACTION_IDS.clear()
                _GS_JOYSTICK_CONTROL_SESSIONS[session] = seq

            last_event_id = _GS_JOYSTICK_BUTTON_EVENT_IDS.get(session, -1)
            new_events = [item for item in parsed_events if item["id"] > last_event_id]
            if new_events:
                _GS_JOYSTICK_BUTTON_EVENT_IDS[session] = max(item["id"] for item in new_events)

            last_action_id = _GS_JOYSTICK_DIRECT_ACTION_IDS.get(session, -1)
            new_actions = [item for item in parsed_actions if item["id"] > last_action_id]
            if new_actions:
                _GS_JOYSTICK_DIRECT_ACTION_IDS[session] = max(item["id"] for item in new_actions)

            bridge_payload = {
                "version": 1,
                "session": session,
                "seq": seq,
                "server_monotonic": now,
                "enabled": enabled,
                "connected": connected,
                "axes": axes,
                "buttons": buttons,
                "button_events": new_events,
                "direct_actions": new_actions,
            }
            raw = json.dumps(bridge_payload, separators=(",", ":")).encode("utf-8")
            _GS_JOYSTICK_CONTROL_SOCKET.sendto(raw, _GS_JOYSTICK_BRIDGE_ADDRESS)
            _GS_JOYSTICK_CONTROL_STATUS.update({
                "last_rx": now,
                "last_client": str(handler.client_address[0]),
                "session": session,
                "seq": seq,
                "enabled": enabled,
            })

        return _gs_joystick_send_json(handler, {"ok": True, "enabled": enabled, "seq": seq, "events": len(new_events), "actions": len(new_actions)}, 200)
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        return _gs_joystick_send_json(handler, {"ok": False, "error": "Invalid control payload", "detail": str(exc)}, 400)
    except Exception as exc:
        return _gs_joystick_send_json(handler, {"ok": False, "error": "Control bridge unavailable", "detail": str(exc)}, 503)


def _gs_groundstation_read_ui_event():
    event = {"ok": True, "event_id": "", "action": ""}
    try:
        with open(_GS_GROUNDSTATION_UI_EVENT_FILE, encoding="utf-8") as handle:
            loaded = json.load(handle)
        if isinstance(loaded, dict):
            event["event_id"] = str(loaded.get("event_id", ""))
            event["action"] = str(loaded.get("action", ""))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    return event


def _gs_groundstation_stream_ui_events(handler):
    handler.send_response(200)
    handler.send_header("Content-Type", "text/event-stream; charset=utf-8")
    handler.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
    handler.send_header("X-Accel-Buffering", "no")
    handler.send_header("Connection", "keep-alive")
    handler.end_headers()

    deadline = time.monotonic() + 300.0
    next_heartbeat = time.monotonic() + 10.0
    last_mtime_ns = -1
    last_event_id = None

    try:
        handler.wfile.write(b"retry: 250\n\n")
        handler.wfile.flush()
        while time.monotonic() < deadline:
            mtime_ns = -1
            try:
                mtime_ns = os.stat(_GS_GROUNDSTATION_UI_EVENT_FILE).st_mtime_ns
            except OSError:
                pass

            if mtime_ns != last_mtime_ns:
                last_mtime_ns = mtime_ns
                event = _gs_groundstation_read_ui_event()
                event_id = str(event.get("event_id") or "")
                if event_id and event_id != last_event_id:
                    raw = json.dumps(
                        event, ensure_ascii=False, separators=(",", ":")
                    ).encode("utf-8")
                    handler.wfile.write(b"data: " + raw + b"\n\n")
                    handler.wfile.flush()
                    last_event_id = event_id

            now = time.monotonic()
            if now >= next_heartbeat:
                handler.wfile.write(b": keepalive\n\n")
                handler.wfile.flush()
                next_heartbeat = now + 10.0

            time.sleep(0.02)
    except (BrokenPipeError, ConnectionResetError, OSError):
        pass
    finally:
        handler.close_connection = True


_stage2_previous_get = H.do_GET


def _stage2_do_GET(self):
    path = urllib.parse.urlparse(self.path).path
    if path == "/api/groundstation/joystick/control/status":
        with _GS_JOYSTICK_CONTROL_LOCK:
            status = dict(_GS_JOYSTICK_CONTROL_STATUS)
        age = None if not status.get("last_rx") else max(0, int((time.monotonic() - status["last_rx"]) * 1000))
        status.update({"ok": True, "age_ms": age, "bridge_port": _GS_JOYSTICK_BRIDGE_ADDRESS[1]})
        return _gs_joystick_send_json(self, status, 200)
    if path == "/api/groundstation/ui-events/stream":
        return _gs_groundstation_stream_ui_events(self)
    if path == "/api/groundstation/ui-events":
        return _gs_joystick_send_json(
            self, _gs_groundstation_read_ui_event(), 200
        )
    if path == "/api/groundstation/recording-state":
        state = {"ok": True, "recording": False, "updated_at": 0.0, "source": "bridge"}
        try:
            with open(_GS_GROUNDSTATION_RECORD_STATE_FILE, encoding="utf-8") as handle:
                loaded = json.load(handle)
            if isinstance(loaded, dict):
                state["recording"] = bool(loaded.get("recording", False))
                state["updated_at"] = float(loaded.get("updated_at", 0.0) or 0.0)
                state["source"] = str(loaded.get("source", "bridge"))
        except (FileNotFoundError, json.JSONDecodeError, OSError, TypeError, ValueError):
            pass
        return _gs_joystick_send_json(self, state, 200)
    return _stage2_previous_get(self)


H.do_GET = _stage2_do_GET
_stage2_previous_post = H.do_POST


def _stage2_do_POST(self):
    path = urllib.parse.urlparse(self.path).path
    if path == "/api/groundstation/joystick/control":
        return _gs_joystick_control_post(self)
    return _stage2_previous_post(self)


H.do_POST = _stage2_do_POST
# GROUND_STATION_ANDROID_JOYSTICK_CONTROL_STAGE2_V10_RECORD_INDICATOR_BACKEND_END


# GROUNDSTATION_V11_HUD_MEDIA_PWA_BACKEND
_GS_GROUNDSTATION_VOICE_EVENT_FILE = "/tmp/siyi_groundstation_voice_event.json"


def _v11_send_json(handler, payload, status=200):
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def _v11_camera_command_from_form(values):
    if "cmd" in values:
        return str(values.get("cmd", ""))
    for key, default in (("brightness", "50"), ("saturation", "60"), ("contrast", "50"), ("ev", "0"), ("ss", "0")):
        if key in values:
            return key + ":" + str(values.get(key, default))
    return ""


def _v11_stream_remote_file(handler, url, attachment_name=None):
    if not str(url).startswith(CAM_SD_BASE + "/"):
        handler.send_error(400, "Invalid camera SD URL")
        return
    request_headers = {"User-Agent": "SIYI-WebUI-Media/11", "Cache-Control": "no-cache"}
    range_header = handler.headers.get("Range")
    if range_header:
        request_headers["Range"] = range_header
    request = urllib.request.Request(url, headers=request_headers)
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            status = int(getattr(response, "status", 200) or 200)
            handler.send_response(status)
            for name in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges", "Last-Modified", "ETag"):
                value = response.headers.get(name)
                if value:
                    handler.send_header(name, value)
            if attachment_name:
                safe_name = os.path.basename(attachment_name).replace('"', "") or "camera_file.mp4"
                encoded_name = urllib.parse.quote(safe_name)
                handler.send_header("Content-Disposition", 'attachment; filename="%s"; filename*=UTF-8\'\'%s' % (safe_name, encoded_name))
            handler.send_header("Cache-Control", "no-store")
            handler.end_headers()
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                handler.wfile.write(chunk)
    except (BrokenPipeError, ConnectionResetError):
        pass
    except urllib.error.HTTPError as exc:
        handler.send_error(exc.code, "Camera SD download failed")
    except Exception as exc:
        handler.send_error(502, "Camera SD download failed: " + str(exc))


_v11_previous_get = H.do_GET


def _v11_do_GET(self):
    parsed = urllib.parse.urlparse(self.path)
    path = parsed.path
    if path == "/groundstation.webmanifest":
        manifest = {
            "id": "/groundstation-app",
            "name": "SIYI Ground Station",
            "short_name": "SIYI GS",
            "start_url": "/groundstation-app?v=19",
            "scope": "/",
            "display": "standalone",
            "display_override": ["fullscreen", "standalone"],
            "background_color": "#020617",
            "theme_color": "#020617",
            "orientation": "landscape",
        }
        raw = json.dumps(manifest, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/manifest+json; charset=utf-8")
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)
        return
    if path == "/api/groundstation/voice-event":
        event = {"ok": True, "event_id": "", "text": "", "ts": 0.0}
        try:
            with open(_GS_GROUNDSTATION_VOICE_EVENT_FILE, encoding="utf-8") as handle:
                loaded = json.load(handle)
            if isinstance(loaded, dict):
                event["event_id"] = str(loaded.get("event_id", ""))
                event["text"] = str(loaded.get("text", ""))
                event["ts"] = float(loaded.get("ts", 0.0) or 0.0)
        except (FileNotFoundError, json.JSONDecodeError, OSError, TypeError, ValueError):
            pass
        return _v11_send_json(self, event, 200)
    if path == "/camera_sd_download":
        params = urllib.parse.parse_qs(parsed.query)
        url = (params.get("url") or [""])[0]
        filename = os.path.basename(urllib.parse.urlparse(url).path) or "camera_file.mp4"
        return _v11_stream_remote_file(self, url, filename)
    return _v11_previous_get(self)


H.do_GET = _v11_do_GET
_v11_previous_post = H.do_POST


def _v11_do_POST(self):
    path = urllib.parse.urlparse(self.path).path
    if path == "/unigcs_control":
        try:
            length = min(65536, int(self.headers.get("Content-Length", "0") or 0))
            body = self.rfile.read(length).decode("utf-8", errors="replace") if length else ""
            parsed = urllib.parse.parse_qs(body, keep_blank_values=True)
            values = {key: items[-1] if items else "" for key, items in parsed.items()}
            command = _v11_camera_command_from_form(values)
            if not command:
                return _v11_send_json(self, {"ok": False, "error": "No camera command"}, 400)
            result = send_unigcs_fifo(command)
            try:
                with open("/tmp/siyi_webui_last_action", "w", encoding="utf-8") as handle:
                    handle.write(str(result))
            except Exception:
                pass
            return _v11_send_json(self, {"ok": True, "command": command, "result": str(result)}, 200)
        except Exception as exc:
            return _v11_send_json(self, {"ok": False, "error": str(exc)}, 502)
    if path == "/camera_sd_zip":
        temporary_path = ""
        try:
            length = min(2 * 1024 * 1024, int(self.headers.get("Content-Length", "0") or 0))
            body = self.rfile.read(length).decode("utf-8", errors="replace") if length else ""
            parsed = urllib.parse.parse_qs(body, keep_blank_values=True)
            urls = [url for url in parsed.get("urls", []) if str(url).startswith(CAM_SD_BASE + "/")]
            if not urls:
                return self.send_error(400, "No valid camera files selected")
            fd, temporary_path = tempfile.mkstemp(prefix="siyi-camera-", suffix=".zip")
            os.close(fd)
            used_names = set()
            with zipfile.ZipFile(temporary_path, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as archive:
                for index, url in enumerate(urls, start=1):
                    name = os.path.basename(urllib.parse.urlparse(url).path) or ("camera_file_%d.mp4" % index)
                    base, extension = os.path.splitext(name)
                    candidate = name
                    duplicate = 2
                    while candidate in used_names:
                        candidate = "%s_%d%s" % (base, duplicate, extension)
                        duplicate += 1
                    used_names.add(candidate)
                    request = urllib.request.Request(url, headers={"User-Agent": "SIYI-WebUI-Media/11", "Cache-Control": "no-cache"})
                    with urllib.request.urlopen(request, timeout=60) as response, archive.open(candidate, "w", force_zip64=True) as target:
                        shutil.copyfileobj(response, target, length=1024 * 1024)
            size = os.path.getsize(temporary_path)
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition", 'attachment; filename="camera_sd_selected.zip"')
            self.send_header("Content-Length", str(size))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with open(temporary_path, "rb") as handle:
                shutil.copyfileobj(handle, self.wfile, length=1024 * 1024)
            return
        except (BrokenPipeError, ConnectionResetError):
            return
        except Exception as exc:
            return self.send_error(502, "Camera SD ZIP failed: " + str(exc))
        finally:
            if temporary_path:
                try:
                    os.unlink(temporary_path)
                except OSError:
                    pass
    return _v11_previous_post(self)


H.do_POST = _v11_do_POST
# GROUNDSTATION_V11_HUD_MEDIA_PWA_BACKEND_END


# GROUNDSTATION_V18_LEAFLET_PI_TILE_PROXY_BACKEND
_GS_LEAFLET_VENDOR_DIR = "/home/pi/siyi-webui/vendor/leaflet"
_GS_MAP_TILE_CACHE_DIR = "/var/cache/siyi-maptiler"
_GS_MAP_TILE_STYLES = {"hybrid": "hybrid", "satellite": "satellite"}


def _v18_send_local_file(handler, path, content_type, cache_control):
    try:
        size = os.path.getsize(path)
        handler.send_response(200)
        handler.send_header("Content-Type", content_type)
        handler.send_header("Content-Length", str(size))
        handler.send_header("Cache-Control", cache_control)
        handler.end_headers()
        with open(path, "rb") as source:
            shutil.copyfileobj(source, handler.wfile, length=128 * 1024)
    except FileNotFoundError:
        handler.send_error(404, "Local map asset missing")
    except (BrokenPipeError, ConnectionResetError):
        pass
    except Exception as exc:
        handler.send_error(500, "Local map asset failed: " + str(exc))


def _v18_maptiler_key():
    try:
        with open(_GROUNDSTATION_MAPTILER_CONFIG, encoding="utf-8") as handle:
            data = json.load(handle)
        return str(data.get("api_key") or "").strip()
    except Exception:
        return ""


def _v18_map_tile(handler, style, z_text, x_text, y_text):
    try:
        z = int(z_text)
        x = int(x_text)
        y = int(y_text)
    except ValueError:
        return handler.send_error(400, "Invalid map tile coordinate")
    map_id = _GS_MAP_TILE_STYLES.get(style)
    limit = 1 << z if 0 <= z <= 20 else 0
    if not map_id or not limit or x < 0 or y < 0 or x >= limit or y >= limit:
        return handler.send_error(404, "Map tile outside supported range")
    cache_path = os.path.join(_GS_MAP_TILE_CACHE_DIR, style, str(z), str(x), str(y) + ".jpg")
    if os.path.isfile(cache_path) and os.path.getsize(cache_path) > 100:
        return _v18_send_local_file(handler, cache_path, "image/jpeg", "public, max-age=2592000, immutable")
    key = _v18_maptiler_key()
    if not key:
        return handler.send_error(503, "MapTiler API key is not configured")
    url = (
        "https://api.maptiler.com/maps/"
        + map_id
        + "/256/"
        + str(z)
        + "/"
        + str(x)
        + "/"
        + str(y)
        + ".jpg?key="
        + urllib.parse.quote(key, safe="")
    )
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "SIYI-GroundStation-MapProxy/18",
            "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
            "Cache-Control": "no-cache",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            content_type = str(response.headers.get("Content-Type") or "").split(";", 1)[0].strip().lower()
            raw = response.read(2 * 1024 * 1024 + 1)
        if len(raw) > 2 * 1024 * 1024 or not content_type.startswith("image/") or len(raw) < 100:
            raise ValueError("MapTiler returned an invalid tile response")
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        temporary = cache_path + ".tmp." + str(os.getpid()) + "." + str(threading.get_ident())
        with open(temporary, "wb") as handle:
            handle.write(raw)
        os.replace(temporary, cache_path)
        return _v18_send_local_file(handler, cache_path, content_type, "public, max-age=2592000, immutable")
    except urllib.error.HTTPError as exc:
        return handler.send_error(exc.code, "MapTiler tile request failed")
    except (BrokenPipeError, ConnectionResetError):
        return
    except Exception as exc:
        return handler.send_error(502, "MapTiler tile proxy failed: " + str(exc))


_v18_previous_get = H.do_GET


def _v18_do_GET(self):
    parsed = urllib.parse.urlparse(self.path)
    path = parsed.path
    if path == "/groundstation/vendor/leaflet.js":
        return _v18_send_local_file(self, os.path.join(_GS_LEAFLET_VENDOR_DIR, "leaflet.js"), "application/javascript; charset=utf-8", "public, max-age=31536000, immutable")
    if path == "/groundstation/vendor/leaflet.css":
        return _v18_send_local_file(self, os.path.join(_GS_LEAFLET_VENDOR_DIR, "leaflet.css"), "text/css; charset=utf-8", "public, max-age=31536000, immutable")
    match = re.fullmatch(r"/api/groundstation/maptile/(hybrid|satellite)/(\d+)/(\d+)/(\d+)\.jpg", path)
    if match:
        return _v18_map_tile(self, *match.groups())
    return _v18_previous_get(self)


H.do_GET = _v18_do_GET
# GROUNDSTATION_V18_LEAFLET_PI_TILE_PROXY_BACKEND_END


# GROUND_STATION_TELEMETRY_CANVAS_V2_BACKEND_PROXY

def _telemetry_canvas_proxy(handler, internal_path, method="GET"):
    body = None
    if method == "POST":
        try:
            length = int(handler.headers.get("Content-Length", "0") or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > 1024 * 1024:
            return handler.send_error(400, "Invalid Telemetry Canvas request")
        body = handler.rfile.read(length)
    request = urllib.request.Request(
        GROUNDSTATION_INTERNAL_BASE + internal_path,
        data=body,
        method=method,
        headers={"User-Agent": "SIYI-WebUI-Telemetry-Canvas/2", "Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=8) as response:
            raw = response.read(8 * 1024 * 1024)
            status = response.status
    except urllib.error.HTTPError as exc:
        raw = exc.read(1024 * 1024)
        status = exc.code
    except Exception as exc:
        raw = json.dumps({"ok": False, "error": "Telemetry backend unavailable", "detail": str(exc)}).encode("utf-8")
        status = 503
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


_telemetry_canvas_previous_get = H.do_GET
_telemetry_canvas_previous_post = H.do_POST


def _telemetry_canvas_do_GET(self):
    path = urllib.parse.urlparse(self.path).path
    routes = {
        "/api/groundstation/telemetry/catalog": "/telemetry/catalog",
        "/api/groundstation/telemetry/values": "/telemetry/values",
        "/api/groundstation/telemetry/layout": "/telemetry/layout",
    }
    if path in routes:
        return _telemetry_canvas_proxy(self, routes[path], "GET")
    return _telemetry_canvas_previous_get(self)


def _telemetry_canvas_do_POST(self):
    path = urllib.parse.urlparse(self.path).path
    if path == "/api/groundstation/telemetry/layout":
        return _telemetry_canvas_proxy(self, "/telemetry/layout", "POST")
    return _telemetry_canvas_previous_post(self)


H.do_GET = _telemetry_canvas_do_GET
H.do_POST = _telemetry_canvas_do_POST
# GROUND_STATION_TELEMETRY_CANVAS_V2_BACKEND_PROXY_END



# GROUND_STATION_STICK_WEBSOCKET_LATENCY_FIX_V1_BACKEND_START
import base64 as _gs_ws_base64
import hashlib as _gs_ws_hashlib
import struct as _gs_ws_struct

_GS_JOYSTICK_WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11'


def _gs_latency_process_control_payload(payload, client_ip=''):
    try:
        if not isinstance(payload, dict) or int(payload.get('version', 0)) not in (1, 2):
            return {'ok': False, 'error': 'Unsupported control payload'}, 400
        session = str(payload.get('session') or '').strip()
        if not session or len(session) > 96 or not re.fullmatch(r'[A-Za-z0-9._:-]+', session):
            return {'ok': False, 'error': 'Invalid session'}, 400
        seq = int(payload.get('seq', -1))
        if seq < 0 or seq > 2147483647:
            return {'ok': False, 'error': 'Invalid sequence'}, 400

        axes_in = payload.get('axes') or {}
        if not isinstance(axes_in, dict):
            return {'ok': False, 'error': 'Invalid axes'}, 400
        axes = {}
        for name in ('roll', 'pitch', 'yaw', 'throttle'):
            value = float(axes_in.get(name, 0.0))
            if not math.isfinite(value):
                return {'ok': False, 'error': 'Invalid axis ' + name}, 400
            axes[name] = max(-1.0, min(1.0, value))

        buttons = int(payload.get('buttons', 0)) & 0xFFFF
        enabled = bool(payload.get('enabled'))
        connected = bool(payload.get('connected'))
        client_ms = int(payload.get('client_ms', 0) or 0)
        if client_ms < 0 or client_ms > 9999999999999:
            return {'ok': False, 'error': 'Invalid client time'}, 400

        raw_events = payload.get('button_events') or []
        if not isinstance(raw_events, list) or len(raw_events) > 64:
            return {'ok': False, 'error': 'Invalid button events'}, 400
        parsed_events = []
        for item in raw_events:
            if not isinstance(item, dict):
                return {'ok': False, 'error': 'Invalid button event'}, 400
            event_id = int(item.get('id', -1))
            event_client_ms = int(item.get('client_ms', 0) or 0)
            if event_id < 0 or event_id > 2147483647:
                return {'ok': False, 'error': 'Invalid button event id'}, 400
            if event_client_ms < 0 or event_client_ms > 9999999999999:
                return {'ok': False, 'error': 'Invalid button event time'}, 400
            if int(payload.get('version', 0)) >= 2 or int(item.get('protocol', 0) or 0) == 2:
                press_id = int(item.get('press_id', -1))
                button = str(item.get('button', '')).strip().upper()
                event_type = str(item.get('event', '')).strip().lower()
                duration_ms = int(item.get('duration_ms', 0) or 0)
                if press_id < 0 or press_id > 2147483647:
                    return {'ok': False, 'error': 'Invalid press id'}, 400
                if button not in {'A','B','X','Y','LB','RB','LT','RT','START','BACK','L3','R3','DPAD_UP','DPAD_DOWN','DPAD_LEFT','DPAD_RIGHT'}:
                    return {'ok': False, 'error': 'Invalid button identity'}, 400
                if event_type not in {'button_down','button_tap','button_hold_start','button_hold_repeat','button_up','button_cancel'}:
                    return {'ok': False, 'error': 'Invalid button event type'}, 400
                if duration_ms < 0 or duration_ms > 600000:
                    return {'ok': False, 'error': 'Invalid button duration'}, 400
                parsed_events.append({'id': event_id, 'protocol': 2, 'press_id': press_id, 'button': button, 'event': event_type, 'duration_ms': duration_ms, 'client_ms': event_client_ms})
            else:
                event_mask = int(item.get('mask', 0)) & 0xFFFF
                parsed_events.append({'id': event_id, 'protocol': 1, 'mask': event_mask, 'client_ms': event_client_ms})

        raw_actions = payload.get('direct_actions') or []
        if not isinstance(raw_actions, list) or len(raw_actions) > 16:
            return {'ok': False, 'error': 'Invalid direct actions'}, 400
        parsed_actions = []
        for item in raw_actions:
            if not isinstance(item, dict):
                return {'ok': False, 'error': 'Invalid direct action'}, 400
            action_id = int(item.get('id', -1))
            action_name = str(item.get('action', '')).strip().upper()
            action_client_ms = int(item.get('client_ms', 0) or 0)
            if action_id < 0 or action_id > 2147483647:
                return {'ok': False, 'error': 'Invalid direct action id'}, 400
            if action_name not in {'RECORD_TOGGLE'}:
                return {'ok': False, 'error': 'Unsupported direct action'}, 400
            if action_client_ms < 0 or action_client_ms > 9999999999999:
                return {'ok': False, 'error': 'Invalid direct action time'}, 400
            parsed_actions.append({'id': action_id, 'action': action_name, 'client_ms': action_client_ms})

        if not enabled or not connected:
            buttons = 0
            parsed_events = [item for item in parsed_events if item.get('protocol') == 2 and item.get('event') in {'button_up', 'button_cancel'}]
            parsed_actions = []
            enabled = False
            connected = False

        now = time.monotonic()
        with _GS_JOYSTICK_CONTROL_LOCK:
            previous = _GS_JOYSTICK_CONTROL_SESSIONS.get(session, -1)
            if seq <= previous:
                return {'ok': False, 'error': 'Stale sequence', 'seq': seq}, 409
            _GS_JOYSTICK_CONTROL_SESSIONS[session] = seq
            if len(_GS_JOYSTICK_CONTROL_SESSIONS) > 16:
                _GS_JOYSTICK_CONTROL_SESSIONS.clear()
                _GS_JOYSTICK_BUTTON_EVENT_IDS.clear()
                _GS_JOYSTICK_DIRECT_ACTION_IDS.clear()
                _GS_JOYSTICK_CONTROL_SESSIONS[session] = seq

            last_event_id = _GS_JOYSTICK_BUTTON_EVENT_IDS.get(session, -1)
            new_events = [item for item in parsed_events if item['id'] > last_event_id]
            if new_events:
                last_event_id = max(item['id'] for item in new_events)
                _GS_JOYSTICK_BUTTON_EVENT_IDS[session] = last_event_id

            last_action_id = _GS_JOYSTICK_DIRECT_ACTION_IDS.get(session, -1)
            new_actions = [item for item in parsed_actions if item['id'] > last_action_id]
            if new_actions:
                last_action_id = max(item['id'] for item in new_actions)
                _GS_JOYSTICK_DIRECT_ACTION_IDS[session] = last_action_id

            bridge_payload = {
                'version': int(payload.get('version', 1)),
                'session': session,
                'seq': seq,
                'client_ms': client_ms,
                'server_monotonic': now,
                'enabled': enabled,
                'connected': connected,
                'axes': axes,
                'buttons': buttons,
                'button_events': new_events,
                'direct_actions': new_actions,
            }
            raw = json.dumps(bridge_payload, separators=(',', ':')).encode('utf-8')
            _GS_JOYSTICK_CONTROL_SOCKET.sendto(raw, _GS_JOYSTICK_BRIDGE_ADDRESS)
            _GS_JOYSTICK_CONTROL_STATUS.update({
                'last_rx': now,
                'last_client': str(client_ip or ''),
                'session': session,
                'seq': seq,
                'enabled': enabled,
            })

        return {
            'ok': True,
            'transport': 'websocket-capable-v2',
            'enabled': enabled,
            'seq': seq,
            'events': len(new_events),
            'actions': len(new_actions),
            'last_event_id': last_event_id,
            'last_action_id': last_action_id,
        }, 200
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        return {'ok': False, 'error': 'Invalid control payload', 'detail': str(exc)}, 400
    except Exception as exc:
        return {'ok': False, 'error': 'Control bridge unavailable', 'detail': str(exc)}, 503


def _gs_joystick_control_post(handler):
    try:
        length = int(handler.headers.get('Content-Length', '0') or 0)
        if length < 2 or length > 8192:
            return _gs_joystick_send_json(handler, {'ok': False, 'error': 'Invalid body length'}, 400)
        payload = json.loads(handler.rfile.read(length).decode('utf-8'))
        response, status = _gs_latency_process_control_payload(payload, handler.client_address[0])
        response['status'] = status
        return _gs_joystick_send_json(handler, response, status)
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        return _gs_joystick_send_json(handler, {'ok': False, 'error': 'Invalid control payload', 'detail': str(exc)}, 400)
    except Exception as exc:
        return _gs_joystick_send_json(handler, {'ok': False, 'error': 'Control bridge unavailable', 'detail': str(exc)}, 503)


def _gs_ws_read_exact(handler, length):
    data = handler.rfile.read(length)
    if data is None or len(data) != length:
        raise EOFError('websocket closed')
    return data


def _gs_ws_receive_frame(handler):
    head = _gs_ws_read_exact(handler, 2)
    first, second = head[0], head[1]
    final = bool(first & 0x80)
    opcode = first & 0x0F
    masked = bool(second & 0x80)
    length = second & 0x7F
    if length == 126:
        length = _gs_ws_struct.unpack('!H', _gs_ws_read_exact(handler, 2))[0]
    elif length == 127:
        length = _gs_ws_struct.unpack('!Q', _gs_ws_read_exact(handler, 8))[0]
    if length > 8192:
        raise ValueError('websocket frame too large')
    if not masked:
        raise ValueError('browser websocket frame is not masked')
    mask = _gs_ws_read_exact(handler, 4)
    payload = bytearray(_gs_ws_read_exact(handler, length))
    for index in range(length):
        payload[index] ^= mask[index & 3]
    if not final:
        raise ValueError('fragmented websocket frames are not supported')
    return opcode, bytes(payload)


def _gs_ws_send_frame(handler, opcode, payload=b''):
    if isinstance(payload, str):
        payload = payload.encode('utf-8')
    length = len(payload)
    first = 0x80 | (int(opcode) & 0x0F)
    if length < 126:
        header = bytes((first, length))
    elif length <= 65535:
        header = bytes((first, 126)) + _gs_ws_struct.pack('!H', length)
    else:
        header = bytes((first, 127)) + _gs_ws_struct.pack('!Q', length)
    handler.wfile.write(header + payload)
    handler.wfile.flush()


def _gs_joystick_websocket(handler):
    key = str(handler.headers.get('Sec-WebSocket-Key') or '').strip()
    upgrade = str(handler.headers.get('Upgrade') or '').lower()
    connection = str(handler.headers.get('Connection') or '').lower()
    if upgrade != 'websocket' or 'upgrade' not in connection or not key:
        return handler.send_error(400, 'WebSocket upgrade required')
    accept = _gs_ws_base64.b64encode(
        _gs_ws_hashlib.sha1((key + _GS_JOYSTICK_WS_GUID).encode('ascii')).digest()
    ).decode('ascii')
    handler.send_response(101, 'Switching Protocols')
    handler.send_header('Upgrade', 'websocket')
    handler.send_header('Connection', 'Upgrade')
    handler.send_header('Sec-WebSocket-Accept', accept)
    handler.send_header('X-SIYI-Control-Transport', 'websocket-v2')
    handler.end_headers()
    handler.wfile.flush()
    handler.close_connection = True
    last_session = ''
    last_seq = -1
    try:
        _gs_ws_send_frame(handler, 1, json.dumps({
            'ok': True,
            'ready': True,
            'transport': 'websocket-v2',
            'last_event_id': -1,
            'last_action_id': -1,
        }, separators=(',', ':')))
        while True:
            try:
                opcode, raw = _gs_ws_receive_frame(handler)
            except (TimeoutError, socket.timeout):
                continue
            if opcode == 8:
                try:
                    _gs_ws_send_frame(handler, 8, raw[:125])
                except Exception:
                    pass
                break
            if opcode == 9:
                _gs_ws_send_frame(handler, 10, raw[:125])
                continue
            if opcode != 1:
                continue
            try:
                payload = json.loads(raw.decode('utf-8'))
                if isinstance(payload, dict):
                    last_session = str(payload.get('session') or last_session).strip()
                    try:
                        last_seq = max(last_seq, int(payload.get('seq', last_seq)))
                    except Exception:
                        pass
                response, status = _gs_latency_process_control_payload(
                    payload, handler.client_address[0]
                )
            except Exception as exc:
                response, status = {'ok': False, 'error': str(exc)}, 400
            response['status'] = status
            _gs_ws_send_frame(handler, 1, json.dumps(
                response, ensure_ascii=False, separators=(',', ':')
            ))
    except (BrokenPipeError, ConnectionResetError, EOFError, OSError):
        pass
    except Exception as exc:
        print('[GS_JOYSTICK_WS_FAIL]', repr(exc), flush=True)
    finally:
        if last_session:
            try:
                _gs_latency_process_control_payload({
                    'version': 2,
                    'session': last_session,
                    'seq': max(0, last_seq + 1),
                    'client_ms': int(time.time() * 1000),
                    'enabled': False,
                    'connected': False,
                    'axes': {'roll': 0.0, 'pitch': 0.0, 'yaw': 0.0, 'throttle': 0.0},
                    'buttons': 0,
                    'button_events': [],
                    'direct_actions': [],
                }, handler.client_address[0])
            except Exception as exc:
                print('[GS_JOYSTICK_WS_CANCEL_FAIL]', repr(exc), flush=True)


_gs_latency_previous_get = H.do_GET


def _gs_latency_do_GET(self):
    path = urllib.parse.urlparse(self.path).path
    if path == '/api/groundstation/joystick/ws':
        return _gs_joystick_websocket(self)
    return _gs_latency_previous_get(self)


H.do_GET = _gs_latency_do_GET
# GROUND_STATION_STICK_WEBSOCKET_LATENCY_FIX_V1_BACKEND_END


# GROUND_STATION_SERVER_TTS_AND_GIMBAL_ZERO_V12_START
_V12_TTS_MAX_TEXT = 240
_v12_previous_get = H.do_GET


def _v12_send_json(handler, payload, status=200):
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def _v12_groundstation_tts(handler, parsed):
    params = urllib.parse.parse_qs(parsed.query, keep_blank_values=False)
    text = " ".join(str((params.get("text") or [""])[0]).split()).strip()
    if not text:
        return _v12_send_json(handler, {"ok": False, "error": "Missing speech text"}, 400)
    if len(text) > _V12_TTS_MAX_TEXT:
        text = text[:_V12_TTS_MAX_TEXT]
    try:
        completed = subprocess.run(
            ["/usr/bin/espeak-ng", "--stdout", "-v", "en-us", "-s", "165", "-a", "170", text],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=8,
            check=False,
        )
        wav = bytes(completed.stdout or b"")
        if completed.returncode != 0 or len(wav) < 44 or not wav.startswith(b"RIFF"):
            detail = (completed.stderr or b"").decode("utf-8", errors="replace").strip()
            raise RuntimeError(detail or "espeak-ng did not return valid WAV audio")
        handler.send_response(200)
        handler.send_header("Content-Type", "audio/wav")
        handler.send_header("Cache-Control", "no-store")
        handler.send_header("Content-Length", str(len(wav)))
        handler.end_headers()
        handler.wfile.write(wav)
    except subprocess.TimeoutExpired:
        _v12_send_json(handler, {"ok": False, "error": "Speech generation timed out"}, 504)
    except Exception as exc:
        _v12_send_json(handler, {"ok": False, "error": str(exc)}, 500)


def _v12_normalized_quaternion(value):
    if not isinstance(value, (list, tuple)) or len(value) != 4:
        raise ValueError("No valid raw_q in current gimbal telemetry")
    values = [float(item) for item in value]
    if not all(math.isfinite(item) for item in values):
        raise ValueError("Current gimbal quaternion contains invalid values")
    magnitude = math.sqrt(sum(item * item for item in values))
    if magnitude <= 1e-9:
        raise ValueError("Current gimbal quaternion has zero magnitude")
    return [item / magnitude for item in values]


def _v12_atomic_json(path, payload, mode=0o664):
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)
    temporary = path + ".tmp.%d.%d" % (os.getpid(), int(time.time() * 1000))
    try:
        with open(temporary, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        try:
            if os.path.exists(temporary):
                os.unlink(temporary)
        except OSError:
            pass


def _v12_set_gimbal_zero(handler):
    try:
        with open(GIMBAL_STATE_FILE, "r", encoding="utf-8") as handle:
            state = json.load(handle)
        if not isinstance(state, dict) or not state.get("ok"):
            raise RuntimeError("No current gimbal attitude telemetry is available")
        captured_at = float(state.get("ts", 0.0) or 0.0)
        age = max(0.0, time.time() - captured_at) if captured_at else 999.0
        if age > 5.0:
            raise RuntimeError("Current gimbal attitude telemetry is stale (%.1f seconds)" % age)
        quaternion = _v12_normalized_quaternion(state.get("raw_q"))
        zero = {
            "q_ref": quaternion,
            "raw_yaw": float(state.get("raw_yaw", 0.0) or 0.0),
            "raw_pitch": float(state.get("raw_pitch", 0.0) or 0.0),
            "raw_roll": float(state.get("raw_roll", 0.0) or 0.0),
            "ts": time.time(),
            "source": "webui_set_current_gimbal_position_as_zero_v12",
        }
        _v12_atomic_json(GIMBAL_ZERO_FILE, zero, 0o664)

        # Publish an immediate zeroed state. The bridge replaces this on the next
        # real GIMBAL_DEVICE_ATTITUDE_STATUS message using the same q_ref.
        immediate = dict(state)
        immediate.update({
            "ok": True,
            "yaw": 0.0,
            "pitch": 0.0,
            "roll": 0.0,
            "q_ref": quaternion,
            "zeroed_at": zero["ts"],
        })
        _v12_atomic_json(GIMBAL_STATE_FILE, immediate, 0o644)

        # Read back the persistent zero file before reporting success.
        with open(GIMBAL_ZERO_FILE, "r", encoding="utf-8") as handle:
            verified = json.load(handle)
        _v12_normalized_quaternion(verified.get("q_ref"))
        return _v12_send_json(handler, {
            "ok": True,
            "yaw": 0.0,
            "pitch": 0.0,
            "raw_yaw": zero["raw_yaw"],
            "raw_pitch": zero["raw_pitch"],
            "telemetry_age_s": round(age, 3),
        }, 200)
    except Exception as exc:
        return _v12_send_json(handler, {"ok": False, "error": str(exc)}, 500)


def _v12_do_GET(self):
    parsed = urllib.parse.urlparse(self.path)
    if parsed.path == "/api/groundstation/tts":
        return _v12_groundstation_tts(self, parsed)
    if parsed.path == "/gimbal_set_zero":
        return _v12_set_gimbal_zero(self)
    return _v12_previous_get(self)


H.do_GET = _v12_do_GET
# GROUND_STATION_SERVER_TTS_AND_GIMBAL_ZERO_V12_END


if __name__ == "__main__":
    ThreadingHTTPServer(("0.0.0.0",PORT),H).serve_forever()


# FULL_LOGS_PAGE_FIX_START
from flask import Response
import subprocess
import shlex

def _safe_cmd(cmd, timeout=4):
    try:
        return subprocess.check_output(
            cmd, shell=True, text=True,
            stderr=subprocess.STDOUT, timeout=timeout
        )
    except subprocess.CalledProcessError as e:
        return e.output or str(e)
    except Exception as e:
        return str(e)

@app.route("/api/logs")
def api_logs():
    parts = []

    sources = [
        ("SIYI Web UI", "journalctl -u siyi-webui -n 250 --no-pager"),
        ("MAVLink Router", "journalctl -u mavlink-router -n 180 --no-pager"),
        ("SIYI Services", "journalctl -u 'siyi-*' -n 220 --no-pager"),
        ("System Errors", "journalctl -p warning..alert -n 120 --no-pager"),
    ]

    for title, cmd in sources:
        parts.append(f'\n\n===== {title} =====\n')
        parts.append(_safe_cmd(cmd))

    return Response("".join(parts), mimetype="text/plain")


@app.route("/logs")
def logs_page():
    return f"""
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SIYI Logs</title>
<style>
body {{
  margin: 0;
  background: #101418;
  color: #e8eef5;
  font-family: Arial, sans-serif;
}}
.header {{
  padding: 14px 18px;
  background: #171d24;
  border-bottom: 1px solid #2b3440;
  display: flex;
  gap: 12px;
  align-items: center;
  flex-wrap: wrap;
}}
h1 {{
  margin: 0;
  font-size: 20px;
}}
button, a.btn {{
  background: #253244;
  color: #e8eef5;
  border: 1px solid #3c4b5f;
  border-radius: 8px;
  padding: 8px 11px;
  text-decoration: none;
  cursor: pointer;
}}
button:hover, a.btn:hover {{
  background: #314158;
}}
.status {{
  opacity: .8;
  font-size: 13px;
}}
.version {{
  font-size: 12px;
  opacity: 0.6;
}}
#logs {{
  height: calc(100vh - 72px);
  overflow-y: auto;
  padding: 14px;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: Menlo, Consolas, monospace;
  font-size: 12px;
  line-height: 1.35;
}}
.err {{ color: #ff9b9b; }}
.warn {{ color: #ffd28a; }}
.ok {{ color: #a8ffbf; }}
</style>
</head>
<body>
<div class="header">
  <h1>SIYI Logs</h1>
  <span class="version">v{VERSION}</span>
  <button onclick="loadLogs(false)">Refresh</button>
  <button onclick="toggleFollow()" id="followBtn">Auto-follow: ON</button>
  <button onclick="copyLogs()">Copy diagnostics</button>
  <a class="btn" href="/" >Back</a>
  <span class="status" id="status">Loading…</span>
</div>

<pre id="logs"></pre>

<script>
let follow = true;
let timer = null;

function colorize(t) {{
  return t
    .replace(/(error|failed|traceback|exception|critical)/gi, '<span class="err">$1</span>')
    .replace(/(warning|warn)/gi, '<span class="warn">$1</span>')
    .replace(/(active \\(running\\)|started|success)/gi, '<span class="ok">$1</span>');
}}

async function loadLogs(auto) {{
  const box = document.getElementById('logs');
  const status = document.getElementById('status');
  try {{
    const r = await fetch('/api/logs?ts=' + Date.now());
    const t = await r.text();
    box.innerHTML = colorize(t);
    status.innerText = 'Updated: ' + new Date().toLocaleTimeString();
    if (follow) box.scrollTop = box.scrollHeight;
  }} catch(e) {{
    status.innerText = 'Failed to load logs';
    if (!auto) alert(e);
  }}
}}

function toggleFollow() {{
  follow = !follow;
  document.getElementById('followBtn').innerText = 'Auto-follow: ' + (follow ? 'ON' : 'OFF');
}}

function copyLogs() {{
  navigator.clipboard.writeText(document.getElementById('logs').innerText);
  document.getElementById('status').innerText = 'Copied diagnostics';
}}

loadLogs(false);
timer = setInterval(() => loadLogs(true), 3000);
</script>
</body>
</html>
"""
# FULL_LOGS_PAGE_FIX_END

# FORCE_LOGS2_PAGE_START
from flask import Response
import subprocess
import shlex

def _logs2_cmd(cmd, timeout=5):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT, timeout=timeout)
    except Exception as e:
        return str(e)

@app.route("/api/logs2")
def api_logs2():
    out = []
    checks = [
        ("SIYI WEBUI", "journalctl -u siyi-webui -n 300 --no-pager"),
        ("MAVLINK ROUTER", "journalctl -u mavlink-router -n 200 --no-pager"),
        ("ALL SIYI SERVICES", "journalctl -u 'siyi-*' -n 250 --no-pager"),
        ("SYSTEM WARNINGS", "journalctl -p warning..alert -n 150 --no-pager"),
    ]
    for title, cmd in checks:
        out.append("\\n\\n==================== " + title + " ====================\\n")
        out.append(_logs2_cmd(cmd))
    return Response("".join(out), mimetype="text/plain")

@app.route("/logs2")
def logs2_page():
    return """
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SIYI Logs v{VERSION}</title>
<style>
body{margin:0;background:#101418;color:#e8eef5;font-family:Arial,sans-serif}
.header{padding:14px 18px;background:#171d24;border-bottom:1px solid #2b3440;display:flex;gap:12px;align-items:center;flex-wrap:wrap}
h1{margin:0;font-size:20px}
.badge{font-size:12px;opacity:.7}
button,a{background:#253244;color:#e8eef5;border:1px solid #3c4b5f;border-radius:8px;padding:8px 11px;text-decoration:none;cursor:pointer}
button:hover,a:hover{background:#314158}
#status{opacity:.75;font-size:13px}
#logs{height:calc(100vh - 72px);overflow-y:auto;padding:14px;white-space:pre-wrap;word-break:break-word;font-family:Menlo,Consolas,monospace;font-size:12px;line-height:1.35}
.err{color:#ff9b9b;font-weight:bold}
.warn{color:#ffd28a;font-weight:bold}
.ok{color:#a8ffbf;font-weight:bold}
</style>
</head>
<body>
<div class="header">
  <h1>SIYI Logs</h1>
  <span class="badge">v{VERSION} / forced logs2 page</span>
  <button onclick="loadLogs()">Refresh</button>
  <button onclick="toggleFollow()" id="followBtn">Auto-follow: ON</button>
  <button onclick="copyLogs()">Copy diagnostics</button>
  <a href="/">Back</a>
  <span id="status">Loading…</span>
</div>
<pre id="logs"></pre>
<script>
let follow=true;
function colorize(t){
  return t
    .replace(/(error|failed|failure|traceback|exception|critical)/gi,'<span class="err">$1</span>')
    .replace(/(warning|warn)/gi,'<span class="warn">$1</span>')
    .replace(/(active \\(running\\)|started|success|online)/gi,'<span class="ok">$1</span>');
}
async function loadLogs(){
  const box=document.getElementById('logs');
  const status=document.getElementById('status');
  try{
    const r=await fetch('/api/logs2?t='+Date.now());
    const t=await r.text();
    box.innerHTML=colorize(t);
    status.innerText='Updated: '+new Date().toLocaleTimeString();
    if(follow) box.scrollTop=box.scrollHeight;
  }catch(e){
    status.innerText='Failed to load logs';
  }
}
function toggleFollow(){
  follow=!follow;
  document.getElementById('followBtn').innerText='Auto-follow: '+(follow?'ON':'OFF');
}
function copyLogs(){
  navigator.clipboard.writeText(document.getElementById('logs').innerText);
  document.getElementById('status').innerText='Copied diagnostics';
}
loadLogs();
setInterval(loadLogs,3000);
</script>
</body>
</html>
"""
# FORCE_LOGS2_PAGE_END


# SIYI_CONTROL_CENTER_RELEASE_4_0_2

# PARAMETERS_PHONE_LANDSCAPE_V1_START
_parameters_phone_previous_page = arduplane_parameters_page

def arduplane_parameters_page():
    document = _parameters_phone_previous_page()
    if 'name="viewport"' not in document and "name='viewport'" not in document:
        document = document.replace(
            '<head>',
            '<head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,viewport-fit=cover">',
            1,
        )
    phone_css = "/* PARAMETERS_PHONE_LANDSCAPE_V1 */\nhtml.param-phone-landscape,\nhtml.param-phone-landscape body{\n  width:100%;height:100%;overflow:hidden!important;\n}\nhtml.param-phone-landscape header,\nhtml.param-phone-landscape nav{\n  display:none!important;\n}\nhtml.param-phone-landscape main,\nhtml.param-phone-landscape body.v9-embedded main{\n  margin:0!important;\n  padding:4px!important;\n  width:100%!important;\n  height:100dvh!important;\n  max-width:none!important;\n  overflow:hidden!important;\n  box-sizing:border-box!important;\n}\nhtml.param-phone-landscape main>h1{\n  display:none!important;\n}\nhtml.param-phone-landscape .paramTopCompact{\n  height:36px!important;\n  min-height:36px!important;\n  display:flex!important;\n  flex-wrap:nowrap!important;\n  align-items:center!important;\n  gap:4px!important;\n  margin:0 0 4px 0!important;\n  padding:2px 3px!important;\n  overflow-x:auto!important;\n  overflow-y:hidden!important;\n  border-radius:8px!important;\n  scrollbar-width:none!important;\n  -webkit-overflow-scrolling:touch;\n}\nhtml.param-phone-landscape .paramTopCompact::-webkit-scrollbar,\nhtml.param-phone-landscape .paramScrollArea::-webkit-scrollbar,\nhtml.param-phone-landscape .paramSide::-webkit-scrollbar{\n  display:none!important;\n}\nhtml.param-phone-landscape .paramTopTitle,\nhtml.param-phone-landscape .paramTopDivider,\nhtml.param-phone-landscape #fcExportChromeNote{\n  display:none!important;\n}\nhtml.param-phone-landscape .paramTopLoaded{\n  flex:0 0 auto!important;\n  font-size:10px!important;\n  white-space:nowrap!important;\n  padding:0 3px!important;\n}\nhtml.param-phone-landscape .paramTopRefreshForm{\n  flex:0 0 auto!important;\n  margin:0!important;\n}\nhtml.param-phone-landscape .paramTopCompact button,\nhtml.param-phone-landscape .paramTopCompact a{\n  min-height:30px!important;\n  height:30px!important;\n  margin:0!important;\n  padding:4px 8px!important;\n  border-radius:7px!important;\n  font-size:11px!important;\n  line-height:1!important;\n  white-space:nowrap!important;\n  display:inline-flex!important;\n  align-items:center!important;\n  justify-content:center!important;\n  box-sizing:border-box!important;\n}\nhtml.param-phone-landscape .paramTopStatus{\n  flex:0 0 auto!important;\n  max-width:210px!important;\n  overflow:hidden!important;\n  text-overflow:ellipsis!important;\n  white-space:nowrap!important;\n  font-size:10px!important;\n}\nhtml.param-phone-landscape .paramLayout{\n  display:block!important;\n  width:100%!important;\n  height:calc(100dvh - 44px)!important;\n  min-height:0!important;\n  overflow:hidden!important;\n}\nhtml.param-phone-landscape .paramMain{\n  display:flex!important;\n  flex-direction:column!important;\n  width:100%!important;\n  height:100%!important;\n  min-height:0!important;\n  overflow:hidden!important;\n}\nhtml.param-phone-landscape .paramToolbar{\n  flex:0 0 auto!important;\n  margin:0 0 3px 0!important;\n  padding:4px!important;\n  border-radius:8px!important;\n  z-index:100!important;\n}\nhtml.param-phone-landscape .paramSearchMainRow{\n  display:grid!important;\n  grid-template-columns:auto minmax(140px,1fr) 96px 30px!important;\n  gap:4px!important;\n  align-items:center!important;\n}\nhtml.param-phone-landscape .paramSearchMainRow input,\nhtml.param-phone-landscape .paramSearchMainRow select{\n  width:100%!important;\n  min-width:0!important;\n  max-width:none!important;\n  height:32px!important;\n  padding:4px 7px!important;\n  margin:0!important;\n  font-size:12px!important;\n  box-sizing:border-box!important;\n}\nhtml.param-phone-landscape .paramSearchMainRow>button:not(.paramPhoneGroupToggle){\n  width:30px!important;\n  min-width:30px!important;\n  height:30px!important;\n  margin:0!important;\n}\nhtml.param-phone-landscape .paramPhoneGroupToggle{\n  display:inline-flex!important;\n  align-items:center!important;\n  gap:5px!important;\n  max-width:146px!important;\n  min-width:86px!important;\n  height:32px!important;\n  margin:0!important;\n  padding:4px 7px!important;\n  background:#1d4ed8!important;\n  border:1px solid #60a5fa!important;\n  color:white!important;\n  border-radius:7px!important;\n  font-size:11px!important;\n  overflow:hidden!important;\n  white-space:nowrap!important;\n}\nhtml.param-phone-landscape .paramPhoneGroupToggle strong{\n  min-width:0!important;\n  overflow:hidden!important;\n  text-overflow:ellipsis!important;\n}\nhtml.param-phone-landscape .paramSearchSecondaryRow{\n  display:grid!important;\n  grid-template-columns:minmax(130px,1fr) 30px 30px 30px!important;\n  gap:4px!important;\n  align-items:center!important;\n  margin-top:4px!important;\n  opacity:1!important;\n}\nhtml.param-phone-landscape .paramQuickSearchSelect{\n  width:100%!important;\n  min-width:0!important;\n  max-width:none!important;\n  height:30px!important;\n  padding:3px 6px!important;\n  margin:0!important;\n  font-size:11px!important;\n}\nhtml.param-phone-landscape .paramQuickActionBtn,\nhtml.param-phone-landscape .paramIconBtn{\n  width:30px!important;\n  min-width:30px!important;\n  height:30px!important;\n  margin:0!important;\n  border-radius:7px!important;\n}\nhtml.param-phone-landscape .paramSearchFooterRow{\n  display:flex!important;\n  align-items:center!important;\n  min-height:15px!important;\n  margin-top:2px!important;\n}\nhtml.param-phone-landscape #paramResultCount{\n  margin:0!important;\n  font-size:10px!important;\n  line-height:1.2!important;\n}\nhtml.param-phone-landscape .paramWildcardHint{\n  display:none!important;\n}\nhtml.param-phone-landscape .paramScrollArea{\n  flex:1 1 auto!important;\n  min-height:0!important;\n  overflow-y:auto!important;\n  overflow-x:hidden!important;\n  padding:0 2px 48px 0!important;\n  overscroll-behavior:contain!important;\n  -webkit-overflow-scrolling:touch!important;\n  scrollbar-width:none!important;\n}\nhtml.param-phone-landscape .paramGroupCard{\n  padding:5px!important;\n  margin:0 0 5px 0!important;\n  border-radius:8px!important;\n}\nhtml.param-phone-landscape .paramGroupCard>h2{\n  position:sticky!important;\n  top:0!important;\n  z-index:3!important;\n  margin:0!important;\n  padding:3px 4px 5px!important;\n  background:#111827!important;\n  color:#93c5fd!important;\n  font-size:12px!important;\n  line-height:1.2!important;\n}\nhtml.param-phone-landscape .paramRow{\n  display:grid!important;\n  grid-template-columns:minmax(130px,.82fr) minmax(180px,1.18fr)!important;\n  grid-template-areas:'name value' 'desc desc'!important;\n  gap:3px 8px!important;\n  align-items:start!important;\n  padding:6px 4px!important;\n  cursor:default!important;\n}\nhtml.param-phone-landscape .paramName{\n  grid-area:name!important;\n  min-width:0!important;\n  color:#dbeafe!important;\n  font-size:12px!important;\n  font-weight:800!important;\n  line-height:1.25!important;\n  overflow-wrap:anywhere!important;\n}\nhtml.param-phone-landscape .paramValue{\n  grid-area:value!important;\n  min-width:0!important;\n  font-size:12px!important;\n  line-height:1.25!important;\n}\nhtml.param-phone-landscape .paramDesc{\n  grid-area:desc!important;\n  color:#cbd5e1!important;\n  font-size:10px!important;\n  line-height:1.3!important;\n  overflow-wrap:anywhere!important;\n}\nhtml.param-phone-landscape .paramDesc .small{\n  font-size:10px!important;\n}\nhtml.param-phone-landscape .paramWriteForm{\n  display:grid!important;\n  grid-template-columns:minmax(105px,1fr) auto!important;\n  gap:4px!important;\n  align-items:center!important;\n  width:100%!important;\n  margin:3px 0 0 0!important;\n}\nhtml.param-phone-landscape .paramEditInput{\n  width:100%!important;\n  min-width:0!important;\n  height:30px!important;\n  padding:3px 6px!important;\n  margin:0!important;\n  font-size:12px!important;\n  box-sizing:border-box!important;\n}\nhtml.param-phone-landscape .paramWriteBtn{\n  min-width:52px!important;\n  height:30px!important;\n  padding:4px 8px!important;\n  margin:0!important;\n  font-size:11px!important;\n}\nhtml.param-phone-landscape .paramPhoneGroupBackdrop{\n  display:none;\n  position:fixed;\n  inset:0;\n  z-index:11890;\n  background:rgba(2,6,23,.68);\n  backdrop-filter:blur(2px);\n  -webkit-backdrop-filter:blur(2px);\n}\nhtml.param-phone-landscape body.param-phone-groups-open .paramPhoneGroupBackdrop{\n  display:block!important;\n}\nhtml.param-phone-landscape .paramSide{\n  display:block!important;\n  position:fixed!important;\n  left:0!important;\n  top:0!important;\n  bottom:0!important;\n  width:min(58vw,340px)!important;\n  height:100dvh!important;\n  min-height:0!important;\n  max-height:none!important;\n  padding:8px!important;\n  margin:0!important;\n  z-index:11900!important;\n  overflow-y:auto!important;\n  overflow-x:hidden!important;\n  background:#0b1220!important;\n  border:0!important;\n  border-right:1px solid #475569!important;\n  border-radius:0!important;\n  box-shadow:14px 0 40px rgba(0,0,0,.55)!important;\n  transform:translateX(-105%)!important;\n  transition:transform .18s ease!important;\n  box-sizing:border-box!important;\n  -webkit-overflow-scrolling:touch!important;\n}\nhtml.param-phone-landscape body.param-phone-groups-open .paramSide{\n  transform:translateX(0)!important;\n}\nhtml.param-phone-landscape .paramSide h2{\n  display:flex!important;\n  align-items:center!important;\n  justify-content:space-between!important;\n  gap:8px!important;\n  position:sticky!important;\n  top:-8px!important;\n  z-index:5!important;\n  margin:0 0 8px 0!important;\n  padding:8px 4px!important;\n  background:#0b1220!important;\n  font-size:16px!important;\n}\nhtml.param-phone-landscape .paramPhoneGroupClose{\n  width:34px!important;\n  min-width:34px!important;\n  height:34px!important;\n  margin:0!important;\n  padding:0!important;\n  border:1px solid #64748b!important;\n  background:#1e293b!important;\n  color:white!important;\n  border-radius:8px!important;\n  font-size:20px!important;\n}\nhtml.param-phone-landscape .paramLevelTabs{\n  display:none!important;\n}\nhtml.param-phone-landscape #paramGroupButtons{\n  display:grid!important;\n  grid-template-columns:repeat(2,minmax(0,1fr))!important;\n  gap:5px!important;\n}\nhtml.param-phone-landscape .paramGroupBtn{\n  width:100%!important;\n  min-width:0!important;\n  min-height:38px!important;\n  margin:0!important;\n  padding:6px 4px!important;\n  font-size:11px!important;\n  line-height:1.15!important;\n  overflow-wrap:anywhere!important;\n}\nhtml.param-phone-landscape .paramGroupBtn[data-group='__ALL__']{\n  grid-column:1/-1!important;\n}\nhtml.param-phone-landscape .paramImportOverlay{\n  padding:0!important;\n  align-items:stretch!important;\n  justify-content:stretch!important;\n}\nhtml.param-phone-landscape .paramImportDialog{\n  width:100vw!important;\n  height:100dvh!important;\n  max-width:none!important;\n  max-height:none!important;\n  border:0!important;\n  border-radius:0!important;\n}\nhtml.param-phone-landscape .paramImportHeader{\n  flex:0 0 auto!important;\n  padding:7px 9px!important;\n  gap:8px!important;\n}\nhtml.param-phone-landscape .paramImportHeader h2{\n  margin:0!important;\n  font-size:16px!important;\n}\nhtml.param-phone-landscape #paramImportSubtitle{\n  font-size:10px!important;\n}\nhtml.param-phone-landscape .paramImportClose{\n  width:34px!important;\n  height:34px!important;\n  padding:0!important;\n  margin:0!important;\n}\nhtml.param-phone-landscape #paramImportPreviewPanel,\nhtml.param-phone-landscape #paramImportProgressPanel{\n  padding:6px!important;\n}\nhtml.param-phone-landscape .paramImportSummary{\n  display:flex!important;\n  gap:4px!important;\n  margin-bottom:5px!important;\n  overflow-x:auto!important;\n  flex-wrap:nowrap!important;\n}\nhtml.param-phone-landscape .paramImportSummaryItem{\n  flex:0 0 105px!important;\n  padding:5px 7px!important;\n  border-radius:7px!important;\n  font-size:10px!important;\n}\nhtml.param-phone-landscape .paramImportSummaryItem strong{\n  font-size:15px!important;\n}\nhtml.param-phone-landscape .paramImportSafety{\n  padding:6px 8px!important;\n  margin-bottom:5px!important;\n  font-size:10px!important;\n}\nhtml.param-phone-landscape .paramImportToolbar{\n  display:flex!important;\n  flex-wrap:nowrap!important;\n  gap:6px!important;\n  margin-bottom:5px!important;\n  overflow-x:auto!important;\n  font-size:10px!important;\n}\nhtml.param-phone-landscape .paramImportToolbar label{\n  flex:0 0 auto!important;\n}\nhtml.param-phone-landscape .paramImportToolbar select{\n  min-width:128px!important;\n  height:29px!important;\n  padding:3px 6px!important;\n  font-size:10px!important;\n}\nhtml.param-phone-landscape .paramImportTableWrap{\n  overflow-y:auto!important;\n  overflow-x:hidden!important;\n  border-radius:7px!important;\n}\nhtml.param-phone-landscape .paramImportTable,\nhtml.param-phone-landscape .paramImportTable tbody{\n  display:block!important;\n  width:100%!important;\n  min-width:0!important;\n}\nhtml.param-phone-landscape .paramImportTable thead{\n  display:none!important;\n}\nhtml.param-phone-landscape .paramImportTable tr{\n  display:grid!important;\n  grid-template-columns:52px minmax(120px,1fr) minmax(94px,.75fr)!important;\n  grid-template-areas:'apply parameter status' 'current imported imported' 'warning warning warning'!important;\n  gap:4px 6px!important;\n  padding:6px!important;\n  border-bottom:1px solid #334155!important;\n}\nhtml.param-phone-landscape .paramImportTable td{\n  display:block!important;\n  min-width:0!important;\n  padding:0!important;\n  border:0!important;\n  font-size:10px!important;\n  overflow-wrap:anywhere!important;\n}\nhtml.param-phone-landscape .paramImportTable td::before{\n  display:block!important;\n  margin-bottom:2px!important;\n  color:#94a3b8!important;\n  font-size:8px!important;\n  font-weight:800!important;\n  text-transform:uppercase!important;\n  letter-spacing:.06em!important;\n}\nhtml.param-phone-landscape .paramImportTable td:nth-child(1){grid-area:apply!important}\nhtml.param-phone-landscape .paramImportTable td:nth-child(2){grid-area:parameter!important}\nhtml.param-phone-landscape .paramImportTable td:nth-child(3){grid-area:current!important}\nhtml.param-phone-landscape .paramImportTable td:nth-child(4){grid-area:imported!important}\nhtml.param-phone-landscape .paramImportTable td:nth-child(5){grid-area:status!important}\nhtml.param-phone-landscape .paramImportTable td:nth-child(6){grid-area:warning!important}\nhtml.param-phone-landscape .paramImportTable td:nth-child(1)::before{content:'Apply'}\nhtml.param-phone-landscape .paramImportTable td:nth-child(2)::before{content:'Parameter'}\nhtml.param-phone-landscape .paramImportTable td:nth-child(3)::before{content:'Current'}\nhtml.param-phone-landscape .paramImportTable td:nth-child(4)::before{content:'Imported'}\nhtml.param-phone-landscape .paramImportTable td:nth-child(5)::before{content:'Status'}\nhtml.param-phone-landscape .paramImportTable td:nth-child(6)::before{content:'Warning'}\nhtml.param-phone-landscape .paramImportWarning{\n  max-width:none!important;\n  font-size:9px!important;\n}\nhtml.param-phone-landscape .paramImportFooter{\n  flex:0 0 auto!important;\n  flex-wrap:nowrap!important;\n  justify-content:flex-start!important;\n  gap:4px!important;\n  padding:5px 7px!important;\n  overflow-x:auto!important;\n}\nhtml.param-phone-landscape .paramImportFooter button,\nhtml.param-phone-landscape .paramImportFooter a{\n  flex:0 0 auto!important;\n  min-height:30px!important;\n  margin:0!important;\n  padding:5px 8px!important;\n  font-size:10px!important;\n}\nhtml.param-phone-landscape .paramImportRunStatus{\n  gap:8px!important;\n  margin-bottom:7px!important;\n}\nhtml.param-phone-landscape .paramImportSpinner{\n  width:18px!important;\n  height:18px!important;\n  border-width:2px!important;\n}\nhtml.param-phone-landscape .paramImportProgressTrack{\n  height:12px!important;\n}\nhtml.param-phone-landscape .paramImportProgressFacts{\n  margin:4px 0 5px!important;\n  font-size:10px!important;\n}\nhtml.param-phone-landscape .paramImportCurrent{\n  min-height:16px!important;\n  margin-bottom:4px!important;\n  font-size:10px!important;\n}\nhtml.param-phone-landscape .paramImportEventLog{\n  height:calc(100% - 95px)!important;\n  min-height:80px!important;\n  padding:7px!important;\n  font-size:10px!important;\n}\nhtml.param-phone-landscape .paramImportMetaPopup{\n  width:calc(100vw - 8px)!important;\n  max-width:none!important;\n  max-height:calc(100dvh - 8px)!important;\n  border-radius:8px!important;\n}\nhtml.param-phone-landscape .paramImportMetaHeader{\n  padding:8px!important;\n}\nhtml.param-phone-landscape .paramImportMetaBody{\n  padding:8px!important;\n  font-size:10px!important;\n}"
    phone_js = '/* PARAMETERS_PHONE_LANDSCAPE_V1 */\n(function(){\n  \'use strict\';\n  const ROOT_CLASS=\'param-phone-landscape\';\n  const OPEN_CLASS=\'param-phone-groups-open\';\n  let controlsPrepared=false;\n\n  function isMobileDevice(){\n    const ua=String(navigator.userAgent||\'\');\n    const mobileUa=/Android|iPhone|iPod|Mobile|Windows Phone/i.test(ua);\n    const iPadLike=navigator.platform===\'MacIntel\' && Number(navigator.maxTouchPoints||0)>1;\n    return mobileUa || iPadLike;\n  }\n\n  function shouldUsePhoneLayout(){\n    const landscape=window.matchMedia && window.matchMedia(\'(orientation: landscape)\').matches;\n    const touch=Number(navigator.maxTouchPoints||0)>0 || (\'ontouchstart\' in window);\n    const viewport=window.visualViewport;\n    const height=Math.round(viewport&&viewport.height ? viewport.height : window.innerHeight||0);\n    const screenShort=Math.min(Number(screen.width||0),Number(screen.height||0)) || height;\n    return Boolean(isMobileDevice() && touch && landscape && height<=680 && screenShort<=700);\n  }\n\n  function setCompactText(element, compactText, active){\n    if(!element){return;}\n    if(!element.dataset.paramDesktopText){\n      element.dataset.paramDesktopText=String(element.textContent||\'\').trim();\n    }\n    element.textContent=active ? compactText : element.dataset.paramDesktopText;\n  }\n\n  function currentGroupName(){\n    const active=document.querySelector(\'.paramGroupBtn.active\');\n    if(!active){return \'All\';}\n    const group=String(active.dataset.group||\'\');\n    if(group===\'__ALL__\'){return \'All\';}\n    const clone=active.cloneNode(true);\n    clone.querySelectorAll(\'.small\').forEach(node=>node.remove());\n    return String(clone.textContent||group).trim() || group;\n  }\n\n  function updateGroupButtonLabel(){\n    const label=document.getElementById(\'paramPhoneGroupCurrent\');\n    if(label){label.textContent=currentGroupName();}\n  }\n\n  function closeGroups(){\n    document.body&&document.body.classList.remove(OPEN_CLASS);\n    const toggle=document.getElementById(\'paramPhoneGroupToggle\');\n    if(toggle){toggle.setAttribute(\'aria-expanded\',\'false\');}\n  }\n\n  function openGroups(){\n    if(!document.body||!document.documentElement.classList.contains(ROOT_CLASS)){return;}\n    document.body.classList.add(OPEN_CLASS);\n    const toggle=document.getElementById(\'paramPhoneGroupToggle\');\n    if(toggle){toggle.setAttribute(\'aria-expanded\',\'true\');}\n  }\n\n  function toggleGroups(){\n    if(document.body&&document.body.classList.contains(OPEN_CLASS)){closeGroups();}\n    else{openGroups();}\n  }\n\n  function prepareControls(){\n    if(controlsPrepared){return;}\n    const searchRow=document.querySelector(\'.paramSearchMainRow\');\n    const side=document.querySelector(\'.paramSide\');\n    if(!searchRow||!side){return;}\n\n    const toggle=document.createElement(\'button\');\n    toggle.type=\'button\';\n    toggle.id=\'paramPhoneGroupToggle\';\n    toggle.className=\'paramPhoneGroupToggle\';\n    toggle.setAttribute(\'aria-expanded\',\'false\');\n    toggle.setAttribute(\'aria-controls\',\'paramGroupButtons\');\n    toggle.innerHTML=\'<span>Groups</span><strong id="paramPhoneGroupCurrent">All</strong>\';\n    toggle.addEventListener(\'click\',toggleGroups);\n    searchRow.insertBefore(toggle,searchRow.firstChild);\n\n    const backdrop=document.createElement(\'div\');\n    backdrop.className=\'paramPhoneGroupBackdrop\';\n    backdrop.setAttribute(\'aria-hidden\',\'true\');\n    backdrop.addEventListener(\'click\',closeGroups);\n    document.body.appendChild(backdrop);\n\n    const heading=side.querySelector(\'h2\');\n    if(heading){\n      const close=document.createElement(\'button\');\n      close.type=\'button\';\n      close.className=\'paramPhoneGroupClose\';\n      close.setAttribute(\'aria-label\',\'Close parameter groups\');\n      close.textContent=\'×\';\n      close.addEventListener(\'click\',closeGroups);\n      heading.appendChild(close);\n    }\n\n    side.querySelectorAll(\'.paramGroupBtn\').forEach(function(button){\n      button.addEventListener(\'click\',function(){\n        window.setTimeout(function(){updateGroupButtonLabel();closeGroups();},0);\n      });\n    });\n\n    document.addEventListener(\'keydown\',function(event){\n      if(event.key===\'Escape\'){closeGroups();}\n    });\n\n    controlsPrepared=true;\n    updateGroupButtonLabel();\n  }\n\n  function applyCompactLabels(active){\n    setCompactText(document.querySelector(\'form.paramTopRefreshForm button\'),\'Refresh FC\',active);\n    setCompactText(document.getElementById(\'fcParamExportBtn\'),\'Export\',active);\n    const importButton=document.querySelector("button[onclick*=\'paramImportFileInput\']");\n    setCompactText(importButton,\'Import\',active);\n  }\n\n  function applyLayout(){\n    const active=shouldUsePhoneLayout();\n    document.documentElement.classList.toggle(ROOT_CLASS,active);\n    if(document.body){document.body.classList.toggle(ROOT_CLASS,active);}\n    prepareControls();\n    applyCompactLabels(active);\n    if(!active){closeGroups();}\n    updateGroupButtonLabel();\n  }\n\n  function start(){\n    prepareControls();\n    applyLayout();\n    window.addEventListener(\'resize\',applyLayout,{passive:true});\n    window.addEventListener(\'orientationchange\',function(){window.setTimeout(applyLayout,80);},{passive:true});\n    if(window.visualViewport){window.visualViewport.addEventListener(\'resize\',applyLayout,{passive:true});}\n  }\n\n  if(document.readyState===\'loading\'){\n    document.addEventListener(\'DOMContentLoaded\',start,{once:true});\n  }else{\n    start();\n  }\n})();'
    document = document.replace(
        '</head>',
        '<style id="parametersPhoneLandscapeStyles">' + phone_css + '</style></head>',
        1,
    )
    document = document.replace(
        '</body>',
        '<script id="parametersPhoneLandscapeScript">' + phone_js + '</script></body>',
        1,
    )
    return document
# PARAMETERS_PHONE_LANDSCAPE_V1_END

