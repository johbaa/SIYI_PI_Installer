#!/usr/bin/env bash
set -Eeuo pipefail
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
export LC_CTYPE=C.UTF-8

VERSION="4.2.0"
BUILD_ID="SIYI_4_2_0_BASELINE_V6"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload/rootfs"
MANIFEST="$SCRIPT_DIR/payload-manifest.json"
SOURCE_LOCK="$SCRIPT_DIR/source-lock.json"
REPAIR=0
NO_REBOOT=0
REQUIRE_FC=0
for arg in "$@"; do
  case "$arg" in
    --repair) REPAIR=1 ;;
    --no-reboot) NO_REBOOT=1 ;;
    --require-fc) REQUIRE_FC=1 ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done

CALLING_USER="${SUDO_USER:-${USER:-pi}}"
[ "$CALLING_USER" = root ] && CALLING_USER=pi
CALLING_HOME="$(getent passwd "$CALLING_USER" 2>/dev/null | cut -d: -f6 || true)"
[ -n "$CALLING_HOME" ] || CALLING_HOME=/home/pi
INSTALL_LOG="$CALLING_HOME/siyi_install_${VERSION}_$(date +%Y%m%d_%H%M%S).log"
mkdir -p "$CALLING_HOME"
touch "$INSTALL_LOG"

SIYI_BLUE=$'\033[0;94m'
SIYI_GREEN=$'\033[1;32m'
SIYI_RESET=$'\033[0m'
SIYI_PROGRESS_HEADING_PRINTED=0
exec 3>&1 4>&2
exec >>"$INSTALL_LOG" 2>&1
CURRENT_STEP_NAME="starting"
INSTALL_START_TS="$SECONDS"
PROGRESS_ANIM_PID=""
PROGRESS_LAST=0
SUCCESS=0
SNAPSHOT_READY=0
VENV_SWAPPED=0
CAM_PROFILE_CREATED=0
ROLLBACK_RESULT="not required"
TX="$(date +%Y%m%d_%H%M%S)_$RANDOM"
TX_DIR="/var/lib/siyi-installer/transactions/$TX"
TX_LOG="/var/log/siyi-installer/install_${VERSION}_${TX}.log"

progress_next_target() {
  case "$1" in
    5) echo 9 ;; 10) echo 24 ;; 25) echo 34 ;; 35) echo 44 ;; 45) echo 49 ;;
    50) echo 57 ;; 58) echo 64 ;; 65) echo 69 ;; 70) echo 75 ;; 76) echo 81 ;;
    82) echo 87 ;; 88) echo 99 ;; *) echo "$1" ;;
  esac
}

draw_progress() {
  local pct="$1" msg="$2" elapsed="${3:-0}"
  if [ "${SIYI_WEBUI_UPGRADE:-0}" = "1" ]; then
    printf "%3d%%  %s\n" "$pct" "$msg" >&3
    return
  fi
  local width=20 filled=$((pct * 20 / 100)) empty bar="" i
  empty=$((width-filled))
  local spin='|/-\\' idx=$((SECONDS % 4)) sp timer=""
  sp="${spin:$idx:1}"
  if [ "$elapsed" -gt 0 ]; then timer=$(printf " (%02dm %02ds)" $((elapsed/60)) $((elapsed%60))); fi
  for ((i=0; i<filled; i++)); do bar+="█"; done
  for ((i=0; i<empty; i++)); do bar+="░"; done
  if [ "${SIYI_PROGRESS_HEADING_PRINTED:-0}" -eq 0 ]; then
    printf "%sInstalling, SIYI PI Control System%s\n\n" "$SIYI_BLUE" "$SIYI_RESET" >&3
    SIYI_PROGRESS_HEADING_PRINTED=1
  fi
  printf "\r\033[2K%s%s [%s] %3d%%  %s%s%s" "$SIYI_GREEN" "$sp" "$bar" "$pct" "$msg" "$timer" "$SIYI_RESET" >&3
}

stop_progress_anim() {
  if [ -n "${PROGRESS_ANIM_PID:-}" ]; then
    kill "$PROGRESS_ANIM_PID" >/dev/null 2>&1 || true
    wait "$PROGRESS_ANIM_PID" >/dev/null 2>&1 || true
    PROGRESS_ANIM_PID=""
  fi
}

progress() {
  local pct="$1" msg="$2" target cur
  stop_progress_anim
  CURRENT_STEP_NAME="$msg"
  PROGRESS_LAST="$pct"
  draw_progress "$pct" "$msg" "$((SECONDS-INSTALL_START_TS))"
  target="$(progress_next_target "$pct")"
  if [ "$pct" -ge 100 ]; then
    stop_progress_anim
    draw_progress 100 "$msg" "$((SECONDS-INSTALL_START_TS))"
    printf "\n" >&3
    return
  fi
  (
    cur="$pct"
    while true; do
      sleep 1
      elapsed=$((SECONDS-INSTALL_START_TS))
      if [ "$cur" -lt "$target" ]; then cur=$((cur+1)); fi
      draw_progress "$cur" "$msg" "$elapsed"
    done
  ) &
  PROGRESS_ANIM_PID="$!"
}

run_logged() {
  local description="$1"; shift
  echo "=== $description ==="
  "$@"
}

die() { echo "INSTALL FAILED: $*"; return 1; }

rollback_transaction() {
  local original_rc="$1" rollback_warning=0
  set +e
  echo "=== ROLLBACK START: transaction $TX, original exit $original_rc ==="
  if [ "$VENV_SWAPPED" -eq 1 ]; then
    rm -rf /home/pi/siyi-bridge-venv || rollback_warning=1
    if [ -d "$TX_DIR/siyi-bridge-venv.previous" ]; then
      mv "$TX_DIR/siyi-bridge-venv.previous" /home/pi/siyi-bridge-venv || rollback_warning=1
    fi
  fi
  if [ "$SNAPSHOT_READY" -eq 1 ]; then
    sudo python3 - "$MANIFEST" "$TX_DIR/backup-index.json" "$TX_DIR/backup-root" <<'PYROLLBACK' || rollback_warning=1
import json,os,shutil,sys
manifest,index_path,backup_root=sys.argv[1:]
items=json.load(open(manifest,encoding='utf-8'))['files']
index=json.load(open(index_path,encoding='utf-8')); existing=set(index.get('existing',[]))
for p in ['/usr/local/bin/mediamtx','/usr/bin/mavlink-routerd','/usr/bin/mavlink-router','/usr/local/bin/mavlink-routerd','/usr/local/bin/mavlink-router']:
    if p in existing: continue
    try:
        if os.path.isdir(p) and not os.path.islink(p): shutil.rmtree(p)
        elif os.path.lexists(p): os.unlink(p)
    except Exception: pass
for item in reversed(items):
    p=item['path']
    if item['type']=='directory': continue
    try:
        if os.path.isdir(p) and not os.path.islink(p): shutil.rmtree(p)
        elif os.path.lexists(p): os.unlink(p)
    except Exception: pass
for p in index.get('existing',[]):
    src=os.path.join(backup_root,p.lstrip('/'))
    try:
        os.makedirs(os.path.dirname(p),exist_ok=True)
        if os.path.islink(src): os.symlink(os.readlink(src),p)
        elif os.path.isdir(src): shutil.copytree(src,p,symlinks=True,dirs_exist_ok=True)
        elif os.path.isfile(src): shutil.copy2(src,p,follow_symlinks=False)
    except Exception: pass
PYROLLBACK
    if [ -d "$TX_DIR/boot-backup" ]; then sudo cp -a "$TX_DIR/boot-backup/." / || rollback_warning=1; fi
  fi
  if [ "$CAM_PROFILE_CREATED" -eq 1 ]; then sudo nmcli connection delete cam-eth0 >/dev/null 2>&1 || rollback_warning=1; fi
  sudo systemctl daemon-reload >/dev/null 2>&1 || rollback_warning=1
  if [ -f "$TX_DIR/active-units.txt" ]; then
    while read -r unit; do [ -z "$unit" ] || sudo systemctl restart "$unit" >/dev/null 2>&1 || true; done <"$TX_DIR/active-units.txt"
  fi
  if [ "$rollback_warning" -eq 0 ]; then ROLLBACK_RESULT="Complete"; else ROLLBACK_RESULT="Completed with warnings; inspect the log"; fi
  echo "=== ROLLBACK END: $ROLLBACK_RESULT ==="
  set -e
}

on_failure() {
  local rc="$1"
  trap - ERR INT TERM
  stop_progress_anim || true
  rollback_transaction "$rc"
  printf "\n\n" >&3
  echo "========================================" >&3
  echo "❌ SIYI INSTALL FAILED" >&3
  echo "========================================" >&3
  echo "Step: ${CURRENT_STEP_NAME:-starting}" >&3
  echo "Exit code: $rc" >&3
  echo "Rollback: $ROLLBACK_RESULT" >&3
  echo "Transaction: $TX_DIR" >&3
  echo "Full log:" >&3
  echo "$INSTALL_LOG" >&3
  echo >&3
  exit "$rc"
}
trap 'on_failure $?' ERR
trap 'on_failure 130' INT
trap 'on_failure 143' TERM

# Canonical 3.1.12 first-install introduction.
echo "=== SIYI Public Installer $VERSION ==="
echo "Full log: $INSTALL_LOG" >&3
echo >&3
echo "Sudo check: enter the Pi password if asked." >&3
command -v sudo >/dev/null 2>&1 || die "sudo is required."
sudo -v
sudo install -d -o pi -g pi -m 0750 "$TX_DIR" "$TX_DIR/backup-root" "$TX_DIR/boot-backup"
sudo install -d -o root -g root -m 0755 /var/log/siyi-installer /var/lib/siyi-installer/transactions
sudo ln -sfn "$INSTALL_LOG" "$TX_LOG"

progress 5 "Preparing installer"
[ "$(uname -m)" = aarch64 ] || die "4.2.0 supports Raspberry Pi OS 64-bit (aarch64) only."
. /etc/os-release
case "${ID:-}" in debian|raspbian) ;; *) die "Unsupported OS ${ID:-unknown}" ;; esac
[ "${VERSION_ID:-}" = 13 ] || die "4.2.0 baseline requires Raspberry Pi OS / Debian 13."
[ -r /proc/device-tree/model ] || die "Raspberry Pi hardware was not detected."
model="$(tr -d '\0' </proc/device-tree/model)"
case "$model" in *"Raspberry Pi 3 Model B Plus"*|*"Raspberry Pi 4 Model B"*|*"Raspberry Pi 5"*) ;; *) die "Unsupported Raspberry Pi model: $model" ;; esac
free_kb="$(df -Pk / | awk 'NR==2{print $4}')"
[ "$free_kb" -ge 2097152 ] || die "At least 2 GiB free space is required."
release_marker=/etc/siyi/release_version
current=""
[ ! -r "$release_marker" ] || current="$(tr -d '[:space:]' <"$release_marker")"
if [ -e "$release_marker" ]; then
  [ -n "$current" ] || die "Invalid empty release marker. Refusing an uncontrolled overwrite."
  current_build="$(tr -d '[:space:]' </etc/siyi/release_build 2>/dev/null || true)"
  current_status="$(tr -d '[:space:]' </etc/siyi/release_status 2>/dev/null || true)"
  if [ "$current" = "$VERSION" ] && [ "$REPAIR" -eq 1 ]; then :
  elif [ "$current" = "$VERSION" ] && { [ "$current_status" = accepted ] || [ "$current_status" = core_accepted_hardware_pending ]; }; then
    die "$VERSION is already installed. Use --repair for a verified reinstall."
  elif [ "$current" = "$VERSION" ]; then
    echo "=== Recovering interrupted 4.2.0 installation from ${current_build:-unknown-build}/${current_status:-unknown-status} ==="
  else
    die "Upgrade from $current is unsupported. 4.2.0 is the fresh-install ground-zero baseline."
  fi
elif [ -e /home/pi/siyi-webui/server.py ] || sudo systemctl list-unit-files 'siyi-*.service' --no-legend 2>/dev/null | grep -q .; then
  # Permit only a clearly identifiable interrupted 4.2.0 attempt; reject legacy/unversioned installs.
  interrupted=0
  if [ -r /usr/local/share/siyi/releases/4.2.0/release-metadata.json ]; then
    interrupted="$(python3 - /usr/local/share/siyi/releases/4.2.0/release-metadata.json <<'PYINT'
import json,sys
try:
    print(1 if str(json.load(open(sys.argv[1]))['version']).strip()=='4.2.0' else 0)
except Exception:
    print(0)
PYINT
)"
  elif sudo find /var/lib/siyi-installer/transactions -mindepth 1 -maxdepth 1 -type d -print -quit 2>/dev/null | grep -q .; then
    interrupted=1
  fi
  [ "$interrupted" = 1 ] || die "An unversioned existing SIYI installation was detected. 4.2.0 fresh install requires a freshly flashed OS."
  echo "=== Recovering interrupted 4.2.0 installation ==="
fi

python3 - "$PAYLOAD" "$MANIFEST" <<'PYVERIFY'
import hashlib,json,os,sys
root,manifest=sys.argv[1:]
data=json.load(open(manifest,encoding='utf-8'))
for item in data['files']:
    p=os.path.join(root,item['path'].lstrip('/'))
    if item['type']=='directory':
        if not os.path.isdir(p): raise SystemExit('missing directory '+item['path'])
    elif item['type']=='symlink':
        if not os.path.islink(p): raise SystemExit('missing symlink '+item['path'])
        if hashlib.sha256(os.readlink(p).encode()).hexdigest()!=item['sha256']: raise SystemExit('symlink checksum mismatch '+item['path'])
    else:
        if not os.path.isfile(p): raise SystemExit('missing file '+item['path'])
        if hashlib.sha256(open(p,'rb').read()).hexdigest()!=item['sha256']: raise SystemExit('checksum mismatch '+item['path'])
PYVERIFY

sudo systemctl list-units --state=active --type=service --no-legend 2>/dev/null | awk '{print $1}' >"$TX_DIR/active-units.txt" || true
sudo python3 - "$MANIFEST" "$TX_DIR/backup-index.json" "$TX_DIR/backup-root" <<'PYBACKUP'
import json,os,shutil,sys
manifest,index_path,backup_root=sys.argv[1:]
paths=[x['path'] for x in json.load(open(manifest,encoding='utf-8'))['files'] if x['type']!='directory']
paths += ['/usr/local/bin/mediamtx','/usr/bin/mavlink-routerd','/usr/bin/mavlink-router','/usr/local/bin/mavlink-routerd','/usr/local/bin/mavlink-router']
existing=[]
for p in dict.fromkeys(paths):
    if not os.path.lexists(p): continue
    existing.append(p); dst=os.path.join(backup_root,p.lstrip('/')); os.makedirs(os.path.dirname(dst),exist_ok=True)
    if os.path.islink(p): os.symlink(os.readlink(p),dst)
    elif os.path.isdir(p): shutil.copytree(p,dst,symlinks=True)
    else: shutil.copy2(p,dst,follow_symlinks=False)
json.dump({'existing':existing},open(index_path,'w'),indent=2)
PYBACKUP
for p in /boot/firmware/cmdline.txt /boot/firmware/config.txt /boot/cmdline.txt /boot/config.txt; do
  [ ! -e "$p" ] || sudo install -D -m 0644 "$p" "$TX_DIR/boot-backup$p"
done
SNAPSHOT_READY=1

progress 10 "Installing base dependencies"
export DEBIAN_FRONTEND=noninteractive APT_LISTCHANGES_FRONTEND=none
sudo install -D -o root -g root -m 0644 "$PAYLOAD/usr/share/keyrings/zerotier-debian-package-key.gpg" /usr/share/keyrings/zerotier-debian-package-key.gpg
sudo install -D -o root -g root -m 0644 "$PAYLOAD/etc/apt/sources.list.d/zerotier.list" /etc/apt/sources.list.d/zerotier.list
run_logged "Updating package indexes" sudo -E apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 update
mapfile -t packages < <(grep -Ev '^($|#)' "$SCRIPT_DIR/apt-packages.txt")
run_logged "Installing required operating-system packages" sudo -E apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 install -y --no-install-recommends "${packages[@]}"
run_logged "Verifying MAVLink Router systemd build metadata" pkg-config --exists systemd

progress 25 "Installing ZeroTier"
run_logged "Installing ZeroTier" sudo -E apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 install -y --no-install-recommends zerotier-one
sudo systemctl enable zerotier-one
sudo systemctl start zerotier-one

progress 35 "Installing SIYI configuration"
getent group pi >/dev/null 2>&1 || sudo groupadd pi
if ! id pi >/dev/null 2>&1; then sudo useradd -m -g pi -s /bin/bash pi; fi
for group in dialout input video render netdev; do getent group "$group" >/dev/null && sudo usermod -a -G "$group" pi; done
sudo python3 - "$PAYLOAD" "$MANIFEST" <<'PYDEPLOY'
import json,os,shutil,sys,tempfile
root,manifest=sys.argv[1:]
data=json.load(open(manifest,encoding='utf-8'))
for item in sorted(data['files'],key=lambda x:(x['type']!='directory',x['path'].count('/'),x['path'])):
    src=os.path.join(root,item['path'].lstrip('/')); dst=item['path']
    if dst in {'/etc/siyi/release_version','/etc/siyi/release_build','/etc/siyi/release_status'}: continue
    if item.get('persistent') and os.path.lexists(dst): continue
    if item['type']=='directory': os.makedirs(dst,exist_ok=True)
    elif item['type']=='symlink':
        os.makedirs(os.path.dirname(dst),exist_ok=True)
        if os.path.lexists(dst):
            if os.path.isdir(dst) and not os.path.islink(dst): shutil.rmtree(dst)
            else: os.unlink(dst)
        os.symlink(os.readlink(src),dst)
    else:
        os.makedirs(os.path.dirname(dst),exist_ok=True)
        fd,tmp=tempfile.mkstemp(prefix='.siyi420.',dir=os.path.dirname(dst)); os.close(fd)
        shutil.copy2(src,tmp,follow_symlinks=False); os.replace(tmp,dst)
    try: os.chmod(dst,int(item['mode'],8),follow_symlinks=False)
    except (NotImplementedError,FileNotFoundError): pass
    try: shutil.chown(dst,user=item['owner'],group=item['group'])
    except (LookupError,PermissionError,FileNotFoundError): pass
for p in data.get('obsolete_paths',[]):
    if os.path.isdir(p) and not os.path.islink(p): shutil.rmtree(p,ignore_errors=True)
    elif os.path.lexists(p): os.unlink(p)
PYDEPLOY
sudo install -d -o pi -g pi -m 0775 /home/pi/.config/siyi /var/lib/siyi-user-config/groundstation
sudo install -d -o root -g pi -m 0775 /var/lib/siyi-upgrade /var/backups/siyi-upgrade /var/lib/siyi-installer
for dst in /home/pi/.config/siyi/telemetry_canvas.json /var/lib/siyi-user-config/groundstation/telemetry_canvas.json; do
  [ -e "$dst" ] || sudo install -o pi -g pi -m 0664 /usr/local/share/siyi/defaults/telemetry_canvas.json "$dst"
done
[ -e /var/lib/siyi-upgrade/preserve_preferences.json ] || sudo install -o root -g pi -m 0664 /usr/local/share/siyi/defaults/upgrade_preserve_preferences.json /var/lib/siyi-upgrade/preserve_preferences.json
sudo rm -f /etc/siyi/zerotier_api_token

progress 45 "Installing Web UI"
test -f /home/pi/siyi-webui/server.py
test -f /home/pi/siyi-webui/wifi_passwords.json
sudo chown -R pi:pi /home/pi/siyi-webui /home/pi/siyi-joystick

progress 50 "Configuring camera Ethernet"
if ip link show eth0 >/dev/null 2>&1; then
  existing_cam="$(nmcli -t -f NAME connection show 2>/dev/null | awk '$0=="cam-eth0"{print;exit}')"
  if [ -z "$existing_cam" ]; then sudo nmcli connection add type ethernet ifname eth0 con-name cam-eth0 >/dev/null; CAM_PROFILE_CREATED=1; fi
  sudo nmcli connection modify cam-eth0 connection.interface-name eth0 connection.autoconnect yes connection.autoconnect-priority 100 ipv4.method manual ipv4.addresses 192.168.144.20/24 ipv4.gateway "" ipv4.dns "" ipv4.never-default yes ipv6.method disabled
fi

progress 58 "Preparing Python environment"
rm -rf /home/pi/siyi-bridge-venv.new
run_logged "Creating Python virtual environment" python3 -m venv /home/pi/siyi-bridge-venv.new
run_logged "Updating Python package installer" /home/pi/siyi-bridge-venv.new/bin/pip install --disable-pip-version-check --no-cache-dir --upgrade pip
run_logged "Installing pinned Python dependencies" /home/pi/siyi-bridge-venv.new/bin/pip install --disable-pip-version-check --no-cache-dir --requirement "$SCRIPT_DIR/requirements.txt"
run_logged "Checking Python dependency consistency" /home/pi/siyi-bridge-venv.new/bin/pip check
/home/pi/siyi-bridge-venv.new/bin/python - <<'PYIMPORT'
from pymavlink import mavutil
import fastcrc,future,lxml,numpy,serial,requests,psutil,aiohttp,websockets,yaml
PYIMPORT
if [ -d /home/pi/siyi-bridge-venv ]; then mv /home/pi/siyi-bridge-venv "$TX_DIR/siyi-bridge-venv.previous"; fi
mv /home/pi/siyi-bridge-venv.new /home/pi/siyi-bridge-venv
VENV_SWAPPED=1
sudo chown -R pi:pi /home/pi/siyi-bridge-venv

progress 65 "Installing system services"
boot_dir=""
[ ! -d /boot/firmware ] || boot_dir=/boot/firmware
[ -n "$boot_dir" ] || [ ! -d /boot ] || boot_dir=/boot
[ -n "$boot_dir" ] || die "Boot configuration directory not found."
cmdline="$boot_dir/cmdline.txt"; config="$boot_dir/config.txt"
[ -f "$cmdline" ] || die "$cmdline not found."
sudo python3 - "$cmdline" <<'PYCMD'
import pathlib,re,sys
p=pathlib.Path(sys.argv[1]); tokens=p.read_text().strip().split()
tokens=[t for t in tokens if not re.fullmatch(r'console=(serial0|ttyS0|ttyAMA0),.*',t)]
p.write_text(' '.join(tokens)+'\n')
PYCMD
sudo touch "$config"
sudo python3 - "$config" <<'PYCONFIG'
import pathlib,re,sys
p=pathlib.Path(sys.argv[1]); s=p.read_text()
if re.search(r'(?m)^enable_uart=',s): s=re.sub(r'(?m)^enable_uart=.*$','enable_uart=1',s)
else: s=s.rstrip()+'\n\nenable_uart=1\n'
p.write_text(s)
PYCONFIG
sudo systemctl disable --now serial-getty@serial0.service serial-getty@ttyS0.service serial-getty@ttyAMA0.service 2>/dev/null || true
sudo systemctl mask serial-getty@serial0.service serial-getty@ttyS0.service serial-getty@ttyAMA0.service 2>/dev/null || true
/home/pi/siyi-bridge-venv/bin/python -m py_compile /home/pi/siyi-webui/server.py /home/pi/siyi_mav_button_bridge.py /home/pi/siyi-battery-cache.py /home/pi/siyi-joystick/joystickd.py /usr/local/lib/siyi/groundstation/groundstation_daemon.py /usr/local/bin/siyi-paramd /usr/local/bin/siyi-video-source /usr/local/bin/siyi-video-udp-forward /usr/local/sbin/siyi-video-source-control
sudo visudo -cf /etc/sudoers.d/siyi-webui
sudo chmod 0600 /home/pi/siyi-webui/wifi_passwords.json /etc/siyi/maptiler.json
sudo chmod 0660 /etc/siyi/video_source.json /etc/siyi/zerotier_config.json
sudo install -d -o root -g root -m 0755 /usr/local/share/siyi/releases/4.2.0
sudo install -o root -g root -m 0755 "$SCRIPT_DIR/health-check.sh" /usr/local/share/siyi/releases/4.2.0/health-check.sh
for file in release-metadata.json supported-sources.json source-lock.json payload-manifest.json requirements.txt apt-packages.txt; do
  sudo install -o root -g root -m 0644 "$SCRIPT_DIR/$file" "/usr/local/share/siyi/releases/4.2.0/$file"
done

progress 70 "Configuring MAVLink router"
sudo install -d -o root -g root -m 0755 /etc/mavlink-router
sudo install -o root -g root -m 0644 "$PAYLOAD/etc/mavlink-router/main.conf" /etc/mavlink-router/main.conf
sudo install -o pi -g pi -m 0755 "$PAYLOAD/home/pi/apply_siyi_endpoints.sh" /home/pi/apply_siyi_endpoints.sh
/home/pi/apply_siyi_endpoints.sh || true

progress 76 "Installing camera time sync"
test -x /usr/local/bin/siyi_proxy_socket_time_sync.sh
test -f /etc/systemd/system/siyi-camera-time-sync.service

progress 82 "Enabling SIYI services"
sudo systemctl daemon-reload
sudo systemctl enable NetworkManager.service zerotier-one.service
units=(mavlink-router.service mediamtx.service siyi-battery-cache.service siyi-button-bridge.service siyi-camera-time-sync.service siyi-groundstation.service siyi-joystickd.service siyi-paramd.service siyi-rec-proxy.service siyi-rec-redirect.service siyi-rtsp-redirect.service siyi-telemetry-canvas.service siyi-video-dual.service siyi-video-source.service siyi-webui.service siyi-postinstall-verify.service)
sudo systemctl enable "${units[@]}"

readarray -t mav < <(python3 - "$SOURCE_LOCK" <<'PYMAV'
import json,sys
m=json.load(open(sys.argv[1]))['mavlink-router']
print(m['repository']); print(m['commit']); print(m['submodules']['modules/mavlink_c_library_v2']); print(m['expected_version'])
PYMAV
)
if ! command -v mavlink-routerd >/dev/null 2>&1 || ! mavlink-routerd --version 2>/dev/null | grep -Fq "${mav[3]}"; then
  echo "=== Build mavlink-router ==="
  rm -rf /home/pi/mavlink-router-build
  git clone "${mav[0]}" /home/pi/mavlink-router-build
  cd /home/pi/mavlink-router-build
  git -c advice.detachedHead=false checkout --detach "${mav[1]}"
  [ "$(git rev-parse HEAD)" = "${mav[1]}" ] || die "MAVLink Router commit verification failed."
  git submodule update --init --recursive
  [ "$(git -C modules/mavlink_c_library_v2 rev-parse HEAD)" = "${mav[2]}" ] || die "MAVLink C submodule verification failed."
  meson setup build .
  ninja -C build
  sudo ninja -C build install
  cd "$SCRIPT_DIR"
fi
command -v mavlink-routerd >/dev/null 2>&1 || die "MAVLink Router was not installed."
mavlink-routerd --version 2>&1 | grep -Fq "${mav[3]}" || die "MAVLink Router version verification failed."
sudo systemctl enable mavlink-router

progress 88 "Installing MediaMTX"
readarray -t media < <(python3 - "$SOURCE_LOCK" <<'PYMEDIA'
import json,sys
m=json.load(open(sys.argv[1]))['mediamtx']
print(m['url']); print(m['archive_sha256']); print(m['binary_sha256']); print(m['version'])
PYMEDIA
)
media_url="${media[0]}"; media_archive_sha="${media[1]}"; media_binary_sha="${media[2]}"; media_version="${media[3]}"
if ! { [ -x /usr/local/bin/mediamtx ] && [ "$(sha256sum /usr/local/bin/mediamtx | awk '{print $1}')" = "$media_binary_sha" ]; }; then
  media_dir="/tmp/siyi-mediamtx-$TX"
  rm -rf "$media_dir"; mkdir -p "$media_dir"
  curl --connect-timeout 15 --max-time 180 -fL "$media_url" -o "$media_dir/mediamtx.tar.gz"
  echo "$media_archive_sha  $media_dir/mediamtx.tar.gz" | sha256sum -c -
  tar -xzf "$media_dir/mediamtx.tar.gz" -C "$media_dir" mediamtx
  echo "$media_binary_sha  $media_dir/mediamtx" | sha256sum -c -
  sudo install -m 0755 "$media_dir/mediamtx" /usr/local/bin/mediamtx
fi
[ "$(sha256sum /usr/local/bin/mediamtx | awk '{print $1}')" = "$media_binary_sha" ] || die "MediaMTX binary checksum verification failed."
/usr/local/bin/mediamtx --version 2>&1 | grep -Fq "$media_version" || die "MediaMTX version verification failed."
sudo systemctl daemon-reload
sudo systemctl enable mediamtx.service siyi-rtsp-redirect.service

printf '%s\n' "$VERSION" >"$TX_DIR/release_version"
printf '%s\n' "$BUILD_ID" >"$TX_DIR/release_build"
printf '%s\n' pending_reboot >"$TX_DIR/release_status"
sudo install -d -o pi -g pi -m 0775 /etc/siyi
sudo install -o root -g root -m 0644 "$TX_DIR/release_version" /etc/siyi/release_version
sudo install -o root -g root -m 0644 "$TX_DIR/release_build" /etc/siyi/release_build
sudo install -o root -g root -m 0644 "$TX_DIR/release_status" /etc/siyi/release_status
[ "$(tr -d '[:space:]' </etc/siyi/release_version)" = "$VERSION" ] || die "Release-version marker write verification failed."
[ "$(tr -d '[:space:]' </etc/siyi/release_build)" = "$BUILD_ID" ] || die "Release-build marker write verification failed."
sudo "$SCRIPT_DIR/health-check.sh" --pre-reboot
sudo python3 - "$MANIFEST" <<'PYFINAL'
import hashlib,json,os,sys
m=json.load(open(sys.argv[1],encoding='utf-8'))
for item in m['files']:
    if item['type']!='file' or item.get('persistent') or item['path']=='/usr/local/share/siyi/releases/4.2.0/payload-manifest.json': continue
    p=item['path']
    if not os.path.isfile(p): raise SystemExit('missing '+p)
    if hashlib.sha256(open(p,'rb').read()).hexdigest()!=item['sha256']: raise SystemExit('mismatch '+p)
PYFINAL
touch "$TX_DIR/INSTALL_STAGED"
SUCCESS=1
trap - ERR INT TERM
progress 100 "Install complete"

PRIMARY_IP=""
if [ -n "${SSH_CONNECTION:-}" ]; then
  CLIENT_IP="$(echo "$SSH_CONNECTION" | awk '{print $1}')"
  PRIMARY_IP="$(ip route get "$CLIENT_IP" 2>/dev/null | sed -n 's/.* src \([^ ]*\).*/\1/p')"
fi
[ -n "$PRIMARY_IP" ] || PRIMARY_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
[ -n "$PRIMARY_IP" ] || PRIMARY_IP="$(hostname).local"
cat >&3 <<EOF

========================================
✅ SIYI INSTALL COMPLETE
========================================

=== OPEN WEB UI ===
http://${PRIMARY_IP}:8080

👉 Connect Mac or PC to the same WiFi as the PI and use the above URL for local access to the Web client, from there configure Zero Tier and Hosts.

Full install log:
$INSTALL_LOG
EOF

if [ "$NO_REBOOT" -eq 0 ]; then
  cat >&3 <<EOF

The Raspberry Pi will reboot automatically in 5 seconds.
Post-reboot acceptance will be written to:
/etc/siyi/release_status
EOF
  sleep 5
  sudo systemctl reboot
else
  cat >&3 <<EOF

Reboot required. Run:
sudo reboot
EOF
fi
