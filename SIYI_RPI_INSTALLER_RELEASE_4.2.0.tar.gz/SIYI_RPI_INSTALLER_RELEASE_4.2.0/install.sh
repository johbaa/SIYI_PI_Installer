#!/usr/bin/env bash
set -Eeuo pipefail
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
export LC_CTYPE=C.UTF-8
VERSION="4.2.0"
BUILD_ID="SIYI_4_2_0_BASELINE_V5"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload/rootfs"
MANIFEST="$SCRIPT_DIR/payload-manifest.json"
SOURCE_LOCK="$SCRIPT_DIR/source-lock.json"
REPAIR=0
NO_REBOOT=0
REQUIRE_FC=0
for arg in "$@"; do
  case "$arg" in
    --repair) REPAIR=1 ;;
    --no-reboot) NO_REBOOT=1 ;;
    --require-fc) REQUIRE_FC=1 ;;
    *) echo "Unknown option: $arg" >&2; exit 2 ;;
  esac
done

CALLING_USER="${SIYI_CALLING_USER:-${SUDO_USER:-${USER:-pi}}}"
[ "$CALLING_USER" = root ] && CALLING_USER=pi
CALLING_HOME="$(getent passwd "$CALLING_USER" 2>/dev/null | cut -d: -f6 || true)"
[ -n "$CALLING_HOME" ] || CALLING_HOME=/home/pi
INSTALL_LOG="${SIYI_INSTALL_LOG:-$CALLING_HOME/siyi_install_${VERSION}_$(date +%Y%m%d_%H%M%S).log}"

if [ "$(id -u)" -ne 0 ]; then
  echo "Full log: $INSTALL_LOG"
  echo
  echo "Sudo check: enter the Pi password if asked."
  command -v sudo >/dev/null 2>&1 || { echo "sudo is required." >&2; exit 1; }
  sudo -v
  exec sudo env \
    SIYI_CALLING_USER="$CALLING_USER" \
    SIYI_INSTALL_LOG="$INSTALL_LOG" \
    SIYI_UI_INTRO_SHOWN=1 \
    SSH_CONNECTION="${SSH_CONNECTION:-}" \
    TERM="${TERM:-xterm}" \
    LANG=C.UTF-8 LC_ALL=C.UTF-8 LC_CTYPE=C.UTF-8 \
    bash "$0" "$@"
fi

mkdir -p "$(dirname "$INSTALL_LOG")"
touch "$INSTALL_LOG"
chown "$CALLING_USER:$CALLING_USER" "$INSTALL_LOG" 2>/dev/null || true
exec 3>&1 4>&2
exec >>"$INSTALL_LOG" 2>&1
if [ "${SIYI_UI_INTRO_SHOWN:-0}" != 1 ]; then
  echo "Full log: $INSTALL_LOG" >&3
fi

SIYI_BLUE=$'\033[0;94m'
SIYI_GREEN=$'\033[1;32m'
SIYI_RESET=$'\033[0m'
SIYI_PROGRESS_HEADING_PRINTED=0
INSTALL_START_TS="$SECONDS"
PROGRESS_ANIM_PID=""
CURRENT_STEP_NAME="Starting installer"
PROGRESS_LAST=0
SUCCESS=0
SNAPSHOT_READY=0
VENV_SWAPPED=0
CAM_PROFILE_CREATED=0
TX="$(date +%Y%m%d_%H%M%S)_$RANDOM"
LOG_DIR=/var/log/siyi-installer
TX_DIR="/var/lib/siyi-installer/transactions/$TX"
mkdir -p "$LOG_DIR" "$TX_DIR"
TX_LOG="$LOG_DIR/install_${VERSION}_${TX}.log"
ln -sf "$INSTALL_LOG" "$TX_LOG" 2>/dev/null || true

progress_next_target(){
  case "$1" in
    5) echo 9 ;; 10) echo 24 ;; 25) echo 34 ;; 35) echo 44 ;; 45) echo 49 ;;
    50) echo 57 ;; 58) echo 64 ;; 65) echo 69 ;; 70) echo 75 ;; 76) echo 81 ;;
    82) echo 87 ;; 88) echo 99 ;; *) echo "$1" ;;
  esac
}
draw_progress(){
  local pct="$1" msg="$2" elapsed="${3:-0}" width=20
  local filled empty bar="" i
  filled=$((pct * width / 100))
  empty=$((width - filled))
  local spin idx sp timer=""
  spin='|/-\\'
  idx=$((SECONDS % 4))
  sp="${spin:$idx:1}"
  if [ "$elapsed" -gt 0 ]; then timer=$(printf ' (%02dm %02ds)' $((elapsed/60)) $((elapsed%60))); fi
  for ((i=0;i<filled;i++)); do bar+='█'; done
  for ((i=0;i<empty;i++)); do bar+='░'; done
  if [ "$SIYI_PROGRESS_HEADING_PRINTED" -eq 0 ]; then
    printf '%sInstalling, SIYI PI Control System%s\n\n' "$SIYI_BLUE" "$SIYI_RESET" >&3
    SIYI_PROGRESS_HEADING_PRINTED=1
  fi
  printf '\r\033[2K%s%s [%s] %3d%%  %s%s%s' "$SIYI_GREEN" "$sp" "$bar" "$pct" "$msg" "$timer" "$SIYI_RESET" >&3
}
stop_progress_anim(){
  if [ -n "${PROGRESS_ANIM_PID:-}" ]; then
    kill "$PROGRESS_ANIM_PID" >/dev/null 2>&1 || true
    wait "$PROGRESS_ANIM_PID" >/dev/null 2>&1 || true
    PROGRESS_ANIM_PID=""
  fi
}
progress(){
  local pct="$1" msg="$2" target cur
  stop_progress_anim
  CURRENT_STEP_NAME="$msg"; PROGRESS_LAST="$pct"
  draw_progress "$pct" "$msg" "$((SECONDS-INSTALL_START_TS))"
  if [ "$pct" -ge 100 ]; then printf '\n' >&3; return; fi
  target="$(progress_next_target "$pct")"
  (
    cur="$pct"
    while true; do
      sleep 1
      [ "$cur" -ge "$target" ] || cur=$((cur+1))
      draw_progress "$cur" "$msg" "$((SECONDS-INSTALL_START_TS))"
    done
  ) &
  PROGRESS_ANIM_PID="$!"
}
run_logged(){
  local description="$1"; shift
  echo "=== $description ==="
  "$@"
}
die(){ echo "INSTALL FAILED: $*"; return 1; }

ROLLBACK_RESULT="not required"
rollback_transaction(){
  local original_rc="$1" rollback_warning=0
  set +e
  echo "=== ROLLBACK START: transaction $TX, original exit $original_rc ==="
  if [ "$VENV_SWAPPED" -eq 1 ]; then
    rm -rf /home/pi/siyi-bridge-venv || rollback_warning=1
    if [ -d "$TX_DIR/siyi-bridge-venv.previous" ]; then mv "$TX_DIR/siyi-bridge-venv.previous" /home/pi/siyi-bridge-venv || rollback_warning=1; fi
  fi
  if [ "$SNAPSHOT_READY" -eq 1 ]; then
    python3 - "$MANIFEST" "$TX_DIR/backup-index.json" "$TX_DIR/backup-root" <<'PYROLLBACK' || rollback_warning=1
import json,os,shutil,sys
manifest,index_path,backup_root=sys.argv[1:]
items=json.load(open(manifest,encoding='utf-8'))['files']
index=json.load(open(index_path,encoding='utf-8')); existing=set(index.get('existing',[]))
for p in ['/usr/local/bin/mediamtx','/usr/bin/mavlink-routerd','/usr/bin/mavlink-router']:
    if p in existing: continue
    try:
        if os.path.isdir(p) and not os.path.islink(p): shutil.rmtree(p)
        elif os.path.lexists(p): os.unlink(p)
    except Exception: pass
for item in reversed(items):
    p=item['path']
    if item['type']=='directory': continue
    try:
        if os.path.isdir(p) and not os.path.islink(p): shutil.rmtree(p)
        elif os.path.lexists(p): os.unlink(p)
    except Exception: pass
for p in index.get('existing',[]):
    src=os.path.join(backup_root,p.lstrip('/'))
    try:
        os.makedirs(os.path.dirname(p),exist_ok=True)
        if os.path.islink(src): os.symlink(os.readlink(src),p)
        elif os.path.isdir(src): shutil.copytree(src,p,symlinks=True,dirs_exist_ok=True)
        elif os.path.isfile(src): shutil.copy2(src,p,follow_symlinks=False)
    except Exception: pass
PYROLLBACK
    [ ! -d "$TX_DIR/boot-backup" ] || cp -a "$TX_DIR/boot-backup/." / 2>/dev/null || rollback_warning=1
  fi
  [ "$CAM_PROFILE_CREATED" -eq 0 ] || nmcli connection delete cam-eth0 >/dev/null 2>&1 || rollback_warning=1
  systemctl daemon-reload >/dev/null 2>&1 || rollback_warning=1
  if [ -f "$TX_DIR/active-units.txt" ]; then
    while read -r u; do [ -z "$u" ] || systemctl restart "$u" >/dev/null 2>&1 || true; done <"$TX_DIR/active-units.txt"
  fi
  if [ "$rollback_warning" -eq 0 ]; then ROLLBACK_RESULT="Complete"; else ROLLBACK_RESULT="Completed with warnings; inspect the log"; fi
  echo "=== ROLLBACK END: $ROLLBACK_RESULT ==="
  set -e
}
on_failure(){
  local rc="$1"
  trap - ERR INT TERM
  stop_progress_anim || true
  rollback_transaction "$rc"
  chown "$CALLING_USER:$CALLING_USER" "$INSTALL_LOG" 2>/dev/null || true
  printf '\n\n' >&3
  echo '========================================' >&3
  echo '❌ SIYI INSTALL FAILED' >&3
  echo '========================================' >&3
  echo "Step: ${CURRENT_STEP_NAME:-Starting installer}" >&3
  echo "Exit code: $rc" >&3
  echo "Rollback: $ROLLBACK_RESULT" >&3
  echo "Transaction: $TX_DIR" >&3
  echo 'Full log:' >&3
  echo "$INSTALL_LOG" >&3
  echo >&3
  exit "$rc"
}
trap 'on_failure $?' ERR
trap 'on_failure 130' INT
trap 'on_failure 143' TERM

progress 5 "Preparing installer"
[ "$(uname -m)" = aarch64 ] || die "4.2.0 supports Raspberry Pi OS 64-bit (aarch64) only."
. /etc/os-release
case "${ID:-}" in debian|raspbian) ;; *) die "Unsupported OS ${ID:-unknown}" ;; esac
[ "${VERSION_ID:-}" = 13 ] || die "4.2.0 baseline requires Raspberry Pi OS / Debian 13."
[ -r /proc/device-tree/model ] || die "Raspberry Pi hardware was not detected."
model="$(tr -d '\0' </proc/device-tree/model)"
case "$model" in *"Raspberry Pi 3 Model B Plus"*|*"Raspberry Pi 4 Model B"*|*"Raspberry Pi 5"*) ;; *) die "Unsupported Raspberry Pi model: $model" ;; esac
free_kb="$(df -Pk / | awk 'NR==2{print $4}')"; [ "$free_kb" -ge 2097152 ] || die "At least 2 GiB free space is required."
release_marker=/etc/siyi/release_version; current=""; current_build=""
[ ! -r "$release_marker" ] || current="$(tr -d '[:space:]' <"$release_marker")"
[ ! -r /etc/siyi/release_build ] || current_build="$(tr -d '[:space:]' </etc/siyi/release_build)"
if [ -e "$release_marker" ]; then
  [ -n "$current" ] || die "Invalid empty release marker. Refusing an uncontrolled overwrite."
  if [ "$current" = "$VERSION" ] && [ "$REPAIR" -eq 1 ]; then :
  elif [ "$current" = "$VERSION" ]; then die "$VERSION is already installed. Use --repair for a verified reinstall."
  else die "Upgrade from $current is unsupported. 4.2.0 is the fresh-install ground-zero baseline."; fi
elif [ -e /home/pi/siyi-webui/server.py ] || systemctl list-unit-files 'siyi-*.service' --no-legend 2>/dev/null | grep -q .; then
  die "An unversioned existing SIYI installation was detected. 4.2.0 fresh install requires a freshly flashed OS."
fi
python3 - "$PAYLOAD" "$MANIFEST" <<'PYVERIFY'
import hashlib,json,os,sys
root,manifest=sys.argv[1:]; data=json.load(open(manifest,encoding='utf-8'))
for item in data['files']:
    p=os.path.join(root,item['path'].lstrip('/'))
    if item['type']=='directory':
        if not os.path.isdir(p): raise SystemExit('missing directory '+item['path'])
    elif item['type']=='symlink':
        if not os.path.islink(p): raise SystemExit('missing symlink '+item['path'])
        if hashlib.sha256(os.readlink(p).encode()).hexdigest()!=item['sha256']: raise SystemExit('symlink checksum mismatch '+item['path'])
    else:
        if not os.path.isfile(p): raise SystemExit('missing file '+item['path'])
        if hashlib.sha256(open(p,'rb').read()).hexdigest()!=item['sha256']: raise SystemExit('checksum mismatch '+item['path'])
PYVERIFY
mkdir -p "$TX_DIR/backup-root" "$TX_DIR/boot-backup"
systemctl list-units --state=active --type=service --no-legend 2>/dev/null | awk '{print $1}' >"$TX_DIR/active-units.txt" || true
python3 - "$MANIFEST" "$TX_DIR/backup-index.json" "$TX_DIR/backup-root" <<'PYBACKUP'
import json,os,shutil,sys
manifest,index_path,backup_root=sys.argv[1:]
paths=[x['path'] for x in json.load(open(manifest,encoding='utf-8'))['files'] if x['type']!='directory']
paths += ['/usr/local/bin/mediamtx','/usr/bin/mavlink-routerd','/usr/bin/mavlink-router']
existing=[]
for p in dict.fromkeys(paths):
    if not os.path.lexists(p): continue
    existing.append(p); dst=os.path.join(backup_root,p.lstrip('/')); os.makedirs(os.path.dirname(dst),exist_ok=True)
    if os.path.islink(p): os.symlink(os.readlink(p),dst)
    elif os.path.isdir(p): shutil.copytree(p,dst,symlinks=True)
    else: shutil.copy2(p,dst,follow_symlinks=False)
json.dump({'existing':existing},open(index_path,'w'),indent=2)
PYBACKUP
for p in /boot/firmware/cmdline.txt /boot/firmware/config.txt /boot/cmdline.txt /boot/config.txt; do [ ! -e "$p" ] || install -D -m 0644 "$p" "$TX_DIR/boot-backup$p"; done
SNAPSHOT_READY=1

progress 10 "Installing base dependencies"
export DEBIAN_FRONTEND=noninteractive APT_LISTCHANGES_FRONTEND=none
install -D -o root -g root -m 0644 "$PAYLOAD/usr/share/keyrings/zerotier-debian-package-key.gpg" /usr/share/keyrings/zerotier-debian-package-key.gpg
install -D -o root -g root -m 0644 "$PAYLOAD/etc/apt/sources.list.d/zerotier.list" /etc/apt/sources.list.d/zerotier.list
run_logged "Updating package indexes" apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 update
mapfile -t packages < <(grep -Ev '^($|#)' "$SCRIPT_DIR/apt-packages.txt")
run_logged "Installing required operating-system packages" apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 install -y --no-install-recommends "${packages[@]}"
run_logged "Verifying MAVLink Router systemd build metadata" pkg-config --exists systemd

progress 25 "Installing ZeroTier"
run_logged "Installing ZeroTier" apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 install -y --no-install-recommends zerotier-one

progress 35 "Installing SIYI configuration"
getent group pi >/dev/null 2>&1 || groupadd pi
if ! id pi >/dev/null 2>&1; then useradd -m -g pi -s /bin/bash pi; fi
for group in dialout input video render netdev; do getent group "$group" >/dev/null && usermod -a -G "$group" pi; done
python3 - "$PAYLOAD" "$MANIFEST" <<'PYDEPLOY'
import json,os,shutil,sys,tempfile
root,manifest=sys.argv[1:]; data=json.load(open(manifest,encoding='utf-8'))
for item in sorted(data['files'],key=lambda x:(x['type']!='directory',x['path'].count('/'),x['path'])):
    src=os.path.join(root,item['path'].lstrip('/')); dst=item['path']
    if item.get('persistent') and os.path.lexists(dst): continue
    if item['type']=='directory': os.makedirs(dst,exist_ok=True)
    elif item['type']=='symlink':
        os.makedirs(os.path.dirname(dst),exist_ok=True)
        if os.path.lexists(dst):
            if os.path.isdir(dst) and not os.path.islink(dst): shutil.rmtree(dst)
            else: os.unlink(dst)
        os.symlink(os.readlink(src),dst)
    else:
        os.makedirs(os.path.dirname(dst),exist_ok=True)
        fd,tmp=tempfile.mkstemp(prefix='.siyi420.',dir=os.path.dirname(dst)); os.close(fd)
        shutil.copy2(src,tmp,follow_symlinks=False); os.replace(tmp,dst)
    try: os.chmod(dst,int(item['mode'],8),follow_symlinks=False)
    except (NotImplementedError,FileNotFoundError): pass
    try: shutil.chown(dst,user=item['owner'],group=item['group'])
    except (LookupError,PermissionError,FileNotFoundError): pass
for p in data.get('obsolete_paths',[]):
    if os.path.isdir(p) and not os.path.islink(p): shutil.rmtree(p,ignore_errors=True)
    elif os.path.lexists(p): os.unlink(p)
PYDEPLOY
install -d -o pi -g pi -m 0775 /home/pi/.config/siyi /var/lib/siyi-user-config/groundstation
install -d -o root -g pi -m 0775 /var/lib/siyi-upgrade /var/backups/siyi-upgrade /var/lib/siyi-installer
for dst in /home/pi/.config/siyi/telemetry_canvas.json /var/lib/siyi-user-config/groundstation/telemetry_canvas.json; do [ -e "$dst" ] || install -o pi -g pi -m 0664 /usr/local/share/siyi/defaults/telemetry_canvas.json "$dst"; done
[ -e /var/lib/siyi-upgrade/preserve_preferences.json ] || install -o root -g pi -m 0664 /usr/local/share/siyi/defaults/upgrade_preserve_preferences.json /var/lib/siyi-upgrade/preserve_preferences.json
rm -f /etc/siyi/zerotier_api_token

progress 45 "Installing Web UI"
test -f /home/pi/siyi-webui/server.py
test -f /home/pi/siyi-webui/wifi_passwords.json
chown -R pi:pi /home/pi/siyi-webui /home/pi/siyi-joystick

progress 50 "Configuring camera Ethernet"
if ip link show eth0 >/dev/null 2>&1; then
  existing_cam="$(nmcli -t -f NAME connection show 2>/dev/null | awk '$0=="cam-eth0"{print;exit}')"
  if [ -z "$existing_cam" ]; then nmcli connection add type ethernet ifname eth0 con-name cam-eth0 >/dev/null; CAM_PROFILE_CREATED=1; fi
  nmcli connection modify cam-eth0 connection.interface-name eth0 connection.autoconnect yes connection.autoconnect-priority 100 ipv4.method manual ipv4.addresses 192.168.144.20/24 ipv4.gateway "" ipv4.dns "" ipv4.never-default yes ipv6.method disabled
fi

progress 58 "Preparing Python environment"
rm -rf /home/pi/siyi-bridge-venv.new
run_logged "Creating Python virtual environment" python3 -m venv /home/pi/siyi-bridge-venv.new
run_logged "Updating Python package installer" /home/pi/siyi-bridge-venv.new/bin/pip install --disable-pip-version-check --no-cache-dir --upgrade pip
run_logged "Installing pinned Python dependencies" /home/pi/siyi-bridge-venv.new/bin/pip install --disable-pip-version-check --no-cache-dir --requirement "$SCRIPT_DIR/requirements.txt"
run_logged "Checking Python dependency consistency" /home/pi/siyi-bridge-venv.new/bin/pip check
/home/pi/siyi-bridge-venv.new/bin/python - <<'PYIMPORT'
from pymavlink import mavutil
import fastcrc,future,lxml,numpy,serial,requests,psutil,aiohttp,websockets,yaml
PYIMPORT
if [ -d /home/pi/siyi-bridge-venv ]; then mv /home/pi/siyi-bridge-venv "$TX_DIR/siyi-bridge-venv.previous"; fi
mv /home/pi/siyi-bridge-venv.new /home/pi/siyi-bridge-venv
VENV_SWAPPED=1
chown -R pi:pi /home/pi/siyi-bridge-venv

progress 65 "Installing system services"
boot_dir=""; [ ! -d /boot/firmware ] || boot_dir=/boot/firmware; [ -n "$boot_dir" ] || [ ! -d /boot ] || boot_dir=/boot
[ -n "$boot_dir" ] || die "Boot configuration directory not found."
cmdline="$boot_dir/cmdline.txt"; config="$boot_dir/config.txt"; [ -f "$cmdline" ] || die "$cmdline not found."
python3 - "$cmdline" <<'PYCMD'
import pathlib,re,sys
p=pathlib.Path(sys.argv[1]); tokens=p.read_text().strip().split()
tokens=[t for t in tokens if not re.fullmatch(r'console=(serial0|ttyS0|ttyAMA0),.*',t)]
p.write_text(' '.join(tokens)+'\n')
PYCMD
touch "$config"
python3 - "$config" <<'PYCONFIG'
import pathlib,re,sys
p=pathlib.Path(sys.argv[1]); s=p.read_text()
if re.search(r'(?m)^enable_uart=',s): s=re.sub(r'(?m)^enable_uart=.*$','enable_uart=1',s)
else: s=s.rstrip()+'\n\nenable_uart=1\n'
p.write_text(s)
PYCONFIG
systemctl disable --now serial-getty@serial0.service serial-getty@ttyS0.service serial-getty@ttyAMA0.service 2>/dev/null || true
systemctl mask serial-getty@serial0.service serial-getty@ttyS0.service serial-getty@ttyAMA0.service 2>/dev/null || true
/home/pi/siyi-bridge-venv/bin/python -m py_compile /home/pi/siyi-webui/server.py /home/pi/siyi_mav_button_bridge.py /home/pi/siyi-battery-cache.py /home/pi/siyi-joystick/joystickd.py /usr/local/lib/siyi/groundstation/groundstation_daemon.py /usr/local/bin/siyi-paramd /usr/local/bin/siyi-video-source /usr/local/bin/siyi-video-udp-forward /usr/local/sbin/siyi-video-source-control
visudo -cf /etc/sudoers.d/siyi-webui
chmod 0600 /home/pi/siyi-webui/wifi_passwords.json /etc/siyi/maptiler.json
chmod 0660 /etc/siyi/video_source.json /etc/siyi/zerotier_config.json
install -d -o root -g root -m 0755 /usr/local/share/siyi/releases/4.2.0
install -o root -g root -m 0755 "$SCRIPT_DIR/health-check.sh" /usr/local/share/siyi/releases/4.2.0/health-check.sh
for f in release-metadata.json supported-sources.json source-lock.json payload-manifest.json requirements.txt apt-packages.txt; do install -o root -g root -m 0644 "$SCRIPT_DIR/$f" "/usr/local/share/siyi/releases/4.2.0/$f"; done

progress 70 "Configuring MAVLink router"
readarray -t mav < <(python3 - "$SOURCE_LOCK" <<'PYMAV'
import json,sys
m=json.load(open(sys.argv[1]))['mavlink-router']
print(m['repository']); print(m['commit']); print(m['submodules']['modules/mavlink_c_library_v2']); print(m['expected_version'])
PYMAV
)
if ! /usr/bin/mavlink-routerd --version 2>/dev/null | grep -Fq "${mav[3]}"; then
  build="$TX_DIR/mavlink-router"
  run_logged "Downloading pinned MAVLink Router source" git clone --recursive "${mav[0]}" "$build"
  run_logged "Selecting pinned MAVLink Router commit" git -C "$build" -c advice.detachedHead=false checkout --detach "${mav[1]}"
  [ "$(git -C "$build" rev-parse HEAD)" = "${mav[1]}" ] || die "MAVLink Router commit verification failed."
  run_logged "Synchronizing pinned MAVLink definitions" git -C "$build" submodule update --init --recursive
  [ "$(git -C "$build/modules/mavlink_c_library_v2" rev-parse HEAD)" = "${mav[2]}" ] || die "MAVLink C submodule verification failed."
  systemd_unit_dir="$(pkg-config --variable=systemdsystemunitdir systemd)"
  [ -n "$systemd_unit_dir" ] || die "systemd pkg-config metadata returned no unit directory."
  run_logged "Configuring MAVLink Router build" meson setup "$build/build" "$build" --buildtype=release --prefix=/usr -Dsystemdsystemunitdir="$systemd_unit_dir"
  run_logged "Compiling MAVLink Router" ninja -C "$build/build"
  run_logged "Installing MAVLink Router" ninja -C "$build/build" install
fi
/usr/bin/mavlink-routerd --version 2>&1 | grep -Fq "${mav[3]}" || die "MAVLink Router version verification failed."

progress 76 "Installing camera time sync"
test -x /usr/local/bin/siyi_proxy_socket_time_sync.sh
test -f /etc/systemd/system/siyi-camera-time-sync.service

progress 82 "Enabling SIYI services"
run_logged "Reloading service definitions" systemctl daemon-reload
run_logged "Enabling platform services" systemctl enable NetworkManager.service zerotier-one.service
units=(mavlink-router.service mediamtx.service siyi-battery-cache.service siyi-button-bridge.service siyi-camera-time-sync.service siyi-groundstation.service siyi-joystickd.service siyi-paramd.service siyi-rec-proxy.service siyi-rec-redirect.service siyi-rtsp-redirect.service siyi-telemetry-canvas.service siyi-video-dual.service siyi-video-source.service siyi-webui.service siyi-postinstall-verify.service)
run_logged "Enabling SIYI services" systemctl enable "${units[@]}"

progress 88 "Installing MediaMTX"
readarray -t media < <(python3 - "$SOURCE_LOCK" <<'PYMEDIA'
import json,sys
m=json.load(open(sys.argv[1]))['mediamtx']
print(m['url']); print(m['archive_sha256']); print(m['binary_sha256']); print(m['version'])
PYMEDIA
)
media_url="${media[0]}"; media_archive_sha="${media[1]}"; media_binary_sha="${media[2]}"; media_version="${media[3]}"
if ! { [ -x /usr/local/bin/mediamtx ] && [ "$(sha256sum /usr/local/bin/mediamtx | awk '{print $1}')" = "$media_binary_sha" ]; }; then
  media_dir="$TX_DIR/mediamtx"; mkdir -p "$media_dir"
  run_logged "Downloading pinned MediaMTX" curl -fsSL --retry 4 --retry-delay 2 --connect-timeout 20 "$media_url" -o "$media_dir/mediamtx.tar.gz"
  echo "$media_archive_sha  $media_dir/mediamtx.tar.gz" | sha256sum -c -
  tar -tzf "$media_dir/mediamtx.tar.gz" | grep -Fx mediamtx >/dev/null || die "MediaMTX archive does not contain the expected binary."
  run_logged "Extracting MediaMTX" tar -xzf "$media_dir/mediamtx.tar.gz" -C "$media_dir" mediamtx
  echo "$media_binary_sha  $media_dir/mediamtx" | sha256sum -c -
  install -o root -g root -m 0755 "$media_dir/mediamtx" /usr/local/bin/mediamtx
fi
[ "$(sha256sum /usr/local/bin/mediamtx | awk '{print $1}')" = "$media_binary_sha" ] || die "MediaMTX binary checksum verification failed."
/usr/local/bin/mediamtx --version 2>&1 | grep -Fq "$media_version" || die "MediaMTX version verification failed."

# Atomic release markers; health check reads expected values from release metadata.
install -d -o pi -g pi -m 0775 /etc/siyi
printf '%s\n' "$VERSION" >"$TX_DIR/release_version"
printf '%s\n' "$BUILD_ID" >"$TX_DIR/release_build"
printf '%s\n' pending_reboot >"$TX_DIR/release_status"
install -o root -g root -m 0644 "$TX_DIR/release_version" /etc/siyi/release_version
install -o root -g root -m 0644 "$TX_DIR/release_build" /etc/siyi/release_build
install -o root -g root -m 0644 "$TX_DIR/release_status" /etc/siyi/release_status
[ "$(tr -d '[:space:]' </etc/siyi/release_version)" = "$VERSION" ] || die "Release-version marker write verification failed."
[ "$(tr -d '[:space:]' </etc/siyi/release_build)" = "$BUILD_ID" ] || die "Release-build marker write verification failed."
"$SCRIPT_DIR/health-check.sh" --pre-reboot
python3 - "$MANIFEST" <<'PYFINAL'
import hashlib,json,os,sys
m=json.load(open(sys.argv[1],encoding='utf-8'))
for item in m['files']:
    if item['type']!='file' or item.get('persistent') or item['path']=='/usr/local/share/siyi/releases/4.2.0/payload-manifest.json': continue
    p=item['path']
    if not os.path.isfile(p): raise SystemExit('missing '+p)
    if hashlib.sha256(open(p,'rb').read()).hexdigest()!=item['sha256']: raise SystemExit('mismatch '+p)
PYFINAL
touch "$TX_DIR/INSTALL_STAGED"
SUCCESS=1
trap - ERR INT TERM
progress 100 "Install complete"
chown "$CALLING_USER:$CALLING_USER" "$INSTALL_LOG" 2>/dev/null || true
PRIMARY_IP=""
if [ -n "${SSH_CONNECTION:-}" ]; then
  CLIENT_IP="$(echo "$SSH_CONNECTION" | awk '{print $1}')"
  PRIMARY_IP="$(ip route get "$CLIENT_IP" 2>/dev/null | sed -n 's/.* src \([^ ]*\).*/\1/p')"
fi
[ -n "$PRIMARY_IP" ] || PRIMARY_IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
[ -n "$PRIMARY_IP" ] || PRIMARY_IP="$(hostname).local"
cat >&3 <<EOF

========================================
✅ SIYI INSTALL COMPLETE
========================================

=== OPEN WEB UI ===
http://${PRIMARY_IP}:8080

👉 Connect Mac or PC to the same WiFi as the PI and use the above URL for local access to the Web client, from there configure Zero Tier and Hosts.

Full install log:
$INSTALL_LOG
EOF
if [ "$NO_REBOOT" -eq 0 ]; then
  cat >&3 <<EOF

The Raspberry Pi will reboot automatically in 5 seconds.
Post-reboot acceptance will be written to:
/etc/siyi/release_status
EOF
  sleep 5
  systemctl reboot
else
  cat >&3 <<EOF

Reboot required. Run:
sudo reboot
EOF
fi
