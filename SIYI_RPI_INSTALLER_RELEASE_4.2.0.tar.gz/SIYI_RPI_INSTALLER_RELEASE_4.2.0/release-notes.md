# SIYI 4.2.0 SIYI_4_2_0_BASELINE_V9

- Fresh-install-only 4.2.0 ground-zero baseline.
- Canonical first-install terminal UX restored from the proven 3.1.12 installer.
- Detailed package/build output is written only to the full install log.
- Fixed stale release-build identifiers in health check and post-reboot verification.
- Release markers are written atomically and verified before health acceptance.
- Retains pinned MediaMTX, pinned MAVLink Router, transaction snapshot and rollback.

- V7 fixes interrupted-install marker recovery and explicitly restores release markers during rollback.

- V9 fixes Python validation permissions and limits rollback strictly to SIYI-managed services, eliminating cloud-init restart hangs and venv deletion races.
