# SIYI 4.2.0 SIYI_4_2_0_BASELINE_V10

- Fresh-install-only 4.2.0 ground-zero baseline.
- Canonical first-install terminal UX restored from the proven 3.1.12 installer.
- Detailed package/build output is written only to the full install log.
- Fixed stale release-build identifiers in health check and post-reboot verification.
- Release markers are written atomically and verified before health acceptance.
- Retains pinned MediaMTX, pinned MAVLink Router, transaction snapshot and rollback.

- V7 fixes interrupted-install marker recovery and explicitly restores release markers during rollback.

- V9 fixes Python validation permissions and limits rollback strictly to SIYI-managed services, eliminating cloud-init restart hangs and venv deletion races.

## V10 ZeroTier first-setup corrections

- Uses the documented Legacy Central v1 `Authorization: token` header.
- Requires a managed ZeroTier IP before first setup is marked complete.
- Stores the full ZeroTier setup transcript in `/home/pi/siyi_zerotier_setup.log`.
- Shows only a concise, single-line action status in the System overview.
- Removes literal `\\n` diagnostic spam from the dashboard.
