# SIYI 4.2.0 SIYI_4_2_0_RELEASE_CANDIDATE_V22

This is the corrected 4.2.0 fresh-install release candidate.

Included and statically validated:

- Full current live 4.2.0 application source.
- 20 ms / 50 Hz joystick latest-state WebSocket path with HTTP fallback and reconnect.
- Transparent top-banner pills, strong text shadows, and unclipped GPS text.
- Gimbal-zero correction.
- Android-working browser-native voice V3; failed V5 excluded; Mac voice deferred.
- MapTiler cache directory created with `pi:pi` ownership during fresh installation.
- WiFiLink2 Device save returns to Connectivity → Air Link.
- Generic editable WiFiLink2 hostname with no fixed `.199`/`.217` IP and no packaged password.
- Payload manifest regenerated from the final payload after all changes.
- Fresh-install-only 4.2.0 architecture retained.

The candidate still requires fresh-SD and physical hardware acceptance before final stable publication.

- Fixed WiFiLink2 Device-page URL-only save: numeric latency 0 is rendered as
  `0`, not an empty field, so changing only the RTSP URL no longer fails backend
  validation. The field is required and still accepts 0–5000 ms.

- Fixed the shared HTML escaping defect that rendered numeric `0` as blank.
  This covers the dedicated Air Link page and the Video-page SIYI, WiFiLink2,
  and UDP latency fields, plus other numeric settings such as Wi-Fi priority.
- Fixed fresh-install route enforcement: an empty transaction directory created
  by the current or a rejected run is not interrupted-install evidence.
- Fixed rollback safety: route rejection, an already-installed check, an early
  sudo failure, or a platform check cannot stop or disable a live SIYI system
  before its service state has been captured.
- ZeroTier managed-IP acceptance is now tied to the configured Network ID.
  An address from another joined ZeroTier network cannot complete First Setup.
- The setup-incomplete warning remains visible until setup has actually passed.

- First Setup now requires a JSON `complete: true` marker, Legacy Central
  `config.authorized=true` for the exact local node, and a managed IP on the
  exact configured network.
- Removed the packaged false `setup_complete.json`; the marker is created only
  after verified setup and is invalidated whenever ZeroTier configuration changes.
- Repair and interrupted recovery preserve the saved ZeroTier API token.
- Corrected the final runtime WiFiLink2 redirect override.
- Moved the phone-landscape Parameters wrapper before the blocking HTTP-server
  startup so the redesign is active.
