# SIYI 4.2.0 SIYI_4_2_0_BASELINE_V3

Release candidate for the new ground-zero 4.2.x line.

- Fresh installation on a freshly flashed supported Raspberry Pi OS only.
- No legacy upgrade route from 3.x, 4.0.x or 4.1.x.
- Complete current 4.1.1-equivalent application payload.
- MediaMTX is downloaded as pinned v1.12.2 and verified twice; its 42 MB binary is not embedded.
- MAVLink Router is built from the captured pinned commit and submodule revision.
- Existing 50 Hz WebSocket stick transport is retained.
- Browser-side explicit tap/hold events with press_id deduplication and fail-safe cancellation are included.
- The unused flight-mode UI/voice latency patch is excluded.
- The verified Pi Wi-Fi Connect action is included.
- First setup asks only for ZeroTier Network ID, ZeroTier API token, one host endpoint, and optional additional Pi Wi-Fi.

This build is not stable until the physical fresh-SD acceptance checklist passes.
