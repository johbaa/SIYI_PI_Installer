# SIYI 4.2.0 SIYI_4_2_0_RELEASE_CANDIDATE_V18

This is the corrected 4.2.0 fresh-install release candidate.

Included and statically validated:

- Full current live 4.2.0 application source.
- 20 ms / 50 Hz joystick latest-state WebSocket path with HTTP fallback and reconnect.
- Transparent top-banner pills, strong text shadows, and unclipped GPS text.
- Gimbal-zero correction.
- Android-working browser-native voice V3; failed V5 excluded; Mac voice deferred.
- MapTiler cache directory created with `pi:pi` ownership during fresh installation.
- WiFiLink2 Device save returns to Connectivity → Air Link.
- Generic editable WiFiLink2 hostname with no fixed `.199`/`.217` IP and no packaged password.
- Payload manifest regenerated from the final payload after all changes.
- Fresh-install-only 4.2.0 architecture retained.

The candidate still requires fresh-SD and physical hardware acceptance before final stable publication.
