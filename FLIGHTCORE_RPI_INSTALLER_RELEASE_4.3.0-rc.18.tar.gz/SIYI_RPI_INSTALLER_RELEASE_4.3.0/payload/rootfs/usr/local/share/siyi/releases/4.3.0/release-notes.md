# FlightCore 4.3.0 RC18

Canonical machine identity: `4.3.0-rc.18`. Factory model: `FLIGHTCORE_4_3_0_COMPLETE_TARGET_MODEL_V80`.

RC18 is derived from exact accepted RC17 build `20260817.222550-31184ef`. Its native upgrade matrix is frozen to the two identities shown in the product-owner supplied Registry snapshot: RC6/Factory V71 and accepted RC17. Fresh installation remains mandatory.

## Flight Logs

- Large completed logs upload automatically as verified 500-sample chunks and a manifest; smaller and existing legacy objects remain readable.
- The local Flight Logs tab is a native link and remains reachable if tab JavaScript fails.
- The local viewer progressively limits canvas width instead of trying to allocate an unbounded chart.
- FlightCore release and build appear beside the viewer-local flight timestamp.
- Each chart derives its vertical range from the samples visible in the chart viewport. Small changes therefore use the available chart height, while genuinely wide ranges remain fully visible.
- UTC remains canonical for stored, API and exported timestamps. Browser-facing flight times use the viewer timezone.

## TURN HOME

Forecast state is committed in memory before the optional runtime diagnostic snapshot is written. A permission or filesystem failure in that best-effort diagnostic can no longer silently force TURN HOME to measured-wind-only behavior. The shared runtime directory is created before Ground Station startup with the required group write access.

## SIYI video

SIYI recovery serializes close and start on one WHEP player object. It no longer creates overlapping decoder/player objects during reconnect. H.265 1080p25, the existing single-ingest MediaMTX route, Air Link management, controls and flight-controller failsafe behavior are unchanged.

## Acceptance status

The factory package contains deterministic automated evidence. Physical RC6 upgrade, RC17 upgrade, fresh-install, Android repeated recorder/reconnect testing, two-hour decoder soak, cloud upload and flight acceptance remain external gates and must not be inferred from the factory result.
