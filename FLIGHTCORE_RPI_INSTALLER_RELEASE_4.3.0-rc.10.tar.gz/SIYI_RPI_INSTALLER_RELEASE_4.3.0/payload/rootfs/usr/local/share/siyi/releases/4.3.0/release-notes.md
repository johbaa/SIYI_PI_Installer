# FlightCore 4.3.0 RC10

Canonical machine identity: `4.3.0-rc.10`.

RC10 retains the complete RC9 feature scope and corrects the native WebUI publication, target-alias, canonical-version and post-acceptance release-tree contracts. All advisory features retain no flight-control authority.
