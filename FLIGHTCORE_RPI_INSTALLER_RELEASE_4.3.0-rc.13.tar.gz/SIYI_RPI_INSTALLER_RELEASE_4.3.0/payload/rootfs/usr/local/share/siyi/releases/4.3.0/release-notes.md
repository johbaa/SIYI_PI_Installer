# FlightCore 4.3.0 RC13

Canonical machine identity: `4.3.0-rc.13`.

RC13 corrects the release-blocking defects exposed by genuine RC12 fresh-install and First Setup testing:

- ZeroTier fresh-install dependency preparation uses signed HTTPS, bounded APT retries, candidate verification, targeted cache recovery, and preserved failure evidence before FlightCore deployment.
- Device Registry enrollment carries both the legacy stable eligibility baseline and the exact immutable RC13 identity; normal check-ins report the exact identity and candidate channel.
- First Setup saves valid local ZeroTier, Wi-Fi, and Air Link choices before cloud fleet validation. A later Registry failure keeps those settings, leaves setup incomplete, and reports the actual error for retry.
- Control Center restores the full FlightCore header logo, duplicate RC suffix rendering is removed, and Ground Station outlines every visible logo detail for legibility over light transparent backgrounds.
- Negative TURN HOME values and projected emergency-landing distance from Home are regression protected.
- TURN HOME save/reload persistence is regression-tested; a fresh installation remains deliberately unconfigured until both aircraft-specific landing limits are saved.
- Flight-log samples and CSV export now include active Smooth Voltage cruise-current/resistance settings, TURN HOME configuration and state, measured wind, and forecast-wind summary.
- A sparse `TURN_HOME_FORECAST_SNAPSHOT` event records the complete seven-point forecast route once per refresh; samples reference it by snapshot ID.
- Every registered user setting is now mandatory-preserved during upgrades; the update page no longer permits deselecting configuration groups or silently resetting them to release defaults.
- A machine-readable settings registry declares storage, fresh-install default, upgrade behavior, secret classification and migration policy for every configuration domain, and is enforced by RC13 factory tests.
- Schema-aware, idempotent migrations preserve legacy RC12 behavior and write a non-secret migration receipt.
- Fresh installations use safe-off defaults for flaps, Smooth Voltage, TURN HOME, LTE Health and Air Link. Air Link ships without an assumed address, username or password.
- Browser preferences are scoped to the permanent Unit ID, while flap position, gimbal state and Air Link stream epoch are treated as runtime state under `/run/flightcore` rather than persistent configuration.
- Release Notes, User Manual, and Installation Guide are revised for RC13.

Smooth Voltage logic, existing LTE logging scope, and flight-control authority are unchanged. TURN HOME remains advisory only.
