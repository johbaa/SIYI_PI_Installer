#!/usr/bin/env bash
set -Eeuo pipefail
REQUIRE_FC=0
FC_ONLY=0
PRE_REBOOT=0
JSON_OUT=""
ALLOW_RELEASE=""
while [ "$#" -gt 0 ]; do
  case "$1" in
    --require-fc) REQUIRE_FC=1; shift ;;
    --fc-only) FC_ONLY=1; REQUIRE_FC=1; shift ;;
    --pre-reboot) PRE_REBOOT=1; shift ;;
    --json-output) JSON_OUT="${2:-}"; shift 2 ;;
    --allow-release) ALLOW_RELEASE="${2:-}"; shift 2 ;;
    *) echo "Unknown health option: $1" >&2; exit 2 ;;
  esac
done
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
META="$SCRIPT_DIR/release-metadata.json"
[ -f "$META" ] || META=/usr/local/share/siyi/releases/4.3.0/release-metadata.json
[ -f "$META" ] || { echo "HEALTH CHECK FAILED: release_metadata_missing" >&2; exit 1; }
readarray -t EXPECTED < <(python3 - "$META" <<'PYMETA'
import json,sys
m=json.load(open(sys.argv[1],encoding='utf-8'))
# FLIGHTCORE_4_3_0_RC12_CANONICAL_HEALTH_IDENTITY_V1
print(str(m.get('release_identity') or m['version']).strip())
print(str(m['build_id']).strip())
PYMETA
)
EXPECTED_VERSION="${EXPECTED[0]}"
EXPECTED_BUILD="${EXPECTED[1]}"
failures=()
notices=()
port_listening(){ ss -lntupH 2>/dev/null | awk '{print $5}' | grep -Eq "(^|:)$1$"; }
url_ok(){ curl -fsS -L --max-time 8 "$1" >/dev/null; }
service_ok(){ systemctl is-active --quiet "$1"; }
read_marker(){ local p="$1"; [ -r "$p" ] || return 1; tr -d '[:space:]' <"$p"; }
fc_probe(){
  /home/pi/siyi-bridge-venv/bin/python - <<'PYFC'
import json,time
from pymavlink import mavutil
result={'genuine_heartbeats':0,'sources':[],'messages':0,'error':None}
try:
    c=mavutil.mavlink_connection('tcp:127.0.0.1:5760',source_system=253,source_component=191,autoreconnect=False)
    end=time.time()+10; sources=set()
    while time.time()<end:
        m=c.recv_match(blocking=True,timeout=0.5)
        if m is None: continue
        result['messages']+=1
        if m.get_type()!='HEARTBEAT': continue
        sysid=int(m.get_srcSystem() or 0); compid=int(m.get_srcComponent() or 0)
        mtype=int(getattr(m,'type',-1)); autopilot=int(getattr(m,'autopilot',-1))
        if sysid>0 and mtype!=int(mavutil.mavlink.MAV_TYPE_GCS) and autopilot!=int(mavutil.mavlink.MAV_AUTOPILOT_INVALID):
            result['genuine_heartbeats']+=1; sources.add(f'{sysid}:{compid}')
    result['sources']=sorted(sources)
except Exception as exc: result['error']=str(exc)
print(json.dumps(result,sort_keys=True))
raise SystemExit(0 if result['genuine_heartbeats']>=2 and result['messages']>=3 else 1)
PYFC
}
if [ "$FC_ONLY" -eq 0 ]; then
  actual_version="$(read_marker /etc/siyi/release_version 2>/dev/null || true)"
  actual_build="$(read_marker /etc/siyi/release_build 2>/dev/null || true)"
  [ "$actual_version" = "$EXPECTED_VERSION" ] || failures+=("release_version")
  [ "$actual_build" = "$EXPECTED_BUILD" ] || failures+=("release_build")
  manifest="$SCRIPT_DIR/payload-manifest.json"; [ -f "$manifest" ] || manifest=/usr/local/share/siyi/releases/4.3.0/payload-manifest.json
  if [ -f "$manifest" ]; then
    fp_args=(--verify); [ -z "$ALLOW_RELEASE" ] || fp_args+=(--allow-release "$ALLOW_RELEASE")
    /usr/local/sbin/siyi-release-fingerprint "${fp_args[@]}" >/dev/null 2>&1 || failures+=("immutable_payload_or_release_metadata")
  else failures+=("payload_manifest_missing"); fi
  [ -d /var/cache/siyi-maptiler ] || failures+=("maptiler_cache_missing")
  for runtime_dir in /var/lib/siyi-param-import /var/lib/siyi-param-import/sessions /var/backups/siyi-param-import; do
    [ -d "$runtime_dir" ] || { failures+=("runtime_dir_missing:$runtime_dir"); continue; }
    [ "$(stat -c '%U:%G:%a' "$runtime_dir" 2>/dev/null || true)" = "pi:pi:775" ] || failures+=("runtime_dir_permissions:$runtime_dir")
    sudo -u pi test -w "$runtime_dir" || failures+=("runtime_dir_not_writable:$runtime_dir")
  done
  if [ -d /var/cache/siyi-maptiler ]; then
    [ "$(stat -c '%U:%G:%a' /var/cache/siyi-maptiler 2>/dev/null || true)" = "pi:pi:755" ] || failures+=("maptiler_cache_permissions")
    sudo -u pi test -w /var/cache/siyi-maptiler || failures+=("maptiler_cache_not_writable")
  fi
  command -v mediamtx >/dev/null || failures+=("mediamtx_missing")
  command -v mavlink-routerd >/dev/null || failures+=("mavlink_router_missing")
  if command -v mediamtx >/dev/null; then mediamtx --version 2>&1 | grep -Fq 'v1.12.2' || failures+=("mediamtx_version"); fi
  if command -v mavlink-routerd >/dev/null; then mavlink-routerd --version 2>&1 | grep -Fq 'v4-16-g2362c62' || failures+=("mavlink_router_version"); fi
  cmdline=""; for p in /boot/firmware/cmdline.txt /boot/cmdline.txt; do [ ! -f "$p" ] || { cmdline="$p"; break; }; done
  [ -n "$cmdline" ] || failures+=("boot_cmdline_missing")
  if [ -n "$cmdline" ] && grep -Eq '(^| )(console=(serial0|ttyS0|ttyAMA0),[^ ]+)' "$cmdline"; then failures+=("serial_console_conflict"); fi
  if [ "$PRE_REBOOT" -eq 0 ]; then
    [ -e /dev/serial0 ] || failures+=("serial0_missing")
    for unit in NetworkManager.service zerotier-one.service mavlink-router.service mediamtx.service siyi-battery-cache.service siyi-button-bridge.service siyi-groundstation.service siyi-joystickd.service siyi-paramd.service siyi-rec-proxy.service siyi-rec-redirect.service siyi-rtsp-redirect.service siyi-telemetry-canvas.service siyi-video-dual.service siyi-video-source.service siyi-webui.service; do
      service_ok "$unit" || failures+=("service:$unit")
    done
    for port in 5760 8080 8554 9997 18767; do port_listening "$port" || failures+=("port:$port"); done
    url_ok http://127.0.0.1:8080/health || failures+=("url:webui_health")
    url_ok http://127.0.0.1:8080/groundstation || failures+=("url:groundstation")
    url_ok http://127.0.0.1:8080/parameters || failures+=("url:parameters")
    url_ok http://127.0.0.1:9997/v3/paths/list || failures+=("url:mediamtx_api")
    groundstation_html="$(curl -fsS -L --max-time 8 http://127.0.0.1:8080/groundstation 2>/dev/null || true)"
    grep -Fq '/api/groundstation/joystick/ws' <<<"$groundstation_html" || failures+=("groundstation:websocket_endpoint")
    grep -Fq 'JOYSTICK_CONTROL_INTERVAL_MS=20' <<<"$groundstation_html" || failures+=("groundstation:joystick_50hz")
    grep -Fq 'SIYI_4_2_0_WIND_ARROW_UI_V2' <<<"$groundstation_html" || failures+=("groundstation:wind_arrow_v2")
    # SIYI_WEBSOCKET_HANDSHAKE_PROBE_V2
    /home/pi/siyi-bridge-venv/bin/python - <<'PYWS' >/dev/null 2>&1 || failures+=("groundstation:websocket_handshake")
import base64, hashlib, json, os, socket, struct
host='127.0.0.1'; port=8080; path='/api/groundstation/joystick/ws'
key=base64.b64encode(os.urandom(16)).decode('ascii')
request=(f'GET {path} HTTP/1.1\r\nHost: {host}:{port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n').encode('ascii')

def read_exact(sock,n):
    out=b''
    while len(out)<n:
        chunk=sock.recv(n-len(out))
        if not chunk: raise RuntimeError('websocket closed during probe')
        out+=chunk
    return out

sock=socket.create_connection((host,port),timeout=5)
sock.settimeout(5)
try:
    sock.sendall(request)
    raw=b''
    while b'\r\n\r\n' not in raw:
        chunk=sock.recv(1024)
        if not chunk: raise RuntimeError('websocket handshake closed')
        raw+=chunk
        if len(raw)>16384: raise RuntimeError('websocket handshake too large')
    head,extra=raw.split(b'\r\n\r\n',1)
    lines=head.decode('iso-8859-1').split('\r\n')
    if len(lines)<1 or ' 101 ' not in (' '+lines[0]+' '): raise RuntimeError('websocket status is not 101')
    headers={}
    for line in lines[1:]:
        if ':' in line:
            k,v=line.split(':',1); headers[k.strip().lower()]=v.strip()
    expected=base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode('ascii')).digest()).decode('ascii')
    if headers.get('sec-websocket-accept')!=expected: raise RuntimeError('invalid Sec-WebSocket-Accept')
    if headers.get('upgrade','').lower()!='websocket': raise RuntimeError('missing Upgrade websocket')
    if 'upgrade' not in [x.strip().lower() for x in headers.get('connection','').split(',')]: raise RuntimeError('missing Connection upgrade')
    buf=bytearray(extra)
    def take(n):
        while len(buf)<n: buf.extend(read_exact(sock,n-len(buf)))
        out=bytes(buf[:n]); del buf[:n]; return out
    first,second=take(2)
    if not (first&0x80) or (first&0x0f)!=1: raise RuntimeError('ready frame is not final text')
    if second&0x80: raise RuntimeError('server frame is masked')
    length=second&0x7f
    if length==126: length=struct.unpack('!H',take(2))[0]
    elif length==127: length=struct.unpack('!Q',take(8))[0]
    if length>8192: raise RuntimeError('ready frame too large')
    ready=json.loads(take(length).decode('utf-8'))
    if ready.get('ok') is not True or ready.get('ready') is not True or ready.get('transport')!='websocket-v2': raise RuntimeError('invalid ready frame')
    close_payload=struct.pack('!H',1000); mask=os.urandom(4)
    masked=bytes(b^mask[i&3] for i,b in enumerate(close_payload))
    sock.sendall(bytes((0x88,0x80|len(close_payload)))+mask+masked)
finally:
    try: sock.shutdown(socket.SHUT_RDWR)
    except OSError: pass
    sock.close()
PYWS
    stable_services=(siyi-webui.service siyi-button-bridge.service siyi-paramd.service mavlink-router.service mediamtx.service siyi-rtsp-redirect.service zerotier-one.service)
    declare -A restart_before
    for svc in "${stable_services[@]}"; do
      restart_before["$svc"]="$(systemctl show "$svc" -p NRestarts --value 2>/dev/null || echo missing)"
    done
    sleep 6
    for svc in "${stable_services[@]}"; do
      service_ok "$svc" || failures+=("service_stability:$svc")
      [ "${restart_before[$svc]}" = "$(systemctl show "$svc" -p NRestarts --value 2>/dev/null || echo changed)" ] || failures+=("service_restart_counter:$svc")
    done
  fi
fi
fc_json=""
if [ "$PRE_REBOOT" -eq 0 ]; then
  set +e; fc_json="$(fc_probe 2>/dev/null)"; fc_rc=$?; set -e
  if [ "$fc_rc" -ne 0 ]; then
    if [ "$REQUIRE_FC" -eq 1 ]; then failures+=("genuine_fc_heartbeat"); else notices+=("genuine_fc_heartbeat_not_verified"); fi
  fi
fi
if [ -n "$JSON_OUT" ]; then
  python3 - "$JSON_OUT" "${failures[*]}" "${notices[*]}" "$fc_json" <<'PYJSON'
import datetime,json,os,sys,tempfile
path,failures,notices,fc=sys.argv[1:]
data={'captured_at':datetime.datetime.now().astimezone().isoformat(timespec='seconds'),'ok':not bool(failures.strip()),'failures':failures.split() if failures.strip() else [],'notices':notices.split() if notices.strip() else []}
try: data['fc_probe']=json.loads(fc) if fc else None
except Exception: data['fc_probe']={'raw':fc}
os.makedirs(os.path.dirname(path),exist_ok=True)
fd,tmp=tempfile.mkstemp(prefix='.health.',dir=os.path.dirname(path))
with os.fdopen(fd,'w',encoding='utf-8') as f: json.dump(data,f,indent=2); f.write('\n')
os.chmod(tmp,0o644); os.replace(tmp,path)
PYJSON
fi
if [ "${#notices[@]}" -gt 0 ]; then printf 'NOTICE: %s\n' "${notices[@]}"; fi
if [ "${#failures[@]}" -gt 0 ]; then printf 'HEALTH CHECK FAILED: %s\n' "${failures[*]}" >&2; exit 1; fi
echo "HEALTH CHECK PASSED"
