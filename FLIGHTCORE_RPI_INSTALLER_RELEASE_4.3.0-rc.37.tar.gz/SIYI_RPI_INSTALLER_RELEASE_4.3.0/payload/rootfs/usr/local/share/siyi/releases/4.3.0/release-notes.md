# FlightCore 4.3.0 RC37

Canonical machine identity: `4.3.0-rc.37`. Build: `20260822.132718-085b92b`.

RC37 changes only Ground Station display-unit rendering. It removes the RC26 runtime renderer wrappers that performed a second conversion and DOM pass for every telemetry update.

## Changes

- Keeps all telemetry storage, calculations and transport values in canonical SI units.
- Preserves the existing unit-global preferences and Settings UI across upgrade.
- Loads the selected unit profile into one immutable browser-side cache.
- Integrates speed, wind, distance, altitude and vertical-speed conversion into the original HUD and telemetry-tile render pass.
- Updates unit labels only when the selected unit profile changes.
- Performs one scheduled visual refresh after an operator changes units.
- Removes the RC26 runtime wrapping of `updateHud`, `updateWindArrow`, `telemetryTileState` and `telemetryUpdateWindIndicatorTile`.
- Adds no polling, no additional telemetry requests and no second per-sample DOM traversal.

## Preserved behavior

- RC36 dual-stream, Air Link recovery, SIYI recovery, MediaMTX and ZeroTier behavior are unchanged.
- No flight-control, MAVLink, joystick, autopilot or logging behavior changes.
- Fresh installation and all existing checksum-pinned historical upgrade routes remain supported.
- Exact accepted RC36 is the controlled upgrade parent for RC37.

## Validation status

- Python and shell syntax: passed.
- Ground Station generation and required integration markers: passed.
- JavaScript syntax and unit-conversion assertions: passed.
- Payload manifest, archive checksum and clean RC36-to-RC37 delta: passed.
- Physical Android flight acceptance: pending.
