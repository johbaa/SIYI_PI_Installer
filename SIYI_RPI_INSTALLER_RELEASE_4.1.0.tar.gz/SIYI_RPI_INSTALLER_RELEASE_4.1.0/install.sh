#!/usr/bin/env bash
set -Eeuo pipefail
VERSION="4.1.0"
TRANSACTION_FIX="SIYI_4_1_0_TRANSACTION_MANIFEST_FIX_V2"
RELEASE_DIR="$(cd "$(dirname "$0")" && pwd)"
TX="$RELEASE_DIR/tools/transaction.py"
CANON="$RELEASE_DIR/tools/canonicalize_layout.py"
SETTINGS_JSON="$RELEASE_DIR/settings_paths.json"
PROGRESS_FILE="${SIYI_UPGRADE_PROGRESS_FILE:-}"
WEBUI_UPGRADE="${SIYI_WEBUI_UPGRADE:-0}"
STAMP="$(date +%Y%m%d_%H%M%S)"
BACKUP="/var/backups/siyi/release_4_1_0_${STAMP}"
LOG="$BACKUP/install.log"
SNAPSHOT_READY=0
ACCEPTED=0
ROLLING_BACK=0
PREVIOUS_VERSION="$(cat /etc/siyi/release_version 2>/dev/null || printf unknown)"
PROGRAM_PATHS_JSON="$BACKUP/program_paths.json"
progress(){ local p="$1" s="$2"; if [[ -n "$PROGRESS_FILE" ]]; then printf '%s\t%s\n' "$p" "$s" > "$PROGRESS_FILE"; fi; printf '[4.1.0] %s%% %s\n' "$p" "$s"; }
run_root(){ if [[ "$EUID" -eq 0 ]]; then "$@"; else sudo "$@"; fi; }
manual_services(){ printf '%s\n' siyi-groundstation.service siyi-button-bridge.service siyi-webui.service; }
SETTINGS_WRITER_WAS_ACTIVE=0
quiesce_settings_writer(){
  if systemctl is-active --quiet siyi-button-bridge.service; then
    SETTINGS_WRITER_WAS_ACTIVE=1
    run_root systemctl stop siyi-button-bridge.service
  fi
}
resume_settings_writer(){
  if [[ "$SETTINGS_WRITER_WAS_ACTIVE" == 1 ]]; then
    run_root systemctl restart siyi-button-bridge.service
    SETTINGS_WRITER_WAS_ACTIVE=0
  fi
}
stop_manual(){ while read -r s; do run_root systemctl stop "$s" 2>/dev/null || true; done < <(manual_services); }
start_manual(){ run_root systemctl daemon-reload; while read -r s; do run_root systemctl restart "$s"; done < <(manual_services); }
wait_url(){ local url="$1" out="$2"; rm -f "$out"; for _ in $(seq 1 80); do curl -fsS --max-time 4 "$url" -o "$out" && [[ -s "$out" ]] && return 0; sleep .5; done; return 1; }
rollback(){ local rc="$1" reason="$2"; [[ "$ROLLING_BACK" == 0 ]] || exit "$rc"; ROLLING_BACK=1; trap - ERR EXIT INT TERM; set +e; echo "4.1.0 installation failed: $reason"; if [[ "$WEBUI_UPGRADE" != 1 ]]; then stop_manual; fi; if [[ "$SNAPSHOT_READY" == 1 ]]; then run_root python3 "$TX" restore "$BACKUP" program; run_root python3 "$TX" restore "$BACKUP" settings; run_root python3 "$TX" verify "$BACKUP" program; run_root python3 "$TX" verify "$BACKUP" settings; fi; if [[ "$WEBUI_UPGRADE" != 1 ]]; then start_manual; else resume_settings_writer; fi; printf 'accepted=false\nreason=%s\n' "$reason" | run_root tee "$BACKUP/result.txt" >/dev/null; echo "Rollback completed. Backup: $BACKUP"; exit "$rc"; }
on_err(){ local rc=$?; rollback "$rc" "command failed at line $1: $2"; }
trap 'on_err "$LINENO" "$BASH_COMMAND"' ERR
trap '[[ "$ACCEPTED" == 1 ]] || rollback 1 "installer exited before acceptance"' EXIT INT TERM
for c in python3 sha256sum curl systemctl install tar; do command -v "$c" >/dev/null; done
run_root install -d -o root -g root -m 0700 "$BACKUP"
exec > >(tee -a "$LOG") 2>&1
progress 2 "Validating authoritative live-system payload"
[[ "$PREVIOUS_VERSION" == 4.0.4 || "$PREVIOUS_VERSION" == 4.1.0 ]]
python3 -m py_compile "$RELEASE_DIR/payload/rootfs/home/pi/siyi-webui/server.py" "$RELEASE_DIR/payload/rootfs/home/pi/siyi_mav_button_bridge.py" "$RELEASE_DIR/payload/rootfs/usr/local/lib/siyi/groundstation/groundstation_daemon.py" "$TX" "$CANON"
python3 - "$RELEASE_DIR/payload_manifest.json" "$PROGRAM_PATHS_JSON" <<'PYPROGRAM'
import json,sys
m=json.load(open(sys.argv[1])); json.dump([x['target'] for x in m['files']],open(sys.argv[2],'w'),indent=2)
PYPROGRAM
progress 8 "Snapshotting exact program rollback state"
run_root python3 "$TX" snapshot "$BACKUP" program "$PROGRAM_PATHS_JSON"
run_root python3 "$TX" verify-backup "$BACKUP" program
progress 14 "Quiescing the Ground Station settings writer"
quiesce_settings_writer
progress 16 "Snapshotting all Pi-side Ground Station settings"
run_root python3 "$TX" snapshot "$BACKUP" settings "$SETTINGS_JSON"
run_root python3 "$TX" verify-backup "$BACKUP" settings
SNAPSHOT_READY=1
if wait_url http://127.0.0.1:18765/telemetry/layout "$BACKUP/layout_before.json"; then python3 "$CANON" "$BACKUP/layout_before.json" "$BACKUP/layout_before.canonical.json"; fi
if [[ "$WEBUI_UPGRADE" != 1 ]]; then progress 24 "Stopping changed Ground Station services"; stop_manual; fi
progress 38 "Installing exact validated 4.0.4 live program as release 4.1.0"
run_root python3 "$TX" install-payload "$RELEASE_DIR"
progress 64 "Restoring preserved Ground Station settings"
run_root python3 "$TX" restore "$BACKUP" settings
run_root python3 "$TX" verify "$BACKUP" settings
progress 78 "Verifying installed program files"
run_root python3 "$TX" verify-payload "$RELEASE_DIR"
run_root systemctl daemon-reload
if [[ "$WEBUI_UPGRADE" == 1 ]]; then
  if [[ -s "$BACKUP/layout_before.canonical.json" ]]; then wait_url http://127.0.0.1:18765/telemetry/layout "$BACKUP/layout_after.json"; python3 "$CANON" "$BACKUP/layout_after.json" "$BACKUP/layout_after.canonical.json"; cmp -s "$BACKUP/layout_before.canonical.json" "$BACKUP/layout_after.canonical.json"; fi
  resume_settings_writer
  progress 100 "Core 4.1.0 payload installed; returning control to WebUI updater"
else
  progress 84 "Restarting Ground Station services"; start_manual
  progress 90 "Verifying running 4.1.0 system"
  wait_url http://127.0.0.1:8080/health "$BACKUP/health.json"
  wait_url http://127.0.0.1:8080/api/groundstation/telemetry/layout "$BACKUP/layout_after.json"
  python3 "$CANON" "$BACKUP/layout_after.json" "$BACKUP/layout_after.canonical.json"
  if [[ -s "$BACKUP/layout_before.canonical.json" ]]; then cmp -s "$BACKUP/layout_before.canonical.json" "$BACKUP/layout_after.canonical.json"; fi
  wait_url 'http://127.0.0.1:8080/groundstation?release=4.1.0' "$BACKUP/groundstation.html"
  grep -Fq 'SIYI_RELEASE_4_1_0_AUTHORITATIVE_LIVE_BASELINE' /home/pi/siyi-webui/server.py
  printf '%s\n' "$VERSION" | run_root tee /etc/siyi/release_version >/dev/null
  run_root chown root:root /etc/siyi/release_version; run_root chmod 0644 /etc/siyi/release_version
  progress 100 "4.1.0 installed and verified"
fi
printf 'accepted=true\nprevious_version=%s\nwebui_upgrade=%s\nserver_sha256=89c09bddff2459273043ec8ba755bd382bf004615e8ee0f2a91c0788eb7bce3f\nsettings_verified=true\n' "$PREVIOUS_VERSION" "$WEBUI_UPGRADE" | run_root tee "$BACKUP/result.txt" >/dev/null
ACCEPTED=1
trap - ERR EXIT INT TERM
echo "SIYI RPI INSTALLER 4.1.0 CORE INSTALLATION VERIFIED"
echo "Preservation backup: $BACKUP"
