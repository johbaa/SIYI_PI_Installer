#!/usr/bin/env bash
set -Eeuo pipefail

# SIYI_GROUNDSTATION_PRESERVATION_LAYER_4_1_0
VERSION="4.1.0"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

SOURCE_SERVER="$SCRIPT_DIR/siyi-webui/server.py"
BRIDGE_PATCHER="$SCRIPT_DIR/tools/patch_button_bridge.py"

LIVE_SERVER="/home/pi/siyi-webui/server.py"
LIVE_BRIDGE="/home/pi/siyi_mav_button_bridge.py"
RELEASE_FILE="/etc/siyi/release_version"

EXPECTED_SERVER_SHA="a47ac8685b7d5f6706e9141107df74eb93342811ef4eadf6a4597580f22047a6"
SERVER_MARKER="GROUND_STATION_TELEMETRY_GROUP_SIZE_V2_8_21_PLATFORM_LOCAL"
BRIDGE_MARKER="GROUND_STATION_BUTTON_ACTION_V2_8_8_TELEMETRY_TOGGLE_BRIDGE"

STAMP="$(date +%Y%m%d_%H%M%S)"
TMP_DIR="/tmp/siyi_upgrade_4_1_0_${STAMP}"
BACKUP_DIR="/var/backups/siyi/upgrade_4_1_0_groundstation_${STAMP}"

SETTINGS_LIST="$TMP_DIR/settings_paths.txt"
PROGRAM_LIST="$TMP_DIR/program_paths.txt"
SETTINGS_ARCHIVE="$BACKUP_DIR/groundstation_settings.tar.gz"
PROGRAM_ARCHIVE="$BACKUP_DIR/groundstation_program_rollback.tar.gz"
SETTINGS_MANIFEST="$BACKUP_DIR/groundstation_settings_manifest.json"
LAYOUT_BEFORE="$BACKUP_DIR/telemetry_layout_before.json"
LAYOUT_AFTER="$BACKUP_DIR/telemetry_layout_after.json"
SEMANTIC_BEFORE="$BACKUP_DIR/telemetry_layout_semantic_before.json"
SEMANTIC_AFTER="$BACKUP_DIR/telemetry_layout_semantic_after.json"
SERVICE_STATES="$BACKUP_DIR/service_states_before.txt"
PROTECTED_PIDS="$BACKUP_DIR/protected_pids_before.txt"
REPORT="$BACKUP_DIR/preservation_verification_report.txt"
VERIFIED_MARKER="$BACKUP_DIR/VERIFIED"

MUTABLE_SERVICES=(
    siyi-webui.service
    siyi-button-bridge.service
)
ALL_CHECKED_SERVICES=(
    siyi-webui.service
    siyi-button-bridge.service
    siyi-groundstation.service
    mavlink-router.service
    mediamtx.service
    siyi-video-source.service
    zerotier-one.service
)
PROTECTED_SERVICES=(
    siyi-groundstation.service
    mavlink-router.service
    mediamtx.service
    siyi-video-source.service
    zerotier-one.service
)

SNAPSHOT_READY=0
UPGRADE_ACCEPTED=0
ROLLBACK_RUNNING=0
SUDO_KEEPALIVE_PID=""

say() {
    printf '%s\n' "$*"
}

need() {
    command -v "$1" >/dev/null 2>&1 || {
        say "ERROR: required command not found: $1"
        exit 1
    }
}

run_root() {
    if [[ "$EUID" -eq 0 ]]; then
        "$@"
    else
        sudo "$@"
    fi
}

start_sudo() {
    if [[ "$EUID" -ne 0 ]]; then
        sudo -v
        (
            while true; do
                sudo -n true >/dev/null 2>&1 || exit 0
                sleep 45
            done
        ) &
        SUDO_KEEPALIVE_PID="$!"
    fi
}

stop_sudo() {
    if [[ -n "$SUDO_KEEPALIVE_PID" ]]; then
        kill "$SUDO_KEEPALIVE_PID" >/dev/null 2>&1 || true
        wait "$SUDO_KEEPALIVE_PID" >/dev/null 2>&1 || true
    fi
}

pid_of() {
    systemctl show -p MainPID --value "$1" 2>/dev/null || printf '0\n'
}

service_was_active() {
    grep -Fqx "active $1" "$SERVICE_STATES" 2>/dev/null
}

capture_service_states() {
    : > "$TMP_DIR/service_states.txt"
    local service state
    for service in "${ALL_CHECKED_SERVICES[@]}"; do
        if systemctl is-active --quiet "$service"; then
            state=active
        else
            state=inactive
        fi
        printf '%s %s\n' "$state" "$service"             >> "$TMP_DIR/service_states.txt"
    done
    run_root install -o root -g root -m 0600         "$TMP_DIR/service_states.txt" "$SERVICE_STATES"

    : > "$TMP_DIR/protected_pids.txt"
    for service in "${PROTECTED_SERVICES[@]}"; do
        printf '%s %s\n' "$(pid_of "$service")" "$service"             >> "$TMP_DIR/protected_pids.txt"
    done
    run_root install -o root -g root -m 0600         "$TMP_DIR/protected_pids.txt" "$PROTECTED_PIDS"
}

stop_mutable_services() {
    local service
    for service in "${MUTABLE_SERVICES[@]}"; do
        run_root systemctl stop "$service" >/dev/null 2>&1 || true
    done
}

restore_mutable_service_states() {
    run_root systemctl daemon-reload
    local service
    for service in "${MUTABLE_SERVICES[@]}"; do
        if service_was_active "$service"; then
            run_root systemctl restart "$service"
        else
            run_root systemctl stop "$service" >/dev/null 2>&1 || true
        fi
    done
}

wait_for_api() {
    local output="$1"
    rm -f "$output"
    local attempt
    for attempt in $(seq 1 80); do
        if curl -fsS --max-time 4             http://127.0.0.1:8080/api/groundstation/telemetry/layout             -o "$output"; then
            [[ -s "$output" ]] && return 0
        fi
        sleep 0.5
    done
    return 1
}

write_semantic_layout() {
    local source_json="$1"
    local destination_json="$2"
    python3 - "$source_json" "$destination_json" <<'PY_SEMANTIC'
from pathlib import Path
import base64
import json
import sys

source=Path(sys.argv[1])
destination=Path(sys.argv[2])
payload=json.loads(source.read_text(encoding="utf-8"))
assert payload.get("ok") is True
config=payload.get("config")
assert isinstance(config,dict)

GROUP_PREFIX="raw.__tc_group__.v2."
OVERLAY_PREFIX="raw.__gs_overlay__.v1."

def decode_group(token):
    encoded=token[len(GROUP_PREFIX):]
    encoded += "="*((4-len(encoded)%4)%4)
    group=json.loads(base64.urlsafe_b64decode(encoded.encode()).decode())
    return {
        "id":group.get("i"),
        "name":group.get("n"),
        "show_labels":group.get("l"),
        "show_units":group.get("u"),
        "baseline_columns":group.get("bc",group.get("c")),
        "baseline_font_size":group.get("bf",group.get("f")),
    }

selected=[]
for item in config.get("selected_fields") or []:
    text=str(item)
    if text.startswith(OVERLAY_PREFIX):
        continue
    if text.startswith(GROUP_PREFIX):
        selected.append({"group":decode_group(text)})
    else:
        selected.append(text)

layout=config.get("layout") or {}
semantic={
    "schema_version":config.get("schema_version"),
    "visible":bool(config.get("visible",True)),
    "layout":{
        "columns":layout.get("columns"),
        "rows":layout.get("rows"),
        "flow":layout.get("flow"),
        "font_size":layout.get("font_size"),
        "show_labels":layout.get("show_labels"),
        "show_units":layout.get("show_units"),
    },
    "selected_fields":selected,
}
destination.write_text(
    json.dumps(semantic,sort_keys=True,indent=2)+"\n",
    encoding="utf-8",
)
PY_SEMANTIC
}

relative_existing_path() {
    local path="$1"
    if [[ -e "$path" || -L "$path" ]]; then
        printf '%s\n' "${path#/}"
    fi
}

build_settings_list() {
    : > "$SETTINGS_LIST"

    {
        relative_existing_path /etc/siyi
        relative_existing_path /var/lib/siyi
        relative_existing_path /var/lib/siyi-groundstation
        relative_existing_path /var/lib/siyi-upgrade
        relative_existing_path /home/pi/siyi-config.json
        relative_existing_path /home/pi/siyi_gimbal_state.json
        relative_existing_path /home/pi/siyi-webui/wifi_passwords.json
        relative_existing_path /home/pi/.siyi
    } >> "$SETTINGS_LIST"

    local path
    shopt -s nullglob
    for path in         /etc/default/siyi*         /etc/siyi-groundstation*         /etc/systemd/system/siyi-*.service.d         /home/pi/.config/siyi*         /home/pi/.local/share/siyi*
    do
        relative_existing_path "$path" >> "$SETTINGS_LIST"
    done
    shopt -u nullglob

    LC_ALL=C sort -u "$SETTINGS_LIST" -o "$SETTINGS_LIST"
    [[ -s "$SETTINGS_LIST" ]] || {
        say "ERROR: no Pi-side SIYI settings were found"
        exit 1
    }
}

build_program_list() {
    : > "$PROGRAM_LIST"
    {
        relative_existing_path "$LIVE_SERVER"
        relative_existing_path "$LIVE_BRIDGE"
        relative_existing_path "$RELEASE_FILE"
    } >> "$PROGRAM_LIST"
    LC_ALL=C sort -u "$PROGRAM_LIST" -o "$PROGRAM_LIST"
}

tar_feature_args() {
    local option
    for option in --acls --xattrs --selinux; do
        if tar --help 2>/dev/null | grep -q -- "$option"; then
            printf '%s\n' "$option"
        fi
    done
}

create_archive() {
    local list_file="$1"
    local archive="$2"
    local exclude_release="${3:-false}"
    local features=()
    while IFS= read -r option; do
        features+=("$option")
    done < <(tar_feature_args)

    local exclusions=()
    if [[ "$exclude_release" == true ]]; then
        exclusions+=(--exclude='etc/siyi/release_version')
    fi

    run_root tar         "${features[@]}"         --numeric-owner         "${exclusions[@]}"         -C / -czpf "$archive"         -T "$list_file"
}

restore_archive() {
    local archive="$1"
    [[ -s "$archive" ]] || return 0

    local features=()
    while IFS= read -r option; do
        features+=("$option")
    done < <(tar_feature_args)

    run_root tar         "${features[@]}"         --numeric-owner         -C / -xzpf "$archive"
}

create_settings_manifest() {
    run_root python3 - "$SETTINGS_LIST" "$SETTINGS_MANIFEST" <<'PY_MANIFEST'
from pathlib import Path
import hashlib
import json
import os
import stat
import sys

path_list=Path(sys.argv[1])
destination=Path(sys.argv[2])
excluded={"etc/siyi/release_version"}
records={}
seen=set()

def add(relative):
    relative=relative.strip("/")
    if not relative or relative in seen or relative in excluded:
        return
    seen.add(relative)
    absolute=Path("/"+relative)
    try:
        info=os.lstat(absolute)
    except FileNotFoundError:
        return

    record={
        "path":relative,
        "mode":stat.S_IMODE(info.st_mode),
        "uid":info.st_uid,
        "gid":info.st_gid,
    }

    if stat.S_ISLNK(info.st_mode):
        record["type"]="symlink"
        record["target"]=os.readlink(absolute)
    elif stat.S_ISREG(info.st_mode):
        record["type"]="file"
        digest=hashlib.sha256()
        with absolute.open("rb") as handle:
            for chunk in iter(lambda:handle.read(1024*1024),b""):
                digest.update(chunk)
        record["sha256"]=digest.hexdigest()
        record["size"]=info.st_size
    elif stat.S_ISDIR(info.st_mode):
        record["type"]="directory"
    else:
        record["type"]="other"

    records[relative]=record

    if stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode):
        try:
            entries=sorted(os.scandir(absolute),key=lambda item:item.name)
        except PermissionError:
            entries=[]
        for entry in entries:
            add(relative+"/"+entry.name)

for line in path_list.read_text(encoding="utf-8").splitlines():
    add(line)

destination.parent.mkdir(parents=True,exist_ok=True)
destination.write_text(
    json.dumps(
        {
            "schema":1,
            "excluded":sorted(excluded),
            "records":[records[key] for key in sorted(records)],
        },
        indent=2,
        sort_keys=True,
    )+"\n",
    encoding="utf-8",
)
PY_MANIFEST
}

verify_settings_manifest() {
    run_root python3 - "$SETTINGS_MANIFEST" <<'PY_VERIFY'
from pathlib import Path
import hashlib
import json
import os
import stat
import sys

manifest=json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
errors=[]

for expected in manifest.get("records") or []:
    relative=expected["path"]
    absolute=Path("/"+relative)
    try:
        info=os.lstat(absolute)
    except FileNotFoundError:
        errors.append(relative+": missing")
        continue

    if stat.S_IMODE(info.st_mode)!=expected["mode"]:
        errors.append(relative+": permissions changed")
    if info.st_uid!=expected["uid"]:
        errors.append(relative+": owner changed")
    if info.st_gid!=expected["gid"]:
        errors.append(relative+": group changed")

    kind=expected["type"]
    if kind=="symlink":
        if not stat.S_ISLNK(info.st_mode):
            errors.append(relative+": no longer a symlink")
        elif os.readlink(absolute)!=expected["target"]:
            errors.append(relative+": symlink target changed")
    elif kind=="file":
        if not stat.S_ISREG(info.st_mode):
            errors.append(relative+": no longer a regular file")
            continue
        digest=hashlib.sha256()
        with absolute.open("rb") as handle:
            for chunk in iter(lambda:handle.read(1024*1024),b""):
                digest.update(chunk)
        if digest.hexdigest()!=expected["sha256"]:
            errors.append(relative+": SHA256 changed")
    elif kind=="directory" and not stat.S_ISDIR(info.st_mode):
        errors.append(relative+": no longer a directory")

if errors:
    print("GROUND STATION SETTINGS VERIFICATION FAILED")
    for error in errors:
        print(" -",error)
    raise SystemExit(1)

print(
    "Ground Station settings manifest verified:",
    len(manifest.get("records") or []),
    "paths",
)
PY_VERIFY
}

restore_release_version() {
    if [[ -s "$BACKUP_DIR/release_version_before.txt" ]]; then
        local previous
        previous="$(run_root cat "$BACKUP_DIR/release_version_before.txt")"
        printf '%s\n' "$previous" > "$TMP_DIR/release_version.restore"
        run_root install -o root -g root -m 0644             "$TMP_DIR/release_version.restore" "$RELEASE_FILE"
    fi
}

write_release_version() {
    printf '%s\n' "$VERSION" > "$TMP_DIR/release_version.new"
    run_root install -d -o root -g root -m 0755 /etc/siyi
    run_root install -o root -g root -m 0644         "$TMP_DIR/release_version.new" "$RELEASE_FILE"
}

verify_protected_pids() {
    local before service current
    while read -r before service; do
        [[ -n "$service" ]] || continue
        current="$(pid_of "$service")"
        if [[ "$current" != "$before" ]]; then
            say "ERROR: protected service restarted: $service"
            say "Before PID: $before"
            say "After PID:  $current"
            return 1
        fi
    done < "$PROTECTED_PIDS"
}

rollback() {
    local reason="$1"
    local status="${2:-1}"

    if [[ "$ROLLBACK_RUNNING" == 1 ]]; then
        exit "$status"
    fi
    ROLLBACK_RUNNING=1
    trap - EXIT INT TERM
    set +e

    say
    say "============================================================"
    say "4.1.0 UPGRADE NOT ACCEPTED — RESTORING PREVIOUS STATE"
    say "============================================================"
    say "$reason"

    stop_mutable_services
    restore_archive "$PROGRAM_ARCHIVE"
    restore_archive "$SETTINGS_ARCHIVE"
    restore_release_version
    restore_mutable_service_states

    local settings_ok=false
    if verify_settings_manifest; then
        settings_ok=true
    fi

    {
        echo "accepted=false"
        echo "reason=$reason"
        echo "settings_restored=true"
        echo "settings_restore_verified=$settings_ok"
        echo "rolled_back_at=$(date --iso-8601=seconds)"
    } | run_root tee "$REPORT" >/dev/null

    say "Previous Ground Station program and settings were restored."
    say "Settings verification after rollback: $settings_ok"
    say "Backup: $BACKUP_DIR"

    rm -rf "$TMP_DIR"
    stop_sudo
    exit "$status"
}

on_exit() {
    local status=$?
    if [[ "$status" -ne 0 && "$SNAPSHOT_READY" == 1           && "$UPGRADE_ACCEPTED" == 0 ]]; then
        rollback             "The installer exited before all preservation checks passed."             "$status"
    fi
    rm -rf "$TMP_DIR"
    stop_sudo
    exit "$status"
}
trap on_exit EXIT INT TERM

say "============================================================"
say "SIYI RPI INSTALLER 4.1.0"
say "GROUND STATION CONSOLIDATED UPGRADE"
say "============================================================"
say

for command in     bash python3 systemctl tar sha256sum curl install stat grep diff
do
    need "$command"
done
start_sudo
mkdir -p "$TMP_DIR"
run_root install -d -o root -g root -m 0700 "$BACKUP_DIR"

[[ -f "$SOURCE_SERVER" ]] || {
    say "ERROR: packaged server.py is missing"
    exit 1
}
[[ -f "$BRIDGE_PATCHER" ]] || {
    say "ERROR: packaged bridge patcher is missing"
    exit 1
}
[[ -f "$LIVE_SERVER" ]] || {
    say "ERROR: existing Ground Station server is missing: $LIVE_SERVER"
    exit 1
}
[[ -f "$LIVE_BRIDGE" ]] || {
    say "ERROR: existing button bridge is missing: $LIVE_BRIDGE"
    exit 1
}

CURRENT_VERSION="$(cat "$RELEASE_FILE" 2>/dev/null || printf 'unknown')"
case "$CURRENT_VERSION" in
    4.0.4|4.1.0) ;;
    *)
        say "ERROR: this consolidated 4.1.0 installer requires SIYI 4.0.4."
        say "Current release: $CURRENT_VERSION"
        exit 1
        ;;
esac

SOURCE_SHA="$(sha256sum "$SOURCE_SERVER" | awk '{print $1}')"
[[ "$SOURCE_SHA" == "$EXPECTED_SERVER_SHA" ]] || {
    say "ERROR: packaged 4.1.0 server checksum mismatch"
    exit 1
}

python3 -m py_compile "$SOURCE_SERVER" "$BRIDGE_PATCHER"
python3 -m py_compile "$LIVE_SERVER" "$LIVE_BRIDGE"

systemctl is-active --quiet siyi-webui.service || {
    say "ERROR: siyi-webui.service must be active before upgrading"
    exit 1
}
systemctl is-active --quiet siyi-groundstation.service || {
    say "ERROR: siyi-groundstation.service must be active before upgrading"
    exit 1
}

say "Current release: $CURRENT_VERSION"
say "4.1.0 server SHA256: $EXPECTED_SERVER_SHA"
say

capture_service_states

say "Capturing complete Ground Station telemetry configuration..."
wait_for_api "$TMP_DIR/layout_before.json" || {
    say "ERROR: Ground Station telemetry API was unavailable"
    exit 1
}
write_semantic_layout     "$TMP_DIR/layout_before.json"     "$TMP_DIR/semantic_before.json"
run_root install -o root -g root -m 0600     "$TMP_DIR/layout_before.json" "$LAYOUT_BEFORE"
run_root install -o root -g root -m 0600     "$TMP_DIR/semantic_before.json" "$SEMANTIC_BEFORE"

printf '%s\n' "$CURRENT_VERSION"     > "$TMP_DIR/release_version_before.txt"
run_root install -o root -g root -m 0600     "$TMP_DIR/release_version_before.txt"     "$BACKUP_DIR/release_version_before.txt"

say "Freezing mutable Ground Station services..."
stop_mutable_services

say "Creating explicit Pi-side settings snapshot..."
build_settings_list
build_program_list
create_settings_manifest
create_archive "$SETTINGS_LIST" "$SETTINGS_ARCHIVE" true
create_archive "$PROGRAM_LIST" "$PROGRAM_ARCHIVE" false

run_root sha256sum     "$SETTINGS_ARCHIVE"     "$PROGRAM_ARCHIVE"     "$SETTINGS_MANIFEST"     "$LAYOUT_BEFORE"     "$SEMANTIC_BEFORE"     > "$TMP_DIR/snapshot_checksums.txt"
run_root install -o root -g root -m 0600     "$TMP_DIR/snapshot_checksums.txt"     "$BACKUP_DIR/snapshot_checksums.txt"

SNAPSHOT_READY=1
say "Snapshot complete: $BACKUP_DIR"

say
say "Installing consolidated 4.1.0 Ground Station program..."

SERVER_UID="$(stat -c '%u' "$LIVE_SERVER")"
SERVER_GID="$(stat -c '%g' "$LIVE_SERVER")"
SERVER_MODE="$(stat -c '%a' "$LIVE_SERVER")"
BRIDGE_UID="$(stat -c '%u' "$LIVE_BRIDGE")"
BRIDGE_GID="$(stat -c '%g' "$LIVE_BRIDGE")"
BRIDGE_MODE="$(stat -c '%a' "$LIVE_BRIDGE")"

cp "$LIVE_BRIDGE" "$TMP_DIR/bridge_candidate.py"
python3 "$BRIDGE_PATCHER"     "$TMP_DIR/bridge_candidate.py"     "$TMP_DIR/bridge_patched.py"
python3 -m py_compile     "$SOURCE_SERVER"     "$TMP_DIR/bridge_patched.py"

run_root install     -o "$SERVER_UID" -g "$SERVER_GID" -m "$SERVER_MODE"     "$SOURCE_SERVER" "$LIVE_SERVER"
run_root install     -o "$BRIDGE_UID" -g "$BRIDGE_GID" -m "$BRIDGE_MODE"     "$TMP_DIR/bridge_patched.py" "$LIVE_BRIDGE"

restore_archive "$SETTINGS_ARCHIVE"
verify_settings_manifest
restore_mutable_service_states

say "Waiting for Ground Station API after restart..."
wait_for_api "$TMP_DIR/layout_after.json" ||     rollback "Ground Station API did not recover after installation." 1

write_semantic_layout     "$TMP_DIR/layout_after.json"     "$TMP_DIR/semantic_after.json"

if ! cmp -s     "$TMP_DIR/semantic_before.json"     "$TMP_DIR/semantic_after.json"
then
    diff -u         "$TMP_DIR/semantic_before.json"         "$TMP_DIR/semantic_after.json"         > "$TMP_DIR/telemetry_layout_difference.txt" || true
    run_root install -o root -g root -m 0600         "$TMP_DIR/telemetry_layout_difference.txt"         "$BACKUP_DIR/telemetry_layout_difference.txt"
    rollback         "Ground Station telemetry settings changed during installation."         1
fi

run_root install -o root -g root -m 0600     "$TMP_DIR/layout_after.json" "$LAYOUT_AFTER"
run_root install -o root -g root -m 0600     "$TMP_DIR/semantic_after.json" "$SEMANTIC_AFTER"

python3 -m py_compile "$LIVE_SERVER" "$LIVE_BRIDGE"

[[ "$(sha256sum "$LIVE_SERVER" | awk '{print $1}')"     == "$EXPECTED_SERVER_SHA" ]] ||     rollback "Installed server checksum verification failed." 1

grep -Fq "$SERVER_MARKER" "$LIVE_SERVER" ||     rollback "V2.8.21 Ground Station marker is missing." 1
grep -Fq "SIYI_RELEASE_4_1_0" "$LIVE_SERVER" ||     rollback "4.1.0 release marker is missing." 1
grep -Fq "Control Center 4.1.0" "$LIVE_SERVER" ||     rollback "4.1.0 Control Center label is missing." 1
grep -Fq "$BRIDGE_MARKER" "$LIVE_BRIDGE" ||     rollback "Telemetry-toggle bridge marker is missing." 1

curl -fsS --max-time 8     "http://127.0.0.1:8080/groundstation?release=4.1.0"     -o "$TMP_DIR/groundstation.html" ||     rollback "Ground Station page could not be loaded." 1
grep -Fq "$SERVER_MARKER" "$TMP_DIR/groundstation.html" ||     rollback "The served Ground Station page is not the 4.1.0 build." 1

verify_protected_pids ||     rollback "A protected runtime service restarted unexpectedly." 1

while read -r state service; do
    if [[ "$state" == active ]]; then
        systemctl is-active --quiet "$service" ||             rollback "Previously active service is down: $service" 1
    fi
done < "$SERVICE_STATES"

write_release_version

{
    echo "accepted=true"
    echo "previous_release=$CURRENT_VERSION"
    echo "accepted_release=$VERSION"
    echo "server_sha256=$EXPECTED_SERVER_SHA"
    echo "settings_archive=$SETTINGS_ARCHIVE"
    echo "settings_manifest=$SETTINGS_MANIFEST"
    echo "file_manifest_match=true"
    echo "telemetry_semantic_match=true"
    echo "protected_service_pids_unchanged=true"
    echo "verified_at=$(date --iso-8601=seconds)"
} | run_root tee "$REPORT" >/dev/null
run_root touch "$VERIFIED_MARKER"
run_root chmod 0600 "$REPORT" "$VERIFIED_MARKER"

UPGRADE_ACCEPTED=1
trap - EXIT INT TERM
rm -rf "$TMP_DIR"
stop_sudo

say
say "============================================================"
say "SIYI RPI INSTALLER 4.1.0 INSTALLED AND VERIFIED"
say "============================================================"
say "Ground Station program: upgraded"
say "Pi-side Ground Station settings: restored and verified"
say "Telemetry configuration: exact semantic match"
say "Phone/Desktop browser-local geometry: untouched"
say "Protected runtime services: not restarted"
say "Release marker: 4.1.0"
say "Preservation backup: $BACKUP_DIR"
