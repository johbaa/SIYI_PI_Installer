#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import ast
import sys

MARKER = "GROUND_STATION_BUTTON_ACTION_V2_8_8_TELEMETRY_TOGGLE_BRIDGE"

ANCHOR = (
    '    elif action == "PIP_MINIMIZE_TOGGLE":\n'
    '        if str(BUTTON_ACTION_SOURCE).startswith("groundstation"):\n'
    '            groundstation_ui_event("toggle_pip_minimized")\n'
)

ADDITION = (
    '    # GROUND_STATION_BUTTON_ACTION_V2_8_8_TELEMETRY_TOGGLE_BRIDGE\n'
    '    elif action == "TELEMETRY_TOGGLE":\n'
    '        if str(BUTTON_ACTION_SOURCE).startswith("groundstation"):\n'
    '            groundstation_ui_event("toggle_telemetry")\n'
    '        else:\n'
    '            print(\n'
    '                "[TELEMETRY_TOGGLE_IGNORED] source=%s"\n'
    '                % BUTTON_ACTION_SOURCE,\n'
    '                flush=True,\n'
    '            )\n'
)

REQUIRED = (
    MARKER,
    'elif action == "TELEMETRY_TOGGLE":',
    'groundstation_ui_event("toggle_telemetry")',
    'elif action == "PIP_MINIMIZE_TOGGLE":',
    'elif action == "VIDEO_MAP_TOGGLE":',
)


def main() -> int:
    if len(sys.argv) != 3:
        print("usage: patch_button_bridge.py INPUT OUTPUT", file=sys.stderr)
        return 2

    source_path = Path(sys.argv[1])
    output_path = Path(sys.argv[2])
    source = source_path.read_text(encoding="utf-8")

    if MARKER not in source:
        if source.count(ANCHOR) != 1:
            raise SystemExit(
                "The compatible PIP_MINIMIZE_TOGGLE bridge anchor was not "
                "found exactly once. No bridge file was changed."
            )
        source = source.replace(ANCHOR, ADDITION + ANCHOR, 1)

    for token in REQUIRED:
        if token not in source:
            raise SystemExit("Required button-bridge token missing: " + token)
    if source.count('elif action == "TELEMETRY_TOGGLE":') != 1:
        raise SystemExit(
            "The button bridge contains an invalid number of "
            "TELEMETRY_TOGGLE branches."
        )

    ast.parse(source)
    output_path.write_text(source, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
