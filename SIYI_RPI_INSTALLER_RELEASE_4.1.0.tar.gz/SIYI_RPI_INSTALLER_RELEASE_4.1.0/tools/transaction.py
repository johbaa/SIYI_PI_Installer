#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import os
import pwd
import grp
import shutil
import stat
import sys
import tempfile

ROOT_PREFIX = Path(os.environ.get('SIYI_TX_ROOT', '/')).resolve()


def live_path(raw: str) -> Path:
    return ROOT_PREFIX / raw.lstrip('/')


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def remove_item(path: Path) -> None:
    if not (path.exists() or path.is_symlink()):
        return
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    else:
        path.unlink()


def apply_metadata(src_stat: os.stat_result, dst: Path, *, symlink: bool) -> None:
    if symlink:
        if hasattr(os, 'lchown'):
            os.lchown(dst, src_stat.st_uid, src_stat.st_gid)
        return
    os.chown(dst, src_stat.st_uid, src_stat.st_gid, follow_symlinks=False)
    os.chmod(dst, stat.S_IMODE(src_stat.st_mode), follow_symlinks=False)
    os.utime(
        dst,
        ns=(src_stat.st_atime_ns, src_stat.st_mtime_ns),
        follow_symlinks=False,
    )


def copy_item(src: Path, dst: Path) -> None:
    remove_item(dst)
    dst.parent.mkdir(parents=True, exist_ok=True)
    src_stat = os.lstat(src)

    if stat.S_ISLNK(src_stat.st_mode):
        os.symlink(os.readlink(src), dst)
        apply_metadata(src_stat, dst, symlink=True)
        return

    if stat.S_ISDIR(src_stat.st_mode):
        dst.mkdir()
        for child in sorted(src.iterdir(), key=lambda p: p.name):
            copy_item(child, dst / child.name)
        apply_metadata(src_stat, dst, symlink=False)
        return

    if stat.S_ISREG(src_stat.st_mode):
        shutil.copyfile(src, dst, follow_symlinks=False)
        shutil.copystat(src, dst, follow_symlinks=False)
        apply_metadata(src_stat, dst, symlink=False)
        return

    raise RuntimeError(f'unsupported file type: {src}')


def record_tree(path: Path, logical_path: str, records: dict[str, dict]) -> None:
    st = os.lstat(path)
    logical = '/' + logical_path.lstrip('/')
    record = {
        'path': logical,
        'mode': stat.S_IMODE(st.st_mode),
        'uid': st.st_uid,
        'gid': st.st_gid,
    }
    if stat.S_ISLNK(st.st_mode):
        record.update(type='symlink', target=os.readlink(path))
    elif stat.S_ISREG(st.st_mode):
        record.update(type='file', sha256=digest(path), size=st.st_size)
    elif stat.S_ISDIR(st.st_mode):
        record.update(type='directory')
    else:
        record.update(type='other')
    records[logical] = record

    if record['type'] == 'directory':
        for child in sorted(path.iterdir(), key=lambda p: p.name):
            record_tree(child, logical.rstrip('/') + '/' + child.name, records)


def snapshot(paths: list[str], backup: Path, name: str) -> int:
    root = backup / name / 'rootfs'
    root.mkdir(parents=True, exist_ok=True)
    absent: list[str] = []
    records: dict[str, dict] = {}

    for raw in paths:
        logical = '/' + str(raw).lstrip('/')
        src = live_path(logical)
        dst = root / logical.lstrip('/')
        if src.exists() or src.is_symlink():
            copy_item(src, dst)
            record_tree(dst, logical, records)
        else:
            absent.append(logical)

    manifest = {
        'schema': 2,
        'paths': ['/' + str(x).lstrip('/') for x in paths],
        'absent': sorted(set(absent)),
        'records': [records[key] for key in sorted(records)],
    }
    manifest_path = backup / name / 'manifest.json'
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    return verify_backup(backup, name)


def restore(backup: Path, name: str) -> int:
    manifest = json.loads((backup / name / 'manifest.json').read_text())
    root = backup / name / 'rootfs'

    # Restore the requested roots only. Artificial parent directories inside
    # the backup tree are never part of the manifest and never overwrite live
    # /home, /home/pi, /etc, or other container directories.
    for raw in manifest['paths']:
        dst = live_path(raw)
        src = root / raw.lstrip('/')
        if src.exists() or src.is_symlink():
            copy_item(src, dst)
        elif raw in manifest['absent']:
            remove_item(dst)
    return 0


def compare_record(path: Path, expected: dict, errors: list[str]) -> None:
    logical = expected['path']
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        errors.append(logical + ': missing')
        return

    if stat.S_IMODE(st.st_mode) != expected['mode']:
        errors.append(logical + ': mode changed')
    if st.st_uid != expected['uid']:
        errors.append(logical + ': uid changed')
    if st.st_gid != expected['gid']:
        errors.append(logical + ': gid changed')

    typ = expected['type']
    if typ == 'file':
        if not stat.S_ISREG(st.st_mode) or digest(path) != expected['sha256']:
            errors.append(logical + ': content changed')
    elif typ == 'symlink':
        if not stat.S_ISLNK(st.st_mode) or os.readlink(path) != expected['target']:
            errors.append(logical + ': link changed')
    elif typ == 'directory':
        if not stat.S_ISDIR(st.st_mode):
            errors.append(logical + ': type changed')


def verify(backup: Path, name: str) -> int:
    manifest = json.loads((backup / name / 'manifest.json').read_text())
    errors: list[str] = []
    for expected in manifest['records']:
        compare_record(live_path(expected['path']), expected, errors)
    for raw in manifest['absent']:
        p = live_path(raw)
        if p.exists() or p.is_symlink():
            errors.append(raw + ': was absent but now exists')
    if errors:
        print('\n'.join(errors), file=sys.stderr)
        return 1
    print(f'{name} live manifest verified: {len(manifest["records"])} records')
    return 0


def verify_backup(backup: Path, name: str) -> int:
    manifest = json.loads((backup / name / 'manifest.json').read_text())
    root = backup / name / 'rootfs'
    errors: list[str] = []
    for expected in manifest['records']:
        compare_record(root / expected['path'].lstrip('/'), expected, errors)
    for raw in manifest['absent']:
        p = root / raw.lstrip('/')
        if p.exists() or p.is_symlink():
            errors.append(raw + ': absent path unexpectedly exists in backup')
    if errors:
        print('\n'.join(errors), file=sys.stderr)
        return 1
    print(f'{name} backup manifest verified: {len(manifest["records"])} records')
    return 0


def install_payload(release: Path) -> int:
    manifest = json.loads((release / 'payload_manifest.json').read_text())
    for item in manifest['files']:
        src = release / item['source']
        dst = live_path(item['target'])
        if digest(src) != item['sha256']:
            raise SystemExit('payload checksum mismatch: ' + str(src))
        dst.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix='.' + dst.name + '.', dir=str(dst.parent))
        os.close(fd)
        try:
            shutil.copy2(src, tmp)
            os.chmod(tmp, int(item['mode'], 8))
            os.chown(
                tmp,
                pwd.getpwnam(item['owner']).pw_uid,
                grp.getgrnam(item['group']).gr_gid,
            )
            os.replace(tmp, dst)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)
    return 0


def verify_payload(release: Path) -> int:
    manifest = json.loads((release / 'payload_manifest.json').read_text())
    errors: list[str] = []
    for item in manifest['files']:
        p = live_path(item['target'])
        if not p.is_file():
            errors.append(str(p) + ': missing')
            continue
        if digest(p) != item['sha256']:
            errors.append(str(p) + ': checksum mismatch')
        if stat.S_IMODE(p.stat().st_mode) != int(item['mode'], 8):
            errors.append(str(p) + ': mode mismatch')
    if errors:
        print('\n'.join(errors), file=sys.stderr)
        return 1
    print(f'Payload verified: {len(manifest["files"])} files')
    return 0


def main() -> int:
    if len(sys.argv) < 3:
        return 2
    cmd = sys.argv[1]
    if cmd in ('snapshot', 'restore', 'verify', 'verify-backup'):
        backup = Path(sys.argv[2])
        name = sys.argv[3]
        if cmd == 'snapshot':
            return snapshot(json.loads(Path(sys.argv[4]).read_text()), backup, name)
        if cmd == 'restore':
            return restore(backup, name)
        if cmd == 'verify-backup':
            return verify_backup(backup, name)
        return verify(backup, name)

    release = Path(sys.argv[2])
    if cmd == 'install-payload':
        return install_payload(release)
    if cmd == 'verify-payload':
        return verify_payload(release)
    return 2


if __name__ == '__main__':
    raise SystemExit(main())
