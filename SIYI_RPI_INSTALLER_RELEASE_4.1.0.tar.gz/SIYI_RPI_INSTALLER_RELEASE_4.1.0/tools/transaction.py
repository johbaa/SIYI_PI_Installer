#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, os, pwd, grp, shutil, stat, sys, tempfile

def digest(path: Path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def record_tree(path: Path, base: Path, records: dict):
    rel=str(path.relative_to(base)); st=os.lstat(path)
    r={'path':rel,'mode':stat.S_IMODE(st.st_mode),'uid':st.st_uid,'gid':st.st_gid}
    if stat.S_ISLNK(st.st_mode): r.update(type='symlink',target=os.readlink(path))
    elif stat.S_ISREG(st.st_mode): r.update(type='file',sha256=digest(path),size=st.st_size)
    elif stat.S_ISDIR(st.st_mode): r.update(type='directory')
    else: r.update(type='other')
    records[rel]=r
    if r['type']=='directory':
        for child in sorted(path.iterdir(),key=lambda p:p.name): record_tree(child,base,records)

def copy_item(src: Path, dst: Path):
    if dst.exists() or dst.is_symlink():
        if dst.is_dir() and not dst.is_symlink(): shutil.rmtree(dst)
        else: dst.unlink()
    dst.parent.mkdir(parents=True,exist_ok=True)
    if src.is_symlink(): os.symlink(os.readlink(src),dst)
    elif src.is_dir(): shutil.copytree(src,dst,symlinks=True,copy_function=shutil.copy2)
    else: shutil.copy2(src,dst,follow_symlinks=False)

def snapshot(paths,backup:Path,name:str):
    root=backup/name/'rootfs'; root.mkdir(parents=True,exist_ok=True); absent=[]
    for raw in paths:
        src=Path(raw); dst=root/raw.lstrip('/')
        if src.exists() or src.is_symlink(): copy_item(src,dst)
        else: absent.append(raw)
    records={}
    for child in sorted(root.iterdir(),key=lambda p:p.name): record_tree(child,root,records)
    data={'paths':paths,'absent':absent,'records':[records[k] for k in sorted(records)]}
    (backup/name/'manifest.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')

def restore(backup:Path,name:str):
    manifest=json.loads((backup/name/'manifest.json').read_text()); root=backup/name/'rootfs'
    for raw in manifest['paths']:
        dst=Path(raw); src=root/raw.lstrip('/')
        if src.exists() or src.is_symlink(): copy_item(src,dst)
        elif raw in manifest['absent'] and (dst.exists() or dst.is_symlink()):
            if dst.is_dir() and not dst.is_symlink(): shutil.rmtree(dst)
            else: dst.unlink()

def verify(backup:Path,name:str):
    manifest=json.loads((backup/name/'manifest.json').read_text()); errors=[]
    for expected in manifest['records']:
        path=Path('/')/expected['path']
        try: st=os.lstat(path)
        except FileNotFoundError: errors.append(str(path)+': missing'); continue
        if stat.S_IMODE(st.st_mode)!=expected['mode']: errors.append(str(path)+': mode changed')
        if st.st_uid!=expected['uid']: errors.append(str(path)+': uid changed')
        if st.st_gid!=expected['gid']: errors.append(str(path)+': gid changed')
        typ=expected['type']
        if typ=='file' and (not stat.S_ISREG(st.st_mode) or digest(path)!=expected['sha256']): errors.append(str(path)+': content changed')
        elif typ=='symlink' and (not stat.S_ISLNK(st.st_mode) or os.readlink(path)!=expected['target']): errors.append(str(path)+': link changed')
        elif typ=='directory' and not stat.S_ISDIR(st.st_mode): errors.append(str(path)+': type changed')
    for raw in manifest['absent']:
        p=Path(raw)
        if p.exists() or p.is_symlink(): errors.append(raw+': was absent but now exists')
    if errors: print('\n'.join(errors),file=sys.stderr); return 1
    print(f'{name} manifest verified: {len(manifest["records"])} records'); return 0

def install_payload(release:Path):
    manifest=json.loads((release/'payload_manifest.json').read_text())
    for item in manifest['files']:
        src=release/item['source']; dst=Path(item['target'])
        if digest(src)!=item['sha256']: raise SystemExit('payload checksum mismatch: '+str(src))
        dst.parent.mkdir(parents=True,exist_ok=True)
        fd,tmp=tempfile.mkstemp(prefix='.'+dst.name+'.',dir=str(dst.parent)); os.close(fd)
        shutil.copy2(src,tmp); os.chmod(tmp,int(item['mode'],8))
        os.chown(tmp,pwd.getpwnam(item['owner']).pw_uid,grp.getgrnam(item['group']).gr_gid)
        os.replace(tmp,dst)
    return 0

def verify_payload(release:Path):
    manifest=json.loads((release/'payload_manifest.json').read_text()); errors=[]
    for item in manifest['files']:
        p=Path(item['target'])
        if not p.is_file(): errors.append(str(p)+': missing'); continue
        if digest(p)!=item['sha256']: errors.append(str(p)+': checksum mismatch')
        if stat.S_IMODE(p.stat().st_mode)!=int(item['mode'],8): errors.append(str(p)+': mode mismatch')
    if errors: print('\n'.join(errors),file=sys.stderr); return 1
    print(f'Payload verified: {len(manifest["files"])} files'); return 0

def main():
    cmd=sys.argv[1]
    if cmd in ('snapshot','restore','verify'):
        backup=Path(sys.argv[2]); name=sys.argv[3]
        if cmd=='snapshot': snapshot(json.loads(Path(sys.argv[4]).read_text()),backup,name); return 0
        if cmd=='restore': restore(backup,name); return 0
        return verify(backup,name)
    release=Path(sys.argv[2])
    if cmd=='install-payload': return install_payload(release)
    if cmd=='verify-payload': return verify_payload(release)
    return 2
if __name__=='__main__': raise SystemExit(main())
