#!/usr/bin/env python3
from pathlib import Path
import json,sys
p=json.loads(Path(sys.argv[1]).read_text())
if not p.get('ok'): raise SystemExit('layout API did not return ok')
Path(sys.argv[2]).write_text(json.dumps(p.get('config'),sort_keys=True,separators=(',',':'))+'\n')
