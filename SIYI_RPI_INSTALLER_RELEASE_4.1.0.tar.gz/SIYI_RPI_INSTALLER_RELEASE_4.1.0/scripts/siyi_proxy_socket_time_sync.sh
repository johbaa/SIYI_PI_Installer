#!/bin/bash
set -euo pipefail

FIFO="/tmp/siyi_record_proxy"
PROXY_SERVICE="siyi-rec-proxy.service"
SINCE="$(date --iso-8601=seconds)"
DUMMY_PID=""

cleanup() {
  if [[ -n "$DUMMY_PID" ]]; then
    kill "$DUMMY_PID" 2>/dev/null || true
    wait "$DUMMY_PID" 2>/dev/null || true
  fi
}
trap cleanup EXIT

echo "[PROXY_TIME] Waiting for siyi-rec-proxy.service active."
for _ in $(seq 1 40); do
  systemctl is-active --quiet "$PROXY_SERVICE" && break
  sleep 0.25
done
systemctl is-active --quiet "$PROXY_SERVICE"

echo "[PROXY_TIME] Waiting for FIFO."
for _ in $(seq 1 40); do
  [[ -p "$FIFO" ]] && break
  sleep 0.25
done
[[ -p "$FIFO" ]]

if ! ss -tn state established 2>/dev/null | grep -q ':37256'; then
  echo "[PROXY_TIME] Opening dummy client to proxy."
  python3 - <<'PY_DUMMY' &
import socket
import time

sock = socket.create_connection(("127.0.0.1", 37256), timeout=5)
print("[PROXY_TIME] DUMMY_CLIENT_CONNECTED", flush=True)
try:
    time.sleep(10)
finally:
    sock.close()
PY_DUMMY
  DUMMY_PID="$!"
  sleep 2
else
  echo "[PROXY_TIME] Existing QGC/proxy control session detected."
fi

echo "[PROXY_TIME] Sending set_time_now through FIFO."
printf 'set_time_now\n' >"$FIFO"
sleep 2

echo "[PROXY_TIME] Verifying UTC injection."
if journalctl -u "$PROXY_SERVICE" --since "$SINCE" --no-pager |
   grep -q '\[CAMERA_TIME_SYNC_UTC\]'; then
  echo "[PROXY_TIME] VERIFIED: UTC camera time packet injected through proxy"
else
  echo "[PROXY_TIME] ERROR: no verified UTC camera time injection" >&2
  journalctl -u "$PROXY_SERVICE" --since "$SINCE" --no-pager >&2 || true
  exit 1
fi
