#!/usr/bin/env python3
# FLIGHTCORE_4_2_3_RC13_DEVICE_REGISTRY_V1
import argparse, datetime, json, os, re, secrets, shutil, socket, subprocess, tempfile, urllib.request
from pathlib import Path

ROOT = Path(os.environ.get("FLIGHTCORE_REGISTRY_ROOT", "/"))
def rp(path): return ROOT / path.lstrip("/")
DEVICE_ID = rp("/etc/flightcore/device-id")
CONFIG = rp("/etc/flightcore/registry.json")
DEVICE_TOKEN = rp("/etc/flightcore/registry-device-token")
READ_TOKEN = rp("/etc/flightcore/registry-read-token")
STATE = rp("/var/lib/flightcore/registry-state.json")

def now(): return datetime.datetime.now().astimezone().isoformat(timespec="seconds")

def atomic_write(path, data, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix="." + path.name + ".", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.chmod(tmp, mode); os.replace(tmp, path)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass

def ensure_id():
    if DEVICE_ID.exists():
        value = DEVICE_ID.read_text(errors="replace").strip()
        if re.fullmatch(r"FC-[A-F0-9]{12}", value): return value
        raise RuntimeError("Invalid existing FlightCore device ID")
    value = "FC-" + secrets.token_hex(6).upper()
    atomic_write(DEVICE_ID, value + "\n", 0o644)
    return value

def default_config():
    return {"schema_version":1,"enabled":False,"api_url":"","standalone_url":"","name":"","heartbeat_minutes":5}

def ensure_config():
    if not CONFIG.exists(): atomic_write(CONFIG, json.dumps(default_config(), indent=2, sort_keys=True) + "\n", 0o644)
    cfg = json.loads(CONFIG.read_text())
    if not isinstance(cfg, dict): raise RuntimeError("Invalid registry configuration")
    return cfg

def output(cmd):
    try: return subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True, timeout=3).strip()
    except Exception: return ""

def service_active(name): return output(["systemctl", "is-active", name]) == "active"

def boot_time_iso():
    try:
        for line in rp("/proc/stat").read_text().splitlines():
            if line.startswith("btime "):
                ts = int(line.split()[1])
                return datetime.datetime.fromtimestamp(ts, datetime.timezone.utc).astimezone().isoformat(timespec="seconds")
    except Exception: pass
    return ""

def boot_id():
    try: return rp("/proc/sys/kernel/random/boot_id").read_text().strip()
    except Exception: return ""

def zt_ip():
    for line in output(["zerotier-cli", "listnetworks"]).splitlines():
        if " OK " not in (" " + line + " "): continue
        matches = re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}/\d+\b", line)
        if matches: return matches[-1].split("/")[0]
    return ""

def lan_ip():
    m = re.search(r"\bsrc\s+((?:\d{1,3}\.){3}\d{1,3})", output(["ip", "route", "get", "1.1.1.1"]))
    return m.group(1) if m else ""

def hardware():
    try: return rp("/proc/device-tree/model").read_bytes().replace(b"\0", b"").decode(errors="replace").strip()
    except Exception: return output(["uname", "-m"])

def marker(path):
    try: return rp(path).read_text(errors="replace").strip()
    except Exception: return ""

def build_channel(build):
    m = re.search(r"RELEASE_CANDIDATE_V(\d+)", build)
    return "RC" + m.group(1) if m else ("Stable" if build else "")

def cpu_temp_c():
    try: return round(float(rp("/sys/class/thermal/thermal_zone0/temp").read_text()) / 1000.0, 1)
    except Exception: return None

def disk_free_pct():
    try:
        u = shutil.disk_usage(str(ROOT)); return round(100.0 * u.free / max(1, u.total), 1)
    except Exception: return None

def health():
    temp = cpu_temp_c(); free = disk_free_pct()
    return {
        "mavlink_detected": service_active("mavlink-router.service") and service_active("siyi-groundstation.service"),
        "zerotier_connected": bool(zt_ip()),
        "webui_healthy": service_active("siyi-webui.service"),
        "video_healthy": service_active("mediamtx.service"),
        "free_storage_ok": None if free is None else free >= 10.0,
        "free_storage_pct": free,
        "cpu_temp_warning": None if temp is None else temp >= 80.0,
        "cpu_temp_c": temp,
    }

def state_read():
    try:
        v = json.loads(STATE.read_text()); return v if isinstance(v, dict) else {}
    except Exception: return {}

def state_write(data): atomic_write(STATE, json.dumps(data, indent=2, sort_keys=True) + "\n", 0o644)
def token(path):
    try: return path.read_text(errors="replace").strip()
    except Exception: return ""

def api_url(cfg):
    url = str(cfg.get("api_url") or "").strip().rstrip("/")
    if not url: return ""
    if url.startswith("https://"): return url
    if os.environ.get("FLIGHTCORE_REGISTRY_ALLOW_HTTP_TEST") == "1" and url.startswith("http://127.0.0.1:"): return url
    raise RuntimeError("Registry API URL must use HTTPS")

def request_json(url, method="GET", body=None, bearer="", timeout=6):
    headers = {"Accept":"application/json", "User-Agent":"FlightCore-Registry/4.2.3-RC13"}; data = None
    if bearer: headers["Authorization"] = "Bearer " + bearer
    if body is not None:
        data = json.dumps(body, separators=(",", ":")).encode(); headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.urlopen(req, timeout=timeout) as r: raw = r.read(262144)
    return json.loads(raw.decode()) if raw else {}

def payload():
    cfg = ensure_config(); did = ensure_id(); build = marker("/etc/siyi/release_build")
    previous = state_read(); bid = boot_id(); event = "boot" if bid and bid != str(previous.get("boot_id") or "") else "heartbeat"
    return {
        "device_id": did,
        "name": str(cfg.get("name") or "").strip() or socket.gethostname(),
        "hardware": hardware(),
        "flightcore_version": marker("/etc/siyi/release_version"),
        "build_channel": build_channel(build),
        "build_id": build,
        "boot_time": boot_time_iso(),
        "zerotier_ip": zt_ip(),
        "lan_ip": lan_ip(),
        "hostname": socket.gethostname(),
        "health": health(),
        "event_type": event,
    }

def checkin():
    cfg = ensure_config(); did = ensure_id(); base = {"device_id":did,"boot_id":boot_id(),"checked_at":now()}
    if not cfg.get("enabled"):
        state_write({**state_read(), **base, "status":"disabled", "error":""}); return 0
    url = api_url(cfg); devtoken = token(DEVICE_TOKEN)
    if not url or not devtoken:
        state_write({**state_read(), **base, "status":"unconfigured", "error":"Registry API URL or device token is missing"}); return 0
    try:
        result = request_json(url + "/api/v1/checkin", "POST", payload(), devtoken, 6)
        state_write({**state_read(), **base, "status":"ok", "error":"", "last_success":now(), "last_response":result}); return 0
    except Exception as exc:
        state_write({**state_read(), **base, "status":"offline", "error":str(exc)[:400]}); return 0

def list_units():
    cfg = ensure_config(); url = api_url(cfg); rt = token(READ_TOKEN)
    if not url or not rt: raise RuntimeError("Registry API URL or read token is missing")
    return request_json(url + "/api/v1/units", "GET", None, rt, 6)

def main():
    ap = argparse.ArgumentParser(); group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument("--ensure-id", action="store_true"); group.add_argument("--ensure-config", action="store_true")
    group.add_argument("--checkin", action="store_true"); group.add_argument("--list-json", action="store_true"); group.add_argument("--show-state", action="store_true")
    a = ap.parse_args()
    if a.ensure_id: print(ensure_id())
    elif a.ensure_config: ensure_config(); print(CONFIG)
    elif a.checkin: raise SystemExit(checkin())
    elif a.list_json: print(json.dumps(list_units(), indent=2, sort_keys=True))
    else: print(json.dumps(state_read(), indent=2, sort_keys=True))
if __name__ == "__main__": main()
