# FlightCore 4.3.0 RC32

Canonical machine identity: `4.3.0-rc.32`. Build: `20260821.163000-32e7a64`.

RC32 corrects the Airlink regression introduced by the stacked RC30 and RC31 browser recovery layers. Its exact installed parent is RC31 build `20260821.133000-31c8f52`.

## Corrections

- Removes the unrequested **Recover Airlink** Ground Station button.
- Removes both injected RC30 and RC31 Airlink recovery owners.
- Stops RC31 from tearing down a working Airlink stream during Ground Station startup.
- Restores a single canonical Ground Station WHEP receiver lifecycle.
- Adds no page reload, startup takeover, duplicate watchdog or overlapping retry loop.

## Preserved behavior

- SIYI video, telemetry, joystick, flight modes and flight-control authority are unchanged.
- RC30 local and cloud log deletion and local storage-limit controls remain included.
- Existing cloud-log formats and Registry compatibility remain unchanged.

## Validation boundary

Static, packaging, identity, upgrade-route and isolated lifecycle gates pass in the factory package. Physical Android verification remains required: initial Airlink continuity, power interruption, automatic return, repeated outage recovery and SIYI/telemetry/joystick continuity.
