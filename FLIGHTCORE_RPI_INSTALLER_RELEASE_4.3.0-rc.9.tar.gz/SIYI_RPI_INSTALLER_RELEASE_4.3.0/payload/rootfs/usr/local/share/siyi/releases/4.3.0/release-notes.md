# FlightCore 4.3.0 RC9

Canonical machine identity: `4.3.0-rc.9`.

RC9 integrates the approved LTE Health, TURN HOME and Air Link UI corrections, adds signed TURN HOME overdue values with emergency-landing distance, and ships fully revised local documentation. All advisory features retain no flight-control authority.
