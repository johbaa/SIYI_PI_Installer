#!/usr/bin/env bash
set -Eeuo pipefail
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
export LC_CTYPE=C.UTF-8

SIYI_INSTALL_BOOTSTRAP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=webui-ip.sh
. "$SIYI_INSTALL_BOOTSTRAP_DIR/webui-ip.sh"
siyi_capture_install_route_context

# Run the transaction engine as root, while retaining the real interactive
# caller only for the human-readable install log location.
if [ "${EUID:-$(id -u)}" -ne 0 ]; then
  command -v sudo >/dev/null 2>&1 || { echo "sudo is required." >&2; exit 1; }
  _siyi_caller="$(id -un 2>/dev/null || true)"
  [ -n "$_siyi_caller" ] || { echo "Could not determine the invoking user." >&2; exit 1; }
  echo "Sudo check: enter the Pi password if asked." >&2
  exec sudo /usr/bin/env \
    SIYI_INSTALL_CALLER="$_siyi_caller" \
    SIYI_INSTALL_ROUTE_IP="${SIYI_INSTALL_ROUTE_IP:-}" \
    SIYI_INSTALL_SSH_CONNECTION="${SIYI_INSTALL_SSH_CONNECTION:-}" \
    SIYI_PRESERVE_GROUPS="${SIYI_PRESERVE_GROUPS:-buttons,flaps,mavlink,camera,gimbal,voice,video}" \
    SIYI_PRESERVE_REMEMBER="${SIYI_PRESERVE_REMEMBER:-0}" \
    bash "$0" "$@"
fi

VERSION="4.2.1"
BUILD_ID="SIYI_4_2_1_RELEASE_CANDIDATE_V21"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload/rootfs"
MANIFEST="$SCRIPT_DIR/payload-manifest.json"
SOURCE_LOCK="$SCRIPT_DIR/source-lock.json"
REPAIR=0
NO_REBOOT=0
REQUIRE_FC=0
REQUESTED_TARGET=""
PRESERVE_CSV="${SIYI_PRESERVE_GROUPS:-buttons,flaps,mavlink,camera,gimbal,voice,video}"
REMEMBER_SELECTION="${SIYI_PRESERVE_REMEMBER:-0}"
while [ "$#" -gt 0 ]; do
  case "$1" in
    --repair) REPAIR=1; shift ;;
    --no-reboot) NO_REBOOT=1; shift ;;
    --require-fc) REQUIRE_FC=1; shift ;;
    --target) [ "$#" -ge 2 ] || { echo "--target requires a value" >&2; exit 2; }; REQUESTED_TARGET="$2"; shift 2 ;;
    --preserve) [ "$#" -ge 2 ] || { echo "--preserve requires a value" >&2; exit 2; }; PRESERVE_CSV="$2"; shift 2 ;;
    --remember) [ "$#" -ge 2 ] || { echo "--remember requires a value" >&2; exit 2; }; REMEMBER_SELECTION="$2"; shift 2 ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
done
[ -z "$REQUESTED_TARGET" ] || [ "$REQUESTED_TARGET" = "$VERSION" ] || { echo "Requested target $REQUESTED_TARGET does not match package $VERSION" >&2; exit 2; }
case "$REMEMBER_SELECTION" in 0|1) ;; *) echo "--remember must be 0 or 1" >&2; exit 2;; esac
declare -A _siyi_seen_groups=()
_siyi_selected_groups=()
IFS=',' read -r -a _siyi_requested_groups <<<"$PRESERVE_CSV"
for _siyi_group in "${_siyi_requested_groups[@]}"; do
  _siyi_group="${_siyi_group//[[:space:]]/}"
  [ -n "$_siyi_group" ] || continue
  case "$_siyi_group" in
    buttons|flaps|mavlink|camera|gimbal|voice|video)
      if [ -z "${_siyi_seen_groups[$_siyi_group]+x}" ]; then _siyi_selected_groups+=("$_siyi_group"); _siyi_seen_groups[$_siyi_group]=1; fi ;;
    groundstation|telemetry|network) : ;; # legacy aliases; these are always preserved
    *) echo "Unknown preservation group: $_siyi_group" >&2; exit 2 ;;
  esac
done
PRESERVE_CSV="$(IFS=,; echo "${_siyi_selected_groups[*]}")"
export SIYI_PRESERVE_GROUPS="$PRESERVE_CSV" SIYI_PRESERVE_REMEMBER="$REMEMBER_SELECTION"

# A single root transaction lock covers every installer entrypoint. The WebUI
# launcher keeps its own UI lifecycle lock; the installer lock prevents it from
# racing a terminal, repair, or recovery invocation.
command -v flock >/dev/null 2>&1 || { echo "flock is required." >&2; exit 1; }
SIYI_INSTALL_LOCK=/run/siyi-installer-transaction.lock
exec 8>"$SIYI_INSTALL_LOCK"
if ! flock -n 8; then
  echo "Another SIYI install, upgrade, repair, or recovery transaction is already running." >&2
  exit 75
fi

CALLING_USER="${SIYI_INSTALL_CALLER:-${SUDO_USER:-${USER:-root}}}"
if [ "$CALLING_USER" = root ]; then
  if id pi >/dev/null 2>&1; then CALLING_USER=pi; else CALLING_USER=root; fi
fi
CALLING_HOME="$(getent passwd "$CALLING_USER" 2>/dev/null | cut -d: -f6 || true)"
[ -n "$CALLING_HOME" ] || CALLING_HOME="$(getent passwd root | cut -d: -f6)"
CALLING_GROUP="$(id -gn "$CALLING_USER" 2>/dev/null || true)"
[ -n "$CALLING_GROUP" ] || CALLING_GROUP=root
INSTALL_LOG="$CALLING_HOME/siyi_install_${VERSION}_$(date +%Y%m%d_%H%M%S).log"
if [ ! -d "$CALLING_HOME" ]; then
  install -d -o "$CALLING_USER" -g "$CALLING_GROUP" -m 0750 "$CALLING_HOME"
fi
install -o "$CALLING_USER" -g "$CALLING_GROUP" -m 0600 /dev/null "$INSTALL_LOG"

SIYI_BLUE=$'\033[0;94m'
SIYI_GREEN=$'\033[1;32m'
SIYI_RESET=$'\033[0m'
SIYI_PROGRESS_HEADING_PRINTED=0
exec 3>&1 4>&2
exec >>"$INSTALL_LOG" 2>&1
CURRENT_STEP_NAME="starting"
INSTALL_START_TS="$SECONDS"
PROGRESS_ANIM_PID=""
PROGRESS_LAST=0
SUCCESS=0
SNAPSHOT_READY=0
MARKER_SNAPSHOT_READY=0
VENV_SWAPPED=0
CAM_PROFILE_CREATED=0
MAPTILER_CACHE_STATE_READY=0
SERVICE_STATE_READY=0
UNIT_STATE_READY=0
TARGET_RELEASE_TREE_MUTATED=0
FRESH_DEPENDENCY_PHASE=0
ROLLBACK_RESULT="not required"
SIYI_MANAGED_UNITS=(
  mavlink-router.service mediamtx.service
  siyi-battery-cache.service siyi-button-bridge.service
  siyi-camera-time-sync.service siyi-groundstation.service
  siyi-joystickd.service siyi-paramd.service
  siyi-rec-proxy.service siyi-rec-redirect.service
  siyi-rtsp-redirect.service siyi-telemetry-canvas.service
  siyi-video-dual.service siyi-video-source.service
  siyi-webui.service siyi-postinstall-verify.service
)
TX="$(date +%Y%m%d_%H%M%S)_$RANDOM"
TX_DIR="/var/lib/siyi-installer/transactions/$TX"
TX_LOG="/var/log/siyi-installer/install_${VERSION}_${TX}.log"

progress_next_target() {
  case "$1" in
    5) echo 9 ;; 10) echo 24 ;; 25) echo 34 ;; 35) echo 44 ;; 45) echo 49 ;;
    50) echo 57 ;; 58) echo 64 ;; 65) echo 69 ;; 70) echo 75 ;; 76) echo 81 ;;
    82) echo 87 ;; 88) echo 93 ;; 94) echo 99 ;; *) echo "$1" ;;
  esac
}

draw_progress() {
  local pct="$1" msg="$2" elapsed="${3:-0}"
  if [ "${SIYI_WEBUI_UPGRADE:-0}" = "1" ]; then
    printf "%3d%%  %s\n" "$pct" "$msg" >&3
    return
  fi
  # A non-interactive stream cannot update a line in place. Emit only the
  # explicit stage update; suppress the one-second animation refreshes.
  if ! [ -t 3 ]; then
    [ "${SIYI_PROGRESS_BACKGROUND:-0}" = "1" ] && return
    printf "%3d%%  %s\n" "$pct" "$msg" >&3
    return
  fi
  local cols="" width=12 filled empty bar="" i spin='|/-\\' idx sp timer="" display="$msg"
  cols="$(stty size </dev/tty 2>/dev/null | awk '{print $2}' || true)"
  [[ "$cols" =~ ^[0-9]+$ ]] || cols="${COLUMNS:-80}"
  [[ "$cols" =~ ^[0-9]+$ ]] || cols=80
  [ "$cols" -ge 40 ] || cols=40
  [ "$cols" -lt 72 ] && width=8
  [ "$cols" -ge 100 ] && width=20
  case "$display" in
    "Validating operating-system dependencies") display="Validating OS dependencies" ;;
  esac
  filled=$((pct * width / 100)); empty=$((width-filled))
  sp="${spin:$((SECONDS % 4)):1}"
  if [ "$elapsed" -gt 0 ]; then timer=$(printf " (%02dm %02ds)" $((elapsed/60)) $((elapsed%60))); fi
  for ((i=0; i<filled; i++)); do bar+="█"; done
  for ((i=0; i<empty; i++)); do bar+="░"; done
  local prefix suffix max_msg plain
  prefix="$sp [$bar] $(printf '%3d%%' "$pct")  "
  max_msg=$((cols - ${#prefix} - ${#timer} - 1))
  if [ "$max_msg" -lt 10 ]; then timer=""; max_msg=$((cols - ${#prefix} - 1)); fi
  [ "$max_msg" -ge 1 ] || max_msg=1
  if [ "${#display}" -gt "$max_msg" ]; then
    if [ "$max_msg" -gt 1 ]; then display="${display:0:$((max_msg-1))}…"; else display="${display:0:1}"; fi
  fi
  plain="${prefix}${display}${timer}"
  if [ "${#plain}" -ge "$cols" ]; then plain="${plain:0:$((cols-1))}"; fi
  if [ "${SIYI_PROGRESS_HEADING_PRINTED:-0}" -eq 0 ]; then
    printf "%sInstalling, SIYI PI Control System%s\n\n" "$SIYI_BLUE" "$SIYI_RESET" >&3
    SIYI_PROGRESS_HEADING_PRINTED=1
  fi
  printf "\r\033[2K%s%s%s" "$SIYI_GREEN" "$plain" "$SIYI_RESET" >&3
}
stop_progress_anim() {
  if [ -n "${PROGRESS_ANIM_PID:-}" ]; then
    kill "$PROGRESS_ANIM_PID" >/dev/null 2>&1 || true
    wait "$PROGRESS_ANIM_PID" >/dev/null 2>&1 || true
    PROGRESS_ANIM_PID=""
  fi
}

progress() {
  local pct="$1" msg="$2" target cur
  stop_progress_anim
  CURRENT_STEP_NAME="$msg"
  PROGRESS_LAST="$pct"
  draw_progress "$pct" "$msg" "$((SECONDS-INSTALL_START_TS))"
  target="$(progress_next_target "$pct")"
  if [ "$pct" -ge 100 ]; then
    stop_progress_anim
    draw_progress 100 "$msg" "$((SECONDS-INSTALL_START_TS))"
    printf "\n" >&3
    return
  fi
  (
    SIYI_PROGRESS_BACKGROUND=1
    cur="$pct"
    while true; do
      sleep 1
      elapsed=$((SECONDS-INSTALL_START_TS))
      if [ "$cur" -lt "$target" ]; then cur=$((cur+1)); fi
      draw_progress "$cur" "$msg" "$elapsed"
    done
  ) &
  PROGRESS_ANIM_PID="$!"
}

run_logged() {
  local description="$1"; shift
  echo "=== $description ==="
  "$@"
}

die() { echo "INSTALL FAILED: $*"; return 1; }

cleanup_target_transients() {
  rm -rf "/tmp/siyi-mediamtx-$TX" /home/pi/siyi-bridge-venv.new /home/pi/mavlink-router-build
}

restore_existing_pi_groups() {
  [ -f "$TX_DIR/pi-user-existed" ] || return 0
  [ -f "$TX_DIR/pi-supplementary-groups-before" ] || return 1
  id pi >/dev/null 2>&1 || return 1
  local wanted actual csv
  wanted="$(sort -u "$TX_DIR/pi-supplementary-groups-before" | sed '/^$/d')"
  csv="$(printf '%s\n' "$wanted" | paste -sd, -)"
  usermod -G "$csv" pi >/dev/null 2>&1 || return 1
  actual="$(id -Gn pi | tr ' ' '\n' | grep -vx "$(id -gn pi)" | sort -u || true)"
  [ "$actual" = "$wanted" ]
}

remove_created_pi_identity() {
  local warning=0
  if [ -f "$TX_DIR/pi-user-created" ]; then
    pkill -u pi >/dev/null 2>&1 || true
    userdel pi >/dev/null 2>&1 || warning=1
    id pi >/dev/null 2>&1 && warning=1
  fi
  if [ -f "$TX_DIR/pi-group-created" ]; then
    groupdel pi >/dev/null 2>&1 || warning=1
    getent group pi >/dev/null 2>&1 && warning=1
  fi
  return "$warning"
}

refresh_new_packages() {
  [ -f "$TX_DIR/packages-before.tsv" ] || return 0
  dpkg-query -W -f='${binary:Package}\t${Version}\n' 2>/dev/null | sort -u >"$TX_DIR/packages-current.tsv"
  python3 - "$TX_DIR/packages-before.tsv" "$TX_DIR/packages-current.tsv" "$TX_DIR/new-packages.txt" <<'PYPKGREFRESH'
import sys
before,current,out=sys.argv[1:]
def read(path):
 d={}
 for line in open(path,encoding='utf-8',errors='replace'):
  parts=line.rstrip('\n').split('\t',1)
  if len(parts)==2:d[parts[0]]=parts[1]
 return d
b,c=read(before),read(current)
changed=[p for p in b if c.get(p)!=b[p]]
if changed: raise SystemExit('pre-existing package state changed: '+','.join(changed))
open(out,'w').write(''.join(p+'\n' for p in sorted(set(c)-set(b))))
PYPKGREFRESH
}

verify_package_state() {
  [ -f "$TX_DIR/packages-before.tsv" ] || return 0
  dpkg-query -W -f='${binary:Package}\t${Version}\n' 2>/dev/null | sort -u >"$TX_DIR/packages-restored.tsv"
  cmp -s "$TX_DIR/packages-before.tsv" "$TX_DIR/packages-restored.tsv"
}

record_rollback_failure() {
  local reason="${1:-rollback_incomplete}"
  printf '%s\n' "$(date -Is) reason=$reason tx=$TX_DIR" >"$TX_DIR/ROLLBACK_FAILED" 2>/dev/null || true
  install -d -o root -g root -m 0755 /var/lib/siyi-installer >/dev/null 2>&1 || true
  printf '%s\n' "$TX_DIR" >/var/lib/siyi-installer/last_rollback_failure 2>/dev/null || true
  install -d -o root -g root -m 0775 /etc/siyi >/dev/null 2>&1 || true
  if [ -z "${SIYI_SOURCE_RELEASE:-}" ]; then
    printf '%s\n' "$VERSION" >/etc/siyi/release_version 2>/dev/null || true
    printf '%s\n' "$BUILD_ID" >/etc/siyi/release_build 2>/dev/null || true
  fi
  printf '%s\n' rollback_failed >/etc/siyi/release_status 2>/dev/null || true
}

restore_unit_states() {
  local state_file="$TX_DIR/unit-state.tsv" unit expected_enabled expected_active actual warning=0
  [ -f "$state_file" ] || return 0
  unit_enabled_state() { local v; v="$(sudo systemctl is-enabled "$1" 2>/dev/null || true)"; [ -n "$v" ] || v=not-found; printf '%s\n' "$v"; }
  unit_active_state() { local v; v="$(sudo systemctl is-active "$1" 2>/dev/null || true)"; [ -n "$v" ] || v=inactive; printf '%s\n' "$v"; }
  sudo systemctl daemon-reload >/dev/null 2>&1 || warning=1
  while IFS=$'\t' read -r unit expected_enabled expected_active; do
    [ -n "$unit" ] || continue
    sudo systemctl unmask --runtime "$unit" >/dev/null 2>&1 || true
    sudo systemctl unmask "$unit" >/dev/null 2>&1 || true
    sudo systemctl disable --runtime "$unit" >/dev/null 2>&1 || true
    sudo systemctl disable "$unit" >/dev/null 2>&1 || true
    case "$expected_enabled" in
      masked) sudo systemctl mask "$unit" >/dev/null 2>&1 || warning=1 ;;
      masked-runtime) sudo systemctl mask --runtime "$unit" >/dev/null 2>&1 || warning=1 ;;
      enabled) sudo systemctl enable "$unit" >/dev/null 2>&1 || warning=1 ;;
      enabled-runtime) sudo systemctl enable --runtime "$unit" >/dev/null 2>&1 || warning=1 ;;
      disabled|static|indirect|generated|transient|alias|not-found) : ;;
      *) echo "Unsupported captured enable state for exact rollback: $unit=$expected_enabled"; warning=1 ;;
    esac
  done <"$state_file"
  sudo systemctl daemon-reload >/dev/null 2>&1 || warning=1
  for unit in NetworkManager.service zerotier-one.service serial-getty@serial0.service serial-getty@ttyS0.service serial-getty@ttyAMA0.service "${SIYI_MANAGED_UNITS[@]}"; do
    expected_enabled="$(awk -F '\t' -v u="$unit" '$1==u{print $2; exit}' "$state_file")"
    expected_active="$(awk -F '\t' -v u="$unit" '$1==u{print $3; exit}' "$state_file")"
    [ -n "$expected_active" ] || continue
    case "$expected_active" in
      active) sudo systemctl start "$unit" >/dev/null 2>&1 || warning=1 ;;
      inactive)
        if [ "$expected_enabled" != not-found ]; then
          sudo systemctl stop "$unit" >/dev/null 2>&1 || [ "$(unit_active_state "$unit")" = inactive ] || warning=1
        fi
        sudo systemctl reset-failed "$unit" >/dev/null 2>&1 || true
        ;;
      *) echo "Unsupported captured active state for exact rollback: $unit=$expected_active"; warning=1 ;;
    esac
  done
  while IFS=$'\t' read -r unit expected_enabled expected_active; do
    [ -n "$unit" ] || continue
    actual="$(unit_enabled_state "$unit")"; [ "$actual" = "$expected_enabled" ] || { echo "Enable-state verify failed: $unit expected=$expected_enabled actual=$actual"; warning=1; }
    actual="$(unit_active_state "$unit")"; [ "$actual" = "$expected_active" ] || { echo "Active-state verify failed: $unit expected=$expected_active actual=$actual"; warning=1; }
  done <"$state_file"
  return "$warning"
}


rollback_transaction() {
  local original_rc="$1" rollback_warning=0 unit map_cache_state map_cache_uid map_cache_gid map_cache_mode
  set +e
  echo "=== ROLLBACK START: transaction $TX, original exit $original_rc ==="

  # SIYI_4_2_0_ROLLBACK_SERVICE_STATE_GUARD_V21
  # Do not touch a pre-existing installation when route selection, sudo,
  # platform checks, or an already-installed check fails before service state
  # has been captured.
  if [ "$SERVICE_STATE_READY" -eq 1 ]; then
    sudo systemctl stop "${SIYI_MANAGED_UNITS[@]}" >/dev/null 2>&1 || true
    for unit in "${SIYI_MANAGED_UNITS[@]}"; do
      sudo systemctl disable --runtime "$unit" >/dev/null 2>&1 || true
      sudo systemctl disable "$unit" >/dev/null 2>&1 || true
    done
  fi

  refresh_new_packages || rollback_warning=1
  if [ -s "$TX_DIR/new-packages.txt" ]; then
    mapfile -t _siyi_new_packages <"$TX_DIR/new-packages.txt"
    sudo -E apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 purge -y "${_siyi_new_packages[@]}" || rollback_warning=1
  fi
  verify_package_state || rollback_warning=1

  if [ "$VENV_SWAPPED" -eq 1 ]; then
    sudo rm -rf /home/pi/siyi-bridge-venv || rollback_warning=1
    if [ -d "$TX_DIR/siyi-bridge-venv.previous" ]; then
      sudo mv "$TX_DIR/siyi-bridge-venv.previous" /home/pi/siyi-bridge-venv || rollback_warning=1
      sudo chown -R pi:pi /home/pi/siyi-bridge-venv >/dev/null 2>&1 || rollback_warning=1
    fi
  fi

  cleanup_target_transients || rollback_warning=1

  if [ "$SNAPSHOT_READY" -eq 1 ]; then
    if (cd "$TX_DIR" && sha256sum -c recovery-helper.sha256); then
      sudo python3 "$TX_DIR/transaction-restore.py" "$MANIFEST" "$TX_DIR/backup-index.json" "$TX_DIR/backup-root" || rollback_warning=1
    else
      rollback_warning=1
    fi
  fi

  if [ "$MARKER_SNAPSHOT_READY" -eq 1 ] && [ -f "$TX_DIR/marker-state.json" ]; then
    sudo python3 - "$TX_DIR/marker-state.json" "$TX_DIR/marker-backup" <<'PYMARKERRESTORE' || rollback_warning=1
import json, os, shutil, sys
state_path, backup_root = sys.argv[1:]
state = json.load(open(state_path, encoding='utf-8'))
for path, info in state.items():
    if os.path.isdir(path) and not os.path.islink(path):
        shutil.rmtree(path)
    elif os.path.lexists(path):
        os.unlink(path)
    if info.get('exists'):
        src = os.path.join(backup_root, path.lstrip('/'))
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if os.path.islink(src):
            os.symlink(os.readlink(src), path)
        elif os.path.isfile(src):
            shutil.copy2(src, path, follow_symlinks=False)
        else:
            raise SystemExit(f'missing marker backup: {path}')
PYMARKERRESTORE
  fi

  if [ "$CAM_PROFILE_CREATED" -eq 1 ]; then
    sudo nmcli connection delete cam-eth0 >/dev/null 2>&1 || rollback_warning=1
  elif [ -f "$TX_DIR/cam-profile-state.tsv" ]; then
    while IFS=$'	' read -r key value; do
      [ -n "$key" ] || continue
      sudo nmcli connection modify cam-eth0 "$key" "$value" >/dev/null 2>&1 || rollback_warning=1
    done <"$TX_DIR/cam-profile-state.tsv"
    if [ -f "$TX_DIR/cam-profile-was-active" ]; then sudo nmcli connection up cam-eth0 >/dev/null 2>&1 || rollback_warning=1; else sudo nmcli connection down cam-eth0 >/dev/null 2>&1 || true; fi
  fi

  # SIYI_4_2_0_MAPTILER_CACHE_ROLLBACK_V21
  if [ "$MAPTILER_CACHE_STATE_READY" -eq 1 ] && [ -f "$TX_DIR/maptiler-cache-state" ]; then
    map_cache_state="$(cat "$TX_DIR/maptiler-cache-state" 2>/dev/null || true)"
    if [ "$map_cache_state" = "absent" ]; then
      sudo rm -rf /var/cache/siyi-maptiler || rollback_warning=1
    elif [ -n "$map_cache_state" ]; then
      read -r map_cache_uid map_cache_gid map_cache_mode <<<"$map_cache_state"
      sudo chown "$map_cache_uid:$map_cache_gid" /var/cache/siyi-maptiler >/dev/null 2>&1 || rollback_warning=1
      sudo chmod "$map_cache_mode" /var/cache/siyi-maptiler >/dev/null 2>&1 || rollback_warning=1
    fi
  fi

  if [ "$TARGET_RELEASE_TREE_MUTATED" -eq 1 ] || [ -f "$TX_DIR/target-release-tree-mutated" ]; then
    sudo rm -rf "/usr/local/share/siyi/releases/$VERSION" >/dev/null 2>&1 || rollback_warning=1
  fi
  if { [ "$TARGET_RELEASE_TREE_MUTATED" -eq 1 ] || [ -f "$TX_DIR/target-release-tree-mutated" ]; } && [ -n "${SIYI_SOURCE_RELEASE:-}" ] && [ -f "$TX_DIR/source-release-tree.ready" ] && [ -d "$TX_DIR/source-release-tree" ]; then
    sudo install -d -o root -g root -m 0755 /usr/local/share/siyi/releases
    sudo rm -rf "/usr/local/share/siyi/releases/$SIYI_SOURCE_RELEASE" >/dev/null 2>&1 || true
    sudo cp -a "$TX_DIR/source-release-tree" "/usr/local/share/siyi/releases/$SIYI_SOURCE_RELEASE" || rollback_warning=1
  fi
  sudo rm -f /var/lib/siyi-installer/pending-transaction >/dev/null 2>&1 || true
  sudo systemctl daemon-reload >/dev/null 2>&1 || rollback_warning=1

  # Restore exact captured enable/mask/active states.
  if [ "$UNIT_STATE_READY" -eq 1 ]; then
    restore_unit_states || rollback_warning=1
  fi
  restore_existing_pi_groups || rollback_warning=1
  remove_created_pi_identity || rollback_warning=1

  if [ "$rollback_warning" -eq 0 ]; then
    ROLLBACK_RESULT="Complete"
  else
    record_rollback_failure "pre_reboot_rollback_incomplete"
    ROLLBACK_RESULT="FAILED: rollback was incomplete; release status marked rollback_failed"
  fi
  echo "=== ROLLBACK END: $ROLLBACK_RESULT ==="
  set -e
}

on_failure() {
  local rc="$1"
  trap - ERR INT TERM
  stop_progress_anim || true
  cp -a "$INSTALL_LOG" "$TX_DIR/pre-rollback-install.log" 2>/dev/null || true
  if [ "${SIYI_ROUTE:-}" = fresh ] && [ "${FRESH_DEPENDENCY_PHASE:-0}" -eq 1 ] && [ "$SNAPSHOT_READY" -eq 0 ] && [ "$TARGET_RELEASE_TREE_MUTATED" -eq 0 ]; then
    printf '%s\n' "$(date -Is) step=${CURRENT_STEP_NAME:-dependencies} exit=$rc" >"$TX_DIR/FRESH_DEPENDENCY_FAILED" 2>/dev/null || true
    ROLLBACK_RESULT="Not required: SIYI deployment had not started; prepared OS package state retained"
    echo "=== FRESH DEPENDENCY PREPARATION FAILED BEFORE SIYI DEPLOYMENT ==="
  else
    rollback_transaction "$rc"
  fi
  printf "\n\n" >&3
  echo "========================================" >&3
  echo "❌ SIYI INSTALL FAILED" >&3
  echo "========================================" >&3
  echo "Step: ${CURRENT_STEP_NAME:-starting}" >&3
  echo "Exit code: $rc" >&3
  echo "Rollback: $ROLLBACK_RESULT" >&3
  echo "Transaction: $TX_DIR" >&3
  echo "Full log:" >&3
  echo "$INSTALL_LOG" >&3
  echo >&3
  exit "$rc"
}
trap 'on_failure $?' ERR
trap 'on_failure 130' INT
trap 'on_failure 143' TERM

# Canonical 3.1.12 first-install introduction.
echo "=== SIYI Public Installer $VERSION ==="
echo "Full log: $INSTALL_LOG" >&3
echo >&3
command -v sudo >/dev/null 2>&1 || die "sudo is required."
sudo -v
install -d -o root -g root -m 0755 /var/log/siyi-installer /var/lib/siyi-installer
install -d -o root -g root -m 0700 /var/lib/siyi-installer/transactions
install -d -o root -g root -m 0700 "$TX_DIR" "$TX_DIR/backup-root" "$TX_DIR/marker-backup"
ln -sfn "$INSTALL_LOG" "$TX_LOG"
# Snapshot release markers before route selection or any install changes. This
# guarantees a failed fresh install restores "absent" rather than leaving a
# false 4.2.0 marker that blocks the next recovery run.
sudo python3 - "$TX_DIR/marker-state.json" "$TX_DIR/marker-backup" <<'PYMARKERSNAPSHOT'
import json, os, shutil, sys
state_path, backup_root = sys.argv[1:]
markers = ['/etc/siyi/release_version', '/etc/siyi/release_build', '/etc/siyi/release_status']
state = {}
os.makedirs(backup_root, exist_ok=True)
for path in markers:
    exists = os.path.lexists(path)
    state[path] = {'exists': exists}
    if exists:
        dst = os.path.join(backup_root, path.lstrip('/'))
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if os.path.islink(path):
            os.symlink(os.readlink(path), dst)
        elif os.path.isfile(path):
            shutil.copy2(path, dst, follow_symlinks=False)
        else:
            raise SystemExit(f'unsupported release-marker type: {path}')
with open(state_path, 'w', encoding='utf-8') as f:
    json.dump(state, f, indent=2, sort_keys=True)
PYMARKERSNAPSHOT
MARKER_SNAPSHOT_READY=1

progress 5 "Preparing installer"
[ "$(uname -m)" = aarch64 ] || die "4.2.1 supports Raspberry Pi OS 64-bit (aarch64) only."
OS_ID="$(. /etc/os-release; printf '%s' "${ID:-}")"
OS_VERSION_ID="$(. /etc/os-release; printf '%s' "${VERSION_ID:-}")"
case "$OS_ID" in debian|raspbian) ;; *) die "Unsupported OS ${OS_ID:-unknown}" ;; esac
[ "$OS_VERSION_ID" = 13 ] || die "4.2.1 requires Raspberry Pi OS / Debian 13."
[ -r /proc/device-tree/model ] || die "Raspberry Pi hardware was not detected."
model="$(tr -d '\0' </proc/device-tree/model)"
case "$model" in *"Raspberry Pi 3 Model B Plus"*|*"Raspberry Pi 4 Model B"*|*"Raspberry Pi 5"*) ;; *) die "Unsupported Raspberry Pi model: $model" ;; esac
free_kb="$(df -Pk / | awk 'NR==2{print $4}')"
[ "$free_kb" -ge 2097152 ] || die "At least 2 GiB free space is required."
release_marker=/etc/siyi/release_version
read_text_marker() {
  python3 - "$1" <<'PYREADTEXT'
import os,sys
p=sys.argv[1]
try:
    raw=open(p,'rb').read().decode('utf-8-sig','replace')
except FileNotFoundError:
    raw=''
print(raw.replace('\x00','').strip())
PYREADTEXT
}
read_semver_marker() {
  python3 - "$1" <<'PYREADVERSION'
import re,sys
p=sys.argv[1]
try:
    raw=open(p,'rb').read().decode('utf-8-sig','replace').replace('\x00','')
except FileNotFoundError:
    raw=''
m=re.search(r'(?<!\d)(\d+\.\d+\.\d+)(?!\d)',raw)
print(m.group(1) if m else '')
PYREADVERSION
}
interrupted_421_evidence() {
  if [ -r /usr/local/share/siyi/releases/4.2.1/release-metadata.json ]; then
    python3 - /usr/local/share/siyi/releases/4.2.1/release-metadata.json <<'PYINTEVIDENCE'
import json,sys
try:
    print(1 if str(json.load(open(sys.argv[1],encoding='utf-8')).get('version','')).strip()=='4.2.1' else 0)
except Exception:
    print(0)
PYINTEVIDENCE
    return
  fi
  while IFS= read -r marker; do
    tx="${marker%/target-release}"
    if [ "$(tr -d '[:space:]' <"$marker" 2>/dev/null || true)" = "4.2.1" ] && [ -f "$tx/backup-index.json" ]; then
      echo 1
      return
    fi
  done < <(sudo find /var/lib/siyi-installer/transactions -mindepth 2 -maxdepth 2 -type f -name target-release -print 2>/dev/null)
  echo 0
}
# SIYI_4_2_1_COMPLETE_TARGET_MODEL_V19
current=""
current_build=""
current_status="$(read_text_marker /etc/siyi/release_status)"
if [ "$current_status" = rollback_failed ]; then
  die "A previous rollback is incomplete (release_status=rollback_failed). Manual recovery and evidence review are required before another install."
fi
SIYI_ROUTE="fresh"
SIYI_SOURCE_RELEASE=""
SIYI_SOURCE_BUILD=""
SIYI_SOURCE_VARIANT="clean_os"
if [ -e "$release_marker" ]; then
  current="$(read_semver_marker "$release_marker")"
  current_build="$(read_text_marker /etc/siyi/release_build)"
  current_status="$(read_text_marker /etc/siyi/release_status)"
  echo "=== Existing marker: version=${current:-unreadable} build=${current_build:-unknown} status=${current_status:-unknown} ==="
  if [ "$current" = "4.2.0" ]; then
    case "$current_status" in accepted|core_accepted_hardware_pending) ;; *) die "Upgrade refused: source 4.2.0 status ${current_status:-missing} is not accepted.";; esac
    [ "$current_build" = "SIYI_4_2_0_RELEASE_CANDIDATE_V23" ] || die "Upgrade refused: unrecognized 4.2.0 build ${current_build:-missing}."
    SIYI_SOURCE_VARIANT="$(python3 "$SCRIPT_DIR/verify-source-4.2.0.py" \
      --identity "$SCRIPT_DIR/source-identity-4.2.0.json" \
      --manifest "$SCRIPT_DIR/source-payload-manifest-4.2.0.json" \
      --json-output "$TX_DIR/source-verification.json")" || die "Upgrade refused: complete 4.2.0 managed-file identity verification failed."
    [ -n "$SIYI_SOURCE_VARIANT" ] || die "Upgrade refused: approved source variant was not identified."
    SIYI_ROUTE="upgrade"
    SIYI_SOURCE_RELEASE="4.2.0"
    SIYI_SOURCE_BUILD="$current_build"
    echo "=== Approved upgrade route: $SIYI_SOURCE_RELEASE/$SIYI_SOURCE_BUILD/$SIYI_SOURCE_VARIANT -> $VERSION/$BUILD_ID ==="
    source_health="/usr/local/share/siyi/releases/4.2.0/health-check.sh"
    [ -x "$source_health" ] || die "Upgrade refused: source health check is missing."
    source_health_json="$TX_DIR/source-health.json"
    source_health_log="$TX_DIR/source-health.log"
    source_health_rc=0
    # The source health check is expected to return nonzero while the native
    # WebUI upgrade intentionally locks /groundstation and /parameters. Keep
    # the command in an if-condition: Bash ERR traps are active even after
    # merely disabling errexit, so the older pattern incorrectly launched rollback before the
    # maintenance gate could inspect the intentional HTTP 423 state.
    if sudo "$source_health" --json-output "$source_health_json" >"$source_health_log" 2>&1; then
      source_health_rc=0
    else
      source_health_rc=$?
    fi
    cat "$source_health_log"
    if [ "$source_health_rc" -ne 0 ]; then
      [ -r /var/lib/siyi-upgrade/state.json ] || die "Upgrade refused: native-upgrade state is missing while WebUI pages are locked."
      python3 "$SCRIPT_DIR/source-health-gate.py" \
        --health-json "$source_health_json" \
        --upgrade-state /var/lib/siyi-upgrade/state.json \
        --snapshot-output "$TX_DIR/source-upgrade-state.json" \
        --source-version 4.2.0 --target-version "$VERSION" \
        --evidence-output "$TX_DIR/source-health-gate.json" \
        || die "Upgrade refused: source 4.2.0 core health check failed."
      cat "$TX_DIR/source-health-gate.json"
      echo "=== Source health accepted during intentional native-upgrade WebUI lock ==="
    fi
  elif [ "$current" = "$VERSION" ]; then
    if [ "$REPAIR" -eq 1 ]; then
      SIYI_ROUTE="repair"
      SIYI_SOURCE_RELEASE="$VERSION"
      SIYI_SOURCE_BUILD="$current_build"
      SIYI_SOURCE_VARIANT="same_version_repair"
      echo "=== Repairing existing $VERSION installation ==="
    elif [ "$current_status" = accepted ] || [ "$current_status" = core_accepted_hardware_pending ]; then
      die "$VERSION is already installed. Use --repair for a verified reinstall."
    else
      [ "$(interrupted_421_evidence)" = 1 ] || die "Unverified interrupted $VERSION state; refusing recovery."
      SIYI_ROUTE="recovery"
      SIYI_SOURCE_RELEASE="$VERSION"
      SIYI_SOURCE_BUILD="$current_build"
      SIYI_SOURCE_VARIANT="interrupted_target_recovery"
      echo "=== Recovering interrupted $VERSION installation ==="
    fi
  elif [ -z "$current" ] && [ "$(interrupted_421_evidence)" = 1 ]; then
    SIYI_ROUTE="recovery"
    SIYI_SOURCE_RELEASE="$VERSION"
    SIYI_SOURCE_BUILD="$current_build"
    SIYI_SOURCE_VARIANT="malformed_target_marker_recovery"
    echo "=== Recovering interrupted $VERSION installation with malformed stale marker ==="
  else
    die "Upgrade from ${current:-invalid-marker} is unsupported. Supported routes: fresh OS or genuine 4.2.0."
  fi
elif [ -e /home/pi/siyi-webui/server.py ] || sudo systemctl list-unit-files 'siyi-*.service' --no-legend 2>/dev/null | grep -q .; then
  [ "$(interrupted_421_evidence)" = 1 ] || die "An unversioned existing SIYI installation was detected. Fresh install requires a freshly flashed OS."
  SIYI_ROUTE="recovery"
  SIYI_SOURCE_RELEASE="$VERSION"
  SIYI_SOURCE_VARIANT="unversioned_target_recovery"
  echo "=== Recovering interrupted $VERSION installation ==="
fi
export SIYI_ROUTE SIYI_SOURCE_RELEASE SIYI_SOURCE_BUILD SIYI_SOURCE_VARIANT
echo "$VERSION" >"$TX_DIR/target-release"
echo "$SIYI_ROUTE" >"$TX_DIR/install-route"
echo "$SIYI_SOURCE_RELEASE" >"$TX_DIR/source-release"
echo "$SIYI_SOURCE_BUILD" >"$TX_DIR/source-build"
echo "$SIYI_SOURCE_VARIANT" >"$TX_DIR/source-variant"
echo "$current_status" >"$TX_DIR/source-status"
echo "$PRESERVE_CSV" >"$TX_DIR/preserve-groups"
echo "$REMEMBER_SELECTION" >"$TX_DIR/preserve-remember"
if [ -n "$SIYI_SOURCE_RELEASE" ] && [ -d "/usr/local/share/siyi/releases/$SIYI_SOURCE_RELEASE" ]; then
  rm -rf "$TX_DIR/source-release-tree.partial" "$TX_DIR/source-release-tree"
  cp -a "/usr/local/share/siyi/releases/$SIYI_SOURCE_RELEASE" "$TX_DIR/source-release-tree.partial"
  mv "$TX_DIR/source-release-tree.partial" "$TX_DIR/source-release-tree"
  touch "$TX_DIR/source-release-tree.ready"
fi
sudo install -o root -g root -m 0644 "$MANIFEST" "$TX_DIR/target-payload-manifest.json"
sudo install -o root -g root -m 0644 "$MANIFEST" "$TX_DIR/payload-manifest.json"
sudo install -o root -g root -m 0644 "$SCRIPT_DIR/release-metadata.json" "$TX_DIR/release-metadata.json"
sudo install -o root -g root -m 0700 "$SCRIPT_DIR/health-check.sh" "$TX_DIR/health-check.sh"

[ -f "$SCRIPT_DIR/transaction-backup.py" ] || die "Transaction backup helper is missing."
[ -f "$SCRIPT_DIR/transaction-restore.py" ] || die "Transaction restore helper is missing."
[ -f "$PAYLOAD/usr/local/sbin/siyi-rollback-transaction" ] || die "Rollback engine is missing from the target payload."
install -o root -g root -m 0600 "$SCRIPT_DIR/transaction-restore.py" "$TX_DIR/transaction-restore.py"
install -o root -g root -m 0700 "$PAYLOAD/usr/local/sbin/siyi-rollback-transaction" "$TX_DIR/siyi-rollback-transaction"
printf '%s  %s\n' "$(sha256sum "$TX_DIR/transaction-restore.py" | awk '{print $1}')" transaction-restore.py >"$TX_DIR/recovery-helper.sha256"
printf '%s  %s\n' "$(sha256sum "$TX_DIR/siyi-rollback-transaction" | awk '{print $1}')" siyi-rollback-transaction >>"$TX_DIR/recovery-helper.sha256"
printf '%s  %s\n' "$(sha256sum "$TX_DIR/payload-manifest.json" | awk '{print $1}')" payload-manifest.json >>"$TX_DIR/recovery-helper.sha256"
printf '%s  %s\n' "$(sha256sum "$TX_DIR/release-metadata.json" | awk '{print $1}')" release-metadata.json >>"$TX_DIR/recovery-helper.sha256"
printf '%s  %s\n' "$(sha256sum "$TX_DIR/health-check.sh" | awk '{print $1}')" health-check.sh >>"$TX_DIR/recovery-helper.sha256"
python3 - "$PAYLOAD" "$MANIFEST" <<'PYVERIFY'
import hashlib,json,os,sys
root,manifest=sys.argv[1:]
data=json.load(open(manifest,encoding='utf-8'))
for item in data['files']:
    p=os.path.join(root,item['path'].lstrip('/'))
    if item['type']=='directory':
        if not os.path.isdir(p): raise SystemExit('missing directory '+item['path'])
    elif item['type']=='symlink':
        if not os.path.islink(p): raise SystemExit('missing symlink '+item['path'])
        if hashlib.sha256(os.readlink(p).encode()).hexdigest()!=item['sha256']: raise SystemExit('symlink checksum mismatch '+item['path'])
    else:
        if not os.path.isfile(p): raise SystemExit('missing file '+item['path'])
        if hashlib.sha256(open(p,'rb').read()).hexdigest()!=item['sha256']: raise SystemExit('checksum mismatch '+item['path'])
PYVERIFY

# SIYI_4_2_1_FRESH_DEPENDENCY_BASELINE_V1
# Fresh-OS dependencies are prepared before the SIYI transaction baseline is
# captured. Package upgrades explicitly required by the dependency solver are
# valid OS preparation, not target-deployment drift. A later SIYI rollback
# therefore returns to this prepared clean-OS baseline rather than trying to
# downgrade repository packages that may no longer be available.
progress 10 "Validating operating-system dependencies"
export DEBIAN_FRONTEND=noninteractive APT_LISTCHANGES_FRONTEND=none
mapfile -t packages < <(grep -Ev '^($|#)' "$SCRIPT_DIR/apt-packages.txt")
if [ "$SIYI_ROUTE" = upgrade ] || [ "$SIYI_ROUTE" = repair ]; then
  missing=()
  for package in "${packages[@]}" zerotier-one; do dpkg-query -W -f='${db:Status-Abbrev}' "$package" 2>/dev/null | grep -q '^ii ' || missing+=("$package"); done
  [ "${#missing[@]}" -eq 0 ] || die "Approved-source dependency drift detected; missing packages: ${missing[*]}"
else
  FRESH_DEPENDENCY_PHASE=1
  dpkg-query -W -f='${binary:Package}\t${Version}\n' 2>/dev/null | sort -u >"$TX_DIR/packages-pre-provision.tsv"
  sudo install -D -o root -g root -m 0644 "$PAYLOAD/usr/share/keyrings/zerotier-debian-package-key.gpg" /usr/share/keyrings/zerotier-debian-package-key.gpg
  sudo install -D -o root -g root -m 0644 "$PAYLOAD/etc/apt/sources.list.d/zerotier.list" /etc/apt/sources.list.d/zerotier.list
  run_logged "Updating package indexes" sudo -E apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 update
  sudo -E apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 -s --no-upgrade install -y --no-install-recommends "${packages[@]}" zerotier-one >"$TX_DIR/apt-install-simulation.txt"
  python3 - "$TX_DIR/packages-pre-provision.tsv" "$TX_DIR/apt-install-simulation.txt" "$TX_DIR/apt-provision-plan.json" <<'PYAPTPLAN'
import json,re,sys
before,simulation,out=sys.argv[1:]
installed={}
for line in open(before,encoding='utf-8',errors='replace'):
    parts=line.rstrip('\n').split('\t',1)
    if len(parts)==2: installed[parts[0].split(':',1)[0]]=parts[1]
planned=[]
for line in open(simulation,encoding='utf-8',errors='replace'):
    if not line.startswith('Inst '): continue
    package=line.split()[1].split(':',1)[0]
    if package not in planned: planned.append(package)
json.dump({'schema_version':1,'installed_before':len(installed),'planned_package_actions':planned},open(out,'w'),indent=2,sort_keys=True)
open(out,'a').write('\n')
PYAPTPLAN
  run_logged "Installing required operating-system packages" sudo -E apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 --no-upgrade install -y --no-install-recommends "${packages[@]}"
  progress 25 "Installing ZeroTier"
  run_logged "Installing ZeroTier" sudo -E apt-get -o Dpkg::Use-Pty=0 -o APT::Color=0 --no-upgrade install -y --no-install-recommends zerotier-one
  dpkg-query -W -f='${binary:Package}\t${Version}\n' 2>/dev/null | sort -u >"$TX_DIR/packages-provisioned.tsv"
  python3 - "$TX_DIR/packages-pre-provision.tsv" "$TX_DIR/packages-provisioned.tsv" "$TX_DIR/apt-provision-plan.json" "$TX_DIR/apt-provision-result.json" <<'PYPACKAGES'
import json,sys
before,after,plan_path,out=sys.argv[1:]
def read(p):
    d={}
    for line in open(p,encoding='utf-8',errors='replace'):
        parts=line.rstrip('\n').split('\t',1)
        if len(parts)==2:d[parts[0]]=parts[1]
    return d
b,a=read(before),read(after)
new=sorted(set(a)-set(b)); removed=sorted(set(b)-set(a))
upgraded=sorted(({'package':p,'before':b[p],'after':a[p]} for p in b if p in a and b[p]!=a[p]),key=lambda x:x['package'])
planned=set(json.load(open(plan_path,encoding='utf-8'))['planned_package_actions'])
unplanned=sorted(({p.split(':',1)[0] for p in new}|{x['package'].split(':',1)[0] for x in upgraded})-planned)
result={'schema_version':1,'new_packages':new,'upgraded_packages':upgraded,'removed_packages':removed,'unplanned_changes':unplanned}
json.dump(result,open(out,'w'),indent=2,sort_keys=True); open(out,'a').write('\n')
if removed: raise SystemExit('dependency provisioning removed pre-existing packages: '+','.join(removed))
if unplanned: raise SystemExit('dependency provisioning made unplanned package changes: '+','.join(unplanned))
PYPACKAGES
  for package in "${packages[@]}" zerotier-one; do dpkg-query -W -f='${db:Status-Abbrev}' "$package" 2>/dev/null | grep -q '^ii ' || die "Dependency provisioning incomplete: $package"; done
fi
# This is the package baseline for every subsequent SIYI mutation and rollback.
dpkg-query -W -f='${binary:Package}\t${Version}\n' 2>/dev/null | sort -u >"$TX_DIR/packages-before.tsv"
run_logged "Verifying MAVLink Router systemd build metadata" pkg-config --exists systemd
FRESH_DEPENDENCY_PHASE=0

 : >"$TX_DIR/managed-active-units.txt"
: >"$TX_DIR/managed-enabled-units.txt"
: >"$TX_DIR/unit-state.tsv"
STATE_TRACKED_UNITS=("${SIYI_MANAGED_UNITS[@]}" NetworkManager.service zerotier-one.service serial-getty@serial0.service serial-getty@ttyS0.service serial-getty@ttyAMA0.service)
for unit in "${SIYI_MANAGED_UNITS[@]}"; do
  sudo systemctl is-active --quiet "$unit" 2>/dev/null && echo "$unit" >>"$TX_DIR/managed-active-units.txt" || true
  sudo systemctl is-enabled --quiet "$unit" 2>/dev/null && echo "$unit" >>"$TX_DIR/managed-enabled-units.txt" || true
done
for unit in "${STATE_TRACKED_UNITS[@]}"; do
  enabled="$(sudo systemctl is-enabled "$unit" 2>/dev/null || true)"; [ -n "$enabled" ] || enabled=unknown
  active="$(sudo systemctl is-active "$unit" 2>/dev/null || true)"; [ -n "$active" ] || active=unknown
  case "$enabled" in enabled|enabled-runtime|disabled|masked|masked-runtime|static|indirect|generated|transient|alias|not-found) ;; *) die "Source unit state cannot be restored exactly: $unit enabled=$enabled";; esac
  case "$active" in active|inactive) ;; *) die "Source unit state cannot be restored exactly: $unit active=$active";; esac
  printf '%s\t%s\t%s\n' "$unit" "$enabled" "$active" >>"$TX_DIR/unit-state.tsv"
done
UNIT_STATE_READY=1
SERVICE_STATE_READY=1
sudo systemctl stop "${SIYI_MANAGED_UNITS[@]}" >/dev/null 2>&1 || true
sudo python3 "$SCRIPT_DIR/transaction-backup.py" "$MANIFEST" "$TX_DIR/backup-index.json" "$TX_DIR/backup-root"
SNAPSHOT_READY=1
sudo install -d -o root -g root -m 0700 "$TX_DIR/preserve-root"
sudo python3 - "$SCRIPT_DIR/preservation-model.json" "$TX_DIR/preserve-root" "$TX_DIR/preserve-plan.json" "$SIYI_ROUTE" "$PRESERVE_CSV" <<'PYPRESERVESNAPSHOT'
import hashlib,json,os,shutil,stat,sys
model_path,backup_root,plan_path,route,csv=sys.argv[1:]
model=json.load(open(model_path,encoding='utf-8'))
selected=[x for x in csv.split(',') if x]
unknown=set(selected)-set(model['selectable_groups'])
if unknown: raise SystemExit('unknown preservation groups: '+','.join(sorted(unknown)))
paths=list(model['always_preserve_paths']) if route!='fresh' else []
json_keys={}
if route!='fresh':
  for group in selected:
    spec=model['groups'][group]; paths.extend(spec.get('paths',[]))
    for path,keys in spec.get('json_keys',{}).items(): json_keys.setdefault(path,[]).extend(keys)
entries=[]
os.makedirs(backup_root,exist_ok=True)
for path in dict.fromkeys(paths):
  if not os.path.lexists(path): continue
  st=os.lstat(path); dst=os.path.join(backup_root,path.lstrip('/')); os.makedirs(os.path.dirname(dst),exist_ok=True)
  if stat.S_ISLNK(st.st_mode): os.symlink(os.readlink(path),dst); kind='symlink'; digest=hashlib.sha256(os.readlink(path).encode()).hexdigest()
  elif stat.S_ISREG(st.st_mode): shutil.copy2(path,dst,follow_symlinks=False); kind='file'; digest=hashlib.sha256(open(path,'rb').read()).hexdigest()
  else: raise SystemExit('unsupported preserved path type: '+path)
  entries.append({'path':path,'type':kind,'uid':st.st_uid,'gid':st.st_gid,'mode':stat.S_IMODE(st.st_mode),'sha256':digest})
key_values={}
for path,keys in json_keys.items():
  if not os.path.isfile(path): continue
  try: obj=json.load(open(path,encoding='utf-8'))
  except Exception as exc: raise SystemExit(f'invalid JSON in {path}: {exc}')
  key_values[path]={key:obj[key] for key in dict.fromkeys(keys) if key in obj}
plan={'schema_version':1,'route':route,'selected_groups':selected,'files':entries,'json_key_values':key_values}
json.dump(plan,open(plan_path,'w'),indent=2,sort_keys=True); open(plan_path,'a').write('\n')
PYPRESERVESNAPSHOT



progress 35 "Installing SIYI configuration"
if id pi >/dev/null 2>&1; then
  touch "$TX_DIR/pi-user-existed"
  id -Gn pi | tr ' ' '\n' | grep -vx "$(id -gn pi)" | sort -u >"$TX_DIR/pi-supplementary-groups-before" || true
fi
if ! getent group pi >/dev/null 2>&1; then groupadd pi; touch "$TX_DIR/pi-group-created"; fi
if ! id pi >/dev/null 2>&1; then useradd -m -g pi -s /bin/bash pi; touch "$TX_DIR/pi-user-created"; fi
for group in dialout input video render netdev; do getent group "$group" >/dev/null && usermod -a -G "$group" pi; done
touch "$TX_DIR/target-release-tree-mutated"
TARGET_RELEASE_TREE_MUTATED=1
python3 - "$PAYLOAD" "$MANIFEST" <<'PYDEPLOY'
import grp,json,os,pwd,shutil,stat,sys,tempfile
root,manifest=sys.argv[1:]
data=json.load(open(manifest,encoding='utf-8'))
for item in sorted(data['files'],key=lambda x:(x['type']!='directory',x['path'].count('/'),x['path'])):
    src=os.path.join(root,item['path'].lstrip('/')); dst=item['path']
    if dst in {'/etc/siyi/release_version','/etc/siyi/release_build','/etc/siyi/release_status'}: continue
    if dst == '/var/lib/siyi-upgrade/state.json' and os.path.lexists(dst): continue
    if item['type']=='directory': os.makedirs(dst,exist_ok=True)
    elif item['type']=='symlink':
        os.makedirs(os.path.dirname(dst),exist_ok=True)
        if os.path.lexists(dst):
            if os.path.isdir(dst) and not os.path.islink(dst): shutil.rmtree(dst)
            else: os.unlink(dst)
        os.symlink(os.readlink(src),dst)
    else:
        os.makedirs(os.path.dirname(dst),exist_ok=True)
        fd,tmp=tempfile.mkstemp(prefix='.siyi421.',dir=os.path.dirname(dst)); os.close(fd)
        shutil.copy2(src,tmp,follow_symlinks=False); os.replace(tmp,dst)
    uid=pwd.getpwnam(item['owner']).pw_uid; gid=grp.getgrnam(item['group']).gr_gid
    if item['type']=='symlink': os.lchown(dst,uid,gid)
    else:
        os.chown(dst,uid,gid)
        os.chmod(dst,int(item['mode'],8))
for p in data.get('obsolete_paths',[]):
    if os.path.isdir(p) and not os.path.islink(p): shutil.rmtree(p)
    elif os.path.lexists(p): os.unlink(p)
    if os.path.lexists(p): raise SystemExit('obsolete path remained '+p)
PYDEPLOY
# SIYI_4_2_1_PARAM_IMPORT_STORAGE_GATE_V3
# Directory modes are declarative target state. `install -d -m` does not reliably
# remove pre-existing special mode bits, so creation, ownership and chmod are
# deliberately separate operations and the exact state is verified afterwards.
sudo install -d /var/backups /var/lib/siyi-param-import /var/lib/siyi-param-import/sessions /var/backups/siyi-param-import
sudo chown root:root /var/backups
sudo chmod a-s,u=rwx,g=rx,o=rx /var/backups
for _siyi_dir in /var/lib/siyi-param-import /var/lib/siyi-param-import/sessions /var/backups/siyi-param-import; do
  sudo chown pi:pi "$_siyi_dir"
  sudo chmod a-s,u=rwx,g=rwx,o=rx "$_siyi_dir"
  [ "$(stat -c '%U:%G:%a' "$_siyi_dir")" = "pi:pi:775" ] || die "Parameter import directory ownership/mode failed: $_siyi_dir"
  sudo -u pi test -w "$_siyi_dir" || die "Parameter import directory is not writable by pi: $_siyi_dir"
done
sudo install -d -o pi -g pi -m 0775 /home/pi/.config/siyi /var/lib/siyi-user-config/groundstation
sudo install -d -o root -g pi -m 0775 /var/lib/siyi-upgrade /var/backups/siyi-upgrade /var/lib/siyi-installer
for dst in /home/pi/.config/siyi/telemetry_canvas.json /var/lib/siyi-user-config/groundstation/telemetry_canvas.json; do
  [ -e "$dst" ] || sudo install -o pi -g pi -m 0664 /usr/local/share/siyi/defaults/telemetry_canvas.json "$dst"
done
[ -e /var/lib/siyi-upgrade/preserve_preferences.json ] || sudo install -o root -g pi -m 0664 /usr/local/share/siyi/defaults/upgrade_preserve_preferences.json /var/lib/siyi-upgrade/preserve_preferences.json
sudo python3 - "$TX_DIR/preserve-root" "$TX_DIR/preserve-plan.json" <<'PYPRESERVERESTORE'
import hashlib,json,os,shutil,stat,sys,tempfile
backup_root,plan_path=sys.argv[1:]
plan=json.load(open(plan_path,encoding='utf-8'))
for item in plan.get('files',[]):
  path=item['path']; src=os.path.join(backup_root,path.lstrip('/')); os.makedirs(os.path.dirname(path),exist_ok=True)
  if os.path.isdir(path) and not os.path.islink(path): shutil.rmtree(path)
  elif os.path.lexists(path): os.unlink(path)
  if item['type']=='symlink': os.symlink(os.readlink(src),path); digest=hashlib.sha256(os.readlink(path).encode()).hexdigest()
  else:
    fd,tmp=tempfile.mkstemp(prefix='.siyi-preserve.',dir=os.path.dirname(path)); os.close(fd)
    shutil.copy2(src,tmp,follow_symlinks=False); os.replace(tmp,path); digest=hashlib.sha256(open(path,'rb').read()).hexdigest()
  if digest!=item['sha256']: raise SystemExit('preservation checksum mismatch: '+path)
  if not os.path.islink(path): os.chmod(path,int(item['mode'])); os.chown(path,int(item['uid']),int(item['gid']))
for path,values in plan.get('json_key_values',{}).items():
  try: target=json.load(open(path,encoding='utf-8'))
  except FileNotFoundError: target={}
  except Exception as exc: raise SystemExit(f'invalid target JSON {path}: {exc}')
  if not isinstance(target,dict): raise SystemExit('target JSON is not an object: '+path)
  target.update(values); os.makedirs(os.path.dirname(path),exist_ok=True)
  fd,tmp=tempfile.mkstemp(prefix='.siyi-merge.',dir=os.path.dirname(path),text=True)
  with os.fdopen(fd,'w',encoding='utf-8') as f: json.dump(target,f,indent=2); f.write('\n')
  os.chmod(tmp,0o664); os.chown(tmp,os.getuid(),os.getgid()); os.replace(tmp,path)
  check=json.load(open(path,encoding='utf-8'))
  for key,value in values.items():
    if check.get(key)!=value: raise SystemExit(f'preserved JSON key mismatch: {path}:{key}')
PYPRESERVERESTORE
sudo chown pi:pi /home/pi/siyi-config.json 2>/dev/null || true
sudo chmod 0664 /home/pi/siyi-config.json 2>/dev/null || true
# mediamtx.yml is generated runtime state. Rebuild it from the target default or
# the preserved /etc/siyi/video_source.json after every route.
/usr/local/sbin/siyi-video-source-control configure
[ "$(stat -c '%U:%G:%a' /usr/local/etc/mediamtx/mediamtx.yml 2>/dev/null || true)" = "root:root:600" ] || die "Generated MediaMTX configuration ownership/mode verification failed."
/usr/local/sbin/siyi-release-fingerprint --manifest "$MANIFEST" --clean-managed-extras --clean-managed-extras-only --allow-release "$SIYI_SOURCE_RELEASE" >/dev/null
if [ "$REMEMBER_SELECTION" -eq 1 ]; then
  sudo python3 - /var/lib/siyi-upgrade/preserve_preferences.json "$PRESERVE_CSV" <<'PYPREFS'
import grp,json,os,sys,tempfile
path,csv=sys.argv[1:]; data={'schema_version':2,'preserve':[x for x in csv.split(',') if x]}
os.makedirs(os.path.dirname(path),exist_ok=True); fd,tmp=tempfile.mkstemp(prefix='.prefs.',dir=os.path.dirname(path))
with os.fdopen(fd,'w',encoding='utf-8') as f: json.dump(data,f,indent=2); f.write('\n')
os.chmod(tmp,0o664); os.chown(tmp,0,grp.getgrnam('pi').gr_gid); os.replace(tmp,path)
PYPREFS
fi
# SIYI_4_2_1_GROUP_PRESERVATION_MODEL_V1

progress 45 "Installing Web UI"
test -f /home/pi/siyi-webui/server.py
test -f /home/pi/siyi-webui/wifi_passwords.json
sudo chown -R pi:pi /home/pi/siyi-webui /home/pi/siyi-joystick

progress 50 "Configuring camera Ethernet"
if ip link show eth0 >/dev/null 2>&1; then
  if nmcli -t -f NAME connection show --active 2>/dev/null | grep -Fxq cam-eth0; then touch "$TX_DIR/cam-profile-was-active"; fi
  existing_cam="$(nmcli -t -f NAME connection show 2>/dev/null | awk '$0=="cam-eth0"{print;exit}')"
  if [ -z "$existing_cam" ]; then
    sudo nmcli connection add type ethernet ifname eth0 con-name cam-eth0 >/dev/null
    CAM_PROFILE_CREATED=1; touch "$TX_DIR/cam-profile-created"
  else
    : >"$TX_DIR/cam-profile-state.tsv"
    for _siyi_nm_key in connection.interface-name connection.autoconnect connection.autoconnect-priority ipv4.method ipv4.addresses ipv4.gateway ipv4.dns ipv4.never-default ipv6.method; do
      printf '%s\t%s\n' "$_siyi_nm_key" "$(nmcli -g "$_siyi_nm_key" connection show cam-eth0 2>/dev/null || true)" >>"$TX_DIR/cam-profile-state.tsv"
    done
  fi
  camera_eth_ip="$(python3 - /home/pi/siyi-config.json <<'PYCAMERAIP'
import json,sys
try: value=str(json.load(open(sys.argv[1],encoding='utf-8')).get('camera_eth_ip','')).strip()
except Exception: value=''
print(value or '192.168.144.20/24')
PYCAMERAIP
)"
  [[ "$camera_eth_ip" =~ ^[0-9a-fA-F:.]+/[0-9]+$ ]] || die "Invalid camera_eth_ip in /home/pi/siyi-config.json: $camera_eth_ip"
  sudo nmcli connection modify cam-eth0 connection.interface-name eth0 connection.autoconnect yes connection.autoconnect-priority 100 ipv4.method manual ipv4.addresses "$camera_eth_ip" ipv4.gateway "" ipv4.dns "" ipv4.never-default yes ipv6.method disabled
fi

progress 58 "Preparing Python environment"
sudo rm -rf /home/pi/siyi-bridge-venv.new
run_logged "Creating Python virtual environment" python3 -m venv /home/pi/siyi-bridge-venv.new
run_logged "Updating Python package installer" /home/pi/siyi-bridge-venv.new/bin/pip install --disable-pip-version-check --no-cache-dir --upgrade pip
run_logged "Installing pinned Python dependencies" /home/pi/siyi-bridge-venv.new/bin/pip install --disable-pip-version-check --no-cache-dir --requirement "$SCRIPT_DIR/requirements.txt"
run_logged "Checking Python dependency consistency" /home/pi/siyi-bridge-venv.new/bin/pip check
/home/pi/siyi-bridge-venv.new/bin/python - <<'PYIMPORT'
from pymavlink import mavutil
import fastcrc,future,lxml,numpy,serial,requests,psutil,aiohttp,websockets,yaml
PYIMPORT
if [ -d /home/pi/siyi-bridge-venv ]; then sudo mv /home/pi/siyi-bridge-venv "$TX_DIR/siyi-bridge-venv.previous"; fi
sudo mv /home/pi/siyi-bridge-venv.new /home/pi/siyi-bridge-venv
VENV_SWAPPED=1
touch "$TX_DIR/venv-swapped"
sudo chown -R pi:pi /home/pi/siyi-bridge-venv

progress 65 "Installing system services"
boot_dir=""
[ ! -d /boot/firmware ] || boot_dir=/boot/firmware
[ -n "$boot_dir" ] || [ ! -d /boot ] || boot_dir=/boot
[ -n "$boot_dir" ] || die "Boot configuration directory not found."
cmdline="$boot_dir/cmdline.txt"; config="$boot_dir/config.txt"
[ -f "$cmdline" ] || die "$cmdline not found."
sudo python3 - "$cmdline" <<'PYCMD'
import pathlib,re,sys
p=pathlib.Path(sys.argv[1]); tokens=p.read_text().strip().split()
tokens=[t for t in tokens if not re.fullmatch(r'console=(serial0|ttyS0|ttyAMA0),.*',t)]
p.write_text(' '.join(tokens)+'\n')
PYCMD
sudo touch "$config"
sudo python3 - "$config" <<'PYCONFIG'
import pathlib,re,sys
p=pathlib.Path(sys.argv[1]); s=p.read_text()
if re.search(r'(?m)^enable_uart=',s): s=re.sub(r'(?m)^enable_uart=.*$','enable_uart=1',s)
else: s=s.rstrip()+'\n\nenable_uart=1\n'
p.write_text(s)
PYCONFIG
sudo systemctl disable --now serial-getty@serial0.service serial-getty@ttyS0.service serial-getty@ttyAMA0.service 2>/dev/null || true
sudo systemctl mask serial-getty@serial0.service serial-getty@ttyS0.service serial-getty@ttyAMA0.service 2>/dev/null || true
mkdir -p "$TX_DIR/pycache"
PYTHONPYCACHEPREFIX="$TX_DIR/pycache" /home/pi/siyi-bridge-venv/bin/python -m py_compile /home/pi/siyi-webui/server.py /home/pi/siyi_mav_button_bridge.py /home/pi/siyi-battery-cache.py /home/pi/siyi-joystick/joystickd.py /usr/local/lib/siyi/groundstation/groundstation_daemon.py /usr/local/bin/siyi-paramd /usr/local/bin/siyi-video-source /usr/local/bin/siyi-video-udp-forward /usr/local/sbin/siyi-video-source-control
sudo visudo -cf /etc/sudoers.d/siyi-webui
sudo chmod 0600 /home/pi/siyi-webui/wifi_passwords.json /etc/siyi/maptiler.json
sudo chmod 0660 /etc/siyi/video_source.json /etc/siyi/zerotier_config.json
# All release metadata except the self-describing payload-manifest.json is
# already part of the complete target payload and immutable manifest. Install
# only the manifest itself here; a manifest cannot hash its own bytes.
sudo install -d -o root -g root -m 0755 /usr/local/share/siyi/releases/4.2.1
sudo install -o root -g root -m 0644 "$SCRIPT_DIR/payload-manifest.json" /usr/local/share/siyi/releases/4.2.1/payload-manifest.json

progress 70 "Configuring MAVLink router"
sudo install -d -o root -g root -m 0755 /etc/mavlink-router
[ -f /etc/mavlink-router/main.conf ] || die "MAVLink router configuration is missing after preservation restore."
sudo chown root:root /etc/mavlink-router/main.conf
sudo chmod 0644 /etc/mavlink-router/main.conf
sudo install -o pi -g pi -m 0755 "$PAYLOAD/home/pi/apply_siyi_endpoints.sh" /home/pi/apply_siyi_endpoints.sh
# Do not regenerate main.conf here: target defaults or the selected MAVLink snapshot are authoritative.
# Endpoint application remains available to the UI but is not run during release deployment.

progress 76 "Installing camera time sync"
test -x /usr/local/bin/siyi_proxy_socket_time_sync.sh
test -f /etc/systemd/system/siyi-camera-time-sync.service

# SIYI_4_2_0_MAPTILER_CACHE_SUCCESS_PATH_V21
if sudo test -d /var/cache/siyi-maptiler; then
  sudo stat -c '%u %g %a' /var/cache/siyi-maptiler >"$TX_DIR/maptiler-cache-state"
else
  printf '%s\n' absent >"$TX_DIR/maptiler-cache-state"
fi
MAPTILER_CACHE_STATE_READY=1
sudo install -d -o pi -g pi -m 0755 /var/cache/siyi-maptiler
[ "$(stat -c '%U:%G:%a' /var/cache/siyi-maptiler)" = "pi:pi:755" ] || die "MapTiler cache ownership or mode verification failed."
sudo -u pi test -w /var/cache/siyi-maptiler || die "MapTiler cache is not writable by pi."

progress 82 "Enabling SIYI services"
sudo systemctl daemon-reload
sudo systemctl enable NetworkManager.service zerotier-one.service
units=(mavlink-router.service mediamtx.service siyi-battery-cache.service siyi-button-bridge.service siyi-camera-time-sync.service siyi-groundstation.service siyi-joystickd.service siyi-paramd.service siyi-rec-proxy.service siyi-rec-redirect.service siyi-rtsp-redirect.service siyi-telemetry-canvas.service siyi-video-dual.service siyi-video-source.service siyi-webui.service siyi-postinstall-verify.service)
sudo systemctl enable "${units[@]}"

readarray -t mav < <(python3 - "$SOURCE_LOCK" <<'PYMAV'
import json,sys
m=json.load(open(sys.argv[1]))['mavlink-router']
print(m['repository']); print(m['commit']); print(m['submodules']['modules/mavlink_c_library_v2']); print(m['expected_version'])
PYMAV
)
if ! command -v mavlink-routerd >/dev/null 2>&1 || ! mavlink-routerd --version 2>/dev/null | grep -Fq "${mav[3]}"; then
  echo "=== Build mavlink-router ==="
  rm -rf /home/pi/mavlink-router-build
  git clone "${mav[0]}" /home/pi/mavlink-router-build
  cd /home/pi/mavlink-router-build
  git -c advice.detachedHead=false checkout --detach "${mav[1]}"
  [ "$(git rev-parse HEAD)" = "${mav[1]}" ] || die "MAVLink Router commit verification failed."
  git submodule update --init --recursive
  [ "$(git -C modules/mavlink_c_library_v2 rev-parse HEAD)" = "${mav[2]}" ] || die "MAVLink C submodule verification failed."
  meson setup build .
  ninja -C build
  sudo ninja -C build install
  cd "$SCRIPT_DIR"
fi
command -v mavlink-routerd >/dev/null 2>&1 || die "MAVLink Router was not installed."
mavlink-routerd --version 2>&1 | grep -Fq "${mav[3]}" || die "MAVLink Router version verification failed."
sudo systemctl enable mavlink-router
sudo rm -rf /home/pi/mavlink-router-build

progress 88 "Installing MediaMTX"
readarray -t media < <(python3 - "$SOURCE_LOCK" <<'PYMEDIA'
import json,sys
m=json.load(open(sys.argv[1]))['mediamtx']
print(m['url']); print(m['archive_sha256']); print(m['binary_sha256']); print(m['version'])
PYMEDIA
)
media_url="${media[0]}"; media_archive_sha="${media[1]}"; media_binary_sha="${media[2]}"; media_version="${media[3]}"
if ! { [ -x /usr/local/bin/mediamtx ] && [ "$(sha256sum /usr/local/bin/mediamtx | awk '{print $1}')" = "$media_binary_sha" ]; }; then
  media_dir="/tmp/siyi-mediamtx-$TX"
  rm -rf "$media_dir"; mkdir -p "$media_dir"
  curl --connect-timeout 15 --max-time 180 -fL "$media_url" -o "$media_dir/mediamtx.tar.gz"
  echo "$media_archive_sha  $media_dir/mediamtx.tar.gz" | sha256sum -c -
  tar -xzf "$media_dir/mediamtx.tar.gz" -C "$media_dir" mediamtx
  echo "$media_binary_sha  $media_dir/mediamtx" | sha256sum -c -
  sudo install -m 0755 "$media_dir/mediamtx" /usr/local/bin/mediamtx
fi
[ "$(sha256sum /usr/local/bin/mediamtx | awk '{print $1}')" = "$media_binary_sha" ] || die "MediaMTX binary checksum verification failed."
/usr/local/bin/mediamtx --version 2>&1 | grep -Fq "$media_version" || die "MediaMTX version verification failed."
sudo systemctl daemon-reload
sudo systemctl enable mediamtx.service siyi-rtsp-redirect.service
cleanup_target_transients

progress 94 "Validating staged installation"

# SIYI_4_2_0_RELEASE_DUPLICATE_CONSISTENCY_GATE_V23
top_health_sha="$(sha256sum "$SCRIPT_DIR/health-check.sh" | awk '{print $1}')"
payload_health_sha="$(sha256sum "$PAYLOAD/usr/local/share/siyi/releases/4.2.1/health-check.sh" | awk '{print $1}')"
[ "$top_health_sha" = "$payload_health_sha" ] || die "Release health-check copies differ."
top_restore_sha="$(sha256sum "$SCRIPT_DIR/transaction-restore.py" | awk '{print $1}')"
payload_restore_sha="$(sha256sum "$PAYLOAD/usr/local/share/siyi/releases/4.2.1/transaction-restore.py" | awk '{print $1}')"
[ "$top_restore_sha" = "$payload_restore_sha" ] || die "Transaction-restore copies differ."
for file in release-metadata.json supported-sources.json supported-source-releases.json source-lock.json preservation-model.json requirements.txt apt-packages.txt release-notes.md feature-parity-checklist.md SIYI_4.2.x_RELEASE_MODEL.md source-identity-4.2.0.json source-payload-manifest-4.2.0.json verify-source-4.2.0.py source-health-gate.py; do
  [ "$(sha256sum "$SCRIPT_DIR/$file" | awk '{print $1}')" = "$(sha256sum "/usr/local/share/siyi/releases/4.2.1/$file" | awk '{print $1}')" ] || die "Installed release metadata copy differs: $file"
done

printf '%s\n' "$VERSION" >"$TX_DIR/release_version"
printf '%s\n' "$BUILD_ID" >"$TX_DIR/release_build"
printf '%s\n' pending_reboot >"$TX_DIR/release_status"
sudo install -d -o pi -g pi -m 0775 /etc/siyi
sudo install -o root -g root -m 0644 "$TX_DIR/release_version" /etc/siyi/release_version
sudo install -o root -g root -m 0644 "$TX_DIR/release_build" /etc/siyi/release_build
sudo install -o root -g root -m 0644 "$TX_DIR/release_status" /etc/siyi/release_status
[ "$(tr -d '[:space:]' </etc/siyi/release_version)" = "$VERSION" ] || die "Release-version marker write verification failed."
[ "$(tr -d '[:space:]' </etc/siyi/release_build)" = "$BUILD_ID" ] || die "Release-build marker write verification failed."
/usr/local/sbin/siyi-release-fingerprint --verify --allow-release "$SIYI_SOURCE_RELEASE" >/dev/null
sudo "$SCRIPT_DIR/health-check.sh" --pre-reboot --allow-release "$SIYI_SOURCE_RELEASE"
python3 - "$MANIFEST" <<'PYFINAL'
import grp,hashlib,json,os,pwd,stat,sys
m=json.load(open(sys.argv[1],encoding='utf-8'))
for item in m['files']:
    if item.get('persistent') or item['path']=='/usr/local/share/siyi/releases/4.2.1/payload-manifest.json': continue
    p=item['path']
    if not os.path.lexists(p): raise SystemExit('missing '+p)
    st=os.lstat(p)
    actual='symlink' if stat.S_ISLNK(st.st_mode) else 'directory' if stat.S_ISDIR(st.st_mode) else 'file' if stat.S_ISREG(st.st_mode) else 'other'
    if actual!=item['type']: raise SystemExit('type mismatch '+p)
    if st.st_uid!=pwd.getpwnam(item['owner']).pw_uid or st.st_gid!=grp.getgrnam(item['group']).gr_gid: raise SystemExit('ownership mismatch '+p)
    if actual!='symlink' and stat.S_IMODE(st.st_mode)!=int(item['mode'],8): raise SystemExit('mode mismatch '+p)
    if actual=='file' and hashlib.sha256(open(p,'rb').read()).hexdigest()!=item['sha256']: raise SystemExit('checksum mismatch '+p)
    if actual=='symlink' and hashlib.sha256(os.readlink(p).encode()).hexdigest()!=item['sha256']: raise SystemExit('symlink mismatch '+p)
for p in m.get('obsolete_paths',[]):
    if os.path.lexists(p): raise SystemExit('obsolete path remained '+p)
PYFINAL
touch "$TX_DIR/INSTALL_STAGED"
printf '%s\n' "$TX_DIR" >"$TX_DIR/pending-transaction"
sudo install -d -o root -g root -m 0755 /var/lib/siyi-installer
sudo install -o root -g root -m 0644 "$TX_DIR/pending-transaction" /var/lib/siyi-installer/pending-transaction
SUCCESS=1
trap - ERR INT TERM
progress 100 "Install complete"

# Select the user-reachable LAN address captured from the initiating SSH route.
# The camera-management address from siyi-config.json is explicitly excluded.
PRIMARY_IP="$(siyi_select_primary_webui_ip)"
cat >&3 <<EOF

========================================
✅ SIYI INSTALL COMPLETE
========================================

=== OPEN WEB UI ===
http://${PRIMARY_IP}:8080

👉 Connect Mac or PC to the same local network as the Pi and use the above URL for local access to the Web client. From there, configure ZeroTier and Hosts.

Full install log:
$INSTALL_LOG
EOF

if [ "$NO_REBOOT" -eq 0 ]; then
  cat >&3 <<EOF

The Raspberry Pi will reboot automatically in 5 seconds.
Post-reboot acceptance will be written to:
/etc/siyi/release_status
EOF
  sleep 5
  sudo systemctl reboot
else
  cat >&3 <<EOF

Reboot required. Run:
sudo reboot
EOF
fi
