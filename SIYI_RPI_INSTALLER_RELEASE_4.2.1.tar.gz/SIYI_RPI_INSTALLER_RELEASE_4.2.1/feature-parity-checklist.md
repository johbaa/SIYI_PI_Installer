# SIYI 4.2.1 SIYI_4_2_1_RELEASE_CANDIDATE_V28 acceptance checklist

## Required physical paths

- [ ] Configure ZeroTier and Hosts on accepted 4.2.0 RC23, then perform the genuine native WebUI upgrade.
- [ ] Fresh installation using public curl, then complete initial ZeroTier and Hosts setup before acceptance.
- [ ] Local Mac upgrade is not used as an acceptance path.

## RC28 configured-system integrity gates

- [ ] `/home/pi/siyi-webui/backups` is absent after migration or normal operation.
- [ ] `/home/pi/siyi_zerotier_setup.log` is absent after migration or normal operation.
- [ ] Endpoint backups are preserved/written under `/home/pi/.local/state/siyi/webui-backups`.
- [ ] ZeroTier setup diagnostics are preserved/written under `/home/pi/.local/state/siyi/zerotier_setup.log`.
- [ ] Native-voice diagnostics remain under `/home/pi/.local/state/siyi/groundstation_native_device_voice_v3.log`.
- [ ] Canonical fingerprint passes after ZeroTier, Hosts and native-voice interactions.
- [ ] Complete release health passes after those interactions.

## Existing mandatory gates

- [ ] All required services active with stable restart counters and zero failed units.
- [ ] Joystick WebSocket handshake, 50 Hz latest-state/no-backlog transport, HTTP fallback, reconnect and UDP 18767 pass.
- [ ] Selective preservation and network state survive the supported upgrade.
- [ ] Fresh and upgrade routes converge to the same canonical immutable fingerprint.
- [ ] Pre-reboot and post-reboot injected rollback gates remain valid.
