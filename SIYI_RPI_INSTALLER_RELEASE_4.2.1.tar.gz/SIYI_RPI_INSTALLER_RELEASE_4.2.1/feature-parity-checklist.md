# SIYI 4.2.1 SIYI_4_2_1_RELEASE_CANDIDATE_V27 acceptance checklist

## Required physical paths

- [ ] Genuine native WebUI upgrade from accepted 4.2.0 RC23.
- [ ] Fresh installation using the public curl command.
- [ ] Local Mac upgrade is not used as an acceptance path.

## RC27 regression gates

- [ ] The reconnect handoff never presents a frozen numeric percentage while the WebUI is unreachable.
- [ ] Reconnect view shows an indeterminate moving bar, elapsed time, last-contact age and reconnect attempts.
- [ ] Trigger `/api/groundstation/native-voice-diagnostic`; `/home/pi/siyi_groundstation_native_device_voice_v3.log` remains absent.
- [ ] Diagnostic output is written under `/home/pi/.local/state/siyi/groundstation_native_device_voice_v3.log`.
- [ ] Canonical fingerprint passes after the diagnostic endpoint is exercised.
- [ ] Complete release health passes after the diagnostic endpoint is exercised.

## Existing mandatory gates

- [ ] All required services active with stable restart counters and zero failed units.
- [ ] Joystick WebSocket handshake, 50 Hz latest-state/no-backlog transport, HTTP fallback, reconnect and UDP 18767 pass.
- [ ] Selective preservation and network state survive the supported upgrade.
- [ ] Fresh and upgrade routes converge to the same canonical immutable fingerprint.
- [ ] Pre-reboot and post-reboot injected rollback gates remain valid.
