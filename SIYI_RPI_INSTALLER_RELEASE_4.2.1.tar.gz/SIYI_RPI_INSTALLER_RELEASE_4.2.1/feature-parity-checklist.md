# SIYI 4.2.1 SIYI_4_2_1_RELEASE_CANDIDATE_V26 acceptance checklist

- [ ] Fresh install on a clean Raspberry Pi OS 64-bit Debian 13 image.
- [ ] Fresh install using a non-`pi` SSH login.
- [ ] Native upgrade from published 4.2.0 V23.
- [ ] Native upgrade from accepted live 4.2.0 Wind V1/V2.
- [ ] Selective preservation matrix.
- [ ] Pre-reboot injected failure restores the exact source state.
- [ ] Post-reboot injected failure automatically restores the exact source state.
- [ ] Originally absent SIYI units restore as not-found/inactive.
- [ ] Boot cmdline/config metadata and absence restore exactly.
- [ ] Duplicate install/upgrade/acceptance/rollback attempts are locked out.
- [ ] Unexpected managed files are removed and canonical fingerprints converge.
- [ ] Fresh and upgrade canonical immutable fingerprints match.
- [ ] All core services remain active with stable restart counters.
- [ ] Joystick persistent WebSocket, 50 Hz, latest-state/no-backlog, fallback, reconnect, and UDP 18767 pass.
- [ ] Wind speed and relative arrow pass flight validation.
- [ ] Genuine FC strict hardware acceptance passes.

- [ ] Source gate accepts published V23 with observed runtime artifacts and altered symlink ownership, but rejects active-file, symlink-target, or unapproved executable tampering.

- [ ] Native upgrade source health accepts only intentional 423 locks for Ground Station and Parameters, with exact active upgrade-state proof.

- [ ] Expected nonzero source-health during native HTTP 423 lock does not trigger the Bash ERR rollback trap; maintenance-gate evidence is created before any target mutation.

- [ ] Payload directory modes are host-independent: approved-source paths retain exact source modes, target-only paths match the explicit policy, and no setuid/setgid/sticky bits are present.
- [ ] The RC14 `2755` staging-leak regression is reproduced and blocked; post-deployment V24 directories are exactly `pi:pi:775`.

- [ ] Fresh-SD dependency provisioning may perform only apt-simulated package actions and establishes the rollback baseline after provisioning.
- [ ] Fresh dependency failure before SIYI mutation does not write `rollback_failed` or a target release marker.
- [ ] Installer progress remains one physical terminal line at 40, 60, 80, and 100 columns.

- [ ] Production 4.2.0 V23 parameter-daemon preflight runs in the actual installer path, self-restores on failure, and proves stable service health before target mutation.
