#!/usr/bin/env python3
"""Fail-closed source-health decision during a native WebUI upgrade.

The 4.2.0 WebUI intentionally returns HTTP 423 for normal pages while the
native upgrade transaction is active. This helper performs the complete
maintenance-gate capture itself, avoiding shell command-substitution and
pipefail/SIGPIPE failure modes. All other source-health failures remain fatal.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import pathlib
import re
import subprocess
import tempfile
import urllib.error
import urllib.request
from typing import Any

ALLOWED_LOCK_FAILURES = {"url:groundstation", "url:parameters"}
TERMINAL_OR_IDLE_STATUSES = {"", "idle", "completed", "failed", "rollback_failed"}
UNIT_RE = re.compile(r"^siyi-github-upgrade-[A-Za-z0-9_.@:-]+\.service$")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def load_json(path: str) -> dict[str, Any]:
    try:
        value = json.loads(pathlib.Path(path).read_text(encoding="utf-8"))
    except Exception as exc:
        raise RuntimeError(f"invalid JSON {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise RuntimeError(f"invalid JSON object {path}")
    return value


def atomic_json(path: str, payload: dict[str, Any], mode: int = 0o600) -> None:
    p = pathlib.Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{p.name}.", dir=str(p.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
            f.write("\n")
        os.chmod(tmp, mode)
        os.replace(tmp, p)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def direct_http_status(base_url: str, path: str, timeout: float) -> tuple[int, str]:
    url = base_url.rstrip("/") + path
    opener = urllib.request.build_opener(NoRedirect())
    req = urllib.request.Request(url, headers={"User-Agent": "SIYI-Upgrade-Health-Gate/1"})
    try:
        with opener.open(req, timeout=timeout) as response:
            return int(response.getcode()), ""
    except urllib.error.HTTPError as exc:
        return int(exc.code), ""
    except Exception as exc:
        return 0, f"{type(exc).__name__}: {exc}"


def active_native_units(systemctl: str, timeout: float) -> tuple[list[str], str]:
    cmd = [
        systemctl, "list-units", "--type=service", "--state=activating,running",
        "--no-legend", "--no-pager", "--plain", "--full",
    ]
    try:
        proc = subprocess.run(cmd, text=True, capture_output=True, timeout=timeout, check=False)
    except Exception as exc:
        return [], f"{type(exc).__name__}: {exc}"
    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "").strip()
        return [], f"systemctl exited {proc.returncode}: {detail}"
    units: list[str] = []
    for line in proc.stdout.splitlines():
        fields = line.split()
        if fields and UNIT_RE.fullmatch(fields[0]):
            units.append(fields[0])
    return sorted(set(units)), ""


def evaluate(
    health: dict[str, Any],
    state: dict[str, Any],
    source: str,
    target: str,
    gs_code: int,
    params_code: int,
    native_units: list[str],
    probe_errors: list[str],
) -> tuple[bool, str]:
    failures = {str(x).strip() for x in health.get("failures", []) if str(x).strip()}
    if not failures:
        return bool(health.get("ok", False)), "source health passed"
    if failures != ALLOWED_LOCK_FAILURES:
        return False, "source health failures are not exactly the two intentional page locks: " + ",".join(sorted(failures))
    if probe_errors:
        return False, "maintenance-gate probe failed: " + "; ".join(probe_errors)
    if state.get("running") is not True:
        return False, "upgrade-state snapshot is not running=true"
    status = str(state.get("status", "")).strip()
    if status in TERMINAL_OR_IDLE_STATUSES:
        return False, f"upgrade-state snapshot is not active: status={status or 'missing'}"
    if str(state.get("from_version", "")).strip() != source:
        return False, "upgrade-state source version mismatch"
    if str(state.get("to_version", "")).strip() != target:
        return False, "upgrade-state target version mismatch"
    if gs_code != 423 or params_code != 423:
        return False, f"locked-page HTTP status mismatch: groundstation={gs_code} parameters={params_code}"
    if not native_units:
        return False, "no active native-upgrade transient systemd unit was proven"
    return True, "source health accepted with only intentional WebUI 423 lock failures"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--health-json", required=True)
    ap.add_argument("--upgrade-state", required=True)
    ap.add_argument("--source-version", required=True)
    ap.add_argument("--target-version", required=True)
    ap.add_argument("--snapshot-output", required=True)
    ap.add_argument("--evidence-output", required=True)
    ap.add_argument("--base-url", default="http://127.0.0.1:8080")
    ap.add_argument("--systemctl", default="systemctl")
    ap.add_argument("--timeout", type=float, default=8.0)
    a = ap.parse_args()

    captured_at = dt.datetime.now().astimezone().isoformat(timespec="seconds")
    health: dict[str, Any] = {}
    state: dict[str, Any] = {}
    gs_code = params_code = 0
    native_units: list[str] = []
    probe_errors: list[str] = []
    try:
        health = load_json(a.health_json)
        state = load_json(a.upgrade_state)
        atomic_json(a.snapshot_output, state)
        gs_code, gs_error = direct_http_status(a.base_url, "/groundstation", a.timeout)
        params_code, params_error = direct_http_status(a.base_url, "/parameters", a.timeout)
        native_units, unit_error = active_native_units(a.systemctl, a.timeout)
        for label, error in (("groundstation", gs_error), ("parameters", params_error), ("systemctl", unit_error)):
            if error:
                probe_errors.append(f"{label}: {error}")
        ok, reason = evaluate(
            health, state, a.source_version, a.target_version,
            gs_code, params_code, native_units, probe_errors,
        )
    except Exception as exc:
        ok = False
        reason = f"maintenance-gate capture failed: {type(exc).__name__}: {exc}"
        probe_errors.append(reason)

    evidence = {
        "captured_at": captured_at,
        "ok": ok,
        "reason": reason,
        "source_version": a.source_version,
        "target_version": a.target_version,
        "groundstation_code": gs_code,
        "parameters_code": params_code,
        "native_units": native_units,
        "probe_errors": probe_errors,
        "health": health,
        "upgrade_state_snapshot": state,
    }
    atomic_json(a.evidence_output, evidence)
    print(reason)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
