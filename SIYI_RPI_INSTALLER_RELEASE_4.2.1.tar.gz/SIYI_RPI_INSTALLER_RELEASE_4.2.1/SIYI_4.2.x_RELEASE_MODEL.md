# SIYI 4.2.x complete-target release model V13

Each release is one complete authoritative target package. Fresh installation and every supported upgrade route differ only in source verification and preservation preparation; all routes deploy the same target payload and must converge to the same immutable fingerprint.

Permanent rules:

1. The previous accepted release package is the build baseline.
2. Every supported source is validated by version, build, accepted status, exact source manifest, and complete immutable managed-file identity.
3. User-selectable and always-preserved settings are restored only through the declared preservation model.
4. A root-owned transaction snapshot is completed before target mutation.
5. Install, native upgrade, post-reboot acceptance, rollback, repair, and manual acceptance share one global lock.
6. Failed transactions restore content, type, ownership, mode, timestamps, symlinks, service state, boot files, package delta, runtime identity, and source release metadata.
7. Unexpected files in SIYI-managed namespaces are removed or rejected; explicit runtime state is excluded.
8. Post-reboot acceptance uses transaction-pinned checksum-verified recovery evidence.
9. Successful routes remove obsolete source release trees and full transaction backups, leaving compact acceptance history.
10. A release is not promoted until fresh, every supported upgrade source, rollback injection, hardware, and canonical convergence tests pass.

## V13 source identity refinement

The source gate verifies all active immutable managed files. Only explicitly classified non-active backup, diagnostic-log, and current native-installer staging artifacts are excluded. Symlink targets remain checksum-verified; symlink uid/gid is not identity-bearing.

## V13 native-upgrade health semantics

The installed source is health-checked before mutation. During the genuine native WebUI route, `/groundstation` and `/parameters` are deliberately HTTP 423 while the update lock is active. Only those exact failures may be waived, and only when the active state file proves the exact source and target and both endpoints are observed returning 423.

## V13 expected-failure and ERR-trap rule

Commands whose nonzero status is an expected input to a later decision must be executed in an `if`, `while`, `until`, `&&`, or `||` conditional context. `set +e` alone is forbidden for this purpose because an installed Bash `ERR` trap still fires. Factory validation executes a regression harness proving that the source-health nonzero result reaches the maintenance gate without rollback.

## V13 declarative directory-mode rule

Directory ownership and mode are release metadata, not properties to infer from a checkout, ZIP extraction directory, shared build volume, umask, default ACL, or setgid parent. The factory imports modes for inherited directories from the approved source manifest and requires an explicit mode for every target-only directory. Special mode bits are fail-closed. Runtime gates that require exact modes use separate creation, ownership and special-bit-clearing mode operations because `install -d -m` does not normalize every pre-existing directory state.


## RC18 / Factory V16

Pre-reboot source-release coexistence is passed explicitly across privilege boundaries.

## RC19 / Factory V17

Fresh-OS dependency provisioning is a prerequisite phase. It completes before package, unit-state, and filesystem transaction baselines are captured. The release transaction therefore remains exact without attempting unavailable package downgrades. The terminal progress renderer is column-bounded and single-line on every supported TTY width.

## RC20 / Factory V18

Adds markerless fresh-install namespace cleanup and immediate failed-fresh-runner termination. Immutable target verification is unchanged and remains mandatory after release markers are written.

## RC23 / Factory V20

Adds route-aware completion URL selection. The initiating SSH route is captured before sudo, preserved through the root re-exec, and preferred over all interface enumeration. Camera-management addresses are never advertised as the WebUI LAN URL.
