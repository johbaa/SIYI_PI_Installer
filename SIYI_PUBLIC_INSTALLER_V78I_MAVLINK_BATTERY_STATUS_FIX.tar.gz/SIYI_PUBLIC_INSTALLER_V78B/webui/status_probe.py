
import json
try:
    with open("/home/pi/siyi-config.json") as cf:
        CFG = json.load(cf)
except Exception:
    CFG = {}

CAM_IP = CFG.get("camera_ip", "192.168.144.25")

#!/usr/bin/env python3
import subprocess, time, os, html

def run(cmd, timeout=2):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.DEVNULL, timeout=timeout).strip()
    except Exception:
        return ""

def network_ok():
    """
    REAL network health:
    Wi-Fi must be connected AND gateway must respond.
    """
    state = run("nmcli -t -f GENERAL.STATE dev show wlan0 | cut -d: -f2", timeout=2)
    if not state.startswith("100"):
        return False

    gw = run("ip route | awk '/default/ {print $3; exit}'", timeout=2)
    if not gw:
        return False

    ping = run(f"ping -c 1 -W 1 {gw}", timeout=2)
    return "1 received" in ping

def zt_ok():
    return "ONLINE" in run("sudo zerotier-cli info", timeout=2)

def camera_ok():
    return bool(run("ping -c 1 -W 1 "+CAM_IP+""))



def mavlink_ok():
    import socket, time

    def is_autopilot_heartbeat(pkt):
        try:
            # MAVLink 2
            if pkt[0] == 0xFD and len(pkt) >= 21:
                length = pkt[1]
                msgid = pkt[7] | (pkt[8] << 8) | (pkt[9] << 16)
                payload = pkt[10:10+length]
                if msgid == 0 and len(payload) >= 9:
                    mav_type = payload[4]
                    autopilot = payload[5]
                    return mav_type != 6 and autopilot != 8

            # MAVLink 1
            if pkt[0] == 0xFE and len(pkt) >= 17:
                length = pkt[1]
                msgid = pkt[5]
                payload = pkt[6:6+length]
                if msgid == 0 and len(payload) >= 9:
                    mav_type = payload[4]
                    autopilot = payload[5]
                    return mav_type != 6 and autopilot != 8
        except Exception:
            return False
        return False

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("127.0.0.1", 14601))
        sock.settimeout(0.5)

        deadline = time.time() + 3.0
        while time.time() < deadline:
            try:
                data, addr = sock.recvfrom(4096)
                if is_autopilot_heartbeat(data):
                    return True
            except socket.timeout:
                pass

        return False
    except Exception:
        return False

def battery_text():
    try:
        return open("/tmp/siyi_battery_status.txt").read().strip()
    except:
        return "Bat ?"

def cpu_load_text():

    try:
        load = open("/proc/loadavg").read().split()[0]
        return f"CPU {load}"
    except Exception:
        return "CPU ?"

def temp_text():
    try:
        raw = open("/sys/class/thermal/thermal_zone0/temp").read().strip()
        c = int(raw) / 1000.0
        return f"Temp {c:.1f}°C"
    except Exception:
        return "Temp ?"

items = [
    (battery_text(), True),
    ("Network", network_ok()),
    ("MAVLink", mavlink_ok()),
    ("Camera", camera_ok()),
    ("ZT", zt_ok()),
    (cpu_load_text(), True),
    (temp_text(), True),
]

out = []
for name, ok in items:
    cls = "ok" if ok else "bad"
    txt = f"{name} OK" if ok else f"{name} Down"
    out.append(f'<span class="status-pill {cls}">{html.escape(txt)}</span>')

print('<div id="top-status-bar">' + "".join(out) + '</div>')
