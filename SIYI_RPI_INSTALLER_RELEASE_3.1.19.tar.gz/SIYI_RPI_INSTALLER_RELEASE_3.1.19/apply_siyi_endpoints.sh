#!/usr/bin/env bash
set -e

ENDPOINTS="/etc/siyi/endpoints.json"
MAVCONF="/etc/mavlink-router/main.conf"

if [ ! -f "$ENDPOINTS" ]; then
  echo "No endpoints.json found"
  exit 0
fi

TMP="$(mktemp)"

cat > "$TMP" <<'EOC'
[General]
TcpServerPort=5760
ReportStats=false

[UartEndpoint fc]
Device=/dev/serial0
Baud=57600

[UdpEndpoint button_safety]
Mode=Normal
Address=127.0.0.1
Port=14600

[UdpEndpoint webui_status_monitor]
Mode=Normal
Address=127.0.0.1
Port=14601
EOC

python3 - "$ENDPOINTS" "$TMP" <<'PY'
import json, sys, re
endpoints_file, tmp = sys.argv[1], sys.argv[2]
try:
    eps = json.load(open(endpoints_file))
except Exception:
    eps = []

with open(tmp, "a") as f:
    for i, e in enumerate(eps, 1):
        ip = (e.get("ip") or "").strip()
        name = re.sub(r"[^A-Za-z0-9_]", "_", (e.get("name") or f"host{i}").strip())
        mav = bool(e.get("mavlink", False))
        if ip and mav:
            f.write(f"""

[UdpEndpoint host_{name}]
Mode=Normal
Address={ip}
Port=14550
""")
PY

sudo mkdir -p /etc/mavlink-router
sudo cp "$TMP" "$MAVCONF"
rm -f "$TMP"

sudo systemctl restart mavlink-router || true
echo "Applied endpoints and restarted mavlink-router"
