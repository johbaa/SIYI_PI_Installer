
import json
try:
    with open("/home/pi/siyi-config.json") as cf:
        CFG = json.load(cf)
except Exception:
    CFG = {}

CAM = CFG.get("camera_ip", CAM)

#!/usr/bin/env python3
import json, urllib.request, urllib.parse

CAM = CAM
BASE = f"http://{CAM}:82"
MEDIA_TYPE = 1
DIR = "100SIYI_VID"

def get_json(url, timeout=5):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="replace"))

def list_files():
    count_url = f"{BASE}/cgi-bin/media.cgi/api/v1/getmediacount?media_type={MEDIA_TYPE}&path={urllib.parse.quote(DIR)}"
    count_data = get_json(count_url)
    count = int(count_data.get("data", {}).get("count", 0))

    list_url = f"{BASE}/cgi-bin/media.cgi/api/v1/getmedialist?media_type={MEDIA_TYPE}&path={urllib.parse.quote(DIR)}&start=0&count={count}"
    list_data = get_json(list_url)
    return list_data.get("data", {}).get("list", [])

if __name__ == "__main__":
    files = list_files()
    for f in files:
        print(f"{f.get('name','')}|{f.get('url','')}")
