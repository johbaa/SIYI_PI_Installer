(function(){
  const items = Array.from(document.querySelectorAll(".sd-res"));

  function next(i){
    if(i >= items.length) return;

    const el = items[i];
    const url = el.getAttribute("data-url");

    if(!url){
      next(i+1);
      return;
    }

    el.textContent = " [..]";

    fetch("/camera_sd_res?url=" + encodeURIComponent(url), {cache:"no-store"})
      .then(r => r.json())
      .then(d => {
        if(d.res){
          el.textContent = " [" + d.res + "]";
        } else {
          el.textContent = "";
        }
      })
      .catch(() => { el.textContent = ""; })
      .finally(() => setTimeout(() => next(i+1), 120));
  }

  window.addEventListener("load", () => setTimeout(() => next(0), 200));
})();
