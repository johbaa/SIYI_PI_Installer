import glob

import json
try:
    with open("/home/pi/siyi-config.json") as cf:
        CFG = json.load(cf)
except Exception:
    CFG = {}

CAM_IP = CFG.get("camera_ip", "192.168.144.25")
ENDPOINTS_FILE = "/etc/siyi/endpoints.json"

def load_hosts():
    try:
        with open(ENDPOINTS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        hosts = []
        if isinstance(data, list):
            for e in data:
                if not isinstance(e, dict):
                    continue
                ip = str(e.get("ip", "")).strip()
                name = str(e.get("name", ip or "Host")).strip() or ip or "Host"
                if ip:
                    hosts.append((name, ip))
        return hosts
    except Exception:
        return []

def ping_ok(ip):
    return "1 received" in run(f"ping -c 1 -W 1 {ip}", timeout=2)

def hosts_status():
    hosts = load_hosts()
    if not hosts:
        return ("Hosts not set", "warn")
    ok = 0
    for _name, ip in hosts:
        if ping_ok(ip):
            ok += 1
    total = len(hosts)
    if ok == total:
        return (f"Hosts {ok}/{total}", "ok")
    if ok > 0:
        return (f"Hosts {ok}/{total}", "warn")
    return (f"Hosts 0/{total}", "bad")

#!/usr/bin/env python3
import subprocess, time, os, html, json

FLIGHT_MODE_CACHE_FILE = "/tmp/siyi_flight_mode.json"
MAVLINK_LAST_OK_FILE = "/tmp/siyi_mavlink_last_ok.json"
MAVLINK_GRACE_SECONDS = 6.0

ARDUPLANE_MODE_NAMES = {
    0:"MANUAL", 1:"CIRCLE", 2:"STABILIZE", 3:"TRAINING", 4:"ACRO",
    5:"FBWA", 6:"FBWB", 7:"CRUISE", 8:"AUTOTUNE", 10:"AUTO",
    11:"RTL", 12:"LOITER", 13:"TAKEOFF", 15:"GUIDED", 16:"INITIALISING",
    17:"QSTABILIZE", 18:"QHOVER", 19:"QLOITER", 20:"QLAND",
    21:"QRTL", 22:"QAUTOTUNE", 23:"QACRO", 24:"THERMAL",
    25:"LOITER_TO_QLAND", 26:"AUTOLAND"
}

def write_flight_mode_cache(mode, custom_mode, base_mode=None):
    try:
        tmp = FLIGHT_MODE_CACHE_FILE + ".tmp"
        data = {
            "mode": mode,
            "custom_mode": custom_mode,
            "base_mode": base_mode,
            "last_seen": time.time(),
            "source": "status_probe"
        }
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, FLIGHT_MODE_CACHE_FILE)
    except Exception:
        pass


def mark_mavlink_seen():
    try:
        tmp = MAVLINK_LAST_OK_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"last_ok": time.time()}, f)
        os.replace(tmp, MAVLINK_LAST_OK_FILE)
    except Exception:
        pass

def mavlink_recently_seen():
    try:
        with open(MAVLINK_LAST_OK_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)

        age = time.time() - float(data.get("last_ok", 0))
        return age <= MAVLINK_GRACE_SECONDS

    except Exception:
        return False

def parse_autopilot_heartbeat(pkt):
    try:
        # MAVLink 2
        if pkt and pkt[0] == 0xFD and len(pkt) >= 21:
            length = pkt[1]
            msgid = pkt[7] | (pkt[8] << 8) | (pkt[9] << 16)
            payload = pkt[10:10+length]
            if msgid == 0 and len(payload) >= 9:
                custom_mode = int.from_bytes(payload[0:4], "little", signed=False)
                mav_type = payload[4]
                autopilot = payload[5]
                base_mode = payload[6]

                # Accept only real ArduPilot FC heartbeat.
                if autopilot == 3 and mav_type != 6:
                    return {
                        "custom_mode": custom_mode,
                        "mode": ARDUPLANE_MODE_NAMES.get(custom_mode, f"MODE {custom_mode}"),
                        "base_mode": base_mode,
                    }

        # MAVLink 1
        if pkt and pkt[0] == 0xFE and len(pkt) >= 17:
            length = pkt[1]
            msgid = pkt[5]
            payload = pkt[6:6+length]
            if msgid == 0 and len(payload) >= 9:
                custom_mode = int.from_bytes(payload[0:4], "little", signed=False)
                mav_type = payload[4]
                autopilot = payload[5]
                base_mode = payload[6]

                # Accept only real ArduPilot FC heartbeat.
                if autopilot == 3 and mav_type != 6:
                    return {
                        "custom_mode": custom_mode,
                        "mode": ARDUPLANE_MODE_NAMES.get(custom_mode, f"MODE {custom_mode}"),
                        "base_mode": base_mode,
                    }
    except Exception:
        pass

    return None


def run(cmd, timeout=2):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.DEVNULL, timeout=timeout).strip()
    except Exception:
        return ""

def network_ok():
    """
    REAL network health:
    Wi-Fi must be connected AND gateway must respond.
    """
    state = run("nmcli -t -f GENERAL.STATE dev show wlan0 | cut -d: -f2", timeout=2)
    if not state.startswith("100"):
        return False

    gw = run("ip route | awk '/default/ {print $3; exit}'", timeout=2)
    if not gw:
        return False

    ping = run(f"ping -c 1 -W 1 {gw}", timeout=2)
    return "1 received" in ping

def zt_ok():
    try:
        info = run("sudo zerotier-cli info", timeout=2)
        if "ONLINE" in info:
            return True
    except Exception:
        pass

    try:
        nets = run("sudo zerotier-cli listnetworks", timeout=3)
        if " OK " in (" " + nets.replace("\\t", " ") + " "):
            return True
    except Exception:
        pass

    try:
        if glob.glob("/sys/class/net/zt*"):
            return True
    except Exception:
        pass

    return False

def camera_ok():
    return bool(run("ping -c 1 -W 1 "+CAM_IP+""))



def mavlink_ok():
    try:
        with open(FLIGHT_MODE_CACHE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        age = time.time() - float(data.get("last_seen", 0))
        return age <= MAVLINK_GRACE_SECONDS
    except Exception:
        return False

def battery_text():
    try:
        return open("/tmp/siyi_battery_status.txt").read().strip()
    except:
        return "Bat ?"

def cpu_load_text():

    try:
        load = open("/proc/loadavg").read().split()[0]
        return f"CPU {load}"
    except Exception:
        return "CPU ?"

def temp_text():
    try:
        raw = open("/sys/class/thermal/thermal_zone0/temp").read().strip()
        c = int(raw) / 1000.0
        return f"Temp {c:.1f}°C"
    except Exception:
        return "Temp ?"

host_txt, host_cls = hosts_status()

items = [
    (battery_text(), "ok", None),
    ("Network", "ok" if network_ok() else "bad", "Network Down"),
    ("MAVLink", "ok" if mavlink_ok() else "bad", "MAVLink Down"),
    ("Camera", "ok" if camera_ok() else "bad", "Camera Down"),
    ("ZT", "ok" if zt_ok() else "bad", "ZT Down"),
    (host_txt, host_cls, None),
    (cpu_load_text(), "ok", None),
    (temp_text(), "ok", None),
]

out = []
for name, cls, down_text in items:
    if down_text and cls != "ok":
        txt = down_text
    elif name in ("Network", "MAVLink", "Camera", "ZT"):
        txt = f"{name} OK"
    else:
        txt = name
    # CPU_TEMP_VOICE_PILL_V1
    if txt.startswith("CPU Temp") or txt.startswith("Temp") or "°C" in txt:
        out.append(f'<a id="cpuTempPill" class="status-pill {cls}" title="Configure voice alerts" style="cursor:pointer;text-decoration:none" href="/cpu_temp_voice">{html.escape(txt)}</a>')
    elif txt.startswith("Bat "):
        # BATTERY_VOICE_PILL_LINK_V1
        out.append(f'<a id="batteryVoltPill" class="status-pill {cls}" title="Configure voice alerts" style="cursor:pointer;text-decoration:none" href="/cpu_temp_voice">{html.escape(txt)}</a>')
    else:
        out.append(f'<span class="status-pill {cls}">{html.escape(txt)}</span>')

print('<div id="top-status-bar">' + "".join(out) + '</div>')
