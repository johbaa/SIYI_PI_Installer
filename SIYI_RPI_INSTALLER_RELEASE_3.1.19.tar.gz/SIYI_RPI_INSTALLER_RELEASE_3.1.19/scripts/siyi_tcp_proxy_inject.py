#!/usr/bin/env python3
import socket, select, os, threading, time, datetime

LISTEN_HOST="0.0.0.0"
LISTEN_PORT=37256
# === CONFIG LOAD ===
import json
try:
    with open("/home/pi/siyi-config.json") as cf:
        CFG = json.load(cf)
except Exception:
    CFG = {}
CAM_HOST = CFG.get("camera_ip", "192.168.144.25")
# === END CONFIG ===
CAM_PORT=37256
FIFO="/tmp/siyi_record_proxy"

cam_sock = None
next_counter = 0
counter_lock = threading.Lock()

# Old static record commands, kept for compatibility
CMD_START = bytes.fromhex("55 66 aa bb 01 01 00 00 00 dc be 81 c6 17 5c 2c 01 09 84 d3 24")
CMD_STOP  = bytes.fromhex("55 66 aa bb 01 01 00 00 00 e2 be 81 7c c0 d5 00 00 00 06 04 15")

ACTIONS = {
    # Image
    "brightness_50": ("e3", bytes.fromhex("000032")),
    "brightness_51": ("e3", bytes.fromhex("000033")),
    "saturation_60": ("e3", bytes.fromhex("01003c")),
    "contrast_50":   ("e3", bytes.fromhex("020032")),
    "contrast_51":   ("e3", bytes.fromhex("020033")),

    # Exposure
    "ev_0":    ("e3", bytes.fromhex("040000")),
    "ev_1":    ("e3", bytes.fromhex("040001")),
    "ss_auto": ("e3", bytes.fromhex("070000")),
    "ss_1_30": ("e3", bytes.fromhex("070001")),

    # Stream resolution
    "stream_720p":  ("84", bytes.fromhex("01020005d002d00719")),
    "stream_1080p": ("84", bytes.fromhex("010280073804220619")),

    # Gimbal mode
    "gimbal_lock":   ("c8", bytes.fromhex("00")),
    "gimbal_follow": ("c8", bytes.fromhex("01")),
    "gimbal_fpv":    ("c8", bytes.fromhex("02")),

    # Auto recording
    "autorecord_on":  ("86", bytes.fromhex("01")),
    "autorecord_off": ("86", bytes.fromhex("00")),

    # Recording resolution
    "rec_720p":  ("84", bytes.fromhex("00020005d00220")),
    "rec_1080p": ("84", bytes.fromhex("00028007380420")),
    "rec_2k":    ("84", bytes.fromhex("0002000aa00598")),
    "rec_4k":    ("84", bytes.fromhex("0002000f700898")),
}

def crc32_mpeg2(data):
    crc = 0
    poly = 0x04C11DB7
    for b in data:
        crc ^= b << 24
        for _ in range(8):
            if crc & 0x80000000:
                crc = ((crc << 1) ^ poly) & 0xffffffff
            else:
                crc = (crc << 1) & 0xffffffff
    return crc

def build_packet(msg_type_hex, payload):
    global next_counter

    with counter_lock:
        counter = next_counter & 0xffff
        next_counter = (next_counter + 1) & 0xffff

    low = counter & 0xff
    high = (counter >> 8) & 0xff

    h = bytearray.fromhex("5566aabb")
    h += b"\x01"
    h += bytes([len(payload)])
    h += b"\x00\x00\x00"
    h += bytes([low, high])
    h += bytes.fromhex(msg_type_hex)

    mid = crc32_mpeg2(h).to_bytes(4, "little")
    body = h + mid + payload
    tail = crc32_mpeg2(body).to_bytes(4, "little")

    return bytes(body + tail)


def build_packet_class(packet_class, msg_type_hex, payload):
    global next_counter

    with counter_lock:
        counter = next_counter & 0xffff
        next_counter = (next_counter + 1) & 0xffff

    low = counter & 0xff
    high = (counter >> 8) & 0xff

    h = bytearray.fromhex("5566aabb")
    h += bytes([packet_class])
    h += bytes([len(payload)])
    h += b"\x00\x00\x00"
    h += bytes([low, high])
    h += bytes.fromhex(msg_type_hex)

    mid = crc32_mpeg2(h).to_bytes(4, "little")
    body = h + mid + payload
    tail = crc32_mpeg2(body).to_bytes(4, "little")

    return bytes(body + tail)

def build_siyi_time_packet():
    now = datetime.datetime.now()
    payload = bytes([
        0xea,
        now.year - 2019,
        now.month,
        now.day,
        now.hour,
        now.minute,
        now.second
    ])
    return now, build_packet_class(0x02, "91", payload)


def update_counter_from_qgc(data):
    global next_counter

    # SIYI packet minimum length is 20 bytes
    if len(data) < 20:
        return

    # Handle one or more complete packets in the TCP chunk
    i = 0
    while i + 20 <= len(data):
        if data[i:i+4] != b"\x55\x66\xaa\xbb":
            i += 1
            continue

        payload_len = data[i+5]
        total_len = 20 + payload_len

        if i + total_len > len(data):
            break

        low = data[i+9]
        high = data[i+10]
        counter = low | (high << 8)

        with counter_lock:
            # Keep injector close to the last real UniGCS packet.
            # Camera appears sequence-sensitive; do not run far ahead.
            next_counter = counter

        i += total_len


def parse_dynamic_command(cmd):
    """
    Supports:
      brightness:20
      brightness:80
      saturation:60
      contrast:50
      ev:1
      ss:1
    """
    if ":" not in cmd:
        return None

    name, val = cmd.split(":", 1)
    name = name.strip().lower()
    val = val.strip().lower()

    try:
        n = int(val)
    except Exception:
        return None

    n = max(0, min(255, n))

    if name == "brightness":
        return ("e3", bytes([0x00, 0x00, n]))
    if name == "saturation":
        return ("e3", bytes([0x01, 0x00, n]))
    if name == "contrast":
        return ("e3", bytes([0x02, 0x00, n]))
    if name == "ev":
        return ("e3", bytes([0x04, 0x00, n]))
    if name == "ss":
        return ("e3", bytes([0x07, 0x00, n]))

    return None


def inject_command(cmd):
    global cam_sock

    if not cam_sock:
        print("No active camera socket yet", flush=True)
        return

    try:
        dyn = parse_dynamic_command(cmd)
        if dyn:
            msg_type, payload = dyn
            packet = build_packet(msg_type, payload)
            cam_sock.sendall(packet)
            print(f"Injected {cmd}: {packet.hex()}", flush=True)
            return

        if cmd == "set_time_now":
            now, packet = build_siyi_time_packet()
            cam_sock.sendall(packet)
            print(f"Injected set_time_now {now.strftime('%Y-%m-%d %H:%M:%S')}: {packet.hex()}", flush=True)
            return

        if cmd == "start":
            cam_sock.sendall(CMD_START)
            print("Injected legacy RECORD START command", flush=True)
            return

        if cmd == "stop":
            cam_sock.sendall(CMD_STOP)
            print("Injected legacy RECORD STOP command", flush=True)
            return

        if cmd not in ACTIONS:
            print(f"Unknown command: {cmd}", flush=True)
            print("Available:", ", ".join(sorted(list(ACTIONS.keys()) + ["start", "stop"])), flush=True)
            return

        msg_type, payload = ACTIONS[cmd]
        packet = build_packet(msg_type, payload)

        cam_sock.sendall(packet)
        print(f"Injected {cmd}: {packet.hex()}", flush=True)

    except Exception as e:
        print(f"Inject failed for {cmd}: {e}", flush=True)

def fifo_loop():
    try:
        os.unlink(FIFO)
    except FileNotFoundError:
        pass

    os.mkfifo(FIFO, 0o666)
    os.chmod(FIFO, 0o666)

    print(f"Command FIFO ready: {FIFO}", flush=True)
    print(f"Use: echo gimbal_lock > {FIFO}", flush=True)

    last_cmd=None
    last_time=0

    while True:
        with open(FIFO, "r") as f:
            raw = f.read()

        cmds=[x.replace("\\n","").strip().lower() for x in raw.splitlines() if x.replace("\\n","").strip()]

        for cmd in cmds:
            now=time.time()

            # Allow repeated mode commands (important for gimbal)
            if cmd == last_cmd and now-last_time < 0.05:
                print(f"Ignored duplicate command: {cmd}", flush=True)
                continue

            last_cmd=cmd
            last_time=now

            inject_command(cmd)

def handle(qgc, addr):
    global cam_sock, next_counter

    print(f"QGC connected: {addr}", flush=True)

    cam = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    cam.connect((CAM_HOST, CAM_PORT))
    cam_sock = cam

    with counter_lock:
        next_counter = 0

    sockets = [qgc, cam]

    try:
        while True:
            r,_,_ = select.select(sockets, [], [])
            for s in r:
                data = s.recv(4096)
                if not data:
                    raise ConnectionError("socket closed")

                if s is qgc:
                    # Debug: log UniGCS -> camera SIYI packets
                    try:
                        i = 0
                        while i + 20 <= len(data):
                            if data[i:i+4] != b"\x55\x66\xaa\xbb":
                                i += 1
                                continue
                            plen = data[i+5]
                            total = 20 + plen
                            if i + total > len(data):
                                break
                            pkt = data[i:i+total]
                            if len(pkt) != 20:
                                print(f"REAL_QGC len={len(pkt)} hex={pkt.hex()}", flush=True)
                            i += total
                    except Exception as e:
                        print(f"REAL_QGC debug parse failed: {e}", flush=True)

                    update_counter_from_qgc(data)
                    cam.sendall(data)
                else:
                    try:
                        i = 0
                        while i + 20 <= len(data):
                            if data[i:i+4] != b"\x55\x66\xaa\xbb":
                                i += 1
                                continue
                            plen = data[i+5]
                            total = 20 + plen
                            if i + total > len(data):
                                break
                            pkt = data[i:i+total]
                            if len(pkt) != 20:
                                print(f"CAM_REPLY len={len(pkt)} hex={pkt.hex()}", flush=True)
                            i += total
                    except Exception as e:
                        print(f"CAM_REPLY debug parse failed: {e}", flush=True)

                    qgc.sendall(data)

    except Exception as e:
        print(f"QGC disconnected: {e}", flush=True)

    finally:
        try: qgc.close()
        except: pass
        try: cam.close()
        except: pass
        cam_sock = None

def main():
    threading.Thread(target=fifo_loop, daemon=True).start()

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((LISTEN_HOST, LISTEN_PORT))
    server.listen(1)

    print(f"SIYI TCP proxy listening on {LISTEN_HOST}:{LISTEN_PORT}", flush=True)
    print(f"Forwarding to {CAM_HOST}:{CAM_PORT}", flush=True)

    while True:
        qgc, addr = server.accept()
        handle(qgc, addr)

if __name__ == "__main__":
    main()
