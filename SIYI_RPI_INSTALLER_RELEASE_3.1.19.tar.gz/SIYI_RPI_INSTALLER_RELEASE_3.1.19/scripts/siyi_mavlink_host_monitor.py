#!/usr/bin/env python3
import json
import re
import subprocess
import time
from pathlib import Path

OUT = Path("/tmp/siyi_mavlink_host_activity.json")
ENDPOINTS = Path("/home/pi/siyi-webui/endpoints.json")

def load_hosts():
    try:
        eps = json.loads(ENDPOINTS.read_text())
        return {e.get("ip","").strip() for e in eps if e.get("ip","").strip() and e.get("mavlink", True)}
    except Exception:
        return set()

def write_state(state):
    tmp = OUT.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2))
    tmp.replace(OUT)

state = {}
write_state(state)

cmd = [
    "tcpdump",
    "-l",
    "-n",
    "-i", "any",
    "udp and dst port 14550"
]

while True:
    hosts = load_hosts()
    try:
        p = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            bufsize=1,
        )

        for line in p.stdout:
            now = time.time()
            hosts = load_hosts()

            for ip in hosts:
                if ip in line:
                    state[ip] = {
                        "last_seen": now,
                        "line": line.strip()
                    }
                    write_state(state)

    except Exception as e:
        state["_error"] = {
            "time": time.time(),
            "error": str(e)
        }
        write_state(state)
        time.sleep(3)
