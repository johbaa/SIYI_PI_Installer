#!/usr/bin/env python3
import datetime
import json
import socket
import sys
import time

CONFIG = "/home/pi/siyi-config.json"
DEFAULT_CAMERA_IP = "192.168.144.25"
CAMERA_PORT = 37256

def crc32_mpeg2(data):
    crc = 0
    poly = 0x04C11DB7
    for b in data:
        crc ^= b << 24
        for _ in range(8):
            if crc & 0x80000000:
                crc = ((crc << 1) ^ poly) & 0xffffffff
            else:
                crc = (crc << 1) & 0xffffffff
    return crc

def build_packet_class(packet_class, msg_type_hex, payload, counter=0):
    low = counter & 0xff
    high = (counter >> 8) & 0xff

    h = bytearray.fromhex("5566aabb")
    h += bytes([packet_class])
    h += bytes([len(payload)])
    h += b"\x00\x00\x00"
    h += bytes([low, high])
    h += bytes.fromhex(msg_type_hex)

    mid = crc32_mpeg2(h).to_bytes(4, "little")
    body = h + mid + payload
    tail = crc32_mpeg2(body).to_bytes(4, "little")
    return bytes(body + tail)

def build_siyi_time_packet():
    now = datetime.datetime.now()
    payload = bytes([
        0xea,
        now.year - 2019,
        now.month,
        now.day,
        now.hour,
        now.minute,
        now.second,
    ])
    return now, build_packet_class(0x02, "91", payload, counter=0)

def load_camera_ip():
    try:
        with open(CONFIG) as f:
            cfg = json.load(f)
        return cfg.get("camera_ip", DEFAULT_CAMERA_IP)
    except Exception:
        return DEFAULT_CAMERA_IP

def main():
    host = load_camera_ip()
    last_err = None

    for attempt in range(1, 6):
        now, pkt = build_siyi_time_packet()
        print(f"[DIRECT_TIME] Target {host}:{CAMERA_PORT}")
        print(f"[DIRECT_TIME] Sending attempt {attempt} {now.strftime('%Y-%m-%d %H:%M:%S')}: {pkt.hex()}")

        try:
            with socket.create_connection((host, CAMERA_PORT), timeout=5) as s:
                s.sendall(pkt)
                s.settimeout(3)
                try:
                    reply = s.recv(256)
                    print(f"[DIRECT_TIME] Reply attempt {attempt}: {reply.hex() if reply else '<empty>'}")
                except socket.timeout:
                    print(f"[DIRECT_TIME] No reply attempt {attempt}, packet still sent")

                print("[DIRECT_TIME] SENT")
                return 0

        except Exception as e:
            last_err = e
            print(f"[DIRECT_TIME] attempt {attempt} failed: {e}", file=sys.stderr)
            time.sleep(2)

    print(f"[DIRECT_TIME] ERROR: failed after retries: {last_err}", file=sys.stderr)
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
