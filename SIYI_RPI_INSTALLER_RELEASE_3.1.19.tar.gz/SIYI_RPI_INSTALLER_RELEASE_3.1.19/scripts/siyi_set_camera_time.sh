#!/bin/bash
set -e

FIFO="/tmp/siyi_record_proxy"

for i in $(seq 1 30); do
  if [ -p "$FIFO" ]; then
    echo set_time_now > "$FIFO"
    exit 0
  fi
  sleep 1
done

echo "ERROR: $FIFO not ready" >&2
exit 1
