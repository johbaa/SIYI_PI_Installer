#!/usr/bin/env python3
import time
from pymavlink import mavutil

OUT="/tmp/siyi_battery_status.txt"

def write(txt):
    with open(OUT, "w") as f:
        f.write(txt)

while True:
    try:
        m = mavutil.mavlink_connection("tcp:127.0.0.1:5760", source_system=254)
        while True:
            msg = m.recv_match(type="BATTERY_STATUS", blocking=True, timeout=5)
            if not msg:
                write("Bat ?")
                continue

            volts = list(getattr(msg, "voltages", []) or [])
            valid = [v for v in volts if isinstance(v, int) and 0 < v < 65535]

            if valid:
                total_v = sum(valid) / 1000.0
                write(f"Bat {total_v:.1f}V")
            else:
                write("Bat ?")
    except Exception:
        write("Bat ?")
        time.sleep(3)
