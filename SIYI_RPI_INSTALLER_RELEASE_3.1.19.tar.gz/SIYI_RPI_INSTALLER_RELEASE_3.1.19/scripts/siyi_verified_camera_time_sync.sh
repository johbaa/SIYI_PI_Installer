#!/bin/bash
set -e

FIFO="/tmp/siyi_record_proxy"
SERVICE="siyi-rec-proxy.service"
MARKER="Injected set_time_now"

echo "[TIME_SYNC] Waiting for $SERVICE active..."

for i in $(seq 1 40); do
  systemctl is-active --quiet "$SERVICE" && break
  sleep 1
done

systemctl is-active --quiet "$SERVICE" || {
  echo "[TIME_SYNC] ERROR: $SERVICE not active" >&2
  exit 1
}

echo "[TIME_SYNC] Waiting for FIFO $FIFO..."

for i in $(seq 1 40); do
  [ -p "$FIFO" ] && break
  sleep 1
done

[ -p "$FIFO" ] || {
  echo "[TIME_SYNC] ERROR: FIFO not ready" >&2
  exit 1
}

echo "[TIME_SYNC] Waiting for REC proxy runtime/log activity..."

for i in $(seq 1 20); do
  if journalctl -u "$SERVICE" --no-pager -n 30 | grep -qE "CAM_REPLY|FIFO|proxy|listening|Started"; then
    echo "[TIME_SYNC] REC proxy appears alive"
    break
  fi
  sleep 1
done

echo "[TIME_SYNC] Extra settle delay..."
sleep 5

SINCE="$(date '+%Y-%m-%d %H:%M:%S')"

for attempt in 1 2 3 4 5; do
  echo "[TIME_SYNC] Sending set_time_now attempt $attempt..."
  printf 'set_time_now\n' > "$FIFO"
  sleep 3

  if journalctl -u "$SERVICE" --since "$SINCE" --no-pager | grep -q "$MARKER"; then
    echo "[TIME_SYNC] VERIFIED: camera time packet injected"
    exit 0
  fi
done

echo "[TIME_SYNC] ERROR: no verified set_time_now injection in proxy log" >&2
exit 1
