#!/usr/bin/env bash
set -u

STATE="/tmp/siyi_param_refresh_state.json"
LOG="/tmp/siyi_param_refresh.log"

echo '{"running":true,"ok":false,"message":"Refreshing from FC..."}' > "$STATE"

if /home/pi/siyi_param_full_cache.py > "$LOG" 2>&1; then
  echo '{"running":false,"ok":true,"message":"Refresh complete"}' > "$STATE"
else
  MSG=$(tail -n 5 "$LOG" | tr '\n' ' ' | sed 's/"/'\''/g')
  echo "{\"running\":false,\"ok\":false,\"message\":\"Refresh failed: $MSG\"}" > "$STATE"
fi
