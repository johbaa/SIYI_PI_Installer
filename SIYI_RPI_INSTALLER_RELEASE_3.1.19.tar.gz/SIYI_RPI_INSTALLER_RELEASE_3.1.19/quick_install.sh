#!/bin/bash




set -e

echo "Downloading SIYI installer..."

cd /home/pi
ARCHIVE="/home/pi/siyi_installer.tar.gz"
wget -O "$ARCHIVE" "${SIYI_INSTALLER_URL:?Set SIYI_INSTALLER_URL to the release tarball URL}"

INSTALL_DIR="$(tar -tzf "$ARCHIVE" | awk -F/ 'NF { print $1; exit }')"
case "$INSTALL_DIR" in
  SIYI_RPI_INSTALLER_RELEASE_*) ;;
  *)
    echo "Invalid SIYI installer archive: unexpected top-level directory '$INSTALL_DIR'" >&2
    exit 1
    ;;
esac

tar -xzf "$ARCHIVE"
cd "/home/pi/$INSTALL_DIR"

chmod +x install.sh
./install.sh
