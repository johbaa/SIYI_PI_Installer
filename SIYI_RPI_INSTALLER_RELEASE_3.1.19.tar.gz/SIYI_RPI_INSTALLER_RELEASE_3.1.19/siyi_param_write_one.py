#!/usr/bin/env python3
import sys, json, time, os
from pymavlink import mavutil

CACHE="/tmp/siyi_param_cache.json"
RECENT_WRITES="/tmp/siyi_param_recent_writes.json"

def fail(msg):
    print(json.dumps({"ok": False, "error": msg}))
    raise SystemExit(1)

if len(sys.argv) != 3:
    fail("Usage: siyi_param_write_one.py PARAM_NAME VALUE")

name=sys.argv[1].strip()
new_value_raw=sys.argv[2].strip()

if not name:
    fail("Missing parameter name")

try:
    new_value=float(new_value_raw)
except Exception:
    fail("Value must be numeric")

try:
    cache=json.load(open(CACHE))
    params=cache.get("params", {})
except Exception:
    cache={"params":{}}
    params={}

old=params.get(name, {})
param_type=int(old.get("type", mavutil.mavlink.MAV_PARAM_TYPE_REAL32))

m=mavutil.mavlink_connection(
    "udp:127.0.0.1:14600",
    source_system=251,
    source_component=193
)

hb=m.wait_heartbeat(timeout=15)
if not hb:
    fail("No heartbeat from FC")

target_system=m.target_system
target_component=m.target_component

# Write exactly one parameter.
m.mav.param_set_send(
    target_system,
    target_component,
    name.encode("ascii"),
    float(new_value),
    param_type
)

# Verify by waiting for the matching PARAM_VALUE.
deadline=time.time()+8
verified=None

while time.time() < deadline:
    msg=m.recv_match(type="PARAM_VALUE", blocking=True, timeout=1)
    if not msg:
        continue

    pid=msg.param_id
    if isinstance(pid, bytes):
        pid=pid.decode(errors="ignore")
    pid=pid.strip("\x00")

    if pid == name:
        verified=msg
        break

if not verified:
    fail("No PARAM_VALUE confirmation received")

actual=float(verified.param_value)

# ArduPilot float params may round slightly.
if abs(actual - new_value) > 0.0001:
    fail(f"Verification mismatch: requested {new_value}, got {actual}")

# Update cache and recompute native enum label.
value_label = ""
if name in params:
    values = params[name].get("values") or {}
    keys = [str(int(actual)), str(actual)]
    for k in keys:
        if k in values:
            value_label = values[k]
            break

    params[name]["value"] = actual
    params[name]["value_label"] = value_label
else:
    params[name]={
        "name": name,
        "value": actual,
        "value_label": value_label,
        "type": param_type,
        "group": name.split("_",1)[0],
    }

cache["params"]=params
cache["created"]=int(time.time())

# Persist cache atomically.
try:
    tmp = CACHE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(cache, f, indent=2)
    os.replace(tmp, CACHE)
except Exception as e:
    fail(f"Cache update failed: {e}")

# Store verified recent write override so full-list refresh cannot briefly
# overwrite the UI with stale PARAM_REQUEST_LIST data.
try:
    try:
        recent=json.load(open(RECENT_WRITES))
    except Exception:
        recent={}

    recent[name]={
        "value": actual,
        "type": param_type,
        "ts": int(time.time())
    }

    tmp = RECENT_WRITES + ".tmp"
    with open(tmp, "w") as f:
        json.dump(recent, f, indent=2)
    os.replace(tmp, RECENT_WRITES)
except Exception as e:
    fail(f"Recent write override update failed: {e}")

print(json.dumps({
    "ok": True,
    "param": name,
    "value": actual,
    "old_value": old.get("value"),
    "type": param_type,
}))
