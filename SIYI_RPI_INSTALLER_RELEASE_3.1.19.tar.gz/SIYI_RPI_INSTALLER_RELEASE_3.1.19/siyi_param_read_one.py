#!/usr/bin/env python3

import sys, json, time
from pymavlink import mavutil

if len(sys.argv) != 2:
    print(json.dumps({"ok":False,"error":"missing param"}))
    raise SystemExit(1)

param=sys.argv[1].strip()

m=mavutil.mavlink_connection(
    "udp:127.0.0.1:14600",
    source_system=251,
    source_component=195
)

hb=m.wait_heartbeat(timeout=10)
if not hb:
    print(json.dumps({"ok":False,"error":"no heartbeat"}))
    raise SystemExit(1)

m.mav.param_request_read_send(
    m.target_system,
    m.target_component,
    param.encode("ascii"),
    -1
)

deadline=time.time()+5

while time.time() < deadline:
    msg=m.recv_match(type="PARAM_VALUE", blocking=True, timeout=1)
    if not msg:
        continue

    pid=msg.param_id
    if isinstance(pid, bytes):
        pid=pid.decode(errors="ignore")
    pid=pid.strip("\x00")

    if pid == param:
        print(json.dumps({
            "ok":True,
            "param":pid,
            "value":float(msg.param_value),
            "type":int(msg.param_type),
        }))
        raise SystemExit(0)

print(json.dumps({"ok":False,"error":"timeout"}))
raise SystemExit(1)
