#!/usr/bin/env python3
"""Refresh persistent ArduPlane parameter metadata without requiring FC access."""

from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
import time
import urllib.request
import xml.etree.ElementTree as ET

OUTPUT = Path('/etc/siyi/arduplane_param_metadata.json')
STATE_DIR = Path('/var/lib/siyi-param-metadata')
XML_CACHE = STATE_DIR / 'apm.pdef.xml'
LEGACY_XML = Path('/tmp/ardupilot_arduplane_apm.pdef.xml')
MIN_XML_SIZE = 1000
MAX_CACHE_AGE = 7 * 24 * 60 * 60
URLS = (
    'https://autotest.ardupilot.org/Parameters/ArduPlane/apm.pdef.xml',
    'https://raw.githubusercontent.com/ArduPilot/ParameterRepository/main/Plane-4.5/apm.pdef.xml',
)


def xml_is_usable(path: Path) -> bool:
    try:
        return path.is_file() and path.stat().st_size >= MIN_XML_SIZE
    except OSError:
        return False


def download_xml() -> tuple[Path, str]:
    STATE_DIR.mkdir(parents=True, exist_ok=True)

    if xml_is_usable(LEGACY_XML) and not xml_is_usable(XML_CACHE):
        shutil.copy2(LEGACY_XML, XML_CACHE)

    if xml_is_usable(XML_CACHE):
        age = time.time() - XML_CACHE.stat().st_mtime
        if age <= MAX_CACHE_AGE:
            return XML_CACHE, 'persistent cache'

    errors: list[str] = []
    for url in URLS:
        request = urllib.request.Request(
            url,
            headers={'User-Agent': 'SIYI-Pi-Param-Metadata/1'},
        )
        try:
            with urllib.request.urlopen(request, timeout=35) as response:
                data = response.read(32 * 1024 * 1024)
            if len(data) < MIN_XML_SIZE:
                raise ValueError(f'downloaded file is too small ({len(data)} bytes)')
            with tempfile.NamedTemporaryFile(
                mode='wb', dir=STATE_DIR, prefix='apm.pdef.', delete=False
            ) as handle:
                handle.write(data)
                temp_name = handle.name
            os.chmod(temp_name, 0o644)
            os.replace(temp_name, XML_CACHE)
            return XML_CACHE, url
        except Exception as exc:  # retain a usable older cache when refresh fails
            errors.append(f'{url}: {exc}')

    if xml_is_usable(XML_CACHE):
        return XML_CACHE, 'stale persistent cache; refresh failed: ' + '; '.join(errors)

    raise RuntimeError('Unable to obtain ArduPlane metadata XML: ' + '; '.join(errors))


def parse_metadata(path: Path) -> dict[str, dict]:
    root = ET.parse(path).getroot()
    params: dict[str, dict] = {}

    for param in root.findall('.//param'):
        raw_name = str(param.attrib.get('name', '')).strip()
        name = raw_name.split(':')[-1].strip().upper()
        if not name:
            continue

        fields: dict[str, str] = {}
        values: dict[str, str] = {}

        for field in param.findall('field'):
            key = str(field.attrib.get('name', '')).strip()
            value = (field.text or '').strip()
            if key and value:
                fields[key] = value

        for entry in param.findall('values/value'):
            code = str(entry.attrib.get('code', '')).strip()
            label = (entry.text or '').strip()
            if code and label:
                values[code] = label

        params[name] = {
            'humanName': str(param.attrib.get('humanName', '')).strip(),
            'documentation': str(param.attrib.get('documentation', '')).strip(),
            'user': str(param.attrib.get('user', '')).strip(),
            'fields': fields,
            'values': values,
        }

    if len(params) < 100:
        raise RuntimeError(f'Parsed metadata contains only {len(params)} parameters')
    return params


def write_json(params: dict[str, dict], source: str) -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        'created': int(time.time()),
        'source': source,
        'param_count': len(params),
        'params': params,
    }
    fd, temp_name = tempfile.mkstemp(prefix=OUTPUT.name + '.', dir=OUTPUT.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False, separators=(',', ':'))
            handle.write('\n')
        os.chmod(temp_name, 0o644)
        os.replace(temp_name, OUTPUT)
    except Exception:
        try:
            os.unlink(temp_name)
        except OSError:
            pass
        raise


def existing_json_is_usable() -> bool:
    try:
        raw = json.loads(OUTPUT.read_text(encoding='utf-8'))
        params = raw.get('params', {})
        sample = params.get('AIRSPEED_CRUISE', {})
        return (
            isinstance(params, dict)
            and len(params) >= 100
            and isinstance(sample, dict)
            and bool(
                sample.get('humanName')
                or sample.get('documentation')
                or sample.get('fields')
                or sample.get('values')
            )
        )
    except Exception:
        return False


def main() -> int:
    try:
        xml_path, source = download_xml()
        params = parse_metadata(xml_path)
        write_json(params, source)
        print(f'Metadata cache refreshed: {len(params)} parameters')
        print(OUTPUT)
        return 0
    except Exception as exc:
        if existing_json_is_usable():
            print(f'WARNING: metadata refresh failed; keeping existing cache: {exc}', file=sys.stderr)
            return 0
        print(f'ERROR: metadata refresh failed: {exc}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
