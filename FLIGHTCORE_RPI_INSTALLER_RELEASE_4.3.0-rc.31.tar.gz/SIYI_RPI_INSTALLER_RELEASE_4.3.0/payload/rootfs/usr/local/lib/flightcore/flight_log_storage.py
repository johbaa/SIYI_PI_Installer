#!/usr/bin/env python3
"""FlightCore Flight Log retention and deletion policy.

This module has no flight-control authority.  Automatic cleanup is fail-closed:
only completed logs with an exact successful cloud-sync receipt are eligible.
"""
from __future__ import annotations

import datetime
import json
import os
import re
import shutil
import tempfile
from pathlib import Path

ROOT = Path(os.environ.get("FLIGHTCORE_STORAGE_ROOT", "/"))
LOG_ROOT = ROOT / "var/lib/flightcore/flight-logs"
SYNC_STATE = ROOT / "var/lib/flightcore/flight-log-cloud-sync.json"
CONFIG = ROOT / "var/lib/flightcore/flight-log-storage.json"
AUDIT = ROOT / "var/lib/flightcore/flight-log-deletions.jsonl"
DEFAULT_MAX_BYTES = 5 * 1024 ** 3
MIN_MAX_BYTES = 256 * 1024 ** 2
MAX_MAX_BYTES = 48 * 1024 ** 3


def now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def atomic_json(path: Path, value, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix="." + path.name + ".", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, indent=2, sort_keys=True)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    finally:
        try:
            os.unlink(tmp)
        except FileNotFoundError:
            pass


def read_json(path: Path, default):
    try:
        value = json.loads(path.read_text())
        return value
    except Exception:
        return default


def config_read():
    value = read_json(CONFIG, {})
    maximum = int(value.get("max_bytes") or DEFAULT_MAX_BYTES) if isinstance(value, dict) else DEFAULT_MAX_BYTES
    maximum = max(MIN_MAX_BYTES, min(MAX_MAX_BYTES, maximum))
    return {"schema_version": 1, "max_bytes": maximum, "max_gib": round(maximum / 1024 ** 3, 2)}


def config_write(max_gib):
    try:
        maximum = int(float(max_gib) * 1024 ** 3)
    except Exception as exc:
        raise ValueError("Maximum log storage must be a number in GiB") from exc
    if maximum < MIN_MAX_BYTES or maximum > MAX_MAX_BYTES:
        raise ValueError("Maximum log storage must be between 0.25 and 48 GiB")
    value = {"schema_version": 1, "max_bytes": maximum, "max_gib": round(maximum / 1024 ** 3, 2), "updated_at": now()}
    atomic_json(CONFIG, value)
    return value


def valid_id(value):
    value = str(value or "")
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", value):
        raise ValueError("Invalid Flight Log ID")
    return value


def directory(log_id):
    log_id = valid_id(log_id)
    root = LOG_ROOT.resolve()
    target = (root / log_id).resolve()
    if root not in target.parents or not target.is_dir():
        raise ValueError("Flight Log not found")
    return target


def directory_size(path: Path):
    return sum(item.stat().st_size for item in path.rglob("*") if item.is_file() and not item.is_symlink())


def meta(path: Path):
    value = read_json(path / "meta.json", {})
    return value if isinstance(value, dict) else {}


def sync_logs():
    value = read_json(SYNC_STATE, {})
    logs = value.get("logs") if isinstance(value, dict) else {}
    return logs if isinstance(logs, dict) else {}


def audit(action, log_id, bytes_removed=0, actor="system", details=None):
    AUDIT.parent.mkdir(parents=True, exist_ok=True)
    entry = {"at": now(), "action": action, "flight_id": log_id, "bytes_removed": int(bytes_removed), "actor": actor}
    if details:
        entry["details"] = details
    fd = os.open(AUDIT, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o640)
    try:
        os.write(fd, (json.dumps(entry, separators=(",", ":"), sort_keys=True) + "\n").encode())
        os.fsync(fd)
    finally:
        os.close(fd)
    return entry


def entries():
    receipts = sync_logs()
    out = []
    if not LOG_ROOT.is_dir():
        return out
    for item in sorted((p for p in LOG_ROOT.iterdir() if p.is_dir()), key=lambda p: p.name, reverse=True):
        m = meta(item)
        receipt = receipts.get(item.name) if isinstance(receipts.get(item.name), dict) else {}
        out.append({
            "id": item.name,
            "bytes": directory_size(item),
            "status": str(m.get("status") or "unknown"),
            "started_at": m.get("started_at"),
            "cloud_status": str(receipt.get("status") or "not_uploaded"),
            "cloud_verified": receipt.get("status") == "uploaded" and bool(receipt.get("sha256")),
        })
    return out


def snapshot():
    cfg = config_read()
    logs = entries()
    used = sum(item["bytes"] for item in logs)
    disk = shutil.disk_usage(LOG_ROOT if LOG_ROOT.exists() else ROOT)
    return {
        "ok": True,
        "config": cfg,
        "used_bytes": used,
        "remaining_allocation_bytes": max(0, cfg["max_bytes"] - used),
        "over_limit_bytes": max(0, used - cfg["max_bytes"]),
        "flight_count": len(logs),
        "disk_free_bytes": disk.free,
        "logs": logs,
    }


def delete_local(log_id, actor="manual", allow_unsynced=True):
    target = directory(log_id)
    m = meta(target)
    if str(m.get("status") or "") != "complete":
        raise RuntimeError("Active or incomplete Flight Logs cannot be deleted")
    receipt = sync_logs().get(target.name)
    verified = isinstance(receipt, dict) and receipt.get("status") == "uploaded" and bool(receipt.get("sha256"))
    if not allow_unsynced and not verified:
        raise RuntimeError("Flight Log has not been successfully synchronized and verified in cloud storage")
    size = directory_size(target)
    shutil.rmtree(target)
    entry = audit("delete_local", target.name, size, actor, {"cloud_verified": verified})
    return {"ok": True, "deleted": True, "scope": "local", "flight_id": target.name, "bytes_removed": size, "audit": entry}


def enforce_quota(actor="automatic-quota"):
    cfg = config_read()
    current = entries()
    used = sum(item["bytes"] for item in current)
    removed = []
    for item in sorted(current, key=lambda row: (str(row.get("started_at") or ""), row["id"])):
        if used <= cfg["max_bytes"]:
            break
        if item["status"] != "complete" or not item["cloud_verified"]:
            continue
        result = delete_local(item["id"], actor=actor, allow_unsynced=False)
        used -= int(result["bytes_removed"])
        removed.append(result["flight_id"])
    return {"ok": True, "max_bytes": cfg["max_bytes"], "used_bytes": used, "removed": removed, "still_over_limit_bytes": max(0, used - cfg["max_bytes"])}
