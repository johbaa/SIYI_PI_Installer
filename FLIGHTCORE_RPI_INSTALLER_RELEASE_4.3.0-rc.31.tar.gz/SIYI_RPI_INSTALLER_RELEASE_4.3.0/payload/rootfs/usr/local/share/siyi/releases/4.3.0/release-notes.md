# FlightCore 4.3.0 RC31

Canonical machine identity: `4.3.0-rc.31`. Build: `20260821.133000-31c8f52`.

RC31 corrects the Airlink recovery failure proven during physical RC30 acceptance. Its exact parent is published RC30 build `20260821.111225-30b7e41`.

## Airlink recovery correction

- Recovery is successful only after WebRTC statistics prove that decoded frames are increasing.
- Completed WHEP negotiation without decoded frames remains a failure and does not reset retry backoff.
- Legacy automatic recovery requests are suppressed; only the RC31 Airlink manager schedules retries.
- Retry delays increase through 2, 4, 8, 15 and 30 seconds.
- The old Airlink video element source, media track and peer connection are fully detached before replacement.
- A visible **Recover Airlink** button performs one complete Airlink-only decoder rebuild.
- MediaMTX readiness gating, request timeouts, cancellation, generation protection and recovery journaling remain active.

## Preserved RC30 behavior

- Manual local/cloud/both Flight Log deletion remains available while disarmed.
- The protected 0.25-48 GiB local Flight Log quota remains unchanged.
- SIYI video, telemetry, joystick/control and flight-controller failsafe authority remain outside Airlink recovery.
- Recovery does not reload Ground Station or issue RTL, SET_MODE or other flight commands.

## Compatibility and acceptance

The exact published RC30 parent is checksum-pinned. Retained clean historical upgrade routes and genuinely fresh installation remain supported. Physical RC30-to-RC31 upgrade, repeated Android Airlink power interruptions, automatic and manual recovery, and uninterrupted SIYI/telemetry/joystick operation remain external acceptance gates.
