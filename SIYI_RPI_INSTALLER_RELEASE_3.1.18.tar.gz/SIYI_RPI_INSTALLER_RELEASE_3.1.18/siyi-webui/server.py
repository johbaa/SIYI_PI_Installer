import threading

# === CONFIG LOAD ===
import json
from email.utils import parsedate_to_datetime
from zoneinfo import ZoneInfo
try:
    with open("/home/pi/siyi-config.json") as cf:
        CFG = json.load(cf)
except Exception:
    CFG = {}

CAM_IP = CFG.get("camera_ip", "192.168.144.25")
QGC_HOSTS = CFG.get("qgc_hosts", [])
VIDEO_PORT = CFG.get("video_port", 5600)
# === END CONFIG ===

RELEASE_VERSION_FILE = "/etc/siyi/release_version"

def get_release_version():
    try:
        with open(RELEASE_VERSION_FILE, "r", encoding="utf-8") as f:
            v = f.read().strip()
        return v if v else "unknown"
    except Exception:
        return "unknown"

VERSION = get_release_version()


# === SOFTWARE_UPDATE_V3 ===
SOFTWARE_UPDATE_MANIFEST_URL = (
    "https://raw.githubusercontent.com/"
    "johbaa/SIYI_PI_Installer/main/manifest.json"
)
SOFTWARE_UPDATE_LOG_FILE = "/tmp/siyi_webui_update.log"
SOFTWARE_UPDATE_PID_FILE = "/run/siyi-github-upgrade.pid"
SOFTWARE_UPDATE_STATE_FILE = "/var/lib/siyi-upgrade/state.json"
SOFTWARE_UPDATE_LAUNCHER = "/usr/local/sbin/siyi-github-upgrade-launch"
SOFTWARE_UPDATE_PREFERENCES_FILE = "/var/lib/siyi-upgrade/preserve_preferences.json"
# SOFTWARE_UPDATE_NO_WIZARD_AFTER_UPGRADE_V1
SOFTWARE_UPDATE_COMPLETED_FILE = "/var/lib/siyi-upgrade/upgrade_completed"
SOFTWARE_UPDATE_ACTIVE_STATUSES = {
    "starting", "checking", "downloading", "verifying", "backing_up",
    "installing", "restoring", "restarting",
}
SOFTWARE_UPDATE_PRESERVE_GROUPS = (
    ("buttons", "Button assignments and safety"),
    ("flaps", "Flap configuration"),
    ("mavlink", "MAVLink hosts and endpoints"),
    ("camera", "Camera and core SIYI configuration"),
    ("gimbal", "Gimbal presets, zero and virtual settings"),
    ("voice", "CPU temperature voice settings"),
    ("video", "Video source configuration"),
)
SOFTWARE_UPDATE_DEFAULT_PRESERVE = tuple(
    key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS
)


def _software_version_tuple(value):
    value = str(value or "").strip()
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", value):
        raise ValueError("Invalid release version: " + value)
    return tuple(int(part) for part in value.split("."))


def software_update_is_newer(candidate, current):
    return _software_version_tuple(candidate) > _software_version_tuple(current)


# SOFTWARE_UPDATE_MANIFEST_CACHE_BYPASS_V1
def software_update_manifest():
    separator = "&" if "?" in SOFTWARE_UPDATE_MANIFEST_URL else "?"
    manifest_url = (
        SOFTWARE_UPDATE_MANIFEST_URL
        + separator
        + "cache_bust="
        + str(time.time_ns())
    )
    req = urllib.request.Request(
        manifest_url,
        headers={
            "User-Agent": "SIYI-Pi-Updater/4",
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
        },
    )
    with urllib.request.urlopen(req, timeout=8) as response:
        raw = response.read(65536)
    data = json.loads(raw.decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("GitHub manifest is not a JSON object")
    stable = str(data.get("stable", "")).strip()
    _software_version_tuple(stable)
    return {"stable": stable}


# SOFTWARE_UPDATE_PID_EPERM_FIX_V1
# The upgrade worker runs as root while the WebUI runs as pi. On Linux,
# os.kill(pid, 0) raises PermissionError when the process exists but the
# caller is not allowed to signal it. That means "running", not "stopped".
def software_update_pid_running():
    try:
        with open(SOFTWARE_UPDATE_PID_FILE, "r", encoding="utf-8") as f:
            pid = int(f.read().strip())
    except (OSError, ValueError):
        return False

    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def software_update_state():
    state = {
        "running": False,
        "status": "idle",
        "progress": 0,
        "stage": "No upgrade is running",
        "from_version": get_release_version(),
        "to_version": "",
        "started_at": "",
        "updated_at": "",
        "technical_log": "",
        "error": "",
    }
    state_mtime = 0.0
    try:
        state_mtime = os.path.getmtime(SOFTWARE_UPDATE_STATE_FILE)
        with open(SOFTWARE_UPDATE_STATE_FILE, "r", encoding="utf-8") as f:
            loaded = json.load(f)
        if isinstance(loaded, dict):
            state.update(loaded)
    except Exception:
        pass

    pid_running = software_update_pid_running()
    declared_running = bool(state.get("running"))
    status = str(state.get("status", "idle"))
    startup_grace = (
        declared_running
        and status == "starting"
        and state_mtime > 0
        and (time.time() - state_mtime) < 30
    )
    running = bool(pid_running or startup_grace)
    state["running"] = running

    if declared_running and not running and status in SOFTWARE_UPDATE_ACTIVE_STATUSES:
        state["status"] = "failed"
        state["progress"] = round(max(0.0, min(99.0, float(state.get("progress", 0) or 0))), 1)
        state["stage"] = "Upgrade process stopped unexpectedly"
        if not state.get("error"):
            state["error"] = "The upgrade process is no longer running."

    try:
        state["progress"] = round(max(0.0, min(100.0, float(state.get("progress", 0) or 0))), 1)
    except Exception:
        state["progress"] = 0
    for key in (
        "status", "stage", "from_version", "to_version", "started_at",
        "updated_at", "technical_log", "error",
    ):
        state[key] = str(state.get(key, "") or "")
    return state


def software_update_running():
    return bool(software_update_state().get("running"))


def software_update_lock_active():
    return software_update_running()


def software_update_log_tail(limit=30000):
    try:
        with open(SOFTWARE_UPDATE_LOG_FILE, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - limit), os.SEEK_SET)
            return f.read().decode("utf-8", errors="replace")
    except Exception:
        return "Waiting for upgrade status..."


def software_update_status_payload():
    state = software_update_state()
    state["current"] = get_release_version()
    state["log"] = software_update_log_tail()
    return state


def software_update_preserve_preferences():
    allowed = {key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS}
    try:
        with open(SOFTWARE_UPDATE_PREFERENCES_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        values = data.get("preserve", [])
        if not isinstance(values, list):
            raise ValueError("preserve is not a list")
        requested = {str(value) for value in values}
        # Preferences written before video-source support had no schema marker.
        # Preserve the new setting by default once, while still respecting a
        # deliberate unchecked choice saved by the new UI.
        if int(data.get("schema_version", 1) or 1) < 2:
            requested.add("video")
        if not requested.issubset(allowed):
            raise ValueError("unknown preservation group")
        return tuple(
            key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS
            if key in requested
        )
    except FileNotFoundError:
        return SOFTWARE_UPDATE_DEFAULT_PRESERVE
    except Exception:
        return SOFTWARE_UPDATE_DEFAULT_PRESERVE


def software_update_validate_preserve_groups(values):
    allowed = {key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS}
    requested = [str(value).strip() for value in values if str(value).strip()]
    unknown = [value for value in requested if value not in allowed]
    if unknown:
        raise ValueError("Unknown preservation option: " + ", ".join(unknown))
    requested_set = set(requested)
    return tuple(
        key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS
        if key in requested_set
    )


def software_update_page():
    current = get_release_version()
    state = software_update_state()
    running = bool(state.get("running"))
    latest = "Unavailable"
    error = ""
    update_available = False

    try:
        latest = software_update_manifest()["stable"]
        update_available = software_update_is_newer(latest, current)
    except Exception as exc:
        error = str(exc)

    if running:
        state_text = "Installation is running"
        state_class = "warn"
    elif error:
        state_text = "Could not check GitHub"
        state_class = "bad"
    elif update_available:
        state_text = "A newer published release is available"
        state_class = "ok"
    else:
        state_text = "This system is up to date"
        state_class = "ok"

    disabled = "disabled" if (running or not update_available) else ""
    button_text = "Installation running..." if running else "Install published update"
    error_html = (
        "<p class='bad'><b>GitHub check failed:</b> " + esc(error) + "</p>"
        if error else ""
    )

    selected_preferences = set(software_update_preserve_preferences())
    selectable_rows = []
    for key, label in SOFTWARE_UPDATE_PRESERVE_GROUPS:
        checked = "checked" if key in selected_preferences else ""
        selectable_rows.append(
            "<label style='display:flex;align-items:center;gap:10px;"
            "padding:7px 0;cursor:pointer;'>"
            f"<input style='pointer-events:auto;width:auto;' type='checkbox' "
            f"name='preserve' value='{esc(key)}' data-label='{esc(label)}' {checked}>"
            f"<span>{esc(label)}</span>"
            "</label>"
        )
    selectable_html = "".join(selectable_rows)

    return f"""
    <h1>Software Update</h1>

    <div class='card'>
      <h2>Published release</h2>
      <table>
        <tr><th>Current installed version</th><td><b>{esc(current)}</b></td></tr>
        <tr><th>Latest published version</th><td><b>{esc(latest)}</b></td></tr>
        <tr><th>Status</th><td class='{state_class}'><b>{esc(state_text)}</b></td></tr>
      </table>
      {error_html}
    </div>

    <form method='post' action='/software_update_start'
          data-current='{esc(current)}' data-latest='{esc(latest)}'
          onsubmit='return softwareUpdateConfirm(this);'>
      <div class='card'>
        <h2>Settings to preserve</h2>
        <p class='small'>
          Checked user settings are restored after a successful upgrade.
          Unchecked groups are reset to the defaults supplied by the new release.
          A complete safety backup is always retained for rollback.
        </p>

        <h3>Always preserved</h3>
        <label style='display:flex;align-items:center;gap:10px;padding:7px 0;opacity:.85;'>
          <input style='width:auto;' type='checkbox' checked disabled>
          <span><b>Wi-Fi configuration</b> — Always preserved</span>
        </label>
        <label style='display:flex;align-items:center;gap:10px;padding:7px 0;opacity:.85;'>
          <input style='width:auto;' type='checkbox' checked disabled>
          <span><b>ZeroTier identity and membership</b> — Always preserved</span>
        </label>

        <h3>User-selectable settings</h3>
        {selectable_html}

        <label style='display:flex;align-items:center;gap:10px;padding:12px 0;cursor:pointer;'>
          <input style='pointer-events:auto;width:auto;' type='checkbox'
                 name='remember' value='1' checked>
          <span>Remember these choices for future upgrades</span>
        </label>

        <button style='pointer-events:auto;min-width:220px;' {disabled}>{esc(button_text)}</button>

        <p class='small'>
          The button is enabled only when the GitHub version is newer than the installed version.
          The release checksum is verified before installation.
        </p>
      </div>
    </form>

    <script>
    function softwareUpdateConfirm(form){{
      const selected = Array.from(form.querySelectorAll("input[name='preserve']:checked"))
        .map(function(input){{ return input.dataset.label || input.value; }});
      let message = 'Upgrade ' + form.dataset.current + ' → ' + form.dataset.latest + '?\\n\\n';
      message += 'Always preserved:\\n• Wi-Fi configuration\\n• ZeroTier identity and membership\\n\\n';
      if(selected.length){{
        message += 'Also preserve:\\n• ' + selected.join('\\n• ');
      }}else{{
        message += 'No selectable user settings are selected.\\n'
          + 'Release defaults will be used for all selectable groups.';
      }}
      message += '\\n\\nThe WebUI will be locked during installation.';
      if(!confirm(message)) return false;
      if(window.siyiUpgradeShowStarting){{
        window.siyiUpgradeShowStarting(form.dataset.current, form.dataset.latest);
      }}
      return true;
    }}
    </script>
    """
# === SOFTWARE_UPDATE_V3 END ===
#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse, parse_qsl
import subprocess
import socket
socket.setdefaulttimeout(5)
from pymavlink.dialects.v20 import common as mavlink2
from pymavlink.dialects.v20 import ardupilotmega as mavlink2
import shlex, os, csv, html, time, shutil, re, json, urllib.request, urllib.parse, urllib.error, zipfile, tempfile

PORT=8080

BUTTON_MAP="/home/pi/button_map.csv"
MAVCONF="/etc/mavlink-router/main.conf"
VIDEO_SERVICE="/etc/systemd/system/siyi-video-dual.service"
VIDEO_SOURCE_CONFIG="/etc/siyi/video_source.json"
VIDEO_SOURCE_STATUS="/run/siyi-video-source/status.json"
VIDEO_SOURCE_CONTROL="/usr/local/sbin/siyi-video-source-control"
BACKUP_DIR="/home/pi/siyi-webui/backups"
ENDPOINTS_FILE="/etc/siyi/endpoints.json"
ZT_CONFIG_FILE="/etc/siyi/zerotier_config.json"
ZT_TOKEN_FILE="/etc/siyi/zerotier_api_token"
BUTTON_SAFETY_FILE="/etc/siyi/button_safety.json"
GIMBAL_PRESETS_FILE="/etc/siyi/gimbal_presets.json"
GIMBAL_STATE_FILE="/home/pi/siyi_gimbal_state.json"
GIMBAL_ZERO_FILE="/etc/siyi/gimbal_zero.json"
FLIGHT_SAFETY_ACTIONS=["MANUAL","FBWA","AUTOTUNE","CRUISE","AUTO","LOITER","RTL","TAKEOFF","QHOVER","QLOITER","QLAND","QRTL"]



def send_mavlink_tcp5760(pkt):
    try:
        with socket.create_connection(("127.0.0.1", 5760), timeout=0.8) as sock:
            sock.sendall(pkt)
        return True
    except Exception as e:
        print("[WEBUI_TCP5760_SEND_FAIL]", repr(e), flush=True)
        return False

FLIGHT_MODE_CACHE_FILE="/tmp/siyi_flight_mode.json"
BUTTON_SAFETY_FILE="/etc/siyi/button_safety.json"

def read_pi_ui_mode_safety_blockers():

    default_block = {"MANUAL", "TAKEOFF"}

    try:
        with open(BUTTON_SAFETY_FILE, encoding="utf-8") as f:
            data = json.load(f)

        vals = data.get("block_when_armed", list(default_block))

        if not isinstance(vals, list):
            return default_block

        allowed = {
            "MANUAL", "FBWA", "AUTOTUNE", "CRUISE", "LOITER", "RTL",
            "TAKEOFF", "QHOVER", "QLOITER", "QLAND", "QRTL"
        }

        return {
            str(x).strip()
            for x in vals
            if str(x).strip() in allowed
        }

    except Exception:
        return default_block

def vehicle_is_armed_now():

    try:
        data = flight_mode_state_read_once()
        base_mode = int(data.get("base_mode", 0) or 0)
        return bool(base_mode & 128)

    except Exception:
        return False



ARDUPLANE_MODE_NAMES = {
    0:"MANUAL", 1:"CIRCLE", 2:"STABILIZE", 3:"TRAINING", 4:"ACRO",
    5:"FBWA", 6:"FBWB", 7:"CRUISE", 8:"AUTOTUNE", 10:"AUTO",
    11:"RTL", 12:"LOITER", 13:"TAKEOFF", 15:"GUIDED", 16:"INITIALISING",
    17:"QSTABILIZE", 18:"QHOVER", 19:"QLOITER", 20:"QLAND",
    21:"QRTL", 22:"QAUTOTUNE", 23:"QACRO", 24:"THERMAL",
    25:"LOITER_TO_QLAND", 26:"AUTOLAND"
}

def _parse_autopilot_heartbeat(pkt):
    try:
        if pkt and pkt[0] == 0xFD and len(pkt) >= 21:
            length = pkt[1]
            msgid = pkt[7] | (pkt[8] << 8) | (pkt[9] << 16)
            payload = pkt[10:10+length]
            if msgid == 0 and len(payload) >= 9:
                custom_mode = int.from_bytes(payload[0:4], "little", signed=False)
                mav_type = payload[4]
                autopilot = payload[5]
                base_mode = payload[6]
                if autopilot == 3 and mav_type != 6:
                    return (ARDUPLANE_MODE_NAMES.get(custom_mode, f"MODE {custom_mode}"), custom_mode, base_mode)

        if pkt and pkt[0] == 0xFE and len(pkt) >= 17:
            length = pkt[1]
            msgid = pkt[5]
            payload = pkt[6:6+length]
            if msgid == 0 and len(payload) >= 9:
                custom_mode = int.from_bytes(payload[0:4], "little", signed=False)
                mav_type = payload[4]
                autopilot = payload[5]
                base_mode = payload[6]
                if autopilot == 3 and mav_type != 6:
                    return (ARDUPLANE_MODE_NAMES.get(custom_mode, f"MODE {custom_mode}"), custom_mode, base_mode)
    except Exception:
        pass
    return None

def _write_flight_mode_cache(mode, custom_mode, base_mode):
    try:
        tmp = FLIGHT_MODE_CACHE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({
                "mode": mode,
                "custom_mode": custom_mode,
                "base_mode": base_mode,
                "last_seen": time.time(),
                "source": "server_mode_monitor"
            }, f)
        os.replace(tmp, FLIGHT_MODE_CACHE_FILE)
    except Exception as e:
        print("[MODE_MONITOR_CACHE_WRITE_FAIL]", repr(e), flush=True)

def _mode_monitor_loop():
    while True:
        try:
            print("[MODE_MONITOR_TCP5760] connecting to 127.0.0.1:5760", flush=True)

            with socket.create_connection(("127.0.0.1", 5760), timeout=3.0) as sock:
                sock.settimeout(1.0)
                mav = mavlink2.MAVLink(None)

                print("[MODE_MONITOR_TCP5760] connected", flush=True)

                while True:
                    try:
                        data = sock.recv(4096)
                        if not data:
                            raise RuntimeError("TCP5760 closed")

                        for b in data:
                            try:
                                msg = mav.parse_char(bytes([b]))
                            except Exception:
                                msg = None

                            if not msg:
                                continue

                            if msg.get_type() == "HEARTBEAT":
                                try:
                                    autopilot = int(getattr(msg, "autopilot", -1))
                                    mav_type = int(getattr(msg, "type", -1))
                                    custom_mode = int(getattr(msg, "custom_mode", -1))
                                    base_mode = int(getattr(msg, "base_mode", 0))

                                    if autopilot == 3 and mav_type != 6:
                                        mode = ARDUPLANE_MODE_NAMES.get(custom_mode, f"MODE {custom_mode}")
                                        _write_flight_mode_cache(mode, custom_mode, base_mode)
                                except Exception as e:
                                    print("[MODE_MONITOR_TCP5760_HEARTBEAT_FAIL]", repr(e), flush=True)

                    except socket.timeout:
                        pass

        except Exception as e:
            print("[MODE_MONITOR_TCP5760_FAIL]", repr(e), flush=True)
            time.sleep(1)

def start_mode_monitor_once():
    try:
        if getattr(start_mode_monitor_once, "_started", False):
            return
        start_mode_monitor_once._started = True
        t = threading.Thread(target=_mode_monitor_loop, daemon=True)
        t.start()
    except Exception as e:
        print("[MODE_MONITOR_START_FAIL]", repr(e), flush=True)

start_mode_monitor_once()

def flight_mode_state_read_once(timeout=0):
    try:
        data=json.load(open(FLIGHT_MODE_CACHE_FILE, encoding="utf-8"))
        last=float(data.get("last_seen",0) or 0)
        age=round(time.time()-last,1) if last else None
        return {
            "mode":data.get("mode","UNKNOWN"),
            "custom_mode":data.get("custom_mode"),
            "age_s":age,
            "last_seen":last,
            "base_mode":data.get("base_mode"),
            "source":data.get("source","cache_only")
        }
    except Exception:
        return {
            "mode":"UNKNOWN",
            "custom_mode":None,
            "age_s":None,
            "last_seen":0,
            "base_mode":None,
            "source":"none"
        }


SETUP_COMPLETE_FILE="/etc/siyi/setup_complete.json"
SETUP_SKIP_FILE="/tmp/siyi_setup_skip"

WIFI_PASSWORD_STORE="/home/pi/siyi-webui/wifi_passwords.json"

def wifi_pw_store_read():
    try:
        if os.path.exists(WIFI_PASSWORD_STORE):
            return json.load(open(WIFI_PASSWORD_STORE, encoding="utf-8"))
    except Exception:
        pass
    return {}

def wifi_pw_store_write(d):
    try:
        os.makedirs(os.path.dirname(WIFI_PASSWORD_STORE), exist_ok=True)
        with open(WIFI_PASSWORD_STORE, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=2)
        os.chmod(WIFI_PASSWORD_STORE, 0o600)
    except Exception as e:
        print("wifi password store write failed:", e)

def wifi_pw_get(name):
    return wifi_pw_store_read().get(name, "")

def wifi_pw_set(name, password):
    d = wifi_pw_store_read()
    d[name] = password
    wifi_pw_store_write(d)

def wifi_pw_delete(name):
    d = wifi_pw_store_read()
    if name in d:
        del d[name]
        wifi_pw_store_write(d)


def setup_config_is_valid():
    try:
        eps = load_endpoints()
        return (
            len([e for e in eps if e.get("ip","").strip()]) >= 1
            and bool(zt_network_id_current())
            and bool(zt_read_token())
        )
    except Exception:
        return False

def setup_is_complete():
    try:
        if os.path.exists(SETUP_COMPLETE_FILE):
            return setup_config_is_valid()

        return False
    except Exception:
        return False

def setup_should_force():
    # A software upgrade must return to the normal WebUI, not reopen the
    # first-install wizard. The wizard remains available manually.
    if os.path.exists(SOFTWARE_UPDATE_COMPLETED_FILE):
        return False
    return (not setup_is_complete()) and (not os.path.exists(SETUP_SKIP_FILE))

def setup_banner():
    if setup_config_is_valid():
        return ""
    return """
    <div class='card' style='margin-bottom:16px;border:2px solid #d39e00;background:#fff3cd;color:#3b2f00;'>
      <h2 style='margin-top:0;color:#3b2f00;'>⚠ First setup incomplete</h2>
      <p>ZeroTier and at least one endpoint host should be configured.</p>
      <a href='/first_setup'><button style='pointer-events:auto;'>Open Setup Wizard</button></a>
    </div>
    """

def first_setup_page():
    return f"""
    <h1>First Setup Wizard</h1>

    <div class='card'>
      <p>This setup appears until completed.</p>
      <p>You can skip for now and continue using the UI during this boot.</p>
    </div>

    <form method='post' action='/first_setup_save'>

      <div class='card'>
        <h2>ZeroTier</h2>

        <label>Network ID</label>
        <input style='pointer-events:auto;' name='nwid'
               value='{esc(zt_network_id_current())}'
               placeholder='ZeroTier network ID'>

        <label>API Token</label>
        <input style='pointer-events:auto;'
               id='fstoken'
               type='password'
               name='token'
               value='{esc(zt_read_token())}'
               placeholder='ZeroTier API token'>

        <label style='display:block;margin-top:8px;'>
          <input type='checkbox'
                 style='width:auto;'
                 onclick="document.getElementById('fstoken').type=this.checked?'text':'password'">
          Show token
        </label>
      </div>

      <div class='card'>
        <h2>Host Endpoint</h2>

        <label>Host name</label>
        <input style='pointer-events:auto;' name='name'
               placeholder='Mac / Android / QGC'>

        <label>Host IP</label>
        <input style='pointer-events:auto;' name='ip'
               placeholder='192.168.x.x'>
      </div>

      <div class='card'>
        <h2>Optional Additional WiFi</h2>

        <label>SSID</label>
        <input style='pointer-events:auto;' name='ssid'
               placeholder='Optional SSID'>

        <label>Password</label>
        <input style='pointer-events:auto;'
               id='fswifi'
               type='password'
               name='password'
               placeholder='Optional password'>

        <label style='display:block;margin-top:8px;'>
          <input type='checkbox'
                 style='width:auto;'
                 onclick="document.getElementById('fswifi').type=this.checked?'text':'password'">
          Show password
        </label>
      </div>

      <div class='card'>
        <button style='pointer-events:auto;'>
          Save and Finish Setup
        </button>

        <button style='pointer-events:auto;margin-left:12px;'
                formaction='/first_setup_skip'>
          Skip for now
        </button>
      </div>

    </form>
    """

SERVICES=[
 "siyi-button-bridge",
 "siyi-video-source",
 "siyi-video-dual",
 "mediamtx",
 "mavlink-router",
 "zerotier-one",
 "siyi-rec-proxy",
 "siyi-rec-redirect",
 "siyi-webui",
]



STATUS_LABELS={
    "active":"Running",
    "activating":"Waiting / Starting",
    "failed":"Error",
    "inactive":"Stopped",
    "unknown":"Unknown",
}


SERVICE_GROUPS = {
    "Flight Control": ["mavlink-router"],
    "Video System": ["siyi-video-source", "siyi-video-dual", "mediamtx", "siyi-rec-proxy", "siyi-rec-redirect"],
    "Control System": ["siyi-button-bridge"],
    "Network": ["zerotier-one"],
    "System": ["siyi-webui"],
}

SERVICE_LABELS={
    "siyi-button-bridge":"Button Control Bridge",
    "siyi-video-source":"Selected Video Source",
    "siyi-video-dual":"Video UDP Forwarder",
    "mavlink-router":"MAVLink Router",
    "zerotier-one":"ZeroTier Network",
    "siyi-rec-proxy":"Camera / Recording Proxy",
    "siyi-rec-redirect":"Camera Control Redirect",
    "siyi-webui":"Web Interface",
}

ACTIONS=[
"NO_ACTION","MANUAL","FBWA","AUTOTUNE","CRUISE","AUTO","FLAPS",
"VIDEO_SOURCE","VIDEO_SOURCE_SIYI","VIDEO_SOURCE_HDMI","LOITER","RTL",
"TAKEOFF","QHOVER","QLOITER","QLAND","QRTL",
"ARM","DISARM","TOGGLE_ARM",
"RECORD_TOGGLE","SNAPSHOT",
"ZOOM_IN","ZOOM_OUT","ZOOM_STOP",
"GIMBAL_YAW_RIGHT","GIMBAL_YAW_LEFT","GIMBAL_PITCH_UP","GIMBAL_PITCH_DOWN",
"GIMBAL_STOP","GIMBAL_CENTER","GIMBAL_CENTER_AND_ZOOM_OUT",
"GIMBAL_LOCK","GIMBAL_FOLLOW"
]

def sh(cmd):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT).strip()
    except subprocess.CalledProcessError as e:
        return e.output.strip()



BATTERY_STATUS_FILE="/tmp/siyi_battery_status.txt"

def battery_status():
    try:
        txt=open(BATTERY_STATUS_FILE).read().strip()
        if txt:
            return txt
    except:
        pass
    return "Bat ?"

def esc(x):
    return html.escape(str(x or ""))

def backup(path):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    if os.path.exists(path):
        dst=f"{BACKUP_DIR}/{os.path.basename(path)}.{time.strftime('%Y%m%d_%H%M%S')}.bak"
        shutil.copy2(path,dst)

def read_file(path):
    try:
        return open(path, encoding="utf-8", errors="replace").read()
    except Exception:
        return ""

def write_file(path, content):
    backup(path)
    open(path, "w", encoding="utf-8").write(content)


# === VIDEO_SOURCE_WEBUI_V1 START ===
def video_source_default_config():
    return {
        "source": "siyi_rtsp",
        "switch_mode": "warm",
        "output_url": "rtsp://127.0.0.1:8554/main.264",
        "siyi": {
            "url": "rtsp://192.168.144.25:8554/main.264",
            "transport": "tcp",
            "latency_ms": 0,
        },
        "hdmi": {
            "device": "",
            "input_format": "auto",
            "width": 1920,
            "height": 1080,
            "fps": 30,
            "audio_enabled": False,
            "encoder": "auto",
            "bitrate_kbps": 8000,
        },
        "udp": {"enabled": True, "port": 5600, "latency_ms": 0},
        "switch": {
            "verify_timeout_seconds": 15,
            "restore_on_failure": True,
            "debounce_seconds": 2,
        },
    }


def _video_source_merge(base, incoming):
    result = json.loads(json.dumps(base))
    if not isinstance(incoming, dict):
        return result
    for key, value in incoming.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _video_source_merge(result[key], value)
        else:
            result[key] = value
    return result


def video_source_read_config():
    cfg = video_source_default_config()
    try:
        with open(VIDEO_SOURCE_CONFIG, encoding="utf-8") as f:
            raw = json.load(f)
        cfg = _video_source_merge(cfg, raw)
    except Exception:
        pass
    if cfg.get("source") not in {"siyi_rtsp", "hdmi_usb"}:
        cfg["source"] = "siyi_rtsp"
    return cfg


def video_source_read_status():
    try:
        with open(VIDEO_SOURCE_STATUS, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def video_source_devices():
    try:
        result = subprocess.run(
            ["sudo", "-n", VIDEO_SOURCE_CONTROL, "devices"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            timeout=12, check=False,
        )
        data = json.loads(result.stdout or "{}")
        devices = data.get("devices", [])
        return devices if isinstance(devices, list) else []
    except Exception:
        return []


def video_source_detected_paths():
    paths = set()
    for item in video_source_devices():
        if isinstance(item, dict):
            for key in ("path", "real_path"):
                value = str(item.get(key, ""))
                if value:
                    paths.add(value)
                    try:
                        paths.add(os.path.realpath(value))
                    except Exception:
                        pass
    return paths


def video_source_write_config(cfg):
    os.makedirs(os.path.dirname(VIDEO_SOURCE_CONFIG), exist_ok=True)
    previous = VIDEO_SOURCE_CONFIG + ".previous"
    if os.path.exists(VIDEO_SOURCE_CONFIG):
        shutil.copy2(VIDEO_SOURCE_CONFIG, previous)
    fd, tmp = tempfile.mkstemp(prefix=".video_source.", dir=os.path.dirname(VIDEO_SOURCE_CONFIG))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
            f.write("\n")
        os.chmod(tmp, 0o664)
        os.replace(tmp, VIDEO_SOURCE_CONFIG)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def video_source_int(value, minimum, maximum, label):
    try:
        parsed = int(str(value).strip())
    except Exception:
        raise ValueError(label + " must be a whole number")
    if not minimum <= parsed <= maximum:
        raise ValueError(label + f" must be between {minimum} and {maximum}")
    return parsed


def video_source_config_from_form(data):
    cfg = video_source_read_config()
    source = data.get("source", [cfg["source"]])[0]
    if source not in {"siyi_rtsp", "hdmi_usb"}:
        raise ValueError("Invalid video source")
    siyi_url = data.get("siyi_url", [cfg["siyi"]["url"]])[0].strip()
    parsed = urllib.parse.urlparse(siyi_url)
    if parsed.scheme not in {"rtsp", "rtsps"} or not parsed.hostname:
        raise ValueError("SIYI source must be a valid RTSP URL")
    transport = data.get("transport", [cfg["siyi"].get("transport", "tcp")])[0]
    if transport not in {"tcp", "udp"}:
        raise ValueError("Invalid RTSP transport")
    device = data.get("hdmi_device", [cfg["hdmi"].get("device", "")])[0].strip()
    if device:
        allowed = video_source_detected_paths()
        if device not in allowed and os.path.realpath(device) not in allowed:
            raise ValueError("The selected HDMI capture device is not currently detected")
    input_format = data.get("input_format", [cfg["hdmi"].get("input_format", "auto")])[0]
    if input_format not in {"auto", "h264", "mjpeg", "yuyv422", "uyvy422", "nv12"}:
        raise ValueError("Invalid HDMI input format")
    encoder = data.get("encoder", [cfg["hdmi"].get("encoder", "auto")])[0]
    if encoder not in {"auto", "hardware", "software", "h264_v4l2m2m", "libx264"}:
        raise ValueError("Invalid HDMI encoder")
    cfg["source"] = source
    cfg["switch_mode"] = "warm"
    cfg["siyi"].update({
        "url": siyi_url,
        "transport": transport,
        "latency_ms": video_source_int(data.get("siyi_latency", ["0"])[0], 0, 5000, "SIYI latency"),
    })
    cfg["hdmi"].update({
        "device": device,
        "input_format": input_format,
        "width": video_source_int(data.get("width", ["1920"])[0], 160, 7680, "Width"),
        "height": video_source_int(data.get("height", ["1080"])[0], 120, 4320, "Height"),
        "fps": video_source_int(data.get("fps", ["30"])[0], 1, 120, "Frame rate"),
        "encoder": encoder,
        "bitrate_kbps": video_source_int(data.get("bitrate_kbps", ["8000"])[0], 500, 100000, "Bitrate"),
        "audio_enabled": False,
    })
    cfg["udp"].update({
        "enabled": "udp_enabled" in data,
        "port": video_source_int(data.get("udp_port", ["5600"])[0], 1, 65535, "UDP port"),
        "latency_ms": video_source_int(data.get("udp_latency", ["0"])[0], 0, 5000, "UDP latency"),
    })
    return cfg


def video_source_control(action, source=""):
    cmd = ["sudo", "-n", VIDEO_SOURCE_CONTROL, action]
    if source:
        cmd.append(source)
    result = subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        timeout=45, check=False,
    )
    output = (result.stdout or "").strip()
    if result.returncode != 0:
        raise RuntimeError(output or "Video source operation failed")
    return output


def video_source_page():
    cfg = video_source_read_config()
    status = video_source_read_status()
    devices = video_source_devices()
    options = ["<option value=''>No HDMI capture device selected</option>"]
    selected_device = str(cfg["hdmi"].get("device", ""))
    for item in devices:
        if not isinstance(item, dict):
            continue
        path = str(item.get("path", ""))
        name = str(item.get("name", "USB video device"))
        formats = ", ".join(str(x) for x in item.get("formats", [])) or "formats unknown"
        selected = "selected" if path == selected_device or os.path.realpath(path) == os.path.realpath(selected_device or "/nonexistent") else ""
        options.append(f"<option value='{esc(path)}' {selected}>{esc(name)} — {esc(path)} — {esc(formats)}</option>")
    if selected_device and not any(selected_device in option for option in options):
        options.append(f"<option value='{esc(selected_device)}' selected>{esc(selected_device)} — currently unavailable</option>")
    device_options = "".join(options)
    source = cfg["source"]
    active_label = "SIYI A8 RTSP" if source == "siyi_rtsp" else "HDMI USB capture"
    state = str(status.get("state", "unknown"))
    state_class = "ok" if state == "running" else ("warn" if state in {"starting", "waiting"} else "bad")
    checked_siyi = "checked" if source == "siyi_rtsp" else ""
    checked_hdmi = "checked" if source == "hdmi_usb" else ""
    udp_checked = "checked" if cfg["udp"].get("enabled", True) else ""
    fmt = str(cfg["hdmi"].get("input_format", "auto"))
    encoder = str(cfg["hdmi"].get("encoder", "auto"))
    transport = str(cfg["siyi"].get("transport", "tcp"))
    return f"""<h1>Video Source</h1>
    <div class='card'>
      <h2>Selected source</h2>
      <div class='grid'>
        <div><b>Active configuration</b><br><span id='videoActiveSource'>{esc(active_label)}</span></div>
        <div><b>Service state</b><br><span id='videoSourceState' class='pill {state_class}'>{esc(state.upper())}</span></div>
        <div><b>Output</b><br><span class='small'>{esc(cfg.get('output_url'))}</span></div>
        <div><b>Switching mode</b><br><span class='small'>Warm standby — inactive source is health-checked, not decoded</span></div>
      </div>
      <p id='videoSourceMessage' class='small'>{esc(status.get('message', 'Waiting for status'))}</p>
      <p id='videoStandbyMessage' class='small'>{esc(status.get('standby_message', ''))}</p>
    </div>

    <form method='post' action='/save_video_source'>
      <div class='card'>
        <h2>Source selection</h2>
        <label style='display:block;border:1px solid #334155;border-radius:10px;padding:12px;margin-bottom:10px;'>
          <input style='width:auto;pointer-events:auto;' type='radio' name='source' value='siyi_rtsp' {checked_siyi}>
          <b>SIYI A8 camera — RTSP</b><br>
          <span class='small'>Preserves the camera stream without video re-encoding.</span>
        </label>
        <label style='display:block;border:1px solid #334155;border-radius:10px;padding:12px;'>
          <input style='width:auto;pointer-events:auto;' type='radio' name='source' value='hdmi_usb' {checked_hdmi}>
          <b>HDMI capture card — USB</b><br>
          <span class='small'>H.264 capture is passed through. MJPEG/raw capture is encoded once using low-latency H.264.</span>
        </label>
      </div>

      <div class='card'>
        <h2>SIYI RTSP settings</h2>
        <div class='grid'>
          <div><label>RTSP URL</label><input style='pointer-events:auto;' name='siyi_url' value='{esc(cfg['siyi']['url'])}'></div>
          <div><label>Transport</label><select style='pointer-events:auto;' name='transport'><option value='tcp' {'selected' if transport == 'tcp' else ''}>TCP</option><option value='udp' {'selected' if transport == 'udp' else ''}>UDP</option></select></div>
          <div><label>Receiver latency (ms)</label><input style='pointer-events:auto;' name='siyi_latency' value='{esc(cfg['siyi'].get('latency_ms', 0))}'></div>
        </div>
      </div>

      <div class='card'>
        <h2>HDMI USB settings</h2>
        <div class='grid'>
          <div style='grid-column:1/-1'><label>Capture device</label><select style='pointer-events:auto;' name='hdmi_device'>{device_options}</select></div>
          <div><label>Input format</label><select style='pointer-events:auto;' name='input_format'>
            {''.join(f"<option value='{x}' {'selected' if fmt == x else ''}>{x}</option>" for x in ('auto','h264','mjpeg','yuyv422','uyvy422','nv12'))}
          </select></div>
          <div><label>Encoder</label><select style='pointer-events:auto;' name='encoder'>
            {''.join(f"<option value='{x}' {'selected' if encoder == x else ''}>{x}</option>" for x in ('auto','hardware','software'))}
          </select></div>
          <div><label>Width</label><input style='pointer-events:auto;' name='width' value='{esc(cfg['hdmi'].get('width', 1920))}'></div>
          <div><label>Height</label><input style='pointer-events:auto;' name='height' value='{esc(cfg['hdmi'].get('height', 1080))}'></div>
          <div><label>Frame rate</label><input style='pointer-events:auto;' name='fps' value='{esc(cfg['hdmi'].get('fps', 30))}'></div>
          <div><label>Bitrate (kbps)</label><input style='pointer-events:auto;' name='bitrate_kbps' value='{esc(cfg['hdmi'].get('bitrate_kbps', 8000))}'></div>
        </div>
      </div>

      <div class='card'>
        <h2>UDP forwarding</h2>
        <label><input style='width:auto;pointer-events:auto;' type='checkbox' name='udp_enabled' value='1' {udp_checked}> Forward selected video to hosts enabled for Video on the MAVLink Hosts page</label>
        <div class='grid'>
          <div><label>UDP port</label><input style='pointer-events:auto;' name='udp_port' value='{esc(cfg['udp'].get('port', 5600))}'></div>
          <div><label>UDP receiver latency (ms)</label><input style='pointer-events:auto;' name='udp_latency' value='{esc(cfg['udp'].get('latency_ms', 0))}'></div>
        </div>
        <button style='pointer-events:auto;'>Save and activate</button>
      </div>
    </form>

    <div class='card'>
      <h2>Source switching</h2>
      <p class='small'>The previous source is restored if the requested source cannot be verified. Switching restarts the video path and may cause a brief interruption.</p>
      <div style='display:flex;gap:10px;flex-wrap:wrap;'>
        <form method='post' action='/video_source_select'><input type='hidden' name='source' value='siyi_rtsp'><button style='pointer-events:auto;'>Switch to SIYI</button></form>
        <form method='post' action='/video_source_select'><input type='hidden' name='source' value='hdmi_usb'><button style='pointer-events:auto;'>Switch to HDMI</button></form>
        <form method='post' action='/video_source_toggle'><button style='pointer-events:auto;'>Toggle source</button></form>
        <a class='button' href='/video' style='text-decoration:none;'>Refresh devices</a>
      </div>
    </div>

    <div class='card'>
      <h2>Live Preview</h2>
      <p class='small'>On-demand browser preview from the stable MediaMTX path.</p>
      <div style='display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px;'>
        <button type='button' style='pointer-events:auto;' onclick='startVideoPreview()'>Start preview</button>
        <button type='button' style='pointer-events:auto;' onclick='stopVideoPreview()'>Stop preview</button>
        <span id='videoPreviewStatus' class='pill warn'>PREVIEW OFF</span>
      </div>
      <div id='videoPreviewBox' style='display:none;border:1px solid #ddd;border-radius:10px;overflow:hidden;background:#111;'>
        <iframe id='videoPreviewFrame' style='width:100%;height:360px;border:0;background:#111;' allow='autoplay; fullscreen'></iframe>
      </div>
    </div>

    <script>
    function startVideoPreview(){{
      const url = location.protocol + '//' + location.hostname + ':8889/main.264/';
      document.getElementById('videoPreviewFrame').src = url;
      document.getElementById('videoPreviewBox').style.display = 'block';
      const st=document.getElementById('videoPreviewStatus'); st.textContent='PREVIEW ON'; st.className='pill ok';
    }}
    function stopVideoPreview(){{
      document.getElementById('videoPreviewFrame').src='about:blank';
      document.getElementById('videoPreviewBox').style.display='none';
      const st=document.getElementById('videoPreviewStatus'); st.textContent='PREVIEW OFF'; st.className='pill warn';
    }}
    async function pollVideoSource(){{
      try{{
        const r=await fetch('/video_source_status?ts='+Date.now(),{{cache:'no-store'}});
        const s=await r.json();
        const state=String(s.state||'unknown');
        const pill=document.getElementById('videoSourceState');
        pill.textContent=state.toUpperCase();
        pill.className='pill '+(state==='running'?'ok':((state==='starting'||state==='waiting')?'warn':'bad'));
        document.getElementById('videoActiveSource').textContent=(s.active_source==='hdmi_usb'?'HDMI USB capture':'SIYI A8 RTSP');
        document.getElementById('videoSourceMessage').textContent=s.message||'';
        document.getElementById('videoStandbyMessage').textContent=s.standby_message||'';
      }}catch(_e){{}}
    }}
    setInterval(pollVideoSource,2000);
    </script>"""
# === VIDEO_SOURCE_WEBUI_V1 END ===


# === FLAPS_WEBUI_V1 START ===
FLAPS_CONFIG_FILE = "/etc/siyi/flaps.json"


def flaps_default_config():
    return {
        "enabled": False,
        "left_servo": 9,
        "right_servo": 10,
        "left_reverse": False,
        "right_reverse": False,
        "up_pwm": 1000,
        "takeoff_pwm": 1500,
        "landing_pwm": 2000,
        "current_position": "UP",
    }


def flaps_read_config():
    cfg = flaps_default_config()

    try:
        with open(
            FLAPS_CONFIG_FILE,
            encoding="utf-8",
        ) as f:
            saved = json.load(f)

        if isinstance(saved, dict):
            cfg.update(saved)

    except Exception:
        pass

    return cfg


def flaps_write_config(cfg):
    current = flaps_read_config()

    clean = {
        "enabled": bool(
            cfg.get("enabled", False)
        ),
        "left_servo": int(
            cfg.get("left_servo", 9)
        ),
        "right_servo": int(
            cfg.get("right_servo", 10)
        ),
        "left_reverse": bool(
            cfg.get("left_reverse", False)
        ),
        "right_reverse": bool(
            cfg.get("right_reverse", False)
        ),
        "up_pwm": int(
            cfg.get("up_pwm", 1000)
        ),
        "takeoff_pwm": int(
            cfg.get("takeoff_pwm", 1500)
        ),
        "landing_pwm": int(
            cfg.get("landing_pwm", 2000)
        ),
        "current_position": str(
            current.get(
                "current_position",
                "UP",
            )
        ).upper(),
    }

    if (
        clean["left_servo"]
        == clean["right_servo"]
    ):
        raise ValueError(
            "Left and right outputs must be different"
        )

    if not (
        1 <= clean["left_servo"] <= 16
        and 1 <= clean["right_servo"] <= 16
    ):
        raise ValueError(
            "Outputs must be SERVO1 through SERVO16"
        )

    for key in (
        "up_pwm",
        "takeoff_pwm",
        "landing_pwm",
    ):
        if not 800 <= clean[key] <= 2200:
            raise ValueError(
                "PWM values must be between 800 and 2200"
            )

    os.makedirs(
        os.path.dirname(FLAPS_CONFIG_FILE),
        exist_ok=True,
    )

    tmp = FLAPS_CONFIG_FILE + ".tmp"

    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(clean, f, indent=2)
        f.write("\n")

    os.replace(tmp, FLAPS_CONFIG_FILE)
    os.chmod(FLAPS_CONFIG_FILE, 0o664)

    return clean


def flaps_page():
    cfg = flaps_read_config()

    checked = (
        "checked"
        if cfg.get("enabled")
        else ""
    )

    left_is_reverse = bool(
        cfg.get("left_reverse", False)
    )

    right_is_reverse = bool(
        cfg.get("right_reverse", False)
    )

    left_normal_selected = (
        "" if left_is_reverse else "selected"
    )

    left_reverse_selected = (
        "selected" if left_is_reverse else ""
    )

    right_normal_selected = (
        "" if right_is_reverse else "selected"
    )

    right_reverse_selected = (
        "selected" if right_is_reverse else ""
    )

    position = str(
        cfg.get("current_position", "UP")
    ).upper()

    msg = esc(
        sh(
            "cat /tmp/siyi_webui_last_action "
            "2>/dev/null || true"
        )
    )

    return f"""
    <h1>Flap Control</h1>

    <div class='card'>
      <h2>Status</h2>

      <div class='grid'>
        <div>
          <b>Current commanded position</b><br>
          {esc(position)}
        </div>

        <div>
          <b>Ownership rule</b><br>
          Both configured SERVOx_FUNCTION parameters
          must be Disabled (0).
        </div>
      </div>

      <p class='small'>
        If either output has any ArduPilot function
        other than Disabled, every flap command is blocked.
      </p>
    </div>

    <div class='card'>
      <h2>Configuration</h2>

      <form method='post' action='/save_flaps'>

        <label style='display:flex;align-items:center;
                      gap:8px;margin-bottom:14px;'>

          <input
            style='pointer-events:auto;width:auto;'
            type='checkbox'
            name='enabled'
            value='1'
            {checked}>

          Enable button-controlled flaps
        </label>

        <div class='grid'>

          <div>
            <label>Left flap output</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='1'
              max='16'
              name='left_servo'
              value='{esc(cfg.get("left_servo", 9))}'>
          </div>

          <div>
            <label>Right flap output</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='1'
              max='16'
              name='right_servo'
              value='{esc(cfg.get("right_servo", 10))}'>
          </div>

          <div>
            <label>Left servo direction</label>
            <select
              style='pointer-events:auto;'
              name='left_reverse'>

              <option
                value='0'
                {left_normal_selected}>
                Normal
              </option>

              <option
                value='1'
                {left_reverse_selected}>
                Reversed
              </option>
            </select>
          </div>

          <div>
            <label>Right servo direction</label>
            <select
              style='pointer-events:auto;'
              name='right_reverse'>

              <option
                value='0'
                {right_normal_selected}>
                Normal
              </option>

              <option
                value='1'
                {right_reverse_selected}>
                Reversed
              </option>
            </select>
          </div>

          <div>
            <label>UP PWM</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='800'
              max='2200'
              name='up_pwm'
              value='{esc(cfg.get("up_pwm", 1000))}'>
          </div>

          <div>
            <label>MID PWM</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='800'
              max='2200'
              name='takeoff_pwm'
              value='{esc(cfg.get("takeoff_pwm", 1500))}'>
          </div>

          <div>
            <label>DOWN PWM</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='800'
              max='2200'
              name='landing_pwm'
              value='{esc(cfg.get("landing_pwm", 2000))}'>
          </div>

        </div>

        <button style='pointer-events:auto;'>
          Save flap configuration
        </button>

      </form>
    </div>

    <div class='card'>
      <h2>Button action</h2>

      <p>
        Assign <b>FLAPS</b> on the Buttons page.
        Each activation cycles
        UP → MID → DOWN → UP.
      </p>
    </div>

    <div class='card'>
      <h2>Last action</h2>
      <pre>{msg}</pre>
    </div>
    """

# === FLAPS_WEBUI_V1 END ===

def zt_save_config(cfg):
    try:
        os.makedirs("/etc/siyi", exist_ok=True)
        open(ZT_CONFIG_FILE, "w").write(json.dumps(cfg, indent=2))
        return True
    except Exception as e:
        print("zt_save_config failed:", e)
        return False


def zt_read_config():
    try:
        if os.path.exists(ZT_CONFIG_FILE):
            with open(ZT_CONFIG_FILE, encoding="utf-8") as f:
                data=json.load(f)
                if isinstance(data, dict):
                    return data
    except Exception:
        pass
    return {}

def zt_write_config(data):
    os.makedirs(os.path.dirname(ZT_CONFIG_FILE), exist_ok=True)
    with open(ZT_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    try:
        os.chmod(ZT_CONFIG_FILE, 0o600)
    except Exception:
        pass

def zt_save_token(token):
    token=(token or "").strip()
    if not token:
        return
    os.makedirs(os.path.dirname(ZT_TOKEN_FILE), exist_ok=True)
    with open(ZT_TOKEN_FILE, "w", encoding="utf-8") as f:
        f.write(token + "\n")
    try:
        os.chmod(ZT_TOKEN_FILE, 0o600)
    except Exception:
        pass

def zt_read_token():
    try:
        return open(ZT_TOKEN_FILE, encoding="utf-8").read().strip()
    except Exception:
        return ""

def zt_token_saved():
    return bool(zt_read_token())

def zt_node_id():
    out=sh("sudo zerotier-cli info 2>/dev/null || true")
    parts=out.split()
    if len(parts) >= 3 and parts[0] == "200" and parts[1] == "info":
        return parts[2]
    return ""

def zt_current_ip():
    out=sh("sudo zerotier-cli listnetworks 2>/dev/null || true")
    for line in out.splitlines():
        if " OK " in line and "/" in line:
            parts=line.split()
            for part in reversed(parts):
                if "/" in part and "." in part:
                    return part.split("/")[0]
    out=sh("ip -4 -br addr | awk '/zt/ {print $3}' | head -n1 | cut -d/ -f1")
    return out.strip()

def zt_network_id_current():
    cfg=zt_read_config()
    nwid=(cfg.get("network_id") or "").strip()
    if nwid:
        return nwid
    out=sh("sudo zerotier-cli listnetworks 2>/dev/null || true")
    for line in out.splitlines():
        parts=line.split()
        if len(parts) >= 3 and parts[0] == "200" and parts[1] == "listnetworks" and parts[2] != "<nwid>":
            return parts[2]
    return ""

def zt_api_request(method, path, payload=None):
    token=zt_read_token()
    if not token:
        return False, "No API token saved"
    url="https://api.zerotier.com/api/v1" + path
    data=None
    headers={
        "Authorization": "Bearer " + token,
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "curl/8.0 SIYI-Pi-WebUI",
    }
    if payload is not None:
        data=json.dumps(payload).encode("utf-8")
    req=urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=12) as r:
            body=r.read().decode("utf-8", errors="replace")
            return True, body
    except Exception as e:
        return False, str(e)

def zt_test_token():
    nwid=zt_network_id_current()
    if not nwid:
        return "ZT API test failed: no network ID saved/found"
    ok, body=zt_api_request("GET", "/network/" + nwid)
    if ok:
        return "ZT API token OK for network " + nwid
    return "ZT API token test failed for network " + nwid + ": " + body


def zt_authorize_this_pi(default_name="New_PI"):
    nwid=zt_network_id_current()
    node=zt_node_id()

    if not nwid:
        return "ZT authorize failed: no network ID configured"

    if not node:
        return "ZT authorize failed: no local node ID"

    hostname=sh("hostname").strip() or default_name

    payload={
        "config":{"authorized":True},
        "name":hostname
    }

    ok, body=zt_api_request(
        "POST",
        "/network/" + nwid + "/member/" + node,
        payload
    )

    if not ok:
        return "ZT authorize failed: " + body

    for i in range(1,11):
        time.sleep(2)

        ok2, verify_body=zt_api_request(
            "GET",
            "/network/" + nwid + "/member/" + node
        )

        if ok2:
            try:
                obj=json.loads(verify_body)

                if obj.get("config",{}).get("authorized") is True:
                    return "ZT authorize OK verified for node " + node + " as " + hostname

            except Exception:
                pass

    return "ZT authorize failed verification for node " + node


def zt_update_camera_route():
    nwid=zt_network_id_current()
    ip=zt_current_ip()
    if not nwid:
        return "ZT route update failed: no network ID"
    if not ip:
        return "ZT route update failed: no Pi ZeroTier IP"

    ok, body=zt_api_request("GET", "/network/" + nwid)
    if not ok:
        return "ZT route update failed reading network: " + body

    try:
        obj=json.loads(body)
        cfg=obj.get("config",{})
        routes=cfg.get("routes") or []
        if not isinstance(routes, list):
            routes=[]
    except Exception as e:
        return "ZT route update failed parsing network JSON: " + str(e)

    # Replace only the camera subnet route, preserve all other routes.
    routes=[r for r in routes if not (isinstance(r,dict) and r.get("target")=="192.168.144.0/24")]
    routes.append({"target":"192.168.144.0/24","via":ip})

    payload={"config":{"routes":routes}}
    ok, body=zt_api_request("POST", "/network/" + nwid, payload)
    if ok:
        return "ZT managed route updated OK: 192.168.144.0/24 via " + ip
    return "ZT managed route update failed: " + body

def zt_full_setup():
    out=[]

    nwid=zt_network_id_current()

    if not nwid:
        return "ZT setup failed: no network ID configured"

    out.append("=== ZT FULL SETUP START ===")
    out.append("Network ID: " + nwid)

    # Step 1: Join network
    out.append("")
    out.append("=== JOIN NETWORK ===")
    join_out=sh(f"sudo zerotier-cli join {nwid}")
    out.append(join_out)

    # Step 2: Authorize/update member
    out.append("")
    out.append("=== AUTHORIZE MEMBER ===")
    auth_out=zt_authorize_this_pi()
    out.append(auth_out)

    # Step 3: Wait for operational state
    out.append("")
    out.append("=== WAIT FOR ZT IP ===")

    zt_ip=None
    status_txt=""

    for i in range(1,16):
        time.sleep(2)

        try:
            status_txt=sh("sudo zerotier-cli listnetworks")
        except Exception as e:
            status_txt=str(e)

        out.append(f"TRY {i}/15")
        out.append(status_txt)

        current=zt_current_ip()

        if current:
            zt_ip=current
            break

    # Step 4: Validate operational success
    if not zt_ip:
        out.append("")
        out.append("ZT SETUP FAILED")
        out.append("No managed ZeroTier IP received.")
        out.append("Current status:")
        out.append(status_txt)

        if "REQUESTING_CONFIGURATION" in status_txt:
            out.append("")
            out.append("Likely causes:")
            out.append("- Member not authorized")
            out.append("- Managed IP assignment disabled")
            out.append("- Broken/stale node state")
            out.append("- Invalid API token")
            out.append("- Network controller issue")

        if "ACCESS_DENIED" in status_txt:
            out.append("")
            out.append("Member exists but is NOT authorized in ZeroTier Central.")

        return "\\n".join(out)

    out.append("")
    out.append("ZT ONLINE OK")
    out.append("Pi ZT IP: " + zt_ip)

    # Step 5: Route update
    out.append("")
    out.append("=== UPDATE CAMERA ROUTE ===")
    out.append(zt_update_camera_route())

    out.append("")
    out.append("=== ZT SETUP COMPLETE ===")

    return "\\n".join(out)

def zt_status_html():
    cfg=zt_read_config()
    nwid=zt_network_id_current()
    token_status="saved" if zt_token_saved() else "not saved"
    node=zt_node_id() or "-"
    ip=zt_current_ip() or "-"
    raw=sh("sudo zerotier-cli info; sudo zerotier-cli listnetworks")
    return f"""
    <div class='grid'>
      <div><b>Network ID</b><br><span class='small'>{esc(nwid or "-")}</span></div>
      <div><b>API token</b><br><span class='small'>{esc(token_status)}</span></div>
      <div><b>This Pi node ID</b><br><span class='small'>{esc(node)}</span></div>
      <div><b>This Pi ZeroTier IP</b><br><span class='small'>{esc(ip)}</span></div>
    </div>
    <details style='margin-top:12px;'><summary>Show ZeroTier raw status</summary><pre>{esc(raw)}</pre></details>
    """

def get_video_values():
    txt=read_file(VIDEO_SERVICE)
    vals={"rtsp":"rtsp://"+CAM_IP+":8554/main.264","protocols":"tcp","latency":"0","host1":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","host2":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","port":"5600"}
    m=re.search(r"location=([^ ]+)", txt)
    if m: vals["rtsp"]=m.group(1)
    m=re.search(r"protocols=([^ ]+)", txt)
    if m: vals["protocols"]=m.group(1)
    m=re.search(r"latency=([^ ]+)", txt)
    if m: vals["latency"]=m.group(1)
    hosts=re.findall(r"udpsink host=([^ ]+) port=([0-9]+)", txt)
    if len(hosts)>0:
        vals["host1"], vals["port"]=hosts[0]
    if len(hosts)>1:
        vals["host2"], _=hosts[1]
    return vals

def make_video_service(rtsp, protocols, latency, host1, host2, port):
    return f"""[Unit]
Description=SIYI RTSP to dual UDP forwarder
After=network-online.target zerotier-one.service NetworkManager.service
Wants=network-online.target zerotier-one.service

[Service]
Type=simple
Restart=always
RestartSec=3
ExecStart=/usr/bin/gst-launch-1.0 -e rtspsrc location={rtsp} latency={latency} protocols={protocols} ! rtph265depay ! h265parse ! rtph265pay config-interval=1 pt=96 ! tee name=t t. ! queue ! udpsink host={host1} port={port} t. ! queue ! udpsink host={host2} port={port}
ExecStop=/usr/bin/pkill -f "gst-launch-1.0"
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
"""

def get_mav_values():
    txt=read_file(MAVCONF)
    vals={"device":"/dev/ttyAMA0","baud":"57600","android":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","mac":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","port":"14550","tcp":"5760"}
    m=re.search(r"TcpServerPort=([0-9]+)", txt)
    if m: vals["tcp"]=m.group(1)
    m=re.search(r"Device=(.+)", txt)
    if m: vals["device"]=m.group(1).strip()
    m=re.search(r"Baud=([0-9]+)", txt)
    if m: vals["baud"]=m.group(1)
    m=re.search(r"\[UdpEndpoint android\].*?Address=([0-9.]+).*?Port=([0-9]+)", txt, re.S)
    if m: vals["android"], vals["port"]=m.group(1), m.group(2)
    m=re.search(r"\[UdpEndpoint mac\].*?Address=([0-9.]+)", txt, re.S)
    if m: vals["mac"]=m.group(1)
    return vals

def make_mav_conf(device, baud, android, mac, port, tcp):
    return f"""[General]
TcpServerPort={tcp}
ReportStats=false

[UartEndpoint fc]
Device={device}
Baud={baud}

[UdpEndpoint android]
Mode=Normal
Address={android}
Port={port}

[UdpEndpoint mac]
Mode=Normal
Address={mac}
Port={port}

[UdpEndpoint button_safety]
Mode=Normal
Address=127.0.0.1
Port=14600
"""



def system_summary():
    problems = []
    warnings = []

    for s in SERVICES:
        state = sh(f"systemctl is-active {s} 2>/dev/null || true")
        if state == "failed":
            problems.append(s)
        elif state == "activating":
            warnings.append(s)

    if problems:
        return f"<div style='color:#ef4444;font-weight:bold'>❌ Issues: {', '.join(problems)}</div>"
    if warnings:
        return f"<div style='color:#f59e0b;font-weight:bold'>⚠ Waiting: {', '.join(warnings)}</div>"
    return "<div style='color:#22c55e;font-weight:bold'>✔ All systems running</div>"

def service_rows():
    rows = ""
    for group, services in SERVICE_GROUPS.items():
        rows += f"<tr><td colspan='3' style='padding-top:10px;font-weight:bold;color:#93c5fd'>{group}</td></tr>"
        for s in services:
            active = sh(f"systemctl is-active {s} 2>/dev/null || true")
            cls = "ok" if active == "active" else ("bad" if active in ["failed"] else "")
            disabled = "disabled" if s == "siyi-webui" else ""
            label = SERVICE_LABELS.get(s, s)
            status_label = STATUS_LABELS.get(active, active)
            rows += f"<tr><td><b>{esc(label)}</b><br><span class='small'>{esc(s)}</span></td><td class='{cls}'><b>{esc(status_label)}</b><br><span class='small'>{esc(active)}</span></td><td><form method='post' action='/restart'><input style='pointer-events:auto;' type='hidden' name='service' value='{s}'><button style='pointer-events:auto;' {disabled}>Restart</button></form></td></tr>"
    return rows


def action_select(name, current):
    dyn = []
    try:
        dyn = gimbal_preset_actions()
    except Exception as e:
        print("[GIMBAL_PRESET_ACTIONS_FAIL]", e, flush=True)

    merged = list(ACTIONS)

    for a in dyn:
        if a not in merged:
            merged.append(a)

    return "<select style='pointer-events:auto;' name='%s'>%s</select>" % (
        name,
        "".join([f"<option {'selected' if a==current else ''}>{a}</option>" for a in merged])
    )

def read_button_rows():
    if not os.path.exists(BUTTON_MAP):
        return []
    with open(BUTTON_MAP,encoding="utf-8-sig") as f:
        return list(csv.DictReader(f,delimiter=";"))


def read_button_safety_config():
    default={
        "block_when_armed":["MANUAL","TAKEOFF"],
        "block_disarm_in_air":True,
        "block_toggle_arm_disarm_in_air":True,
    }

    try:
        if os.path.exists(BUTTON_SAFETY_FILE):
            with open(BUTTON_SAFETY_FILE, encoding="utf-8") as f:
                data=json.load(f)

            vals=data.get("block_when_armed", default["block_when_armed"])

            if not isinstance(vals, list):
                vals=default["block_when_armed"]

            allowed=set(FLIGHT_SAFETY_ACTIONS)

            vals=[
                str(v).strip()
                for v in vals
                if str(v).strip() in allowed
            ]

            return {
                "block_when_armed":vals,
                "block_disarm_in_air":bool(data.get("block_disarm_in_air", True)),
                "block_toggle_arm_disarm_in_air":bool(data.get("block_toggle_arm_disarm_in_air", True)),
            }

    except Exception:
        pass

    return default


def write_button_safety_config(vals, block_disarm_in_air=True, block_toggle_arm_disarm_in_air=True):
    allowed=set(FLIGHT_SAFETY_ACTIONS)

    vals=[
        str(v).strip()
        for v in vals
        if str(v).strip() in allowed
    ]

    # Preserve UI/action ordering.
    ordered=[a for a in FLIGHT_SAFETY_ACTIONS if a in vals]

    os.makedirs("/etc/siyi", exist_ok=True)

    with open(BUTTON_SAFETY_FILE, "w", encoding="utf-8") as f:
        json.dump({
            "block_when_armed":ordered,
            "block_disarm_in_air":bool(block_disarm_in_air),
            "block_toggle_arm_disarm_in_air":bool(block_toggle_arm_disarm_in_air),
        }, f, indent=2)

    try:
        os.chmod(BUTTON_SAFETY_FILE, 0o644)
    except Exception:
        pass



def read_gimbal_presets():
    try:
        if os.path.exists(GIMBAL_PRESETS_FILE):
            with open(GIMBAL_PRESETS_FILE, encoding="utf-8") as f:
                data=json.load(f)
            if isinstance(data, list):
                return data
    except Exception as e:
        print("[GIMBAL_PRESETS_READ_FAIL]", e, flush=True)
    return []
def normalize_preset_name(name):
    name=str(name or "").strip()
    out=[]
    for ch in name:
        if ch.isalnum():
            out.append(ch)
        else:
            out.append("_")
    name="".join(out).strip("_")
    while "__" in name:
        name=name.replace("__","_")
    return name or "PRESET"

def write_gimbal_presets(presets):
    clean=[]
    seen=set()
    for r in presets:
        name=normalize_preset_name(r.get("name") or r.get("label") or "PRESET")
        base=name
        n=2
        while name in seen:
            name="%s_%d"%(base,n)
            n+=1
        seen.add(name)
        label=str(r.get("label") or name.replace("_"," ").title()).strip()
        try:
            yaw=float(r.get("yaw",0))
        except Exception:
            yaw=0.0
        try:
            pitch=float(r.get("pitch",0))
        except Exception:
            pitch=0.0
        clean.append({"name":name,"label":label,"yaw":yaw,"pitch":pitch})
    os.makedirs(os.path.dirname(GIMBAL_PRESETS_FILE), exist_ok=True)
    with open(GIMBAL_PRESETS_FILE,"w",encoding="utf-8") as f:
        json.dump(clean,f,indent=2)
    try:
        os.chmod(GIMBAL_PRESETS_FILE,0o644)
    except Exception:
        pass
    return clean

def gimbal_preset_actions():
    return ["GIMBAL_PRESET_"+p.get("name","") for p in read_gimbal_presets() if p.get("name")]


def gimbal_presets_card():
    presets=read_gimbal_presets()
    presets_json=json.dumps(presets)
    return """
    <div class='card'>
      <h2>Gimbal Presets</h2>
      <p class='small'>Create named gimbal preset positions. These become selectable button actions as <b>GIMBAL_PRESET_NAME</b>.</p>

      <div class='small' style='margin:8px 0 12px 0;color:#cbd5e1;'>
        Current zeroed gimbal position:
        Yaw: <b id='gimbalCurrentYaw'>--</b>
        &nbsp; Pitch: <b id='gimbalCurrentPitch'>--</b>
        &nbsp;
<br><button type='button' style='pointer-events:auto;margin-top:8px;' onclick='gimbalSetZero()'>Set current gimbal position as center / zero</button>
      </div>

      <table id='gimbalPresetTable'>
        <tr><th>Preset</th><th>Yaw</th><th>Pitch</th><th></th></tr>
      </table>

      <button type='button' style='pointer-events:auto;' onclick='gimbalPresetAdd()'>Add preset</button>
      <button type='button' style='pointer-events:auto;' onclick='gimbalPresetAddCurrent()'>Add preset from current position</button>
      <div id='gimbalPresetSaveStatus' class='small' style='margin-top:8px;color:#94a3b8;'>Saved automatically</div>
    </div>

    <script>
      let gimbalPresets = __PRESETS_JSON__;
      let gimbalPresetSaveTimer = null;
      window.gimbalLastCurrent = {yaw:0,pitch:0};

      function gimbalPresetNormalizeName(v){
        v=String(v||'').trim().replace(/^_+|_+$/g,'');
        return v || 'PRESET';
      }

      function gimbalPresetRender(){
        const tbl=document.getElementById('gimbalPresetTable');
        if(!tbl) return;
        let html="<tr><th>Preset</th><th>Yaw</th><th>Pitch</th><th></th></tr>";
        gimbalPresets.forEach((p,i)=>{
          html += `
            <tr>
              <td><input style="pointer-events:auto;" value="${p.label||p.name||''}" onchange="gimbalPresetSet(${i},'name',this.value)"></td>
              <td><input style="pointer-events:auto;" type="number" step="0.1" value="${p.yaw||0}" onchange="gimbalPresetSet(${i},'yaw',this.value)"></td>
              <td><input style="pointer-events:auto;" type="number" step="0.1" value="${p.pitch||0}" onchange="gimbalPresetSet(${i},'pitch',this.value)"></td>
              <td><button type="button" class="danger" style="pointer-events:auto;" onclick="gimbalPresetDelete(${i})">Delete</button></td>
            </tr>`;
        });
        tbl.innerHTML=html;
      }

      function gimbalPresetSet(i,k,v){
        if(k==='name') { v=String(v||'').trim(); gimbalPresets[i].label=v; }
        if(k==='yaw' || k==='pitch') v=parseFloat(v||0);
        gimbalPresets[i][k]=v;
        gimbalPresetAutosave();
      }

      function gimbalPresetAdd(){
        gimbalPresets.push({name:'NEW_PRESET',label:'New preset',yaw:0,pitch:0});
        gimbalPresetRender();
        gimbalPresetAutosave();
      }


      function gimbalPresetNudge(i,k,d){
        gimbalPresets[i][k]=parseFloat(gimbalPresets[i][k]||0)+d;
        gimbalPresetRender();
        gimbalPresetAutosave();
      }

      function gimbalPresetDelete(i){
        gimbalPresets.splice(i,1);
        gimbalPresetRender();
        gimbalPresetAutosave();
      }

      async function gimbalCurrentRead(){
        try{
          const r=await fetch('/gimbal_current?ts='+Date.now());
          const j=await r.json();
          const y=document.getElementById('gimbalCurrentYaw');
          const p=document.getElementById('gimbalCurrentPitch');
          if(y) y.textContent=j.yaw;
          if(p) p.textContent=j.pitch;
          window.gimbalLastCurrent=j;
        }catch(e){
          console.log("gimbalCurrentRead fail", e);
        }
      }


      async function gimbalSetZero(){
        try{
          const r=await fetch('/gimbal_set_zero?ts='+Date.now());
          const j=await r.json();
          if(!j.ok) throw new Error(j.error || 'zero failed');
          await gimbalCurrentRead();
          alert('Gimbal center/zero saved');
        }catch(e){
          alert('Failed to set gimbal zero: '+e);
        }
      }

      function gimbalPresetAddCurrent(){
        const j=window.gimbalLastCurrent || {yaw:0,pitch:0};
        const idx=gimbalPresets.length+1;
        gimbalPresets.push({
          name:'Preset '+idx,
          label:'Preset '+idx,
          yaw:parseFloat(j.yaw||0),
          pitch:parseFloat(j.pitch||0)
        });
        gimbalPresetRender();
        gimbalPresetAutosave();
      }

      function gimbalPresetAutosave(){
        clearTimeout(gimbalPresetSaveTimer);
        gimbalPresetSaveTimer=setTimeout(async function(){
          const st=document.getElementById('gimbalPresetSaveStatus');
          try{
            if(st) st.textContent='Saving...';
            const body=new URLSearchParams();
            body.set('presets_json', JSON.stringify(gimbalPresets));
            const r=await fetch('/save_gimbal_presets', {
              method:'POST',
              headers:{'Content-Type':'application/x-www-form-urlencoded'},
              body:body.toString()
            });
            if(!r.ok) throw new Error('HTTP '+r.status);
            if(st) st.textContent='Saved. Refresh page to update button action dropdowns.';
          }catch(e){
            if(st) st.textContent='Save failed: '+e;
          }
        },400);
      }

      gimbalPresetRender();
      gimbalCurrentRead();
      setInterval(gimbalCurrentRead,700);
    </script>
    """.replace("__PRESETS_JSON__", presets_json)


def button_safety_card():
    cfg=read_button_safety_config()
    selected=[a for a in FLIGHT_SAFETY_ACTIONS if a in set(cfg.get("block_when_armed", []))]

    selected_json=json.dumps(selected)
    actions_json=json.dumps(FLIGHT_SAFETY_ACTIONS)

    disarm_checked="checked" if cfg.get("block_disarm_in_air", True) else ""
    toggle_checked="checked" if cfg.get("block_toggle_arm_disarm_in_air", True) else ""

    return f"""
    <div class='card'>
      <h2 style='margin-top:0;'>Flight Safety Blockers</h2>

      <p class='small' style='margin-top:0;'>
        Prevent selected flight actions while the aircraft is armed.
      </p>

      <form method='post' action='/save_button_safety'>

        <label class='small'>Add blocker</label>

        <div style='display:flex;gap:8px;align-items:flex-start;max-width:520px;margin-top:6px;margin-bottom:10px;'>
          <div style='position:relative;max-width:260px;flex:1;'>
            <button id='safetyDropdownButton'
                    type='button'
                    onclick='safetyToggleDropdown()'
                    style='pointer-events:auto;width:100%;margin:0;text-align:left;background:#020617;color:#e5e7eb;border:1px solid #334155;border-radius:6px;padding:7px 32px 7px 10px;min-height:36px;font-size:14px;position:relative;box-sizing:border-box;'>
              Select mode <span style='position:absolute;right:10px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:12px;pointer-events:none;'>▾</span>
            </button>

            <div id='safetyDropdownMenu'
                 style='display:none;position:absolute;left:0;right:0;top:39px;z-index:60;background:#020617;border:1px solid #334155;border-radius:6px;box-shadow:0 10px 22px rgba(0,0,0,.35);overflow:hidden;'>
            </div>
          </div>
        </div>

        <div class='small' style='margin-bottom:6px;'>Active blockers while armed</div>

        <div id='safetySelectedChips'
             style='display:flex;flex-wrap:wrap;gap:8px;min-height:34px;background:#020617;border:1px solid #334155;border-radius:8px;padding:8px;margin-bottom:12px;'>
        </div>

        <input type='hidden' name='block_when_armed_csv' id='blockWhenArmedCsv'>

        <div style='border-top:1px solid #334155;margin-top:12px;padding-top:12px;'>
          <h3 style='font-size:15px;margin:0 0 6px 0;color:#e5e7eb;'>Airborne arm/disarm protection</h3>

          <p class='small' style='margin:0 0 10px 0;'>
            These protections are visible here, but locked by default. Unlock only if you intentionally want to change them.
          </p>

          <label style='display:flex;align-items:center;gap:8px;margin-bottom:10px;font-size:14px;'>
            <input style='pointer-events:auto;width:auto;margin:0;' type='checkbox' id='unlockAirborneSafety'
                   name='unlock_airborne_safety' value='1'
                   onchange='safetyToggleAirborneUnlock()'>
            <span>Unlock advanced airborne safety settings</span>
          </label>

          <div id='airborneWarn' class='small' style='display:none;color:#fbbf24;margin-bottom:10px;'>
            Advanced safety override enabled. Disabling these can allow disarm commands while the aircraft is airborne.
          </div>

          <div style='display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:8px;margin-bottom:12px;'>
            <label style='display:flex;align-items:center;gap:7px;background:#020617;border:1px solid #334155;border-radius:6px;padding:7px 8px;font-size:14px;line-height:1.2;min-height:32px;'>
              <input class='airborneSafety' disabled style='pointer-events:auto;width:auto;margin:0;' type='checkbox' name='block_disarm_in_air' value='1' {disarm_checked}>
              <span>Block DISARM while in air</span>
            </label>

            <label style='display:flex;align-items:center;gap:7px;background:#020617;border:1px solid #334155;border-radius:6px;padding:7px 8px;font-size:14px;line-height:1.2;min-height:32px;'>
              <input class='airborneSafety' disabled style='pointer-events:auto;width:auto;margin:0;' type='checkbox' name='block_toggle_arm_disarm_in_air' value='1' {toggle_checked}>
              <span>Block TOGGLE_ARM disarm while in air</span>
            </label>
          </div>
        </div>

        <div id='safetySaveStatus' class='small' style='min-height:18px;color:#94a3b8;'>Saved automatically</div>

      </form>

      <script>
      const safetyAllActions = {actions_json};
      let safetySelected = {selected_json};
      let safetySaveTimer=null;

      function safetyRender(){{
        const chipBox=document.getElementById('safetySelectedChips');
        const hidden=document.getElementById('blockWhenArmedCsv');
        const menu=document.getElementById('safetyDropdownMenu');
        const btn=document.getElementById('safetyDropdownButton');

        if(!chipBox || !hidden || !menu || !btn) return;

        hidden.value=safetySelected.join(',');
        btn.textContent='Select mode';

        if(safetySelected.length===0){{
          chipBox.innerHTML="<span class='small'>No flight actions are blocked while armed.</span>";
        }} else {{
          chipBox.innerHTML=safetySelected.map(a =>
            "<span style='display:inline-flex;align-items:center;gap:7px;background:#1e293b;border:1px solid #475569;border-radius:999px;padding:5px 9px;font-size:14px;line-height:1;'>" +
            "<span>" + a + "</span>" +
            "<button type='button' onclick=\\"safetyRemoveBlocker('" + a + "')\\" style='pointer-events:auto;background:#334155;color:#e5e7eb;border:0;border-radius:999px;margin:0;padding:1px 6px;font-size:13px;line-height:1.3;'>×</button>" +
            "</span>"
          ).join("");
        }}

        const available=safetyAllActions.filter(a => !safetySelected.includes(a));

        if(available.length===0){{
          menu.innerHTML="<div class='small' style='padding:9px 10px;'>All modes selected</div>";
          btn.textContent='All modes selected';
        }} else {{
          menu.innerHTML=available.map(a =>
            "<button type='button' onclick=\\"safetyAddBlocker('" + a + "')\\" style='display:block;width:100%;text-align:left;margin:0;background:#020617;color:#e5e7eb;border:0;border-bottom:1px solid #1f2937;border-radius:0;padding:8px 10px;font-size:14px;cursor:pointer;'>" +
            a +
            "</button>"
          ).join("");
        }}
      }}

      function safetyToggleDropdown(){{
        const menu=document.getElementById('safetyDropdownMenu');
        if(!menu) return;
        menu.style.display = menu.style.display==='block' ? 'none' : 'block';
      }}

      function safetyAutosave(){{
        clearTimeout(safetySaveTimer);
        safetySaveTimer=setTimeout(async function(){{
          const st=document.getElementById('safetySaveStatus');
          if(st) st.textContent='Saving...';

          const form=document.querySelector("form[action='/save_button_safety']");
          const fd=new FormData(form);

          try {{
            await fetch('/save_button_safety', {{
              method:'POST',
              body:new URLSearchParams(fd)
            }});
            if(st) st.textContent='Saved automatically';
          }} catch(e) {{
            if(st) st.textContent='Save failed';
          }}
        }}, 1200);
      }}

      function safetyAddBlocker(action){{
        if(!action) return;
        if(!safetySelected.includes(action)){{
          safetySelected.push(action);
        }}
        const menu=document.getElementById('safetyDropdownMenu');
        if(menu) menu.style.display='none';
        safetyRender();
        safetyAutosave();
      }}

      function safetyRemoveBlocker(action){{
        safetySelected=safetySelected.filter(a => a!==action);
        safetyRender();
        safetyAutosave();
      }}

      function safetyToggleAirborneUnlock(){{
        const unlock=document.getElementById('unlockAirborneSafety');
        const warn=document.getElementById('airborneWarn');
        document.querySelectorAll('.airborneSafety').forEach(e => e.disabled = !unlock.checked);
        if(warn) warn.style.display = unlock.checked ? 'block' : 'none';
      }}

      document.addEventListener('click', function(e){{
        const menu=document.getElementById('safetyDropdownMenu');
        const btn=document.getElementById('safetyDropdownButton');
        if(!menu || !btn) return;
        if(menu.contains(e.target) || btn.contains(e.target)) return;
        menu.style.display='none';
      }});

      document.addEventListener('change', function(e){{
        if(e.target && e.target.classList && e.target.classList.contains('airborneSafety')) {{
          safetyAutosave();
        }}
      }});

      safetyRender();
      safetyToggleAirborneUnlock();
      </script>
    </div>
    """

def wifi_profiles_cards():
    active_ssid = sh("iwgetid -r 2>/dev/null || true").strip()
    active_conn = sh("nmcli -g GENERAL.CONNECTION dev show wlan0 2>/dev/null || true").strip()

    # --- LIVE SCAN ---
    scan_map = {}
    try:
        sh("timeout 3s sudo -n nmcli dev wifi rescan ifname wlan0 >/dev/null 2>&1 || true")
        scan = sh("nmcli -t -f SSID,SIGNAL dev wifi list ifname wlan0 2>/dev/null")
        for line in scan.splitlines():
            parts = line.rsplit(":", 1)
            if len(parts) == 2:
                ssid = parts[0].replace("\\:", ":").strip()
                sig = int(parts[1]) if parts[1].isdigit() else 0

                if ssid and ssid != "--":
                    scan_map[ssid] = max(sig, scan_map.get(ssid, 0))
    except Exception:
        pass

    lines = sh("nmcli -t -f NAME,TYPE,DEVICE,AUTOCONNECT connection show").splitlines()

    active_list = []
    visible_list = []
    saved_list = []

    for line in lines:
        parts = line.split(":")
        if len(parts) < 4:
            continue

        name, typ, device, autoconnect = parts[0], parts[1], parts[2], parts[3]

        if typ not in ("wifi", "802-11-wireless"):
            continue

        ssid = sh(f"nmcli -g 802-11-wireless.ssid connection show '{name}' 2>/dev/null || true").strip()

        if not ssid and name == active_conn and active_ssid:
            ssid = active_ssid

        if not ssid:
            ssid = "(unknown)"

        prio = sh(f"nmcli -g connection.autoconnect-priority connection show '{name}' 2>/dev/null || true").strip() or "0"
        psk = wifi_pw_get(name)

        active = (name == active_conn or device == "wlan0")
        visible = ssid in scan_map
        signal = scan_map.get(ssid, 0)

        # --- CLASSIFY ---
        if active:
            state = "active"
        elif visible:
            state = "visible"
        else:
            state = "saved"

        entry = (ssid, name, device, autoconnect, prio, signal, state, psk)

        if state == "active":
            active_list.append(entry)
        elif state == "visible":
            visible_list.append(entry)
        else:
            saved_list.append(entry)

    # --- SORT ---
    visible_list.sort(key=lambda x: -x[5])
    saved_list.sort(key=lambda x: -int(x[4]))

    def render_card(e, highlight=False):
        ssid, name, device, autoconnect, prio, signal, state, psk = e

        if state == "active":
            label = "🟢 Connected"
            cls = "ok"
        elif state == "visible":
            label = f"🔵 In range ({signal}%)"
            cls = "warn"
        else:
            label = "🟡 Saved"
            cls = "bad"

        bars = int(signal / 20)
        signal_bar = "▮" * bars + "▯" * (5 - bars)

        is_system = name.startswith("netplan-")

        if is_system:
            controls = "<div class='readonlybox'>System network (read-only)</div>"
        else:
            controls = f"""
            <div class='inlineform'>
              <button style='pointer-events:auto;' class='switchbtn'   onclick="location.href='/wifi_switch?name={esc(name)}'">Connect</button>
              <label>Priority</label>
              <input style='pointer-events:auto;' value='{esc(prio)}' class='smallinput' readonly>
              <label>Auto</label>
              <span>{esc(autoconnect)}</span>
            </div>
            """

        bg = "#0f1b2e" if highlight else "#0b1220"

        try:
            in_range = int(signal) > 0
        except Exception:
            in_range = False

        wifi_actions = ""
        if not highlight:
            if in_range:
                wifi_actions += f"""
<form method='post' action='/wifi_switch' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<button class='switchbtn'>Connect now</button>
</form>"""

            wifi_actions += f"""
<form method='post' action='/wifi_update_password' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<input style='pointer-events:auto;width:170px;' type='password' name='password' value='{esc(psk)}' placeholder='Wi-Fi password'>
<label class='small'>
<input style='pointer-events:auto;width:auto;' type='checkbox' onclick="this.closest('form').querySelector('input[name=password]').type=this.checked?'text':'password'">
Show
</label>
<button style='pointer-events:auto;' type='submit'>Update password</button>
</form>

<form method='post' action='/wifi_delete' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<button class='danger'>Delete</button>
</form>"""

        return f"""
        <div class='ssidcard' style="background:{bg}; border:1px solid #334155;">
          <div class='ssidtop'>
            <div>
              <div class='ssidtitle'>{esc(ssid)} <span class='status-pill {cls}'>{label}</span></div>
              <div class='ssidmeta'>{signal_bar} {signal}%</div>
              <div class='ssidmeta'> {esc(name)}</div>
            </div>
            <div class='ssidfacts'>
              <div><b>Priority</b><br>{esc(prio)}</div>
              <div><b>Auto</b><br>{esc(autoconnect)}</div>
            </div>
          </div>
          <div class='ssidcontrols'>
<form method='post' action='/wifi_update' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<label>Priority</label>
<input name='priority' value='{esc(prio)}' class='smallinput'>
<label>Autoconnect</label>
<select name='autoconnect' class='smallselect'>
<option {'selected' if autoconnect=='yes' else ''}>yes</option>
<option {'selected' if autoconnect=='no' else ''}>no</option>
</select>
<button>Apply</button>
</form>
{wifi_actions}
</div>
        </div>
        """

    html = ""

    if active_list:
        html += "<h2>Connected</h2>"
        for e in active_list:
            html += render_card(e, True)

    if visible_list:
        html += "<h2>Available Networks</h2>"
        for e in visible_list:
            html += render_card(e)

    if saved_list:
        html += "<h2>Saved Networks</h2>"
        for e in saved_list:
            html += render_card(e)

    return html or "<p>No Wi-Fi profiles found</p>"





# === ARDUPLANE PARAMETER IMPORT V1 ===
PARAM_IMPORT_DAEMON_BASE = "http://127.0.0.1:8765"
PARAM_IMPORT_MAX_REQUEST = 8 * 1024 * 1024
PARAM_IMPORT_METADATA_CACHE_FILES = (
    "/etc/siyi/arduplane_param_metadata.json",
    "/etc/siyi/param_metadata_cache.json",
    "/tmp/siyi_param_cache.json",
)
PARAM_IMPORT_METADATA_HOVER_MARKER = "PARAM_IMPORT_METADATA_HOVER_V3"
PARAM_IMPORT_METADATA_EMBED_MARKER = "PARAM_IMPORT_METADATA_EMBED_V1"
_param_import_metadata_lock = threading.Lock()
_param_import_metadata_signature = None
_param_import_metadata_params = {}
_param_import_metadata_sources = []
_param_import_metadata_errors = []


def _param_import_metadata_signature_now():
    signature = []
    for path in PARAM_IMPORT_METADATA_CACHE_FILES:
        try:
            stat = os.stat(path)
            signature.append((path, stat.st_mtime_ns, stat.st_size))
        except OSError:
            continue
    return tuple(signature)


def _param_import_reload_metadata():
    global _param_import_metadata_signature
    global _param_import_metadata_params
    global _param_import_metadata_sources
    global _param_import_metadata_errors

    signature = _param_import_metadata_signature_now()
    if signature == _param_import_metadata_signature:
        return

    merged = {}
    sources = []
    errors = []

    for path, _mtime, _size in signature:
        try:
            with open(path, "r", encoding="utf-8") as handle:
                raw = json.load(handle)
            params = raw.get("params", {}) if isinstance(raw, dict) else {}
            if not isinstance(params, dict):
                raise ValueError("top-level params field is not an object")

            added = 0
            for param_name, meta in params.items():
                normalized = str(param_name or "").strip().upper()
                if not normalized or normalized in merged or not isinstance(meta, dict):
                    continue
                merged[normalized] = meta
                added += 1

            sources.append({"path": path, "entries": len(params), "added": added})
            metadata_error = raw.get("metadata_error") if isinstance(raw, dict) else None
            if metadata_error:
                errors.append(path + ": " + str(metadata_error))
        except Exception as exc:
            errors.append(path + ": " + str(exc))

    _param_import_metadata_params = merged
    _param_import_metadata_sources = sources
    _param_import_metadata_errors = errors
    _param_import_metadata_signature = signature


def param_import_metadata_lookup(name):
    """Return sanitized ArduPilot metadata for one parameter."""
    name = str(name or "").strip().upper()
    if not re.fullmatch(r"[A-Z0-9_]{1,64}", name):
        raise ValueError("Invalid parameter name")

    with _param_import_metadata_lock:
        _param_import_reload_metadata()
        meta = _param_import_metadata_params.get(name)
        sources = list(_param_import_metadata_sources)
        errors = list(_param_import_metadata_errors)

    if not isinstance(meta, dict):
        if not sources:
            message = (
                "Parameter metadata cache is not available. "
                "Run the metadata refresh or perform a full parameter refresh."
            )
        else:
            message = "No ArduPilot metadata is available for this parameter."
        if errors:
            message += " " + errors[-1]
        return {
            "ok": True,
            "name": name,
            "available": False,
            "message": message,
            "sources": sources,
        }

    fields = meta.get("fields") or {}
    values = meta.get("values") or {}
    if not isinstance(fields, dict):
        fields = {}
    if not isinstance(values, dict):
        values = {}

    human_name = str(meta.get("humanName") or "")
    documentation = str(meta.get("documentation") or "")
    user_level = str(meta.get("user") or "")
    descriptive = bool(human_name or documentation or user_level or fields or values)

    if not descriptive:
        message = "The parameter exists in the value cache, but descriptive ArduPilot metadata is missing."
        if errors:
            message += " " + errors[-1]
        return {
            "ok": True,
            "name": name,
            "available": False,
            "message": message,
            "sources": sources,
        }

    return {
        "ok": True,
        "name": name,
        "available": True,
        "humanName": human_name,
        "documentation": documentation,
        "user": user_level,
        "type": meta.get("type"),
        "fields": {str(key): str(value) for key, value in fields.items()},
        "values": {str(key): str(value) for key, value in values.items()},
        "sources": sources,
    }


def param_import_attach_metadata(result):
    """Embed metadata in import preview entries so hover does not need a second request."""
    if not isinstance(result, dict):
        return result
    entries = result.get("entries")
    if not isinstance(entries, list):
        return result

    for entry in entries:
        if not isinstance(entry, dict):
            continue
        name = str(entry.get("name") or "").strip().upper()
        if not name:
            continue
        try:
            entry["metadata"] = param_import_metadata_lookup(name)
        except Exception as exc:
            entry["metadata"] = {
                "ok": False,
                "name": name,
                "available": False,
                "message": "Metadata lookup failed: " + str(exc),
            }
    return result


def param_import_daemon_request(path, method="GET", payload=None, timeout=35):
    url = PARAM_IMPORT_DAEMON_BASE + path
    body = None
    headers = {"Accept": "application/json"}
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read(PARAM_IMPORT_MAX_REQUEST)
    except urllib.error.HTTPError as exc:
        raw = exc.read(PARAM_IMPORT_MAX_REQUEST)
    data = json.loads(raw.decode("utf-8", errors="replace"))
    if not isinstance(data, dict):
        raise ValueError("Parameter daemon returned an invalid response")
    return data


def send_json_response(handler, payload, status=200):
    raw = json.dumps(payload).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def send_param_import_download(handler, daemon_path):
    result = param_import_daemon_request(daemon_path)
    if not result.get("ok"):
        send_json_response(handler, result, 400)
        return
    filename = re.sub(r"[^A-Za-z0-9._-]+", "_", str(result.get("filename", "download.txt")))
    raw = str(result.get("content", "")).encode("utf-8")
    handler.send_response(200)
    handler.send_header("Content-Type", "text/plain; charset=utf-8")
    handler.send_header("Content-Disposition", f'attachment; filename="{filename}"')
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)
# === ARDUPLANE PARAMETER IMPORT V1 END ===

def arduplane_parameters_page():

    import json
    from html import escape as esc

    cache="/etc/siyi/param_metadata_cache.json"

    QGC_LEVELS = {
        "Standard": [
            "ACRO","AHRS","AIRSPEED","ARMING","ARSPD","AUTOTUNE","BATT","BRD",
            "CAM","CHUTE","COMPASS","FBWB","FENCE","FLTMODE","FRSKY","FS",
            "GROUND","KFF","LAND","LGR","LOG","MAN","MIXING","MNT","MSP",
            "NAVL","OSD","PTCH2SRV","PTCH","RC","RLL","SERIAL","SERVO",
            "TECS","THR","TKOFF","YAW","Misc"
        ],
        "Advanced": [
            "AHRS","ARMING","ARSPD","AUTOTUNE","BARO","BATT","BRD","BTN",
            "COMPASS","CRASH","DSPOILER","EK","FLAP","FLTMODE","FRSKY","FS",
            "FWD","GLIDE","GPS","GROUND","INS","KFF","LAND","LOG","MIS",
            "MNT","NAVL","NTF","OSD","PTCH2SRV","PTCH","Q","RALLY","RC",
            "RLL","RNGFND","RNGFNDA","RPM","RSSI","RTL","SERIAL","SERVO",
            "STAT","STEER2SRV","TECS","TERRAIN","THR","TKOFF","TUNE","WP","Misc"
        ],
        "Other": [
            "BARO","CAM","COMPASS","EK","INS","NTF","OSD","PTCH","RELAY","RLL","VTX"
        ],
    }

    try:
        with open(cache) as f:
            raw=json.load(f)
            data=raw.get("params", {})
            received=raw.get("received_count", len(data))
            expected=raw.get("expected_count", "?")
            meta_error=raw.get("metadata_error", "")
    except Exception:
        data={}
        received=0
        expected="?"
        meta_error=""

    # Live paramd fallback: if metadata cache is empty/stale, build page from live /state.
    if not data:
        try:
            import urllib.request
            with urllib.request.urlopen("http://127.0.0.1:8765/state", timeout=5) as r:
                live=json.loads(r.read().decode("utf-8", errors="ignore"))
            live_params=live.get("params", {})
            if live_params:
                data={k: {"value": v.get("value"), "type": v.get("type")} for k,v in live_params.items()}
                received=len(data)
                expected=received
        except Exception as e:
            meta_error = "Live paramd fallback failed: " + repr(e)

    def qgc_group(name):
        special = ["PTCH2SRV", "STEER2SRV", "RNGFNDA", "RNGFND"]
        for sp in special:
            if name.startswith(sp):
                return sp

        first = name.split("_", 1)[0]
        first = re.sub(r"\d+$", "", first)

        if not first:
            first = "Misc"

        return first

    groups={}

    for k,v in sorted(data.items()):
        grp=qgc_group(k)
        groups.setdefault(grp,[]).append((k,v))

    all_groups = sorted(groups.keys())

    def level_for_group(grp):
        levels=[]
        for level, names in QGC_LEVELS.items():
            if grp in names:
                levels.append(level)
        if not levels:
            levels.append("Other")
        return " ".join(levels)

    def group_buttons_for_level(level):
        if level == "All":
            ordered = all_groups
        else:
            ordered = [g for g in QGC_LEVELS.get(level, []) if g in groups]
            extras = [g for g in all_groups if g not in ordered and level in level_for_group(g)]
            ordered += extras

        out = ""
        for grp in ordered:
            safe_grp=esc(grp)
            level_attr=esc(level_for_group(grp))
            out += f"""
            <button type='button'
                    class='paramGroupBtn'
                    data-group='{safe_grp}'
                    data-levels='{level_attr}'
                    onclick="paramFilterGroup('{safe_grp}')">
              {safe_grp}
              <span class='small'>({len(groups.get(grp, []))})</span>
            </button>
            """
        return out

    body=f"""

    <h1>ArduPlane Parameters</h1>

    <div class='card paramTopCompact'>
      <span class='paramTopTitle'>ArduPlane parameter configurator</span>
      <span class='paramTopDivider'></span>
      <span class='small paramTopLoaded'>Loaded parameters: {received}/{expected}</span>
      {("<span class='small' style='color:#f97316;'>Metadata warning: " + esc(meta_error) + "</span>") if meta_error else ""}

      <form onsubmit='return paramManualFullSync(event);' class='paramTopRefreshForm'>
        <button style='pointer-events:auto;'>Refresh Parameters From FC</button>
      </form>

      <a id='fcParamExportBtn'
         class='paramTopRefreshForm'
         href='/fc_parameter_export'
         onclick='return fcParameterExportClick(event);'
         style='pointer-events:auto;display:inline-block;text-decoration:none;background:#2563eb;color:white;border:0;border-radius:8px;padding:9px 13px;margin:4px;cursor:pointer;'>
        FC Parameter Export
      </a>
      <span id='fcExportChromeNote' class='small' style='display:none;color:#94a3b8;margin-left:8px;'>If Chrome blocks the download, open download history and choose Keep.</span>

      <input id='paramImportFileInput'
             type='file'
             accept='.params,.param,.txt,text/plain'
             style='display:none;'
             onchange='paramImportFileSelected(this)'>
      <button type='button'
              class='paramTopRefreshForm'
              style='pointer-events:auto;background:#0f766e;'
              onclick="document.getElementById('paramImportFileInput').click()">
        Import Parameter File
      </button>

      <span class='small paramTopStatus' id='paramRefreshStatus'></span>
    </div>


    <div id='paramImportOverlay' class='paramImportOverlay' aria-hidden='true'>
      <div class='paramImportDialog' role='dialog' aria-modal='true' aria-labelledby='paramImportTitle'>
        <div class='paramImportHeader'>
          <div>
            <h2 id='paramImportTitle'>Import ArduPlane parameters</h2>
            <div id='paramImportSubtitle' class='small'>Select a parameter file to begin.</div>
          </div>
          <button id='paramImportCloseTop' type='button' class='paramImportClose' onclick='paramImportClose()'>&times;</button>
        </div>

        <div id='paramImportLoading' class='paramImportLoading' style='display:none;'>
          <span class='paramImportSpinner'></span>
          <span id='paramImportLoadingText'>Reading and comparing parameters...</span>
        </div>

        <div id='paramImportPreviewPanel' style='display:none;'>
          <div id='paramImportSummary' class='paramImportSummary'></div>
          <div id='paramImportSafety' class='paramImportSafety'></div>
          <div class='paramImportToolbar'>
            <label>Show
              <select id='paramImportFilter' onchange='paramImportApplyFilter()'>
                <option value='changed'>Changed only</option>
                <option value='warnings'>Warnings</option>
                <option value='all'>All parsed parameters</option>
              </select>
            </label>
            <label class='paramImportSelectAll'>
              <input id='paramImportSelectAll' type='checkbox' checked onchange='paramImportToggleAll(this.checked)'>
              Select all applicable changes
            </label>
            <span id='paramImportSelectedCount' class='small'></span>
          </div>
          <div class='paramImportTableWrap'>
            <table class='paramImportTable'>
              <thead><tr><th>Apply</th><th>Parameter</th><th>Current</th><th>Imported</th><th>Status</th><th>Warning</th></tr></thead>
              <tbody id='paramImportRows'></tbody>
            </table>
          </div>
        </div>

        <div id='paramImportProgressPanel' style='display:none;'>
          <div class='paramImportRunStatus'>
            <span id='paramImportRunSpinner' class='paramImportSpinner'></span>
            <div>
              <strong id='paramImportRunTitle'>Applying parameters</strong>
              <div id='paramImportRunMessage' class='small'>Preparing...</div>
            </div>
          </div>
          <div class='paramImportProgressTrack'><div id='paramImportProgressBar'></div></div>
          <div class='paramImportProgressFacts'>
            <span id='paramImportProgressText'>0 of 0 verified</span>
            <strong id='paramImportProgressPercent'>0.0%</strong>
          </div>
          <div id='paramImportCurrentParam' class='paramImportCurrent'></div>
          <div id='paramImportEventLog' class='paramImportEventLog'></div>
        </div>

        <div id='paramImportError' class='paramImportError' style='display:none;'></div>

        <div class='paramImportFooter'>
          <button id='paramImportCancelBtn' type='button' class='danger' style='display:none;' onclick='paramImportCancelJob()'>Cancel operation</button>
          <a id='paramImportBackupBtn' class='paramImportDownload' style='display:none;'>Download pre-import backup</a>
          <a id='paramImportReportBtn' class='paramImportDownload' style='display:none;'>Download result report</a>
          <button id='paramImportRollbackBtn' type='button' class='danger' style='display:none;' onclick='paramImportRollback()'>Restore verified changes</button>
          <button id='paramImportApplyBtn' type='button' style='display:none;' onclick='paramImportApply()'>Apply selected parameters</button>
          <button id='paramImportCloseBtn' type='button' onclick='paramImportClose()'>Close</button>
        </div>
      </div>
      <div id='paramImportMetaPopup'
           class='paramImportMetaPopup'
           role='tooltip'
           aria-hidden='true'>
        <div class='paramImportMetaHeader'>
          <div>
            <div id='paramImportMetaName' class='paramImportMetaName'></div>
            <div id='paramImportMetaHuman' class='paramImportMetaHuman'></div>
          </div>
          <span class='paramImportMetaHint'>Parameter metadata</span>
        </div>
        <div id='paramImportMetaBody' class='paramImportMetaBody'></div>
      </div>
    </div>

    <style>
      .paramImportOverlay{{position:fixed;inset:0;background:rgba(2,6,23,.86);backdrop-filter:blur(4px);z-index:12000;display:none;align-items:center;justify-content:center;padding:24px;}}
      .paramImportOverlay.open{{display:flex;}}
      .paramImportDialog{{width:min(1180px,96vw);height:min(820px,92vh);background:#0f172a;border:1px solid #475569;border-radius:16px;box-shadow:0 24px 80px rgba(0,0,0,.55);display:flex;flex-direction:column;overflow:hidden;}}
      .paramImportHeader{{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;padding:18px 20px;border-bottom:1px solid #334155;background:#111827;}}
      .paramImportHeader h2{{margin:0 0 5px 0;}}
      .paramImportClose{{background:transparent;border:1px solid #475569;font-size:24px;line-height:1;padding:4px 10px;margin:0;}}
      .paramImportLoading{{flex:1;display:flex;align-items:center;justify-content:center;gap:14px;font-size:18px;}}
      .paramImportSpinner{{display:inline-block;width:24px;height:24px;border:3px solid #475569;border-top-color:#38bdf8;border-radius:50%;animation:paramImportSpin .85s linear infinite;flex:0 0 auto;}}
      @keyframes paramImportSpin{{to{{transform:rotate(360deg)}}}}
      #paramImportPreviewPanel,#paramImportProgressPanel{{padding:16px 20px;min-height:0;overflow:hidden;flex:1;}}
      #paramImportPreviewPanel{{display:flex;flex-direction:column;}}
      .paramImportSummary{{display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:8px;margin-bottom:10px;}}
      .paramImportSummaryItem{{background:#111827;border:1px solid #334155;border-radius:9px;padding:9px 11px;}}
      .paramImportSummaryItem strong{{display:block;font-size:20px;}}
      .paramImportSafety{{display:none;background:#451a03;border:1px solid #f97316;color:#fed7aa;border-radius:9px;padding:10px 12px;margin-bottom:10px;}}
      .paramImportToolbar{{display:flex;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:10px;}}
      .paramImportToolbar label{{display:flex;align-items:center;gap:8px;}}
      .paramImportToolbar select{{width:auto;min-width:150px;}}
      .paramImportSelectAll input{{width:auto;}}
      .paramImportTableWrap{{overflow:auto;border:1px solid #334155;border-radius:10px;flex:1;min-height:0;}}
      .paramImportTable{{min-width:920px;}}
      .paramImportTable thead{{position:sticky;top:0;background:#111827;z-index:1;}}
      .paramImportTable input{{width:auto;}}
      .paramImportStatus{{display:inline-block;padding:3px 8px;border-radius:999px;background:#334155;font-size:12px;white-space:nowrap;}}
      .paramImportStatus.changed{{background:#1e3a8a;color:#bfdbfe}}.paramImportStatus.same{{background:#14532d;color:#bbf7d0}}.paramImportStatus.unsupported,.paramImportStatus.duplicate{{background:#7c2d12;color:#fed7aa;}}
      .paramImportWarning{{color:#fbbf24;font-size:12px;max-width:360px;}}
      .paramImportMetaRow{{cursor:help;}}
      .paramImportMetaRow:hover{{background:#172033;}}
      .paramImportMetaParamName{{font-weight:800;color:#bae6fd;text-decoration:underline;text-decoration-style:dotted;text-underline-offset:3px;}}
      .paramImportMetaPopup{{position:fixed;display:none;width:min(480px,calc(100vw - 24px));max-height:min(580px,calc(100vh - 24px));overflow:auto;background:#020617;border:1px solid #64748b;border-radius:12px;box-shadow:0 18px 55px rgba(0,0,0,.72);z-index:12050;padding:0;pointer-events:none;}}
      .paramImportMetaPopup.open{{display:block;}}
      .paramImportMetaHeader{{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;padding:13px 15px;border-bottom:1px solid #334155;background:#111827;position:sticky;top:0;}}
      .paramImportMetaName{{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-weight:900;color:#7dd3fc;font-size:16px;}}
      .paramImportMetaHuman{{font-weight:700;color:#e2e8f0;margin-top:3px;}}
      .paramImportMetaHint{{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#94a3b8;white-space:nowrap;}}
      .paramImportMetaBody{{padding:13px 15px;color:#dbeafe;font-size:13px;line-height:1.45;}}
      .paramImportMetaDescription{{white-space:pre-wrap;margin-bottom:11px;}}
      .paramImportMetaGrid{{display:grid;grid-template-columns:max-content 1fr;gap:5px 12px;margin:8px 0 12px;}}
      .paramImportMetaKey{{color:#94a3b8;font-weight:700;}}
      .paramImportMetaValue{{color:#e2e8f0;overflow-wrap:anywhere;}}
      .paramImportMetaEnums{{border-top:1px solid #334155;padding-top:9px;margin-top:9px;}}
      .paramImportMetaEnumsTitle{{font-weight:800;color:#cbd5e1;margin-bottom:5px;}}
      .paramImportMetaEnumLine{{display:grid;grid-template-columns:minmax(52px,max-content) 1fr;gap:10px;padding:2px 0;}}
      .paramImportMetaEnumCode{{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;color:#7dd3fc;}}
      .paramImportMetaMuted{{color:#94a3b8;font-style:italic;}}
      .paramImportRunStatus{{display:flex;align-items:center;gap:14px;margin-bottom:18px;}}
      .paramImportProgressTrack{{height:18px;border-radius:999px;background:#020617;border:1px solid #334155;overflow:hidden;}}
      #paramImportProgressBar{{height:100%;width:0;background:linear-gradient(90deg,#0284c7,#22c55e);transition:width .3s ease;}}
      .paramImportProgressFacts{{display:flex;justify-content:space-between;margin:9px 0 12px;}}
      .paramImportCurrent{{min-height:24px;color:#bae6fd;font-weight:700;margin-bottom:10px;}}
      .paramImportEventLog{{height:calc(100% - 145px);min-height:220px;overflow:auto;background:#020617;border:1px solid #334155;border-radius:10px;padding:12px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:13px;white-space:pre-wrap;}}
      .paramImportEventLine{{padding:2px 0}}.paramImportEventLine.ok,.paramImportEventLine.complete{{color:#86efac}}.paramImportEventLine.warning{{color:#fbbf24}}.paramImportEventLine.error{{color:#fca5a5;}}
      .paramImportError{{margin:12px 20px 0;padding:10px 12px;background:#450a0a;border:1px solid #ef4444;color:#fecaca;border-radius:9px;}}
      .paramImportFooter{{display:flex;justify-content:flex-end;align-items:center;gap:8px;flex-wrap:wrap;padding:14px 20px;border-top:1px solid #334155;background:#111827;}}
      .paramImportDownload{{display:inline-block;background:#334155;color:white;border-radius:8px;padding:9px 13px;text-decoration:none;cursor:pointer;}}
      @media(max-width:700px){{.paramImportOverlay{{padding:5px}}.paramImportDialog{{width:99vw;height:98vh}}.paramImportHeader{{padding:12px}}.paramImportFooter{{padding:10px}}.paramImportSummary{{grid-template-columns:repeat(2,1fr)}}}}
    </style>

    <div class='paramLayout'>

      <div class='paramSide'>
        <h2>Parameter Groups</h2>

        <div class='paramLevelTabs'>

        </div>

        <div id='paramGroupButtons'>
          <button type='button' class='paramGroupBtn active' data-group='__ALL__' data-levels='All Standard Advanced Other' onclick="paramFilterGroup('__ALL__')">
            All <span class='small'>({len(data)})</span>
          </button>

          {group_buttons_for_level("All")}
        </div>
      </div>

      <div class='paramMain'>
        <div class='card paramToolbar'>
          <div class='paramSearchMainRow'>

            <input id='paramSearch'
                   style='pointer-events:auto;width:100%;'
                   placeholder='Search parameter, e.g. MNT_ or SERIAL4'
                   oninput='paramSaveState(); paramApplyFilter()'>

            <select id='paramSearchMode'
                    style='pointer-events:auto;'
                    onchange='paramSaveState(); paramApplyFilter()'>
              <option value='contains'>Contains</option>
              <option value='startswith' selected>Begins with</option>
            </select>

            <button type='button'
                    onclick='paramClearSearch()'
                    title="Clear search" aria-label="Clear search" style="width:28px;height:28px;min-width:28px;padding:0;display:inline-flex;align-items:center;justify-content:center;font-size:20px;font-weight:800;line-height:1;color:#fca5a5;background:transparent;border:1px solid #c8ccd2;border-radius:6px;cursor:pointer;">&times;</button>

          </div>

          <div class='paramSearchSecondaryRow'>

            <select id='paramQuickSearch'
                    class='paramQuickSearchSelect'
                    onchange='paramApplyQuickSearch(this)'>
              <option value=''>Quick search...</option>
            </select>

            <button type='button'
                    class='paramQuickActionBtn'
                    title='Freeze current search'
                    onclick='paramFreezeCurrentSearch()'>
              ❄ Freeze
            </button>

            <button type='button'
                    class='paramQuickActionBtn'
                    title='Unfreeze current search'
                    onclick='paramUnfreezeCurrentSearch()'>
              ↺ Unfreeze
            </button>

            <button type='button'
                    class='paramQuickActionBtn paramQuickDeleteBtn'
                    title='Delete current search from quick list'
                    onclick='paramDeleteCurrentSearch()'>
              × Remove
            </button>

          </div>

          <div class='paramSearchFooterRow'>
            <p class='small' id='paramResultCount'></p>

            <span class='small paramWildcardHint'>
              * = any chars&nbsp;&nbsp;? = one char
            </span>
          </div>
        </div>
    """

    body += "<div class='paramScrollArea'>"

    for grp in all_groups:

        body += f"""
        <div class='card paramGroupCard' data-group='{esc(grp)}' data-levels='{esc(level_for_group(grp))}'>
          <h2>{esc(grp)}</h2>
          <div class='paramList'>
        """

        for name,val in groups[grp]:

            search_blob = name

            if val is None:
                value_display="<span style='color:#ef4444;'>Missing</span>"
                desc_html="<span class='small'>Timeout reading parameter</span>"
                level="Other"
            else:
                raw_val=str(val.get("value"))
                label=val.get("value_label") or ""
                values=val.get("values") or {}

                if values:
                    opts=""
                    current_key=str(int(float(raw_val))) if str(raw_val).replace(".0","").lstrip("-").isdigit() else str(raw_val)
                    for code,text in sorted(values.items(), key=lambda x: float(x[0]) if str(x[0]).replace(".","",1).lstrip("-").isdigit() else 999999):
                        selected="selected" if str(code)==current_key else ""
                        opts += f"<option value='{esc(str(code))}' {selected}>{esc(str(text))} ({esc(str(code))})</option>"

                    editor=f"""
                    <select name='value' class='paramEditInput'>
                      {opts}
                    </select>
                    """
                else:
                    editor=f"<input name='value' class='paramEditInput' value='{esc(raw_val)}'>"

                if label:
                    value_display=f"<b>{esc(label)}</b> <span class='small'>({esc(raw_val)})</span>"
                else:
                    value_display=f"<b>{esc(raw_val)}</b>"

                value_display += f"""
                <form method='post'
                      action='/param_write'
                      class='paramWriteForm'
                      onsubmit="return confirm('Write parameter {esc(name)} ?');">
                  <input type='hidden' name='name' value='{esc(name)}'>
                  {editor}
                  <button type='submit' class='paramWriteBtn'>Write</button>
                </form>
                """

                human=val.get("humanName") or ""
                doc=val.get("documentation") or ""
                user=val.get("user") or ""

                if human or doc:
                    desc_html=f"<span>{esc(human)}</span><br><span class='small'>{esc(doc)}</span>"
                else:
                    desc_html="<span class='small'>No metadata description</span>"

                level=user or "Other"

                search_blob = " ".join([
                    name,
                    str(label),
                    str(human),
                    str(doc),
                    str(grp),
                    str(level),
                ])

            body += f"""
            <div class='paramRow'
                 data-group='{esc(grp)}'
                 data-levels='{esc(level_for_group(grp))}'
                 data-param='{esc(name)}'
                 data-paramname='{esc(name)}'
                 data-search='{esc(search_blob.lower())}'>
              <div class='paramName'>{esc(name)}</div>
              <div class='paramValue' id='paramValue_{esc(name)}'>{value_display}</div>
              <div class='paramDesc'>{desc_html}</div>
            </div>
            """

        body += "</div></div>"

    body += """
      </div>
      </div>
    </div>

    <style>
      .paramLayout{
        display:grid;
        grid-template-columns:270px 1fr;
        gap:16px;
        align-items:start;
        overflow:visible;
      }
      .paramTopCompact{
        display:flex;
        align-items:center;
        gap:16px;
        flex-wrap:wrap;
        padding:10px 16px;
        margin-bottom:10px;
      }
      .paramTopCompact p,
      .paramTopCompact form{
        margin:0;
      }
      .paramTopTitle{
        font-weight:bold;
      }
      .paramTopDivider{
        width:1px;
        height:24px;
        background:#475569;
      }
      .paramTopRefreshForm{
        display:inline-flex;
        align-items:center;
      }
      .paramTopStatus{
        color:#22c55e;
        font-weight:bold;
      }

      .paramSide{
        height:calc(100vh - var(--paramPaneTop, 190px) - 24px);
        min-height:0;
        overflow:auto;
        box-sizing:border-box;
        background:#0b1220;
        border:1px solid #334155;
        border-radius:10px;
        padding:12px;
      }
      .paramSide h2{
        margin-top:0;
        position:sticky;
        top:-12px;
        z-index:20;
        background:#0b1220;
        padding:4px 0 10px 0;
      }
      .paramLevelTabs{
        display:grid;
        grid-template-columns:1fr 1fr;
        gap:6px;
        margin-bottom:12px;
      }
      .paramLevelBtn{
        margin:0;
        padding:8px 6px;
        background:#374151;
        border:1px solid #4b5563;
        color:#e5e7eb;
      }
      .paramLevelBtn.active{
        background:#fff27a;
        color:#111827;
        border-color:#fde047;
      }
      .paramGroupBtn{
        display:block;
        width:100%;
        text-align:center;
        margin:6px 0;
        padding:10px 8px;
        background:#747484;
        border:1px solid #747484;
        color:white;
        border-radius:5px;
      }
      .paramGroupBtn.active{
        background:#fff27a;
        color:#111827;
        border-color:#fde047;
      }
      .paramMain{
        min-width:0;
        height:calc(100vh - var(--paramPaneTop, 190px) - 24px);
        min-height:0;
        box-sizing:border-box;
        display:flex;
        flex-direction:column;
        overflow:hidden;
      }
      .paramToolbar{
        flex:0 0 auto;
        margin-bottom:0;
      }
      .paramScrollArea{
        flex:1 1 auto;
        overflow-y:auto;
        padding-right:6px;
        min-height:0;
      }
      .paramSearchBar{
        display:grid;
        grid-template-columns:minmax(260px, 1fr) minmax(180px, 260px) auto minmax(220px, auto);
        gap:10px;
        align-items:center;
      }
      .paramSearchMainRow{
        display:grid;
        grid-template-columns:minmax(320px,1fr) 180px auto;
        gap:10px;
        align-items:center;
      }

      .paramSearchSecondaryRow{
        margin-top:8px;
        display:flex;
        align-items:center;
        gap:8px;
        flex-wrap:wrap;
        opacity:.88;
      }

      .paramSearchFooterRow{
        margin-top:8px;
        display:flex;
        justify-content:space-between;
        align-items:center;
        gap:12px;
      }

      .paramQuickSearchSelect{
        min-width:220px;
        max-width:320px;
        pointer-events:auto;
      }

      .paramWildcardHint{
        color:#94a3b8;
        white-space:nowrap;
      }

      .paramQuickActionBtn{
        height:28px;
        padding:0 10px;
        border-radius:999px;
        font-size:12px;
        background:#0f172a;
        color:#94a3b8;
        border:1px solid #334155;
      }

      .paramQuickActionBtn:hover{
        color:#e5e7eb;
        border-color:#64748b;
        background:#111827;
      }

      .paramQuickDeleteBtn{
        color:#fca5a5;
      }

      .paramQuickDeleteBtn:hover{
        color:#fecaca;
      }
      .paramSearchBar input,
      .paramSearchBar select{
        width:100% !important;
        max-width:none !important;
        box-sizing:border-box;
      }
      .paramSearchBar select{
        background:#020617;
        color:#e5e7eb;
        border:1px solid #334155;
        border-radius:8px;
        padding:9px 10px;
      }
      .paramQuickActionBtn{
        pointer-events:auto;
        width:30px;
        height:30px;
        padding:0;
        margin:0;
        border-radius:999px;
        border:1px solid #334155;
        background:#0b1220;
        color:#94a3b8;
        font-size:14px;
        line-height:1;
        opacity:.78;
      }
      .paramQuickActionBtn:hover{
        opacity:1;
        color:#e5e7eb;
        border-color:#64748b;
        background:#111827;
      }
      .paramQuickDeleteBtn{
        color:#fca5a5;
      }
      .paramQuickDeleteBtn:hover{
        color:#fecaca;
        border-color:#7f1d1d;
      }
      .paramToolbar{
        padding:10px 12px;
      }
      #paramResultCount{
        margin:8px 0 0 0;
      }
      .paramList{display:flex;flex-direction:column;}
      .paramRow{
        display:grid;
        grid-template-columns:210px 170px 1fr;
        gap:16px;
        padding:7px 4px;
        border-bottom:1px solid rgba(148,163,184,.18);
        align-items:start;
        cursor:pointer;
      }
      .paramRow:hover{background:#111827;}
      .paramName{
        color:#dbeafe;
        font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size:14px;
      }
      .paramValue{
        color:#e5e7eb;
        font-size:14px;
      }
      .paramDesc{
        color:#cbd5e1;
        font-size:13px;
      }
      .paramWriteForm{
        margin-top:7px;
        display:flex;
        gap:6px;
        align-items:center;
        flex-wrap:wrap;
      }
      .paramEditInput{
        pointer-events:auto;
        width:130px;
        background:#020617;
        color:#e5e7eb;
        border:1px solid #334155;
        border-radius:7px;
        padding:6px 8px;
      }
      .paramWriteBtn{
        pointer-events:auto;
        padding:6px 9px;
        font-size:12px;
        background:#14532d;
      }
      .paramHidden{display:none !important;}
      @media (max-width:1000px){
        .paramLayout{
          grid-template-columns:1fr;
          height:auto;
          overflow:visible;
        }
        .paramSide{position:relative;max-height:none;}
        .paramMain{
          height:auto;
          overflow:visible;
          display:block;
        }
        .paramScrollArea{
          overflow:visible;
        }
        .paramRow{grid-template-columns:1fr;}
      }


      /* ===== PARAM TOOLBAR FINAL POLISH ===== */

      .paramSearchMainRow{
        grid-template-columns:340px 180px auto !important;
        align-items:center !important;
      }

      .paramSearchSecondaryRow{
        margin-top:8px !important;
        display:grid !important;
        grid-template-columns:340px 36px 36px 36px !important;
        gap:8px !important;
        align-items:center !important;
      }

      .paramSearchMainRow input{
        width:340px !important;
        max-width:340px !important;
      }

      .paramQuickSearchSelect{
        width:340px !important;
        max-width:340px !important;
        min-width:340px !important;
      }

      .paramIconBtn,
      .paramQuickActionBtn{
        width:36px !important;
        height:36px !important;
        min-width:36px !important;
        padding:0 !important;
        border-radius:8px !important;

        display:flex !important;
        align-items:center !important;
        justify-content:center !important;

        font-size:16px !important;
        line-height:1 !important;

        background:#0f172a !important;
        border:1px solid #334155 !important;

        overflow:hidden !important;
        text-indent:-9999px !important;
        position:relative !important;
      }

      .paramIconBtn::before,
      .paramQuickActionBtn::before{
        position:absolute;
        inset:0;
        display:flex;
        align-items:center;
        justify-content:center;
        text-indent:0;
        font-size:16px;
      }

      button[onclick*='Freeze']::before{
        content:'❄';
        color:#93c5fd;
      }

      button[onclick*='Unfreeze']::before{
        content:'↺';
        color:#cbd5e1;
      }

      button[onclick*='Delete']::before{
        content:'×';
        color:#fca5a5;
        font-size:18px;
        font-weight:700;
      }

      .paramIconBtn:hover,
      .paramQuickActionBtn:hover{
        border-color:#64748b !important;
        background:#111827 !important;
      }


    </style>

    <script>
      let selectedParamLevel='All';
      let selectedParamGroup='__ALL__';

      function paramUpdatePaneHeights(){
        try{
          const side=document.querySelector('.paramSide');
          const main=document.querySelector('.paramMain');
          const el=side || main;
          if(!el){return;}
          const top=Math.ceil(el.getBoundingClientRect().top);
          document.documentElement.style.setProperty('--paramPaneTop', top + 'px');
        }catch(e){}
      }

      function paramDeleteCurrentSearch(){
        const input=document.getElementById('paramSearch');
        const value=String(input?.value || '').trim();

        if(!value){return;}

        let data=paramHistoryLoad();
        const key=value.toLowerCase();

        data.frozen=data.frozen.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.recent=data.recent.filter(function(v){
          return v.toLowerCase() !== key;
        });

        paramHistorySave(data);
        paramHistoryRender();
      }

      window.addEventListener('load', function(){
        paramUpdatePaneHeights();
        setTimeout(paramUpdatePaneHeights, 50);
      });
      window.addEventListener('resize', paramUpdatePaneHeights);

      function paramSaveState(){
        try{
          localStorage.setItem('siyi_param_level', selectedParamLevel);
          localStorage.setItem('siyi_param_group', selectedParamGroup);
          localStorage.setItem('siyi_param_search', document.getElementById('paramSearch')?.value || '');
          localStorage.setItem('siyi_param_search_mode', document.getElementById('paramSearchMode')?.value || 'startswith');
        }catch(e){}
      }

      function paramRestoreState(){
        try{
          selectedParamLevel = localStorage.getItem('siyi_param_level') || 'All';
          selectedParamGroup = localStorage.getItem('siyi_param_group') || '__ALL__';

          const search=document.getElementById('paramSearch');
          if(search){ search.value = localStorage.getItem('siyi_param_search') || ''; }

          const mode=document.getElementById('paramSearchMode');
          if(mode){ mode.value = localStorage.getItem('siyi_param_search_mode') || 'startswith'; }
        }catch(e){
          selectedParamLevel='All';
          selectedParamGroup='__ALL__';
        }
      }

      function paramFilterLevel(level){
        selectedParamLevel=level;
        selectedParamGroup='__ALL__';
        paramSaveState();

        document.querySelectorAll('.paramLevelBtn').forEach(btn=>{
          btn.classList.toggle('active', btn.dataset.level===level);
        });

        document.querySelectorAll('.paramGroupBtn').forEach(btn=>{
          const g=btn.dataset.group || '';
          const levels=btn.dataset.levels || '';
          let visible = (g==='__ALL__' || level==='All' || levels.split(' ').includes(level));
          btn.classList.toggle('paramHidden', !visible);
          btn.classList.toggle('active', g==='__ALL__');
        });
        paramApplyFilter();
        // paramSyncVisibleAfterFilterChange(); // disabled: live /state polling handles normal updates
      }

      function paramFilterGroup(group){
        selectedParamGroup=group;

        const search=document.getElementById('paramSearch');
        if(search){ search.value=''; }

        paramSaveState();

        document.querySelectorAll('.paramGroupBtn').forEach(btn=>{
          btn.classList.toggle('active', btn.dataset.group===group);
        });
        paramApplyFilter();
        // paramSyncVisibleAfterFilterChange(); // disabled: live /state polling handles normal updates
      }

      const PARAM_SEARCH_HISTORY_KEY='siyi_param_search_history_v2_clean';

      function paramHistoryEmpty(){
        return {frozen:[], recent:[]};
      }

      function paramHistoryNormalize(data){
        let frozen=[];
        let recent=[];

        if(Array.isArray(data)){
          recent=data;
        }else if(data && typeof data === 'object'){
          frozen=Array.isArray(data.frozen) ? data.frozen : [];
          recent=Array.isArray(data.recent) ? data.recent : [];
        }

        frozen=frozen
          .map(function(v){return String(v || '').trim();})
          .filter(function(v){return v.length > 0;});

        recent=recent
          .map(function(v){return String(v || '').trim();})
          .filter(function(v){return v.length > 0;});

        const seen=new Set();

        frozen=frozen.filter(function(v){
          const k=v.toLowerCase();
          if(seen.has(k)){return false;}
          seen.add(k);
          return true;
        });

        recent=recent.filter(function(v){
          const k=v.toLowerCase();
          if(seen.has(k)){return false;}
          seen.add(k);
          return true;
        }).slice(0,10);

        return {frozen:frozen, recent:recent};
      }

      function paramHistoryLoad(){
        try{
          const raw=localStorage.getItem(PARAM_SEARCH_HISTORY_KEY) || '[]';
          return paramHistoryNormalize(JSON.parse(raw));
        }catch(e){
          return paramHistoryEmpty();
        }
      }

      function paramHistorySave(data){
        try{
          localStorage.setItem(
            PARAM_SEARCH_HISTORY_KEY,
            JSON.stringify(paramHistoryNormalize(data))
          );
        }catch(e){}
      }

      function paramHistoryRender(){
        const sel=document.getElementById('paramQuickSearch');
        if(!sel){return;}

        while(sel.options.length > 1){
          sel.remove(1);
        }

        const data=paramHistoryLoad();
        const arr=data.frozen.concat(data.recent);

        arr.forEach(function(v){
          const opt=document.createElement('option');
          opt.value=v;
          opt.textContent=(data.frozen.map(function(x){return x.toLowerCase();}).includes(v.toLowerCase()) ? '❄ ' : '') + v;
          sel.appendChild(opt);
        });
      }

      function paramHistoryRemember(){
        const input=document.getElementById('paramSearch');
        if(!input){return;}

        const value=String(input.value || '').trim();
        if(!value){return;}

        let data=paramHistoryLoad();
        const key=value.toLowerCase();

        if(data.frozen.map(function(v){return v.toLowerCase();}).includes(key)){
          paramHistoryRender();
          return;
        }

        data.recent=data.recent.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.recent.unshift(value);
        data=paramHistoryNormalize(data);

        paramHistorySave(data);
        paramHistoryRender();
      }

      function paramFreezeCurrentSearch(){
        const input=document.getElementById('paramSearch');
        const value=String(input?.value || '').trim();
        if(!value){return;}

        let data=paramHistoryLoad();
        const key=value.toLowerCase();

        data.frozen=data.frozen.filter(function(v){
          return v.toLowerCase() !== key;
        });
        data.recent=data.recent.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.frozen.unshift(value);
        data=paramHistoryNormalize(data);

        paramHistorySave(data);
        paramHistoryRender();
      }

      function paramUnfreezeCurrentSearch(){
        const input=document.getElementById('paramSearch');
        const value=String(input?.value || '').trim();
        if(!value){return;}

        let data=paramHistoryLoad();
        const key=value.toLowerCase();

        data.frozen=data.frozen.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.recent=data.recent.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.recent.unshift(value);
        data=paramHistoryNormalize(data);

        paramHistorySave(data);
        paramHistoryRender();
      }

      window.addEventListener('load', function(){
        paramHistoryRender();

        const input=document.getElementById('paramSearch');
        if(input){
          input.addEventListener('change', paramHistoryRemember);
          input.addEventListener('keydown', function(ev){
            if(ev.key === 'Enter'){
              paramHistoryRemember();
            }
          });
        }
      });

      function paramApplyQuickSearch(sel){
        const search=document.getElementById('paramSearch');
        const value=sel?.value || '';

        if(value && search){
          search.value=value;
          paramSaveState();
          paramApplyFilter();
          // paramSyncVisibleAfterFilterChange(); // disabled: live /state polling handles normal updates
        }

        if(sel){
          sel.value='';
        }
      }

      function paramClearSearch(){
        const search=document.getElementById('paramSearch');
        if(search){ search.value=''; }

        paramSaveState();
        paramApplyFilter(); // auto visible sync disabled; live state polling handles updates

        try{
          localStorage.removeItem('siyi_param_search');
        }catch(e){}
      }

      function paramWildcardMatch(text, pattern){
        text=(text || '').toLowerCase();
        pattern=(pattern || '').toLowerCase();

        let ti=0, pi=0, star=-1, match=0;

        while(ti < text.length){
          if(pi < pattern.length && (pattern[pi] === '?' || pattern[pi] === text[ti])){
            ti++;
            pi++;
          }else if(pi < pattern.length && pattern[pi] === '*'){
            star=pi;
            match=ti;
            pi++;
          }else if(star !== -1){
            pi=star+1;
            match++;
            ti=match;
          }else{
            return false;
          }
        }

        while(pi < pattern.length && pattern[pi] === '*'){
          pi++;
        }

        return pi === pattern.length;
      }

      function paramWildcardContains(text, pattern){
        text=(text || '').toLowerCase();
        pattern=(pattern || '').toLowerCase();

        for(let i=0; i<=text.length; i++){
          if(paramWildcardMatch(text.slice(i), pattern)){
            return true;
          }
        }
        return false;
      }

      function paramApplyFilter(){
        const q=(document.getElementById('paramSearch')?.value || '').toLowerCase().trim();
        const mode=(document.getElementById('paramSearchMode')?.value || 'startswith');
        const hasWildcard=(q.includes('*') || q.includes('?'));
        let visibleRows=0;

        document.querySelectorAll('.paramGroupCard').forEach(card=>{
          const group=card.dataset.group || '';
          const levels=card.dataset.levels || '';
          let groupVisibleRows=0;

          card.querySelectorAll('.paramRow').forEach(row=>{
            const rowGroup=row.dataset.group || '';
            const rowLevels=row.dataset.levels || '';
            const param=row.dataset.param || '';
            const blob=row.dataset.search || '';

            let okLevel=(selectedParamLevel==='All' || rowLevels.split(' ').includes(selectedParamLevel));
            let okGroup=(selectedParamGroup==='__ALL__' || rowGroup===selectedParamGroup);

            let okSearch=true;
            if(q){
              if(hasWildcard){
                if(mode === 'contains'){
                  okSearch = paramWildcardContains(blob, q);
                }else{
                  let pattern=q;

                  if(!pattern.endsWith('*')){
                    pattern += '*';
                  }

                  okSearch = paramWildcardMatch(
                    param.toLowerCase(),
                    pattern
                  );
                }
              }else if(mode === 'contains'){
                okSearch = blob.includes(q);
              }else{
                okSearch = param.toLowerCase().startsWith(q);
              }
            }

            const show=okLevel && okGroup && okSearch;
            row.classList.toggle('paramHidden', !show);

            if(show){
              groupVisibleRows++;
              visibleRows++;
            }
          });

          card.classList.toggle('paramHidden', groupVisibleRows===0);
        });

        const c=document.getElementById('paramResultCount');
        if(c){
          c.textContent = 'Showing ' + visibleRows + ' parameter(s)';
        }
      }

      async function paramPollRefreshState(){
        try{
          const r=await fetch('/param_sync_status?ts=' + Date.now());
          const j=await r.json();
          const el=document.getElementById('paramRefreshStatus');

          if(el){
            el.textContent = j.message || '';
            el.style.color = j.running ? '#facc15' : (j.ok ? '#22c55e' : '#ef4444');
          }

          if(j.running){
            setTimeout(paramPollRefreshState, 1000);
          }else if(j.ok && sessionStorage.getItem('siyi_param_refresh_pending') === '1'){

            // IMPORTANT:
            // Do NOT start additional PARAM_REQUEST_READ traffic immediately
            // after full PARAM_REQUEST_LIST refresh.
            //
            // Multiple concurrent pymavlink param readers can steal
            // PARAM_VALUE messages from each other and corrupt refresh stability.
            //
            // Simply reload once stable full cache completed.
            sessionStorage.removeItem('siyi_param_refresh_pending');
            // Disabled: caused reload loop after paramd sync completed.
            // Cached values are now updated through /param_state polling.
            paramPollVisibleState();
          }
        }catch(e){
          setTimeout(paramPollRefreshState, 2000);
        }
      }

      document.addEventListener('submit', (e)=>{
        if(e.target && e.target.getAttribute('action') === '/params_refresh'){
          sessionStorage.setItem('siyi_param_refresh_pending', '1');
        }
      });

      let paramLiveRefreshRunning=false;
      let paramLiveRefreshGeneration=0;
      let paramLiveRefreshAbortController=null;

      function paramApplyCachedStateUpdate(pname, item){
        try{
          if(!pname || !item || item.missing) return;

          const box=document.getElementById('paramValue_' + pname);
          if(!box) return;

          const row=box.closest('.paramRow');
          if(row && row.classList.contains('paramHidden')) return;

          const val=String(item.value).replace(/\.0$/, '');
          const input=box.querySelector('.paramEditInput');

          // Do not overwrite a value while the user is actively editing it.
          if(input && document.activeElement === input){
            return;
          }

          if(input){
            input.value=val;
          }

          const b=box.querySelector('b');
          if(b){
            if(input && input.tagName === 'SELECT'){
              const opt=[...input.options].find(o => String(o.value) === val);
              if(opt){
                input.value=opt.value;
                b.textContent=opt.textContent.replace(/ \([^)]*\)$/, '');
              }else{
                b.textContent=val;
              }
            }else{
              b.textContent=val;
            }
          }

          box.dataset.liveTs=String(item.ts || Date.now()/1000);
        }catch(e){
          console.log('paramApplyCachedStateUpdate failed', e);
        }
      }

      let paramStatePollRunning=false;

      async function paramPollVisibleState(){
        if(paramStatePollRunning) return;
        paramStatePollRunning=true;

        try{
          let rows=[...document.querySelectorAll('.paramRow')]
            .filter(r => !r.classList.contains('paramHidden'))
            .slice(0,120);

          const names=rows
            .map(r => r.dataset.paramname || r.dataset.param || '')
            .filter(Boolean);

          if(!names.length) return;

          const r=await fetch('/param_state?names=' + encodeURIComponent(names.join(',')) + '&ts=' + Date.now(), {cache:'no-store'});
          const j=await r.json();

          if(j && j.ok && j.params){
            Object.entries(j.params).forEach(([name,item]) => {
              paramApplyCachedStateUpdate(name,item);
            });
          }
        }catch(e){
          console.log('paramPollVisibleState failed', e);
        }finally{
          paramStatePollRunning=false;
        }
      }

      async function paramManualFullSync(event){
        if(event) event.preventDefault();

        const el=document.getElementById('paramRefreshStatus');
        if(el){
          el.textContent='Synchronizing parameters from FC...';
          el.style.color='#facc15';
        }

        try{
          const r=await fetch('/param_trigger_full_sync?ts=' + Date.now(), {cache:'no-store'});
          const j=await r.json();
          if(!j || !j.ok){
            if(el){
              el.textContent='Parameter sync failed';
              el.style.color='#ef4444';
            }
            alert('Parameter sync failed: ' + ((j && j.error) ? j.error : 'unknown error'));
            return false;
          }
          paramPollSyncStatus();
        }catch(e){
          if(el){
            el.textContent='Parameter sync failed';
            el.style.color='#ef4444';
          }
          alert('Parameter sync failed: ' + e.message);
        }

        return false;
      }

      async function paramPollSyncStatus(){
        try{
          const el=document.getElementById('paramRefreshStatus');
          if(!el) return;
          const r=await fetch('/param_sync_status?ts=' + Date.now(), {cache:'no-store'});
          const j=await r.json();
          if(!j || !j.ok) return;

          if(j.running){
            el.textContent=j.message || 'Synchronizing parameters from FC...';
            el.style.color='#facc15';
          }else if(j.last_ok){
            el.textContent='Parameters synchronized from FC';
            el.style.color='#22c55e';
          }
        }catch(e){
          console.log('paramPollSyncStatus failed', e);
        }
      }

      function paramStartSyncStatusPolling(){
        if(window.siyiParamSyncStatusTimer) return;
        window.siyiParamSyncStatusTimer=setInterval(paramPollSyncStatus, 1000);
        setTimeout(paramPollSyncStatus, 250);
      }

      function paramStartStatePolling(){
        if(window.siyiParamStatePollTimer) return;
        window.siyiParamStatePollTimer=setInterval(paramPollVisibleState, 500);
        setTimeout(paramPollVisibleState, 200);
      }

      async function paramLiveReadVisibleSerial(syncGeneration){

        const myGeneration = syncGeneration || paramLiveRefreshGeneration;

        if(paramLiveRefreshRunning){
          return;
        }

        paramLiveRefreshRunning=true;

        const el=document.getElementById('paramRefreshStatus');
        let rows=[...document.querySelectorAll('.paramRow')];

        // Older/restored backups may not consistently preserve .paramRow.
        // Fall back to any element carrying parameter metadata.
        if(!rows.length){
          rows=[...document.querySelectorAll('[data-paramname]')];
        }

        rows = rows
          .filter(r => !r.classList.contains('paramHidden'))
          .slice(0,80);

        if(el){
          el.textContent='Synchronizing parameters from FC...';  // only for explicit/manual sync paths
          el.style.color='#facc15';
        }

        let n=0;
        let failed=[];
        for(const row of rows){

          if(myGeneration !== paramLiveRefreshGeneration){
            break;
          }

          try{
            const pname=row.dataset.paramname;
            if(!pname) continue;

            const controller = new AbortController();
            paramLiveRefreshAbortController = controller;

            const timeout = setTimeout(()=>{
              controller.abort();
            }, 5000);

            let j=null;

            try{
              const r=await fetch(
                '/param_live_read?name=' + encodeURIComponent(pname) + '&ts=' + Date.now(),
                {signal: controller.signal}
              );

              j=await r.json();
            }finally{
              clearTimeout(timeout);
            }

            if(!j){
              failed.push(pname + ': no response');
              continue;
            }

            if(j.ok){
              const box=document.getElementById('paramValue_' + pname);
              if(box){
                const input=box.querySelector('.paramEditInput');
                if(input){ input.value = String(j.value).replace(/\.0$/, ''); }

                const b=box.querySelector('b');
                if(b){
                  if(input && input.tagName === 'SELECT'){
                    const opt=input.options[input.selectedIndex];
                    b.textContent = opt ? opt.textContent.replace(/ \([^)]*\)$/, '') : j.value;
                  }else{
                    b.textContent = j.value;
                  }
                }
              }
              n++;
            }else{
              failed.push(pname + ': ' + (j.error || 'not ok'));
            }
          }catch(e){
            if(myGeneration !== paramLiveRefreshGeneration){
              break;
            }
            failed.push((row && row.dataset ? row.dataset.paramname : '?') + ': ' + e);
          }
        }

        if(el && myGeneration === paramLiveRefreshGeneration){
          el.textContent='Parameters synchronized from FC';
          el.style.color='#22c55e';
        }

        paramLiveRefreshAbortController=null;
        paramLiveRefreshRunning=false;
      }

      document.addEventListener('DOMContentLoaded', ()=>{
        paramRestoreState();

        document.querySelectorAll('.paramLevelBtn').forEach(btn=>{
          btn.classList.toggle('active', btn.dataset.level===selectedParamLevel);
        });

        document.querySelectorAll('.paramGroupBtn').forEach(btn=>{
          const g=btn.dataset.group || '';
          const levels=btn.dataset.levels || '';
          let visible = (g==='__ALL__' || selectedParamLevel==='All' || levels.split(' ').includes(selectedParamLevel));
          btn.classList.toggle('paramHidden', !visible);
          btn.classList.toggle('active', g===selectedParamGroup);
        });

        paramApplyFilter();
        paramStartStatePolling();
        paramStartSyncStatusPolling();
        paramPollRefreshState();

        // Auto live param reads enabled: siyi-paramd serializes MAVLink parameter access safely
        
// setTimeout(paramLiveReadVisibleSerial, 700); // disabled
// setTimeout(paramLiveReadVisibleSerial, 1800); // disabled
// setTimeout(paramLiveReadVisibleSerial, 3200); // disabled

      });

      // window load auto live sync disabled; paramd startup sync + state polling handles normal updates

      // pageshow auto live sync disabled; paramd startup sync + state polling handles normal updates

      // FORCE live FC reads whenever /parameters is opened/refreshed.
      // This avoids relying on stale rendered/cache values.
      let paramFilterSyncTimer=null;

      function fcParameterExportClick(event){
      if(event) event.preventDefault();

      const st=document.getElementById('paramRefreshStatus');
      const n=document.getElementById('fcExportChromeNote');
      const b=document.getElementById('fcParamExportBtn');

      if(st) st.innerText='Synchronizing parameters from FC… export will download when ready';
      if(n) n.style.display='inline';
      if(b) {
        b.innerText='Export running…';
        b.style.opacity='0.75';
        b.style.pointerEvents='none';
      }

      fetch('/fc_parameter_export?ts='+Date.now())
        .then(function(r){
          if(!r.ok){
            return r.text().then(function(t){
              throw new Error(t || ('HTTP '+r.status));
            });
          }
          const cd=r.headers.get('Content-Disposition') || '';
          const m=cd.match(/filename="?([^";]+)"?/);
          const fn=m ? m[1] : 'fc_parameters.params';
          return r.blob().then(function(blob){
            const u=URL.createObjectURL(blob);
            const a=document.createElement('a');
            a.href=u;
            a.download=fn;
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(function(){ URL.revokeObjectURL(u); }, 1000);
          });
        })
        .catch(function(e){
          alert('FC Parameter Export failed: ' + e.message);
        })
        .finally(function(){
          if(st) st.innerText='';
          if(n) n.style.display='none';
          if(b) {
            b.innerText='FC Parameter Export';
            b.style.opacity='1';
            b.style.pointerEvents='auto';
          }
        });

      return false;
    }

    function paramSyncVisibleAfterFilterChange(){
        try{
          // Any page/filter/search/group change invalidates the currently running sync.
          paramLiveRefreshGeneration++;

          if(paramFilterSyncTimer){
            clearTimeout(paramFilterSyncTimer);
            paramFilterSyncTimer=null;
          }

          if(paramLiveRefreshAbortController){
            try{ paramLiveRefreshAbortController.abort(); }catch(e){}
            paramLiveRefreshAbortController=null;
          }

          const thisGeneration = paramLiveRefreshGeneration;

          const el=document.getElementById('paramRefreshStatus');
          if(el){
            el.textContent='Waiting to synchronize parameters from FC...';
            el.style.color='#facc15';
          }

          paramFilterSyncTimer=setTimeout(function(){
            if(typeof paramLiveReadVisibleSerial === 'function'){
              // paramLiveReadVisibleSerial(thisGeneration); // disabled: /state polling handles normal updates
            }
          }, 2500);

        }catch(e){
          console.log('paramSyncVisibleAfterFilterChange failed', e);
        }
      }


      function paramForceRefreshFromFC(){
        try{
          sessionStorage.setItem('siyi_param_refresh_pending', '1');

          if(typeof paramApplyFilter === 'function'){
            paramApplyFilter();
          }

          if(typeof paramLiveReadVisibleSerial === 'function'){
            // setTimeout(paramLiveReadVisibleSerial, 200); // disabled
            // setTimeout(paramLiveReadVisibleSerial, 1200); // disabled
            // setTimeout(paramLiveReadVisibleSerial, 2500); // disabled
          }
        }catch(e){
          console.log('paramForceRefreshFromFC failed', e);
        }
      }

      window.addEventListener('load', paramForceRefreshFromFC);

      window.addEventListener('pageshow', paramForceRefreshFromFC);

      // === ARDUPLANE PARAMETER IMPORT V1 ===
      let paramImportSessionId='';
      let paramImportPreview=null;
      let paramImportStatusTimer=null;
      const paramImportMetadataCache=new Map();
      let paramImportMetaHoverTimer=null;
      let paramImportMetaRequestSerial=0;
      let paramImportMetaLastPointer={x:0,y:0};

      function paramImportMetaHide(){
        clearTimeout(paramImportMetaHoverTimer);
        const popup=document.getElementById('paramImportMetaPopup');
        if(popup){ popup.classList.remove('open'); popup.setAttribute('aria-hidden','true'); }
      }

      function paramImportMetaPosition(clientX,clientY){
        const popup=document.getElementById('paramImportMetaPopup');
        if(!popup) return;
        paramImportMetaLastPointer={x:clientX,y:clientY};
        const gap=18;
        const margin=12;
        const rect=popup.getBoundingClientRect();
        let left=clientX+gap;
        let top=clientY+gap;
        if(left+rect.width+margin>window.innerWidth) left=clientX-rect.width-gap;
        if(top+rect.height+margin>window.innerHeight) top=window.innerHeight-rect.height-margin;
        left=Math.max(margin,left);
        top=Math.max(margin,top);
        popup.style.left=Math.round(left)+'px';
        popup.style.top=Math.round(top)+'px';
      }

      function paramImportMetaText(parent,className,text){
        const node=document.createElement('div');
        if(className) node.className=className;
        node.textContent=text;
        parent.appendChild(node);
        return node;
      }

      function paramImportMetaGridRow(grid,key,value){
        if(value===null || value===undefined || String(value).trim()==='') return;
        paramImportMetaText(grid,'paramImportMetaKey',String(key));
        paramImportMetaText(grid,'paramImportMetaValue',String(value));
      }

      function paramImportRenderMetadata(data,item){
        const name=document.getElementById('paramImportMetaName');
        const human=document.getElementById('paramImportMetaHuman');
        const body=document.getElementById('paramImportMetaBody');
        name.textContent=item.name;
        human.textContent=(data && data.available && data.humanName) ? data.humanName : '';
        body.replaceChildren();

        const grid=document.createElement('div');
        grid.className='paramImportMetaGrid';
        paramImportMetaGridRow(grid,'Current value',item.current===null || item.current===undefined ? 'Not present on FC':item.current);
        paramImportMetaGridRow(grid,'Imported value',item.imported);
        paramImportMetaGridRow(grid,'Import status',item.status);
        if(item.type!==null && item.type!==undefined) paramImportMetaGridRow(grid,'MAVLink type',item.type);

        if(!data || !data.available){
          body.appendChild(grid);
          paramImportMetaText(body,'paramImportMetaMuted',(data && data.message) || 'No ArduPilot metadata is available for this parameter.');
          return;
        }

        if(data.documentation) paramImportMetaText(body,'paramImportMetaDescription',data.documentation);
        paramImportMetaGridRow(grid,'User level',data.user);
        Object.entries(data.fields || {}).forEach(([key,value])=>paramImportMetaGridRow(grid,key,value));
        body.appendChild(grid);

        const entries=Object.entries(data.values || {});
        if(entries.length){
          const enumBox=document.createElement('div');
          enumBox.className='paramImportMetaEnums';
          paramImportMetaText(enumBox,'paramImportMetaEnumsTitle','Allowed / enumerated values');
          entries.slice(0,60).forEach(([code,label])=>{
            const line=document.createElement('div'); line.className='paramImportMetaEnumLine';
            paramImportMetaText(line,'paramImportMetaEnumCode',code);
            paramImportMetaText(line,'',label);
            enumBox.appendChild(line);
          });
          if(entries.length>60) paramImportMetaText(enumBox,'paramImportMetaMuted','+'+(entries.length-60)+' additional values');
          body.appendChild(enumBox);
        }
      }

      async function paramImportMetaShowNow(item,event){
        const popup=document.getElementById('paramImportMetaPopup');
        if(!popup) return;
        popup.classList.add('open');
        popup.setAttribute('aria-hidden','false');
        document.getElementById('paramImportMetaName').textContent=item.name;
        document.getElementById('paramImportMetaHuman').textContent='';
        const body=document.getElementById('paramImportMetaBody');
        body.replaceChildren();
        paramImportMetaText(body,'paramImportMetaMuted','Loading parameter metadata...');
        paramImportMetaPosition(event.clientX,event.clientY);

        const serial=++paramImportMetaRequestSerial;
        try{
          let data=item.metadata || paramImportMetadataCache.get(item.name);
          if(data){
            paramImportMetadataCache.set(item.name,data);
          }else{
            const response=await fetch('/param_metadata?name='+encodeURIComponent(item.name),{cache:'no-store'});
            data=await response.json();
            if(!response.ok || !data.ok) throw new Error(data.error || ('HTTP '+response.status));
            paramImportMetadataCache.set(item.name,data);
          }
          if(serial!==paramImportMetaRequestSerial || !popup.classList.contains('open')) return;
          paramImportRenderMetadata(data,item);
          paramImportMetaPosition(paramImportMetaLastPointer.x,paramImportMetaLastPointer.y);
        }catch(error){
          if(serial!==paramImportMetaRequestSerial) return;
          paramImportRenderMetadata({available:false,message:'Metadata lookup failed: '+error.message},item);
          paramImportMetaPosition(paramImportMetaLastPointer.x,paramImportMetaLastPointer.y);
        }
      }

      function paramImportMetaSchedule(item,event){
        clearTimeout(paramImportMetaHoverTimer);
        paramImportMetaLastPointer={x:event.clientX,y:event.clientY};
        paramImportMetaHoverTimer=setTimeout(()=>paramImportMetaShowNow(item,event),220);
      }

      function paramImportMetaMove(event){
        paramImportMetaLastPointer={x:event.clientX,y:event.clientY};
        const popup=document.getElementById('paramImportMetaPopup');
        if(popup && popup.classList.contains('open')) paramImportMetaPosition(event.clientX,event.clientY);
      }

      function paramImportOpen(){
        const overlay=document.getElementById('paramImportOverlay');
        if(overlay){ overlay.classList.add('open'); overlay.setAttribute('aria-hidden','false'); }
      }

      function paramImportClose(){
        paramImportMetaHide();
        const state=document.getElementById('paramImportOverlay');
        const cancel=document.getElementById('paramImportCancelBtn');
        if(cancel && cancel.style.display!=='none'){
          alert('The parameter operation is still running. Cancel it or wait for completion.');
          return;
        }
        if(state){ state.classList.remove('open'); state.setAttribute('aria-hidden','true'); }
      }

      function paramImportSetError(message){
        const box=document.getElementById('paramImportError');
        if(!box) return;
        box.textContent=message || '';
        box.style.display=message ? 'block' : 'none';
      }

      function paramImportShowLoading(message){
        paramImportMetaHide();
        paramImportOpen();
        paramImportSetError('');
        document.getElementById('paramImportLoadingText').textContent=message || 'Working...';
        document.getElementById('paramImportLoading').style.display='flex';
        document.getElementById('paramImportPreviewPanel').style.display='none';
        document.getElementById('paramImportProgressPanel').style.display='none';
        document.getElementById('paramImportApplyBtn').style.display='none';
        document.getElementById('paramImportCancelBtn').style.display='none';
        document.getElementById('paramImportRollbackBtn').style.display='none';
        document.getElementById('paramImportBackupBtn').style.display='none';
        document.getElementById('paramImportReportBtn').style.display='none';
      }

      async function paramImportFileSelected(input){
        const file=input.files && input.files[0];
        input.value='';
        if(!file) return;
        if(file.size > 2*1024*1024){ alert('Parameter file is larger than 2 MB.'); return; }
        paramImportShowLoading('Reading file and comparing it with the connected flight controller...');
        try{
          const content=await file.text();
          const response=await fetch('/param_import_preview',{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({filename:file.name,content:content}),
            cache:'no-store'
          });
          const result=await response.json();
          if(!response.ok || !result.ok) throw new Error(result.error || ('HTTP '+response.status));
          paramImportPreview=result;
          paramImportSessionId=result.session_id;
          paramImportRenderPreview(result);
        }catch(error){
          document.getElementById('paramImportLoading').style.display='none';
          paramImportSetError('Parameter-file preview failed: '+error.message);
        }
      }

      function paramImportSummaryItem(label,value){
        const box=document.createElement('div');
        box.className='paramImportSummaryItem';
        const strong=document.createElement('strong'); strong.textContent=String(value);
        const text=document.createElement('span'); text.className='small'; text.textContent=label;
        box.append(strong,text); return box;
      }

      function paramImportRenderPreview(result){
        document.getElementById('paramImportLoading').style.display='none';
        const panel=document.getElementById('paramImportPreviewPanel');
        panel.style.display='flex';
        document.getElementById('paramImportSubtitle').textContent=result.filename;
        const summary=document.getElementById('paramImportSummary');
        summary.replaceChildren(
          paramImportSummaryItem('Changed',result.summary.changed),
          paramImportSummaryItem('Already match',result.summary.same),
          paramImportSummaryItem('Unsupported',result.summary.unsupported),
          paramImportSummaryItem('Duplicate',result.summary.duplicates),
          paramImportSummaryItem('Invalid lines',result.summary.invalid_lines),
          paramImportSummaryItem('Critical changes',result.summary.critical_changes)
        );
        const safety=document.getElementById('paramImportSafety');
        const messages=[];
        if(result.summary.flap_conflicts){
          messages.push(result.summary.flap_conflicts+' imported SERVOx_FUNCTION change(s) conflict with the servo outputs currently configured for Pi flap control. They are unselected by default.');
        }
        if(result.summary.critical_changes){
          messages.push('Critical flight-control or hardware parameters are present. Type IMPORT when applying them.');
        }
        safety.textContent=messages.join(' ');
        safety.style.display=messages.length ? 'block' : 'none';
        const body=document.getElementById('paramImportRows');
        body.replaceChildren();
        (result.entries || []).forEach(item=>{
          const row=document.createElement('tr');
          row.dataset.status=item.status;
          row.dataset.warning=(item.warning || item.critical || item.flap_conflict) ? '1':'0';
          row.dataset.name=item.name;
          row.dataset.critical=item.critical ? '1':'0';
          const apply=document.createElement('td');
          const check=document.createElement('input');
          check.type='checkbox'; check.className='paramImportCheck'; check.value=item.name;
          check.checked=!!item.selected; check.disabled=item.status!=='changed';
          check.addEventListener('change',paramImportUpdateSelectedCount);
          apply.appendChild(check);
          const name=document.createElement('td');
          name.textContent=item.name;
          name.className='paramImportMetaParamName';
          name.title='Hover to show ArduPilot parameter metadata';
          row.classList.add('paramImportMetaRow');
          row.tabIndex=0;
          row.addEventListener('mouseenter',event=>paramImportMetaSchedule(item,event));
          row.addEventListener('mousemove',paramImportMetaMove);
          row.addEventListener('mouseleave',paramImportMetaHide);
          row.addEventListener('focus',()=>{
            const rect=row.getBoundingClientRect();
            paramImportMetaSchedule(item,{clientX:Math.min(rect.right,window.innerWidth-20),clientY:Math.min(rect.top+24,window.innerHeight-20)});
          });
          row.addEventListener('blur',paramImportMetaHide);
          const current=document.createElement('td'); current.textContent=item.current===null || item.current===undefined ? '—':String(item.current);
          const imported=document.createElement('td'); imported.textContent=String(item.imported);
          const status=document.createElement('td');
          const pill=document.createElement('span'); pill.className='paramImportStatus '+item.status; pill.textContent=item.status; status.appendChild(pill);
          const warning=document.createElement('td'); warning.className='paramImportWarning'; warning.textContent=item.warning || '';
          row.append(apply,name,current,imported,status,warning);
          body.appendChild(row);
        });
        document.getElementById('paramImportFilter').value='changed';
        document.getElementById('paramImportSelectAll').checked=true;
        document.getElementById('paramImportApplyBtn').style.display='inline-block';
        document.getElementById('paramImportCloseBtn').style.display='inline-block';
        paramImportApplyFilter();
        paramImportUpdateSelectedCount();
      }

      function paramImportApplyFilter(){
        const filter=document.getElementById('paramImportFilter').value;
        document.querySelectorAll('#paramImportRows tr').forEach(row=>{
          let show=true;
          if(filter==='changed') show=row.dataset.status==='changed';
          if(filter==='warnings') show=row.dataset.warning==='1';
          row.style.display=show ? 'table-row':'none';
        });
      }

      function paramImportToggleAll(checked){
        document.querySelectorAll('.paramImportCheck:not(:disabled)').forEach(box=>{ box.checked=checked; });
        paramImportUpdateSelectedCount();
      }

      function paramImportUpdateSelectedCount(){
        const selected=[...document.querySelectorAll('.paramImportCheck:checked:not(:disabled)')];
        document.getElementById('paramImportSelectedCount').textContent=selected.length+' selected';
        document.getElementById('paramImportApplyBtn').textContent='Apply '+selected.length+' parameter'+(selected.length===1?'':'s');
      }

      async function paramImportApply(){
        const selected=[...document.querySelectorAll('.paramImportCheck:checked:not(:disabled)')];
        if(!selected.length){ alert('Select at least one changed parameter.'); return; }
        const critical=selected.some(box=>box.closest('tr').dataset.critical==='1');
        let confirmation='';
        if(critical){
          confirmation=window.prompt('Critical flight-control or hardware parameters are selected. Type IMPORT to continue:') || '';
          if(confirmation!=='IMPORT') return;
        }
        if(!confirm('Apply '+selected.length+' selected parameter changes to the connected flight controller?')) return;
        paramImportShowProgress('Starting parameter import...');
        try{
          const response=await fetch('/param_import_apply',{
            method:'POST',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({session_id:paramImportSessionId,parameters:selected.map(box=>box.value),confirmation:confirmation}),
            cache:'no-store'
          });
          const result=await response.json();
          if(!response.ok || !result.ok) throw new Error(result.error || ('HTTP '+response.status));
          paramImportStartPolling();
        }catch(error){
          paramImportSetError('Unable to start import: '+error.message);
          document.getElementById('paramImportCancelBtn').style.display='none';
        }
      }

      function paramImportShowProgress(message){
        paramImportOpen(); paramImportSetError('');
        document.getElementById('paramImportLoading').style.display='none';
        document.getElementById('paramImportPreviewPanel').style.display='none';
        document.getElementById('paramImportProgressPanel').style.display='block';
        document.getElementById('paramImportRunMessage').textContent=message || '';
        document.getElementById('paramImportApplyBtn').style.display='none';
        document.getElementById('paramImportCancelBtn').style.display='inline-block';
        document.getElementById('paramImportCloseTop').style.display='none';
        document.getElementById('paramImportCloseBtn').style.display='none';
      }

      function paramImportStartPolling(){
        if(paramImportStatusTimer) clearInterval(paramImportStatusTimer);
        paramImportStatusTimer=setInterval(paramImportPollStatus,700);
        paramImportPollStatus();
      }

      async function paramImportPollStatus(){
        try{
          const response=await fetch('/param_import_status?ts='+Date.now(),{cache:'no-store'});
          const state=await response.json();
          if(!state.ok) return;
          if(state.session_id) paramImportSessionId=state.session_id;
          if(state.running || ['applying','rolling_back','complete','failed','cancelled','rolled_back'].includes(state.status)){
            paramImportShowProgress(state.message || state.status);
            const pct=Math.max(0,Math.min(100,Number(state.progress)||0));
            document.getElementById('paramImportProgressBar').style.width=pct+'%';
            document.getElementById('paramImportProgressPercent').textContent=pct.toFixed(1)+'%';
            document.getElementById('paramImportProgressText').textContent=(state.verified||0)+' of '+(state.total||0)+' verified';
            document.getElementById('paramImportCurrentParam').textContent=state.current_parameter ? 'Current parameter: '+state.current_parameter : '';
            document.getElementById('paramImportRunMessage').textContent=state.message || '';
            document.getElementById('paramImportRunTitle').textContent=state.operation==='rollback' ? 'Restoring parameters':'Applying parameters';
            const log=document.getElementById('paramImportEventLog');
            log.replaceChildren();
            (state.events || []).forEach(event=>{
              const line=document.createElement('div'); line.className='paramImportEventLine '+(event.level||'info'); line.textContent=(event.level==='ok'?'✓ ':event.level==='error'?'✕ ':event.level==='warning'?'⚠ ':'→ ')+(event.text||''); log.appendChild(line);
            });
            log.scrollTop=log.scrollHeight;
            const running=!!state.running;
            document.getElementById('paramImportCancelBtn').style.display=running ? 'inline-block':'none';
            document.getElementById('paramImportCloseTop').style.display=running ? 'none':'inline-block';
            document.getElementById('paramImportCloseBtn').style.display=running ? 'none':'inline-block';
            document.getElementById('paramImportRunSpinner').style.display=running ? 'inline-block':'none';
            if(!running){
              if(paramImportStatusTimer){ clearInterval(paramImportStatusTimer); paramImportStatusTimer=null; }
              const sid=encodeURIComponent(paramImportSessionId);
              if(state.backup_file){ const b=document.getElementById('paramImportBackupBtn'); b.href='/param_import_backup?session_id='+sid; b.style.display='inline-block'; }
              const r=document.getElementById('paramImportReportBtn'); r.href='/param_import_report?session_id='+sid; r.style.display='inline-block';
              document.getElementById('paramImportRollbackBtn').style.display=state.can_rollback ? 'inline-block':'none';
              if(state.status==='complete' || state.status==='rolled_back'){
                document.getElementById('paramImportRunTitle').textContent=state.status==='rolled_back' ? 'Rollback complete':'Parameter import complete';
              }else if(state.error){ paramImportSetError(state.error); }
            }
          }
        }catch(error){ console.log('paramImportPollStatus failed',error); }
      }

      async function paramImportCancelJob(){
        if(!confirm('Cancel after the current parameter write finishes?')) return;
        await fetch('/param_import_cancel',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
      }

      async function paramImportRollback(){
        const confirmation=window.prompt('Restore all verified changes from the pre-import backup? Type RESTORE to continue:') || '';
        if(confirmation!=='RESTORE') return;
        paramImportShowProgress('Starting rollback...');
        try{
          const response=await fetch('/param_import_rollback',{
            method:'POST',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({session_id:paramImportSessionId,confirmation:confirmation})
          });
          const result=await response.json();
          if(!response.ok || !result.ok) throw new Error(result.error || ('HTTP '+response.status));
          paramImportStartPolling();
        }catch(error){ paramImportSetError('Unable to start rollback: '+error.message); }
      }

      document.addEventListener('DOMContentLoaded',()=>{
        fetch('/param_import_status?ts='+Date.now(),{cache:'no-store'})
          .then(response=>response.json())
          .then(state=>{ if(state && state.ok && state.running){ paramImportSessionId=state.session_id||''; paramImportStartPolling(); } })
          .catch(()=>{});
      });
      // === ARDUPLANE PARAMETER IMPORT V1 END ===

    </script>
    """

    return page("ArduPlane Parameters", body)

def page(title, body):
    initial_upgrade_state = json.dumps(software_update_status_payload(), ensure_ascii=False)
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>{title}</title>
<style>
body{{margin:0;background:#0f172a;color:#e5e7eb;font-family:Arial}}
header{{background:#020617;padding:10px 20px;font-size:22px;font-weight:bold;border-bottom:1px solid #334155;position:fixed;top:0;left:0;right:0;z-index:2;height:36px}}
nav{{width:180px;background:#020617;height:calc(100vh - 58px);position:fixed;left:0;top:58px;padding:15px;border-right:1px solid #334155;overflow-y:auto}}
nav a{{display:block;color:#cbd5e1;text-decoration:none;padding:11px;border-radius:8px;margin-bottom:4px}}
nav a:hover{{background:#1f2937;color:white}}
main{{margin-left:210px;padding:82px 24px 24px 24px}}
.card{{background:#111827;border:1px solid #334155;border-radius:12px;padding:16px;margin-bottom:16px}}
.grid{{display:grid;grid-template-columns:repeat(2,minmax(220px,1fr));gap:12px}}
table{{border-collapse:collapse;width:100%;font-size:14px}}
td,th{{border-bottom:1px solid #334155;padding:8px;text-align:left;vertical-align:top}}
input,select,textarea{{background:#020617;color:#e5e7eb;border:1px solid #334155;border-radius:6px;padding:7px;width:100%}}
button{{background:#2563eb;color:white;border:0;border-radius:8px;padding:9px 13px;margin:4px;cursor:pointer}}
button.danger{{background:#991b1b}}
pre{{background:#020617;border:1px solid #334155;border-radius:8px;padding:12px;overflow:auto;white-space:pre-wrap}}
.ok{{color:#22c55e}} .bad{{color:#ef4444}} .small{{font-size:13px;color:#94a3b8}}
.pill{{padding:3px 8px;border-radius:999px;font-size:12px;margin-left:8px}}
.pill.active{{background:#14532d;color:#86efac}}
.pill.inactive{{background:#334155;color:#cbd5e1}}
.ssidcard{{border:1px solid #334155;border-radius:10px;padding:14px;margin-bottom:12px;background:#0b1220}}
.ssidtop{{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}}
.ssidtitle{{font-size:18px;font-weight:bold;margin-bottom:6px}}
.ssidmeta{{color:#94a3b8;font-size:13px;line-height:1.5}}
.ssidfacts{{display:flex;gap:18px;margin-top:10px}}
.ssidcontrols{{margin-top:12px;border-top:1px solid #334155;padding-top:10px}}
.inlineform{{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:6px 0}}
.smallinput{{width:80px}}
.smallselect{{width:120px}}
.switchbtn{{background:#16a34a}}
.readonlybox{{color:#94a3b8}}

.statusdotimg{{width:14px;height:14px;margin-left:12px;vertical-align:middle}}
.statuslabel{{font-size:13px;color:#94a3b8;margin-left:6px;font-weight:normal}}

.statusdot{{display:inline-block;width:13px;height:13px;border-radius:50%;background:#ef4444;margin-left:12px;vertical-align:middle;box-shadow:0 0 8px #ef4444}}
.statusdot.ok{{background:#22c55e;box-shadow:0 0 8px #22c55e}}
.statuslabel{{font-size:13px;color:#94a3b8;margin-left:6px;font-weight:normal}}


#top-status-bar{{display:inline-flex;gap:6px;align-items:center;white-space:nowrap}}
.status-pill{{font-size:13px;font-weight:bold;padding:5px 10px;border-radius:999px;color:white;margin-left:6px}}
.status-pill.ok{{background:#166534;color:white}}
.status-pill.bad{{background:#991b1b;color:white}}
.status-pill.warn{{background:#92400e;color:white}}


/* SOFTWARE_UPDATE_MODAL_V1 */
body.siyi-upgrade-locked{{overflow:hidden}}
#siyiUpgradeOverlay{{
  display:none;position:fixed;inset:0;z-index:1000000;
  background:rgba(2,6,23,.88);backdrop-filter:blur(5px);
  align-items:center;justify-content:center;padding:24px;box-sizing:border-box;
}}
#siyiUpgradeOverlay.visible{{display:flex}}
#siyiUpgradeDialog{{
  width:min(920px,94vw);height:min(720px,90vh);box-sizing:border-box;
  background:#0b1220;border:1px solid #475569;border-radius:16px;
  box-shadow:0 24px 80px rgba(0,0,0,.65);padding:22px;
  display:flex;flex-direction:column;gap:14px;
}}
.siyi-upgrade-title-row{{display:flex;align-items:center;justify-content:space-between;gap:16px}}
.siyi-upgrade-title{{font-size:25px;font-weight:800}}
.siyi-upgrade-version{{font-size:14px;color:#94a3b8}}
.siyi-upgrade-running-row{{display:flex;align-items:center;gap:12px;font-size:18px;font-weight:700}}
.siyi-upgrade-spinner{{
  width:28px;height:28px;border:4px solid #334155;border-top-color:#60a5fa;
  border-radius:50%;animation:siyiUpgradeSpin .8s linear infinite;flex:0 0 auto;
}}
@keyframes siyiUpgradeSpin{{to{{transform:rotate(360deg)}}}}
.siyi-upgrade-result-icon{{display:none;font-size:30px;font-weight:900;line-height:1}}
.siyi-upgrade-result-icon.ok{{color:#22c55e}}
.siyi-upgrade-result-icon.bad{{color:#ef4444}}
.siyi-upgrade-progress-shell{{height:18px;border-radius:999px;background:#1e293b;overflow:hidden;border:1px solid #334155}}
.siyi-upgrade-progress-bar{{
  height:100%;width:0%;background:#2563eb;transition:width .45s ease;
  position:relative;overflow:hidden;
}}
.siyi-upgrade-progress-bar.running::after{{
  content:'';position:absolute;inset:0;
  background:linear-gradient(110deg,transparent 0%,rgba(255,255,255,.25) 45%,transparent 70%);
  transform:translateX(-100%);animation:siyiUpgradeSweep 1.2s linear infinite;
}}
@keyframes siyiUpgradeSweep{{to{{transform:translateX(100%)}}}}
.siyi-upgrade-stage{{font-size:16px;font-weight:700;color:#e2e8f0}}
.siyi-upgrade-meta{{display:flex;justify-content:space-between;gap:12px;color:#94a3b8;font-size:13px}}
#siyiUpgradeLog{{
  flex:1;min-height:250px;margin:0;background:#020617;border:1px solid #334155;
  border-radius:10px;padding:14px;overflow:auto;white-space:pre-wrap;
  font:14px/1.55 ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;
}}
.siyi-upgrade-warning{{color:#fbbf24;font-size:14px;font-weight:700}}
.siyi-upgrade-actions{{display:none;gap:10px;justify-content:flex-end;align-items:center}}
.siyi-upgrade-actions.visible{{display:flex}}
.siyi-upgrade-detail{{display:none;border-top:1px solid #334155;padding-top:10px;color:#94a3b8;font-size:13px}}
.siyi-upgrade-detail.visible{{display:block}}
@media(max-width:700px){{
  #siyiUpgradeOverlay{{padding:8px}}
  #siyiUpgradeDialog{{width:98vw;height:96vh;padding:15px}}
  .siyi-upgrade-title{{font-size:21px}}
}}

</style></head>
<body>
<header>
SIYI Pi Control Center {VERSION}<span id="statusbar" style="display:inline-block;margin-left:14px;vertical-align:middle;"></span>
</header>
<nav>
<a href="/">Operations</a>
{'' if setup_is_complete() else '<a href="/first_setup">Wizard</a>'}
<a href="/wifi">WiFi</a>
<a href="/zerotier">ZeroTier</a>
<a href="/endpoints">Hosts</a>
<a href="/mavlink">MAVLink</a>
<a href="/video">Video</a>
<a href="/buttons">Buttons</a>
<a href="/flaps">Flaps</a>
<a href="/parameters">ArduPlane Parameters</a>
<a href="/camera_controls">Camera</a>
<a href="/camera_sd">Camera SD</a>
<a href="/logs">Diagnostics</a>
<a href="/software_update">Software Update</a>
</nav>
<main>{body}</main>

<div id="siyiUpgradeOverlay" role="dialog" aria-modal="true" aria-labelledby="siyiUpgradeTitle" aria-hidden="true">
  <div id="siyiUpgradeDialog">
    <div class="siyi-upgrade-title-row">
      <div>
        <div id="siyiUpgradeTitle" class="siyi-upgrade-title">Software update</div>
        <div id="siyiUpgradeVersion" class="siyi-upgrade-version">Preparing upgrade...</div>
      </div>
      <div id="siyiUpgradePercent" style="font-size:22px;font-weight:800;">0%</div>
    </div>

    <div class="siyi-upgrade-running-row">
      <div id="siyiUpgradeSpinner" class="siyi-upgrade-spinner"></div>
      <div id="siyiUpgradeResultOk" class="siyi-upgrade-result-icon ok">✓</div>
      <div id="siyiUpgradeResultBad" class="siyi-upgrade-result-icon bad">✕</div>
      <div id="siyiUpgradeHeadline">Installing</div>
    </div>

    <div class="siyi-upgrade-progress-shell">
      <div id="siyiUpgradeProgressBar" class="siyi-upgrade-progress-bar running"></div>
    </div>

    <div id="siyiUpgradeStage" class="siyi-upgrade-stage">Starting upgrade</div>
    <div class="siyi-upgrade-meta">
      <span id="siyiUpgradeConnection">Connected to WebUI</span>
      <span id="siyiUpgradeStarted"></span>
    </div>

    <pre id="siyiUpgradeLog">Waiting for upgrade status...</pre>

    <div id="siyiUpgradeWarning" class="siyi-upgrade-warning">
      Do not power off the Raspberry Pi during installation.
    </div>

    <div id="siyiUpgradeDetail" class="siyi-upgrade-detail"></div>

    <div id="siyiUpgradeActions" class="siyi-upgrade-actions">
      <button type="button" onclick="siyiUpgradeToggleDetails()">View details</button>
      <button id="siyiUpgradePrimaryAction" type="button" onclick="siyiUpgradeReload()">Reload WebUI</button>
    </div>
  </div>
</div>

<script>
(function(){{
  const initialState = {initial_upgrade_state};
  const overlay = document.getElementById('siyiUpgradeOverlay');
  const dialog = document.getElementById('siyiUpgradeDialog');
  const spinner = document.getElementById('siyiUpgradeSpinner');
  const okIcon = document.getElementById('siyiUpgradeResultOk');
  const badIcon = document.getElementById('siyiUpgradeResultBad');
  const headline = document.getElementById('siyiUpgradeHeadline');
  const version = document.getElementById('siyiUpgradeVersion');
  const percent = document.getElementById('siyiUpgradePercent');
  const bar = document.getElementById('siyiUpgradeProgressBar');
  const stage = document.getElementById('siyiUpgradeStage');
  const log = document.getElementById('siyiUpgradeLog');
  const connection = document.getElementById('siyiUpgradeConnection');
  const started = document.getElementById('siyiUpgradeStarted');
  const warning = document.getElementById('siyiUpgradeWarning');
  const actions = document.getElementById('siyiUpgradeActions');
  const detail = document.getElementById('siyiUpgradeDetail');
  const primaryAction = document.getElementById('siyiUpgradePrimaryAction');
  let lastState = initialState || {{}};
  let sawRunning = sessionStorage.getItem('siyiUpgradeSawRunning') === '1';
  let logWasNearBottom = true;

  function stateToken(s){{
    return String((s && s.updated_at) || '') + '|' + String((s && s.status) || '');
  }}

  function setLocked(locked){{
    document.body.classList.toggle('siyi-upgrade-locked', locked);
    ['header','nav','main','flightModeMenu'].forEach(function(idOrTag){{
      const el = idOrTag === 'header' || idOrTag === 'nav'
        ? document.querySelector(idOrTag)
        : document.getElementById(idOrTag) || document.querySelector(idOrTag);
      if(!el) return;
      if(locked) el.setAttribute('inert','');
      else el.removeAttribute('inert');
    }});
  }}

  function showOverlay(){{
    overlay.classList.add('visible');
    overlay.setAttribute('aria-hidden','false');
    setLocked(true);
  }}

  function hideOverlay(){{
    overlay.classList.remove('visible');
    overlay.setAttribute('aria-hidden','true');
    setLocked(false);
  }}

  function shouldShowTerminal(s){{
    if(!s || (s.status !== 'complete' && s.status !== 'failed')) return false;
    const dismissed = sessionStorage.getItem('siyiUpgradeDismissed');
    return sawRunning && dismissed !== stateToken(s);
  }}

  function applyState(s){{
    if(!s) return;
    lastState = s;
    const running = !!s.running;
    if(running){{
      sawRunning = true;
      sessionStorage.setItem('siyiUpgradeSawRunning','1');
    }}
    const terminal = shouldShowTerminal(s);
    if(!running && !terminal){{
      hideOverlay();
      return;
    }}

    showOverlay();
    const p = Math.max(0, Math.min(100, Number(s.progress || 0)));
    percent.textContent = running ? p.toFixed(1) + '%' : Math.round(p) + '%';
    bar.style.width = p + '%';
    bar.classList.toggle('running', running);
    stage.textContent = s.stage || (running ? 'Installing update' : 'Upgrade finished');
    const fromV = s.from_version || s.current || '';
    const toV = s.to_version || '';
    version.textContent = toV ? ('Updating ' + fromV + ' → ' + toV) : ('Installed version ' + fromV);
    started.textContent = s.started_at ? ('Started ' + s.started_at) : '';

    const nearBottom = (log.scrollHeight - log.scrollTop - log.clientHeight) < 80;
    log.textContent = s.log || 'Waiting for upgrade status...';
    if(logWasNearBottom || nearBottom) log.scrollTop = log.scrollHeight;
    logWasNearBottom = nearBottom;

    spinner.style.display = running ? 'block' : 'none';
    okIcon.style.display = (!running && s.status === 'complete') ? 'block' : 'none';
    badIcon.style.display = (!running && s.status === 'failed') ? 'block' : 'none';
    actions.classList.toggle('visible', !running);

    if(running){{
      headline.textContent = 'Installing';
      warning.textContent = 'Do not power off the Raspberry Pi during installation.';
    }}else if(s.status === 'complete'){{
      headline.textContent = 'Upgrade complete';
      warning.textContent = 'The new release is installed. Continue to the WebUI.';
      primaryAction.textContent = 'Go to WebUI';
    }}else{{
      headline.textContent = 'Upgrade failed';
      warning.textContent = 'The previous configuration was restored when rollback was required.';
      primaryAction.textContent = 'Reload WebUI';
    }}

    const detailParts = [];
    if(s.error) detailParts.push('Error: ' + s.error);
    if(s.technical_log) detailParts.push('Technical log: ' + s.technical_log);
    detail.textContent = detailParts.join('\\n');
    detail.style.display = 'none';
    detail.classList.remove('visible');
  }}

  async function pollUpgradeState(){{
    try{{
      const response = await fetch('/software_update_status?ts=' + Date.now(), {{cache:'no-store'}});
      if(!response.ok) throw new Error('HTTP ' + response.status);
      const state = await response.json();
      connection.textContent = 'Connected to WebUI';
      applyState(state);
    }}catch(error){{
      if(overlay.classList.contains('visible')){{
        connection.textContent = 'Reconnecting to WebUI...';
        if(lastState && lastState.running){{
          stage.textContent = lastState.stage || 'Installation continues in the background';
        }}
      }}
    }}
  }}

  window.siyiUpgradeShowStarting = function(fromVersion, toVersion){{
    sawRunning = true;
    sessionStorage.setItem('siyiUpgradeSawRunning','1');
    applyState({{
      running:true,status:'starting',progress:2,stage:'Starting upgrade',
      from_version:fromVersion || '',to_version:toVersion || '',
      started_at:'',updated_at:'',technical_log:'',error:'',
      log:'[INFO] Starting software update...'
    }});
  }};

  window.siyiUpgradeToggleDetails = function(){{
    detail.classList.toggle('visible');
    detail.style.display = detail.classList.contains('visible') ? 'block' : 'none';
  }};

  window.siyiUpgradeReload = function(){{
    sessionStorage.setItem('siyiUpgradeDismissed', stateToken(lastState));
    sessionStorage.removeItem('siyiUpgradeSawRunning');
    const destination = lastState && lastState.status === 'complete'
      ? '/'
      : '/software_update';
    window.location.replace(destination);
  }};

  document.addEventListener('keydown', function(event){{
    if(overlay.classList.contains('visible') && event.key === 'Escape'){{
      event.preventDefault();
      event.stopPropagation();
    }}
  }}, true);

  applyState(initialState);
  pollUpgradeState();
  setInterval(pollUpgradeState, 1000);
}})();
</script>


<script>
function setPiStatus(ok){{
  var d=document.getElementById('pidot');
  var l=document.getElementById('pilabel');
  if(!d || !l) return;
  if(ok){{
    d.classList.add('ok');
    l.textContent='Pi connected';
  }} else {{
    d.classList.remove('ok');
    l.textContent='Pi disconnected';
  }}
}}
async function checkPi(){{
  try{{
    const r = await fetch('/health?ts=' + Date.now(), {{cache:'no-store'}});
    setPiStatus(r.ok);
  }} catch(e){{
    setPiStatus(false);
  }}
}}
async function refreshStatusBar(){{
  const el = document.getElementById('statusbar');
  try {{
    const r = await fetch('/status_bar?ts=' + Date.now(), {{cache:'no-store'}});
    if(!r.ok) throw new Error('status fetch failed');
    let statusHtml = await r.text();

    try {{

      const prevHtml = window.__siyiLastStatusHtml || '';
      const prevHadOk = prevHtml.includes('MAVLink OK');
      const newHasDown = statusHtml.includes('MAVLink Down');

      if(prevHadOk && newHasDown){{

        window.__siyiMavDownCount =
          (window.__siyiMavDownCount || 0) + 1;

        if(window.__siyiMavDownCount < 3){{
          statusHtml = prevHtml;
        }}

      }} else {{

        window.__siyiMavDownCount = 0;
      }}

      window.__siyiLastStatusHtml = statusHtml;

    }} catch(e){{}}

    const oldModeText =
      window.__siyiLastGoodModeText || 'MODE: ...';

    el.innerHTML =
      statusHtml +
      '<span id="flightModePill" class="status-pill ok" title="Current FC flight mode">' +
      oldModeText +
      '</span>';
    refreshFlightModePill();
  }} catch(e) {{
    el.innerHTML = '<span style="font-size:13px;font-weight:bold;padding:5px 10px;border-radius:999px;color:white;background:#991b1b">Network Lost / Stale</span>';
  }}
}}



async function refreshFlightModePill(){{
  const pill=document.getElementById('flightModePill');
  if(!pill) return;
  try{{
    const r=await fetch('/flight_mode_state?ts=' + Date.now(), {{cache:'no-store'}});
    if(!r.ok) throw new Error('mode fetch failed');
    const j=await r.json();
    const mode=j.mode || 'UNKNOWN';
    pill.textContent='MODE: ' + mode;
    window.__siyiModeFetchFailCount = 0;

    if(mode !== 'UNKNOWN'){{
      window.__siyiLastGoodModeText = 'MODE: ' + mode;
      pill.textContent = window.__siyiLastGoodModeText;
      pill.className='status-pill ok';
      pill.title='Current FC flight mode';
    }}else{{
      pill.textContent = window.__siyiLastGoodModeText || 'MODE: UNKNOWN';
      pill.className='status-pill warn';
      pill.title='No FC flight mode data yet';
    }}
  }}catch(e){{

    window.__siyiModeFetchFailCount =
      (window.__siyiModeFetchFailCount || 0) + 1;

    if(window.__siyiModeFetchFailCount >= 3){{
      pill.textContent = window.__siyiLastGoodModeText || pill.textContent || 'MODE: UNKNOWN';
      pill.className='status-pill warn';
      pill.title='Flight mode update temporarily unavailable';
    }}

  }}
}}

refreshStatusBar();
setInterval(refreshStatusBar,3000);

refreshFlightModePill();
setInterval(refreshFlightModePill,100);

function closeFlightModeMenu(){{
  const m=document.getElementById('flightModeMenu');
  if(m) m.style.display='none';
}}

function openFlightModeMenu(){{
  const pill=document.getElementById('flightModePill');
  const menu=document.getElementById('flightModeMenu');
  if(!pill || !menu) return;
  const r=pill.getBoundingClientRect();
  menu.style.left=(r.left)+'px';
  menu.style.top=(r.bottom + 8)+'px';
  menu.style.display='block';
}}

async function setFlightMode(mode, el){{
  try{{
    if(window.event){{
      window.event.stopPropagation();
    }}
    const r = await fetch(
      '/set_flight_mode?mode=' + encodeURIComponent(mode),
      {{cache:'no-store'}}
    );

    const j = await r.json();

    if(!j.ok && j.error){{
      alert(j.error);
    }}

  }}catch(e){{
    console.log(e);
  }}

  closeFlightModeMenu();
}}

document.addEventListener('click', function(ev){{
  const pill=document.getElementById('flightModePill');
  const menu=document.getElementById('flightModeMenu');
  if(!pill || !menu) return;

  if(pill.contains(ev.target)){{
    ev.stopPropagation();
    if(menu.style.display==='block') closeFlightModeMenu();
    else openFlightModeMenu();
    return;
  }}

  if(!menu.contains(ev.target)) closeFlightModeMenu();
}});

checkPi();
setInterval(checkPi,3000);
</script>

<div id="flightModeMenu" style="
display:none;
position:fixed;
z-index:99999;
background:#1e293b;
border:1px solid #475569;
border-radius:10px;
padding:6px;
min-width:160px;
box-shadow:0 8px 30px rgba(0,0,0,0.45);
color:#e5e7eb;
font-size:13px;
font-weight:700;
">
<div onclick="setFlightMode('MANUAL', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">MANUAL</div>
<div onclick="setFlightMode('FBWA', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">FBWA</div>
<div onclick="setFlightMode('AUTOTUNE', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">AUTOTUNE</div>
<div onclick="setFlightMode('CRUISE', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">CRUISE</div>
<div onclick="setFlightMode('AUTO', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">AUTO</div>
<div onclick="setFlightMode('RTL', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">RTL</div>
<div onclick="setFlightMode('LOITER', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">LOITER</div>
<div onclick="setFlightMode('TAKEOFF', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">TAKEOFF</div>
<div onclick="setFlightMode('QHOVER', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">QHOVER</div>
<div onclick="setFlightMode('QLOITER', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">QLOITER</div>
<div onclick="setFlightMode('QLAND', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">QLAND</div>
<div onclick="setFlightMode('QRTL', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">QRTL</div>
</div>


</body></html>"""


SERVICE_LABELS = {
    "siyi-button-bridge": "Button Control Bridge",
    "siyi-video-source": "Selected Video Source",
    "siyi-video-dual": "Video UDP Forwarder",
    "mavlink-router": "MAVLink Router (FC ↔ Hosts)",
    "zerotier-one": "ZeroTier Network",
    "siyi-rec-proxy": "Camera / Recording Proxy",
    "siyi-rec-redirect": "Camera Control Redirect",
    "siyi-webui": "Web Interface"
}


CAM_SD_BASE="http://"+CAM_IP+":82"
CAM_SD_DIR="100SIYI_VID"
CAM_SD_MEDIA_TYPE=1
UNIGCS_FIFO="/tmp/siyi_record_proxy"
BYTES_PER_SECOND_2K = int(2.5 * 1024 * 1024)
SD_TOTAL_BYTES = 68719476736

def camera_sd_json(url, timeout=5):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="replace"))


def probe_resolution(url):
    try:
        out = subprocess.check_output([
            "ffprobe","-v","error",
            "-select_streams","v:0",
            "-show_entries","stream=width,height",
            "-of","csv=p=0",
            url
        ], timeout=2).decode().strip()
        if out:
            w,h = out.split(",")
            return f"{w}x{h}"
    except Exception:
        pass
    return ""

def camera_sd_files():
    count_url=f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getmediacount?media_type={CAM_SD_MEDIA_TYPE}&path={urllib.parse.quote(CAM_SD_DIR)}"
    count_data=camera_sd_json(count_url)
    count=int(count_data.get("data",{}).get("count",0))
    list_url=f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getmedialist?media_type={CAM_SD_MEDIA_TYPE}&path={urllib.parse.quote(CAM_SD_DIR)}&start=0&count={count}"
    list_data=camera_sd_json(list_url)
    return list_data.get("data",{}).get("list",[])


def camera_sd_head(url, timeout=5):
    try:
        req=urllib.request.Request(url, method="HEAD")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            size=r.headers.get("Content-Length","")
            mod=r.headers.get("Last-Modified","")
            try:
                # SIYI camera now appears to emit local wall-clock timestamps
                # while still labeling HTTP Last-Modified as GMT.
                # Do NOT timezone-convert or new recordings become +2h wrong.
                dt = parsedate_to_datetime(mod)
                mod = dt.strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                pass
            return size, mod
    except Exception:
        return "", ""

def camera_sd_local_date(mod):
    try:
        if not mod:
            return "-"
        dt = parsedate_to_datetime(mod)
        if dt.tzinfo is None:
            return mod
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return mod or "-"

def human_size(n):
    try:
        n=int(n)
        for unit in ["B","KB","MB","GB"]:
            if n < 1024:
                return f"{n:.1f} {unit}" if unit!="B" else f"{n} {unit}"
            n = n / 1024
        return f"{n:.1f} TB"
    except Exception:
        return "-"


def camera_sd_capacity():
    """
    Try to read SD card capacity from SIYI camera API.
    Returns: total_bytes, free_bytes
    If unknown, returns: None, None
    """
    candidates = [
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getsdinfo",
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getmediainfo",
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getstorageinfo",
    ]

    for url in candidates:
        try:
            with urllib.request.urlopen(url, timeout=3) as r:
                raw = r.read().decode(errors="ignore")
                data = json.loads(raw)

            def find_number(obj, keys):
                if isinstance(obj, dict):
                    for k, v in obj.items():
                        lk = str(k).lower()
                        if lk in keys:
                            try:
                                return int(v)
                            except Exception:
                                pass
                        found = find_number(v, keys)
                        if found is not None:
                            return found
                elif isinstance(obj, list):
                    for item in obj:
                        found = find_number(item, keys)
                        if found is not None:
                            return found
                return None

            total = find_number(data, {"total", "totalsize", "total_size", "capacity", "sd_total", "sdtotal"})
            free = find_number(data, {"free", "freesize", "free_size", "available", "avail", "sd_free", "sdfree"})

            if total and free is not None:
                return total, free

        except Exception:
            pass

    return None, None


def camera_sd_page():
    try:
        files=camera_sd_files()

        # SORT: newest -> oldest by SIYI filename
        try:
            files = sorted(files, key=lambda x: x.get("name",""), reverse=True)
        except Exception:
            pass

        # Fast metadata fetch: get file size/date in parallel instead of slow sequential HEAD calls
        meta = {}
        try:
            from concurrent.futures import ThreadPoolExecutor, as_completed
            urls = [x.get("url","") for x in files if x.get("url","")]
            with ThreadPoolExecutor(max_workers=16) as ex:
                futs = {ex.submit(camera_sd_head, u, 1.5): u for u in urls}
                for fut in as_completed(futs):
                    u = futs[fut]
                    try:
                        meta[u] = fut.result()
                    except Exception:
                        meta[u] = ("", "")
        except Exception:
            meta = {}

        rows=""
        total_used = 0
        for idx, f in enumerate(files):
            name=f.get("name","")
            url=f.get("url","")
            size,lastmod = meta.get(url, ("",""))

            res = ""
            label = name

            if size:
                try:
                    total_used += int(size)
                except Exception:
                    pass
            rows+=f"""<tr>
<td><input style='pointer-events:auto;' type="checkbox" class="sdcheck" name="urls" value="{esc(url)}"></td>
<td><b>{esc(label)}</b><br>
<span class='small'>{esc(url)}</span> <span class="sd-res small" data-url="{esc(url)}"></span><br>
<a href="{esc(url)}" target="_blank">Stream / Open</a>
&nbsp;|&nbsp;
<a href="/camera_sd_download?url={urllib.parse.quote(url)}">Download</a>
&nbsp;|&nbsp;
<a class="danger" href="/camera_sd_delete?url={urllib.parse.quote(url)}" onclick="return confirm('Delete this file from camera SD card?');">Delete</a>
</td>
<td>{esc(human_size(size))}</td>
<td>{esc(camera_sd_local_date(lastmod))}</td>
</tr>"""
        total_cap, free_cap = camera_sd_capacity()
        used_str = human_size(total_used)

        if SD_TOTAL_BYTES:
            total_str = human_size(SD_TOTAL_BYTES)
            free_bytes = SD_TOTAL_BYTES - total_used
            free_bytes = max(0, free_bytes)
            free_str = human_size(free_bytes)
            percent = int((total_used / SD_TOTAL_BYTES) * 100)

            # Estimate recording time left (2K)
            try:
                seconds_left = int(free_bytes / BYTES_PER_SECOND_2K)
                hours = seconds_left // 3600
                minutes = (seconds_left % 3600) // 60
                time_str = f"{hours}h {minutes:02d}m"
            except:
                time_str = "unknown"

            sd_summary = f"Used: {used_str} / {total_str} ({percent}%) | Free: {free_str} | Approx {time_str} 2K recording"
        else:
            sd_summary = f"Used: {used_str}"

        return f"""<h1>Camera SD Card</h1>
<span style="font-size:12px;opacity:.65;margin-left:10px;">v{VERSION}</span>
<div class='card' ><h2>Files on Camera SD</h2>
<p class='small'>Directory: {esc(CAM_SD_DIR)} | Count: {len(files)}<br>{esc(sd_summary)}</p>
<form id="sdform" method="post">
<div style="margin-bottom:10px;display:flex;gap:8px;flex-wrap:wrap;">
<button style='pointer-events:auto;' type="button" onclick="document.querySelectorAll('.sdcheck').forEach(c=>c.checked=true)">Select all</button>
<button style='pointer-events:auto;' type="button" onclick="document.querySelectorAll('.sdcheck').forEach(c=>c.checked=false)">Clear selection</button>
<button style='pointer-events:auto;' type="submit" formaction="/camera_sd_zip">Download selected as ZIP</button>
<button style='pointer-events:auto;' class="danger" type="submit" formaction="/camera_sd_delete_selected" onclick="return confirm('Delete all selected files from camera SD card?');">Delete selected</button>
</div>
<table><tr><th>Select</th><th>File</th><th>Size</th><th>Camera Date</th></tr>{rows}</table>
</form>

<script>
(function(){{
  async function loadSdRes(){{
    const spans = Array.from(document.querySelectorAll(".sd-res[data-url]"));
    for (const span of spans){{
      const url = span.dataset.url;
      if (!url) {{
        span.textContent = "-";
        continue;
      }}
      span.textContent = "...";
      try {{
        const r = await fetch("/camera_sd_res?url=" + encodeURIComponent(url), {{cache:"no-store"}});
        const j = await r.json();
        span.textContent = j.res || "-";
      }} catch(e) {{
        span.textContent = "ERR";
      }}
      await new Promise(resolve => setTimeout(resolve, 80));
    }}
  }}

  if (document.readyState === "loading") {{
    document.addEventListener("DOMContentLoaded", function(){{ setTimeout(loadSdRes, 200); }});
  }} else {{
    setTimeout(loadSdRes, 200);
  }}
}})();
</script>

</div>"""
    except Exception as e:
        return f"<h1>Camera SD Card</h1><div class='card'><h2 class='bad'>Could not read camera SD</h2><pre>{esc(str(e))}</pre></div>"


def camera_sd_delete_many(urls):
    data=json.dumps({"media_type":CAM_SD_MEDIA_TYPE,"paths":urls}).encode()
    req=urllib.request.Request(
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/deletemedialist",
        data=data,
        headers={"Content-Type":"application/json","Accept":"application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read().decode("utf-8", errors="replace")

def camera_sd_delete(url):
    data=json.dumps({"media_type":CAM_SD_MEDIA_TYPE,"paths":[url]}).encode()
    req=urllib.request.Request(
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/deletemedialist",
        data=data,
        headers={"Content-Type":"application/json","Accept":"application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=8) as r:
        return r.read().decode("utf-8", errors="replace")


def unigcs_controls_page():
    return """<div class="cam-full"><h1>Camera Controls</h1>\n




<style>/* CAMERA_CONTROLS_COMPACT_SAFE_V3 */
.cam-grid{
  display:grid;
  grid-template-columns: repeat(2, minmax(280px, 1fr));
  gap:12px 14px;
  width:100%;
  max-width:none;
  margin:0;
}
.cam-full{
  width:100%;
  max-width:none;
  margin:0 0 10px 0;
}
.card{
  max-width:none;
  width:100%;
  margin:0;
  padding:10px 12px;
  box-sizing:border-box;
}
.card h2{
  margin:0 0 8px 0;
  font-size:18px;
}
.card form{margin:6px 0;}
.gimbal-row{
  display:flex;
  gap:20px;
  align-items:center;
  flex-wrap:wrap;
}
.gimbal-row label{
  display:flex;
  align-items:center;
  gap:6px;
  white-space:nowrap;
}
.cam-grid .card:nth-child(5) form{
  display:inline-block;
  margin-right:4px;
  white-space:nowrap;
}
.cam-grid .card:nth-child(5) button{
  margin-left:0;
  margin-right:6px;
}
.card button{margin:3px 4px 3px 0;padding:6px 10px;}
.card input[type=range]{width:calc(100% - 55px);max-width:none;}
.image-row{
  display:grid;
  grid-template-columns:90px 1fr 38px;
  gap:8px;
  align-items:center;
  margin:4px 0;
}
.image-row label{
  white-space:nowrap;
  color:#cbd5e1;
}
.image-row input[type=range]{
  width:100%;
  max-width:none;
}

.exposure-row{
  display:grid;
  grid-template-columns:110px 1fr;
  gap:8px;
  align-items:center;
  margin:6px 0;
}
.exposure-row label{
  white-space:nowrap;
  color:#cbd5e1;
}
.exposure-row select{
  width:100%;
}

.image-row output{
  text-align:right;
  color:#e5e7eb;
}

.card output{display:inline-block;width:38px;text-align:right;}
.cam-grid .card:first-child button[type=submit]{display:none;}
@media(max-width:900px){
  .cam-grid{grid-template-columns:1fr;}
}
</style>





<script>
function sendSlider(el){
  const data = new URLSearchParams();
  data.append(el.name, el.value);

  fetch('/unigcs_control', {method:'POST', body:data})
    .then(()=>{ document.getElementById('unigcs_status').innerText='Sent: '+el.value; })
    .catch(()=>{ document.getElementById('unigcs_status').innerText='Failed'; });
}

function sendCmd(cmd){
  const data = new URLSearchParams();
  data.append('cmd', cmd);
  fetch('/unigcs_control', {method:'POST', body:data})
    .then(()=>{ document.getElementById('unigcs_status').innerText='Sent: '+cmd; })
    .catch(()=>{ document.getElementById('unigcs_status').innerText='Failed: '+cmd; });
  return false;
}

function sendForm(form){
  const data = new URLSearchParams(new FormData(form));
  fetch('/unigcs_control', {method:'POST', body:data})
    .then(()=>{ document.getElementById('unigcs_status').innerText='Sent'; })
    .catch(e=>{ document.getElementById('unigcs_status').innerText='Failed'; });
  return false;
}

// UI_ACTIVE_STATE_TRACKER_V1
(function(){
  const groups = {
    stream_720p: "stream_res",
    stream_1080p: "stream_res",
    rec_720p: "rec_res",
    rec_1080p: "rec_res",
    rec_2k: "rec_res",
    rec_4k: "rec_res",
    autorecord_on: "auto_rec",
    autorecord_off: "auto_rec",
    gimbal_lock: "gimbal_mode",
    gimbal_follow: "gimbal_mode",
    gimbal_fpv: "gimbal_mode"
  };

  function restoreRadio(group){
    const cmd = localStorage.getItem("siyi_state_" + group);
    if(!cmd) return;
    document.querySelectorAll('input[type="radio"][name="' + group + '"]').forEach(function(r){
      const onclick = r.getAttribute("onclick") || "";
      if(onclick.indexOf(cmd) >= 0) r.checked = true;
    });
  }

  const oldSendCmd = window.sendCmd;
  window.sendCmd = function(cmd){
    const group = groups[cmd];
    if(group) localStorage.setItem("siyi_state_" + group, cmd);
    return oldSendCmd(cmd);
  };

  function restoreValues(){
    ["brightness","contrast","saturation"].forEach(function(name){
      const val = localStorage.getItem("siyi_value_" + name);
      if(val === null) return;
      const el = document.querySelector('input[type="range"][name="' + name + '"]');
      if(el){
        el.value = val;
        const out = el.parentElement ? el.parentElement.querySelector("output") : null;
        if(out) out.value = val;
      }
    });

    ["ev","ss"].forEach(function(name){
      const val = localStorage.getItem("siyi_value_" + name);
      if(val === null) return;
      const el = document.querySelector('select[name="' + name + '"]');
      if(el) el.value = val;
    });
  }

  const oldSendSlider = window.sendSlider;
  window.sendSlider = function(el){
    if(el && el.name){
      localStorage.setItem("siyi_value_" + el.name, el.value);
    }
    return oldSendSlider(el);
  };

  const oldSendForm = window.sendForm;
  window.sendForm = function(form){
    if(form){
      const field = form.querySelector("select[name], input[name]");
      if(field && field.name){
        localStorage.setItem("siyi_value_" + field.name, field.value);
      }
    }
    return oldSendForm(form);
  };

  document.addEventListener("DOMContentLoaded", function(){
    restoreRadio("stream_res");
    restoreRadio("rec_res");
    restoreRadio("auto_rec");
    restoreRadio("gimbal_mode");
    restoreValues();
  });
})();


// PI_SHARED_STATE_SIDECAR_V1
(function(){
  const STATE_URL = "http://" + window.location.hostname + ":8081/ui_state";

  const groups = {
    stream_720p: "stream_res",
    stream_1080p: "stream_res",
    rec_720p: "rec_res",
    rec_1080p: "rec_res",
    rec_2k: "rec_res",
    rec_4k: "rec_res",
    autorecord_on: "auto_rec",
    autorecord_off: "auto_rec",
    gimbal_lock: "gimbal_mode",
    gimbal_follow: "gimbal_mode",
    gimbal_fpv: "gimbal_mode"
  };

  function postState(obj){
    fetch(STATE_URL, {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(obj)
    }).catch(function(){});
  }

  function applyState(st){
    if(!st) return;

    ["stream_res","rec_res","auto_rec","gimbal_mode"].forEach(function(group){
      const cmd = st[group];
      if(!cmd) return;
      document.querySelectorAll('input[type="radio"][name="' + group + '"]').forEach(function(r){
        const onclick = r.getAttribute("onclick") || "";
        if(onclick.indexOf(cmd) >= 0) r.checked = true;
      });
    });

    ["brightness","contrast","saturation"].forEach(function(name){
      const val = st[name];
      if(val === undefined || val === null) return;
      const el = document.querySelector('input[type="range"][name="' + name + '"]');
      if(el){
        el.value = val;
        const out = el.parentElement ? el.parentElement.querySelector("output") : null;
        if(out) out.value = val;
      }
    });

    ["ev","ss"].forEach(function(name){
      const val = st[name];
      if(val === undefined || val === null) return;
      const el = document.querySelector('select[name="' + name + '"]');
      if(el) el.value = val;
    });
  }

  const prevSendCmd = window.sendCmd;
  window.sendCmd = function(cmd){
    const group = groups[cmd];
    if(group){
      const obj = {};
      obj[group] = cmd;
      postState(obj);
    }
    return prevSendCmd(cmd);
  };

  const prevSendSlider = window.sendSlider;
  window.sendSlider = function(el){
    if(el && el.name){
      const obj = {};
      obj[el.name] = el.value;
      postState(obj);
    }
    return prevSendSlider(el);
  };

  const prevSendForm = window.sendForm;
  window.sendForm = function(form){
    if(form){
      const field = form.querySelector("select[name], input[name]");
      if(field && field.name){
        const obj = {};
        obj[field.name] = field.value;
        postState(obj);
      }
    }
    return prevSendForm(form);
  };

  document.addEventListener("DOMContentLoaded", function(){
    setTimeout(function(){
      fetch(STATE_URL, {cache:"no-store"})
        .then(function(r){ return r.json(); })
        .then(applyState)
        .catch(function(){});
    }, 250);
  });
})();

</script>
<div id="unigcs_status" class="small">Ready</div></div>
<div class="cam-grid">
<div class='card'>
<h2>Image</h2>

<form class="image-row" onsubmit="return false;">
<label>Brightness</label>
<input style='pointer-events:auto;' type="range" onchange="sendSlider(this)" name="brightness" min="0" max="100" value="50" oninput="bval.value=this.value">
<output id="bval">50</output>
</form>

<form class="image-row" onsubmit="return false;">
<label>Contrast</label>
<input style='pointer-events:auto;' type="range" onchange="sendSlider(this)" name="contrast" min="0" max="100" value="50" oninput="cval.value=this.value">
<output id="cval">50</output>
</form>

<form class="image-row" onsubmit="return false;">
<label>Saturation</label>
<input style='pointer-events:auto;' type="range" onchange="sendSlider(this)" name="saturation" min="0" max="100" value="50" oninput="sval.value=this.value">
<output id="sval">50</output>
</form>
</div>

<div class='card'>
<h2>Exposure <span style="color:#9ca3af;font-size:11px;font-style:italic;">(currently unsupported)</span></h2>

<form class="exposure-row" onsubmit="return false;">
<label>EV</label>
<select style='pointer-events:auto;' name="ev" onchange="sendForm(this.form)">
<option value="0">Auto</option>
<option value="1">-2.0</option>
<option value="2">-1.5</option>
<option value="3">-1.0</option>
<option value="4">-0.5</option>
<option value="5">0</option>
<option value="6">+0.5</option>
<option value="7">+1.0</option>
<option value="8">+1.5</option>
<option value="9">+2.0</option>
</select>
</form>

<form class="exposure-row" onsubmit="return false;">
<label>Shutter Speed</label>
<select style='pointer-events:auto;' name="ss" onchange="sendForm(this.form)">
<option value="0">Auto</option>
<option value="1">1/30</option>
<option value="2">1/60</option>
<option value="3">1/120</option>
<option value="4">1/250</option>
<option value="5">1/500</option>
<option value="6">1/1000</option>
<option value="7">1/2000</option>
</select>
</form>
</div>

<div class='card'>
<h2>Stream Resolution</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">720p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="stream_res" onclick="sendCmd('stream_720p')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">1080p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="stream_res" onclick="sendCmd('stream_1080p')"></span>
</form>
</div>

<div class='card'>
<h2>Recording Resolution</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">720p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_720p')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">1080p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_1080p')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">2K <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_2k')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">4K <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_4k')"></span>
</form>
</div>

<div class='card'>
<h2>Gimbal Mode</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">Lock <input style='pointer-events:auto;' style="width:auto;" type="radio" name="gimbal_mode" onclick="sendCmd('gimbal_lock')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">Follow <input style='pointer-events:auto;' style="width:auto;" type="radio" name="gimbal_mode" onclick="sendCmd('gimbal_follow')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">FPV <input style='pointer-events:auto;' style="width:auto;" type="radio" name="gimbal_mode" onclick="sendCmd('gimbal_fpv')"></span>
</form>
</div>

<div class='card'>
<h2>Auto Recording</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">On <input style='pointer-events:auto;' style="width:auto;" type="radio" name="auto_rec" onclick="sendCmd('autorecord_on')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">Off <input style='pointer-events:auto;' style="width:auto;" type="radio" name="auto_rec" onclick="sendCmd('autorecord_off')"></span>
</form>
</div>

</div>
<p class="small cam-full"></p>
"""

def send_unigcs_fifo(command):
    command = (command or "").strip()
    if not command:
        return "No command"

    allowed_prefixes = ("brightness:", "saturation:", "contrast:", "ev:", "ss:")
    allowed_exact = {
        "stream_720p", "stream_1080p",
        "rec_720p", "rec_1080p", "rec_2k", "rec_4k",
        "gimbal_lock", "gimbal_follow", "gimbal_fpv",
        "autorecord_on", "autorecord_off",
        "start", "stop",
    }

    commands = [c.strip() for c in command.split(";") if c.strip()]

    for c in commands:
        if c not in allowed_exact and not c.startswith(allowed_prefixes):
            return "Rejected command: " + c

    import os, errno, time

    try:
        # retry open FIFO safely
        fd = None
        for _ in range(20):
            try:
                fd = os.open(UNIGCS_FIFO, os.O_WRONLY | os.O_NONBLOCK)
                break
            except OSError:
                time.sleep(0.05)
        if fd is None:
            return "FIFO not ready"

        try:
            for c in commands:
                os.write(fd, (c + "\n").encode())
                time.sleep(0.05)
        finally:
            os.close(fd)
    except OSError as e:
        if e.errno == errno.ENXIO:
            return "FIFO has no active reader / SIYI proxy not ready"
        return "FIFO write failed: " + str(e)

    return "Sent UniGCS control: " + command



# ENDPOINTS_SHARED_CONFIG_V1
def load_endpoints():
    defaults = [
        {"name":"Host 1","ip":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","video":True,"mavlink":True},
        {"name":"Host 2","ip":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","video":True,"mavlink":True},
    ]
    try:
        if os.path.exists(ENDPOINTS_FILE):
            data=json.loads(read_file(ENDPOINTS_FILE))
            if isinstance(data,list) and data:
                return data
    except Exception:
        pass
    return defaults

def save_endpoints_from_params(data):
    names=data.get("name",[])
    ips=data.get("ip",[])
    delete_on=set(data.get("delete_host",[]))
    endpoints=[]
    for i,ip in enumerate(ips):
        if str(i) in delete_on:
            continue
        ip=(ip or "").strip()
        if not ip:
            continue
        name=(names[i].strip() if i < len(names) and names[i].strip() else f"Host {i+1}")
        endpoints.append({
            "name": name,
            "ip": ip,
            "video": False,
            "mavlink": True,
        })
    if not endpoints:
        try:
            existing = load_endpoints()
            if existing:
                endpoints = existing
        except Exception:
            pass

    if not endpoints:
        endpoints=[
            {"name":"Host 1","ip":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","video":True,"mavlink":True},
            {"name":"Host 2","ip":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","video":True,"mavlink":True},
        ]
    write_file(ENDPOINTS_FILE, json.dumps(endpoints, indent=2))
    apply_siyi_endpoints_now()
    apply_siyi_endpoints_now()


def host_ping_status(ip):
    if not ip:
        return ("bad", "No IP")

    out=sh(f"ping -c 1 -W 1 {ip} 2>/dev/null || true")

    if "1 received" in out or "1 packets received" in out:
        m=re.search(r"time=([0-9.]+)", out)
        return ("ok", "OK" + (f" {m.group(1)} ms" if m else ""))

    return ("bad", "No ping")

def host_mavlink_status(ip):
    if not ip:
        return ("bad", "No IP")

    conf=read_file(MAVCONF)
    configured=(ip in conf)

    if not configured:
        return ("bad", "Not configured")

    # Real MAVLink activity is tracked by background tcpdump monitor.
    # UI should not run tcpdump during page rendering.
    try:
        data=json.loads(read_file("/tmp/siyi_mavlink_host_activity.json") or "{}")
        item=data.get(ip,{})
        last=float(item.get("last_seen",0))
        age=time.time()-last
        if last > 0 and age < 15:
            return ("ok", "ACTIVE")
        if last > 0:
            return ("warn", "STALE")
    except Exception:
        pass

    return ("ok", "MAVLink endpoint configured")
def host_video_status(ip):
    if not ip:
        return ("bad", "No IP")

    # Current architecture: QGC pulls RTSP from MediaMTX on :8554.
    # A host is video-active if it has an established TCP session to local :8554
    # or recent MediaMTX logs show that host reading main.264.
    ss_out=sh("ss -tunap 2>/dev/null | grep ':8554' || true")
    logs=sh("journalctl -u mediamtx.service -n 160 --no-pager 2>/dev/null || true")

    active_tcp=(ip in ss_out and ":8554" in ss_out and "ESTAB" in ss_out)
    active_log=(ip in logs and ("is reading from path" in logs or "session" in logs))

    if active_tcp:
        return ("ok", "ACTIVE")

    if active_log:
        return ("warn", "RECENT")

    mediamtx=sh("systemctl is-active mediamtx.service 2>/dev/null || true").strip()
    if mediamtx=="active":
        return ("warn", "NO CLIENT")

    return ("bad", "OFFLINE")


def host_qgc_status(ip):
    if not ip:
        return ("bad", "No IP")

    ss_out=sh("ss -tunap 2>/dev/null || true")
    medialog=sh("journalctl -u mediamtx.service -n 180 --no-pager 2>/dev/null || true")

    # Strong QGC confirmation signals:
    # 1) Host has active RTSP TCP session to MediaMTX :8554.
    # 2) Host has REC/control TCP session to :37256.
    # 3) Recent MediaMTX log from host reading stream.
    active_rtsp=(ip in ss_out and ":8554" in ss_out and "ESTAB" in ss_out)
    active_control=(ip in ss_out and ":37256" in ss_out and "ESTAB" in ss_out)
    recent_rtsp=(ip in medialog and ("is reading from path" in medialog or "created by" in medialog))

    if active_rtsp and active_control:
        return ("ok", "VIDEO + CTRL")

    if active_rtsp:
        return ("ok", "VIDEO")

    if active_control:
        return ("ok", "CTRL")

    if recent_rtsp:
        return ("warn", "RECENT")

    return ("warn", "NOT CONFIRMED")


def host_operational_table():
    eps=load_endpoints()

    if not eps:
        return "<p class='small'>No endpoint hosts configured.</p>"

    rows=""

    for e in eps:
        name=e.get("name","")
        ip=e.get("ip","")

        ping_cls,ping_txt=host_ping_status(ip)

        if e.get("mavlink",True):
            mav_cls,mav_txt=host_mavlink_status(ip)
        else:
            mav_cls,mav_txt=("warn","Disabled")

        vid_cls,vid_txt=host_video_status(ip)
        qgc_cls,qgc_txt=host_qgc_status(ip)

        # If host is unreachable on network level,
        # suppress stale/recent subsystem activity states.
        if ping_cls == "bad":
            if mav_txt != "Disabled":
                mav_cls,mav_txt=("bad","HOST OFFLINE")
            vid_cls,vid_txt=("bad","HOST OFFLINE")
            qgc_cls,qgc_txt=("bad","HOST OFFLINE")

        rows += f"""
        <tr>
          <td><b>{esc(name)}</b><br><span class='small'>{esc(ip)}</span></td>
          <td><span class='status-pill {ping_cls}'>{esc(ping_txt)}</span></td>
          <td><span class='status-pill {mav_cls}'>{esc(mav_txt)}</span></td>
          <td><span class='status-pill {vid_cls}'>{esc(vid_txt)}</span></td>
          <td><span class='status-pill {qgc_cls}'>{esc(qgc_txt)}</span></td>
        </tr>
        """

    return f"""
    <style>
    .hoststatus table {{
      width:100%;
      table-layout:auto;
    }}

    .hoststatus td,
    .hoststatus th {{
      vertical-align:middle;
      white-space:nowrap;
    }}

    .hoststatus .status-pill {{
      display:inline-block;
      padding:5px 10px;
      border-radius:999px;
      font-size:12px;
      font-weight:700;
      line-height:1.0;
      white-space:nowrap;
    }}

    .hoststatus th:nth-child(2),
    .hoststatus td:nth-child(2),
    .hoststatus th:nth-child(3),
    .hoststatus td:nth-child(3),
    .hoststatus th:nth-child(4),
    .hoststatus td:nth-child(4) {{
      width:120px;
    }}

    .hoststatus th:nth-child(5),
    .hoststatus td:nth-child(5) {{
      width:150px;
    }}
    </style>

    <div class='hoststatus'>
    <table>
      <tr>
        <th>Host</th>
        <th>Network</th>
        <th>MAVLink</th>
        <th>Video</th>
        <th>QGC</th>
      </tr>
      {rows}
    </table>

    <p class='small'>
    Network = ICMP ping reachability only.<br>
    MAVLink sent = Pi has recently sent UDP telemetry packets to this host on port 14550.<br>
    Video = active/recent RTSP client session from this host via MediaMTX.<br>
    QGC = confirmed only by host-side RTSP/control activity back to the Pi.
    </p></div>
    """


def endpoints_summary(kind):
    eps=load_endpoints()
    rows=""
    for e in eps:
        enabled=e.get(kind,False)
        rows+=f"<tr><td>{esc(e.get('name',''))}</td><td>{esc(e.get('ip',''))}</td><td>{'Yes' if enabled else 'No'}</td></tr>"
    return f"<table><tr><th>Host</th><th>IP</th><th>{kind.capitalize()}</th></tr>{rows}</table><p class='small'>Edit hosts on the Endpoints page.</p>"

def endpoints_page():
    eps=load_endpoints()
    rows=""
    for i,e in enumerate(eps):
        rows+=f"""
        <tr>
          <td><input style='pointer-events:auto;' name='name' value='{esc(e.get("name",f"Host {i+1}"))}'></td>
          <td><input style='pointer-events:auto;' name='ip' value='{esc(e.get("ip",""))}'></td>
          <td style='text-align:center'><input style='pointer-events:auto;width:auto;' type='checkbox' name='delete_host' value='{i}'></td>
        </tr>"""
    rows += """
        <tr>
          <td><input style='pointer-events:auto;' name='name' placeholder='Host 3'></td>
          <td><input style='pointer-events:auto;' name='ip' placeholder='192.168.191.xxx'></td>
          <td></td>
        </tr>"""
    return f"""<h1>MAVLink Hosts</h1>

    <div class='card'>
    <h2>Host Operational Status</h2>
    {host_operational_table()}
    </div>

    <div class='card'>
    <div style='display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;'>
      <p class='small' style='margin:0;'>Saved hosts are automatically used as MAVLink destinations.</p>

      <button id='matrixOpenBtn'
              type='button'
              style='pointer-events:auto;background:#1d4ed8;color:white;border:0;border-radius:10px;padding:8px 14px;font-weight:700;cursor:pointer;'>
        Host status reference
      </button>
    </div>

<div id='matrixFloat'
     class='card'
     style='display:none;position:fixed;right:40px;top:90px;width:900px;min-width:340px;max-width:92vw;max-height:88vh;overflow:auto;z-index:50;box-shadow:0 12px 30px rgba(0,0,0,.45);'>

  <h2 id='matrixDragHandle'
      style='cursor:move;margin-top:0;display:flex;justify-content:space-between;align-items:center;gap:12px;'>

    <span>Host status reference</span>

    <button id='matrixCloseBtn'
            type='button'
            style='pointer-events:auto;background:#334155;color:#e5e7eb;border:0;border-radius:999px;margin:0;padding:2px 8px;font-size:14px;line-height:1.3;cursor:pointer;'>
      ×
    </button>
  </h2>

  <img src='/static/mavlink_qgc_matrix.png'
       style='width:100%;height:auto;border-radius:12px;display:block;'>

  <div id='matrixResizeHandle'
       style='position:absolute;left:0;bottom:0;width:26px;height:26px;cursor:nesw-resize;'></div>
</div>

<script>
(function(){{
  const openBtn=document.getElementById('matrixOpenBtn');
  const box=document.getElementById('matrixFloat');
  const handle=document.getElementById('matrixDragHandle');
  const closeBtn=document.getElementById('matrixCloseBtn');
  const resize=document.getElementById('matrixResizeHandle');

  if(!openBtn || !box || !handle || !resize) return;

  openBtn.addEventListener('click', function(){{
    box.style.display='block';
  }});

  if(closeBtn){{
    closeBtn.addEventListener('mousedown', function(e){{
      e.stopPropagation();
    }});

    closeBtn.addEventListener('click', function(e){{
      e.preventDefault();
      e.stopPropagation();
      box.style.display='none';
    }});
  }}

  let dragging=false;
  let startX=0;
  let startY=0;
  let startLeft=0;
  let startTop=0;

  handle.addEventListener('mousedown', function(e){{
    dragging=true;

    const r=box.getBoundingClientRect();

    startX=e.clientX;
    startY=e.clientY;
    startLeft=r.left;
    startTop=r.top;

    box.style.left=r.left+'px';
    box.style.top=r.top+'px';
    box.style.right='auto';

    e.preventDefault();
  }});

  document.addEventListener('mousemove', function(e){{
    if(!dragging) return;

    box.style.left=(startLeft + (e.clientX-startX))+'px';
    box.style.top=(startTop + (e.clientY-startY))+'px';
  }});

  document.addEventListener('mouseup', function(){{
    dragging=false;
    resizing=false;
  }});

  let resizing=false;
  let startWidth=0;
  let startHeight=0;
  let resizeStartX=0;
  let resizeStartY=0;
  let resizeStartLeft=0;

  resize.addEventListener('mousedown', function(e){{
    resizing=true;

    const r=box.getBoundingClientRect();

    startWidth=r.width;
    startHeight=r.height;
    resizeStartX=e.clientX;
    resizeStartY=e.clientY;
    resizeStartLeft=r.left;

    e.preventDefault();
    e.stopPropagation();
  }});

  document.addEventListener('mousemove', function(e){{
    if(!resizing) return;

    let rightEdge=resizeStartLeft + startWidth;

    let newWidth=rightEdge - e.clientX;
    let newHeight=startHeight + (e.clientY-resizeStartY);

    newWidth=Math.max(340,newWidth);
    newHeight=Math.max(260,newHeight);

    box.style.width=newWidth+'px';
    box.style.height=newHeight+'px';
  }});
}})();
</script>


    <form method='post' action='/save_endpoints'>
    <table><tr><th>Preset</th><th>IP</th><th>Delete</th></tr>{rows}</table>
    <button style='pointer-events:auto;'>Save endpoints</button>
    </form>
    </div>"""

def make_video_service_from_endpoints(rtsp, protocols, latency, port):
    eps=[e for e in load_endpoints() if e.get("video",False) and e.get("ip")]
    if not eps:
        eps=[{"ip":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+""},{"ip":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+""}]
    branches=" ".join([f"t. ! queue ! udpsink host={e['ip']} port={port}" for e in eps])
    return f"""[Unit]
Description=SIYI RTSP to UDP forwarder
After=network-online.target zerotier-one.service NetworkManager.service
Wants=network-online.target zerotier-one.service

[Service]
Type=simple
Restart=always
RestartSec=3
ExecStart=/usr/bin/gst-launch-1.0 -e rtspsrc location={rtsp} latency={latency} protocols={protocols} ! rtph265depay ! h265parse ! rtph265pay config-interval=1 pt=96 ! tee name=t {branches}
ExecStop=/usr/bin/pkill -f "gst-launch-1.0"
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
"""

def make_mav_conf_from_endpoints(device, baud, port, tcp):
    eps=[e for e in load_endpoints() if e.get("ip")]

    lines=[f"""[UartEndpoint fc]
Device={device}
Baud={baud}

[UdpEndpoint webui_status_monitor]
Mode=Normal
Address=127.0.0.1
Port=14601

[UdpEndpoint button_safety]
Mode=Normal
Address=127.0.0.1
Port=14600
"""]

    for i,e in enumerate(eps,1):
        lines.append(f"""
[UdpEndpoint host{i}]
Mode=Normal
Address={e['ip']}
Port={port}
""")

    lines.append(f"""
[TcpEndpoint server]
Mode=Server
Address=0.0.0.0
Port={tcp}
""")

    return "".join(lines)

# ENDPOINTS_SHARED_CONFIG_V1_END



def apply_siyi_endpoints_now():
    try:
        subprocess.run(["/home/pi/apply_siyi_endpoints.sh"], timeout=10, check=False)
    except Exception as e:
        print("apply_siyi_endpoints failed:", e)


def fc_parameter_export_handler(self):
    import json, time, subprocess
    from pathlib import Path

    cache_path = Path("/etc/siyi/param_metadata_cache.json")
    fresh_snapshot_path = Path("/tmp/siyi_param_cache.json")
    refresh_script = "/home/pi/siyi_param_full_cache.py"
    log_path = Path("/tmp/fc_parameter_export.log")

    try:
        with open(log_path, "w") as log:
            rc = subprocess.run(
                ["/home/pi/siyi-bridge-venv/bin/python", refresh_script],
                stdout=log,
                stderr=subprocess.STDOUT,
                timeout=180
            ).returncode

        if rc != 0:
            try:
                tail = log_path.read_text(errors="ignore")[-1500:]
            except Exception:
                tail = "unknown error"
            body = ("FC Parameter Export failed: could not synchronize parameters from FC.\n\n" + tail).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if not cache_path.exists():
            body = b"FC Parameter Export failed: parameter cache was not created."
            self.send_response(500)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        # Truth source for export is the fresh full FC snapshot just collected by refresh_script.
        # The WebUI/cache is not the authority for export values.
        data = json.loads(fresh_snapshot_path.read_text())
        params = data.get("params", {})
        expected = int(data.get("expected_count", 0) or 0)
        received = int(data.get("received_count", 0) or 0)

        if not params or expected <= 0 or received <= 0 or expected != received or len(params) != received:
            body = (
                "FC Parameter Export refused: fresh FC parameter snapshot is incomplete.\n"
                f"expected_count={expected}, received_count={received}, params={len(params)}\n"
            ).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        def fmt_value(v):
            try:
                f = float(v)
                if f.is_integer():
                    return str(int(f))
                return ("%.10g" % f)
            except Exception:
                return str(v)

        lines = [
            "# Onboard parameters for Vehicle 1",
            "#",
            "# Stack: ArduPilot",
            "# Vehicle: Fixed wing aircraft",
            "# Version: 4.5.7",
            "# Git Revision: exported-by-siyi-pi",
            "#",
            "# Vehicle-Id Component-Id Name Value Type",
        ]

        def sort_key(item):
            name, info = item
            try:
                return (int(info.get("index", 999999)), name)
            except Exception:
                return (999999, name)

        # Export values directly from the fresh FC snapshot.
        # No WebUI state, no stale metadata value cache, no per-param /get loop.
        for name, info in sorted(params.items(), key=sort_key):
            val = fmt_value(info.get("value", 0))
            ptype = int(info.get("type", 9) or 9)
            lines.append(f"1\t1\t{name}\t{val}\t{ptype}")

        body = ("\n".join(lines) + "\n").encode("utf-8")
        filename = "fc_parameters_" + time.strftime("%Y%m%d_%H%M%S") + ".params"

        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Set-Cookie", "fc_export_done=1; Path=/; Max-Age=20; SameSite=Lax")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    except subprocess.TimeoutExpired:
        body = b"FC Parameter Export failed: FC parameter synchronization timed out."
        self.send_response(504)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    except Exception as e:
        body = ("FC Parameter Export failed: " + repr(e)).encode("utf-8")
        self.send_response(500)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class H(BaseHTTPRequestHandler):

    def do_POST(self):
        # CPU_TEMP_VOICE_PAGE_V1
        if self.path.startswith("/cpu_temp_voice_save"):
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                raw = self.rfile.read(length).decode()
                data = dict(urllib.parse.parse_qsl(raw))

                enabled = data.get("enabled", "") == "1"
                try:
                    interval = float(str(data.get("interval", "5")).replace(",", "."))
                except Exception:
                    interval = 5

                if interval <= 0:
                    enabled = False
                    interval = 5

                if enabled and interval < 0.25:
                    raise ValueError("Minimum enabled interval is 0.25 minutes")

                cfg = {"enabled": enabled, "interval_minutes": interval}
                cfg_path = "/etc/siyi/cpu_temp_voice.json"

                print("[CPU_TEMP_SAVE] writing cfg=%r path=%s" % (cfg, cfg_path), flush=True)

                with open(cfg_path, "w") as f:
                    json.dump(cfg, f)

                print("[CPU_TEMP_SAVE] write complete", flush=True)

                try:
                    with open(cfg_path, "r") as f:
                        verify = f.read()
                    print("[CPU_TEMP_SAVE] verify=%s" % verify, flush=True)
                except Exception as e:
                    print("[CPU_TEMP_SAVE] verify failed: %s" % e, flush=True)

                self.send_response(303)
                self.send_header("Location", "/cpu_temp_voice")
                self.end_headers()
                return

            except Exception as e:
                self.send_error(400, str(e))
                return

        length = int(self.headers.get("Content-Length", 0))
        data = self.rfile.read(length).decode()
        params = dict(parse_qsl(data))

        if self.path == "/unigcs_control":
            cmd = params.get("cmd", "")
            send_unigcs_fifo(cmd)
            self.send_response(303)
            self.send_header("Location", "/camera_controls")
            self.end_headers()
            return

    def do_GET(self):

        request_path = urllib.parse.urlparse(self.path).path
        upgrade_allowed_paths = {
            "/software_update_status",
            "/health",
        }
        if (
            software_update_lock_active()
            and request_path not in upgrade_allowed_paths
            and not request_path.startswith("/static/")
        ):
            body = """
            <h1>Software update in progress</h1>
            <div class='card'>
              <p>The WebUI is locked until the software update finishes.</p>
              <p class='small'>Installation progress is shown in the update dialog.</p>
            </div>
            """
            payload = page("Software update in progress", body).encode("utf-8")
            self.send_response(423)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if self.path.startswith("/static/"):
            path = "/home/pi/siyi-webui" + self.path

            if not os.path.isfile(path):
                self.send_error(404)
                return

            ctype = "application/octet-stream"

            if path.endswith(".png"):
                ctype = "image/png"
            elif path.endswith(".jpg") or path.endswith(".jpeg"):
                ctype = "image/jpeg"

            with open(path, "rb") as f:
                data = f.read()

            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/video_source_status"):
            payload = video_source_read_status()
            payload["configured_source"] = video_source_read_config().get("source", "siyi_rtsp")
            send_json_response(self, payload, 200)
            return

        if self.path.startswith("/camera_sd_meta"):
            qs = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(self.path).query))
            url = qs.get("url", "")
            size, mod = camera_sd_head(url, timeout=3)
            data = json.dumps({"size": human_size(size), "date": mod if mod else "-"}).encode()
            self.send_response(200)
            self.send_header("Content-Type","application/json")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/camera_sd_res"):
            qs = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(self.path).query))
            url = qs.get("url","")
            res = ""
            try:
                if url:
                    res = probe_resolution(url)
            except:
                res = ""
            data = json.dumps({"res": res}).encode()
            self.send_response(200)
            self.send_header("Content-Type","application/json")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/camera_sd_stream"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            url = q.get("url", [""])[0]

            if not url.startswith(CAM_SD_BASE + "/"):
                self.send_error(400, "Invalid camera SD URL")
                return

            try:
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=20) as r:
                    self.send_response(200)
                    self.send_header("Content-Type", "video/mp4")
                    self.send_header("Content-Disposition", "inline")
                    self.end_headers()
                    shutil.copyfileobj(r, self.wfile, length=1024*1024)
                return
            except Exception as e:
                self.send_error(502, "Camera SD stream failed: " + str(e))
                return

        if self.path in ("/camera_controls", "/unigcs_controls"):
            body = page("Camera Controls", unigcs_controls_page())
            self.send_response(200)
            self.send_header("Content-Type","text/html")
            self.end_headers()
            self.wfile.write(body.encode())
            return

        if self.path.startswith("/camera_sd_download"):
            qs=dict(urllib.parse.parse_qsl(urllib.parse.urlparse(self.path).query))
            url=qs.get("url","")
            if not url.startswith(CAM_SD_BASE + "/"):
                self.send_error(400, "Invalid camera SD URL"); return
            filename=os.path.basename(urllib.parse.urlparse(url).path) or "camera_file.mp4"
            try:
                with urllib.request.urlopen(url, timeout=10) as r:
                    data=r.read()
                self.send_response(200)
                self.send_header("Content-Type","video/mp4")
                self.send_header("Content-Disposition",f'attachment; filename="{filename}"')
                self.send_header("Content-Length",str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            except Exception as e:
                self.send_error(502, str(e))
            return

        # CPU_TEMP_VOICE_UI_V1
        # CPU_TEMP_VOICE_PAGE_V1
        if self.path.startswith("/cpu_temp_voice") and not self.path.startswith("/cpu_temp_voice_config"):
            cfg_path = "/etc/siyi/cpu_temp_voice.json"

            def read_cpu_temp_voice_cfg():
                try:
                    with open(cfg_path, "r") as f:
                        d = json.load(f)
                except Exception:
                    d = {"enabled": False, "interval_minutes": 5}
                return {
                    "enabled": bool(d.get("enabled", False)),
                    "interval_minutes": float(d.get("interval_minutes", 5) or 5),
                    "battery_enabled": bool(d.get("battery_enabled", False)),
                    "battery_interval_minutes": float(d.get("battery_interval_minutes", 5) or 5),
                    "battery_low_voltage": float(d.get("battery_low_voltage", 10.5) or 10.5),
                }

            cfg = read_cpu_temp_voice_cfg()
            checked = "checked" if cfg["enabled"] else ""
            interval = cfg["interval_minutes"]
            cfg["battery_enabled_checked"] = "checked" if cfg.get("battery_enabled", False) else ""

            body = f"""
            <h1>Voice Alerts</h1>
            <div class='card'>
              <form method='get' action='/cpu_temp_voice_config'>
                <label style='display:block;margin-bottom:12px;'>
                  <input type='checkbox' name='enabled' value='1' {checked} style='width:auto;'>
                  Enable spoken CPU temperature alerts
                </label>

                <label>Interval in minutes</label>
                <input name='interval' value='{interval}' inputmode='decimal' style='max-width:160px;'>

                <hr style='border-color:#334155;margin:18px 0;'>

                <h2>Battery Voltage</h2>
                <label style='display:block;margin-bottom:12px;'>
                  <input type='checkbox' name='battery_enabled' value='1' {cfg.get("battery_enabled_checked","")} style='width:auto;'>
                  Enable spoken battery voltage alerts
                </label>

                <label>Battery voltage interval in minutes</label>
                <input name='battery_interval' value='{cfg.get("battery_interval_minutes",5)}' inputmode='decimal' style='max-width:160px;'>

                <label>Low voltage threshold</label>
                <input name='battery_low_voltage' value='{cfg.get("battery_low_voltage",10.5)}' inputmode='decimal' style='max-width:160px;'>

                <p class='small'>
                  Enter 0 or uncheck Enable to disable each alert. Low-voltage warning is spoken when current voltage is equal to or below the threshold.
                </p>

                <button type='submit'>Save</button>
                <a class='button' href='/' style='margin-left:8px;text-decoration:none;'>Back</a>
              </form>
            </div>
            """

            html_body = page("Voice Alerts", body)
            self.send_response(200)
            self.send_header("Content-Type","text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(html_body.encode())
            return

        if self.path.startswith("/cpu_temp_voice_config"):
            try:
                cfg_path = "/etc/siyi/cpu_temp_voice.json"
                qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)

                def read_cfg():
                    try:
                        with open(cfg_path, "r") as f:
                            d = json.load(f)
                    except Exception:
                        d = {"enabled": False, "interval_minutes": 5}
                    return {
                        "enabled": bool(d.get("enabled", False)),
                        "interval_minutes": float(d.get("interval_minutes", 5) or 5),
                    }

                cfg = read_cfg()

                if "enabled" in qs or "interval" in qs or "battery_enabled" in qs or "battery_interval" in qs or "battery_low_voltage" in qs:
                    enabled = qs.get("enabled", ["1" if cfg["enabled"] else "0"])[0].strip() in ("1","true","yes","on")
                    try:
                        interval = float(qs.get("interval", [str(cfg["interval_minutes"])])[0])
                    except Exception:
                        interval = cfg["interval_minutes"]

                    if interval <= 0:
                        enabled = False
                        interval = cfg["interval_minutes"] if cfg["interval_minutes"] > 0 else 5

                    if enabled and interval < 0.25:
                        raise ValueError("Minimum enabled interval is 0.25 minutes")

                    battery_enabled = qs.get("battery_enabled", ["1" if cfg.get("battery_enabled", False) else "0"])[0].strip() in ("1","true","yes","on")

                    try:
                        battery_interval = float(qs.get("battery_interval", [str(cfg.get("battery_interval_minutes", 5))])[0])
                    except Exception:
                        battery_interval = cfg.get("battery_interval_minutes", 5)

                    try:
                        battery_low_voltage = float(qs.get("battery_low_voltage", [str(cfg.get("battery_low_voltage", 10.5))])[0])
                    except Exception:
                        battery_low_voltage = cfg.get("battery_low_voltage", 10.5)

                    if battery_interval <= 0:
                        battery_enabled = False
                        battery_interval = 5

                    cfg = {
                        "enabled": enabled,
                        "interval_minutes": interval,
                        "battery_enabled": battery_enabled,
                        "battery_interval_minutes": battery_interval,
                        "battery_low_voltage": battery_low_voltage,
                    }
                    tmp = cfg_path + ".tmp"
                    with open(tmp, "w") as f:
                        json.dump(cfg, f)
                    os.replace(tmp, cfg_path)

                if "enabled" in qs or "interval" in qs or "battery_enabled" in qs or "battery_interval" in qs or "battery_low_voltage" in qs:
                    self.send_response(303)
                    self.send_header("Location", "/cpu_temp_voice")
                    self.end_headers()
                    return

                data = json.dumps({"ok": True, **cfg}).encode()
                self.send_response(200)
                self.send_header("Content-Type","application/json")
                self.send_header("Cache-Control","no-store")
                self.send_header("Content-Length",str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            except Exception as e:
                data = json.dumps({"ok": False, "error": str(e)}).encode()
                self.send_response(500)
                self.send_header("Content-Type","application/json")
                self.send_header("Cache-Control","no-store")
                self.send_header("Content-Length",str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return

        if self.path.startswith("/status_bar"):
            out = sh("/usr/bin/python3 /home/pi/siyi-webui/status_probe.py")
            data = out.encode()
            self.send_response(200)
            self.send_header("Content-Type","text/html; charset=utf-8")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/set_flight_mode"):

            try:
                qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                mode = qs.get("mode", [""])[0].strip()

                allowed = {
                    "MANUAL", "FBWA", "AUTOTUNE", "CRUISE", "AUTO",
                    "RTL", "LOITER", "TAKEOFF", "QHOVER", "QLOITER",
                    "QLAND", "QRTL"
                }

                if mode not in allowed:
                    out = {
                        "ok": False,
                        "error": "invalid mode",
                        "mode": mode
                    }
                else:
                    blockers = read_pi_ui_mode_safety_blockers()

                    try:
                        st = flight_mode_state_read_once()
                        armed = bool(int(st.get("base_mode", 0) or 0) & 128)
                    except Exception:
                        armed = False

                    if armed and mode in blockers:
                        out = {
                            "ok": False,
                            "blocked": True,
                            "error": "Safety block: %s disabled while armed" % mode,
                            "mode": mode
                        }
                    else:
                        mode_map = {
                            "MANUAL": 0,
                            "FBWA": 5,
                            "CRUISE": 7,
                            "AUTOTUNE": 8,
                            "AUTO": 10,
                            "RTL": 11,
                            "LOITER": 12,
                            "TAKEOFF": 13,
                            "QHOVER": 18,
                            "QLOITER": 19,
                            "QLAND": 20,
                            "QRTL": 21,
                        }

                        mav = mavlink2.MAVLink(None)
                        pkt = mav.set_mode_encode(1, 1, mode_map[mode]).pack(mav)
                        ok = send_mavlink_tcp5760(pkt)

                        try:
                            tmp = FLIGHT_MODE_CACHE_FILE + ".tmp"
                            with open(tmp, "w", encoding="utf-8") as f:
                                json.dump({
                                    "mode": mode,
                                    "custom_mode": mode_map[mode],
                                    "base_mode": 81,
                                    "last_seen": time.time(),
                                    "source": "instant_webui_tx"
                                }, f)
                            os.replace(tmp, FLIGHT_MODE_CACHE_FILE)
                        except Exception as e:
                            print("[INSTANT_MODE_CACHE_FAIL]", repr(e), flush=True)

                        print("[WEBUI_MODE_TCP5760]", mode, "ok=" + str(ok), flush=True)

                        out = {
                            "ok": bool(ok),
                            "mode": mode,
                            "tx": "mavlink_tcp5760"
                        }

            except Exception as e:
                out = {
                    "ok": False,
                    "error": str(e)
                }

            data = json.dumps(out).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/flight_mode_state"):
            data = json.dumps(flight_mode_state_read_once()).encode()
            self.send_response(200)
            self.send_header("Content-Type","application/json")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/software_update_status"):
            payload = json.dumps(software_update_status_payload()).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if self.path.startswith("/health"):
            self.send_response(200)
            self.send_header("Content-type", "text/plain")
            self.end_headers()
            self.wfile.write(b"OK")
            return

        if self.path=="/first_setup":
            body=first_setup_page()

        elif self.path=="/":
            if setup_should_force():
                self.send_response(303)
                self.send_header("Location","/first_setup")
                self.end_headers()
                return

            body=f"""
            <h1>Operations</h1>

            <div class='card'>
              <h2>Operations</h2>
              <p class='small'>Use these controls to restart the main operational areas shown in the top status bar.</p>

              <table>
                <tr><th>System</th><th>Purpose</th><th>Action</th></tr>

                <tr>
                  <td><b>MAVLink</b></td>
                  <td class='small'>Telemetry routing to configured hosts.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='mavlink-router'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart MAVLink</button></form></td>
                </tr>

                <tr>
                  <td><b>Video</b></td>
                  <td class='small'>MediaMTX, selected source publisher and UDP forwarder.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='mediamtx'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart Video</button></form></td>
                </tr>

                

                <tr>
                  <td><b>ZT</b></td>
                  <td class='small'>ZeroTier overlay network.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='zerotier-one'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart ZT</button></form></td>
                </tr>

                <tr>
                  <td><b>Buttons</b></td>
                  <td class='small'>MAVLink button bridge.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='siyi-button-bridge'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart Buttons</button></form></td>
                </tr>

                <tr>
                  <td><b>WebUI</b></td>
                  <td class='small'>This control interface.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='siyi-webui'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart WebUI</button></form></td>
                </tr>
              </table>
            </div>
            """

        elif self.path.startswith("/param_trigger_full_sync"):
            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()
            out=sh("curl -fsS http://127.0.0.1:8765/trigger_full_sync 2>&1")
            try:
                j=json.loads(out.strip())
            except Exception:
                j={"ok":False,"error":out[-300:]}
            self.wfile.write(json.dumps(j).encode())
            return

        elif self.path.startswith("/param_sync_status"):
            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()
            out=sh("curl -fsS http://127.0.0.1:8765/sync_status 2>&1")
            try:
                j=json.loads(out.strip())
            except Exception:
                j={"ok":False,"error":out[-300:]}
            self.wfile.write(json.dumps(j).encode())
            return

        elif self.path.startswith("/param_state?"):
            from urllib.parse import urlparse, parse_qs
            q=parse_qs(urlparse(self.path).query)
            names=q.get("names",[""])[0].strip()

            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()

            if not names:
                self.wfile.write(b'{"ok":true,"params":{}}')
                return

            url="http://127.0.0.1:8765/state?names=" + urllib.parse.quote(names)
            out=sh("curl -fsS " + shlex.quote(url) + " 2>&1")

            try:
                j=json.loads(out.strip())
            except Exception:
                j={"ok":False,"error":out[-300:]}

            self.wfile.write(json.dumps(j).encode())
            return

        elif self.path.startswith("/param_live_read?"):

            from urllib.parse import urlparse, parse_qs

            q=parse_qs(urlparse(self.path).query)
            name=q.get("name",[""])[0].strip()

            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()

            if not name:
                self.wfile.write(b'{"ok":false,"error":"missing name"}')
                return

            url="http://127.0.0.1:8765/get?name=" + urllib.parse.quote(name)
            out=sh("curl -fsS " + shlex.quote(url) + " 2>&1")

            try:
                j=json.loads(out.strip())
            except Exception:
                j={"ok":False,"error":out[-300:]}

            self.wfile.write(json.dumps(j).encode())

        elif self.path.startswith("/param_metadata?"):
            query = parse_qs(urlparse(self.path).query)
            name = query.get("name", [""])[0]
            try:
                send_json_response(self, param_import_metadata_lookup(name), 200)
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 400)
            return

        elif self.path.startswith("/param_import_status"):
            try:
                result = param_import_daemon_request("/import/status")
                send_json_response(self, result, 200 if result.get("ok") else 400)
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 502)
            return

        elif self.path.startswith("/param_import_backup?"):
            query = parse_qs(urlparse(self.path).query)
            session_id = query.get("session_id", [""])[0]
            try:
                send_param_import_download(
                    self,
                    "/import/backup?session_id=" + urllib.parse.quote(session_id),
                )
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 400)
            return

        elif self.path.startswith("/param_import_report?"):
            query = parse_qs(urlparse(self.path).query)
            session_id = query.get("session_id", [""])[0]
            try:
                send_param_import_download(
                    self,
                    "/import/report?session_id=" + urllib.parse.quote(session_id),
                )
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 400)
            return

        elif self.path=="/param_sync_status":
            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()
            try:
                body=open("/etc/siyi/param_refresh_state.json").read()
            except Exception:
                body='{"running":false,"ok":true,"message":"Idle"}'
            self.wfile.write(body.encode())

        elif self.path.startswith("/fc_parameter_export"):
            return fc_parameter_export_handler(self)

        elif self.path=="/parameters":
            self.send_response(200)
            self.send_header("Content-type","text/html")
            self.end_headers()
            self.wfile.write(arduplane_parameters_page().encode())










        elif self.path.startswith("/gimbal_set_zero"):
            try:
                import time

                state_file="/home/pi/siyi_gimbal_state.json"

                with open(state_file,"r",encoding="utf-8") as f:
                    j=json.load(f)

                q=j.get("raw_q")
                if not q:
                    raise Exception("No raw_q in telemetry")

                out={
                    "q_ref": q,
                    "raw_yaw": j.get("raw_yaw",0),
                    "raw_pitch": j.get("raw_pitch",0),
                    "raw_roll": j.get("raw_roll",0),
                    "ts": time.time()
                }

                with open("/etc/siyi/gimbal_zero.json","w",encoding="utf-8") as f:
                    json.dump(out,f,indent=2)

                self.send_response(200)
                self.send_header("Content-Type","application/json")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "ok":True,
                    "yaw":j.get("yaw"),
                    "pitch":j.get("pitch")
                }).encode())
                return

            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type","application/json")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "ok":False,
                    "error":str(e)
                }).encode())
                return

        elif self.path.startswith("/gimbal_current"):
            try:
                if os.path.exists(GIMBAL_STATE_FILE):
                    with open(GIMBAL_STATE_FILE, encoding="utf-8") as f:
                        payload=f.read()
                else:
                    payload=json.dumps({"ok":False,"yaw":0,"pitch":0,"source":"no_state_yet"})
                self.send_response(200)
                self.send_header("Content-Type","application/json")
                self.end_headers()
                self.wfile.write(payload.encode())
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(json.dumps({"ok":False,"error":str(e)}).encode())


        elif self.path=="/software_update":
            body=software_update_page()

        elif self.path=="/flaps":
            body=flaps_page()

        elif self.path=="/buttons":
            rows=read_button_rows()
            extra_gimbal_actions=gimbal_preset_actions()
            tr=""
            for i,r in enumerate(rows):
                b=esc(r.get("Button",""))
                tr+=f"<tr><td>{b}<input style='pointer-events:auto;' type='hidden' name='Button_{i}' value='{b}'></td>"
                for col in ["Tap","Hold","ReleaseAfterTap","ReleaseAfterHold","DoubleTap"]:
                    cell = action_select(col+'_'+str(i), r.get(col,''))
                    if col in ["ReleaseAfterTap","DoubleTap"]:
                        cell = cell.replace("<select", "<select disabled style='opacity:.45;pointer-events:none;'")
                    tr+=f"<td>{cell}</td>"
                tr+="</tr>"
            body="""
            <h1>Button Control System</h1>
            <div class='card'>
            <p>Configure gamepad button actions for the SIYI control system.</p>
            </div>

            
<button id='showGamepadBtn'
        type='button'
        style='position:fixed;top:72px;right:18px;z-index:49;
               display:none;
               pointer-events:auto;
               background:#1e293b;
               color:#cbd5e1;
               border:1px solid #334155;
               border-radius:999px;
               padding:5px 10px;
               font-size:12px;
               line-height:1;
               cursor:pointer;
               opacity:0.82;'>
  Show gamepad reference
</button>

<div id='gamepadFloat' class='card' style='position:fixed;right:24px;top:82px;width:420px;min-width:260px;max-width:80vw;max-height:85vh;overflow:auto;z-index:20;box-shadow:0 12px 30px rgba(0,0,0,.35);'>
            <h2 id='gamepadDragHandle' style='cursor:move;margin-top:0;display:flex;justify-content:space-between;align-items:center;gap:12px;'>
              <span>Standard Gamepad Layout (Reference)</span>
              <button id='gamepadCloseBtn' type='button' style='pointer-events:auto;background:#334155;color:#e5e7eb;border:0;border-radius:999px;margin:0;padding:2px 8px;font-size:14px;line-height:1.3;cursor:pointer;'>×</button>
            </h2>
            <div style='text-align:left;'>
            <img src='/static/gamepad_reference.png'
                 style='max-width:100%;width:100%;border-radius:12px;'>
            </div>
            <p class='small' style='margin-bottom:0;'>Drag this panel by the title bar.</p>

            <div id='gamepadResizeHandle'
                 style='position:absolute;left:0;bottom:0;width:26px;height:26px;cursor:nesw-resize;'>
            </div>

            </div>

            <script>
            (function(){
              const box=document.getElementById('gamepadFloat');
              const handle=document.getElementById('gamepadDragHandle');
              const closeBtn=document.getElementById('gamepadCloseBtn');
              const showBtn=document.getElementById('showGamepadBtn');

              if(!box||!handle) return;

              function hideGamepadPanel(){
                box.style.display='none';
                if(showBtn) showBtn.style.display='block';
              }

              function showGamepadPanel(){
                box.style.display='block';
                if(showBtn) showBtn.style.display='none';
              }

              if(showBtn){
                showBtn.addEventListener('click', function(e){
                  e.preventDefault();
                  e.stopPropagation();
                  showGamepadPanel();
                });
              }

              if(closeBtn){
                closeBtn.addEventListener('mousedown', function(e){
                  e.stopPropagation();
                });
                closeBtn.addEventListener('click', function(e){
                  e.preventDefault();
                  e.stopPropagation();
                  hideGamepadPanel();
                });
              }

              let dragging=false;
              let startX=0,startY=0,startLeft=0,startTop=0;

              handle.addEventListener('mousedown', function(e){
                dragging=true;

                const r=box.getBoundingClientRect();

                startX=e.clientX;
                startY=e.clientY;
                startLeft=r.left;
                startTop=r.top;

                document.body.style.userSelect='none';

                e.preventDefault();
              });

        
      function paramForceLiveReadOnPageLoad(){
        try {
          sessionStorage.setItem('siyi_param_refresh_pending', '1');
          setTimeout(function(){
            if(typeof paramLiveReadVisibleSerial === 'function'){
              // paramLiveReadVisibleSerial(); // disabled: /state polling handles normal updates
            }
          }, 250);
        } catch(e) {
          console.log('param live page-load refresh failed', e);
        }
      }

      window.addEventListener('mousemove', function(e){
                if(!dragging) return;

                let left=startLeft + (e.clientX-startX);
                let top=startTop + (e.clientY-startY);

                const maxLeft=window.innerWidth-box.offsetWidth-8;
                const maxTop=window.innerHeight-box.offsetHeight-8;

                left=Math.max(8,Math.min(left,maxLeft));
                top=Math.max(58,Math.min(top,maxTop));

                box.style.left=left+'px';
                box.style.top=top+'px';
                box.style.right='auto';
              });

              const resize=document.getElementById('gamepadResizeHandle');

              let resizing=false;
              let startWidth=0;
              let resizeStartLeft=0;

              resize.addEventListener('mousedown', function(e){
                resizing=true;

                const r=box.getBoundingClientRect();
                startX=e.clientX;
                startWidth=box.offsetWidth;
                resizeStartLeft=r.left;

                document.body.style.userSelect='none';

                e.preventDefault();
                e.stopPropagation();
              });

              window.addEventListener('mousemove', function(e){

                if(resizing){

                  // Bottom-left handle: dragging left increases width, dragging right decreases width.
                  let delta=startX - e.clientX;
                  let newWidth=startWidth + delta;

                  newWidth=Math.max(260, Math.min(newWidth, window.innerWidth*0.8));

                  // Keep right edge visually anchored while resizing from the left side.
                  let rightEdge=resizeStartLeft + startWidth;
                  let newLeft=rightEdge - newWidth;

                  newLeft=Math.max(8, Math.min(newLeft, window.innerWidth-newWidth-8));

                  box.style.left=newLeft+'px';
                  box.style.right='auto';
                  box.style.width=newWidth+'px';

                  return;
                }

              });

              window.addEventListener('mouseup', function(){
                dragging=false;
                resizing=false;
                document.body.style.userSelect='';
              });
            })();
            </script>

            """

            body += f"""<div class='card'>
<form id='buttonMapForm' method='post' action='/save_buttons'>
<input style='pointer-events:auto;' type='hidden' name='count' value='{len(rows)}'>
<table><tr><th>Button</th><th>Tap</th><th>Hold</th><th>ReleaseAfterTap<br><span style='font-size:11px;font-style:italic;color:#9ca3af;'>(currently unsupported)</span></th><th>ReleaseAfterHold</th><th>DoubleTap<br><span style='font-size:11px;font-style:italic;color:#9ca3af;'>(currently unsupported)</span></th></tr>{tr}</table>
<div id='buttonMapSaveStatus' class='small' style='margin-top:8px;color:#94a3b8;'>Saved automatically</div>
</form>
<script>
(function(){{
  const form=document.getElementById('buttonMapForm');
  const status=document.getElementById('buttonMapSaveStatus');
  if(!form) return;
  let t=null;

  async function saveButtonMap(){{
    clearTimeout(t);
    t=setTimeout(async function(){{
      if(status) status.textContent='Saving...';
      try {{
        const fd=new FormData(form);
        await fetch('/save_buttons', {{
          method:'POST',
          body:new URLSearchParams(fd)
        }});
        if(status) status.textContent='Saved automatically';
      }} catch(e) {{
        if(status) status.textContent='Save failed';
      }}
    }}, 300);
  }}

  form.querySelectorAll('select,input').forEach(el => {{
    el.addEventListener('change', saveButtonMap);
  }});
}})();
</script>
</div>"""

            body += """
            """ + button_safety_card() + gimbal_presets_card() + """

            <div class='card'>
            <h2>Disable Button Controls</h2>
            <p class='small'>Stops the runtime button bridge without affecting MAVLink or video.</p>
            <form method='post' action='/stop_bridge'>
            <button style='pointer-events:auto;' class='danger'>Disable Bridge</button>
            </form>
            </div>
            """


        elif self.path=="/video":
            body=video_source_page()

        elif self.path=="/mavlink":
            m=get_mav_values()
            body=f"""<h1>MAVLink Settings</h1>
            <div class='card'><h2>Telemetry Routing</h2><form method='post' action='/save_mavlink_form'><div class='grid'>
            <div><label>Serial device</label><input style='pointer-events:auto;' name='device' value='{esc(m["device"])}'></div>
            <div><label>Baud</label><input style='pointer-events:auto;' name='baud' value='{esc(m["baud"])}'></div>
            <div><label>UDP MAVLink port</label><input style='pointer-events:auto;' name='port' value='{esc(m["port"])}'></div>
            <div><label>TCP server port</label><input style='pointer-events:auto;' name='tcp' value='{esc(m["tcp"])}'></div>
            </div><button style='pointer-events:auto;'>Save MAVLink config + restart mavlink-router</button></form></div>
            <div class='card'><h2>MAVLink Destination Hosts</h2>{endpoints_summary("mavlink")}<a href='/endpoints'><button style='pointer-events:auto;'>Edit endpoints</button></a></div>"""

        elif self.path=="/endpoints":
            body=endpoints_page()

        elif self.path=="/wifi":
            msg=esc(sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true"))
            body=f"""<h1>WiFi</h1>
            <div class='card'>{wifi_profiles_cards()}</div>
            <div class='card'><h2>Add / Replace Saved Wi-Fi SSID</h2><p class='small'>Saves profile without forcing reconnect.</p>
            <form method='post' action='/wifi_add'><div class='grid'><div><label>SSID</label><input style='pointer-events:auto;' name='ssid'></div><div><label>Password</label><input id='wifi_add_password' style='pointer-events:auto;' name='password' type='password'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="this.closest('div').querySelector('input[name=password]').type=this.checked?'text':'password'"> Show password</label></div><div><label>Priority</label><input style='pointer-events:auto;' name='priority' value='10'></div><div><label>Autoconnect</label><select style='pointer-events:auto;' name='autoconnect'><option selected>yes</option><option>no</option></select></div></div><button style='pointer-events:auto;'>Save Wi-Fi profile only</button></form></div>"""

        elif self.path=="/zerotier":
            msg=esc(sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true"))
            body=f"""<h1>ZeroTier</h1>
            <div class='card'>
            {zt_status_html()}
            <form method='post' action='/zt_save_config'>
              <div class='grid'>
                <div><label>ZeroTier Network ID</label><input style='pointer-events:auto;' name='nwid' value='{esc(zt_network_id_current())}' placeholder='ZeroTier network ID'></div>
                <div><label>ZeroTier API Token</label><input id='zt_token_field' style='pointer-events:auto;' name='token' type='password' value='{esc(zt_read_token())}' placeholder='Paste token to save/update'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="document.getElementById('zt_token_field').type=this.checked?'text':'password'"> Show token</label></div>
              </div>
              <button style='pointer-events:auto;'>Save ZeroTier config</button>
            </form>
            <p class='small'>Saving ZeroTier config also runs setup: join network, authorize/name this Pi, and update camera managed route 192.168.144.0/24 via this Pi.</p>
            </div>"""

        elif self.path=="/network":
            msg=esc(sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true"))
            body=f"""<h1>Network</h1>
            <div class='card'>{wifi_profiles_cards()}</div>
            <div class='card'><h2>Add / Replace Saved Wi-Fi SSID</h2><p class='small'>Saves profile without forcing reconnect.</p>
            <form method='post' action='/wifi_add'><div class='grid'><div><label>SSID</label><input style='pointer-events:auto;' name='ssid'></div><div><label>Password</label><input id='wifi_add_password' style='pointer-events:auto;' name='password' type='password'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="this.closest('div').querySelector('input[name=password]').type=this.checked?'text':'password'"> Show password</label></div><div><label>Priority</label><input style='pointer-events:auto;' name='priority' value='10'></div><div><label>Autoconnect</label><select style='pointer-events:auto;' name='autoconnect'><option selected>yes</option><option>no</option></select></div></div><button style='pointer-events:auto;'>Save Wi-Fi profile only</button></form></div>
            <div class='card'><h2>ZeroTier</h2>
            {zt_status_html()}
            <form method='post' action='/zt_save_config'>
              <div class='grid'>
                <div><label>ZeroTier Network ID</label><input style='pointer-events:auto;' name='nwid' value='{esc(zt_network_id_current())}' placeholder='ZeroTier network ID'></div>
                <div><label>ZeroTier API Token</label><input id='zt_token_field' style='pointer-events:auto;' name='token' type='password' value='{esc(zt_read_token())}' placeholder='Paste token to save/update'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="document.getElementById('zt_token_field').type=this.checked?'text':'password'"> Show token</label></div>
              </div>
              <button style='pointer-events:auto;'>Save ZeroTier config</button>
            </form>
            <p class='small'>Saving ZeroTier config also runs setup: join network, authorize/name this Pi, and update camera managed route 192.168.144.0/24 via this Pi.</p>
            </div>"""

        elif self.path=="/camera_sd":
            body=camera_sd_page()

        elif self.path=="/logs":
            body="<h1>Logs</h1>"
            for s in SERVICES:
                body+=f"<div class='card'><h2>{s}</h2><pre>{esc(sh(f'journalctl -u {s} -n 80 --no-pager -l'))}</pre></div>"

        elif self.path=="/safety":
            body="<h1>Safety / Failsafe</h1><div class='card'><p>The Web UI edits configuration files and restarts services.</p><p>The button bridge remains the runtime executor.</p><p>ArduPlane / FC failsafe remains independent from this UI.</p><form method='post' action='/stop_bridge'><button style='pointer-events:auto;' class='danger'>Disable Button Bridge</button></form></div>"

        else:
            self.send_error(404); return

        if self.path != "/first_setup":
            if 'body' in locals():
                body = setup_banner() + body

        data=page("SIYI Pi Control Center",body).encode()
        self.send_response(200)
        self.send_header("Content-Type","text/html; charset=utf-8")
        self.send_header("Content-Length",str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        if software_update_lock_active():
            payload = json.dumps({
                "error": "Software upgrade in progress"
            }).encode("utf-8")
            self.send_response(423)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if self.path == "/unigcs_control":
            length = int(self.headers.get("Content-Length", "0"))
            data = self.rfile.read(length).decode(errors="ignore")
            q = dict(parse_qsl(data))

            cmd = ""

            if "cmd" in q:
                cmd = q.get("cmd", "")
            elif "brightness" in q:
                cmd = "brightness:" + q.get("brightness", "50")
            elif "saturation" in q:
                cmd = "saturation:" + q.get("saturation", "60")
            elif "contrast" in q:
                cmd = "contrast:" + q.get("contrast", "50")
            elif "ev" in q:
                cmd = "ev:" + q.get("ev", "0")
            elif "ss" in q:
                cmd = "ss:" + q.get("ss", "0")

            try:
                out = send_unigcs_fifo(cmd)
            except Exception as e:
                out = "UniGCS control failed: " + str(e)

            try:
                open("/tmp/siyi_webui_last_action", "w").write(out)
            except Exception:
                pass

            self.send_response(303)
            self.send_header("Location", "/camera_controls")
            self.end_headers()
            return

        if self.path in {
            "/param_import_preview",
            "/param_import_apply",
            "/param_import_cancel",
            "/param_import_rollback",
        }:
            try:
                length = int(self.headers.get("Content-Length", "0") or "0")
                if length > PARAM_IMPORT_MAX_REQUEST:
                    raise ValueError("Parameter import request is too large")
                raw = self.rfile.read(length)
                payload = json.loads(raw.decode("utf-8")) if raw else {}
                if not isinstance(payload, dict):
                    raise ValueError("JSON request must be an object")
                daemon_path = {
                    "/param_import_preview": "/import/preview",
                    "/param_import_apply": "/import/apply",
                    "/param_import_cancel": "/import/cancel",
                    "/param_import_rollback": "/import/rollback",
                }[self.path]
                result = param_import_daemon_request(
                    daemon_path,
                    method="POST",
                    payload=payload,
                    timeout=45 if self.path == "/param_import_preview" else 15,
                )
                if self.path == "/param_import_preview" and result.get("ok"):
                    result = param_import_attach_metadata(result)
                send_json_response(self, result, 200 if result.get("ok") else 400)
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 400)
            return

        length=int(self.headers.get("Content-Length",0))
        data=parse_qs(self.rfile.read(length).decode())


        if self.path=="/save_video_source":
            try:
                cfg = video_source_config_from_form(data)
                video_source_write_config(cfg)
                message = video_source_control("apply")
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(message)
            except Exception as exc:
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(
                    "Video source save failed: " + str(exc)
                )
            self.send_response(303)
            self.send_header("Location", "/video")
            self.end_headers()
            return

        if self.path=="/video_source_select":
            try:
                source = data.get("source", [""])[0]
                if source not in {"siyi_rtsp", "hdmi_usb"}:
                    raise ValueError("Invalid video source")
                message = video_source_control("select", source)
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(message)
            except Exception as exc:
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(
                    "Video source switch failed: " + str(exc)
                )
            self.send_response(303)
            self.send_header("Location", "/video")
            self.end_headers()
            return

        if self.path=="/video_source_toggle":
            try:
                message = video_source_control("toggle")
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(message)
            except Exception as exc:
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(
                    "Video source toggle failed: " + str(exc)
                )
            self.send_response(303)
            self.send_header("Location", "/video")
            self.end_headers()
            return

        if self.path=="/software_update_start":
            try:
                current = get_release_version()
                latest = software_update_manifest()["stable"]
                preserve_groups = software_update_validate_preserve_groups(
                    data.get("preserve", [])
                )
                remember_selection = (
                    "1" if data.get("remember", ["0"])[0] == "1" else "0"
                )

                if software_update_running():
                    message = "Upgrade is already running."
                elif not software_update_is_newer(latest, current):
                    message = (
                        "Upgrade blocked: published version " + latest
                        + " is not newer than installed version " + current + "."
                    )
                else:
                    result = subprocess.run(
                        [
                            "sudo", "-n", SOFTWARE_UPDATE_LAUNCHER,
                            "--from", current,
                            "--target", latest,
                            "--preserve", ",".join(preserve_groups),
                            "--remember", remember_selection,
                        ],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                        timeout=15,
                        check=False,
                    )
                    if result.returncode != 0:
                        raise RuntimeError(
                            (result.stdout or "Upgrade launcher failed").strip()
                        )
                    message = (
                        "Upgrade started: " + current + " -> " + latest
                    )
                try:
                    with open("/tmp/siyi_webui_last_action", "w", encoding="utf-8") as f:
                        f.write(message)
                except Exception:
                    pass
            except Exception as exc:
                try:
                    with open(SOFTWARE_UPDATE_LOG_FILE, "a", encoding="utf-8") as f:
                        f.write("\nUpgrade start failed: " + str(exc) + "\n")
                except Exception:
                    pass

            self.send_response(303)
            self.send_header("Location", "/software_update")
            self.end_headers()
            return

        elif self.path=="/first_setup_skip":
            open(SETUP_SKIP_FILE,"w").write("skip\n")

        elif self.path=="/first_setup_save":

            nwid=data.get("nwid",[""])[0].strip()
            token=data.get("token",[""])[0].strip()

            if nwid:
                cfg=zt_read_config()
                cfg["network_id"]=nwid
                zt_save_config(cfg)

            if token:
                zt_save_token(token)

            save_endpoints_from_params(data)

            ssid=data.get("ssid",[""])[0].strip()
            password=data.get("password",[""])[0]

            if ssid:
                sh(f"nmcli connection add type wifi ifname wlan0 con-name webui-wifi-{ssid.replace(' ','_')} ssid {shlex.quote(ssid)} 2>/dev/null || true")
                con_name = "webui-wifi-" + ssid.replace(" ","_")
                sh(f"nmcli connection modify {shlex.quote(con_name)} wifi-sec.key-mgmt wpa-psk wifi-sec.psk {shlex.quote(password)} 2>/dev/null || true")
                wifi_pw_set(con_name, password)

            out=zt_full_setup()

            if setup_config_is_valid():
                os.makedirs("/etc/siyi",exist_ok=True)
                open(SETUP_COMPLETE_FILE,"w").write(json.dumps({"complete":True},indent=2))
                if os.path.exists(SETUP_SKIP_FILE):
                    os.remove(SETUP_SKIP_FILE)

            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/restart":
            s=data.get("service",[""])[0]
            if s == "mavlink-router":
                sh("sudo -n systemctl stop mavlink-router")
                time.sleep(5)
                sh("sudo -n systemctl start mavlink-router")
                time.sleep(2)
                sh("sudo -n systemctl restart siyi-button-bridge")
            elif s == "zerotier-one":
                sh("sudo -n systemctl stop zerotier-one")
                time.sleep(5)
                sh("sudo -n systemctl start zerotier-one")
                time.sleep(3)

                sh("sudo -n systemctl stop mavlink-router")
                time.sleep(5)
                sh("sudo -n systemctl start mavlink-router")
                time.sleep(2)
                sh("sudo -n systemctl restart siyi-button-bridge")

            elif s == "siyi-webui":
                sh("systemd-run --unit=siyi-webui-delayed-restart --on-active=2 /bin/systemctl restart siyi-webui 2>/dev/null || true")
            elif s == "mediamtx":
                sh("sudo -n systemctl restart mediamtx")
                time.sleep(1)
                sh("sudo -n systemctl restart siyi-video-source")
                sh("sudo -n systemctl restart siyi-video-dual")
            elif s in SERVICES:
                sh(f"sudo -n systemctl restart {s}")

        elif self.path=="/param_write":
            name=data.get("name",[""])[0].strip()
            value=data.get("value",[""])[0].strip()

            if name and value:
                cmd=(
                    "curl -fsS -X POST "
                    "--data-urlencode " + shlex.quote("name=" + name) + " "
                    "--data-urlencode " + shlex.quote("value=" + value) + " "
                    "http://127.0.0.1:8765/set"
                )
                out=sh(cmd + " 2>&1")

                try:
                    j=json.loads(out.strip())
                    if j.get("ok"):
                        msg=f"OK {name} = {j.get('value')}"
                    else:
                        msg=f"FAILED {name}: {j.get('error')}"
                except Exception:
                    msg=f"FAILED {name}: {out[-300:]}"

                try:
                    open("/tmp/siyi_param_write_status.txt","w").write(msg)
                except Exception:
                    pass

            self.send_response(303)
            self.send_header("Location", "/parameters")
            self.end_headers()
            return

        elif self.path=="/params_refresh":

            sh("/home/pi/siyi_param_refresh_wrapper.sh >/tmp/siyi_param_refresh_wrapper.log 2>&1 &")
            self.send_response(303)
            self.send_header("Location", "/parameters")
            self.end_headers()
            return

        elif self.path=="/save_flaps":
            try:
                flaps_write_config({
                    "enabled": "enabled" in data,
                    "left_servo": data.get(
                        "left_servo", ["9"]
                    )[0],
                    "right_servo": data.get(
                        "right_servo", ["10"]
                    )[0],
                    "left_reverse": data.get(
                        "left_reverse", ["0"]
                    )[0] == "1",
                    "right_reverse": data.get(
                        "right_reverse", ["0"]
                    )[0] == "1",
                    "up_pwm": data.get(
                        "up_pwm", ["1000"]
                    )[0],
                    "takeoff_pwm": data.get(
                        "takeoff_pwm", ["1500"]
                    )[0],
                    "landing_pwm": data.get(
                        "landing_pwm", ["2000"]
                    )[0],
                })

                open(
                    "/tmp/siyi_webui_last_action",
                    "w",
                ).write(
                    "Flap configuration saved"
                )

                sh(
                    "sudo -n systemctl restart "
                    "siyi-button-bridge"
                )

            except Exception as e:
                open(
                    "/tmp/siyi_webui_last_action",
                    "w",
                ).write(
                    "Flap configuration save failed: "
                    + str(e)
                )

        elif self.path=="/save_button_safety":

            csv_vals=data.get("block_when_armed_csv", [""])[0]
            vals=[x.strip() for x in csv_vals.split(",") if x.strip()]

            current_safety=read_button_safety_config()

            if "unlock_airborne_safety" in data:
                block_disarm=("block_disarm_in_air" in data)
                block_toggle=("block_toggle_arm_disarm_in_air" in data)
            else:
                block_disarm=current_safety.get("block_disarm_in_air", True)
                block_toggle=current_safety.get("block_toggle_arm_disarm_in_air", True)

            write_button_safety_config(vals, block_disarm, block_toggle)

            sh("sudo -n systemctl restart siyi-button-bridge")
        elif self.path=="/save_gimbal_presets":
            try:
                raw=data.get("presets_json",["[]"])[0]
                presets=json.loads(raw)
                if not isinstance(presets,list):
                    presets=[]
                write_gimbal_presets(presets)
                sh("sudo -n systemctl restart siyi-button-bridge")
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"OK")
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(("ERR: %s"%e).encode())

        elif self.path=="/save_buttons":
            backup(BUTTON_MAP)
            count=int(data.get("count",["0"])[0])
            with open(BUTTON_MAP,"w",encoding="utf-8",newline="") as f:
                w=csv.writer(f,delimiter=";")
                w.writerow(["Button","Tap","Hold","ReleaseAfterTap","ReleaseAfterHold","DoubleTap","Notes"])
                for i in range(count):
                    w.writerow([data.get(f"Button_{i}",[""])[0],data.get(f"Tap_{i}",["NO_ACTION"])[0],data.get(f"Hold_{i}",["NO_ACTION"])[0],data.get(f"ReleaseAfterTap_{i}",["NO_ACTION"])[0],data.get(f"ReleaseAfterHold_{i}",["NO_ACTION"])[0],data.get(f"DoubleTap_{i}",["NO_ACTION"])[0],data.get(f"Notes_{i}",[""])[0]])
            sh("sudo -n systemctl restart siyi-button-bridge")

        elif self.path=="/save_endpoints":
            save_endpoints_from_params(data)

        elif self.path=="/save_video":
            try:
                cfg = video_source_read_config()
                cfg["siyi"]["url"] = data.get("rtsp", [cfg["siyi"]["url"]])[0]
                cfg["siyi"]["transport"] = data.get("protocols", ["tcp"])[0]
                cfg["siyi"]["latency_ms"] = video_source_int(data.get("latency", ["0"])[0], 0, 5000, "Latency")
                cfg["udp"]["port"] = video_source_int(data.get("port", ["5600"])[0], 1, 65535, "UDP port")
                video_source_write_config(cfg)
                video_source_control("apply")
            except Exception as exc:
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write("Video save failed: " + str(exc))

        elif self.path=="/save_mavlink_form":
            write_file(MAVCONF, make_mav_conf_from_endpoints(data.get("device",["/dev/ttyAMA0"])[0],data.get("baud",["57600"])[0],data.get("port",["14550"])[0],data.get("tcp",["5760"])[0]))
            sh("sudo -n systemctl restart mavlink-router")

        elif self.path=="/wifi_add":
            ssid=data.get("ssid",[""])[0].strip()
            pw=data.get("password",[""])[0]
            prio=data.get("priority",["10"])[0].strip() or "10"
            ac=data.get("autoconnect",["yes"])[0].strip()
            if ssid and pw:
                safe="webui-wifi-" + ssid.replace(" ","_")
                out=[]
                out.append(sh(f"sudo -n nmcli connection delete '{safe}' 2>/dev/null || true"))
                out.append(sh(f"sudo nmcli connection add type wifi ifname wlan0 con-name '{safe}' ssid '{ssid}'"))
                out.append(sh(f"sudo nmcli connection modify '{safe}' wifi-sec.key-mgmt wpa-psk wifi-sec.psk '{pw}'"))
                wifi_pw_set(safe, pw)
                out.append(sh(f"sudo nmcli connection modify '{safe}' connection.autoconnect {ac} connection.autoconnect-priority {prio}"))
                out.append("Saved Wi-Fi profile without forcing reconnect: " + safe)
                open("/tmp/siyi_webui_last_action","w").write("\\n".join([x for x in out if x]))

        elif self.path=="/wifi_update":
            name=data.get("name",[""])[0]
            prio=data.get("priority",["0"])[0]
            ac=data.get("autoconnect",["yes"])[0]
            if name and not name.startswith("netplan-"):
                sh(f"sudo -n nmcli connection modify '{name}' connection.autoconnect {ac}")
                sh(f"sudo -n nmcli connection modify '{name}' connection.autoconnect-priority {prio}")
                open("/tmp/siyi_webui_last_action","w").write(f"Updated {name}: priority={prio}, autoconnect={ac}")

        elif self.path=="/wifi_switch":
            name=data.get("name",[""])[0]
            if name:
                out=sh(f"sudo nmcli connection up '{name}'")
                open("/tmp/siyi_webui_last_action","w").write(out or f"Switched to {name}")
                sh("systemd-run --unit=siyi-webui-delayed-restart --on-active=3 /bin/systemctl restart siyi-webui 2>/dev/null || true")

        elif self.path=="/wifi_update_password":
            name=data.get("name",[""])[0]
            pw=data.get("password",[""])[0]
            if name and pw:
                out=sh(f"sudo -n nmcli connection modify '{name}' wifi-sec.psk '{pw}'")
                wifi_pw_set(name, pw)
                open("/tmp/siyi_webui_last_action","w").write(out or f"Updated Wi-Fi password for {name}")

        elif self.path=="/wifi_delete":
            name=data.get("name",[""])[0]
            if name and not name.startswith("netplan-"):
                out=sh(f"sudo -n nmcli connection delete '{name}'")
                wifi_pw_delete(name)
                open("/tmp/siyi_webui_last_action","w").write(out or f"Deleted {name}")



        elif self.path=="/camera_sd_zip":
            urls=data.get("urls",[])
            urls=[u for u in urls if u.startswith(CAM_SD_BASE + "/")]
            if urls:
                tmp=tempfile.NamedTemporaryFile(delete=False,suffix=".zip")
                tmp.close()
                try:
                    with zipfile.ZipFile(tmp.name,"w",compression=zipfile.ZIP_STORED) as z:
                        for url in urls:
                            name=os.path.basename(urllib.parse.urlparse(url).path) or "camera_file.mp4"
                            with urllib.request.urlopen(url, timeout=30) as r:
                                z.writestr(name, r.read())
                    with open(tmp.name,"rb") as f:
                        payload=f.read()
                    os.unlink(tmp.name)
                    self.send_response(200)
                    self.send_header("Content-Type","application/zip")
                    self.send_header("Content-Disposition",'attachment; filename="camera_sd_selected.zip"')
                    self.send_header("Content-Length",str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                    return
                except Exception as e:
                    try:
                        os.unlink(tmp.name)
                    except Exception:
                        pass
                    self.send_error(502, str(e))
                    return


        elif self.path=="/camera_sd_delete_selected":
            urls=data.get("urls",[])
            urls=[u for u in urls if u.startswith(CAM_SD_BASE + "/")]
            if urls:
                out=camera_sd_delete_many(urls)
                open("/tmp/siyi_webui_last_action","w").write("Camera SD batch delete: " + out)

        elif self.path=="/camera_sd_delete":
            url=data.get("url",[""])[0]
            if url.startswith(CAM_SD_BASE + "/"):
                out=camera_sd_delete(url)
                open("/tmp/siyi_webui_last_action","w").write("Camera SD delete: " + out)

        elif self.path=="/zt_save_config":
            nwid=data.get("nwid",[""])[0].strip()
            token=data.get("token",[""])[0].strip()
            cfg=zt_read_config()
            if nwid:
                cfg["network_id"]=nwid
                zt_write_config(cfg)
            if token:
                zt_save_token(token)

            saved_msg="Saved ZeroTier config. Network ID=" + (nwid or cfg.get("network_id",""))
            if token:
                saved_msg += " API token=saved"
            else:
                saved_msg += " API token=unchanged"

            setup_msg=zt_full_setup()
            open("/tmp/siyi_webui_last_action","w").write(saved_msg + "\n\n" + setup_msg)

        elif self.path=="/zt_test_token":
            out=zt_test_token()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_authorize_pi":
            out=zt_authorize_this_pi()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_update_route":
            out=zt_update_camera_route()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_full_setup":
            out=zt_full_setup()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_join":
            nwid=data.get("nwid",[""])[0].strip() or zt_network_id_current()
            if nwid:
                cfg=zt_read_config()
                cfg["network_id"]=nwid
                zt_write_config(cfg)
                out=sh(f"sudo zerotier-cli join {nwid}")
                open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/stop_bridge":
            sh("systemctl stop siyi-button-bridge")

        loc="/"
        if self.path.startswith("/save_video"): loc="/video"
        elif self.path.startswith("/save_mavlink"): loc="/mavlink"
        elif self.path.startswith("/save_endpoints"): loc="/endpoints"
        elif self.path.startswith("/save_buttons"): loc="/buttons"
        elif self.path.startswith("/save_flaps"): loc="/flaps"
        elif self.path.startswith("/wifi") or self.path.startswith("/zt"):
            loc="/wifi" if self.path.startswith("/wifi") else "/zerotier"

        elif self.path == "/unigcs_control":
            length = int(self.headers.get("Content-Length", "0"))
            data = self.rfile.read(length).decode(errors="ignore")
            q = dict(parse_qsl(data))

            cmd = ""

            if "cmd" in q:
                cmd = q.get("cmd", "")
            elif "brightness" in q:
                cmd = "brightness:" + q.get("brightness", "50")
            elif "saturation" in q:
                cmd = "saturation:" + q.get("saturation", "60")
            elif "contrast" in q:
                cmd = "contrast:" + q.get("contrast", "50")
            elif "ev" in q:
                cmd = "ev:" + q.get("ev", "0")
            elif "ss" in q:
                cmd = "ss:" + q.get("ss", "0")

            try:
                out = send_unigcs_fifo(cmd)
            except Exception as e:
                out = "UniGCS control failed: " + str(e)

            try:
                open("/tmp/siyi_webui_last_action", "w").write(out)
            except Exception:
                pass

            self.send_response(303)
            self.send_header("Location", "/camera_controls")
            self.end_headers()
            return

        self.send_response(303)
        self.send_header("Location",loc)
        self.end_headers()


# REAL_HTTP_LOGS_PAGE_FIX_START
def _real_logs_cmd(cmd, timeout=6):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT, timeout=timeout)
    except Exception as e:
        return str(e)

def _log_level(line):
    low = line.lower()
    if any(x in low for x in ["error", "failed", "failure", "traceback", "exception", "critical", "panic"]):
        return "ERROR"
    if any(x in low for x in ["warning", "warn", "denied", "timeout", "unreachable"]):
        return "WARN"
    return "INFO"

def _log_category(line):
    low = line.lower()
    if "mavlink-router" in low or "mavlink" in low or "/dev/ttyama0" in low:
        return "MAVLINK"
    if "siyi-video" in low or "gstreamer" in low or "rtsp" in low or "udp" in low or "video" in low:
        return "VIDEO"
    if "siyi-button" in low or "siyi-rec" in low or "unigcs" in low or "camera" in low:
        return "SIYI"
    if "zerotier" in low or "wlan" in low or "network" in low:
        return "NETWORK"
    if "siyi-webui" in low or "python3" in low or "webui" in low or "get /" in low:
        return "WEBUI"
    return "SYSTEM"

def _noise(line):
    low = line.lower()
    noise_words = [
        "pipewire", "wireplumber", "xdg-desktop", "rtkit", "bluez",
        "bcm2835", "vc_sm_cma", "alsa", "portal", "upower",
        "pam_unix(sudo:session): session opened",
        "pam_unix(sudo:session): session closed",
        "command=/usr/sbin/sudo zerotier-cli info",
        "get /status_bar", "get /health", "get /api/logs",
    ]
    return any(w in low for w in noise_words)

def _simplify(line):
    raw = line.strip()
    msg = raw

    # Remove noisy syslog prefix as much as possible
    m = re.match(r"^([A-Z][a-z]{2}\s+\d+\s+\d\d:\d\d:\d\d)\s+\S+\s+(.*)$", raw)
    ts = ""
    if m:
        ts = m.group(1)
        msg = m.group(2)

    msg = re.sub(r"^\S+\[\d+\]:\s*", "", msg)
    msg = msg.replace('"GET ', "GET ").replace(' HTTP/1.1" 200 -', "")

    low = msg.lower()

    if "opened uart" in low and "/dev/ttyama0" in low:
        msg = "FC serial opened: /dev/ttyAMA0"
    elif "uart" in low and "speed = 57600" in low:
        msg = "FC serial speed: 57600"
    elif "opened udp client" in low and ""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"" in low:
        msg = "MAVLink endpoint opened: Mac "+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+":14550"
    elif "opened udp client" in low and ""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"" in low:
        msg = "MAVLink endpoint opened: Android "+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+":14550"
    elif "started mavlink-router" in low:
        msg = "MAVLink Router started"
    elif "started siyi-webui" in low:
        msg = "Web UI service started"
    elif "get /logs" in low:
        msg = "Logs page opened"
    elif "get /camera_controls" in low:
        msg = "Camera Controls page opened"
    elif "get /safety" in low:
        msg = "Safety page opened"
    elif "permissions for /lib/netplan" in low:
        msg = "Netplan file permissions are too open"
    elif "registration to specific type not supported" in low:
        msg = "WiFi driver capability warning"
    elif "bgscan simple" in low:
        msg = "WiFi background scan warning"

    return ts, msg

def _real_logs_events(mode="important"):
    raw = _real_logs_cmd("journalctl --since '6 hours ago' --no-pager -n 1200")
    events = []

    for line in raw.splitlines():
        if not line.strip():
            continue
        if _noise(line):
            continue

        cat = _log_category(line)
        lvl = _log_level(line)
        ts, msg = _simplify(line)

        keep = False
        if mode == "full":
            keep = True
        elif mode == "important":
            keep = (
                lvl in ("ERROR", "WARN")
                or cat in ("MAVLINK", "VIDEO", "SIYI", "NETWORK")
                or "started" in msg.lower()
                or "opened" in msg.lower()
            )
        else:
            keep = (cat.lower() == mode.lower())

        if keep:
            events.append((ts, lvl, cat, msg))

    # Newest first. journalctl is chronological, so reverse after filtering.
    events = list(reversed(events))[:250]

    if not events:
        return "No important events found. This usually means the system is quiet/healthy."

    lines = []
    for ts, lvl, cat, msg in events:
        lines.append(f"{ts:<15}  {lvl:<5}  {cat:<8}  {msg}")
    return "\n".join(lines)

def _real_logs_text(mode="important"):
    return _real_logs_events(mode)

def _send_bytes(self, data, ctype="text/html; charset=utf-8"):
    if isinstance(data, str):
        data = data.encode("utf-8", "replace")
    self.send_response(200)
    self.send_header("Content-Type", ctype)
    self.send_header("Cache-Control", "no-store")
    self.send_header("Content-Length", str(len(data)))
    self.end_headers()
    self.wfile.write(data)

def _real_logs_page():
    return f"""<style>
.logbar{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;align-items:center}}
.logbtn{{background:#253244;color:#e8eef5;border:1px solid #3c4b5f;border-radius:8px;padding:8px 11px;cursor:pointer}}
.logbtn:hover{{background:#314158}}
.loghint{{opacity:.75;font-size:13px;margin-left:4px}}
#logs{{height:calc(100vh - 230px);min-height:420px;overflow-y:auto;padding:14px;white-space:pre-wrap;word-break:break-word;font-family:Menlo,Consolas,monospace;font-size:12px;line-height:1.4;background:#101418;color:#e8eef5;border-radius:12px;border:1px solid #2b3440}}
.err{{color:#ff9b9b;font-weight:bold}}
.warn{{color:#ffd28a;font-weight:bold}}
.info{{color:#a8ffbf;font-weight:bold}}
</style>

<h2>Logs <span style="font-size:13px;opacity:.65">v{VERSION}</span></h2>
<p style="opacity:.8;margin-top:-4px">Filtered diagnostic timeline. Newest first. Desktop/audio noise is hidden.</p>

<div class="logbar">
  <button class="logbtn" onclick="setMode('important')">Important</button>
  <button class="logbtn" onclick="setMode('mavlink')">MAVLink</button>
  <button class="logbtn" onclick="setMode('video')">Video</button>
  <button class="logbtn" onclick="setMode('siyi')">SIYI</button>
  <button class="logbtn" onclick="setMode('network')">Network</button>
  <button class="logbtn" onclick="setMode('webui')">Web UI</button>
  <button class="logbtn" onclick="setMode('system')">System</button>
  <button class="logbtn" onclick="setMode('full')">Full Filtered</button>
  <button class="logbtn" onclick="copyLogs()">Copy</button>
  <span class="loghint" id="status">Loading…</span>
</div>

<pre id="logs"></pre>

<script>
let mode='important';
let follow=true;

function colorize(t){{
  return t
    .replace(/(ERROR)/g,'<span class="err">$1</span>')
    .replace(/(WARN)/g,'<span class="warn">$1</span>')
    .replace(/(INFO)/g,'<span class="info">$1</span>');
}}

async function loadLogs(){{
  const box=document.getElementById('logs');
  const status=document.getElementById('status');
  try{{
    const r=await fetch('/api/logs?mode='+encodeURIComponent(mode)+'&t='+Date.now(), {{cache:'no-store'}});
    const t=await r.text();
    box.innerHTML=colorize(t);
    status.innerText='Mode: '+mode+' | Updated: '+new Date().toLocaleTimeString();
    if(follow) box.scrollTop=0;
  }}catch(e){{
    status.innerText='Failed to load logs';
  }}
}}

function setMode(m){{
  mode=m;
  loadLogs();
}}

function copyLogs(){{
  navigator.clipboard.writeText(document.getElementById('logs').innerText);
  document.getElementById('status').innerText='Copied diagnostics';
}}

loadLogs();
setInterval(loadLogs,5000);
</script>"""

_old_do_GET = H.do_GET
def _patched_do_GET(self):
    parsed = urlparse(self.path)
    path = parsed.path
    qs = dict(parse_qsl(parsed.query))

    if path == "/logs":
        return _send_bytes(self, page("Logs", _real_logs_page()), "text/html; charset=utf-8")

    if path == "/api/logs":
        mode = qs.get("mode", "important")
        return _send_bytes(self, _real_logs_text(mode), "text/plain; charset=utf-8")

    return _old_do_GET(self)

H.do_GET = _patched_do_GET
# REAL_HTTP_LOGS_PAGE_FIX_END


if __name__ == "__main__":
    ThreadingHTTPServer(("0.0.0.0",PORT),H).serve_forever()


# FULL_LOGS_PAGE_FIX_START
from flask import Response
import subprocess
import shlex

def _safe_cmd(cmd, timeout=4):
    try:
        return subprocess.check_output(
            cmd, shell=True, text=True,
            stderr=subprocess.STDOUT, timeout=timeout
        )
    except subprocess.CalledProcessError as e:
        return e.output or str(e)
    except Exception as e:
        return str(e)

@app.route("/api/logs")
def api_logs():
    parts = []

    sources = [
        ("SIYI Web UI", "journalctl -u siyi-webui -n 250 --no-pager"),
        ("MAVLink Router", "journalctl -u mavlink-router -n 180 --no-pager"),
        ("SIYI Services", "journalctl -u 'siyi-*' -n 220 --no-pager"),
        ("System Errors", "journalctl -p warning..alert -n 120 --no-pager"),
    ]

    for title, cmd in sources:
        parts.append(f'\n\n===== {title} =====\n')
        parts.append(_safe_cmd(cmd))

    return Response("".join(parts), mimetype="text/plain")


@app.route("/logs")
def logs_page():
    return f"""
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SIYI Logs</title>
<style>
body {{
  margin: 0;
  background: #101418;
  color: #e8eef5;
  font-family: Arial, sans-serif;
}}
.header {{
  padding: 14px 18px;
  background: #171d24;
  border-bottom: 1px solid #2b3440;
  display: flex;
  gap: 12px;
  align-items: center;
  flex-wrap: wrap;
}}
h1 {{
  margin: 0;
  font-size: 20px;
}}
button, a.btn {{
  background: #253244;
  color: #e8eef5;
  border: 1px solid #3c4b5f;
  border-radius: 8px;
  padding: 8px 11px;
  text-decoration: none;
  cursor: pointer;
}}
button:hover, a.btn:hover {{
  background: #314158;
}}
.status {{
  opacity: .8;
  font-size: 13px;
}}
.version {{
  font-size: 12px;
  opacity: 0.6;
}}
#logs {{
  height: calc(100vh - 72px);
  overflow-y: auto;
  padding: 14px;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: Menlo, Consolas, monospace;
  font-size: 12px;
  line-height: 1.35;
}}
.err {{ color: #ff9b9b; }}
.warn {{ color: #ffd28a; }}
.ok {{ color: #a8ffbf; }}
</style>
</head>
<body>
<div class="header">
  <h1>SIYI Logs</h1>
  <span class="version">v{VERSION}</span>
  <button onclick="loadLogs(false)">Refresh</button>
  <button onclick="toggleFollow()" id="followBtn">Auto-follow: ON</button>
  <button onclick="copyLogs()">Copy diagnostics</button>
  <a class="btn" href="/" >Back</a>
  <span class="status" id="status">Loading…</span>
</div>

<pre id="logs"></pre>

<script>
let follow = true;
let timer = null;

function colorize(t) {{
  return t
    .replace(/(error|failed|traceback|exception|critical)/gi, '<span class="err">$1</span>')
    .replace(/(warning|warn)/gi, '<span class="warn">$1</span>')
    .replace(/(active \\(running\\)|started|success)/gi, '<span class="ok">$1</span>');
}}

async function loadLogs(auto) {{
  const box = document.getElementById('logs');
  const status = document.getElementById('status');
  try {{
    const r = await fetch('/api/logs?ts=' + Date.now());
    const t = await r.text();
    box.innerHTML = colorize(t);
    status.innerText = 'Updated: ' + new Date().toLocaleTimeString();
    if (follow) box.scrollTop = box.scrollHeight;
  }} catch(e) {{
    status.innerText = 'Failed to load logs';
    if (!auto) alert(e);
  }}
}}

function toggleFollow() {{
  follow = !follow;
  document.getElementById('followBtn').innerText = 'Auto-follow: ' + (follow ? 'ON' : 'OFF');
}}

function copyLogs() {{
  navigator.clipboard.writeText(document.getElementById('logs').innerText);
  document.getElementById('status').innerText = 'Copied diagnostics';
}}

loadLogs(false);
timer = setInterval(() => loadLogs(true), 3000);
</script>
</body>
</html>
"""
# FULL_LOGS_PAGE_FIX_END

# FORCE_LOGS2_PAGE_START
from flask import Response
import subprocess
import shlex

def _logs2_cmd(cmd, timeout=5):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT, timeout=timeout)
    except Exception as e:
        return str(e)

@app.route("/api/logs2")
def api_logs2():
    out = []
    checks = [
        ("SIYI WEBUI", "journalctl -u siyi-webui -n 300 --no-pager"),
        ("MAVLINK ROUTER", "journalctl -u mavlink-router -n 200 --no-pager"),
        ("ALL SIYI SERVICES", "journalctl -u 'siyi-*' -n 250 --no-pager"),
        ("SYSTEM WARNINGS", "journalctl -p warning..alert -n 150 --no-pager"),
    ]
    for title, cmd in checks:
        out.append("\\n\\n==================== " + title + " ====================\\n")
        out.append(_logs2_cmd(cmd))
    return Response("".join(out), mimetype="text/plain")

@app.route("/logs2")
def logs2_page():
    return """
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SIYI Logs v{VERSION}</title>
<style>
body{margin:0;background:#101418;color:#e8eef5;font-family:Arial,sans-serif}
.header{padding:14px 18px;background:#171d24;border-bottom:1px solid #2b3440;display:flex;gap:12px;align-items:center;flex-wrap:wrap}
h1{margin:0;font-size:20px}
.badge{font-size:12px;opacity:.7}
button,a{background:#253244;color:#e8eef5;border:1px solid #3c4b5f;border-radius:8px;padding:8px 11px;text-decoration:none;cursor:pointer}
button:hover,a:hover{background:#314158}
#status{opacity:.75;font-size:13px}
#logs{height:calc(100vh - 72px);overflow-y:auto;padding:14px;white-space:pre-wrap;word-break:break-word;font-family:Menlo,Consolas,monospace;font-size:12px;line-height:1.35}
.err{color:#ff9b9b;font-weight:bold}
.warn{color:#ffd28a;font-weight:bold}
.ok{color:#a8ffbf;font-weight:bold}
</style>
</head>
<body>
<div class="header">
  <h1>SIYI Logs</h1>
  <span class="badge">v{VERSION} / forced logs2 page</span>
  <button onclick="loadLogs()">Refresh</button>
  <button onclick="toggleFollow()" id="followBtn">Auto-follow: ON</button>
  <button onclick="copyLogs()">Copy diagnostics</button>
  <a href="/">Back</a>
  <span id="status">Loading…</span>
</div>
<pre id="logs"></pre>
<script>
let follow=true;
function colorize(t){
  return t
    .replace(/(error|failed|failure|traceback|exception|critical)/gi,'<span class="err">$1</span>')
    .replace(/(warning|warn)/gi,'<span class="warn">$1</span>')
    .replace(/(active \\(running\\)|started|success|online)/gi,'<span class="ok">$1</span>');
}
async function loadLogs(){
  const box=document.getElementById('logs');
  const status=document.getElementById('status');
  try{
    const r=await fetch('/api/logs2?t='+Date.now());
    const t=await r.text();
    box.innerHTML=colorize(t);
    status.innerText='Updated: '+new Date().toLocaleTimeString();
    if(follow) box.scrollTop=box.scrollHeight;
  }catch(e){
    status.innerText='Failed to load logs';
  }
}
function toggleFollow(){
  follow=!follow;
  document.getElementById('followBtn').innerText='Auto-follow: '+(follow?'ON':'OFF');
}
function copyLogs(){
  navigator.clipboard.writeText(document.getElementById('logs').innerText);
  document.getElementById('status').innerText='Copied diagnostics';
}
loadLogs();
setInterval(loadLogs,3000);
</script>
</body>
</html>
"""
# FORCE_LOGS2_PAGE_END
