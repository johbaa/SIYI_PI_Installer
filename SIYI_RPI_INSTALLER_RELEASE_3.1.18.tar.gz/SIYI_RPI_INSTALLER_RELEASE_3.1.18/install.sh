#!/usr/bin/env bash
set -euo pipefail

PAYLOAD_DIR="$(cd "$(dirname "$0")" && pwd)"
VERSION_FILE="$PAYLOAD_DIR/release_version"

if [ ! -s "$VERSION_FILE" ]; then
  echo "INSTALL FAILED: missing or empty package version file: $VERSION_FILE" >&2
  exit 1
fi

SIYI_INSTALL_VERSION="$(tr -d '[:space:]' < "$VERSION_FILE")"
if [[ ! "$SIYI_INSTALL_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  echo "INSTALL FAILED: invalid package version: $SIYI_INSTALL_VERSION" >&2
  exit 1
fi

cd "$PAYLOAD_DIR"

# === SIYI FLAPS CONFIG START ===
SIYI_FLAPS_INSTALL_DIR="$PAYLOAD_DIR"

sudo mkdir -p /etc/siyi

if [ ! -e /etc/siyi/flaps.json ] &&
   [ -f "$SIYI_FLAPS_INSTALL_DIR/config/flaps.json" ]; then

    sudo install \
        -o pi \
        -g pi \
        -m 664 \
        "$SIYI_FLAPS_INSTALL_DIR/config/flaps.json" \
        /etc/siyi/flaps.json
fi
# === SIYI FLAPS CONFIG END ===

# === VIDEO SOURCE CONFIG START ===
SIYI_VIDEO_CONFIG_CREATED=0
if [ ! -e /etc/siyi/video_source.json ] && [ -f "$PAYLOAD_DIR/config/video_source.json" ]; then
  sudo install -o pi -g pi -m 664 "$PAYLOAD_DIR/config/video_source.json" /etc/siyi/video_source.json
  SIYI_VIDEO_CONFIG_CREATED=1
fi

# One-time migration when upgrading from a release that predates selectable
# video sources. This preserves the existing SIYI RTSP URL, transport,
# receiver latency and UDP port. Existing 3.1.18+ video settings are never
# modified here.
if [ "$SIYI_VIDEO_CONFIG_CREATED" -eq 1 ] && [ -s /etc/siyi/release_version ]; then
  SIYI_PREVIOUS_VERSION="$(tr -d '[:space:]' < /etc/siyi/release_version)"
  if python3 - "$SIYI_PREVIOUS_VERSION" <<'PYVERSION'
import re, sys
value=sys.argv[1]
if not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', value):
    raise SystemExit(1)
raise SystemExit(0 if tuple(map(int,value.split('.'))) < (3,1,17) else 1)
PYVERSION
  then
    sudo python3 - <<'PYVIDEO'
import json, os, pwd, grp, re, tempfile
from pathlib import Path
path=Path('/etc/siyi/video_source.json')
try:
    cfg=json.loads(path.read_text(encoding='utf-8'))
except Exception:
    raise SystemExit(0)
try:
    core=json.loads(Path('/home/pi/siyi-config.json').read_text(encoding='utf-8'))
except Exception:
    core={}
cfg.setdefault('siyi', {})
cfg.setdefault('udp', {})
cfg['source']='siyi_rtsp'
cfg['switch_mode']='warm'
if isinstance(core, dict):
    if core.get('camera_rtsp'):
        cfg['siyi']['url']=str(core['camera_rtsp'])
    if core.get('video_port'):
        try: cfg['udp']['port']=int(core['video_port'])
        except Exception: pass
old=Path('/etc/systemd/system/siyi-video-dual.service')
if old.exists():
    text=old.read_text(encoding='utf-8', errors='replace')
    m=re.search(r'location=([^ ]+)', text)
    if m: cfg['siyi']['url']=m.group(1)
    m=re.search(r'protocols=([^ ]+)', text)
    if m and m.group(1) in {'tcp','udp'}: cfg['siyi']['transport']=m.group(1)
    m=re.search(r'latency=([0-9]+)', text)
    if m: cfg['siyi']['latency_ms']=int(m.group(1))
    m=re.search(r'udpsink host=[^ ]+ port=([0-9]+)', text)
    if m: cfg['udp']['port']=int(m.group(1))
fd,tmp=tempfile.mkstemp(prefix='.video_source.',dir=str(path.parent))
try:
    with os.fdopen(fd,'w',encoding='utf-8') as handle:
        json.dump(cfg,handle,indent=2); handle.write('\n')
    os.chmod(tmp,0o664)
    os.chown(tmp,pwd.getpwnam('pi').pw_uid,grp.getgrnam('pi').gr_gid)
    os.replace(tmp,path)
finally:
    if os.path.exists(tmp): os.unlink(tmp)
PYVIDEO
  fi
fi
# === VIDEO SOURCE CONFIG END ===


# === HARD GATE: /etc/siyi must be writable by WebUI user ===
echo "[$SIYI_INSTALL_VERSION] Preflight: fixing /etc/siyi permissions"
sudo mkdir -p /etc/siyi
sudo touch /etc/siyi/zerotier_api_token
sudo touch /etc/siyi/zerotier_config.json
sudo touch /etc/siyi/setup_complete.json
sudo touch /etc/siyi/button_safety.json

if [ ! -s /etc/siyi/setup_complete.json ]; then
  echo '{"complete": false}' | sudo tee /etc/siyi/setup_complete.json >/dev/null
fi

sudo chown -R pi:pi /etc/siyi || true
sudo chmod 664 /etc/siyi/button_safety.json || true
chmod 664 /etc/siyi/zerotier_api_token || true
sudo chmod 664 /etc/siyi/zerotier_config.json || true
sudo chmod 664 /etc/siyi/setup_complete.json || true

sudo -u pi test -w /etc/siyi/zerotier_api_token || {
  echo "INSTALL FAILED: pi cannot write /etc/siyi/zerotier_api_token"
  exit 1
}
sudo -u pi test -w /etc/siyi/zerotier_config.json || {
  echo "INSTALL FAILED: pi cannot write /etc/siyi/zerotier_config.json"
  exit 1
}
sudo -u pi test -w /etc/siyi/setup_complete.json || {
  echo "INSTALL FAILED: pi cannot write /etc/siyi/setup_complete.json"
  exit 1
}
# === end hard gate ===

# === UART PREFLIGHT / END-OF-INSTALL REBOOT ===
SIYI_UART_REBOOT_REQUIRED=0
export SIYI_UART_REBOOT_REQUIRED

if [ ! -e /dev/serial0 ]; then
  echo "=== SIYI $SIYI_INSTALL_VERSION UART PREFLIGHT ==="
  echo "Hardware UART missing. Enabling UART now; reboot will happen after installation completes."

  sudo raspi-config nonint do_serial_hw 0

  SIYI_UART_REBOOT_REQUIRED=1
  export SIYI_UART_REBOOT_REQUIRED
fi
# === END UART PREFLIGHT ===

POST_LOG="/home/pi/siyi_install_${SIYI_INSTALL_VERSION}_postdeploy_$(date +%Y%m%d_%H%M%S).log"

echo "=== SIYI INSTALLER $SIYI_INSTALL_VERSION ==="
echo "=== RUN ORIGINAL INSTALLER ==="
bash "$PAYLOAD_DIR/install_original_pre_231.sh"
if [ -f /tmp/siyi_webui_update.log ]; then
  sudo chown root:pi /tmp/siyi_webui_update.log 2>/dev/null || true
  sudo chmod 664 /tmp/siyi_webui_update.log 2>/dev/null || true
fi

echo "Core installer returned successfully."
sync

{
echo "=== SIYI $SIYI_INSTALL_VERSION POSTDEPLOY START ==="
date

echo "=== RUNTIME PERMISSION FIX ==="
sudo mkdir -p /etc/siyi

sudo touch /etc/siyi/zerotier_api_token
sudo touch /etc/siyi/zerotier_config.json
sudo touch /etc/siyi/setup_complete.json
sudo touch /etc/siyi/button_safety.json

if [ ! -s /etc/siyi/zerotier_config.json ]; then
  echo '{}' | sudo tee /etc/siyi/zerotier_config.json >/dev/null
fi

if [ ! -s /etc/siyi/setup_complete.json ]; then
  echo '{"complete": false}' | sudo tee /etc/siyi/setup_complete.json >/dev/null
fi

sudo chown pi:pi /etc/siyi/zerotier_api_token /etc/siyi/zerotier_config.json /etc/siyi/setup_complete.json
sudo chmod 600 /etc/siyi/zerotier_api_token
sudo chmod 664 /etc/siyi/zerotier_config.json /etc/siyi/setup_complete.json

touch /tmp/siyi_webui_last_action
chown pi:pi /tmp/siyi_webui_last_action || true

echo "=== REQUIRED RUNTIME DEPLOY ==="

echo "=== $SIYI_INSTALL_VERSION SUDOERS DEPLOY ==="
sudo install -o root -g root -m 440 "$PAYLOAD_DIR/files/etc/sudoers.d/siyi-webui" /etc/sudoers.d/siyi-webui
sudo visudo -cf /etc/sudoers.d/siyi-webui

sudo install -o root -g root -m 755 "$PAYLOAD_DIR/files/usr/local/sbin/siyi-github-upgrade-launch" /usr/local/sbin/siyi-github-upgrade-launch
sudo install -o root -g root -m 755 "$PAYLOAD_DIR/files/usr/local/sbin/siyi-github-upgrade-worker" /usr/local/sbin/siyi-github-upgrade-worker
sudo install -o root -g root -m 755 "$PAYLOAD_DIR/files/usr/local/sbin/siyi-video-source-control" /usr/local/sbin/siyi-video-source-control
sudo install -o root -g root -m 755 "$PAYLOAD_DIR/files/usr/local/bin/siyi-video-source" /usr/local/bin/siyi-video-source
sudo install -o root -g root -m 755 "$PAYLOAD_DIR/files/usr/local/bin/siyi-video-udp-forward" /usr/local/bin/siyi-video-udp-forward
sudo install -o root -g root -m 644 "$PAYLOAD_DIR/services/siyi-video-source.service" /etc/systemd/system/siyi-video-source.service
sudo install -o root -g root -m 644 "$PAYLOAD_DIR/services/siyi-video-dual.service" /etc/systemd/system/siyi-video-dual.service
sudo install -d -o root -g root -m 755 /var/log
sudo touch /var/log/siyi-video-source.log
sudo chown pi:pi /var/log/siyi-video-source.log
sudo chmod 664 /var/log/siyi-video-source.log

sudo install -d -o pi -g pi -m 750 /var/lib/siyi-param-import
sudo install -d -o pi -g pi -m 750 /var/lib/siyi-param-import/sessions
sudo install -d -o pi -g pi -m 750 /var/backups/siyi-param-import
sudo install -m 755 "$PAYLOAD_DIR/files/usr/local/bin/siyi-paramd" /usr/local/bin/siyi-paramd

sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/siyi_param_full_cache.py" /home/pi/siyi_param_full_cache.py
sudo install -o root -g root -m 755 "$PAYLOAD_DIR/siyi_param_metadata_refresh.py" /home/pi/siyi_param_metadata_refresh.py
sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/siyi_param_read_one.py" /home/pi/siyi_param_read_one.py
sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/siyi_param_write_one.py" /home/pi/siyi_param_write_one.py
sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/siyi_param_refresh_wrapper.sh" /home/pi/siyi_param_refresh_wrapper.sh

sudo install -m 644 "$PAYLOAD_DIR/services/siyi-webui.service" /etc/systemd/system/siyi-webui.service
sudo install -m 644 "$PAYLOAD_DIR/files/etc/systemd/system/siyi-paramd.service" /etc/systemd/system/siyi-paramd.service
sudo install -d -m 755 /usr/local/etc/mediamtx
sudo install -m 644 "$PAYLOAD_DIR/mediamtx.yml" /usr/local/etc/mediamtx/mediamtx.yml
sudo install -m 644 "$PAYLOAD_DIR/services/mediamtx.service" /etc/systemd/system/mediamtx.service
sudo install -m 644 "$PAYLOAD_DIR/services/siyi-rtsp-redirect.service" /etc/systemd/system/siyi-rtsp-redirect.service

echo "=== $SIYI_INSTALL_VERSION DEFAULT SIYI CONFIG DEPLOY ==="
sudo mkdir -p /etc/siyi

for f in endpoints.json cpu_temp_voice.json gimbal_zero.json gimbal_presets.json gimbal_virtual_config.json button_safety.json; do
  if [ -f "$PAYLOAD_DIR/config/$f" ]; then
    sudo cp -f "$PAYLOAD_DIR/config/$f" "/etc/siyi/$f"
    sudo chown pi:pi "/etc/siyi/$f"
    sudo chmod 664 "/etc/siyi/$f"
  fi
done

# Ensure JSON defaults exist even if source files were empty/missing
[ -s /etc/siyi/endpoints.json ] || echo "[]" | sudo tee /etc/siyi/endpoints.json >/dev/null
[ -s /etc/siyi/cpu_temp_voice.json ] || echo '{"enabled": false, "interval": 60}' | sudo tee /etc/siyi/cpu_temp_voice.json >/dev/null
[ -s /etc/siyi/gimbal_zero.json ] || echo '{}' | sudo tee /etc/siyi/gimbal_zero.json >/dev/null
[ -s /etc/siyi/gimbal_presets.json ] || echo '[]' | sudo tee /etc/siyi/gimbal_presets.json >/dev/null
[ -s /etc/siyi/gimbal_virtual_config.json ] || echo '{}' | sudo tee /etc/siyi/gimbal_virtual_config.json >/dev/null
[ -s /etc/siyi/video_source.json ] || sudo cp -f "$PAYLOAD_DIR/config/video_source.json" /etc/siyi/video_source.json
sudo chown pi:pi /etc/siyi/*.json || true
sudo chmod 664 /etc/siyi/*.json || true

# Match MediaMTX to the preserved selected source before services start.
sudo /usr/local/sbin/siyi-video-source-control configure

echo "=== $SIYI_INSTALL_VERSION ENDPOINT APPLY ==="
sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/apply_siyi_endpoints.sh" /home/pi/apply_siyi_endpoints.sh
/home/pi/apply_siyi_endpoints.sh || true

printf "%s\n" "$SIYI_INSTALL_VERSION" | sudo tee /etc/siyi/release_version >/dev/null

sudo systemctl daemon-reload
sudo systemctl enable siyi-webui.service
sudo systemctl enable siyi-paramd.service
sudo systemctl enable mediamtx.service
sudo systemctl enable siyi-rtsp-redirect.service
sudo systemctl enable siyi-video-source.service
sudo systemctl enable siyi-video-dual.service

# Dependency-safe restart order
sudo systemctl restart mavlink-router || true
sleep 2
sudo systemctl restart siyi-button-bridge || true
sudo systemctl restart siyi-paramd.service
sudo systemctl restart mediamtx.service
sudo systemctl restart siyi-rtsp-redirect.service || true
sudo systemctl restart siyi-video-source.service
sudo systemctl restart siyi-video-dual.service

sudo systemctl restart siyi-webui.service

echo "=== PARAM METADATA CACHE GENERATION ==="
if [ -f /home/pi/siyi_param_metadata_refresh.py ]; then
  timeout 60 sudo /usr/bin/python3 /home/pi/siyi_param_metadata_refresh.py || true
fi

if [ -x /home/pi/siyi-bridge-venv/bin/python ] && [ -f /home/pi/siyi_param_full_cache.py ]; then
  timeout 120 /home/pi/siyi-bridge-venv/bin/python /home/pi/siyi_param_full_cache.py || true
fi

if [ -s /tmp/siyi_param_cache.json ]; then
  sudo cp -f /tmp/siyi_param_cache.json /etc/siyi/param_metadata_cache.json
  sudo chmod 644 /etc/siyi/param_metadata_cache.json
  echo "PARAM_METADATA_CACHE_INSTALLED"
else
  echo "WARNING_PARAM_METADATA_CACHE_NOT_CREATED"
fi


echo "=== $SIYI_INSTALL_VERSION HARD POSTDEPLOY VALIDATION ==="


test -x /usr/local/bin/siyi-paramd
test -f /etc/systemd/system/siyi-paramd.service
test -f /etc/sudoers.d/siyi-webui
test -x /usr/local/bin/siyi-video-source
test -x /usr/local/bin/siyi-video-udp-forward
test -x /usr/local/sbin/siyi-video-source-control
test -s /etc/siyi/video_source.json
test -s /usr/local/etc/mediamtx/mediamtx.yml
systemctl is-enabled siyi-video-source.service >/dev/null
systemctl is-enabled siyi-video-dual.service >/dev/null

systemctl is-enabled siyi-paramd.service >/dev/null
systemctl is-active --quiet siyi-paramd.service

curl -fsS --max-time 5 http://127.0.0.1:8765/health >/dev/null

test -s /etc/siyi/param_metadata_cache.json

python3 - <<'PYMETA'
import json
from pathlib import Path
paths = [
    Path('/etc/siyi/arduplane_param_metadata.json'),
    Path('/etc/siyi/param_metadata_cache.json'),
]
valid = False
for path in paths:
    try:
        raw = json.loads(path.read_text(encoding='utf-8'))
        entry = (raw.get('params') or {}).get('AIRSPEED_CRUISE') or {}
        if entry.get('humanName') or entry.get('documentation') or entry.get('fields') or entry.get('values'):
            valid = True
            print('PARAM_METADATA_LOOKUP_READY', path)
            break
    except Exception:
        pass
if not valid:
    print('WARNING_PARAM_METADATA_DESCRIPTIONS_NOT_AVAILABLE')
PYMETA

sudo -n systemctl restart mavlink-router
sudo -n systemctl restart siyi-button-bridge
sudo -n nmcli dev status >/dev/null

echo "=== $SIYI_INSTALL_VERSION HARD POSTDEPLOY VALIDATION OK ==="

echo "=== SIYI $SIYI_INSTALL_VERSION POSTDEPLOY COMPLETE ==="
date
} >> "$POST_LOG" 2>&1

# Print the full completion screen for a manual install. During a WebUI
# upgrade, the worker owns the concise final status shown in the browser.
if [ "${SIYI_WEBUI_UPGRADE:-0}" = "1" ]; then
  echo "Post-deployment validation complete."
  echo "Post-deployment log: ${POST_LOG}"
  if [ "${SIYI_UART_REBOOT_REQUIRED:-0}" = "1" ]; then
    echo "Reboot required: the Raspberry Pi hardware UART was enabled."
  fi
else
  if [ -n "$SSH_CONNECTION" ]; then
      CLIENT_IP="$(echo "$SSH_CONNECTION" | awk '{print $1}')"
      PRIMARY_IP="$(ip route get "$CLIENT_IP" 2>/dev/null | sed -n 's/.* src \([^ ]*\).*/\1/p')"
  fi

  if [ -z "$PRIMARY_IP" ]; then
      PRIMARY_IP="$(hostname -I | awk '{print $1}')"
  fi
  if [ -z "${PRIMARY_IP:-}" ]; then
    PRIMARY_IP="installertest.local"
  fi

  echo
  echo "========================================"
  echo "✅ SIYI Installer $SIYI_INSTALL_VERSION complete"
  echo "========================================"
  echo
  echo "Web UI:"
  echo "  http://${PRIMARY_IP}:8080"
  echo
  echo "Log:"
  echo "  ${POST_LOG}"
  echo

  echo "========================================"
  echo "IMPORTANT"
  echo "========================================"
  echo
  echo "If this is a fresh Raspberry Pi installation,"
  echo "please reboot the Raspberry Pi before using"
  echo "the SIYI system."
  echo
  echo "Run:"
  echo "  sudo reboot"
  echo

  if [ "${SIYI_UART_REBOOT_REQUIRED:-0}" = "1" ]; then
    echo "Hardware UART has been enabled."
    echo "The Raspberry Pi must reboot once before MAVLink UART telemetry is available."
    echo
    read -r -p "Reboot now? [Y/n] " answer
    answer="${answer:-Y}"
    case "$answer" in
      y|Y|yes|YES|Yes)
        echo "Rebooting now..."
        sleep 3
        sudo reboot
        ;;
      *)
        echo "Reboot skipped. Reboot manually later with: sudo reboot"
        ;;
    esac
  fi
fi

exit 0
