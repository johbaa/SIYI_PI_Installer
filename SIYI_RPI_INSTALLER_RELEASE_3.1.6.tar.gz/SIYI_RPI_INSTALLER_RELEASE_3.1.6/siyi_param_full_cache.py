#!/usr/bin/env python3
import json
import sys
import os
import time
import urllib.request
import xml.etree.ElementTree as ET
from pymavlink import mavutil

CACHE="/tmp/siyi_param_cache.json"
RECENT_WRITES="/tmp/siyi_param_recent_writes.json"
META="/tmp/ardupilot_arduplane_apm.pdef.xml"
META_URL="https://autotest.ardupilot.org/Parameters/ArduPlane/apm.pdef.xml"

def param_group(name):
    if "_" in name:
        return name.split("_", 1)[0]
    for prefix in ("PTCH2SRV", "STEER2SRV"):
        if name.startswith(prefix):
            return prefix
    return "Misc"

def load_metadata():
    meta = {}
    try:
        if not os.path.exists(META) or os.path.getsize(META) < 1000:
            urllib.request.urlretrieve(META_URL, META)

        root = ET.parse(META).getroot()

        for p in root.findall(".//param"):
            raw_name = p.attrib.get("name", "")
            name = raw_name.split(":")[-1]
            if not name:
                continue

            values = {}
            fields = {}

            for v in p.findall("values/value"):
                code = v.attrib.get("code")
                text = (v.text or "").strip()
                if code is not None and text:
                    values[str(code)] = text

            for f in p.findall("field"):
                fname = f.attrib.get("name", "")
                ftext = (f.text or "").strip()
                if fname and ftext:
                    fields[fname] = ftext

            meta[name] = {
                "humanName": p.attrib.get("humanName", ""),
                "documentation": p.attrib.get("documentation", ""),
                "user": p.attrib.get("user", ""),
                "values": values,
                "fields": fields,
            }

    except Exception as e:
        meta["_metadata_error"] = str(e)

    return meta

def enum_label(meta_entry, value):
    try:
        if not meta_entry:
            return ""

        values = meta_entry.get("values") or {}
        if not values:
            return ""

        keys = [
            str(int(float(value))),
            str(float(value)),
            str(value),
        ]

        for k in keys:
            if k in values:
                return values[k]

    except Exception:
        pass

    return ""

def main():
    metadata = load_metadata()

    m = mavutil.mavlink_connection(
        "tcp:127.0.0.1:5760",
        source_system=251,
        source_component=192
    )

    print("Waiting for heartbeat...")
    hb = m.wait_heartbeat(timeout=15)
    if not hb:
        raise SystemExit("NO_HEARTBEAT")

    print(f"Heartbeat OK: system={m.target_system} component={m.target_component}")

    params = {}
    expected = None
    last_rx = time.time()

    print("Requesting full parameter list...")
    m.mav.param_request_list_send(m.target_system, m.target_component)

    deadline = time.time() + 90

    while time.time() < deadline:
        msg = m.recv_match(type="PARAM_VALUE", blocking=True, timeout=1)

        if not msg:
            if expected and len(params) >= expected:
                break
            if time.time() - last_rx > 8 and params:
                break
            continue

        last_rx = time.time()

        pid = msg.param_id
        if isinstance(pid, bytes):
            pid = pid.decode(errors="ignore")
        name = pid.strip("\x00")

        if not name:
            continue

        expected = int(msg.param_count)

        meta = metadata.get(name, {})
        label = enum_label(meta, msg.param_value)

        params[name] = {
            "name": name,
            "value": msg.param_value,
            "value_label": label,
            "type": int(msg.param_type),
            "index": int(msg.param_index),
            "count": int(msg.param_count),
            "group": param_group(name),
            "humanName": meta.get("humanName", ""),
            "documentation": meta.get("documentation", ""),
            "user": meta.get("user", ""),
            "fields": meta.get("fields", {}),
            "values": meta.get("values", {}),
        }

        if len(params) % 100 == 0:
            print(f"Received {len(params)}/{expected}")

        if expected and len(params) >= expected:
            break

    # Apply recent verified single-param writes.
    # ArduPilot full PARAM_REQUEST_LIST can briefly return stale values
    # right after PARAM_SET, while direct PARAM_REQUEST_READ is already correct.
    try:
        recent=json.load(open(RECENT_WRITES))
    except Exception:
        recent={}

    now=int(time.time())
    kept_recent={}

    for pname, r in recent.items():
        try:
            age = now - int(r.get("ts", 0))
            if age > 10:
                continue

            if pname in params:
                actual=float(r.get("value"))
                params[pname]["value"] = actual

                values = params[pname].get("values") or {}
                label = ""
                for k in [str(int(actual)), str(actual)]:
                    if k in values:
                        label = values[k]
                        break

                params[pname]["value_label"] = label
                params[pname]["recent_write_override"] = True
                kept_recent[pname] = r
        except Exception:
            pass

    try:
        tmp = RECENT_WRITES + ".tmp"
        with open(tmp, "w") as f:
            json.dump(kept_recent, f, indent=2)
        os.replace(tmp, RECENT_WRITES)
    except Exception:
        pass

    if expected and len(params) < expected:
        print(f"INCOMPLETE PARAM REFRESH: {len(params)}/{expected}. Keeping previous cache.")
        sys.exit(2)

    out = {
        "created": int(time.time()),
        "source": "mavlink",
        "metadata_url": META_URL,
        "metadata_error": metadata.get("_metadata_error", ""),
        "expected_count": expected,
        "received_count": len(params),
        "params": params,
    }

    with open(CACHE, "w") as f:
        json.dump(out, f, indent=2)

    print(f"Saved {CACHE}")
    print(f"Params received: {len(params)}/{expected}")

if __name__ == "__main__":
    main()
