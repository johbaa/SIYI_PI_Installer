#!/usr/bin/env bash
set -euo pipefail

PAYLOAD_DIR="$(cd "$(dirname "$0")" && pwd)"
VERSION_FILE="$PAYLOAD_DIR/release_version"

if [ ! -s "$VERSION_FILE" ]; then
  echo "INSTALL FAILED: missing or empty package version file: $VERSION_FILE" >&2
  exit 1
fi

SIYI_INSTALL_VERSION="$(tr -d '[:space:]' < "$VERSION_FILE")"
if [[ ! "$SIYI_INSTALL_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  echo "INSTALL FAILED: invalid package version: $SIYI_INSTALL_VERSION" >&2
  exit 1
fi

cd "$PAYLOAD_DIR"

# === SIYI FLAPS CONFIG START ===
SIYI_FLAPS_INSTALL_DIR="$PAYLOAD_DIR"

sudo mkdir -p /etc/siyi

if [ ! -e /etc/siyi/flaps.json ] &&
   [ -f "$SIYI_FLAPS_INSTALL_DIR/config/flaps.json" ]; then

    sudo install \
        -o pi \
        -g pi \
        -m 664 \
        "$SIYI_FLAPS_INSTALL_DIR/config/flaps.json" \
        /etc/siyi/flaps.json
fi
# === SIYI FLAPS CONFIG END ===


# === HARD GATE: /etc/siyi must be writable by WebUI user ===
echo "[$SIYI_INSTALL_VERSION] Preflight: fixing /etc/siyi permissions"
sudo mkdir -p /etc/siyi
sudo touch /etc/siyi/zerotier_api_token
sudo touch /etc/siyi/zerotier_config.json
sudo touch /etc/siyi/setup_complete.json
sudo touch /etc/siyi/button_safety.json

if [ ! -s /etc/siyi/setup_complete.json ]; then
  echo '{"complete": false}' | sudo tee /etc/siyi/setup_complete.json >/dev/null
fi

sudo chown -R pi:pi /etc/siyi || true
sudo chmod 664 /etc/siyi/button_safety.json || true
chmod 664 /etc/siyi/zerotier_api_token || true
sudo chmod 664 /etc/siyi/zerotier_config.json || true
sudo chmod 664 /etc/siyi/setup_complete.json || true

sudo -u pi test -w /etc/siyi/zerotier_api_token || {
  echo "INSTALL FAILED: pi cannot write /etc/siyi/zerotier_api_token"
  exit 1
}
sudo -u pi test -w /etc/siyi/zerotier_config.json || {
  echo "INSTALL FAILED: pi cannot write /etc/siyi/zerotier_config.json"
  exit 1
}
sudo -u pi test -w /etc/siyi/setup_complete.json || {
  echo "INSTALL FAILED: pi cannot write /etc/siyi/setup_complete.json"
  exit 1
}
# === end hard gate ===

# === UART PREFLIGHT / END-OF-INSTALL REBOOT ===
SIYI_UART_REBOOT_REQUIRED=0
export SIYI_UART_REBOOT_REQUIRED

if [ ! -e /dev/serial0 ]; then
  echo "=== SIYI $SIYI_INSTALL_VERSION UART PREFLIGHT ==="
  echo "Hardware UART missing. Enabling UART now; reboot will happen after installation completes."

  sudo raspi-config nonint do_serial_hw 0

  SIYI_UART_REBOOT_REQUIRED=1
  export SIYI_UART_REBOOT_REQUIRED
fi
# === END UART PREFLIGHT ===

POST_LOG="/home/pi/siyi_install_${SIYI_INSTALL_VERSION}_postdeploy_$(date +%Y%m%d_%H%M%S).log"

echo "=== SIYI INSTALLER $SIYI_INSTALL_VERSION ==="
echo "=== RUN ORIGINAL INSTALLER ==="
bash "$PAYLOAD_DIR/install_original_pre_231.sh"
if [ -f /tmp/siyi_webui_update.log ]; then
  sudo chown root:pi /tmp/siyi_webui_update.log 2>/dev/null || true
  sudo chmod 664 /tmp/siyi_webui_update.log 2>/dev/null || true
fi

echo "Core installer returned successfully."
sync

{
echo "=== SIYI $SIYI_INSTALL_VERSION POSTDEPLOY START ==="
date

echo "=== RUNTIME PERMISSION FIX ==="
sudo mkdir -p /etc/siyi

sudo touch /etc/siyi/zerotier_api_token
sudo touch /etc/siyi/zerotier_config.json
sudo touch /etc/siyi/setup_complete.json
sudo touch /etc/siyi/button_safety.json

if [ ! -s /etc/siyi/zerotier_config.json ]; then
  echo '{}' | sudo tee /etc/siyi/zerotier_config.json >/dev/null
fi

if [ ! -s /etc/siyi/setup_complete.json ]; then
  echo '{"complete": false}' | sudo tee /etc/siyi/setup_complete.json >/dev/null
fi

sudo chown pi:pi /etc/siyi/zerotier_api_token /etc/siyi/zerotier_config.json /etc/siyi/setup_complete.json
sudo chmod 600 /etc/siyi/zerotier_api_token
sudo chmod 664 /etc/siyi/zerotier_config.json /etc/siyi/setup_complete.json

touch /tmp/siyi_webui_last_action
chown pi:pi /tmp/siyi_webui_last_action || true

echo "=== REQUIRED RUNTIME DEPLOY ==="

echo "=== $SIYI_INSTALL_VERSION SUDOERS DEPLOY ==="
sudo install -o root -g root -m 440 "$PAYLOAD_DIR/files/etc/sudoers.d/siyi-webui" /etc/sudoers.d/siyi-webui
sudo visudo -cf /etc/sudoers.d/siyi-webui

sudo install -o root -g root -m 755 "$PAYLOAD_DIR/files/usr/local/sbin/siyi-github-upgrade-launch" /usr/local/sbin/siyi-github-upgrade-launch
sudo install -o root -g root -m 755 "$PAYLOAD_DIR/files/usr/local/sbin/siyi-github-upgrade-worker" /usr/local/sbin/siyi-github-upgrade-worker

sudo install -m 755 "$PAYLOAD_DIR/files/usr/local/bin/siyi-paramd" /usr/local/bin/siyi-paramd

sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/siyi_param_full_cache.py" /home/pi/siyi_param_full_cache.py
sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/siyi_param_read_one.py" /home/pi/siyi_param_read_one.py
sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/siyi_param_write_one.py" /home/pi/siyi_param_write_one.py
sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/siyi_param_refresh_wrapper.sh" /home/pi/siyi_param_refresh_wrapper.sh

sudo install -m 644 "$PAYLOAD_DIR/services/siyi-webui.service" /etc/systemd/system/siyi-webui.service
sudo install -m 644 "$PAYLOAD_DIR/files/etc/systemd/system/siyi-paramd.service" /etc/systemd/system/siyi-paramd.service

echo "=== $SIYI_INSTALL_VERSION DEFAULT SIYI CONFIG DEPLOY ==="
sudo mkdir -p /etc/siyi

for f in endpoints.json cpu_temp_voice.json gimbal_zero.json gimbal_presets.json gimbal_virtual_config.json button_safety.json; do
  if [ -f "$PAYLOAD_DIR/config/$f" ]; then
    sudo cp -f "$PAYLOAD_DIR/config/$f" "/etc/siyi/$f"
    sudo chown pi:pi "/etc/siyi/$f"
    sudo chmod 664 "/etc/siyi/$f"
  fi
done

# Ensure JSON defaults exist even if source files were empty/missing
[ -s /etc/siyi/endpoints.json ] || echo "[]" | sudo tee /etc/siyi/endpoints.json >/dev/null
[ -s /etc/siyi/cpu_temp_voice.json ] || echo '{"enabled": false, "interval": 60}' | sudo tee /etc/siyi/cpu_temp_voice.json >/dev/null
[ -s /etc/siyi/gimbal_zero.json ] || echo '{}' | sudo tee /etc/siyi/gimbal_zero.json >/dev/null
[ -s /etc/siyi/gimbal_presets.json ] || echo '[]' | sudo tee /etc/siyi/gimbal_presets.json >/dev/null
[ -s /etc/siyi/gimbal_virtual_config.json ] || echo '{}' | sudo tee /etc/siyi/gimbal_virtual_config.json >/dev/null
sudo chown pi:pi /etc/siyi/*.json || true
sudo chmod 664 /etc/siyi/*.json || true

echo "=== $SIYI_INSTALL_VERSION ENDPOINT APPLY ==="
sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/apply_siyi_endpoints.sh" /home/pi/apply_siyi_endpoints.sh
/home/pi/apply_siyi_endpoints.sh || true

printf "%s\n" "$SIYI_INSTALL_VERSION" | sudo tee /etc/siyi/release_version >/dev/null

sudo systemctl daemon-reload
sudo systemctl enable siyi-webui.service
sudo systemctl enable siyi-paramd.service

# Dependency-safe restart order
sudo systemctl restart mavlink-router || true
sleep 2
sudo systemctl restart siyi-button-bridge || true
sudo systemctl restart siyi-paramd.service

sudo systemctl restart siyi-webui.service

echo "=== PARAM METADATA CACHE GENERATION ==="
if [ -x /home/pi/siyi-bridge-venv/bin/python ] && [ -f /home/pi/siyi_param_full_cache.py ]; then
  timeout 120 /home/pi/siyi-bridge-venv/bin/python /home/pi/siyi_param_full_cache.py || true
fi

if [ -s /tmp/siyi_param_cache.json ]; then
  sudo cp -f /tmp/siyi_param_cache.json /etc/siyi/param_metadata_cache.json
  sudo chmod 644 /etc/siyi/param_metadata_cache.json
  echo "PARAM_METADATA_CACHE_INSTALLED"
else
  echo "WARNING_PARAM_METADATA_CACHE_NOT_CREATED"
fi


echo "=== $SIYI_INSTALL_VERSION HARD POSTDEPLOY VALIDATION ==="


test -x /usr/local/bin/siyi-paramd
test -f /etc/systemd/system/siyi-paramd.service
test -f /etc/sudoers.d/siyi-webui

systemctl is-enabled siyi-paramd.service >/dev/null
systemctl is-active --quiet siyi-paramd.service

curl -fsS --max-time 5 http://127.0.0.1:8765/health >/dev/null

test -s /etc/siyi/param_metadata_cache.json

sudo -n systemctl restart mavlink-router
sudo -n systemctl restart siyi-button-bridge
sudo -n nmcli dev status >/dev/null

echo "=== $SIYI_INSTALL_VERSION HARD POSTDEPLOY VALIDATION OK ==="

echo "=== SIYI $SIYI_INSTALL_VERSION POSTDEPLOY COMPLETE ==="
date
} >> "$POST_LOG" 2>&1

# Print the full completion screen for a manual install. During a WebUI
# upgrade, the worker owns the concise final status shown in the browser.
if [ "${SIYI_WEBUI_UPGRADE:-0}" = "1" ]; then
  echo "Post-deployment validation complete."
  echo "Post-deployment log: ${POST_LOG}"
  if [ "${SIYI_UART_REBOOT_REQUIRED:-0}" = "1" ]; then
    echo "Reboot required: the Raspberry Pi hardware UART was enabled."
  fi
else
  if [ -n "$SSH_CONNECTION" ]; then
      CLIENT_IP="$(echo "$SSH_CONNECTION" | awk '{print $1}')"
      PRIMARY_IP="$(ip route get "$CLIENT_IP" 2>/dev/null | sed -n 's/.* src \([^ ]*\).*/\1/p')"
  fi

  if [ -z "$PRIMARY_IP" ]; then
      PRIMARY_IP="$(hostname -I | awk '{print $1}')"
  fi
  if [ -z "${PRIMARY_IP:-}" ]; then
    PRIMARY_IP="installertest.local"
  fi

  echo
  echo "========================================"
  echo "✅ SIYI Installer $SIYI_INSTALL_VERSION complete"
  echo "========================================"
  echo
  echo "Web UI:"
  echo "  http://${PRIMARY_IP}:8080"
  echo
  echo "Log:"
  echo "  ${POST_LOG}"
  echo

  echo "========================================"
  echo "IMPORTANT"
  echo "========================================"
  echo
  echo "If this is a fresh Raspberry Pi installation,"
  echo "please reboot the Raspberry Pi before using"
  echo "the SIYI system."
  echo
  echo "Run:"
  echo "  sudo reboot"
  echo

  if [ "${SIYI_UART_REBOOT_REQUIRED:-0}" = "1" ]; then
    echo "Hardware UART has been enabled."
    echo "The Raspberry Pi must reboot once before MAVLink UART telemetry is available."
    echo
    read -r -p "Reboot now? [Y/n] " answer
    answer="${answer:-Y}"
    case "$answer" in
      y|Y|yes|YES|Yes)
        echo "Rebooting now..."
        sleep 3
        sudo reboot
        ;;
      *)
        echo "Reboot skipped. Reboot manually later with: sudo reboot"
        ;;
    esac
  fi
fi

exit 0
