import threading
#!/usr/bin/env python3
import socket,time,subprocess,re,threading,subprocess,re,threading
import csv
import json
import math
import struct
import urllib.request, urllib.parse
from pymavlink.dialects.v20 import ardupilotmega as mavlink2
from pymavlink import mavutil

# === CONFIG LOAD ===
import json, os
CFG_PATH = "/home/pi/siyi-config.json"
try:
    with open(CFG_PATH) as cf:
        CFG = json.load(cf)
except Exception:
    CFG = {}

IFACE = CFG.get("button_interface", "auto")
if IFACE == "auto":
    import os
    IFACE = next((x for x in os.listdir("/sys/class/net") if x.startswith("zt")), "wlan0")
QGC_INPUT_HOSTS = set(CFG.get("qgc_hosts", []))
CAM = (CFG.get("camera_ip", "192.168.144.25"), int(CFG.get("camera_port", 37260)))
# === END CONFIG ===
# QGC_INPUT_HOSTS loaded from config
# CAM loaded from config
PORTS=[59133,54099]

BTN_A=0x1
BTN_Y=0x2000
BTN_RB=0x20
BTN_LB=0x8
BTN_RT=0x40
BTN_LT=0x10
BTN_BACK=0x100
BTN_START=0x200
BTN_B=0x2
BTN_X=0x1000
BTN_L3=0x400
BTN_R3=0x800
recording=False
last_voice_state=None
last_qgc_voice_text=None
last_qgc_voice_time=0
recording_start_ms=0
last_record_press=0
last_l3_press=0
toggle_arm_state=False
REC_DEBOUNCE=2.0
record_button_locked=False
start_btn_was_down=False
start_press_time=0
start_hold_started=False
GIMBAL_RATE=40
GIMBAL_RATE_SLOW=25
GIMBAL_RATE_FAST=65
GIMBAL_RATE_CENTER=90
GIMBAL_RAMP_TIME=0.7
gimbal_press_time=0

# ---- ARMED SAFETY GATE ----
# These actions are blocked when the flight controller reports ARMED.
# This is runtime bridge safety logic, not Web UI logic.
VEHICLE_ARMED=False
LAST_ARMED_HEARTBEAT=0
BUTTON_SAFETY_FILE="/etc/siyi/button_safety.json"

def load_button_safety_config():
    default_block = {"MANUAL", "TAKEOFF"}
    try:
        with open(BUTTON_SAFETY_FILE, encoding="utf-8") as f:
            data = json.load(f)
        vals = data.get("block_when_armed", list(default_block))
        if not isinstance(vals, list):
            return default_block
        allowed = {
            "MANUAL", "FBWA", "AUTOTUNE", "CRUISE", "LOITER", "RTL",
            "TAKEOFF", "QHOVER", "QLOITER", "QLAND", "QRTL"
        }
        return {str(x).strip().upper() for x in vals if str(x).strip().upper() in allowed}
    except Exception as e:
        print("[BUTTON_SAFETY_CONFIG_FAIL]", e, flush=True)
        return default_block

BLOCK_WHEN_ARMED = load_button_safety_config()

def load_button_safety_bool(key, default=True):
    try:
        with open(BUTTON_SAFETY_FILE, encoding="utf-8") as f:
            data = json.load(f)
        return bool(data.get(key, default))
    except Exception as e:
        print("[BUTTON_SAFETY_BOOL_FAIL]", key, e, flush=True)
        return default

BLOCK_DISARM_IN_AIR = load_button_safety_bool("block_disarm_in_air", True)
BLOCK_TOGGLE_ARM_DISARM_IN_AIR = load_button_safety_bool("block_toggle_arm_disarm_in_air", True)

print("[BUTTON_SAFETY] block_when_armed=%s block_disarm_in_air=%s block_toggle_arm_disarm_in_air=%s" % (
    sorted(BLOCK_WHEN_ARMED),
    BLOCK_DISARM_IN_AIR,
    BLOCK_TOGGLE_ARM_DISARM_IN_AIR
), flush=True)
VEHICLE_LANDED=True

ARMED_LISTEN_PORT=14600

TAP_WINDOW=0.60
HOLD_START=0.18
SMOOTH_DELAY=0.00

def load_button_map(path):
    cfg = {}
    with open(path, encoding="utf-8-sig") as f:
        reader = csv.DictReader(f, delimiter=';')
        for r in reader:
            btn = r["Button"].strip().upper()
            cfg[btn] = {
                "tap": r["Tap"].strip().upper(),
                "hold": r["Hold"].strip().upper(),
                "release_after_tap": r["ReleaseAfterTap"].strip().upper(),
                "release_after_hold": r["ReleaseAfterHold"].strip().upper(),
                "double_tap": r["DoubleTap"].strip().upper(),
            }
    print("[CONFIG] Loaded button map:", cfg, flush=True)
    return cfg

BUTTON_MAP = load_button_map("/home/pi/button_map.csv")

LIVE_BUTTON_FILE="/tmp/siyi_button_live.json"


def publish_held_buttons(buttons):
    try:
        with open(LIVE_BUTTON_FILE, "w") as f:
            json.dump({
                "held": buttons,
                "ts": time.time()
            }, f)
    except Exception as e:
        print("[LIVE_BUTTON_FAIL]", e, flush=True)

def publish_button_event(button, event, action):
    try:
        with open(LIVE_BUTTON_FILE, "w") as f:
            json.dump({
                "button": button,
                "event": event,
                "action": action,
                "ts": time.time()
            }, f)
    except Exception as e:
        print("[LIVE_BUTTON_FAIL]", e, flush=True)



cam=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
mavsock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)


def send_mavlink_tcp5760(pkt):
    try:
        with socket.create_connection(("127.0.0.1", 5760), timeout=0.5) as sock:
            sock.sendall(pkt)
        return True
    except Exception as e:
        print("[MAV TCP5760 FAIL]", repr(e), flush=True)
        return False

MAV_PORTS_CACHE=[]
MAV_PORTS_LAST=0
LAST_MANUAL_KEY=None
LAST_MANUAL_TIME=0

def get_mav_ports():
    global MAV_PORTS_CACHE, MAV_PORTS_LAST
    now=time.time()

    # Cache for 5 seconds. Avoid running "ss" on every button/gimbal command.
    if MAV_PORTS_CACHE and now-MAV_PORTS_LAST < 5:
        return MAV_PORTS_CACHE

    try:
        out=subprocess.check_output(["ss","-lunp"],text=True,stderr=subprocess.DEVNULL)
        ports=[]
        for line in out.splitlines():
            if "mavlink-routerd" in line:
                m=re.search(r":(\d+)\s",line)
                if m:
                    ports.append(int(m.group(1)))
        MAV_PORTS_CACHE = ports or PORTS
        MAV_PORTS_LAST = now
        return MAV_PORTS_CACHE
    except Exception:
        return MAV_PORTS_CACHE or PORTS


def zoom_in():
    cam.sendto(bytes.fromhex("55 66 01 01 00 00 00 05 01 8d 64"),CAM)
    print("[SIYI] zoom_in",flush=True)

def zoom_out():
    cam.sendto(bytes.fromhex("55 66 01 01 00 00 00 05 ff 5c 6a"),CAM)
    print("[SIYI] zoom_out",flush=True)

def zoom_stop():
    cam.sendto(bytes.fromhex("55 66 01 01 00 00 00 05 00 ac 74"),CAM)
    print("[SIYI] zoom_stop",flush=True)

def qgc_voice_announce(text):
    try:
        qgc_notice(text)
    except NameError:
        print("[QGC_VOICE_FAIL] qgc_notice not available yet", flush=True)
    except Exception as e:
        print("[QGC_VOICE_FAIL]", e, flush=True)


# === JOYSTICK_IDLE_VOICE_ALERT_V1 ===
# === JOYSTICK_IDLE_RESET_FIX_V2 ===
# TEST THRESHOLD: 1 minute. Final release target should be 8 minutes.
# Reuses the already validated qgc_voice_announce() path used by
# Safety Block and REC started/stopped voice messages.
#
# V2 fix:
# The original watchdog watched MANUAL_CONTROL/RC_CHANNELS_OVERRIDE on TCP5760,
# but the real joystick/button activity in this system is handled by the
# raw fast-input button path. Therefore reset idle using the actual button
# bridge action path instead of a separate MAVLink monitor.
JOYSTICK_IDLE_ALERT_SECONDS = 8 * 60
JOYSTICK_IDLE_STOP_AFTER_SECONDS = int(10.5 * 60)
JOYSTICK_IDLE_REPEAT_SECONDS = 10
JOYSTICK_IDLE_ALERT_TEXT = "Joystick idle. Move stick to keep controller awake."
JOYSTICK_LAST_ACTIVITY = time.time()
JOYSTICK_LAST_ALERT = 0
JOYSTICK_LAST_AXIS_KEY = None
JOYSTICK_AXIS_BUCKET = 50

def joystick_mark_activity(reason="input"):
    global JOYSTICK_LAST_ACTIVITY, JOYSTICK_LAST_ALERT
    JOYSTICK_LAST_ACTIVITY = time.time()
    JOYSTICK_LAST_ALERT = 0
    print("[JOYSTICK_IDLE] activity reset by %s" % reason, flush=True)

def joystick_idle_voice_watchdog():
    global JOYSTICK_LAST_ALERT

    while True:
        try:
            now = time.time()
            idle = now - JOYSTICK_LAST_ACTIVITY

            if idle >= JOYSTICK_IDLE_ALERT_SECONDS and idle <= JOYSTICK_IDLE_STOP_AFTER_SECONDS and (now - JOYSTICK_LAST_ALERT) >= JOYSTICK_IDLE_REPEAT_SECONDS:
                print("[JOYSTICK_IDLE] %s" % JOYSTICK_IDLE_ALERT_TEXT, flush=True)
                qgc_voice_announce(JOYSTICK_IDLE_ALERT_TEXT)
                JOYSTICK_LAST_ALERT = now

            time.sleep(0.25)

        except Exception as e:
            print("[JOYSTICK_IDLE] ERROR: %s" % e, flush=True)
            time.sleep(3)

def start_joystick_idle_voice_watchdog():
    t = threading.Thread(target=joystick_idle_voice_watchdog, daemon=True)
    t.start()
    print("[JOYSTICK_IDLE] watchdog thread started", flush=True)

start_joystick_idle_voice_watchdog()

# === END JOYSTICK_IDLE_VOICE_ALERT_V1 ===

# === CPU_TEMP_VOICE_LOOP_V1 ===
CPU_TEMP_VOICE_CONFIG = "/etc/siyi/cpu_temp_voice.json"

def cpu_temp_voice_read_config():
    try:
        with open(CPU_TEMP_VOICE_CONFIG, "r") as f:
            d = json.load(f)
        enabled = bool(d.get("enabled", False))
        interval = float(d.get("interval_minutes", 5) or 5)
        if interval <= 0:
            enabled = False
            interval = 5
        return enabled, interval
    except Exception as e:
        print("[CPU_TEMP_VOICE] config read failed: %s" % e, flush=True)
        return False, 5

def cpu_temp_celsius():
    try:
        raw = open("/sys/class/thermal/thermal_zone0/temp").read().strip()
        return round(float(raw) / 1000.0, 1)
    except Exception as e:
        print("[CPU_TEMP_VOICE] temp read failed: %s" % e, flush=True)
        return None

def battery_voice_read_config():
    try:
        with open(CPU_TEMP_VOICE_CONFIG, "r") as f:
            d = json.load(f)
        enabled = bool(d.get("battery_enabled", False))
        interval = float(d.get("battery_interval_minutes", 5) or 5)
        low_voltage = float(d.get("battery_low_voltage", 10.5) or 10.5)
        if interval <= 0:
            enabled = False
            interval = 5
        return enabled, interval, low_voltage
    except Exception as e:
        print("[BATTERY_VOICE] config read failed: %s" % e, flush=True)
        return False, 5, 10.5

def battery_voltage_read():
    try:
        txt = open("/tmp/siyi_battery_status.txt").read().strip()
        m = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*V", txt)
        if m:
            return float(m.group(1))
    except Exception as e:
        print("[BATTERY_VOICE] voltage read failed: %s" % e, flush=True)
    return None

def cpu_temp_voice_loop():
    last_spoken = 0
    last_bat_spoken = 0
    while True:
        try:
            now = time.time()

            enabled, interval_min = cpu_temp_voice_read_config()
            if enabled and (now - last_spoken) >= (interval_min * 60.0):
                temp = cpu_temp_celsius()
                if temp is not None:
                    txt = "Pi CPU temperature %.1f degrees" % temp
                    print("[CPU_TEMP_VOICE] %s" % txt, flush=True)
                    qgc_voice_announce(txt)
                    last_spoken = now

            # BATTERY_VOICE_LOOP_V1
            bat_enabled, bat_interval_min, bat_low_voltage = battery_voice_read_config()
            if bat_enabled and (now - last_bat_spoken) >= (bat_interval_min * 60.0):
                voltage = battery_voltage_read()
                if voltage is not None:
                    if voltage <= bat_low_voltage:
                        txt = "Low voltage %.1f volts" % voltage
                    else:
                        txt = "Battery voltage %.1f volts" % voltage
                    print("[BATTERY_VOICE] %s" % txt, flush=True)
                    qgc_voice_announce(txt)
                    last_bat_spoken = now

            time.sleep(5)
        except Exception as e:
            print("[CPU_TEMP_VOICE] ERROR: %s" % e, flush=True)
            time.sleep(10)

def start_cpu_temp_voice_loop():
    t = threading.Thread(target=cpu_temp_voice_loop, daemon=True)
    t.start()
    print("[CPU_TEMP_VOICE] loop started", flush=True)

start_cpu_temp_voice_loop()

# === END CPU_TEMP_VOICE_LOOP_V1 ===





# === FLAPS_CONTROL_V1 START ===
FLAPS_CONFIG_FILE = "/etc/siyi/flaps.json"


def flaps_default_config():
    return {
        "enabled": False,
        "left_servo": 9,
        "right_servo": 10,
        "left_reverse": False,
        "right_reverse": False,
        "up_pwm": 1000,
        "takeoff_pwm": 1500,
        "landing_pwm": 2000,
        "current_position": "UP",
    }


def load_flaps_config():
    cfg = flaps_default_config()

    try:
        with open(FLAPS_CONFIG_FILE, encoding="utf-8") as f:
            saved = json.load(f)

        if isinstance(saved, dict):
            cfg.update(saved)

    except Exception as e:
        print("[FLAPS_CONFIG_READ_FAIL]", repr(e), flush=True)

    return cfg


def save_flaps_config(cfg):
    try:
        os.makedirs(os.path.dirname(FLAPS_CONFIG_FILE), exist_ok=True)

        tmp = FLAPS_CONFIG_FILE + ".tmp"

        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
            f.write("\n")

        os.replace(tmp, FLAPS_CONFIG_FILE)

        try:
            os.chmod(FLAPS_CONFIG_FILE, 0o664)
        except Exception:
            pass

        return True

    except Exception as e:
        print("[FLAPS_CONFIG_WRITE_FAIL]", repr(e), flush=True)
        return False


def flaps_read_fc_param(name):
    try:
        url = (
            "http://127.0.0.1:8765/get?name="
            + urllib.parse.quote(name)
        )

        with urllib.request.urlopen(url, timeout=8) as r:
            obj = json.loads(
                r.read().decode("utf-8", errors="replace")
            )

        if not obj.get("ok"):
            return None, str(
                obj.get("error") or "parameter read failed"
            )

        return int(round(float(obj.get("value")))), ""

    except Exception as e:
        return None, repr(e)


def flaps_validate_config(cfg):
    if not bool(cfg.get("enabled", False)):
        return False, "Flap control is disabled"

    try:
        left = int(cfg.get("left_servo"))
        right = int(cfg.get("right_servo"))

        up_pwm = int(cfg.get("up_pwm"))
        mid_pwm = int(cfg.get("takeoff_pwm"))
        down_pwm = int(cfg.get("landing_pwm"))

    except Exception:
        return False, "Invalid flap configuration"

    if left == right:
        return False, (
            "Left and right flap outputs must be different"
        )

    if not (
        1 <= left <= 16
        and 1 <= right <= 16
    ):
        return False, (
            "Flap outputs must be SERVO1 through SERVO16"
        )

    for pwm in (up_pwm, mid_pwm, down_pwm):
        if not 800 <= pwm <= 2200:
            return False, (
                "Flap PWM must be between 800 and 2200"
            )

    return True, ""


def flaps_outputs_are_disabled(cfg):
    left = int(cfg["left_servo"])
    right = int(cfg["right_servo"])

    left_name = "SERVO%d_FUNCTION" % left
    right_name = "SERVO%d_FUNCTION" % right

    left_value, left_error = flaps_read_fc_param(left_name)
    right_value, right_error = flaps_read_fc_param(right_name)

    if left_value is None or right_value is None:
        reason = "%s=%s; %s=%s" % (
            left_name,
            left_error or "read failed",
            right_name,
            right_error or "read failed",
        )

        return False, reason

    if left_value != 0 or right_value != 0:
        return False, (
            "%s=%s, %s=%s; both must be Disabled (0)"
            % (
                left_name,
                left_value,
                right_name,
                right_value,
            )
        )

    return True, ""


def flaps_config_bool(value):
    if isinstance(value, bool):
        return value

    if isinstance(value, (int, float)):
        return value != 0

    return str(value).strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
        "reverse",
        "reversed",
    )


def flaps_apply_direction(pwm, reversed_output):
    pwm = int(pwm)

    if flaps_config_bool(reversed_output):
        return 3000 - pwm

    return pwm


def cycle_flaps():
    cfg = load_flaps_config()

    valid, reason = flaps_validate_config(cfg)

    if not valid:
        print("[FLAPS_DISABLED]", reason, flush=True)
        qgc_voice_announce(reason)
        return

    owned, reason = flaps_outputs_are_disabled(cfg)

    if not owned:
        print("[FLAPS_DISABLED]", reason, flush=True)

        qgc_voice_announce(
            "Flap control blocked. "
            "Servo function is not disabled"
        )

        return

    current = str(
        cfg.get("current_position", "UP")
    ).strip().upper()

    if current == "UP":
        next_position = "MID"
        pwm = int(cfg["takeoff_pwm"])

    elif current == "MID":
        next_position = "DOWN"
        pwm = int(cfg["landing_pwm"])

    else:
        next_position = "UP"
        pwm = int(cfg["up_pwm"])

    left = int(cfg["left_servo"])
    right = int(cfg["right_servo"])

    left_reverse = flaps_config_bool(
        cfg.get("left_reverse", False)
    )

    right_reverse = flaps_config_bool(
        cfg.get("right_reverse", False)
    )

    left_pwm = flaps_apply_direction(
        pwm,
        left_reverse,
    )

    right_pwm = flaps_apply_direction(
        pwm,
        right_reverse,
    )

    send_command_long(
        mavlink2.MAV_CMD_DO_SET_SERVO,
        [left, left_pwm, 0, 0, 0, 0, 0],
    )

    time.sleep(0.05)

    send_command_long(
        mavlink2.MAV_CMD_DO_SET_SERVO,
        [right, right_pwm, 0, 0, 0, 0, 0],
    )

    cfg["current_position"] = next_position
    save_flaps_config(cfg)

    print(
        "[FLAPS_MOVED] position=%s "
        "left=%s:%s right=%s:%s"
        % (
            next_position,
            left,
            left_pwm,
            right,
            right_pwm,
        ),
        flush=True,
    )

    qgc_voice_announce(
        "Flaps " + next_position.lower()
    )

# === FLAPS_CONTROL_V1 END ===

def load_gimbal_presets():
    try:
        if os.path.exists(GIMBAL_PRESETS_FILE):
            with open(GIMBAL_PRESETS_FILE, encoding="utf-8") as f:
                data=json.load(f)
            if isinstance(data, list):
                out={}
                for r in data:
                    name=str(r.get("name","")).strip().upper()
                    if name:
                        out[name]=r
                return out
    except Exception as e:
        print("[GIMBAL_PRESETS_LOAD_FAIL]", e, flush=True)
    return {}

def run_csv_action(button, event):
    joystick_mark_activity("%s/%s" % (button, event))
    action = BUTTON_MAP.get(button, {}).get(event, "NO_ACTION")
    print("[RUN_ACTION] button=%s event=%s action=%s" % (button, event, action), flush=True)
    publish_button_event(button, event, action)
    print("[BTN] %s %s -> %s" % (button, event, action), flush=True)

    # ---- ARMED SAFETY FILTER ----
    # Block DISARM in air
    if BLOCK_DISARM_IN_AIR and action == "DISARM" and VEHICLE_ARMED and not VEHICLE_LANDED:
        text = "Safety block: disarm disabled while in air"
        print("[SAFETY BLOCK] DISARM blocked while IN AIR", flush=True)
        qgc_voice_announce(text)
        return

    # Block only selected dangerous actions while ARMED.
    if VEHICLE_ARMED and action in BLOCK_WHEN_ARMED:
        text = "Safety block: %s disabled while armed" % action
        print("[SAFETY BLOCK] %s blocked while ARMED" % action, flush=True)
        qgc_voice_announce(text)
        return

    if action == "NO_ACTION":
        return
    elif action == "FBWA":
        fbwa()
    elif action == "AUTOTUNE":
        autotune()
    elif action == "RTL":
        rtl()
    elif action == "TOGGLE_ARM":
        toggle_arm()
    elif action == "CRUISE":
        cruise()
    elif action == "AUTO":
        set_mode(10)
    elif action == "FLAPS":
        cycle_flaps()
    elif action == "TAKEOFF":
        set_mode(13)

    # Additional flight modes
    elif action == "MANUAL":
        set_mode(0)
    elif action == "LOITER":
        set_mode(12)
    elif action == "QHOVER":
        set_mode(18)
    elif action == "QLOITER":
        set_mode(19)
    elif action == "QLAND":
        set_mode(20)
    elif action == "QRTL":
        set_mode(21)

    # Arm/disarm
    elif action == "ARM":
        send_command_long(mavlink2.MAV_CMD_COMPONENT_ARM_DISARM,[1,0,0,0,0,0,0])
        print("[ARM]", flush=True)
    elif action == "DISARM":
        send_command_long(mavlink2.MAV_CMD_COMPONENT_ARM_DISARM,[0,0,0,0,0,0,0])
        print("[DISARM]", flush=True)

    # Camera
    elif action == "RECORD_TOGGLE":
        record_toggle()
    elif action == "SNAPSHOT":
        print("[SNAPSHOT_UNIMPLEMENTED_SAFE]", flush=True)

    # Zoom
    elif action == "ZOOM_IN":
        zoom_in()
    elif action == "ZOOM_OUT":
        zoom_out()
    elif action == "ZOOM_STOP":
        zoom_stop()

    # Gimbal rate movement
    elif action == "GIMBAL_YAW_RIGHT":
        gimbal_send(0, GIMBAL_RATE_SLOW)
    elif action == "GIMBAL_YAW_LEFT":
        gimbal_send(0, -GIMBAL_RATE_SLOW)
    elif action == "GIMBAL_PITCH_UP":
        gimbal_send(GIMBAL_RATE_SLOW, 0)
    elif action == "GIMBAL_PITCH_DOWN":
        gimbal_send(-GIMBAL_RATE_SLOW, 0)
    elif action == "GIMBAL_STOP":
        gimbal_send(0, 0)

    # Gimbal modes/positions
    elif action == "GIMBAL_CENTER":
        gimbal_send(0, 0)
        print("[GIMBAL_CENTER_COMMAND_SAFE_STOP_ONLY]", flush=True)
    elif action == "GIMBAL_CENTER_AND_ZOOM_OUT":
        gimbal_center()
    elif action == "GIMBAL_LOCK":
        print("[GIMBAL_LOCK_UNIMPLEMENTED_SAFE]", flush=True)
    elif action.startswith("GIMBAL_PRESET_"):
        preset_name = action.replace("GIMBAL_PRESET_","",1).strip().upper()
        presets = load_gimbal_presets()
        preset = presets.get(preset_name)
        if not preset:
            print("[GIMBAL_PRESET_NOT_FOUND]", preset_name, flush=True)
        else:
            yaw = float(preset.get("yaw", 0))
            pitch = float(preset.get("pitch", 0))
            print("[GIMBAL_PRESET_ACTION] %s yaw=%s pitch=%s" % (preset_name, yaw, pitch), flush=True)
            gimbal_preset(yaw, pitch)

    elif action == "GIMBAL_FOLLOW":
        print("[GIMBAL_FOLLOW_UNIMPLEMENTED_SAFE]", flush=True)

    else:
        print("[ACTION_UNSUPPORTED]", action, flush=True)

def run_csv_tap(button):
    run_csv_action(button, "tap")



def send_command_long(command, params):
    mav=mavlink2.MAVLink(None)
    pkt=mav.command_long_encode(
        1,1,command,0,
        params[0],params[1],params[2],params[3],params[4],params[5],params[6]
    ).pack(mav)
    for p in get_mav_ports():
        mavsock.sendto(pkt,("127.0.0.1",p))
    print("[MAV_CMD]",command,params,flush=True)

def set_mode(mode):
    mav=mavlink2.MAVLink(None)
    pkt=mav.set_mode_encode(1,1,mode).pack(mav)
    ok=send_mavlink_tcp5760(pkt)
    print("[MAV MODE TCP5760]",mode,"ok="+str(ok),flush=True)

def fbwa():
    set_mode(5)

def autotune():
    set_mode(8)

def rtl():
    set_mode(11)

def toggle_arm():
    global toggle_arm_state, VEHICLE_ARMED

    if toggle_arm_state:
        if BLOCK_TOGGLE_ARM_DISARM_IN_AIR and VEHICLE_ARMED and not VEHICLE_LANDED:
            text = "Safety block: disarm disabled while in air"
            print("[SAFETY BLOCK] TOGGLE_ARM/DISARM blocked while IN AIR", flush=True)
            qgc_voice_announce(text)
            return

        send_command_long(mavlink2.MAV_CMD_COMPONENT_ARM_DISARM,[0,0,0,0,0,0,0])
        toggle_arm_state=False
        VEHICLE_ARMED=False
        print("[TOGGLE_ARM] DISARM",flush=True)
        print("[ARMED_STATE_LOCAL] DISARMED",flush=True)
    else:
        send_command_long(mavlink2.MAV_CMD_COMPONENT_ARM_DISARM,[1,0,0,0,0,0,0])
        toggle_arm_state=True
        VEHICLE_ARMED=True
        print("[TOGGLE_ARM] ARM",flush=True)
        print("[ARMED_STATE_LOCAL] ARMED",flush=True)

def cruise():
    mav=mavlink2.MAVLink(None)
    pkt=mav.set_mode_encode(1,1,7).pack(mav)
    for p in get_mav_ports():
        mavsock.sendto(pkt,("127.0.0.1",p))
    print("[MAV] CRUISE",flush=True)

last=0

press_time={BTN_A:0,BTN_Y:0,BTN_B:0,BTN_X:0,BTN_L3:0,BTN_R3:0}
zoom_started={BTN_A:False,BTN_Y:False}
pending_tap={BTN_A:0,BTN_Y:0,BTN_B:0,BTN_X:0,BTN_L3:0,BTN_R3:0}
suppress_release={BTN_A:False,BTN_Y:False}
generic_hold_started={BTN_B:False,BTN_X:False,BTN_L3:False,BTN_R3:False}

def handle_button(btn,b,pressed,released,now):
    global pending_tap,suppress_release

    # A keeps old behavior: tap=zoom OUT, hold=zoom OUT, double=reserved
    if btn == BTN_A:
        if pending_tap[btn] and now-pending_tap[btn]>TAP_WINDOW:
            run_csv_action("A","tap")
            time.sleep(SMOOTH_DELAY)
            run_csv_action("A","release_after_tap")
            pending_tap[btn]=0

        if pressed & btn:
            press_time[btn]=now
            zoom_started[btn]=False
            if pending_tap[btn] and now-pending_tap[btn]<TAP_WINDOW:
                pending_tap[btn]=0
                suppress_release[btn]=True
                print("[BTN] A double tap reserved",flush=True)

        if (b & btn) and not zoom_started[btn] and now-press_time[btn]>HOLD_START:
            run_csv_action("A","hold")
            time.sleep(SMOOTH_DELAY)
            zoom_started[btn]=True

        if released & btn:
            if suppress_release[btn]:
                suppress_release[btn]=False
            elif zoom_started[btn]:
                run_csv_action("A","release_after_hold")
            else:
                if not pending_tap[btn]:
                    pending_tap[btn]=now
        return

    # Y behavior via CSV:
    # tap = CSV action Y/tap
    # hold = CSV action Y/hold
    # release after hold = zoom STOP only
    if btn == BTN_Y:
        if pressed & btn:
            press_time[btn]=now
            zoom_started[btn]=False

        if (b & btn) and not zoom_started[btn] and now-press_time[btn]>HOLD_START:
            run_csv_action("Y","hold")
            time.sleep(SMOOTH_DELAY)
            zoom_started[btn]=True

        if released & btn:
            if zoom_started[btn]:
                run_csv_action("Y","release_after_hold")
            else:
                run_csv_action("Y","tap")
        return

def handle_generic_button(btn, name, b, pressed, released, now):
    global generic_hold_started

    if pressed & btn:
        press_time[btn] = now
        generic_hold_started[btn] = False

    if (b & btn) and not generic_hold_started[btn] and now-press_time[btn] > HOLD_START:
        run_csv_action(name, "hold")
        generic_hold_started[btn] = True

    if released & btn:
        if generic_hold_started[btn]:
            run_csv_action(name, "release_after_hold")
        else:
            run_csv_action(name, "tap")
            run_csv_action(name, "release_after_tap")


def handle(b):
    held_buttons = []
    if b & BTN_Y: held_buttons.append("Y")
    if b & BTN_A: held_buttons.append("A")
    if b & BTN_X: held_buttons.append("X")
    if b & BTN_B: held_buttons.append("B")
    if b & BTN_RB: held_buttons.append("RB")
    if b & BTN_LB: held_buttons.append("LB")
    if b & BTN_RT: held_buttons.append("RT")
    if b & BTN_LT: held_buttons.append("LT")
    if b & BTN_START: held_buttons.append("START")
    if b & BTN_BACK: held_buttons.append("BACK")
    if b & BTN_L3: held_buttons.append("L3")
    if b & BTN_R3: held_buttons.append("R3")
    publish_held_buttons(held_buttons)

    global last, last_record_press, record_button_locked, start_btn_was_down, start_press_time, start_hold_started, last_l3_press
    now=time.time()
    pressed=b & ~last
    released=(~b) & last

    start_down = bool(b & BTN_START)

    # CSV START: tap and hold are mutually exclusive.
    if start_down and not start_btn_was_down:
        start_press_time = now
        start_hold_started = False
        start_btn_was_down = True

    if start_down and start_btn_was_down and not start_hold_started:
        if now - start_press_time > 0.75:
            start_hold_started = True
            print("[BTN] START hold confirmed", flush=True)

    if (not start_down) and start_btn_was_down:
        if start_hold_started:
            run_csv_action("START","hold")
        else:
            run_csv_action("START","tap")

        print("[BTN] START duration=%.3f hold=%s" % (now-start_press_time, start_hold_started), flush=True)
        start_btn_was_down = False
        start_hold_started = False


    handle_button(BTN_A,b,pressed,released,now)
    handle_button(BTN_Y,b,pressed,released,now)

    handle_generic_button(BTN_B, "B", b, pressed, released, now)
    handle_generic_button(BTN_X, "X", b, pressed, released, now)
    handle_generic_button(BTN_L3, "L3", b, pressed, released, now)
    handle_generic_button(BTN_R3, "R3", b, pressed, released, now)

    last=b


def get_qgc_voice_hosts():
    hosts = set()
    try:
        current = {}
        in_udp = False
        for raw in open("/etc/mavlink-router/main.conf"):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("["):
                if in_udp and current.get("Address") and current.get("Port", "14550") == "14550":
                    addr = current["Address"]
                    if addr not in ("127.0.0.1", "0.0.0.0"):
                        hosts.add(addr)
                current = {}
                in_udp = line.startswith("[UdpEndpoint")
                continue
            if in_udp and "=" in line:
                k, v = line.split("=", 1)
                current[k.strip()] = v.strip()
        if in_udp and current.get("Address") and current.get("Port", "14550") == "14550":
            addr = current["Address"]
            if addr not in ("127.0.0.1", "0.0.0.0"):
                hosts.add(addr)
    except Exception as e:
        print("[QGC_VOICE_HOSTS_FAIL]", e, flush=True)

    hosts.update(QGC_INPUT_HOSTS)
    return hosts

def qgc_notice(text):
    global last_qgc_voice_text, last_qgc_voice_time

    now=time.time()

    # Absolute final guard:
    # never send same voice text twice within 5 seconds.
    if text == last_qgc_voice_text and now-last_qgc_voice_time < 5.0:
        print("[QGC_VOICE_SUPPRESSED]",text,flush=True)
        return

    last_qgc_voice_text=text
    last_qgc_voice_time=now

    mav=mavlink2.MAVLink(None, srcSystem=1, srcComponent=1)
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)

    pkt=mav.statustext_encode(4, text.encode("ascii")[:50]).pack(mav)

    try:
        for h in get_qgc_voice_hosts():
            sock.sendto(pkt,(h,14550))
    except Exception as e:
        print("[NOTICE_FAIL]",e,flush=True)

    print("[QGC_VOICE]",text,flush=True)


def record_toggle():
    global recording,recording_start_ms,last,record_button_locked

    recording = not recording
    recording_start_ms = int(time.time()*1000) if recording else 0

    cmd = "start" if recording else "stop"
    txt = "REC STARTED" if recording else "REC STOPPED"

    try:
        with open("/tmp/siyi_record_proxy", "w") as f:
            f.write(cmd + "\n")

        print("[REC_FIFO_OK]", cmd, flush=True)
        print("[SIYI]", txt, flush=True)
        qgc_notice(txt)

    except Exception as e:
        print("[REC_FIFO_FAIL]", cmd, repr(e), flush=True)
        qgc_notice("REC COMMAND FAILED")



GIMBAL_PRESETS_FILE="/etc/siyi/gimbal_presets.json"
GIMBAL_STATE_FILE="/home/pi/siyi_gimbal_state.json"
GIMBAL_ZERO_FILE="/etc/siyi/gimbal_zero.json"

def quat_normalize(q):
    n = math.sqrt(sum(float(x)*float(x) for x in q))
    if n <= 0:
        return [1.0,0.0,0.0,0.0]
    return [float(x)/n for x in q]

def quat_conj(q):
    w,x,y,z = quat_normalize(q)
    return [w,-x,-y,-z]

def quat_mul(a,b):
    aw,ax,ay,az = quat_normalize(a)
    bw,bx,by,bz = quat_normalize(b)
    return [
        aw*bw - ax*bx - ay*by - az*bz,
        aw*bx + ax*bw + ay*bz - az*by,
        aw*by - ax*bz + ay*bw + az*bx,
        aw*bz + ax*by - ay*bx + az*bw
    ]

def quat_to_euler_deg(q):
    w, x, y, z = quat_normalize(q)
    sinr_cosp = 2.0 * (w*x + y*z)
    cosr_cosp = 1.0 - 2.0 * (x*x + y*y)
    roll = math.atan2(sinr_cosp, cosr_cosp)
    sinp = 2.0 * (w*y - z*x)
    pitch = math.copysign(math.pi/2.0, sinp) if abs(sinp) >= 1 else math.asin(sinp)
    siny_cosp = 2.0 * (w*z + x*y)
    cosy_cosp = 1.0 - 2.0 * (y*y + z*z)
    yaw = math.atan2(siny_cosp, cosy_cosp)
    return math.degrees(roll), math.degrees(pitch), math.degrees(yaw)

def wrap_angle_180(v):
    v=float(v)
    while v > 180:
        v -= 360
    while v < -180:
        v += 360
    return v

def load_gimbal_zero_quat():
    try:
        if os.path.exists(GIMBAL_ZERO_FILE):
            with open(GIMBAL_ZERO_FILE, encoding="utf-8") as f:
                z=json.load(f)
            q=z.get("q_ref")
            if isinstance(q,list) and len(q)==4:
                return quat_normalize(q)
    except Exception as e:
        print("[GIMBAL_ZERO_LOAD_FAIL]", e, flush=True)
    return [1.0,0.0,0.0,0.0]

def publish_real_gimbal_attitude_from_mavlink():
    while True:
        try:
            print("[GIMBAL_REAL_ATT] connecting tcp:127.0.0.1:5760", flush=True)
            m = mavutil.mavlink_connection("tcp:127.0.0.1:5760", source_system=249)

            while True:
                msg = m.recv_match(type=["GIMBAL_DEVICE_ATTITUDE_STATUS"], blocking=True, timeout=3)
                if msg is None:
                    continue

                d = msg.to_dict()
                q = d.get("q")
                if not q or len(q) != 4:
                    continue

                q_cur = quat_normalize(q)
                q_ref = load_gimbal_zero_quat()
                q_rel = quat_mul(quat_conj(q_ref), q_cur)

                raw_roll, raw_pitch, raw_yaw = quat_to_euler_deg(q_cur)
                rel_roll, rel_pitch, rel_yaw = quat_to_euler_deg(q_rel)

                tmp = GIMBAL_STATE_FILE + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump({
                        "ok": True,
                        "yaw": round(wrap_angle_180(rel_yaw), 2),
                        "pitch": round(-rel_pitch, 2),
                        "roll": round(rel_roll, 2),
                        "raw_yaw": round(wrap_angle_180(raw_yaw), 2),
                        "raw_pitch": round(raw_pitch, 2),
                        "raw_roll": round(raw_roll, 2),
                        "raw_q": q_cur,
                        "q_ref": q_ref,
                        "ts": time.time(),
                        "source": "real_mavlink_gimbal_device_attitude_status_relative_quaternion",
                        "gimbal_device_id": d.get("gimbal_device_id", 0),
                        "flags": d.get("flags", 0)
                    }, f)
                os.replace(tmp, GIMBAL_STATE_FILE)

        except Exception as e:
            print("[GIMBAL_REAL_ATT_FAIL]", repr(e), flush=True)
            time.sleep(2)

last_gimbal=(None,None)

def gimbal_send(pitch_rate,yaw_rate):
    mav=mavlink2.MAVLink(None)
    pkt=mav.command_long_encode(
        1,1,1000,255,
        float('nan'),float('nan'),
        pitch_rate,yaw_rate,
        12,0,1
    ).pack(mav)
    for port in get_mav_ports():
        mavsock.sendto(pkt,("127.0.0.1",port))
    print("[GIMBAL] pitch_rate=%s yaw_rate=%s"%(pitch_rate,yaw_rate),flush=True)

def gimbal_preset(yaw, pitch):
    mav=mavlink2.MAVLink(None)
    pkt=mav.command_long_encode(
        1,1,1000,255,
        float(pitch),float(yaw),
        float('nan'),float('nan'),
        12,0,1
    ).pack(mav)
    for port in get_mav_ports():
        mavsock.sendto(pkt,("127.0.0.1",port))
    print("[GIMBAL_PRESET_SEND] yaw=%s pitch=%s"%(yaw,pitch),flush=True)

def gimbal_pitch_down_90():
    mav=mavlink2.MAVLink(None)
    pkt=mav.command_long_encode(
        1,1,1000,255,
        float('nan'),float('nan'),
        -90,0,   # pitch = -90 degrees
        12,0,1
    ).pack(mav)
    for port in get_mav_ports():
        mavsock.sendto(pkt,("127.0.0.1",port))
    print("[GIMBAL] PITCH -90",flush=True)

def full_zoom_out():
    print("[SIYI] full_zoom_out",flush=True)
    zoom_out()
    time.sleep(2.5)
    zoom_stop()

def gimbal_center():
    print("[GIMBAL] TRUE CENTER + FULL ZOOM OUT",flush=True)
    mav=mavlink2.MAVLink(None)
    pkt=mav.command_long_encode(
        1,1,1000,255,
        0,0,
        float('nan'),float('nan'),
        12,0,1
    ).pack(mav)
    for port in get_mav_ports():
        mavsock.sendto(pkt,("127.0.0.1",port))

    threading.Thread(target=full_zoom_out,daemon=True).start()

def gimbal_action_vector(action, rate):
    if action == "GIMBAL_YAW_RIGHT":
        return (0, rate)
    if action == "GIMBAL_YAW_LEFT":
        return (0, -rate)
    if action == "GIMBAL_PITCH_UP":
        return (rate, 0)
    if action == "GIMBAL_PITCH_DOWN":
        return (-rate, 0)
    return (0, 0)

def gimbal_handle(b,pressed,released):
    global last_gimbal,gimbal_press_time

    if not hasattr(gimbal_handle, "press"):
        gimbal_handle.press={}
        gimbal_handle.hold_started={}

    if pressed & BTN_BACK:
        run_csv_action("BACK","tap")

    now=time.time()

    btns=[
        (BTN_RT, "RT"),
        (BTN_LT, "LT"),
        (BTN_RB, "RB"),
        (BTN_LB, "LB"),
    ]

    for btn,name in btns:
        if pressed & btn:
            gimbal_handle.press[btn]=now
            gimbal_handle.hold_started[btn]=False
            gimbal_press_time=now

    pitch=0
    yaw=0

    for btn,name in btns:
        if b & btn:
            held=now-gimbal_handle.press.get(btn,now)
            if held >= HOLD_START:
                gimbal_handle.hold_started[btn]=True
                rate=GIMBAL_RATE_FAST if held>=GIMBAL_RAMP_TIME else GIMBAL_RATE_SLOW
                action = BUTTON_MAP.get(name, {}).get("hold", "NO_ACTION")
                dp, dy = gimbal_action_vector(action, rate)
                pitch += dp
                yaw += dy

    for btn,name in btns:
        if released & btn:
            if gimbal_handle.hold_started.get(btn,False):
                run_csv_action(name,"release_after_hold")
            else:
                run_csv_action(name,"tap")
                run_csv_action(name,"release_after_tap")
            gimbal_handle.press.pop(btn,None)
            gimbal_handle.hold_started.pop(btn,None)

    state=(pitch,yaw)

    if state!=last_gimbal:
        gimbal_send(pitch,yaw)
        last_gimbal=state


def armed_state_loop():
    global VEHICLE_ARMED, LAST_ARMED_HEARTBEAT

    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
    sock.bind(("127.0.0.1", ARMED_LISTEN_PORT))

    parser=mavlink2.MAVLink(None)

    print("[ARMED_MONITOR] listening on 127.0.0.1:%s" % ARMED_LISTEN_PORT, flush=True)

    while True:
        try:
            data,_=sock.recvfrom(4096)
            for b in data:
                msg=parser.parse_char(bytes([b]))
                if not msg:
                    continue
                # Track landed state
                if msg.get_type()=="EXTENDED_SYS_STATE":
                    global VEHICLE_LANDED
                    ls = int(msg.landed_state)

                    # MAVLink landed_state:
                    # 1 = ON_GROUND
                    # 2 = IN_AIR
                    # 3 = TAKEOFF
                    # 4 = LANDING
                    VEHICLE_LANDED = (ls == 1)

                    print("[LANDED_STATE] %s" % (
                        "ON_GROUND" if VEHICLE_LANDED else "IN_AIR"
                    ), flush=True)

                if msg.get_type()!="HEARTBEAT":
                    continue

                # Ignore camera/component heartbeats; only use autopilot heartbeat.
                if msg.get_srcComponent() != 1:
                    continue

                new_armed = bool(int(msg.base_mode) & 128)  # MAV_MODE_FLAG_SAFETY_ARMED
                LAST_ARMED_HEARTBEAT=time.time()

                if new_armed != VEHICLE_ARMED:
                    VEHICLE_ARMED=new_armed
                    print("[ARMED_STATE] %s" % ("ARMED" if VEHICLE_ARMED else "DISARMED"), flush=True)

        except Exception as e:
            print("[ARMED_MONITOR_FAIL]", e, flush=True)
            time.sleep(0.2)

def camera_status_loop():
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    mav=mavlink2.MAVLink(None, srcSystem=1, srcComponent=100)

    targets=[
        
        
    ]

    last_hb=0

    while True:
        try:
            now_ms=int(time.time()*1000)

            # 1) Announce Pi as MAVLink camera component
            if time.time()-last_hb > 1.0:
                hb=mav.heartbeat_encode(
                    30,   # MAV_TYPE_CAMERA
                    8,    # MAV_AUTOPILOT_INVALID
                    0,
                    0,
                    4,    # MAV_STATE_ACTIVE
                    3
                ).pack(mav)

                for host,port in targets:
                    sock.sendto(hb,(host,port))

                last_hb=time.time()

            # 2) Send recording status as camera component
            video_status=1 if recording else 0
            rec_time=(now_ms-recording_start_ms) if recording and recording_start_ms else 0

            pkt=mav.camera_capture_status_encode(
                now_ms & 0xffffffff,
                0,              # image_status
                video_status,   # video_status: 1 = running
                0.0,            # image_interval
                rec_time,       # recording_time_ms
                9999.0,         # available capacity
                0               # image_count
            ).pack(mav)

            for host,port in targets:
                sock.sendto(pkt,(host,port))

        except Exception as e:
            print("[CAM_EMU_FAIL]",e,flush=True)

        time.sleep(0.25)

def fast_mavlink_loop():
    parser=mavlink2.MAVLink(None)

    # Raw packet socket on ZeroTier interface. Much faster than Scapy sniff().
    rsock=socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0800))
    rsock.bind((IFACE, 0))

    print("[FAST_INPUT] raw UDP listener active on",IFACE,flush=True)

    while True:
        try:
            frame=rsock.recv(4096)

            # Ethernet + IPv4 minimum
            if len(frame) < 42:
                continue

            eth_type=struct.unpack("!H", frame[12:14])[0]
            if eth_type != 0x0800:
                continue

            ip_start=14
            ver_ihl=frame[ip_start]
            ihl=(ver_ihl & 0x0F)*4
            proto=frame[ip_start+9]
            if proto != 17:   # UDP
                continue

            src_ip=".".join(str(x) for x in frame[ip_start+12:ip_start+16])

            # Accept multiple QGC sources (fix auto-learn bug)
            if not (src_ip.startswith("192.168.191.") or src_ip.startswith("192.168.0.")):
                continue
                continue

            udp_start=ip_start+ihl
            if len(frame) < udp_start+8:
                continue

            src_port,dst_port,udp_len,_=struct.unpack("!HHHH", frame[udp_start:udp_start+8])

            # QGC MANUAL_CONTROL arrives on MAVLink UDP 14550 path
            if src_port != 14550 and dst_port != 14550:
                continue

            payload=frame[udp_start+8:udp_start+udp_len]
            for x in payload:
                msg=parser.parse_char(bytes([x]))
                if msg and msg.get_type()=="MANUAL_CONTROL":
                    global LAST_MANUAL_KEY, LAST_MANUAL_TIME, last

                    bb=int(msg.buttons)
                    now=time.time()

                    global LAST_RAW_BUTTONS
                    try:
                        LAST_RAW_BUTTONS
                    except NameError:
                        LAST_RAW_BUTTONS=-1

                    if bb != LAST_RAW_BUTTONS:
                        print(f"[RAW_MC] buttons=0x{bb:04x}", flush=True)
                        LAST_RAW_BUTTONS=bb

                    # Deduplicate identical MANUAL_CONTROL packets arriving almost back-to-back.
                    # Keeps fast response, but prevents double REC/voice from duplicate MAVLink paths.
                    key=(msg.get_srcSystem(), msg.get_srcComponent(), bb)
                    if key == LAST_MANUAL_KEY and now-LAST_MANUAL_TIME < 0.035:
                        continue

                    LAST_MANUAL_KEY=key
                    LAST_MANUAL_TIME=now

                    pressed=bb & ~last
                    released=(~bb) & last
                    # JOYSTICK_IDLE_AXIS_CHANGE_FIX_V4
                    # QGC/Android sends continuous MANUAL_CONTROL packets even when untouched.
                    # Reset idle only on meaningful stick/axis or button change.
                    global JOYSTICK_LAST_AXIS_KEY
                    try:
                        axis_key = (
                            int(getattr(msg, "x", 0) / JOYSTICK_AXIS_BUCKET),
                            int(getattr(msg, "y", 0) / JOYSTICK_AXIS_BUCKET),
                            int(getattr(msg, "z", 0) / JOYSTICK_AXIS_BUCKET),
                            int(getattr(msg, "r", 0) / JOYSTICK_AXIS_BUCKET),
                            int(bb),
                        )
                        if JOYSTICK_LAST_AXIS_KEY is None:
                            JOYSTICK_LAST_AXIS_KEY = axis_key
                        elif axis_key != JOYSTICK_LAST_AXIS_KEY:
                            JOYSTICK_LAST_AXIS_KEY = axis_key
                            joystick_mark_activity("manual_control_change")
                    except Exception as e:
                        print("[JOYSTICK_IDLE] axis_change reset failed: %s" % e, flush=True)

                    handle(bb)
                    gimbal_handle(bb,pressed,released)
                    last=bb

        except Exception as e:
            print("[FAST_INPUT_FAIL]",e,flush=True)
            time.sleep(0.1)

print("A tap=NO_ACTION | hold=ZOOM_OUT | release_after_hold=ZOOM_STOP")
print("Y tap=CRUISE | hold=ZOOM_IN | release_after_hold=ZOOM_STOP",flush=True)

threading.Thread(target=armed_state_loop,daemon=True).start()
threading.Thread(target=publish_real_gimbal_attitude_from_mavlink,daemon=True).start()
threading.Thread(target=camera_status_loop,daemon=True).start()

fast_mavlink_loop()