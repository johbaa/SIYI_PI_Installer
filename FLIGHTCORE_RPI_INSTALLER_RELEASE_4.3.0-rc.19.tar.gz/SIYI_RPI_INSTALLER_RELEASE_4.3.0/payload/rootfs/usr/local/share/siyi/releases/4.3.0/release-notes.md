# FlightCore 4.3.0 RC19

Canonical machine identity: `4.3.0-rc.19`. Factory model: `FLIGHTCORE_4_3_0_COMPLETE_TARGET_MODEL_V83`.

RC19 is derived from exact accepted RC18 build `20260818.234700-562be25`. Its native upgrade matrix includes exact RC6/Factory V71, exact accepted RC17, and exact accepted RC18, plus genuine fresh installation.

## Local Flight Logs

- Selecting a flight immediately opens a visible loading state.
- Samples load in bounded pages of 500 and events in bounded pages of 250.
- The browser yields between requests, so a 20 MB log no longer makes the button appear unresponsive.
- The existing all-in-one detail API remains available for backward compatibility.
- RC18 chart bounds, visible-window Y scaling, viewer-local timestamps and source version/build display remain active.

## Cloud Flight Logs

- Large logs upload samples and events as separate checksum-confirmed chunks.
- The final `chunked-v2` manifest contains only compact descriptors and remains below the Registry manifest ceiling.
- Registry v13 retains reads for sample-only `chunked-v1` and legacy single-object logs.
- A deferred RC18 receipt remains deferred across installation and retries automatically while disarmed after RC19 starts.
- Local source logs are never modified or deleted by synchronization.

## Preserved behavior

TURN HOME calculations and forecast isolation, SIYI H.265 1080p25 recovery, Air Link, joystick/control paths, and flight-controller failsafe authority are unchanged from RC18.

## Acceptance status

Factory automation includes the realistic 2,750-sample/1,289-event flight shape. Physical RC18 upgrade, automatic deferred upload, Local UI and Cloud UI readback remain explicit external gates.
