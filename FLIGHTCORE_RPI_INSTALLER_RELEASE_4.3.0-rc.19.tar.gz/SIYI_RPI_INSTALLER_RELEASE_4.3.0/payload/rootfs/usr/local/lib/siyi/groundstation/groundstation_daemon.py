#!/usr/bin/env python3
"""FlightCore Ground Station read-only telemetry daemon.

Receives MAVLink from the dedicated mavlink-router UDP endpoint, maintains a
normalized state model, and exposes a loopback-only JSON/SSE interface for the
existing WebUI. This first live patch is deliberately monitor-only.
"""

# GROUND_STATION_CANONICAL_QGC_TELEMETRY_OVERHAUL_V4_1_0
# SIYI_4_2_2_TELEMETRY_WIND_AND_VOLTAGE_V1
# SIYI_4_2_2_RC2_WIND_LEGACY_SEMANTICS_AND_SPEED_V1
# SIYI_4_2_2_RC2_RESTING_VOLTAGE_TRACKER_V1
# SIYI_4_2_2_RC6_BATTERY_PERCENT_V1
# SIYI_4_2_2_RC12_GROUNDSTATION_LOAD_BOUNDS_V1
# FLIGHTCORE_4_2_3_RC3_RELAXED_VOLTAGE_ESTIMATOR_V1
# FLIGHTCORE_4_3_0_RC1_WIND_GUST_TELEMETRY_V1

from __future__ import annotations

import copy
import hashlib
import json
import math
import os
import threading
import time
from collections import deque
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Optional, Set, Tuple
from urllib.parse import parse_qs, urlparse

from pymavlink import mavutil

CONFIG_PATH = Path("/etc/siyi/groundstation.json")

TELEMETRY_LAYOUT_PATH = Path("/var/lib/siyi-user-config/groundstation/telemetry_canvas.json")
TELEMETRY_LAYOUT_SHADOW_PATH = Path("/home/pi/.config/siyi/telemetry_canvas.json")
TELEMETRY_LAYOUT_SCHEMA_VERSION = 1

NORMALIZED_TELEMETRY_FIELDS = [
    {"key": "norm.speed.groundspeed_kmh", "label": "Ground Speed", "unit": "km/h", "path": ["speed", "groundspeed_m_s"], "multiplier": 3.6, "digits": 1, "age_key": "speed", "category": "Flight"},
    {"key": "norm.speed.airspeed_kmh", "label": "Air Speed", "unit": "km/h", "path": ["speed", "airspeed_m_s"], "multiplier": 3.6, "digits": 1, "age_key": "speed", "category": "Flight"},
    {"key": "norm.position.relative_alt_m", "label": "Alt (Rel)", "unit": "m", "path": ["position", "relative_alt_m"], "digits": 1, "age_key": "position", "category": "Flight"},
    {"key": "norm.position.amsl_alt_m", "label": "Alt (AMSL)", "unit": "m", "path": ["position", "amsl_alt_m"], "digits": 1, "age_key": "position", "category": "Flight"},
    {"key": "norm.navigation.home_distance_m", "label": "Distance to Home", "unit": "m", "path": ["navigation", "home_distance_m"], "digits": 0, "age_key": "position", "category": "Navigation"},
    {"key": "norm.navigation.distance_to_waypoint_m", "label": "Distance to Waypoint", "unit": "m", "path": ["navigation", "distance_to_waypoint_m"], "digits": 0, "age_key": "navigation", "category": "Navigation"},
    {"key": "norm.navigation.flight_distance_m", "label": "Flight Distance", "unit": "m", "path": ["navigation", "flight_distance_m"], "digits": 0, "age_key": "position", "category": "Flight"},
    {"key": "norm.timers.flight_time_text", "label": "Flight Time", "unit": "", "path": ["timers", "flight_time_text"], "age_key": "heartbeat", "category": "Flight"},
    {"key": "norm.timers.local_time_text", "label": "Time", "unit": "", "path": ["timers", "local_time_text"], "age_key": "heartbeat", "category": "Flight"},
    {"key": "norm.speed.vertical_speed_m_s", "label": "Vertical Speed", "unit": "m/s", "path": ["speed", "vertical_speed_m_s"], "digits": 1, "age_key": "speed", "category": "Flight"},
    {"key": "norm.speed.throttle_pct", "label": "Throttle %", "unit": "%", "path": ["speed", "throttle_pct"], "digits": 0, "age_key": "speed", "category": "Flight"},
    {"key": "norm.attitude.heading_deg", "label": "Heading", "unit": "deg", "path": ["attitude", "heading_deg"], "digits": 0, "age_key": "attitude", "category": "Attitude"},
    {"key": "norm.position.ground_course_deg", "label": "Course Over Ground", "unit": "deg", "path": ["position", "ground_course_deg"], "digits": 0, "age_key": "position", "category": "Navigation"},
    {"key": "norm.attitude.roll_deg", "label": "Roll", "unit": "deg", "path": ["attitude", "roll_deg"], "digits": 1, "age_key": "attitude", "category": "Attitude"},
    {"key": "norm.attitude.pitch_deg", "label": "Pitch", "unit": "deg", "path": ["attitude", "pitch_deg"], "digits": 1, "age_key": "attitude", "category": "Attitude"},
    {"key": "norm.position.latitude", "label": "Latitude", "unit": "deg", "path": ["position", "lat"], "digits": 6, "age_key": "position", "category": "Navigation"},
    {"key": "norm.position.longitude", "label": "Longitude", "unit": "deg", "path": ["position", "lon"], "digits": 6, "age_key": "position", "category": "Navigation"},
    {"key": "norm.battery.voltage_v", "label": "Raw Voltage", "unit": "V", "path": ["battery", "voltage_v"], "digits": 2, "age_key": "battery", "category": "Battery"},
    {"key": "norm.battery.voltage_smooth_v", "label": "Smooth Voltage", "unit": "V", "path": ["battery", "voltage_smooth_v"], "digits": 2, "age_key": "battery", "category": "Battery", "renderer": "smooth_voltage"},
    {"key": "norm.battery.estimated_pct", "label": "Battery %", "unit": "%", "path": ["battery", "estimated_pct"], "digits": 0, "age_key": "battery", "category": "Battery", "renderer": "battery_percent"},
    {"key": "norm.battery.current_a", "label": "Current", "unit": "A", "path": ["battery", "current_a"], "digits": 1, "age_key": "battery", "category": "Battery"},
    {"key": "norm.battery.consumed_mah", "label": "Consumed", "unit": "mAh", "path": ["battery", "consumed_mah"], "digits": 0, "age_key": "battery", "category": "Battery"},
    {"key": "norm.battery.remaining_pct", "label": "Battery Remaining", "unit": "%", "path": ["battery", "remaining_pct"], "digits": 0, "age_key": "battery", "category": "Battery"},
    {"key": "norm.gps.fix", "label": "GPS Fix", "unit": "", "path": ["gps", "fix"], "age_key": "gps", "category": "GPS"},
    {"key": "norm.gps.fix_type", "label": "GPS Fix Type", "unit": "", "path": ["gps", "fix_type"], "digits": 0, "age_key": "gps", "category": "GPS"},
    {"key": "norm.gps.satellites", "label": "GPS Sats", "unit": "", "path": ["gps", "satellites"], "digits": 0, "age_key": "gps", "category": "GPS"},
    {"key": "norm.gps.hdop", "label": "GPS HDOP", "unit": "", "path": ["gps", "hdop"], "digits": 2, "age_key": "gps", "category": "GPS"},
    {"key": "norm.navigation.home_bearing_deg", "label": "Home Bearing", "unit": "deg", "path": ["navigation", "home_bearing_deg"], "digits": 0, "age_key": "position", "category": "Navigation"},
    {"key": "norm.navigation.waypoint_current", "label": "Current Waypoint", "unit": "", "path": ["navigation", "waypoint_current"], "digits": 0, "age_key": "navigation", "category": "Navigation"},
    {"key": "norm.navigation.target_bearing_deg", "label": "Target Bearing", "unit": "deg", "path": ["navigation", "target_bearing_deg"], "digits": 0, "age_key": "navigation", "category": "Navigation"},
    # SIYI_4_2_0_WIND_SPEED_MPS_FIX_V1
    # SIYI_4_2_2_WIND_INDICATOR_TELEMETRY_FIELD_V1
    {"key": "norm.wind.relative_indicator", "label": "Wind", "unit": "", "path": ["wind", "relative_indicator"], "age_keys": ["wind", "attitude"], "category": "Wind", "renderer": "wind_indicator"},
    {"key": "norm.wind.speed_m_s", "label": "Wind Spd", "unit": "m/s", "path": ["wind", "speed_m_s"], "digits": 1, "age_key": "wind", "category": "Wind"},
    {"key": "norm.wind.gust_m_s", "label": "Wind Gust", "unit": "m/s", "path": ["wind", "gust_m_s"], "digits": 1, "age_key": "wind", "category": "Wind", "renderer": "wind_gust"},
    {"key": "norm.wind.direction_deg", "label": "Wind Direction", "unit": "deg", "path": ["wind", "direction_deg"], "digits": 0, "age_key": "wind", "category": "Wind"},
    {"key": "norm.wind.vertical_m_s", "label": "Vertical Wind", "unit": "m/s", "path": ["wind", "vertical_m_s"], "digits": 1, "age_key": "wind", "category": "Wind"},
    {"key": "norm.link.rssi", "label": "RSSI", "unit": "", "path": ["link", "rssi"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.remote_rssi", "label": "Remote RSSI", "unit": "", "path": ["link", "remote_rssi"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.noise", "label": "Radio Noise", "unit": "", "path": ["link", "noise"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.remote_noise", "label": "Remote Noise", "unit": "", "path": ["link", "remote_noise"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.rx_errors", "label": "RX Errors", "unit": "", "path": ["link", "rx_errors"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.fixed_packets", "label": "Fixed Packets", "unit": "", "path": ["link", "fixed_packets"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.vehicle.mode", "label": "Flight Mode", "unit": "", "path": ["vehicle", "mode"], "age_key": "heartbeat", "category": "Vehicle"},
    {"key": "norm.vehicle.armed", "label": "Armed", "unit": "", "path": ["vehicle", "armed"], "age_key": "heartbeat", "category": "Vehicle"},
    # FLIGHTCORE_4_3_0_RC16_ARSP_TELEMETRY_PRESENTATION_V1
    {"key": "norm.airspeed_sensor.status", "label": "ARSP Health", "unit": "", "path": ["airspeed_sensor", "status"], "category": "Vehicle"},
    {"key": "norm.timers.armed_s", "label": "Armed Time", "unit": "s", "path": ["timers", "armed_s"], "digits": 0, "age_key": "heartbeat", "category": "Vehicle"},
]

DEFAULT_TELEMETRY_LAYOUT = {
    "schema_version": TELEMETRY_LAYOUT_SCHEMA_VERSION,
    "visible": True,
    "layout": {
        "left": None,
        "top": None,
        "width": 320,
        "height": 280,
        "auto_fit": True,
        "columns": 2,
        "rows": 6,
        "flow": "row",
        "font_size": 17,
        "show_labels": True,
        "show_units": True,
    },

    "battery_stabilization": {
        "enabled": False,
        "pack_resistance_mohm": 0.0,
        "normal_cruise_current_a": 6.0,
        "battery_chemistry": "",
        "battery_series_cells": 6,
        "battery_full_v_per_cell": 4.10,
        "battery_empty_v_per_cell": 3.00,
    },

    "selected_fields": [
            "norm.speed.groundspeed_kmh",
            "norm.position.relative_alt_m",
            "norm.timers.flight_time_text",
            "norm.navigation.home_distance_m",
            "norm.navigation.flight_distance_m",
            "norm.battery.consumed_mah",
            "norm.battery.current_a",
            "norm.speed.airspeed_kmh",
            "norm.battery.voltage_v",
            "norm.battery.voltage_smooth_v",
            "norm.wind.relative_indicator",
            "norm.timers.local_time_text",
            "norm.speed.throttle_pct",
        ],}
DEFAULT_CONFIG: Dict[str, Any] = {
    "enabled": True,
    "mavlink": {
        "host": "0.0.0.0",
        "port": 14602,
        "system_id": 254,
        "component_id": 192,
        "manage_message_intervals": False,
    },
    "internal_api": {"host": "127.0.0.1", "port": 18765},
    "video": {
        "path": "main.264",
        "primary_protocol": "webrtc",
        "fallback_protocol": "hls",
    },
    "controls": {"enabled": False},
    "telemetry": {
        "airspeed_unit": "kmh",
        "altitude_unit": "m",
        "distance_unit": "metric",
    },
    "warnings": {
        "heartbeat_degraded_s": 3.0,
        "heartbeat_lost_s": 5.0,
    },
    "track": {"maximum_points": 3000, "minimum_interval_s": 0.8},
}


def deep_merge(base: Dict[str, Any], incoming: Dict[str, Any]) -> Dict[str, Any]:
    result = copy.deepcopy(base)
    for key, value in incoming.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def load_config() -> Dict[str, Any]:
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("configuration root is not an object")
        return deep_merge(DEFAULT_CONFIG, raw)
    except FileNotFoundError:
        return copy.deepcopy(DEFAULT_CONFIG)
    except Exception as exc:
        print(f"[GROUNDSTATION_CONFIG] using defaults: {exc!r}", flush=True)
        return copy.deepcopy(DEFAULT_CONFIG)



def _deep_get(payload: Dict[str, Any], path: list[str]) -> Any:
    value: Any = payload
    for item in path:
        if not isinstance(value, dict):
            return None
        value = value.get(item)
    return value


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace").rstrip("\\x00")
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    try:
        number = float(value)
        if math.isfinite(number):
            return number
    except (TypeError, ValueError):
        pass
    return str(value)



def _migrate_wind_speed_unit_overrides(value: Any) -> tuple[Any, bool]:
    field_key = "norm.wind.speed_m_s"
    unit_names = {
        "unit",
        "unit_override",
        "unitOverride",
        "display_unit",
        "displayUnit",
    }
    map_names = {
        "units",
        "unit_overrides",
        "unitOverrides",
        "display_units",
        "displayUnits",
    }

    def old_unit(candidate: Any) -> bool:
        return str(candidate or "").strip().lower().replace(" ", "") == "km/h"

    changed = False
    if isinstance(value, list):
        for index, child in enumerate(value):
            migrated, child_changed = _migrate_wind_speed_unit_overrides(child)
            if child_changed:
                value[index] = migrated
                changed = True
        return value, changed

    if not isinstance(value, dict):
        return value, False

    identifiers = (
        value.get("key"),
        value.get("field"),
        value.get("id"),
        value.get("telemetryKey"),
        value.get("telemetry_key"),
    )
    if any(str(candidate or "") == field_key for candidate in identifiers):
        for name in unit_names:
            if name in value and old_unit(value.get(name)):
                value[name] = "m/s"
                changed = True

    for name in map_names:
        unit_map = value.get(name)
        if isinstance(unit_map, dict) and old_unit(unit_map.get(field_key)):
            unit_map[field_key] = "m/s"
            changed = True

    for key, child in list(value.items()):
        migrated, child_changed = _migrate_wind_speed_unit_overrides(child)
        if child_changed:
            value[key] = migrated
            changed = True

    return value, changed

def _normalise_telemetry_layout(payload: Any) -> Dict[str, Any]:
    base = copy.deepcopy(DEFAULT_TELEMETRY_LAYOUT)
    if not isinstance(payload, dict):
        return base
    payload, _wind_unit_migrated = _migrate_wind_speed_unit_overrides(copy.deepcopy(payload))
    base["visible"] = bool(payload.get("visible", base["visible"]))
    incoming_layout = payload.get("layout") if isinstance(payload.get("layout"), dict) else {}
    layout = base["layout"]

    def number_or_none(name: str, minimum: float, maximum: float, fallback: Any) -> Any:
        value = incoming_layout.get(name, fallback)
        if value is None and name in {"left", "top"}:
            return None
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            return fallback
        if not math.isfinite(numeric):
            return fallback
        return max(minimum, min(maximum, numeric))

    layout["left"] = number_or_none("left", 0, 10000, layout["left"])
    layout["top"] = number_or_none("top", 0, 10000, layout["top"])
    layout["width"] = int(round(number_or_none("width", 20, 1600, layout["width"])))
    layout["height"] = int(round(number_or_none("height", 20, 1200, layout["height"])))
    layout["columns"] = int(round(number_or_none("columns", 1, 24, layout["columns"])))
    layout["rows"] = int(round(number_or_none("rows", 1, 24, layout["rows"])))
    layout["font_size"] = int(round(number_or_none("font_size", 10, 40, layout["font_size"])))
    layout["flow"] = "column" if incoming_layout.get("flow") == "column" else "row"
    layout["show_labels"] = bool(incoming_layout.get("show_labels", layout["show_labels"]))
    layout["show_units"] = bool(incoming_layout.get("show_units", layout["show_units"]))
    layout["auto_fit"] = bool(incoming_layout.get("auto_fit", layout["auto_fit"]))
    # GROUND_STATION_TELEMETRY_CANVAS_V2_CONTENT_FIT

    incoming_battery = payload.get("battery_stabilization")
    if not isinstance(incoming_battery, dict):
        incoming_battery = {}
    battery_config = base["battery_stabilization"]
    battery_config["enabled"] = bool(
        incoming_battery.get("enabled", battery_config["enabled"])
    )
    try:
        resistance_mohm = float(
            incoming_battery.get(
                "pack_resistance_mohm",
                battery_config["pack_resistance_mohm"],
            )
        )
    except (TypeError, ValueError):
        resistance_mohm = float(battery_config["pack_resistance_mohm"])
    if not math.isfinite(resistance_mohm):
        resistance_mohm = 0.0
    battery_config["pack_resistance_mohm"] = max(0.0, min(200.0, resistance_mohm))

    try:
        cruise_current = float(incoming_battery.get(
            "normal_cruise_current_a", battery_config["normal_cruise_current_a"]
        ))
    except (TypeError, ValueError):
        cruise_current = float(battery_config["normal_cruise_current_a"])
    if not math.isfinite(cruise_current):
        cruise_current = 6.0
    battery_config["normal_cruise_current_a"] = max(0.5, min(100.0, cruise_current))

    chemistry = str(incoming_battery.get("battery_chemistry", "") or "").strip().lower()
    if chemistry not in {"lipo", "liion"}:
        chemistry = ""
    battery_config["battery_chemistry"] = chemistry

    try:
        series_cells = int(round(float(incoming_battery.get(
            "battery_series_cells", battery_config["battery_series_cells"]
        ))))
    except (TypeError, ValueError):
        series_cells = int(battery_config["battery_series_cells"])
    battery_config["battery_series_cells"] = max(1, min(24, series_cells))

    defaults = {"lipo": (4.20, 3.50), "liion": (4.10, 3.00)}
    default_full, default_empty = defaults.get(chemistry, (4.10, 3.00))
    try:
        full_v = float(incoming_battery.get("battery_full_v_per_cell", default_full))
    except (TypeError, ValueError):
        full_v = default_full
    try:
        empty_v = float(incoming_battery.get("battery_empty_v_per_cell", default_empty))
    except (TypeError, ValueError):
        empty_v = default_empty
    if not math.isfinite(full_v):
        full_v = default_full
    if not math.isfinite(empty_v):
        empty_v = default_empty
    battery_config["battery_full_v_per_cell"] = full_v
    battery_config["battery_empty_v_per_cell"] = empty_v
    if not (3.50 <= full_v <= 4.40 and 2.50 <= empty_v <= 4.00 and full_v - empty_v >= 0.20):
        # Invalid endpoints are retained for UI correction, but chemistry is
        # cleared so Battery % cannot silently use an unsafe configuration.
        battery_config["battery_chemistry"] = ""

    selected: list[str] = []
    for item in payload.get("selected_fields", base["selected_fields"]):
        key = str(item or "").strip()
        if not key or len(key) > 180 or not (key.startswith("norm.") or key.startswith("raw.")):
            continue
        if key not in selected:
            selected.append(key)
        if len(selected) >= 1000:
            break
    base["selected_fields"] = selected or copy.deepcopy(DEFAULT_TELEMETRY_LAYOUT["selected_fields"])
    base["schema_version"] = TELEMETRY_LAYOUT_SCHEMA_VERSION
    return base


def _write_telemetry_layout_copy(path: Path, config: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}.{threading.get_ident()}")
    temporary.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.chmod(temporary, 0o664)
    os.replace(temporary, path)


def load_telemetry_layout() -> Dict[str, Any]:
    errors: list[str] = []
    for path in (TELEMETRY_LAYOUT_PATH, TELEMETRY_LAYOUT_SHADOW_PATH):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            config = _normalise_telemetry_layout(payload)
            for copy_path in (TELEMETRY_LAYOUT_PATH, TELEMETRY_LAYOUT_SHADOW_PATH):
                try:
                    _write_telemetry_layout_copy(copy_path, config)
                except Exception as exc:
                    errors.append(f"{copy_path}: {exc!r}")
            if errors:
                print("[GROUNDSTATION_TELEMETRY_CONFIG] mirror warning: " + "; ".join(errors), flush=True)
            return config
        except FileNotFoundError:
            continue
        except Exception as exc:
            errors.append(f"{path}: {exc!r}")
    if errors:
        print("[GROUNDSTATION_TELEMETRY_CONFIG] using defaults: " + "; ".join(errors), flush=True)
    return copy.deepcopy(DEFAULT_TELEMETRY_LAYOUT)


def save_telemetry_layout(payload: Any) -> Dict[str, Any]:
    config = _normalise_telemetry_layout(payload)
    failures: list[str] = []
    saved = 0
    for path in (TELEMETRY_LAYOUT_PATH, TELEMETRY_LAYOUT_SHADOW_PATH):
        try:
            _write_telemetry_layout_copy(path, config)
            saved += 1
        except Exception as exc:
            failures.append(f"{path}: {exc!r}")
    if saved == 0:
        raise OSError("could not save Telemetry Canvas configuration: " + "; ".join(failures))
    if failures:
        print("[GROUNDSTATION_TELEMETRY_CONFIG] mirror warning: " + "; ".join(failures), flush=True)
    return config


RAW_CANONICAL_FIELD_LABELS = {
    "groundspeed": "Ground Speed",
    "airspeed": "Air Speed",
    "relative_alt": "Alt (Rel)",
    "voltage_battery": "Voltage",
    "current_battery": "Current",
    "current_consumed": "Consumed",
    "battery_remaining": "Battery Remaining",
    "throttle": "Throttle %",
    "throttle_scaled": "Throttle %",
    "satellites_visible": "GPS Sats",
    "eph": "GPS HDOP",
    "hdop": "GPS HDOP",
    "wp_dist": "Distance to Waypoint",
    "target_bearing": "Target Bearing",
    "nav_bearing": "Navigation Bearing",
    "heading": "Heading",
    "cog": "Course Over Ground",
    "lat": "Latitude",
    "lon": "Longitude",
}

CANONICAL_ACRONYMS = {
    "gps": "GPS",
    "rssi": "RSSI",
    "hdop": "HDOP",
    "vdop": "VDOP",
    "uid": "UID",
    "id": "ID",
    "imu": "IMU",
    "rpm": "RPM",
    "rc": "RC",
    "wp": "WP",
    "mav": "MAV",
}

def canonical_field_label(field_name: str) -> str:
    key = str(field_name or "").strip().lower()
    if key in RAW_CANONICAL_FIELD_LABELS:
        return RAW_CANONICAL_FIELD_LABELS[key]
    words = [part for part in key.replace("[", " ").replace("]", " ").split("_") if part]
    if not words:
        return str(field_name or "")
    return " ".join(CANONICAL_ACRONYMS.get(word, word.capitalize()) for word in words)

def canonical_category_name(message_name: str) -> str:
    words = [part for part in str(message_name or "").strip().lower().split("_") if part]
    return " ".join(CANONICAL_ACRONYMS.get(word, word.capitalize()) for word in words)


def build_telemetry_catalog() -> list[Dict[str, Any]]:
    catalog: list[Dict[str, Any]] = []
    for item in NORMALIZED_TELEMETRY_FIELDS:
        catalog.append(
            {
                "key": item["key"],
                "label": item["label"],
                "unit": item.get("unit", ""),
                "category": item.get("category", "Ground Station"),
                "message": "NORMALIZED",
                "field": item["key"].rsplit(".", 1)[-1],
                "type": "normalized",
                "digits": item.get("digits"),
                "renderer": item.get("renderer", ""),
            }
        )
    mavlink_map = getattr(mavutil.mavlink, "mavlink_map", {}) or {}
    for message_id, message_class in sorted(mavlink_map.items(), key=lambda pair: int(pair[0])):
        name = str(
            getattr(message_class, "msgname", "")
            or getattr(message_class, "name", "")
            or f"MSG_{message_id}"
        ).upper()
        fields = list(getattr(message_class, "fieldnames", []) or [])
        types = list(getattr(message_class, "fieldtypes", []) or [])
        arrays = list(getattr(message_class, "array_lengths", []) or [])
        units_by_name = dict(getattr(message_class, "fieldunits_by_name", {}) or {})
        enums_by_name = dict(getattr(message_class, "fieldenums_by_name", {}) or {})
        for index, field in enumerate(fields):
            field_name = str(field)
            field_type = str(types[index]) if index < len(types) else ""
            array_length = int(arrays[index] or 0) if index < len(arrays) else 0
            unit = str(units_by_name.get(field_name) or "")
            enum = str(enums_by_name.get(field_name) or "")
            label_base = canonical_field_label(field_name)
            category_label = canonical_category_name(name)
            if array_length > 0 and field_type.lower() not in {"char", "char[]"}:
                for array_index in range(array_length):
                    catalog.append(
                        {
                            "key": f"raw.{name}.{field_name}[{array_index + 1}]",
                            "label": f"{label_base} {array_index + 1}",
                            "unit": unit,
                            "category": category_label,
                            "message": name,
                            "field": f"{field_name}[{array_index + 1}]",
                            "type": field_type,
                            "enum": enum,
                            "message_id": int(message_id),
                        }
                    )
            else:
                catalog.append(
                    {
                        "key": f"raw.{name}.{field_name}",
                        "label": label_base,
                        "unit": unit,
                        "category": category_label,
                        "message": name,
                        "field": field_name,
                        "type": field_type,
                        "enum": enum,
                        "message_id": int(message_id),
                    }
                )
    return catalog

def finite(value: Any) -> Optional[float]:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def degrees(value: Any) -> Optional[float]:
    number = finite(value)
    return math.degrees(number) if number is not None else None


def gps_fix_name(value: int) -> str:
    return {
        0: "NO GPS",
        1: "NO FIX",
        2: "2D",
        3: "3D",
        4: "DGPS",
        5: "RTK FLOAT",
        6: "RTK FIXED",
        7: "STATIC",
        8: "PPP",
    }.get(int(value or 0), "UNKNOWN")


def severity_name(value: int) -> str:
    return {
        0: "Emergency",
        1: "Alert",
        2: "Critical",
        3: "Error",
        4: "Warning",
        5: "Notice",
        6: "Info",
        7: "Debug",
    }.get(int(value or 6), "Info")


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    radius = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * radius * math.atan2(math.sqrt(a), math.sqrt(max(0.0, 1.0 - a)))


def bearing_deg(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    y = math.sin(dl) * math.cos(p2)
    x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(y, x)) + 360.0) % 360.0


def format_hms(total_seconds: Any) -> str:
    number = finite(total_seconds)
    if number is None or number < 0:
        number = 0.0
    seconds = int(round(number))
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


class WindGustDetector:
    """Display-only validated wind-gust detector.

    The detector works on the incoming horizontal WIND vector. It never sends
    MAVLink commands and has no aircraft-control side effects.
    """

    FAST_TAU_S = 0.50
    BACKGROUND_TAU_S = 30.0
    PERSISTENCE_S = 0.75
    HOLD_S = 10.0
    MIN_DELTA_M_S = 1.0
    FRACTIONAL_DELTA = 0.20
    SOURCE_GAP_RESET_S = 3.0

    def __init__(self) -> None:
        self.fast_x: Optional[float] = None
        self.fast_y: Optional[float] = None
        self.background_x: Optional[float] = None
        self.background_y: Optional[float] = None
        self.fast_scalar_m_s: Optional[float] = None
        self.background_scalar_m_s: Optional[float] = None
        self.last_sample_at: Optional[float] = None
        self.candidate_since: Optional[float] = None
        self.candidate_peak_m_s: Optional[float] = None
        self.candidate_validated = False
        self.active_peak_m_s: Optional[float] = None
        self.hold_until = 0.0
        self.last_fast_m_s: Optional[float] = None
        self.last_background_m_s: Optional[float] = None
        self.last_delta_m_s: Optional[float] = None
        self.last_threshold_m_s: Optional[float] = None

    @staticmethod
    def _vector(speed_m_s: float, direction_deg: float) -> Tuple[float, float]:
        angle = math.radians(direction_deg % 360.0)
        return speed_m_s * math.cos(angle), speed_m_s * math.sin(angle)

    @staticmethod
    def _ema(previous: float, current: float, dt: float, tau: float) -> float:
        if tau <= 0.0:
            return current
        alpha = 1.0 - math.exp(-max(0.0, dt) / tau)
        return previous + alpha * (current - previous)

    def _reset_candidate(self) -> None:
        self.candidate_since = None
        self.candidate_peak_m_s = None
        self.candidate_validated = False

    def _baseline_from_sample(self, speed_m_s: float, direction_deg: float, now: float) -> None:
        x, y = self._vector(speed_m_s, direction_deg)
        self.fast_x = self.background_x = x
        self.fast_y = self.background_y = y
        self.fast_scalar_m_s = speed_m_s
        self.background_scalar_m_s = speed_m_s
        self.last_sample_at = now
        self.last_fast_m_s = speed_m_s
        self.last_background_m_s = speed_m_s
        self.last_delta_m_s = 0.0
        self.last_threshold_m_s = max(self.MIN_DELTA_M_S, self.FRACTIONAL_DELTA * speed_m_s)
        self._reset_candidate()

    def refresh(self, now: float) -> Dict[str, Any]:
        if self.last_sample_at is not None and now - self.last_sample_at > self.SOURCE_GAP_RESET_S:
            self._reset_candidate()
        if self.active_peak_m_s is not None and now >= self.hold_until:
            self.active_peak_m_s = None
            self.hold_until = 0.0
        return self.snapshot(now)

    def update(self, speed_m_s: Any, direction_deg: Any, now: float) -> Dict[str, Any]:
        speed = finite(speed_m_s)
        direction = finite(direction_deg)
        if speed is None or speed < 0.0 or direction is None:
            self._reset_candidate()
            return self.refresh(now)

        if self.last_sample_at is None or now - self.last_sample_at > self.SOURCE_GAP_RESET_S:
            self._baseline_from_sample(speed, direction, now)
            return self.refresh(now)

        dt = max(0.001, now - self.last_sample_at)
        x, y = self._vector(speed, direction)
        self.fast_x = self._ema(float(self.fast_x), x, dt, self.FAST_TAU_S)
        self.fast_y = self._ema(float(self.fast_y), y, dt, self.FAST_TAU_S)
        self.background_x = self._ema(float(self.background_x), x, dt, self.BACKGROUND_TAU_S)
        self.background_y = self._ema(float(self.background_y), y, dt, self.BACKGROUND_TAU_S)
        self.fast_scalar_m_s = self._ema(float(self.fast_scalar_m_s), speed, dt, self.FAST_TAU_S)
        self.background_scalar_m_s = self._ema(float(self.background_scalar_m_s), speed, dt, self.BACKGROUND_TAU_S)
        self.last_sample_at = now

        # Speed detection uses the magnitude series while the input/filter layer
        # remains vector-aware. This prevents a pure wind-direction reversal
        # from collapsing the vector baseline and being misclassified as a gust.
        # It is a conservative credibility guard against turns/navigation transients.
        fast_speed = float(self.fast_scalar_m_s)
        background_speed = float(self.background_scalar_m_s)
        delta = fast_speed - background_speed
        threshold = max(self.MIN_DELTA_M_S, self.FRACTIONAL_DELTA * background_speed)
        self.last_fast_m_s = fast_speed
        self.last_background_m_s = background_speed
        self.last_delta_m_s = delta
        self.last_threshold_m_s = threshold

        above = delta >= threshold
        if above:
            if self.candidate_since is None:
                self.candidate_since = now
                self.candidate_peak_m_s = fast_speed
                self.candidate_validated = False
            else:
                self.candidate_peak_m_s = max(float(self.candidate_peak_m_s or 0.0), fast_speed)

            if not self.candidate_validated and now - float(self.candidate_since) >= self.PERSISTENCE_S:
                self.candidate_validated = True
                peak = float(self.candidate_peak_m_s or fast_speed)
                if self.active_peak_m_s is None or now >= self.hold_until or peak > self.active_peak_m_s:
                    self.active_peak_m_s = peak
                    self.hold_until = now + self.HOLD_S
            elif self.candidate_validated and self.active_peak_m_s is not None:
                peak = float(self.candidate_peak_m_s or fast_speed)
                if peak > self.active_peak_m_s:
                    self.active_peak_m_s = peak
                    self.hold_until = now + self.HOLD_S
        else:
            self._reset_candidate()

        return self.refresh(now)

    def snapshot(self, now: float) -> Dict[str, Any]:
        if self.candidate_since is None:
            detector_state = "HOLD" if self.active_peak_m_s is not None else "IDLE"
        else:
            detector_state = "ACTIVE" if self.candidate_validated else "CANDIDATE"
        return {
            "gust_m_s": round(self.active_peak_m_s, 3) if self.active_peak_m_s is not None else None,
            "gust_state": detector_state,
            "gust_fast_m_s": round(self.last_fast_m_s, 3) if self.last_fast_m_s is not None else None,
            "gust_background_m_s": round(self.last_background_m_s, 3) if self.last_background_m_s is not None else None,
            "gust_delta_m_s": round(self.last_delta_m_s, 3) if self.last_delta_m_s is not None else None,
            "gust_threshold_m_s": round(self.last_threshold_m_s, 3) if self.last_threshold_m_s is not None else None,
            "gust_candidate_peak_m_s": round(self.candidate_peak_m_s, 3) if self.candidate_peak_m_s is not None else None,
            "gust_candidate_age_s": round(max(0.0, now - self.candidate_since), 3) if self.candidate_since is not None else None,
            "gust_hold_remaining_s": round(max(0.0, self.hold_until - now), 3) if self.active_peak_m_s is not None else 0.0,
        }


class VehicleState:
    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.lock = threading.RLock()
        self.started_monotonic = time.monotonic()
        self.started_wall = time.time()
        self.selected_vehicle: Optional[Tuple[int, int]] = None
        self.vehicle_heartbeats: Dict[Tuple[int, int], float] = {}
        self.field_times: Dict[str, float] = {}
        self.messages = deque(maxlen=250)
        self.track = deque(maxlen=int(config.get("track", {}).get("maximum_points", 3000)))
        self.track_sequence = 0
        self.last_track_time = 0.0
        self.last_track_position: Optional[Tuple[float, float]] = None
        self.armed_since: Optional[float] = None
        self.total_armed_s = 0.0
        self.flight_distance_m = 0.0
        self.flight_distance_last_position: Optional[Tuple[float, float]] = None
        self.flight_distance_last_time: Optional[float] = None
        self.raw_telemetry_values: Dict[str, Any] = {}
        self.raw_telemetry_times: Dict[str, float] = {}
        self.telemetry_catalog = build_telemetry_catalog()
        self.telemetry_layout = load_telemetry_layout()
        self.battery_voltage_samples = deque(maxlen=3)
        self.battery_voltage_envelope = deque(maxlen=1200)
        self.battery_voltage_cruise_samples = deque(maxlen=1200)
        self.battery_voltage_cruise_baseline_acquired = False
        self.battery_percentage_last: Optional[float] = None
        self.battery_percentage_source: str = "unavailable"
        self.battery_voltage_stable_v: Optional[float] = None
        self.battery_voltage_candidate_v: Optional[float] = None
        self.battery_voltage_last_update: Optional[float] = None
        self.battery_voltage_last_current_a: Optional[float] = None
        self.battery_voltage_hold_until = 0.0
        self.battery_voltage_drop_confirm_since: Optional[float] = None
        self.battery_voltage_compensation_was_active = False
        self.battery_voltage_armed_was = False
        # FLIGHTCORE_4_2_3_RC3_RELAXED_VOLTAGE_ESTIMATOR_V1
        self.battery_voltage_last_raw_v: Optional[float] = None
        self.battery_voltage_idle_current_a: Optional[float] = None
        self.battery_voltage_effective_resistance_ohm: Optional[float] = None
        self.battery_voltage_config_resistance_ohm: Optional[float] = None
        self.battery_voltage_resistance_samples = deque(maxlen=31)
        self.battery_voltage_slow_load_a = 0.0
        self.battery_voltage_polar_resistance_ohm: Optional[float] = None
        self.battery_voltage_polar_samples = deque(maxlen=31)
        self.battery_voltage_recovery_probe: Optional[Dict[str, float]] = None
        # FLIGHTCORE_4_2_3_RC6_SMOOTH_VOLTAGE_ANTI_DRIFT_V1
        # Display-only estimator guard: cruise may move the resting estimate down
        # with real depletion, but may not slowly ratchet it upward without
        # low-load reference evidence.
        # FLIGHTCORE_4_2_3_RC12_SMOOTH_LOW_CURRENT_FADE_MONOTONIC_V1
        # Low-current correction is confirmed before it is faded, and the
        # displayed Smooth Voltage is session-monotonic: it may hold or decrease,
        # but it never increases after acquisition.
        self.battery_voltage_low_current_since: Optional[float] = None
        self.battery_consumed_mah_floor: Optional[int] = None
        self.battery_consumed_mah_last_update: Optional[float] = None
        self.wind_gust_detector = WindGustDetector()
        self.state: Dict[str, Any] = {
            "connection": {
                "state": "NO_VEHICLE",
                "heartbeat_age_s": None,
                "system_id": None,
                "component_id": None,
                "multiple_vehicles": False,
            },
            "vehicle": {
                "type": None,
                "autopilot": None,
                "armed": None,
                "mode": None,
                "system_status": None,
            },
            "attitude": {"roll_deg": None, "pitch_deg": None, "heading_deg": None},
            "position": {
                "lat": None,
                "lon": None,
                "relative_alt_m": None,
                "amsl_alt_m": None,
                "ground_course_deg": None,
            },
            "speed": {
                "airspeed_m_s": None,
                "groundspeed_m_s": None,
                "vertical_speed_m_s": None,
                "throttle_pct": None,
            },
            "battery": {
                "voltage_v": None,
                "voltage_compensated_v": None,
                "voltage_smooth_v": None,
                "voltage_filter_status": "unavailable",
                "voltage_tracker_state": "unavailable",
                "voltage_tracker_candidate_v": None,
                "voltage_compensation_active": False,
                "voltage_compensation_clamped": False,
                "voltage_effective_resistance_mohm": None,
                "voltage_polarization_v": None,
                "voltage_idle_current_a": None,
                "voltage_slow_load_a": None,
                "estimated_pct": None,
                "percentage_status": "unavailable",
                "percentage_source": "unavailable",
                "percentage_per_cell_v": None,
                "configured_cell_count": None,
                "cell_count": None,
                "current_a": None,
                "remaining_pct": None,
                "consumed_mah": None,
            },
            "gps": {"fix": "UNKNOWN", "fix_type": None, "satellites": None, "hdop": None},
            "navigation": {
                "home_lat": None,
                "home_lon": None,
                "home_distance_m": None,
                "home_bearing_deg": None,
                "waypoint_current": None,
                "waypoint_reached": None,
                "target_bearing_deg": None,
                "distance_to_waypoint_m": None,
                "flight_distance_m": 0.0,
            },
            "link": {
                "rssi": None,
                "remote_rssi": None,
                "noise": None,
                "remote_noise": None,
                "rx_errors": None,
                "fixed_packets": None,
            },
            "wind": {
                "speed_m_s": None,
                "direction_deg": None,
                "vertical_m_s": None,
                "relative_indicator": None,
                "gust_m_s": None,
                "gust_state": "IDLE",
                "gust_fast_m_s": None,
                "gust_background_m_s": None,
                "gust_delta_m_s": None,
                "gust_threshold_m_s": None,
                "gust_candidate_peak_m_s": None,
                "gust_candidate_age_s": None,
                "gust_hold_remaining_s": 0.0,
            },
            "rc": {"channels": []},
            "servo": {"outputs": []},
            "timers": {"connected_s": 0.0, "armed_s": 0.0, "flight_time_text": "00:00:00", "local_time_text": time.strftime("%H:%M:%S")},
            "messages": [],
            "track": [],
            "field_age_s": {},
            "service": {
                "monitor_only": True,
                "started_at": self.started_wall,
                "last_packet_at": None,
                "packet_count": 0,
            },
        }

    def _touch(self, field: str, now: float) -> None:
        self.field_times[field] = now

    def _battery_stabilization_config_locked(self) -> Dict[str, Any]:
        config = self.telemetry_layout.get("battery_stabilization", {})
        if not isinstance(config, dict):
            config = {}
        return {
            "enabled": bool(config.get("enabled", True)),
            "pack_resistance_mohm": max(
                0.0,
                min(200.0, finite(config.get("pack_resistance_mohm")) or 0.0),
            ),
            "normal_cruise_current_a": max(
                0.5,
                min(100.0, finite(config.get("normal_cruise_current_a")) or 6.0),
            ),
            "battery_chemistry": str(config.get("battery_chemistry", "") or "").strip().lower(),
            "battery_series_cells": max(
                1,
                min(24, int(round(finite(config.get("battery_series_cells")) or 6.0))),
            ),
            "battery_full_v_per_cell": finite(config.get("battery_full_v_per_cell")),
            "battery_empty_v_per_cell": finite(config.get("battery_empty_v_per_cell")),
        }

    def _reset_battery_voltage_tracker_locked(self, clear_stable: bool = True) -> None:
        self.battery_voltage_samples.clear()
        self.battery_voltage_envelope.clear()
        self.battery_voltage_cruise_samples.clear()
        self.battery_voltage_cruise_baseline_acquired = False
        self.battery_percentage_last = None
        self.battery_percentage_source = "unavailable"
        if clear_stable:
            self.battery_voltage_stable_v = None
        self.battery_voltage_candidate_v = None
        self.battery_voltage_last_update = None
        self.battery_voltage_last_current_a = None
        self.battery_voltage_hold_until = 0.0
        self.battery_voltage_drop_confirm_since = None
        self.battery_voltage_compensation_was_active = False
        self.battery_voltage_armed_was = False
        self.battery_voltage_last_raw_v = None
        self.battery_voltage_idle_current_a = None
        self.battery_voltage_effective_resistance_ohm = None
        self.battery_voltage_config_resistance_ohm = None
        self.battery_voltage_resistance_samples.clear()
        self.battery_voltage_slow_load_a = 0.0
        self.battery_voltage_polar_resistance_ohm = None
        self.battery_voltage_polar_samples.clear()
        self.battery_voltage_recovery_probe = None
        self.battery_voltage_low_current_since = None

    @staticmethod
    def _battery_upper_percentile(values: list[float], percentile: float = 0.90) -> Optional[float]:
        clean = sorted(value for value in values if math.isfinite(value))
        if not clean:
            return None
        index = int(round((len(clean) - 1) * max(0.0, min(1.0, percentile))))
        return clean[max(0, min(len(clean) - 1, index))]

    # SIYI_4_2_2_RC5_CRUISE_BASELINE_TRACKER_V1
    # SIYI_4_2_2_RC8_CONSERVATIVE_SMOOTH_VOLTAGE_AND_PERCENT_V1
    def _update_battery_stabilization_locked(self, now: float) -> None:
        """Estimate relaxed/resting battery voltage for display and voice only.

        RC3 separates immediate ohmic sag from delayed electrochemical recovery.
        The configured pack resistance is the starting prior for fast sag and is
        adapted from short load steps. A slow filtered propulsion-load state adds
        the remaining polarization/recovery term and is refined during low-load
        recovery windows. Normal cruise current only classifies stable/transient
        operating regions; it is never subtracted from sag compensation.

        RC6 preserves the successful fast/load compensation but prevents ordinary
        cruise evidence from slowly ratcheting the resting estimate upward.

        RC12 preserves all takeoff/cruise behavior at 3 A and above, but after
        twelve continuous seconds below 3 A it smoothly fades the displayed
        resistance/polarization correction: 0% at <=1 A, smooth transition from
        1-3 A, and 100% at >=3 A. At confirmed low current, Smooth may converge
        gently downward toward Raw with a thirty-second time constant. A hard
        session invariant prevents any upward movement after initial acquisition.

        Raw FC voltage, battery warnings and failsafes are not modified.
        """
        battery = self.state["battery"]
        raw_voltage = finite(battery.get("voltage_v"))
        if raw_voltage is None or raw_voltage <= 0.0 or raw_voltage > 100.0:
            battery.update({
                "voltage_compensated_v": None, "voltage_smooth_v": None,
                "voltage_filter_status": "unavailable", "voltage_tracker_state": "unavailable",
                "voltage_tracker_candidate_v": None, "voltage_compensation_active": False,
                "voltage_compensation_clamped": False,
                "voltage_effective_resistance_mohm": None,
                "voltage_polarization_v": None,
                "voltage_idle_current_a": None,
                "voltage_slow_load_a": None,
            })
            self._reset_battery_voltage_tracker_locked()
            return

        config = self._battery_stabilization_config_locked()
        if not bool(config["enabled"]):
            battery.update({
                "voltage_compensated_v": raw_voltage, "voltage_smooth_v": None,
                "voltage_filter_status": "disabled", "voltage_tracker_state": "disabled",
                "voltage_tracker_candidate_v": None, "voltage_compensation_active": False,
                "voltage_compensation_clamped": False,
                "voltage_effective_resistance_mohm": None,
                "voltage_polarization_v": None,
                "voltage_idle_current_a": None,
                "voltage_slow_load_a": None,
            })
            self._reset_battery_voltage_tracker_locked()
            return

        configured_r = float(config["pack_resistance_mohm"]) / 1000.0
        cruise_a = float(config["normal_cruise_current_a"])
        chemistry = str(config.get("battery_chemistry") or "")
        current_a = finite(battery.get("current_a"))
        configured_cells = int(config.get("battery_series_cells") or 0)
        try:
            telemetry_cells = int(battery.get("cell_count"))
        except (TypeError, ValueError):
            telemetry_cells = 0
        cell_count = configured_cells if 1 <= configured_cells <= 24 else telemetry_cells
        cell_count_valid = 1 <= cell_count <= 24
        current_valid = current_a is not None and 0.0 <= current_a <= 500.0
        compensation_active = bool(configured_r > 0.0 and current_valid and cell_count_valid)
        armed = self.state.get("vehicle", {}).get("armed") is True

        elapsed = None if self.battery_voltage_last_update is None else now - self.battery_voltage_last_update
        natural_gap = elapsed is None or elapsed > 3.0
        dt = 0.1 if elapsed is None else max(0.02, min(1.0, elapsed))
        mode_changed = compensation_active != self.battery_voltage_compensation_was_active
        just_armed = armed and not self.battery_voltage_armed_was
        just_disarmed = (not armed) and self.battery_voltage_armed_was
        self.battery_voltage_armed_was = armed

        # FLIGHTCORE_4_2_3_RC12_SMOOTH_LOW_CURRENT_FADE_MONOTONIC_V1
        # A brief throttle reduction must not change the established estimator.
        # Confirm low current for twelve continuous seconds before fading any
        # compensation or allowing Raw-voltage convergence.
        low_current_zero_a = 1.0
        low_current_full_a = 3.0
        low_current_confirm_s = 12.0
        low_current_converge_tau_s = 30.0
        if natural_gap:
            self.battery_voltage_low_current_since = None
        if current_valid and float(current_a) < low_current_full_a:
            if self.battery_voltage_low_current_since is None:
                self.battery_voltage_low_current_since = now
        else:
            self.battery_voltage_low_current_since = None
        low_current_confirmed = bool(
            self.battery_voltage_low_current_since is not None
            and now - self.battery_voltage_low_current_since >= low_current_confirm_s
        )
        low_current_compensation_factor = 1.0
        if low_current_confirmed and current_valid:
            value = float(current_a)
            if value <= low_current_zero_a:
                low_current_compensation_factor = 0.0
            elif value < low_current_full_a:
                t = (value - low_current_zero_a) / (low_current_full_a - low_current_zero_a)
                # Smoothstep avoids a visible kink at 1 A and 3 A.
                low_current_compensation_factor = t * t * (3.0 - 2.0 * t)

        if natural_gap or mode_changed:
            self.battery_voltage_samples.clear()
            self.battery_voltage_envelope.clear()
            self.battery_voltage_cruise_samples.clear()
            self.battery_voltage_drop_confirm_since = None
            self.battery_voltage_recovery_probe = None
        if self.battery_voltage_compensation_was_active and not compensation_active:
            self.battery_voltage_effective_resistance_ohm = None
            self.battery_voltage_config_resistance_ohm = None
            self.battery_voltage_resistance_samples.clear()
            self.battery_voltage_polar_resistance_ohm = None
            self.battery_voltage_polar_samples.clear()
            self.battery_voltage_slow_load_a = 0.0
        self.battery_voltage_compensation_was_active = compensation_active

        # Reinitialize adaptive electrical parameters when the user changes the
        # configured resistance. The user value remains the prior and bounding
        # reference; automatic learning cannot run if the user selects 0 mOhm.
        resistance_changed = (
            self.battery_voltage_config_resistance_ohm is None
            or abs(float(self.battery_voltage_config_resistance_ohm) - configured_r) > 1e-9
        )
        polar_ratio_default = 0.25 if chemistry == "liion" else (0.30 if chemistry == "lipo" else 0.40)
        if resistance_changed:
            self.battery_voltage_config_resistance_ohm = configured_r
            self.battery_voltage_effective_resistance_ohm = configured_r if configured_r > 0.0 else 0.0
            self.battery_voltage_resistance_samples.clear()
            self.battery_voltage_polar_resistance_ohm = configured_r * polar_ratio_default if configured_r > 0.0 else 0.0
            self.battery_voltage_polar_samples.clear()
            self.battery_voltage_recovery_probe = None

        effective_r = float(self.battery_voltage_effective_resistance_ohm or 0.0)
        polar_r = float(self.battery_voltage_polar_resistance_ohm or 0.0)

        # Learn the system-idle current (Pi/cameras/etc.) so "resting voltage"
        # means the practical low-load state seen on the aircraft, not theoretical
        # zero-current OCV. Disarmed/low-load evidence is favored.
        low_load_limit = max(1.5, cruise_a * 0.30)
        if current_valid:
            value = float(current_a)
            if self.battery_voltage_idle_current_a is None:
                self.battery_voltage_idle_current_a = value if (not armed or value <= low_load_limit) else 0.0
            elif not armed and value <= low_load_limit:
                alpha_idle = dt / (5.0 + dt)
                self.battery_voltage_idle_current_a += alpha_idle * (value - self.battery_voltage_idle_current_a)
            elif armed and value <= low_load_limit:
                tau_idle = 8.0 if value < self.battery_voltage_idle_current_a else 60.0
                alpha_idle = dt / (tau_idle + dt)
                self.battery_voltage_idle_current_a += alpha_idle * (value - self.battery_voltage_idle_current_a)
        idle_current = max(0.0, min(cruise_a * 0.50, float(self.battery_voltage_idle_current_a or 0.0)))

        previous_current = self.battery_voltage_last_current_a
        previous_raw = self.battery_voltage_last_raw_v
        delta_i = 0.0
        current_step_limit = max(1.5, cruise_a * 0.20)
        current_step = False
        if current_valid and previous_current is not None and not natural_gap:
            delta_i = float(current_a) - float(previous_current)
            current_step = abs(delta_i) >= current_step_limit

        # Adaptive fast resistance: a rapid current change with opposite voltage
        # movement is a direct in-flight R observation because SOC cannot change
        # materially over the same short interval. Median rejection prevents one
        # noisy telemetry pair from retuning the estimator.
        if (
            compensation_active and previous_current is not None and previous_raw is not None
            and elapsed is not None and 0.05 <= elapsed <= 2.5
            and abs(delta_i) >= current_step_limit
        ):
            delta_v = raw_voltage - float(previous_raw)
            if delta_i * delta_v < 0.0 and 0.03 <= abs(delta_v) <= 2.5:
                observed_r = -delta_v / delta_i
                lower_r = max(0.010, configured_r * 0.50)
                upper_r = min(0.200, configured_r * 1.80)
                if lower_r <= observed_r <= upper_r:
                    self.battery_voltage_resistance_samples.append(observed_r)
                    ordered_r = sorted(self.battery_voltage_resistance_samples)
                    median_r = ordered_r[len(ordered_r) // 2]
                    effective_r += 0.20 * (median_r - effective_r)
        if compensation_active and not self.battery_voltage_resistance_samples:
            alpha_r = dt / (120.0 + dt)
            effective_r += alpha_r * (configured_r - effective_r)
        if configured_r > 0.0:
            effective_r = max(max(0.010, configured_r * 0.50), min(min(0.200, configured_r * 1.80), effective_r))
        else:
            effective_r = 0.0
        self.battery_voltage_effective_resistance_ohm = effective_r

        # Slow load state models polarization: it rises under sustained propulsion
        # load and decays after unloading. This is the component the RC13/RC2
        # estimator missed when Raw remained ~0.17 V below its later relaxed value
        # even at ~0.9 A.
        load_current = max(0.0, float(current_a) - idle_current) if current_valid else 0.0
        slow_drive = min(load_current, cruise_a * 1.50)
        tau_slow = 18.0 if slow_drive > self.battery_voltage_slow_load_a else 25.0
        alpha_slow = dt / (tau_slow + dt)
        self.battery_voltage_slow_load_a += alpha_slow * (slow_drive - self.battery_voltage_slow_load_a)
        slow_load = max(0.0, self.battery_voltage_slow_load_a)

        # Begin a recovery probe when propulsion load drops sharply into the
        # low-load region. Subsequent Raw-voltage recovery divided by the decay of
        # slow-load state gives a direct estimate of the polarization resistance.
        if (
            compensation_active and previous_current is not None and current_valid
            and float(previous_current) - float(current_a) >= max(2.0, cruise_a * 0.30)
            and float(current_a) <= low_load_limit
        ):
            self.battery_voltage_recovery_probe = {
                "started": now, "raw_start": raw_voltage, "slow_start": slow_load
            }
        probe = self.battery_voltage_recovery_probe
        if probe is not None:
            if not current_valid or float(current_a) > low_load_limit or now - probe["started"] > 45.0:
                self.battery_voltage_recovery_probe = None
            elif now - probe["started"] >= 4.0:
                recovered_v = raw_voltage - probe["raw_start"]
                released_slow_a = probe["slow_start"] - slow_load
                if recovered_v >= 0.0 and released_slow_a >= 0.50:
                    observed_polar_r = recovered_v / released_slow_a
                    upper_polar_r = min(0.100, max(0.020, effective_r))
                    if 0.005 <= observed_polar_r <= upper_polar_r:
                        self.battery_voltage_polar_samples.append(observed_polar_r)
                        ordered_p = sorted(self.battery_voltage_polar_samples)
                        median_p = ordered_p[len(ordered_p) // 2]
                        polar_r += 0.15 * (median_p - polar_r)

        if compensation_active and not self.battery_voltage_polar_samples:
            target_polar_r = effective_r * polar_ratio_default
            alpha_p = dt / (60.0 + dt)
            polar_r += alpha_p * (target_polar_r - polar_r)
        polar_r = max(0.0, min(0.100, polar_r if compensation_active else 0.0))
        self.battery_voltage_polar_resistance_ohm = polar_r

        requested_fast_sag = load_current * effective_r if compensation_active else 0.0
        requested_polar_sag = slow_load * polar_r if compensation_active else 0.0
        requested_sag_unfaded = requested_fast_sag + requested_polar_sag
        requested_sag = requested_sag_unfaded * low_current_compensation_factor
        maximum_sag = 0.12 * cell_count if cell_count_valid else 0.0
        sag_v = max(0.0, min(maximum_sag, requested_sag)) if compensation_active else 0.0
        compensation_clamped = bool(compensation_active and requested_sag > maximum_sag + 1e-9)
        instantaneous_compensated = raw_voltage + sag_v
        self.battery_voltage_samples.append(instantaneous_compensated)
        ordered = sorted(self.battery_voltage_samples)
        compensated = ordered[len(ordered) // 2]

        if just_armed:
            self.battery_voltage_hold_until = max(self.battery_voltage_hold_until, now + 4.0)
        high_load = bool(current_valid and float(current_a) > max(cruise_a * 1.80, cruise_a + 8.0))
        if current_step:
            self.battery_voltage_hold_until = max(self.battery_voltage_hold_until, now + 3.0)
        if high_load or compensation_clamped:
            self.battery_voltage_hold_until = max(self.battery_voltage_hold_until, now + 3.0)

        evidence_weight = 0.0
        current_region = "unusable"
        if current_valid and not high_load and not current_step and now >= self.battery_voltage_hold_until:
            value = float(current_a)
            if value <= low_load_limit:
                evidence_weight = 1.20; current_region = "low_reference"
            elif abs(value - cruise_a) <= max(1.0, cruise_a * 0.30):
                evidence_weight = 1.00; current_region = "cruise"
            elif value <= cruise_a * 1.60:
                evidence_weight = 0.60; current_region = "moderate"
        if evidence_weight > 0.0:
            self.battery_voltage_cruise_samples.append((now, compensated, evidence_weight, dt))
            self.battery_voltage_envelope.append((now, compensated))
        while self.battery_voltage_cruise_samples and now - self.battery_voltage_cruise_samples[0][0] > 20.0:
            self.battery_voltage_cruise_samples.popleft()
        while self.battery_voltage_envelope and now - self.battery_voltage_envelope[0][0] > 20.0:
            self.battery_voltage_envelope.popleft()

        evidence_values = [sample for _ts, sample, _weight, _sample_dt in self.battery_voltage_cruise_samples]
        candidate = self._battery_upper_percentile(evidence_values, 0.65)
        if candidate is None:
            candidate = compensated
        self.battery_voltage_candidate_v = candidate

        previous_stable = self.battery_voltage_stable_v
        if previous_stable is None:
            stable = raw_voltage if (not armed and current_valid and float(current_a) <= low_load_limit) else candidate
            tracker_state = "acquire"
        elif natural_gap and armed:
            stable = previous_stable
            tracker_state = "reacquire"
        elif (
            low_current_confirmed
            and current_valid
            and raw_voltage < previous_stable - 0.003
        ):
            # Confirmed near-rest evidence can remove the remaining small
            # positive compensation bias. It is deliberately one-way: Raw may
            # pull Smooth down, but a Raw rebound can never pull Smooth up.
            alpha = dt / (low_current_converge_tau_s + dt)
            stable = previous_stable + alpha * (raw_voltage - previous_stable)
            tracker_state = "low_current_raw_down"
        elif not armed:
            # Disarmed operation is also monotonic. If current has entered the
            # <3 A fade region but has not yet remained there for four seconds,
            # hold the established value. This prevents a short throttle cut or
            # landing transient from being mistaken for settled rest.
            if current_valid and float(current_a) < low_current_full_a and not low_current_confirmed:
                stable = previous_stable
                tracker_state = "low_current_confirm"
            else:
                target = raw_voltage if (current_valid and float(current_a) <= low_load_limit) else candidate
                error = target - previous_stable
                if error < -0.015:
                    tau_output = 25.0
                    alpha = dt / (tau_output + dt)
                    stable = previous_stable + alpha * error
                    tracker_state = "idle_track_down"
                else:
                    stable = previous_stable
                    tracker_state = "idle_hold"
        elif now < self.battery_voltage_hold_until or high_load or current_step:
            stable = previous_stable
            tracker_state = "hold"
        else:
            error = candidate - previous_stable
            deadband = 0.015
            if error < -deadband:
                # Real depletion is always allowed to pull Smooth downward.
                tau_output = 25.0
                alpha = dt / (tau_output + dt)
                stable = previous_stable + alpha * error
                tracker_state = "track_down"
            elif abs(error) <= deadband:
                stable = previous_stable
                tracker_state = "track"
            else:
                # RC12 hardens RC6 anti-drift into a session invariant:
                # positive evidence never raises Smooth after acquisition.
                stable = previous_stable
                tracker_state = "monotonic_hold"

        # Defense-in-depth invariant for all present and future branches.
        if previous_stable is not None:
            stable = min(float(stable), float(previous_stable))

        display_stable = max(0.0, min(100.0, stable))
        if compensation_active and compensation_clamped:
            status = "compensated_limited"
        elif compensation_active:
            status = "compensated"
        else:
            status = "filtered_only"
            if configured_r > 0.0 and not compensation_active:
                tracker_state = "fallback"

        self.battery_voltage_stable_v = display_stable
        self.battery_voltage_last_update = now
        self.battery_voltage_last_current_a = float(current_a) if current_valid else None
        self.battery_voltage_last_raw_v = raw_voltage
        battery["voltage_compensated_v"] = round(compensated, 4)
        battery["voltage_smooth_v"] = round(display_stable, 4)
        battery["voltage_filter_status"] = status
        battery["voltage_tracker_state"] = (
            tracker_state + ":" + current_region
            + (":lowfade" if low_current_confirmed and low_current_compensation_factor < 0.999 else "")
        )
        battery["voltage_tracker_candidate_v"] = round(candidate, 4)
        battery["voltage_compensation_active"] = compensation_active
        battery["voltage_compensation_clamped"] = compensation_clamped
        battery["voltage_effective_resistance_mohm"] = round(effective_r * 1000.0, 3) if compensation_active else None
        battery["voltage_polarization_v"] = round(
            requested_polar_sag * low_current_compensation_factor, 4
        ) if compensation_active else 0.0
        battery["voltage_idle_current_a"] = round(idle_current, 3) if current_valid else None
        battery["voltage_slow_load_a"] = round(slow_load, 3) if compensation_active else 0.0

    def _update_battery_percentage_locked(self) -> None:
        """Calculate display-only Battery % from user-defined pack endpoints."""
        battery = self.state["battery"]
        config = self._battery_stabilization_config_locked()
        chemistry = str(config.get("battery_chemistry") or "")
        cells = int(config.get("battery_series_cells") or 0)
        full_v = finite(config.get("battery_full_v_per_cell"))
        empty_v = finite(config.get("battery_empty_v_per_cell"))
        valid_config = bool(
            chemistry in {"lipo", "liion"}
            and 1 <= cells <= 24
            and full_v is not None
            and empty_v is not None
            and 3.50 <= full_v <= 4.40
            and 2.50 <= empty_v <= 4.00
            and full_v - empty_v >= 0.20
        )
        battery["configured_cell_count"] = cells if valid_config else None
        if not valid_config:
            battery.update({
                "estimated_pct": None,
                "percentage_status": "unconfigured",
                "percentage_source": "unavailable",
                "percentage_per_cell_v": None,
            })
            self.battery_percentage_last = None
            self.battery_percentage_source = "unavailable"
            return

        smooth_v = finite(battery.get("voltage_smooth_v"))
        raw_v = finite(battery.get("voltage_v"))
        if smooth_v is not None and smooth_v > 0.0:
            pack_v = smooth_v
            source = "smooth"
        elif raw_v is not None and raw_v > 0.0:
            pack_v = raw_v
            source = "raw"
        else:
            battery.update({
                "estimated_pct": None,
                "percentage_status": "voltage_unavailable",
                "percentage_source": "unavailable",
                "percentage_per_cell_v": None,
            })
            self.battery_percentage_last = None
            self.battery_percentage_source = "unavailable"
            return

        per_cell = pack_v / cells
        percentage = 100.0 * (per_cell - empty_v) / (full_v - empty_v)
        percentage = max(0.0, min(100.0, percentage))

        # RC8: calculate continuously from the current selected voltage. RC7's
        # armed-only min(previous, current) latch could capture a temporary
        # takeoff value (about 55% in the flight test) and then forbid recovery
        # when Smooth Voltage returned to its valid held value.
        self.battery_percentage_last = percentage
        self.battery_percentage_source = source
        battery.update({
            "estimated_pct": round(percentage, 2),
            "percentage_status": "ok",
            "percentage_source": source,
            "percentage_per_cell_v": round(per_cell, 4),
        })

    def _update_wind_gust_locked(self, now: float, new_sample: bool = False) -> None:
        wind = self.state["wind"]
        if new_sample:
            snapshot = self.wind_gust_detector.update(
                wind.get("speed_m_s"), wind.get("direction_deg"), now
            )
        else:
            snapshot = self.wind_gust_detector.refresh(now)
        wind.update(snapshot)

    def _update_wind_indicator_locked(self) -> None:
        # Preserve the first-generation 4.2.1 convention exactly:
        # WIND.direction is treated as the incoming wind direction.
        # Equal wind direction and aircraft heading is direct headwind = 0 deg,
        # and the down-pointing SVG therefore points down. Tailwind = 180 deg.
        wind = self.state["wind"]
        speed = finite(wind.get("speed_m_s"))
        direction = finite(wind.get("direction_deg"))
        heading = finite(self.state["attitude"].get("heading_deg"))
        if speed is None and (direction is None or heading is None):
            wind["relative_indicator"] = None
            return
        relative = None
        if direction is not None and heading is not None:
            relative = (direction - heading) % 360.0
        wind["relative_indicator"] = {
            "speed_m_s": speed,
            "direction_deg": direction,
            "heading_deg": heading,
            "relative_deg": relative,
            "semantics": "incoming_headwind_down",
        }

    def _is_fc_heartbeat(self, msg: Any) -> bool:
        autopilot = int(getattr(msg, "autopilot", mavutil.mavlink.MAV_AUTOPILOT_INVALID))
        vehicle_type = int(getattr(msg, "type", mavutil.mavlink.MAV_TYPE_GENERIC))
        if autopilot == mavutil.mavlink.MAV_AUTOPILOT_INVALID:
            return False
        if vehicle_type in {
            mavutil.mavlink.MAV_TYPE_GCS,
            mavutil.mavlink.MAV_TYPE_ONBOARD_CONTROLLER,
            mavutil.mavlink.MAV_TYPE_GIMBAL,
        }:
            return False
        return True

    def _selected(self, msg: Any) -> bool:
        if self.selected_vehicle is None:
            return False
        return (msg.get_srcSystem(), msg.get_srcComponent()) == self.selected_vehicle

    def _capture_raw_telemetry(self, msg: Any, kind: str, now: float) -> None:
        try:
            payload = msg.to_dict()
        except Exception:
            payload = {}
            for field in getattr(msg, "get_fieldnames", lambda: [])():
                payload[field] = getattr(msg, field, None)
        for field, value in payload.items():
            if field == "mavpackettype":
                continue
            safe = _json_safe(value)
            base = f"raw.{kind}.{field}"
            if isinstance(safe, list):
                self.raw_telemetry_values[base] = copy.deepcopy(safe)
                self.raw_telemetry_times[base] = now
                for index, item in enumerate(safe, start=1):
                    key = f"{base}[{index}]"
                    self.raw_telemetry_values[key] = item
                    self.raw_telemetry_times[key] = now
            else:
                self.raw_telemetry_values[base] = safe
                self.raw_telemetry_times[base] = now

    def telemetry_catalog_snapshot(self) -> Dict[str, Any]:
        with self.lock:
            return {
                "ok": True,
                "schema_version": TELEMETRY_LAYOUT_SCHEMA_VERSION,
                "catalog_total": len(self.telemetry_catalog),
                "fields": copy.deepcopy(self.telemetry_catalog),
            }

    def telemetry_values_snapshot(self, requested_keys: Optional[Set[str]] = None) -> Dict[str, Any]:
        now = time.monotonic()
        with self.lock:
            self._refresh_dynamic_telemetry_locked(now)
            values: Dict[str, Any] = {}
            for item in NORMALIZED_TELEMETRY_FIELDS:
                if requested_keys is not None and item["key"] not in requested_keys:
                    continue
                value = _deep_get(self.state, item["path"])
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    multiplier = float(item.get("multiplier", 1.0))
                    value = float(value) * multiplier
                age_keys = item.get("age_keys")
                if isinstance(age_keys, (list, tuple)) and age_keys:
                    timestamps = [
                        self.field_times.get(str(key)) for key in age_keys
                    ]
                    if any(timestamp is None for timestamp in timestamps):
                        age = None
                    else:
                        age = max(max(0.0, now - float(timestamp)) for timestamp in timestamps)
                else:
                    age_key = str(item.get("age_key") or "")
                    timestamp = self.field_times.get(age_key)
                    age = max(0.0, now - timestamp) if timestamp is not None else None
                if value is not None or item["key"] in {"norm.battery.voltage_smooth_v", "norm.battery.estimated_pct", "norm.wind.gust_m_s"}:
                    entry = {
                        "value": _json_safe(value),
                        "age_s": round(age, 3) if age is not None else None,
                    }
                    if item["key"] == "norm.battery.estimated_pct":
                        battery = self.state["battery"]
                        entry.update({
                            "status": battery.get("percentage_status", "unavailable"),
                            "source": battery.get("percentage_source", "unavailable"),
                            "per_cell_v": battery.get("percentage_per_cell_v"),
                            "configured_cell_count": battery.get("configured_cell_count"),
                        })
                    if item["key"] == "norm.battery.voltage_smooth_v":
                        battery = self.state["battery"]
                        entry.update(
                            {
                                "status": battery.get("voltage_filter_status", "unavailable"),
                                "compensation_active": bool(
                                    battery.get("voltage_compensation_active")
                                ),
                                "compensation_clamped": bool(
                                    battery.get("voltage_compensation_clamped")
                                ),
                                "cell_count": battery.get("cell_count"),
                                "compensated_v": battery.get("voltage_compensated_v"),
                                "tracker_state": battery.get("voltage_tracker_state", "unavailable"),
                                "tracker_candidate_v": battery.get("voltage_tracker_candidate_v"),
                            }
                        )
                    values[item["key"]] = entry
            for key, value in self.raw_telemetry_values.items():
                if requested_keys is not None and key not in requested_keys:
                    continue
                timestamp = self.raw_telemetry_times.get(key)
                age = max(0.0, now - timestamp) if timestamp is not None else None
                values[key] = {"value": copy.deepcopy(value), "age_s": round(age, 3) if age is not None else None}
            return {
                "ok": True,
                "schema_version": TELEMETRY_LAYOUT_SCHEMA_VERSION,
                "values": values,
                "available_fields": len(values),
                "packet_count": self.state["service"]["packet_count"],
            }

    def telemetry_layout_snapshot(self) -> Dict[str, Any]:
        with self.lock:
            return {
                "ok": True,
                "config": copy.deepcopy(self.telemetry_layout),
                "path": str(TELEMETRY_LAYOUT_PATH),
                "shadow_path": str(TELEMETRY_LAYOUT_SHADOW_PATH),
            }

    def update_telemetry_layout(self, payload: Any) -> Dict[str, Any]:
        with self.lock:
            before = self._battery_stabilization_config_locked()
            self.telemetry_layout = save_telemetry_layout(payload)
            after = self._battery_stabilization_config_locked()
            if before != after:
                self._reset_battery_voltage_tracker_locked()
            return copy.deepcopy(self.telemetry_layout)

    def update(self, msg: Any) -> None:
        now = time.monotonic()
        kind = msg.get_type()
        if kind == "BAD_DATA":
            return
        with self.lock:
            self.state["service"]["packet_count"] += 1
            self.state["service"]["last_packet_at"] = time.time()

            if kind == "HEARTBEAT" and self._is_fc_heartbeat(msg):
                key = (msg.get_srcSystem(), msg.get_srcComponent())
                self.vehicle_heartbeats[key] = now
                active = [item for item, ts in self.vehicle_heartbeats.items() if now - ts <= 5.0]
                active.sort()
                self.state["connection"]["multiple_vehicles"] = len(active) > 1
                if self.selected_vehicle not in active:
                    self.selected_vehicle = active[0] if len(active) == 1 else None
                if self.selected_vehicle == key:
                    base_mode = int(getattr(msg, "base_mode", 0) or 0)
                    armed = bool(base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED)
                    previous = self.state["vehicle"].get("armed")
                    if armed and previous is not True:
                        self.armed_since = now
                        self._reset_flight_distance_locked(keep_current_position=True)
                        # Seed the monotonic in-flight consumed-mAh guard from the
                        # FC's current value. Re-arming the same battery therefore
                        # preserves consumption, while a newly powered FC can start
                        # from its own fresh counter.
                        current_consumed = self.state.get("battery", {}).get("consumed_mah")
                        try:
                            self.battery_consumed_mah_floor = int(current_consumed) if current_consumed is not None else None
                        except (TypeError, ValueError):
                            self.battery_consumed_mah_floor = None
                    elif not armed and previous is True and self.armed_since is not None:
                        self.total_armed_s += max(0.0, now - self.armed_since)
                        self.armed_since = None
                    self.state["vehicle"].update(
                        {
                            "type": mavutil.mavlink.enums["MAV_TYPE"].get(int(msg.type), None).name
                            if int(msg.type) in mavutil.mavlink.enums["MAV_TYPE"]
                            else str(int(msg.type)),
                            "autopilot": mavutil.mavlink.enums["MAV_AUTOPILOT"].get(int(msg.autopilot), None).name
                            if int(msg.autopilot) in mavutil.mavlink.enums["MAV_AUTOPILOT"]
                            else str(int(msg.autopilot)),
                            "armed": armed,
                            "mode": mavutil.mode_string_v10(msg),
                            "system_status": mavutil.mavlink.enums["MAV_STATE"].get(int(msg.system_status), None).name
                            if int(msg.system_status) in mavutil.mavlink.enums["MAV_STATE"]
                            else str(int(msg.system_status)),
                        }
                    )
                    self._touch("vehicle", now)
                    self._touch("heartbeat", now)
                    self._capture_raw_telemetry(msg, kind, now)
                return

            if not self._selected(msg):
                return

            # GROUND_STATION_ATTITUDE_FALLBACK_V6
            if self._selected(msg):
                self._capture_raw_telemetry(msg, kind, now)

            if kind == "ATTITUDE":
                self.state["attitude"].update(
                    {
                        "roll_deg": degrees(msg.roll),
                        "pitch_deg": degrees(msg.pitch),
                        "heading_deg": (degrees(msg.yaw) or 0.0) % 360.0,
                    }
                )
                self._touch("attitude", now)

            elif kind == "ATTITUDE_QUATERNION":
                q1 = finite(getattr(msg, "q1", None))
                q2 = finite(getattr(msg, "q2", None))
                q3 = finite(getattr(msg, "q3", None))
                q4 = finite(getattr(msg, "q4", None))
                if None not in (q1, q2, q3, q4):
                    sinr_cosp = 2.0 * (q1 * q2 + q3 * q4)
                    cosr_cosp = 1.0 - 2.0 * (q2 * q2 + q3 * q3)
                    roll = math.atan2(sinr_cosp, cosr_cosp)
                    sinp = 2.0 * (q1 * q3 - q4 * q2)
                    pitch = math.copysign(math.pi / 2.0, sinp) if abs(sinp) >= 1.0 else math.asin(sinp)
                    siny_cosp = 2.0 * (q1 * q4 + q2 * q3)
                    cosy_cosp = 1.0 - 2.0 * (q3 * q3 + q4 * q4)
                    yaw = math.atan2(siny_cosp, cosy_cosp)
                    self.state["attitude"].update(
                        {
                            "roll_deg": degrees(roll),
                            "pitch_deg": degrees(pitch),
                            "heading_deg": (degrees(yaw) or 0.0) % 360.0,
                        }
                    )
                    self._touch("attitude", now)

            elif kind == "AHRS2":
                roll = finite(getattr(msg, "roll", None))
                pitch = finite(getattr(msg, "pitch", None))
                yaw = finite(getattr(msg, "yaw", None))
                if roll is not None and pitch is not None:
                    self.state["attitude"].update(
                        {
                            "roll_deg": degrees(roll),
                            "pitch_deg": degrees(pitch),
                            "heading_deg": (degrees(yaw) or 0.0) % 360.0 if yaw is not None else self.state["attitude"].get("heading_deg"),
                        }
                    )
                    self._touch("attitude", now)

            elif kind == "GLOBAL_POSITION_INT":
                lat = int(msg.lat) / 1e7
                lon = int(msg.lon) / 1e7
                heading = None if int(msg.hdg) == 65535 else int(msg.hdg) / 100.0
                self.state["position"].update(
                    {
                        "lat": lat,
                        "lon": lon,
                        "relative_alt_m": int(msg.relative_alt) / 1000.0,
                        "amsl_alt_m": int(msg.alt) / 1000.0,
                        "ground_course_deg": heading,
                    }
                )
                self.state["speed"]["groundspeed_m_s"] = math.hypot(int(msg.vx), int(msg.vy)) / 100.0
                self.state["speed"]["vertical_speed_m_s"] = -int(msg.vz) / 100.0
                self._touch("position", now)
                self._touch("speed", now)
                self._update_track(lat, lon, now)
                self._update_home_geometry()
                self._update_flight_distance_locked(lat, lon, now)

            elif kind == "VFR_HUD":
                self.state["speed"].update(
                    {
                        "airspeed_m_s": finite(msg.airspeed),
                        "groundspeed_m_s": finite(msg.groundspeed),
                        "vertical_speed_m_s": finite(msg.climb),
                        "throttle_pct": finite(msg.throttle),
                    }
                )
                if self.state["position"].get("amsl_alt_m") is None:
                    self.state["position"]["amsl_alt_m"] = finite(msg.alt)
                if self.state["attitude"].get("heading_deg") is None:
                    self.state["attitude"]["heading_deg"] = finite(msg.heading)
                self._touch("speed", now)

            elif kind == "GPS_RAW_INT":
                eph = int(getattr(msg, "eph", 65535))
                self.state["gps"].update(
                    {
                        "fix_type": int(msg.fix_type),
                        "fix": gps_fix_name(int(msg.fix_type)),
                        "satellites": int(msg.satellites_visible) if int(msg.satellites_visible) != 255 else None,
                        "hdop": None if eph == 65535 else eph / 100.0,
                    }
                )
                self._touch("gps", now)

            elif kind == "SYS_STATUS":
                voltage = int(getattr(msg, "voltage_battery", 65535))
                current = int(getattr(msg, "current_battery", -1))
                remaining = int(getattr(msg, "battery_remaining", -1))
                self.state["battery"].update(
                    {
                        "voltage_v": None if voltage == 65535 else voltage / 1000.0,
                        "current_a": None if current < 0 else current / 100.0,
                        "remaining_pct": None if remaining < 0 else remaining,
                    }
                )
                self._touch("battery", now)
                if voltage != 65535:
                    self._update_battery_stabilization_locked(now)

            elif kind == "BATTERY_STATUS":
                voltages = [int(value) for value in getattr(msg, "voltages", []) if 0 < int(value) < 65535]
                if voltages:
                    self.state["battery"]["voltage_v"] = sum(voltages) / 1000.0
                    self.state["battery"]["cell_count"] = len(voltages)
                current = int(getattr(msg, "current_battery", -1))
                remaining = int(getattr(msg, "battery_remaining", -1))
                consumed = int(getattr(msg, "current_consumed", -1))
                self.state["battery"]["current_a"] = None if current < 0 else current / 100.0
                if remaining >= 0:
                    self.state["battery"]["remaining_pct"] = remaining
                if consumed >= 0:
                    # FLIGHTCORE_4_2_3_RC6_CONSUMED_MAH_RECONNECT_GUARD_V1
                    # BATTERY_STATUS current_consumed is monotonic during a flight.
                    # A transient zero/smaller value immediately after a telemetry
                    # reconnect must not make the Ground Station restart consumed mAh
                    # from zero. A true fresh counter is accepted while disarmed after
                    # a meaningful telemetry gap.
                    previous_consumed = self.state["battery"].get("consumed_mah")
                    armed_now = self.state.get("vehicle", {}).get("armed") is True
                    gap = None if self.battery_consumed_mah_last_update is None else now - self.battery_consumed_mah_last_update
                    if (
                        not armed_now and consumed <= 20 and
                        self.battery_consumed_mah_floor is not None and
                        self.battery_consumed_mah_floor >= 100 and
                        gap is not None and gap >= 15.0
                    ):
                        self.battery_consumed_mah_floor = consumed
                    elif self.battery_consumed_mah_floor is None:
                        try:
                            self.battery_consumed_mah_floor = max(consumed, int(previous_consumed or 0))
                        except (TypeError, ValueError):
                            self.battery_consumed_mah_floor = consumed
                    elif consumed >= self.battery_consumed_mah_floor - 10:
                        self.battery_consumed_mah_floor = max(self.battery_consumed_mah_floor, consumed)
                    display_consumed = max(consumed, int(self.battery_consumed_mah_floor or 0))
                    self.state["battery"]["consumed_mah"] = display_consumed
                    self.battery_consumed_mah_last_update = now
                self._touch("battery", now)
                if voltages:
                    self._update_battery_stabilization_locked(now)

            elif kind == "HOME_POSITION":
                self.state["navigation"]["home_lat"] = int(msg.latitude) / 1e7
                self.state["navigation"]["home_lon"] = int(msg.longitude) / 1e7
                self._touch("home", now)
                self._update_home_geometry()

            elif kind == "RADIO_STATUS":
                self.state["link"].update(
                    {
                        "rssi": int(msg.rssi),
                        "remote_rssi": int(msg.remrssi),
                        "noise": int(msg.noise),
                        "remote_noise": int(msg.remnoise),
                        "rx_errors": int(msg.rxerrors),
                        "fixed_packets": int(msg.fixed),
                    }
                )
                self._touch("link", now)

            elif kind == "MISSION_CURRENT":
                self.state["navigation"]["waypoint_current"] = int(msg.seq)
                self._touch("mission", now)

            elif kind == "MISSION_ITEM_REACHED":
                self.state["navigation"]["waypoint_reached"] = int(msg.seq)
                self._touch("mission", now)

            elif kind == "NAV_CONTROLLER_OUTPUT":
                self.state["navigation"]["target_bearing_deg"] = finite(msg.target_bearing)
                self.state["navigation"]["distance_to_waypoint_m"] = finite(msg.wp_dist)
                self._touch("navigation", now)

            elif kind == "WIND":
                self.state["wind"].update(
                    {
                        "direction_deg": finite(msg.direction),
                        "speed_m_s": finite(msg.speed),
                        "vertical_m_s": finite(msg.speed_z),
                    }
                )
                self._touch("wind", now)
                self._update_wind_gust_locked(now, new_sample=True)

            elif kind == "RC_CHANNELS":
                count = max(0, min(18, int(getattr(msg, "chancount", 18) or 18)))
                values = []
                for index in range(1, count + 1):
                    value = int(getattr(msg, f"chan{index}_raw", 65535))
                    values.append(None if value == 65535 else value)
                self.state["rc"]["channels"] = values
                self._touch("rc", now)

            elif kind == "SERVO_OUTPUT_RAW":
                values = []
                for index in range(1, 17):
                    if not hasattr(msg, f"servo{index}_raw"):
                        break
                    value = int(getattr(msg, f"servo{index}_raw", 0))
                    values.append(value if value > 0 else None)
                self.state["servo"]["outputs"] = values
                self._touch("servo", now)

            elif kind == "STATUSTEXT":
                text = str(getattr(msg, "text", "") or "").rstrip("\x00").strip()
                if text:
                    item = {
                        "ts": time.time(),
                        "severity": severity_name(int(getattr(msg, "severity", 6))),
                        "severity_id": int(getattr(msg, "severity", 6)),
                        "text": text,
                        "system_id": msg.get_srcSystem(),
                        "component_id": msg.get_srcComponent(),
                    }
                    self.messages.append(item)
                    self.state["messages"] = list(self.messages)[-50:]
                    print(f"[GROUNDSTATION_MESSAGE] {item['severity']}: {text}", flush=True)

    def _update_track(self, lat: float, lon: float, now: float) -> None:
        minimum_interval = float(self.config.get("track", {}).get("minimum_interval_s", 0.8))
        if now - self.last_track_time < minimum_interval:
            return
        if self.last_track_position is not None:
            distance = haversine_m(self.last_track_position[0], self.last_track_position[1], lat, lon)
            if distance < 1.0:
                return
        self.track_sequence += 1
        self.track.append({
            "seq": self.track_sequence,
            "lat": lat,
            "lon": lon,
            "ts": time.time(),
        })
        self.last_track_time = now
        self.last_track_position = (lat, lon)

    def track_snapshot_since(self, since_sequence: int = 0) -> Dict[str, Any]:
        with self.lock:
            points = list(self.track)
            latest = int(self.track_sequence)
            oldest = int(points[0].get("seq", latest + 1)) if points else latest + 1
            reset = (
                since_sequence <= 0
                or since_sequence > latest
                or since_sequence < oldest - 1
            )
            if reset:
                selected = points
            else:
                selected = [
                    point for point in points
                    if int(point.get("seq", 0)) > since_sequence
                ]
            return {
                "ok": True,
                "reset": reset,
                "from_seq": oldest if points else latest,
                "to_seq": latest,
                "maximum_points": self.track.maxlen,
                "points": copy.deepcopy(selected),
            }

    def _update_home_geometry(self) -> None:
        position = self.state["position"]
        navigation = self.state["navigation"]
        values = (position.get("lat"), position.get("lon"), navigation.get("home_lat"), navigation.get("home_lon"))
        if any(value is None for value in values):
            navigation["home_distance_m"] = None
            navigation["home_bearing_deg"] = None
            return
        lat, lon, home_lat, home_lon = values
        navigation["home_distance_m"] = haversine_m(lat, lon, home_lat, home_lon)
        navigation["home_bearing_deg"] = bearing_deg(lat, lon, home_lat, home_lon)



    def _reset_flight_distance_locked(self, keep_current_position: bool = False) -> None:
        self.flight_distance_m = 0.0
        self.state["navigation"]["flight_distance_m"] = 0.0
        if keep_current_position:
            lat = finite(self.state["position"].get("lat"))
            lon = finite(self.state["position"].get("lon"))
            if lat is not None and lon is not None:
                self.flight_distance_last_position = (lat, lon)
                self.flight_distance_last_time = time.monotonic()
                return
        self.flight_distance_last_position = None
        self.flight_distance_last_time = None


    def _valid_gps_for_distance_locked(self) -> bool:
        fix_type = self.state.get("gps", {}).get("fix_type")
        try:
            return int(fix_type or 0) >= 2
        except Exception:
            return False


    def _update_flight_distance_locked(self, lat: float, lon: float, now: float) -> None:
        armed = self.state.get("vehicle", {}).get("armed") is True
        if not armed:
            self.flight_distance_last_position = (lat, lon)
            self.flight_distance_last_time = now
            self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)
            return
        if not self._valid_gps_for_distance_locked():
            self.flight_distance_last_position = (lat, lon)
            self.flight_distance_last_time = now
            self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)
            return
        if self.flight_distance_last_position is None:
            self.flight_distance_last_position = (lat, lon)
            self.flight_distance_last_time = now
            self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)
            return
        last_lat, last_lon = self.flight_distance_last_position
        step_distance = haversine_m(last_lat, last_lon, lat, lon)
        delta_t = max(0.05, now - (self.flight_distance_last_time or now))
        groundspeed = finite(self.state.get("speed", {}).get("groundspeed_m_s")) or 0.0
        max_reasonable_step = max(35.0, groundspeed * delta_t * 4.0 + 25.0)
        if 0.5 <= step_distance <= max_reasonable_step:
            self.flight_distance_m += step_distance
        self.flight_distance_last_position = (lat, lon)
        self.flight_distance_last_time = now
        self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)


    def _refresh_dynamic_telemetry_locked(self, now: float) -> float:
        armed_s = self.total_armed_s
        if self.armed_since is not None:
            armed_s += max(0.0, now - self.armed_since)
        self.state["timers"]["armed_s"] = armed_s
        self.state["timers"]["flight_time_text"] = format_hms(armed_s)
        self.state["timers"]["local_time_text"] = time.strftime("%H:%M:%S")
        self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)
        self._update_battery_percentage_locked()
        self._update_wind_gust_locked(now, new_sample=False)
        self._update_wind_indicator_locked()
        return armed_s

    def snapshot(self, include_track: bool = False) -> Dict[str, Any]:
        now = time.monotonic()
        with self.lock:
            self._refresh_dynamic_telemetry_locked(now)
            result = copy.deepcopy(self.state)
            result["track"] = copy.deepcopy(list(self.track)) if include_track else []
            result["track_meta"] = {
                "latest_seq": int(self.track_sequence),
                "points": len(self.track),
                "maximum_points": self.track.maxlen,
            }
            active = {key: ts for key, ts in self.vehicle_heartbeats.items() if now - ts <= 5.0}
            multiple = len(active) > 1
            heartbeat_age = None
            if self.selected_vehicle in active:
                heartbeat_age = max(0.0, now - active[self.selected_vehicle])
            degraded = float(self.config.get("warnings", {}).get("heartbeat_degraded_s", 3.0))
            lost = float(self.config.get("warnings", {}).get("heartbeat_lost_s", 5.0))
            if multiple:
                connection_state = "DEGRADED"
            elif heartbeat_age is None:
                connection_state = "NO_VEHICLE"
            elif heartbeat_age < degraded:
                connection_state = "CONNECTED"
            elif heartbeat_age <= lost:
                connection_state = "DEGRADED"
            else:
                connection_state = "LINK_LOST"
            result["connection"].update(
                {
                    "state": connection_state,
                    "heartbeat_age_s": heartbeat_age,
                    "system_id": self.selected_vehicle[0] if self.selected_vehicle else None,
                    "component_id": self.selected_vehicle[1] if self.selected_vehicle else None,
                    "multiple_vehicles": multiple,
                }
            )
            result["timers"]["connected_s"] = max(0.0, now - self.started_monotonic)
            armed_s = result["timers"].get("armed_s", 0.0)
            result["field_age_s"] = {
                key: round(max(0.0, now - timestamp), 3)
                for key, timestamp in self.field_times.items()
            }
            result["service"]["uptime_s"] = max(0.0, now - self.started_monotonic)
            result["service"]["config_path"] = str(CONFIG_PATH)
            return result


class GroundStationRuntime:
    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.vehicle = VehicleState(config)
        self.stop_event = threading.Event()
        self.connection = None

    def stop(self, *_args: Any) -> None:
        self.stop_event.set()
        if self.connection is not None:
            try:
                self.connection.close()
            except Exception:
                pass

    def mavlink_loop(self) -> None:
        mav_cfg = self.config["mavlink"]
        endpoint = f"udpin:{mav_cfg.get('host', '0.0.0.0')}:{int(mav_cfg.get('port', 14602))}"
        while not self.stop_event.is_set():
            try:
                print(f"[GROUNDSTATION_MAVLINK] opening {endpoint}", flush=True)
                self.connection = mavutil.mavlink_connection(
                    endpoint,
                    source_system=int(mav_cfg.get("system_id", 254)),
                    source_component=int(mav_cfg.get("component_id", 192)),
                    dialect="ardupilotmega",
                )
                while not self.stop_event.is_set():
                    message = self.connection.recv_match(blocking=True, timeout=0.5)
                    if message is not None:
                        self.vehicle.update(message)
            except Exception as exc:
                print(f"[GROUNDSTATION_MAVLINK_ERROR] {exc!r}", flush=True)
                time.sleep(1.0)
            finally:
                if self.connection is not None:
                    try:
                        self.connection.close()
                    except Exception:
                        pass
                    self.connection = None


RUNTIME: Optional[GroundStationRuntime] = None


class ApiHandler(BaseHTTPRequestHandler):
    server_version = "SIYIGroundStation/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        print("[GROUNDSTATION_HTTP] " + (fmt % args), flush=True)

    def _json(self, payload: Any, status: int = 200) -> None:
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        assert RUNTIME is not None
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query, keep_blank_values=False)
        if path == "/health":
            snapshot = RUNTIME.vehicle.snapshot()
            self._json(
                {
                    "ok": True,
                    "service": "siyi-groundstation",
                    "monitor_only": True,
                    "connection": snapshot["connection"],
                    "packet_count": snapshot["service"]["packet_count"],
                    "uptime_s": snapshot["service"]["uptime_s"],
                    "telemetry_canvas": {
                        "schema_version": TELEMETRY_LAYOUT_SCHEMA_VERSION,
                        "catalog_total": len(RUNTIME.vehicle.telemetry_catalog),
                        "config_path": str(TELEMETRY_LAYOUT_PATH),
                        "shadow_path": str(TELEMETRY_LAYOUT_SHADOW_PATH),
                    },
                }
            )
            return
        if path == "/state":
            include_track = str((query.get("include_track") or [""])[0]).lower() in {"1", "true", "yes"}
            self._json(RUNTIME.vehicle.snapshot(include_track=include_track))
            return
        if path == "/track":
            try:
                since = int((query.get("since") or ["0"])[0])
            except (TypeError, ValueError):
                since = 0
            self._json(RUNTIME.vehicle.track_snapshot_since(since))
            return
        if path == "/messages":
            snapshot = RUNTIME.vehicle.snapshot()
            self._json({"messages": snapshot.get("messages", [])})
            return
        if path == "/telemetry/catalog":
            self._json(RUNTIME.vehicle.telemetry_catalog_snapshot())
            return
        if path == "/telemetry/values":
            requested_keys: Optional[Set[str]] = None
            raw_keys = query.get("key", [])
            if not raw_keys and query.get("keys"):
                raw_keys = [
                    item
                    for value in query.get("keys", [])
                    for item in value.split(",")
                ]
            cleaned = {str(item).strip() for item in raw_keys if str(item).strip()}
            if cleaned:
                requested_keys = cleaned
            self._json(RUNTIME.vehicle.telemetry_values_snapshot(requested_keys))
            return
        if path == "/telemetry/layout":
            self._json(RUNTIME.vehicle.telemetry_layout_snapshot())
            return
        if path == "/stream":
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
            self.send_header("Connection", "keep-alive")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            last_payload = None
            last_keepalive = 0.0
            last_track_sequence = 0
            first_payload = True
            try:
                while not RUNTIME.stop_event.is_set():
                    snapshot = RUNTIME.vehicle.snapshot(include_track=False)
                    track_update = RUNTIME.vehicle.track_snapshot_since(last_track_sequence)
                    if first_payload or track_update["points"] or track_update["reset"]:
                        snapshot["track_update"] = track_update
                        last_track_sequence = int(track_update["to_seq"])
                    payload = json.dumps(snapshot, ensure_ascii=False, separators=(",", ":"))
                    now = time.monotonic()
                    first_payload = False
                    if payload != last_payload:
                        self.wfile.write(("data: " + payload + "\n\n").encode("utf-8"))
                        self.wfile.flush()
                        last_payload = payload
                        last_keepalive = now
                    elif now - last_keepalive >= 10.0:
                        self.wfile.write(b": keepalive\n\n")
                        self.wfile.flush()
                        last_keepalive = now
                    time.sleep(0.2)
            except (BrokenPipeError, ConnectionResetError, TimeoutError):
                pass
            return
        self._json({"error": "not found"}, 404)


    def do_POST(self) -> None:
        assert RUNTIME is not None
        path = self.path.split("?", 1)[0]
        if path != "/telemetry/layout":
            self._json({"error": "not found"}, 404)
            return
        try:
            length = int(self.headers.get("Content-Length", "0") or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > 1024 * 1024:
            self._json({"ok": False, "error": "invalid content length"}, 400)
            return
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            config = RUNTIME.vehicle.update_telemetry_layout(payload)
            self._json({
                "ok": True,
                "config": config,
                "path": str(TELEMETRY_LAYOUT_PATH),
                "shadow_path": str(TELEMETRY_LAYOUT_SHADOW_PATH),
            })
        except Exception as exc:
            self._json({"ok": False, "error": str(exc)}, 400)



# FLIGHTCORE_4_3_0_RC6_AIRSPEED_HEALTH_SMOOTH_GUARD_FLIGHT_LOG_V1
# Passive/read-only diagnostics only. This block never sends MAVLink commands,
# never changes flight mode, and never requests a full parameter list while armed.
import queue as _fc6_queue
import urllib.request as _fc6_urllib_request
import urllib.error as _fc6_urllib_error

FC6_PARAMD_STATE_URL = "http://127.0.0.1:8765/state"
FC6_JOYSTICK_STATUS_URL = "http://127.0.0.1:18766/status"
FC6_FLIGHT_LOG_ROOT = Path(os.environ.get("FLIGHTCORE_FLIGHT_LOG_ROOT", "/var/lib/flightcore/flight-logs"))
FC6_ARSP_RECOVERY_S = 5.0
FC6_SAMPLE_PERIOD_S = 0.5
FC6_PARAM_POLL_S = 5.0
FC6_JOYSTICK_POLL_S = 1.0


def _fc81_release_log_identity() -> Dict[str, Any]:
    """Return the exact installed release identity without network access."""
    release_version = Path("/etc/siyi/release_version")
    release_build = Path("/etc/siyi/release_build")
    release_status = Path("/etc/siyi/release_status")
    metadata_path = Path("/usr/local/share/siyi/releases/4.3.0/release-metadata.json")
    manifest_path = Path("/usr/local/share/siyi/releases/4.3.0/payload-manifest.json")

    def text(path: Path) -> Optional[str]:
        try:
            value = path.read_text(encoding="utf-8").strip()
            return value or None
        except Exception:
            return None

    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        if not isinstance(metadata, dict):
            metadata = {}
    except Exception:
        metadata = {}

    release_identity = text(release_version) or metadata.get("release_identity")
    candidate = metadata.get("release_candidate", metadata.get("candidate"))
    if candidate is None and isinstance(release_identity, str) and "-rc." in release_identity:
        try:
            candidate = int(release_identity.rsplit("-rc.", 1)[1])
        except Exception:
            candidate = None
    payload_manifest_sha256 = None
    try:
        payload_manifest_sha256 = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    except Exception:
        pass
    return {
        "product_version": metadata.get("version") or metadata.get("target_version") or "4.3.0",
        "release_identity": release_identity,
        "release_candidate": candidate,
        "build_id": text(release_build) or metadata.get("build_id"),
        "source_commit": metadata.get("source_commit"),
        "release_status": text(release_status),
        "payload_manifest_sha256": payload_manifest_sha256,
    }


FC81_RELEASE_LOG_IDENTITY = _fc81_release_log_identity()


def _fc6_json_get(url: str, timeout: float = 1.0) -> Dict[str, Any]:
    request = _fc6_urllib_request.Request(url, headers={"User-Agent": "FlightCore-RC6-LocalDiagnostics/1"})
    with _fc6_urllib_request.urlopen(request, timeout=timeout) as response:
        raw = response.read(8 * 1024 * 1024)
    payload = json.loads(raw.decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("local endpoint returned non-object JSON")
    return payload


def _fc6_param_value(entry: Any) -> Any:
    if isinstance(entry, dict) and "value" in entry:
        return entry.get("value")
    return entry


def _fc6_sanitize_log_id(value: str) -> str:
    value = "".join(ch for ch in str(value) if ch.isalnum() or ch in "-_")
    return value[:80]


class _FlightCoreRC6FlightLogger:
    """Buffered post-flight diagnostics. All filesystem/param-cache I/O is off the MAVLink thread."""
    def __init__(self, root: Path) -> None:
        self.root = Path(root)
        self.queue = _fc6_queue.Queue(maxsize=8192)
        self.stop_event = threading.Event()
        self.active_requested = False
        self.drop_count = 0
        self.thread = threading.Thread(target=self._worker, name="fc6-flight-log", daemon=True)
        self.thread.start()

    def _put(self, item: Any) -> None:
        try:
            self.queue.put_nowait(item)
        except _fc6_queue.Full:
            self.drop_count += 1

    def start_flight(self, state: Dict[str, Any]) -> None:
        if self.active_requested:
            return
        self.active_requested = True
        wall = time.time()
        flight_id = time.strftime("%Y%m%d_%H%M%S", time.localtime(wall))
        state_copy = copy.deepcopy(state)
        try:
            state_copy["flightcore_release"] = _fc81_release_log_identity()
        except Exception:
            state_copy["flightcore_release"] = {}
        self._put(("start", flight_id, wall, state_copy))

    def event(self, event: str, detail: Optional[Dict[str, Any]] = None, severity: str = "info") -> None:
        if not self.active_requested:
            return
        self._put(("event", time.time(), str(event), str(severity), copy.deepcopy(detail or {})))

    def sample(self, sample: Dict[str, Any]) -> None:
        if not self.active_requested:
            return
        self._put(("sample", time.time(), copy.deepcopy(sample)))

    def stop_flight(self, state: Dict[str, Any]) -> None:
        if not self.active_requested:
            return
        self.active_requested = False
        self._put(("stop", time.time(), copy.deepcopy(state)))

    def shutdown(self) -> None:
        if self.active_requested:
            self.active_requested = False
            self._put(("abort", time.time()))
        self.stop_event.set()
        self._put(("shutdown",))
        self.thread.join(timeout=3.0)

    @staticmethod
    def _cached_params() -> Dict[str, Any]:
        try:
            payload = _fc6_json_get(FC6_PARAMD_STATE_URL, timeout=1.5)
            params = payload.get("params")
            if isinstance(params, dict):
                return {
                    "ok": True,
                    "source": "flightcore_paramd_cache_only",
                    "captured_at": time.time(),
                    "params": params,
                }
            return {"ok": False, "source": "flightcore_paramd_cache_only", "error": "params cache unavailable", "params": {}}
        except Exception as exc:
            return {"ok": False, "source": "flightcore_paramd_cache_only", "error": str(exc), "params": {}}

    @staticmethod
    def _param_diff(arm: Dict[str, Any], disarm: Dict[str, Any]) -> Dict[str, Any]:
        a = arm.get("params") if isinstance(arm, dict) else {}
        b = disarm.get("params") if isinstance(disarm, dict) else {}
        a = a if isinstance(a, dict) else {}
        b = b if isinstance(b, dict) else {}
        changed = {}
        for name in sorted(set(a) | set(b)):
            av = _fc6_param_value(a.get(name)) if name in a else None
            bv = _fc6_param_value(b.get(name)) if name in b else None
            if av != bv:
                changed[name] = {"arm": av, "disarm": bv}
        return {"changed_count": len(changed), "changed": changed}

    def _worker(self) -> None:
        active_dir = None
        meta = None
        sample_handle = None
        event_handle = None
        arm_params = None
        warning_count = 0
        arsp_failure = False
        last_flush = time.monotonic()

        def close_handles() -> None:
            nonlocal sample_handle, event_handle
            for handle in (sample_handle, event_handle):
                if handle is not None:
                    try:
                        handle.flush(); os.fsync(handle.fileno())
                    except Exception:
                        pass
                    try: handle.close()
                    except Exception: pass
            sample_handle = None; event_handle = None

        def write_json(path: Path, payload: Any) -> None:
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            os.replace(tmp, path)

        while True:
            try:
                item = self.queue.get(timeout=0.5)
            except _fc6_queue.Empty:
                item = None
            try:
                if item is not None:
                    kind = item[0]
                    if kind == "start":
                        close_handles()
                        flight_id, wall, state = _fc6_sanitize_log_id(item[1]), float(item[2]), item[3]
                        active_dir = self.root / flight_id
                        suffix = 1
                        while active_dir.exists():
                            active_dir = self.root / f"{flight_id}_{suffix:02d}"; suffix += 1
                        active_dir.mkdir(parents=True, exist_ok=False)
                        sample_handle = (active_dir / "samples.jsonl").open("a", encoding="utf-8", buffering=65536)
                        event_handle = (active_dir / "events.jsonl").open("a", encoding="utf-8", buffering=65536)
                        arm_params = self._cached_params()
                        write_json(active_dir / "params_at_arm.json", arm_params)
                        warning_count = 0; arsp_failure = False
                        meta = {
                            "schema_version": 1,
                            "flight_id": active_dir.name,
                            "started_at": wall,
                            "started_local": time.strftime("%Y-%m-%d %H:%M:%S %z", time.localtime(wall)),
                            "ended_at": None,
                            "duration_s": None,
                            "status": "recording",
                            "sample_period_s": FC6_SAMPLE_PERIOD_S,
                            "parameter_snapshot_source": "FlightCore paramd cache only - no full FC parameter request",
                            "warnings": 0,
                            "airspeed_failure_seen": False,
                            "dropped_queue_records": 0,
                            "flightcore_release": copy.deepcopy(state.get("flightcore_release") or {}),
                            "start_state": state,
                        }
                        write_json(active_dir / "meta.json", meta)
                        event_handle.write(json.dumps({"ts": wall, "event": "ARMED", "severity": "info", "detail": {}}, separators=(",", ":")) + "\n")
                    elif kind == "event" and active_dir is not None and event_handle is not None:
                        ts, event, severity, detail = float(item[1]), item[2], item[3], item[4]
                        if severity.lower() in {"warning", "warn", "error", "critical", "alert", "emergency"}: warning_count += 1
                        if event in {"AIRSPEED_SENSOR_FAIL", "AIRSPEED_SENSOR_LOST"}: arsp_failure = True
                        event_handle.write(json.dumps({"ts": ts, "event": event, "severity": severity, "detail": detail}, ensure_ascii=False, separators=(",", ":")) + "\n")
                    elif kind == "sample" and active_dir is not None and sample_handle is not None:
                        sample_handle.write(json.dumps({"ts": float(item[1]), **item[2]}, ensure_ascii=False, separators=(",", ":")) + "\n")
                    elif kind in {"stop", "abort"} and active_dir is not None:
                        end_wall = float(item[1])
                        if event_handle is not None:
                            event_handle.write(json.dumps({"ts": end_wall, "event": "DISARMED" if kind == "stop" else "LOGGER_STOPPED", "severity": "info", "detail": {}}, separators=(",", ":")) + "\n")
                        disarm_params = self._cached_params()
                        write_json(active_dir / "params_at_disarm.json", disarm_params)
                        diff = self._param_diff(arm_params or {}, disarm_params)
                        write_json(active_dir / "param_diff.json", diff)
                        if meta is not None:
                            meta["ended_at"] = end_wall
                            meta["ended_local"] = time.strftime("%Y-%m-%d %H:%M:%S %z", time.localtime(end_wall))
                            meta["duration_s"] = round(max(0.0, end_wall - float(meta.get("started_at") or end_wall)), 3)
                            meta["status"] = "complete" if kind == "stop" else "interrupted"
                            meta["warnings"] = warning_count
                            meta["airspeed_failure_seen"] = bool(arsp_failure)
                            meta["dropped_queue_records"] = self.drop_count
                            if kind == "stop" and len(item) > 2: meta["end_state"] = item[2]
                            write_json(active_dir / "meta.json", meta)
                            if kind == "stop":
                                trigger = self.root / ".cloud-sync-trigger"
                                trigger_tmp = self.root / (".cloud-sync-trigger.tmp.%s" % os.getpid())
                                trigger_tmp.write_text(str(end_wall) + "\n", encoding="utf-8")
                                os.replace(trigger_tmp, trigger)
                        close_handles(); active_dir = None; meta = None; arm_params = None
                    elif kind == "shutdown":
                        close_handles(); return
                now_m = time.monotonic()
                if now_m - last_flush >= 5.0:
                    for handle in (sample_handle, event_handle):
                        if handle is not None:
                            try: handle.flush()
                            except Exception: pass
                    last_flush = now_m
                if self.stop_event.is_set() and self.queue.empty():
                    close_handles(); return
            except Exception as exc:
                print(f"[FLIGHTCORE_RC6_FLIGHT_LOG_ERROR] {exc!r}", flush=True)


_fc6_previous_vehicle_init = VehicleState.__init__
def _fc6_vehicle_init(self, config: Dict[str, Any]) -> None:
    _fc6_previous_vehicle_init(self, config)
    self.rc6_runtime = None
    self.rc6_airspeed_params: Dict[str, Any] = {}
    self.rc6_airspeed_params_seen = False
    self.rc6_airspeed_sys_seen = False
    self.rc6_airspeed_sys = {"present": None, "enabled": None, "healthy": None}
    self.rc6_airspeed_healthy_since: Optional[float] = None
    self.rc6_airspeed_last_status = "CHECKING"
    self.state["airspeed_sensor"] = {
        "status": "CHECKING", "expected": None, "type": None, "use": None,
        "devid": None, "primary": None, "present": None, "enabled": None,
        "healthy": None, "reason": "waiting_for_cached_parameters",
        "smooth_ready": False, "recovery_remaining_s": None,
        "last_change_at": time.time(),
    }
VehicleState.__init__ = _fc6_vehicle_init


def _fc6_refresh_airspeed_status_locked(self, now: float) -> Tuple[str, str]:
    arsp = self.state["airspeed_sensor"]
    previous = str(arsp.get("status") or "CHECKING")
    p = self.rc6_airspeed_params
    atype = _fc6_param_value(p.get("ARSPD_TYPE")) if self.rc6_airspeed_params_seen else None
    use = _fc6_param_value(p.get("ARSPD_USE")) if self.rc6_airspeed_params_seen else None
    devid = _fc6_param_value(p.get("ARSPD_DEVID")) if self.rc6_airspeed_params_seen else None
    primary = _fc6_param_value(p.get("ARSPD_PRIMARY")) if self.rc6_airspeed_params_seen else None
    try: atype_i = int(float(atype)) if atype is not None else None
    except Exception: atype_i = None
    try: use_i = int(float(use)) if use is not None else None
    except Exception: use_i = None
    try: devid_i = int(float(devid)) if devid is not None else None
    except Exception: devid_i = None
    try: primary_i = int(float(primary)) if primary is not None else None
    except Exception: primary_i = None

    expected = None if not self.rc6_airspeed_params_seen else bool((atype_i or 0) != 0 and (use_i or 0) != 0)
    present = self.rc6_airspeed_sys.get("present") if self.rc6_airspeed_sys_seen else None
    enabled = self.rc6_airspeed_sys.get("enabled") if self.rc6_airspeed_sys_seen else None
    healthy = self.rc6_airspeed_sys.get("healthy") if self.rc6_airspeed_sys_seen else None

    if expected is None:
        status, reason = "CHECKING", "waiting_for_cached_parameters"
    elif not expected:
        status, reason = "OFF", "airspeed_not_configured_or_not_used"
    elif devid_i is None:
        status, reason = "CHECKING", "waiting_for_device_id"
    elif devid_i == 0:
        status, reason = "FAIL", "device_not_detected"
    elif not self.rc6_airspeed_sys_seen:
        status, reason = "CHECKING", "waiting_for_live_sensor_health"
    elif present is not True:
        status, reason = "FAIL", "differential_pressure_not_present"
    elif enabled is not True:
        status, reason = "FAIL", "differential_pressure_not_enabled"
    elif healthy is not True:
        status, reason = "FAIL", "differential_pressure_unhealthy"
    else:
        status, reason = "OK", "detected_and_healthy"

    if status == "OK":
        if previous != "OK" or self.rc6_airspeed_healthy_since is None:
            self.rc6_airspeed_healthy_since = now
        healthy_age = max(0.0, now - float(self.rc6_airspeed_healthy_since))
        smooth_ready = healthy_age >= FC6_ARSP_RECOVERY_S
        remaining = max(0.0, FC6_ARSP_RECOVERY_S - healthy_age)
    else:
        self.rc6_airspeed_healthy_since = None
        smooth_ready = False; remaining = None

    arsp.update({
        "status": status, "expected": expected, "type": atype_i, "use": use_i,
        "devid": devid_i, "primary": primary_i, "present": present,
        "enabled": enabled, "healthy": healthy, "reason": reason,
        "smooth_ready": bool(smooth_ready),
        "recovery_remaining_s": round(remaining, 2) if remaining is not None else None,
    })
    if status != previous:
        arsp["last_change_at"] = time.time()
        self.rc6_airspeed_last_status = status
    return previous, status


def _fc6_apply_cached_airspeed_params(self, params: Dict[str, Any], now: Optional[float] = None) -> Tuple[str, str]:
    with self.lock:
        self.rc6_airspeed_params_seen = True
        self.rc6_airspeed_params = {k: params.get(k) for k in ("ARSPD_TYPE", "ARSPD_USE", "ARSPD_DEVID", "ARSPD_PRIMARY", "ARSPD2_TYPE")}
        return _fc6_refresh_airspeed_status_locked(self, time.monotonic() if now is None else float(now))
VehicleState.rc6_apply_cached_airspeed_params = _fc6_apply_cached_airspeed_params


def _fc6_tick(self, now: Optional[float] = None) -> Tuple[str, str]:
    with self.lock:
        return _fc6_refresh_airspeed_status_locked(self, time.monotonic() if now is None else float(now))
VehicleState.rc6_tick = _fc6_tick


_fc6_previous_smooth = VehicleState._update_battery_stabilization_locked
def _fc6_smooth_guard(self, now: float) -> None:
    battery = self.state["battery"]
    raw_voltage = finite(battery.get("voltage_v"))
    config = self._battery_stabilization_config_locked()
    arsp = self.state.get("airspeed_sensor") or {}
    if (
        bool(config.get("enabled", True))
        and raw_voltage is not None and raw_voltage > 0.0
        and (str(arsp.get("status")) != "OK" or not bool(arsp.get("smooth_ready")))
    ):
        reason = str(arsp.get("reason") or "airspeed_unavailable")
        self._reset_battery_voltage_tracker_locked(clear_stable=True)
        battery.update({
            "voltage_compensated_v": round(raw_voltage, 4) if raw_voltage is not None else None,
            "voltage_smooth_v": round(raw_voltage, 4) if raw_voltage is not None else None,
            "voltage_filter_status": "raw_airspeed_unavailable",
            "voltage_tracker_state": "raw_fallback:airspeed:" + reason,
            "voltage_tracker_candidate_v": round(raw_voltage, 4) if raw_voltage is not None else None,
            "voltage_compensation_active": False,
            "voltage_compensation_clamped": False,
            "voltage_effective_resistance_mohm": None,
            "voltage_polarization_v": 0.0,
            "voltage_idle_current_a": None,
            "voltage_slow_load_a": 0.0,
        })
        return
    _fc6_previous_smooth(self, now)
VehicleState._update_battery_stabilization_locked = _fc6_smooth_guard


_fc6_previous_percent = VehicleState._update_battery_percentage_locked
def _fc6_percent_guard(self) -> None:
    _fc6_previous_percent(self)
    battery = self.state.get("battery", {})
    if str(battery.get("voltage_filter_status") or "").startswith("raw_airspeed_") and finite(battery.get("voltage_v")) is not None:
        battery["percentage_source"] = "raw"
        self.battery_percentage_source = "raw"
VehicleState._update_battery_percentage_locked = _fc6_percent_guard


def _fc6_event_for_airspeed_transition(self, previous: str, current: str) -> None:
    runtime = getattr(self, "rc6_runtime", None)
    if runtime is None or previous == current:
        return
    detail = copy.deepcopy(self.state.get("airspeed_sensor") or {})
    if current == "FAIL": runtime.flight_logger.event("AIRSPEED_SENSOR_FAIL", detail, "warning")
    elif current == "OK": runtime.flight_logger.event("AIRSPEED_SENSOR_OK", detail, "info")
    elif current == "OFF": runtime.flight_logger.event("AIRSPEED_SENSOR_OFF", detail, "info")
VehicleState.rc6_event_for_airspeed_transition = _fc6_event_for_airspeed_transition


_fc6_previous_update = VehicleState.update
def _fc6_vehicle_update(self, msg: Any) -> None:
    kind = msg.get_type()
    with self.lock:
        prev_armed = self.state.get("vehicle", {}).get("armed")
        prev_arsp = str((self.state.get("airspeed_sensor") or {}).get("status") or "CHECKING")
    _fc6_previous_update(self, msg)
    runtime = getattr(self, "rc6_runtime", None)
    now = time.monotonic()
    if kind == "SYS_STATUS":
        with self.lock:
            # Live health is derived from MAV_SYS_STATUS differential-pressure bits.
            bit = int(getattr(mavutil.mavlink, "MAV_SYS_STATUS_SENSOR_DIFFERENTIAL_PRESSURE", 0) or 0)
            if bit:
                present_mask = int(getattr(msg, "onboard_control_sensors_present", 0) or 0)
                enabled_mask = int(getattr(msg, "onboard_control_sensors_enabled", 0) or 0)
                health_mask = int(getattr(msg, "onboard_control_sensors_health", 0) or 0)
                self.rc6_airspeed_sys_seen = True
                self.rc6_airspeed_sys = {
                    "present": bool(present_mask & bit),
                    "enabled": bool(enabled_mask & bit),
                    "healthy": bool(health_mask & bit),
                }
            _fc6_refresh_airspeed_status_locked(self, now)
    with self.lock:
        new_armed = self.state.get("vehicle", {}).get("armed")
        new_arsp = str((self.state.get("airspeed_sensor") or {}).get("status") or "CHECKING")
        state_copy = copy.deepcopy(self.state)
    if prev_arsp != new_arsp: self.rc6_event_for_airspeed_transition(prev_arsp, new_arsp)
    if runtime is not None and new_armed is True and prev_armed is not True:
        runtime.flight_logger.start_flight(state_copy)
    elif runtime is not None and new_armed is False and prev_armed is True:
        runtime.flight_logger.stop_flight(state_copy)
    if runtime is not None and kind == "STATUSTEXT" and runtime.flight_logger.active_requested:
        text = str(getattr(msg, "text", "") or "").rstrip("\x00").strip()
        severity_n = int(getattr(msg, "severity", 6) or 6)
        severity = "warning" if severity_n <= 4 else "info"
        if text: runtime.flight_logger.event("FC_STATUSTEXT", {"text": text, "severity_code": severity_n}, severity)
VehicleState.update = _fc6_vehicle_update


def _fc6_log_sample_from_snapshot(snapshot: Dict[str, Any], joystick: Dict[str, Any]) -> Dict[str, Any]:
    speed = snapshot.get("speed") or {}; battery = snapshot.get("battery") or {}; attitude = snapshot.get("attitude") or {}
    vehicle = snapshot.get("vehicle") or {}; gps = snapshot.get("gps") or {}; wind = snapshot.get("wind") or {}
    arsp = snapshot.get("airspeed_sensor") or {}; connection = snapshot.get("connection") or {}
    return {
        "airspeed_m_s": speed.get("airspeed_m_s"), "groundspeed_m_s": speed.get("groundspeed_m_s"),
        "throttle_pct": speed.get("throttle_pct"), "vertical_speed_m_s": speed.get("vertical_speed_m_s"),
        "roll_deg": attitude.get("roll_deg"), "pitch_deg": attitude.get("pitch_deg"), "heading_deg": attitude.get("heading_deg"),
        "raw_voltage_v": battery.get("voltage_v"), "smooth_voltage_v": battery.get("voltage_smooth_v"),
        "smooth_status": battery.get("voltage_filter_status"), "current_a": battery.get("current_a"),
        "battery_pct": battery.get("estimated_pct"), "battery_pct_source": battery.get("percentage_source"),
        "consumed_mah": battery.get("consumed_mah"), "mode": vehicle.get("mode"), "armed": vehicle.get("armed"),
        "gps_fix": gps.get("fix"), "gps_fix_type": gps.get("fix_type"), "gps_satellites": gps.get("satellites"),
        "wind_m_s": wind.get("speed_m_s"), "wind_gust_m_s": wind.get("gust_m_s"), "wind_direction_deg": wind.get("direction_deg"),
        "airspeed_sensor_status": arsp.get("status"), "airspeed_devid": arsp.get("devid"),
        "airspeed_present": arsp.get("present"), "airspeed_enabled": arsp.get("enabled"), "airspeed_healthy": arsp.get("healthy"),
        "connection_state": connection.get("state"),
        "joystick_connected": joystick.get("connected"), "joystick_configured": joystick.get("configured"),
    }


_fc6_previous_runtime_init = GroundStationRuntime.__init__
def _fc6_runtime_init(self, config: Dict[str, Any]) -> None:
    _fc6_previous_runtime_init(self, config)
    self.flight_logger = _FlightCoreRC6FlightLogger(FC6_FLIGHT_LOG_ROOT)
    self.vehicle.rc6_runtime = self
    self.rc6_joystick_status: Dict[str, Any] = {}
    self.rc6_housekeeping_stop = threading.Event()
    self.rc6_housekeeping_thread = threading.Thread(target=self._fc6_housekeeping_loop, name="fc6-housekeeping", daemon=True)
    self.rc6_housekeeping_thread.start()
GroundStationRuntime.__init__ = _fc6_runtime_init


def _fc6_housekeeping_loop(self) -> None:
    next_param = 0.0; next_joy = 0.0; next_sample = 0.0; last_connection = None
    while not self.stop_event.is_set() and not self.rc6_housekeeping_stop.is_set():
        now = time.monotonic()
        try:
            if now >= next_param:
                next_param = now + FC6_PARAM_POLL_S
                try:
                    payload = _fc6_json_get(FC6_PARAMD_STATE_URL + "?names=ARSPD_TYPE,ARSPD_USE,ARSPD_DEVID,ARSPD_PRIMARY,ARSPD2_TYPE", timeout=0.8)
                    params = payload.get("params") if isinstance(payload, dict) else None
                    if isinstance(params, dict):
                        before, after = self.vehicle.rc6_apply_cached_airspeed_params(params, now)
                        if before != after: self.vehicle.rc6_event_for_airspeed_transition(before, after)
                except Exception:
                    pass
            if now >= next_joy:
                next_joy = now + FC6_JOYSTICK_POLL_S
                try:
                    joy = _fc6_json_get(FC6_JOYSTICK_STATUS_URL, timeout=0.5)
                    self.rc6_joystick_status = joy if isinstance(joy, dict) else {}
                except Exception:
                    self.rc6_joystick_status = {}
            before, after = self.vehicle.rc6_tick(now)
            if before != after: self.vehicle.rc6_event_for_airspeed_transition(before, after)
            snapshot = self.vehicle.snapshot(include_track=False)
            connection = str((snapshot.get("connection") or {}).get("state") or "")
            if last_connection is not None and connection != last_connection and self.flight_logger.active_requested:
                severity = "warning" if connection in {"LINK_LOST", "NO_VEHICLE"} else "info"
                self.flight_logger.event("CONNECTION_STATE", {"from": last_connection, "to": connection}, severity)
            last_connection = connection
            if snapshot.get("vehicle", {}).get("armed") is True and now >= next_sample:
                next_sample = now + FC6_SAMPLE_PERIOD_S
                self.flight_logger.sample(_fc6_log_sample_from_snapshot(snapshot, self.rc6_joystick_status))
        except Exception as exc:
            print(f"[FLIGHTCORE_RC6_HOUSEKEEPING_ERROR] {exc!r}", flush=True)
        self.stop_event.wait(0.2)
GroundStationRuntime._fc6_housekeeping_loop = _fc6_housekeeping_loop


_fc6_previous_runtime_stop = GroundStationRuntime.stop
def _fc6_runtime_stop(self, *_args: Any) -> None:
    try: self.rc6_housekeeping_stop.set()
    except Exception: pass
    _fc6_previous_runtime_stop(self, *_args)
    try: self.flight_logger.shutdown()
    except Exception: pass
GroundStationRuntime.stop = _fc6_runtime_stop


# FLIGHTCORE_4_3_0_RC8_V81_ADVISORY_FEATURES_V1
# RC8 adds TURN HOME + LTE Health as advisory-only telemetry and extends
# flight diagnostics. This block intentionally contains no MAVLink transmitter,
# SET_MODE, RTL command, or flight-controller failsafe authority.
import sys as _fc81_sys
_fc81_feature_lib = '/usr/local/lib/flightcore'
if _fc81_feature_lib not in _fc81_sys.path:
    _fc81_sys.path.insert(0, _fc81_feature_lib)
from rc8_features import FeatureManager as _FC81FeatureManager

# New telemetry items are ordinary movable Telemetry Edit values. Ground Station
# Settings UI itself is deliberately not redesigned in RC8.
NORMALIZED_TELEMETRY_FIELDS.extend([
    {"key":"norm.turn_home.display","label":"TURN HOME","unit":"","path":["turn_home","telemetry_value"],"category":"Navigation"},
    {"key":"norm.lte_health.display","label":"LTE","unit":"","path":["lte_health","telemetry_value"],"category":"Radio"},
    {"key":"norm.lte_health.signal_dbm","label":"LTE Signal","unit":"dBm","path":["lte_health","signal_dbm"],"digits":0,"category":"Radio"},
])

_FC81_BASE_SNAPSHOT = VehicleState.snapshot

def _fc81_publish_features(self, payload: Dict[str, Any]) -> None:
    with self.vehicle.lock:
        self.vehicle.state['turn_home'] = copy.deepcopy(payload.get('turn_home') or {})
        self.vehicle.state['turn_home_config'] = copy.deepcopy(payload.get('turn_home_config') or {})
        self.vehicle.state['lte_health'] = copy.deepcopy(payload.get('lte_health') or {})
        now = time.monotonic()
        self.vehicle.field_times['turn_home'] = now
        self.vehicle.field_times['turn_home_config'] = now
        self.vehicle.field_times['lte_health'] = now
GroundStationRuntime._fc81_publish_features = _fc81_publish_features

_fc81_previous_snapshot = VehicleState.snapshot
def _fc81_snapshot(self, include_track: bool = False) -> Dict[str, Any]:
    snap = _fc81_previous_snapshot(self, include_track=include_track)
    with self.lock:
        try:
            cfg = self._battery_stabilization_config_locked()
        except Exception:
            cfg = {}
    snap['smooth_voltage_user_settings'] = {
        'enabled': cfg.get('enabled'),
        'cruise_current_a': cfg.get('normal_cruise_current_a'),
        'pack_resistance_mohm': cfg.get('pack_resistance_mohm'),
    }
    return snap
VehicleState.snapshot = _fc81_snapshot

_fc81_previous_runtime_init = GroundStationRuntime.__init__
def _fc81_runtime_init(self, config: Dict[str, Any]) -> None:
    _fc81_previous_runtime_init(self, config)
    self.fc81_feature_manager = _FC81FeatureManager(
        lambda include_track=False: _FC81_BASE_SNAPSHOT(self.vehicle, include_track=include_track),
        lambda payload: self._fc81_publish_features(payload),
    )
    self.fc81_diag_stop = threading.Event()
    self.fc81_diag_thread = threading.Thread(target=self._fc81_diag_loop, name='fc81-joystick-diag-tail', daemon=True)
    self.fc81_diag_thread.start()
GroundStationRuntime.__init__ = _fc81_runtime_init

FC81_JOYSTICK_EVENT_STREAM = Path('/var/lib/flightcore/flight-logs/.joystick-events.jsonl')
FC81_JOYSTICK_STATE = Path('/var/lib/flightcore/flight-logs/.joystick-state.json')
FC81_TURN_HOME_FORECAST_DIAGNOSTIC = Path('/run/flightcore/turn_home_forecast_snapshot.json')

def _fc81_read_joystick_state() -> Dict[str, Any]:
    try:
        value = json.loads(FC81_JOYSTICK_STATE.read_text(encoding='utf-8'))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _fc81_diag_loop(self) -> None:
    # Sparse bridge events plus mode transitions are correlated onto the same
    # flight-log timeline. This thread never sends control traffic.
    offset = 0
    last_inode = None
    last_mode = None
    last_turn_signature = None
    last_forecast_snapshot_id = None
    last_lte_signature = None
    last_smooth_settings = None
    last_turn_config = None
    release_identity_recorded = False
    while not self.stop_event.is_set() and not self.fc81_diag_stop.is_set():
        try:
            snapshot = self.vehicle.snapshot(include_track=False)
            mode = str((snapshot.get('vehicle') or {}).get('mode') or '')
            if last_mode is not None and mode and mode != last_mode and self.flight_logger.active_requested:
                self.flight_logger.event('MODE', {'from': last_mode, 'to': mode}, 'info')
            if mode:
                last_mode = mode
            if self.flight_logger.active_requested:
                turn = snapshot.get('turn_home') or {}
                turn_config = snapshot.get('turn_home_config') or {}
                if not release_identity_recorded:
                    self.flight_logger.event('FLIGHTCORE_RELEASE_IDENTITY', copy.deepcopy(FC81_RELEASE_LOG_IDENTITY), 'info')
                    release_identity_recorded = True
                turn_config_sig = json.dumps(turn_config, sort_keys=True, separators=(',', ':'))
                if last_turn_config is None or turn_config_sig != last_turn_config:
                    self.flight_logger.event('TURN_HOME_CONFIG', copy.deepcopy(turn_config), 'info')
                last_turn_config = turn_config_sig
                turn_sig = (turn.get('display'), turn.get('confidence'), turn.get('controlling_limit'), turn.get('forecast_status'))
                if last_turn_signature is None or turn_sig != last_turn_signature:
                    # Sparse material-change event; full segment diagnostics live here
                    # rather than being repeated in every ~1 Hz sample.
                    self.flight_logger.event('TURN_HOME_CHANGE', copy.deepcopy(turn), 'info')
                last_turn_signature = turn_sig
                forecast_snapshot_id = turn.get('forecast_snapshot_id')
                if forecast_snapshot_id and forecast_snapshot_id != last_forecast_snapshot_id:
                    provider_input = {}
                    try:
                        value = json.loads(FC81_TURN_HOME_FORECAST_DIAGNOSTIC.read_text(encoding='utf-8'))
                        if isinstance(value, dict) and value.get('snapshot_id') == forecast_snapshot_id:
                            provider_input = value
                    except Exception:
                        provider_input = {}
                    self.flight_logger.event('TURN_HOME_FORECAST_SNAPSHOT', {
                        'forecast_snapshot_id': forecast_snapshot_id,
                        'provider': turn.get('provider'),
                        'forecast_status': turn.get('forecast_status'),
                        'forecast_age_s': turn.get('forecast_age_s'),
                        'forecast_source_host': turn.get('forecast_source_host'),
                        'forecast_model': turn.get('forecast_model'),
                        'forecast_wind_speed_m_s': turn.get('forecast_wind_speed_m_s'),
                        'forecast_wind_from_deg_true': turn.get('forecast_wind_from_deg_true'),
                        'forecast_effective_headwind_m_s': turn.get('forecast_effective_headwind_m_s'),
                        'forecast_anchor_tau_s': turn.get('forecast_anchor_tau_s'),
                        'route_points': copy.deepcopy(turn.get('route_points') or []),
                        'segments': copy.deepcopy(turn.get('segments') or []),
                        'provider_input': provider_input,
                    }, 'info')
                    last_forecast_snapshot_id = forecast_snapshot_id
                lte = snapshot.get('lte_health') or {}
                lte_sig = (lte.get('state'), lte.get('trend'), lte.get('cell_id'), lte.get('internet_state'), lte.get('sim_state'))
                if last_lte_signature is not None and lte_sig != last_lte_signature:
                    safe_lte = {k:v for k,v in lte.items() if k not in {'password','session','imsi','iccid','imei'}}
                    self.flight_logger.event('LTE_HEALTH_CHANGE', safe_lte, 'info')
                last_lte_signature = lte_sig
                smooth_settings = snapshot.get('smooth_voltage_user_settings') or {}
                smooth_sig = (smooth_settings.get('enabled'), smooth_settings.get('cruise_current_a'), smooth_settings.get('pack_resistance_mohm'))
                if last_smooth_settings is None or smooth_sig != last_smooth_settings:
                    self.flight_logger.event('SMOOTH_VOLTAGE_SETTINGS_CHANGE', copy.deepcopy(smooth_settings), 'info')
                last_smooth_settings = smooth_sig
            else:
                last_turn_signature = None; last_forecast_snapshot_id = None; last_lte_signature = None; last_smooth_settings = None
                last_turn_config = None; release_identity_recorded = False
            try:
                st = FC81_JOYSTICK_EVENT_STREAM.stat()
                if last_inode != (st.st_dev, st.st_ino):
                    last_inode = (st.st_dev, st.st_ino); offset = 0
                with FC81_JOYSTICK_EVENT_STREAM.open('r', encoding='utf-8', errors='replace') as f:
                    f.seek(offset)
                    for line in f:
                        try:
                            ev = json.loads(line)
                        except Exception:
                            continue
                        if self.flight_logger.active_requested and isinstance(ev, dict):
                            name = str(ev.get('event') or 'JOYSTICK_DIAGNOSTIC')
                            detail = {k:v for k,v in ev.items() if k not in {'event','ts','severity'}}
                            self.flight_logger.event(name, detail, str(ev.get('severity') or 'info'))
                    offset = f.tell()
            except FileNotFoundError:
                pass
        except Exception as exc:
            print(f'[FLIGHTCORE_RC8_JOYSTICK_DIAG_ERROR] {exc!r}', flush=True)
        self.fc81_diag_stop.wait(0.25)
GroundStationRuntime._fc81_diag_loop = _fc81_diag_loop

_fc81_previous_log_sample = _fc6_log_sample_from_snapshot
def _fc81_log_sample_from_snapshot(snapshot: Dict[str, Any], joystick: Dict[str, Any]) -> Dict[str, Any]:
    row = _fc81_previous_log_sample(snapshot, joystick)
    settings = snapshot.get('smooth_voltage_user_settings') or {}
    turn = snapshot.get('turn_home') or {}
    turn_config = snapshot.get('turn_home_config') or {}
    lte = snapshot.get('lte_health') or {}
    wind = snapshot.get('wind') or {}
    position = snapshot.get('position') or {}
    navigation = snapshot.get('navigation') or {}
    speed = snapshot.get('speed') or {}
    battery = snapshot.get('battery') or {}
    field_age = snapshot.get('field_age_s') or {}
    bjoy = _fc81_read_joystick_state()
    row.update({
        # FLIGHTCORE_4_3_0_RC17_COMPLETE_TURN_HOME_FORENSIC_LOG_V1
        # Exact release identity is recorded once in meta.json and as a flight
        # event; the CSV exporter adds it to every portable row after the flight.
        'smooth_voltage_enabled': settings.get('enabled'),
        'smooth_cruise_current_setting_a': settings.get('cruise_current_a'),
        'smooth_pack_resistance_setting_mohm': settings.get('pack_resistance_mohm'),
        'turn_home_config_schema_version': turn_config.get('schema_version'),
        'turn_home_enabled': turn_config.get('enabled'),
        'turn_home_config_provider': turn_config.get('provider'),
        'turn_home_config_provider_url': turn_config.get('provider_url'),
        'turn_home_landing_zero_load_voltage_v': turn_config.get('landing_zero_load_voltage_v'),
        'turn_home_max_consumed_mah': turn_config.get('max_consumed_mah'),
        'turn_home_warning_minutes': turn_config.get('warning_minutes'),
        'turn_home_route_sample_points': turn_config.get('route_sample_points'),
        'turn_home_forecast_refresh_s': turn_config.get('forecast_refresh_s'),
        'turn_home_forecast_timeout_s': turn_config.get('forecast_timeout_s'),
        'turn_home_forecast_fresh_s': turn_config.get('forecast_fresh_s'),
        'turn_home_return_groundspeed_floor_m_s': turn_config.get('return_groundspeed_floor_m_s'),
        'aircraft_lat': position.get('lat'),
        'aircraft_lon': position.get('lon'),
        'aircraft_relative_alt_m': position.get('relative_alt_m'),
        'aircraft_amsl_alt_m': position.get('amsl_alt_m'),
        'aircraft_ground_course_deg': position.get('ground_course_deg'),
        'home_lat': navigation.get('home_lat'),
        'home_lon': navigation.get('home_lon'),
        'home_distance_m': navigation.get('home_distance_m'),
        'home_bearing_deg': navigation.get('home_bearing_deg'),
        'airspeed_input_m_s': speed.get('airspeed_m_s'),
        'groundspeed_input_m_s': speed.get('groundspeed_m_s'),
        'current_input_a': battery.get('current_a'),
        'consumed_mah_input': battery.get('consumed_mah'),
        'raw_voltage_input_v': battery.get('voltage_v'),
        'smooth_voltage_input_v': battery.get('voltage_smooth_v'),
        'heartbeat_age_s': field_age.get('heartbeat'),
        'position_age_s': field_age.get('position'),
        'speed_age_s': field_age.get('speed'),
        'battery_age_s': field_age.get('battery'),
        'wind_age_s': field_age.get('wind'),
        'turn_home_valid': turn.get('valid'),
        'turn_home_safe': turn.get('safe'),
        'turn_home_invalid': turn.get('invalid'),
        'turn_home_seconds': turn.get('seconds'),
        'turn_home_minutes': turn.get('minutes'),
        'turn_home_display': turn.get('display'),
        'turn_home_telemetry_value': turn.get('telemetry_value'),
        'turn_home_confidence': turn.get('confidence'),
        'turn_home_controlling_limit': turn.get('controlling_limit'),
        'turn_home_reason': turn.get('reason'),
        'turn_home_projection': turn.get('projection'),
        'turn_home_updated_at': turn.get('updated_at'),
        'turn_home_flight_control_effect': turn.get('flight_control_effect'),
        'turn_home_overdue_seconds': turn.get('overdue_seconds'),
        'turn_home_emergency_landing_required': turn.get('emergency_landing_required'),
        'turn_home_emergency_landing_distance_from_home_m': turn.get('emergency_landing_distance_from_home_m'),
        'turn_home_landing_margin_s': turn.get('landing_margin_s'),
        'turn_home_turn_position_lat': (turn.get('turn_position') or {}).get('lat'),
        'turn_home_turn_position_lon': (turn.get('turn_position') or {}).get('lon'),
        'turn_home_direct_distance_m': turn.get('direct_distance_m'),
        'turn_home_return_eta_s': turn.get('return_eta_s'),
        'turn_home_return_current_a': turn.get('return_current_a'),
        'turn_home_mission_current_a': turn.get('mission_current_a'),
        'turn_home_return_mah': turn.get('return_mah'),
        'turn_home_mission_mah': turn.get('mission_mah'),
        'turn_home_projected_landing_mah': turn.get('projected_landing_mah'),
        'turn_home_capacity_limit_mah': turn.get('capacity_limit_mah'),
        'turn_home_projected_landing_zero_load_v': turn.get('projected_landing_zero_load_v'),
        'turn_home_voltage_limit_v': turn.get('voltage_limit_v'),
        'turn_home_voltage_slope_v_per_mah': turn.get('voltage_slope_v_per_mah'),
        'turn_home_voltage_slope_source': turn.get('voltage_slope_source'),
        'turn_home_capacity_available_return_s': turn.get('capacity_available_return_s'),
        'turn_home_voltage_available_return_s': turn.get('voltage_available_return_s'),
        'turn_home_forecast_status': turn.get('forecast_status'),
        'turn_home_forecast_age_s': turn.get('forecast_age_s'),
        'turn_home_forecast_provider': turn.get('provider'),
        'turn_home_forecast_snapshot_id': turn.get('forecast_snapshot_id'),
        'turn_home_forecast_source_host': turn.get('forecast_source_host'),
        'turn_home_forecast_model': turn.get('forecast_model'),
        'turn_home_forecast_error': turn.get('forecast_error'),
        'turn_home_forecast_anchor_tau_s': turn.get('forecast_anchor_tau_s'),
        'turn_home_forecast_route_anchor_delta_s': turn.get('forecast_route_anchor_delta_s'),
        'turn_home_armed': turn.get('armed'),
        'turn_home_on_ground': turn.get('on_ground'),
        'turn_home_airborne_qualified': turn.get('airborne_qualified'),
        'turn_home_flight_state': turn.get('flight_state'),
        'turn_home_flight_qualification_reason': turn.get('flight_qualification_reason'),
        'turn_home_credible_motion': turn.get('credible_motion'),
        'turn_home_motion_fresh': turn.get('motion_fresh'),
        'turn_home_measured_wind_eligible': turn.get('measured_wind_eligible'),
        'turn_home_measured_wind_rejection_reason': turn.get('measured_wind_rejection_reason'),
        'turn_home_measured_wind_continuous_valid_s': turn.get('measured_wind_continuous_valid_s'),
        'turn_home_measured_wind_ramp': turn.get('measured_wind_ramp'),
        'turn_home_measured_wind_age_s': turn.get('measured_wind_age_s'),
        'turn_home_measured_wind_valid': turn.get('measured_wind_valid'),
        'turn_home_measured_wind_blend_weight': turn.get('measured_wind_blend_weight'),
        'turn_home_return_feasible': turn.get('return_feasible'),
        'turn_home_return_groundspeed_min_m_s': turn.get('return_groundspeed_min_m_s'),
        'turn_home_average_return_tailwind_m_s': turn.get('average_return_tailwind_m_s'),
        'turn_home_battery_voltage_margin_now_v': turn.get('battery_voltage_margin_now_v'),
        'turn_home_battery_capacity_margin_now_mah': turn.get('battery_capacity_margin_now_mah'),
        'turn_home_projected_voltage_margin_v': turn.get('projected_voltage_margin_v'),
        'turn_home_projected_capacity_margin_mah': turn.get('projected_capacity_margin_mah'),
        'wind_measured_speed_m_s': wind.get('speed_m_s'),
        'wind_measured_from_deg_true': wind.get('direction_deg'),
        'wind_measured_vertical_m_s': wind.get('vertical_m_s'),
        'wind_measured_gust_m_s': wind.get('gust_m_s'),
        'wind_measured_valid': finite(wind.get('speed_m_s')) is not None and finite(wind.get('direction_deg')) is not None,
        'wind_forecast_speed_m_s': turn.get('forecast_wind_speed_m_s'),
        'wind_forecast_from_deg_true': turn.get('forecast_wind_from_deg_true'),
        'wind_forecast_effective_headwind_m_s': turn.get('forecast_effective_headwind_m_s'),
        'lte_state': lte.get('state'),
        'lte_signal_dbm': lte.get('signal_dbm'),
        'lte_trend': lte.get('trend'),
        'browser_joystick_connected': bjoy.get('controller_connected'),
        'browser_joystick_packets_last_second': bjoy.get('packets_received_last_second'),
        'browser_joystick_packet_age_ms': bjoy.get('packet_age_ms'),
        'browser_joystick_human_idle_s': bjoy.get('human_idle_s'),
        'browser_gcs_heartbeat_active': bjoy.get('gcs_heartbeat_active'),
    })
    return row
_fc6_log_sample_from_snapshot = _fc81_log_sample_from_snapshot

# Smooth Voltage RC8 correction: preserve adaptive fast sag learning while
# reducing Li-ion slow polarization prior from 45% to 25%. Flight evidence
# showed ~0.14 V late-flight over-compensation at 5 A / 75 mOhm versus a
# 24.06 V independent rested measurement. Low-current monotonic convergence is
# retained as the conservative boundary pending RC8 flight validation.
_fc81_original_smooth = VehicleState._update_battery_stabilization_locked
# The source-level constant is patched by the Factory builder; this marker makes
# the exact design intent auditable in the installed daemon.
FC81_LIION_POLARIZATION_RATIO = 0.25

_fc81_previous_runtime_stop = GroundStationRuntime.stop
def _fc81_runtime_stop(self, *_args: Any) -> None:
    try:
        self.fc81_diag_stop.set()
    except Exception:
        pass
    try:
        self.fc81_feature_manager.stop()
    except Exception:
        pass
    _fc81_previous_runtime_stop(self, *_args)
    try:
        self.fc81_diag_thread.join(timeout=1.0)
    except Exception:
        pass
GroundStationRuntime.stop = _fc81_runtime_stop

# Extend loopback-only feature configuration API. Router password remains
# server-side and is never returned from this endpoint.
_fc81_previous_api_get = ApiHandler.do_GET
def _fc81_api_get(self) -> None:
    assert RUNTIME is not None
    path = urlparse(self.path).path
    if path == '/features/turn-home':
        return self._json({'ok': True, 'config': RUNTIME.fc81_feature_manager.turn_home.read_config(), 'state': RUNTIME.fc81_feature_manager.turn_home.snapshot()})
    if path == '/features/lte-health':
        return self._json({'ok': True, 'config': RUNTIME.fc81_feature_manager.lte.safe_config(), 'state': RUNTIME.fc81_feature_manager.lte.snapshot()})
    return _fc81_previous_api_get(self)
ApiHandler.do_GET = _fc81_api_get

_fc81_previous_api_post = ApiHandler.do_POST
def _fc81_api_post(self) -> None:
    assert RUNTIME is not None
    path = self.path.split('?',1)[0]
    if path not in {'/features/turn-home','/features/lte-health'}:
        return _fc81_previous_api_post(self)
    try:
        length = int(self.headers.get('Content-Length','0') or 0)
    except ValueError:
        length = 0
    if length <= 0 or length > 65536:
        return self._json({'ok': False, 'error': 'invalid content length'}, 400)
    try:
        payload = json.loads(self.rfile.read(length).decode('utf-8'))
        if not isinstance(payload, dict):
            raise ValueError('configuration must be a JSON object')
        if path == '/features/turn-home':
            cfg = RUNTIME.fc81_feature_manager.turn_home.write_config(payload.get('config', payload))
            return self._json({'ok': True, 'config': cfg})
        password = payload.get('password') if 'password' in payload else None
        cfg = RUNTIME.fc81_feature_manager.lte.write_config(payload.get('config', payload), password=password)
        return self._json({'ok': True, 'config': RUNTIME.fc81_feature_manager.lte.safe_config()})
    except Exception as exc:
        return self._json({'ok': False, 'error': str(exc)}, 400)
ApiHandler.do_POST = _fc81_api_post
# FLIGHTCORE_4_3_0_RC8_V81_ADVISORY_FEATURES_V1_END


def main() -> int:
    global RUNTIME
    config = load_config()
    if not bool(config.get("enabled", True)):
        print("[GROUNDSTATION] disabled in configuration", flush=True)
        return 0
    RUNTIME = GroundStationRuntime(config)
    thread = threading.Thread(target=RUNTIME.mavlink_loop, name="mavlink", daemon=True)
    thread.start()
    api_cfg = config["internal_api"]
    server = ThreadingHTTPServer((str(api_cfg.get("host", "127.0.0.1")), int(api_cfg.get("port", 18765))), ApiHandler)
    server.daemon_threads = True
    print(
        "[GROUNDSTATION] monitor-only daemon ready on "
        f"{api_cfg.get('host', '127.0.0.1')}:{int(api_cfg.get('port', 18765))}",
        flush=True,
    )
    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        RUNTIME.stop()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
