# FlightCore 4.3.0 RC35

Canonical machine identity: `4.3.0-rc.35`. Build: `20260821.233000-35d8a24`.

RC35 corrects the remaining Android Airlink recovery defect proven by the RC34 physical bench test. RC34 restored the WiFiLink source and WHEP reader, but Android could retain a stale video element and decoder until the Ground Station page was reloaded.

## Correction

- A genuine new Airlink MediaStream generation now releases the obsolete Airlink receiver tracks and replaces only the affected Airlink `<video>` element.
- The rebuilt element retains its identity, layout, muted autoplay and inline-playback behaviour.
- Recovery is accepted only after the video element reports a decoded frame through `requestVideoFrameCallback`; reader count alone is insufficient.
- A playback rejection or sustained no-frame condition enters the existing serialized recovery path; no manual recovery button or Ground Station reload is used.
- A local browser-recovery state endpoint records the latest generation and decoded-element event for deterministic bench verification.

## Preserved behaviour

RC34 management isolation and single-flight WiFiLink settings access remain unchanged. SIYI video, telemetry, joystick, flight modes, flight-control authority, Flight Logs, cloud compatibility and log-storage controls are unchanged. WiFiLink firmware, Wi-Fi profiles, router settings and network configuration are not modified.

## Acceptance boundary

Factory validation covers the exact accepted RC34 upgrade identity, retained clean historical upgrade routes, fresh-install packaging, JavaScript/Python/shell syntax, Airlink-only media-element reconstruction, decoded-frame confirmation and immutable manifests. Physical acceptance must confirm automatic Android picture return without Ground Station reload followed by a thirty-minute continuity soak.
