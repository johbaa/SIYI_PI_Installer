# FlightCore 4.3.0 RC11

Canonical machine identity: `4.3.0-rc.11`.

RC11 retains the complete RC10 publication compatibility scope and restores installed-source marker loading before Registry-derived native upgrade routing. All advisory features retain no flight-control authority.
