#!/usr/bin/env python3
"""FlightCore 4.3.0 RC8 / Factory V81 pilot-advisory feature engines.

TURN HOME and LTE Health are telemetry/advisory-only. This module contains no
MAVLink transmitter, mode command, RTL authority, or flight-controller writes.
All external networking is executed by the Ground Station feature worker, never
by the MAVLink receive, joystick, telemetry-stream, video, or mode-command path.
"""
from __future__ import annotations

import copy
import json
import math
import os
import random
import socket
import statistics
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import deque
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

TURN_HOME_CONFIG = Path(os.environ.get("FLIGHTCORE_TURN_HOME_CONFIG", "/var/lib/siyi-user-config/groundstation/turn_home.json"))
LTE_CONFIG = Path(os.environ.get("FLIGHTCORE_LTE_CONFIG", "/var/lib/siyi-user-config/groundstation/lte_health.json"))
LTE_SECRET = Path(os.environ.get("FLIGHTCORE_LTE_SECRET", "/var/lib/siyi-user-config/groundstation/lte_router_secret.json"))
TURN_HOME_SECRET = Path(os.environ.get("FLIGHTCORE_TURN_HOME_SECRET", "/var/lib/siyi-user-config/groundstation/turn_home_provider_secret.json"))

TURN_HOME_DEFAULT = {
    "schema_version": 2,
    "enabled": False,
    "provider": "open_meteo",
    "provider_url": "https://api.open-meteo.com/v1/forecast",
    "landing_zero_load_voltage_v": 0.0,
    "max_consumed_mah": 0.0,
    "warning_minutes": 5,
    "route_sample_points": 7,
    "forecast_refresh_s": 600,
    "forecast_timeout_s": 5,
    "forecast_fresh_s": 1800,
    "return_groundspeed_floor_m_s": 3.0,
}
LTE_DEFAULT = {
    "schema_version": 2,
    "enabled": False,
    "gateway": "auto",
    "username": "admin",
    "poll_s": 2.0,
    "context_poll_s": 20.0,
    "network_mode_poll_s": 60.0,
    "stale_s": 10.0,
}


def finite(v: Any) -> Optional[float]:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))


def atomic_json(path: Path, value: Dict[str, Any], mode: int = 0o640) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}.{threading.get_ident()}")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.chmod(tmp, mode)
    os.replace(tmp, path)


def read_json(path: Path, default: Dict[str, Any]) -> Dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else copy.deepcopy(default)
    except Exception:
        return copy.deepcopy(default)


def normalize_turn_home(value: Any) -> Dict[str, Any]:
    src = copy.deepcopy(TURN_HOME_DEFAULT)
    if isinstance(value, dict):
        src.update(value)
    provider = str(src.get("provider") or "open_meteo").strip().lower()
    if provider not in {"open_meteo"}:
        provider = "open_meteo"
    url = str(src.get("provider_url") or TURN_HOME_DEFAULT["provider_url"]).strip()
    if not url.startswith("https://"):
        url = TURN_HOME_DEFAULT["provider_url"]
    return {
        "schema_version": 2,
        "enabled": bool(src.get("enabled", False)),
        "provider": provider,
        "provider_url": url,
        "landing_zero_load_voltage_v": clamp(finite(src.get("landing_zero_load_voltage_v")) or 0.0, 0.0, 100.0),
        "max_consumed_mah": clamp(finite(src.get("max_consumed_mah")) or 0.0, 0.0, 500000.0),
        "warning_minutes": int(round(clamp(finite(src.get("warning_minutes")) or 5.0, 0.0, 120.0))),
        "route_sample_points": int(round(clamp(finite(src.get("route_sample_points")) or 7.0, 5.0, 10.0))),
        "forecast_refresh_s": int(round(clamp(finite(src.get("forecast_refresh_s")) or 600.0, 60.0, 3600.0))),
        "forecast_timeout_s": int(round(clamp(finite(src.get("forecast_timeout_s")) or 5.0, 2.0, 15.0))),
        "forecast_fresh_s": int(round(clamp(finite(src.get("forecast_fresh_s")) or 1800.0, 300.0, 7200.0))),
        "return_groundspeed_floor_m_s": clamp(finite(src.get("return_groundspeed_floor_m_s")) or 3.0, 1.0, 15.0),
    }


def normalize_lte(value: Any) -> Dict[str, Any]:
    src = copy.deepcopy(LTE_DEFAULT)
    if isinstance(value, dict):
        src.update(value)
    gateway = str(src.get("gateway") or "auto").strip()
    if not gateway:
        gateway = "auto"
    username = str(src.get("username") or "admin").strip()[:64] or "admin"
    return {
        "schema_version": 2,
        "enabled": bool(src.get("enabled", False)),
        "gateway": gateway,
        "username": username,
        "poll_s": clamp(finite(src.get("poll_s")) or 2.0, 1.0, 10.0),
        "context_poll_s": clamp(finite(src.get("context_poll_s")) or 20.0, 10.0, 120.0),
        "network_mode_poll_s": clamp(finite(src.get("network_mode_poll_s")) or 60.0, 30.0, 600.0),
        "stale_s": clamp(finite(src.get("stale_s")) or 10.0, 5.0, 60.0),
    }


def meteorological_to_motion(speed_m_s: float, direction_from_deg: float) -> Tuple[float, float]:
    theta = math.radians(direction_from_deg % 360.0)
    return (-speed_m_s * math.sin(theta), -speed_m_s * math.cos(theta))  # east, north


def motion_to_meteorological(east: float, north: float) -> Tuple[float, float]:
    speed = math.hypot(east, north)
    if speed <= 1e-9:
        return 0.0, 0.0
    direction = (math.degrees(math.atan2(-east, -north)) + 360.0) % 360.0
    return speed, direction


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    r = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.atan2(math.sqrt(a), math.sqrt(max(0.0, 1.0 - a)))


def bearing_deg(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    y = math.sin(dl) * math.cos(p2)
    x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(y, x)) + 360.0) % 360.0


def destination(lat: float, lon: float, bearing: float, distance_m: float) -> Tuple[float, float]:
    r = 6371000.0
    d = max(0.0, distance_m) / r
    b = math.radians(bearing % 360.0)
    p1 = math.radians(lat)
    l1 = math.radians(lon)
    p2 = math.asin(math.sin(p1) * math.cos(d) + math.cos(p1) * math.sin(d) * math.cos(b))
    l2 = l1 + math.atan2(math.sin(b) * math.sin(d) * math.cos(p1), math.cos(d) - math.sin(p1) * math.sin(p2))
    return math.degrees(p2), ((math.degrees(l2) + 540.0) % 360.0) - 180.0


def great_circle_points(lat1: float, lon1: float, lat2: float, lon2: float, count: int) -> List[Tuple[float, float]]:
    count = max(2, int(count))
    total = haversine_m(lat1, lon1, lat2, lon2)
    if total < 1.0:
        return [(lat1, lon1) for _ in range(count)]
    b = bearing_deg(lat1, lon1, lat2, lon2)
    return [destination(lat1, lon1, b, total * i / (count - 1)) for i in range(count)]


def _nearest_layer(agl_m: float) -> int:
    return min((10, 80, 120), key=lambda z: abs(float(agl_m) - z))


def _hourly_vector(row: Dict[str, Any], layer: int, valid_epoch: float) -> Optional[Tuple[float, float, Optional[float], int]]:
    hourly = row.get("hourly") if isinstance(row, dict) else None
    if not isinstance(hourly, dict):
        return None
    times = hourly.get("time")
    speeds = hourly.get(f"wind_speed_{layer}m")
    dirs = hourly.get(f"wind_direction_{layer}m")
    gusts = hourly.get("wind_gusts_10m")
    if not (isinstance(times, list) and isinstance(speeds, list) and isinstance(dirs, list)):
        return None
    n = min(len(times), len(speeds), len(dirs))
    pairs: List[Tuple[float, float, float, Optional[float]]] = []
    for i in range(n):
        t, s, d = finite(times[i]), finite(speeds[i]), finite(dirs[i])
        if t is None or s is None or d is None or s < 0 or s > 100:
            continue
        g = finite(gusts[i]) if isinstance(gusts, list) and i < len(gusts) else None
        e, no = meteorological_to_motion(s, d)
        pairs.append((t, e, no, g))
    if not pairs:
        return None
    pairs.sort(key=lambda x: x[0])
    if valid_epoch <= pairs[0][0]:
        return pairs[0][1], pairs[0][2], pairs[0][3], layer
    if valid_epoch >= pairs[-1][0]:
        return pairs[-1][1], pairs[-1][2], pairs[-1][3], layer
    for a, b in zip(pairs, pairs[1:]):
        if a[0] <= valid_epoch <= b[0]:
            f = (valid_epoch - a[0]) / max(1.0, b[0] - a[0])
            e = a[1] + f * (b[1] - a[1])
            no = a[2] + f * (b[2] - a[2])
            if a[3] is not None and b[3] is not None:
                g = a[3] + f * (b[3] - a[3])
            else:
                g = a[3] if a[3] is not None else b[3]
            return e, no, g, layer
    return None


def classify_lte(dbm: float) -> str:
    if dbm > -44 or dbm < -120:
        return "UNKNOWN"
    if dbm >= -95:
        return "EXCELLENT"
    if dbm >= -102:
        return "GOOD"
    if dbm >= -108:
        return "WEAK"
    return "CRITICAL"


class OpenMeteoAdapter:
    """Provider-neutral contract implementation for the documented Open-Meteo shape."""
    name = "open_meteo"

    def __init__(self, endpoint: str, timeout_s: int = 5, api_key: str = "") -> None:
        self.endpoint = endpoint
        self.timeout_s = timeout_s
        self.api_key = str(api_key or "").strip()

    def fetch(self, coords: List[Tuple[float, float]]) -> Dict[str, Any]:
        if not 1 <= len(coords) <= 10:
            raise ValueError("forecast coordinate count must be 1..10")
        q = {
            "latitude": ",".join(f"{lat:.6f}" for lat, _ in coords),
            "longitude": ",".join(f"{lon:.6f}" for _, lon in coords),
            "hourly": "wind_speed_10m,wind_direction_10m,wind_speed_80m,wind_direction_80m,wind_speed_120m,wind_direction_120m,wind_gusts_10m",
            "wind_speed_unit": "ms",
            "timeformat": "unixtime",
            "timezone": "GMT",
            "forecast_days": "2",
        }
        if self.api_key:
            q["apikey"] = self.api_key
        url = self.endpoint + ("&" if "?" in self.endpoint else "?") + urllib.parse.urlencode(q, safe=",")
        req = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": "FlightCore-RC8-TurnHome/4.3.0"})
        with urllib.request.urlopen(req, timeout=self.timeout_s) as r:
            if int(getattr(r, "status", 200)) != 200:
                raise RuntimeError(f"forecast HTTP {getattr(r, 'status', 0)}")
            raw = r.read(2 * 1024 * 1024)
        value = json.loads(raw.decode("utf-8"))
        rows = value if isinstance(value, list) else [value]
        if len(rows) != len(coords):
            raise RuntimeError(f"forecast coordinate count mismatch: requested {len(coords)} got {len(rows)}")
        for row in rows:
            if not isinstance(row, dict) or not isinstance(row.get("hourly"), dict):
                raise RuntimeError("forecast response missing hourly object")
        models = []
        for row in rows:
            model = row.get("models") if isinstance(row, dict) else None
            if model is not None:
                models.append(model)
        return {
            "provider": self.name, "received_at": time.time(), "rows": rows, "coords": coords,
            "url_host": urllib.parse.urlparse(self.endpoint).hostname or "", "models": models,
            "api_key_configured": bool(self.api_key),
        }


# FLIGHTCORE_4_3_0_RC16_TURN_HOME_AIRBORNE_WIND_QUALIFICATION_V1
class TurnHomeEngine:
    AIRBORNE_QUALIFY_S = 5.0
    GROUND_REQUALIFY_S = 3.0
    MEASURED_WIND_QUALIFY_S = 8.0
    MEASURED_WIND_RAMP_S = 12.0
    MOTION_FRESH_S = 3.0
    WIND_FRESH_S = 3.0

    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.config = normalize_turn_home(read_json(TURN_HOME_CONFIG, TURN_HOME_DEFAULT))
        self.history: deque = deque(maxlen=1800)
        self.forecast: Optional[Dict[str, Any]] = None
        self.forecast_error = ""
        self.last_forecast_attempt_m = 0.0
        self.next_forecast_m = 0.0
        self.forecast_anchor_tau_s = 0.0
        self.forecast_refresh_active = False
        self.last_anchor_refine_m = 0.0
        self.last_result: Dict[str, Any] = self._unavailable("initializing")
        self.last_warning_bucket: Optional[int] = None
        self.airborne_candidate_since_m: Optional[float] = None
        self.ground_candidate_since_m: Optional[float] = None
        self.airborne_confirmed = False
        self.measured_wind_valid_since_m: Optional[float] = None

    @staticmethod
    def _unavailable(reason: str) -> Dict[str, Any]:
        return {
            "valid": False, "display": "TURN HOME --", "telemetry_value": "--", "seconds": None, "minutes": None,
            "confidence": "INVALID", "reason": reason, "provider": "open_meteo",
            "forecast_age_s": None, "controlling_limit": None, "updated_at": time.time(),
        }

    def read_config(self) -> Dict[str, Any]:
        with self.lock:
            self.config = normalize_turn_home(read_json(TURN_HOME_CONFIG, self.config))
            return copy.deepcopy(self.config)

    def write_config(self, value: Any) -> Dict[str, Any]:
        merged = self.read_config()
        if isinstance(value, dict):
            merged.update(value)
        config = normalize_turn_home(merged)
        atomic_json(TURN_HOME_CONFIG, config, 0o640)
        with self.lock:
            self.config = config
            self.next_forecast_m = 0.0
        return copy.deepcopy(config)

    def snapshot(self) -> Dict[str, Any]:
        with self.lock:
            return copy.deepcopy(self.last_result)

    def _flight_wind_qualification(self, snapshot: Dict[str, Any], now_m: float) -> Dict[str, Any]:
        """Qualify airborne state and FC wind without adding MAVLink traffic.

        All inputs are taken from the existing Ground Station snapshot.  The
        stateful delays prevent a stationary EKF/airspeed estimate from becoming
        a flight-valid wind source during boot, arming, takeoff or landing.
        """
        vehicle = snapshot.get("vehicle") or {}
        position = snapshot.get("position") or {}
        speed = snapshot.get("speed") or {}
        wind = snapshot.get("wind") or {}
        ages = snapshot.get("field_age_s") or {}
        armed_value = vehicle.get("armed")
        armed = armed_value is True
        relative_alt = finite(position.get("relative_alt_m"))
        groundspeed = finite(speed.get("groundspeed_m_s"))
        airspeed = finite(speed.get("airspeed_m_s"))
        position_age = finite(ages.get("position"))
        speed_age = finite(ages.get("speed"))
        heartbeat_age = finite(ages.get("heartbeat"))
        wind_age = finite(ages.get("wind"))
        motion_fresh = (
            position_age is not None and position_age <= self.MOTION_FRESH_S
            and speed_age is not None and speed_age <= self.MOTION_FRESH_S
            and heartbeat_age is not None and heartbeat_age <= self.MOTION_FRESH_S
        )
        credible_motion = bool(
            motion_fresh
            and relative_alt is not None and relative_alt >= 5.0
            and ((groundspeed is not None and groundspeed >= 3.0)
                 or (airspeed is not None and airspeed >= 5.0))
        )
        positive_ground = bool(
            motion_fresh
            and relative_alt is not None and relative_alt <= 1.5
            and (groundspeed is None or groundspeed < 1.5)
            and (airspeed is None or airspeed < 3.0)
        )

        if not armed:
            self.airborne_candidate_since_m = None
            self.ground_candidate_since_m = None
            self.airborne_confirmed = False
            self.measured_wind_valid_since_m = None
        elif credible_motion:
            self.ground_candidate_since_m = None
            if self.airborne_candidate_since_m is None:
                self.airborne_candidate_since_m = now_m
            if now_m - self.airborne_candidate_since_m >= self.AIRBORNE_QUALIFY_S:
                self.airborne_confirmed = True
        elif positive_ground:
            self.airborne_candidate_since_m = None
            if self.ground_candidate_since_m is None:
                self.ground_candidate_since_m = now_m
            if now_m - self.ground_candidate_since_m >= self.GROUND_REQUALIFY_S:
                self.airborne_confirmed = False
                self.measured_wind_valid_since_m = None
        elif not self.airborne_confirmed:
            self.airborne_candidate_since_m = None

        if armed_value is None:
            flight_state = "unknown"
            flight_reason = "armed_state_unknown"
        elif not armed:
            flight_state = "disarmed"
            flight_reason = "disarmed"
        elif not self.airborne_confirmed:
            flight_state = "armed_ground" if positive_ground else "airborne_acquiring"
            flight_reason = "on_ground" if positive_ground else "airborne_qualification_pending"
        else:
            flight_state = "airborne"
            flight_reason = "qualified"

        wind_speed = finite(wind.get("speed_m_s"))
        wind_direction = finite(wind.get("direction_deg"))
        wind_fresh = wind_age is not None and wind_age <= self.WIND_FRESH_S
        wind_plausible = wind_speed is not None and 0.0 <= wind_speed <= 40.0 and wind_direction is not None
        wind_candidate = bool(self.airborne_confirmed and credible_motion and wind_fresh and wind_plausible)
        if wind_candidate:
            if self.measured_wind_valid_since_m is None:
                self.measured_wind_valid_since_m = now_m
        else:
            self.measured_wind_valid_since_m = None

        wind_valid_s = max(0.0, now_m - self.measured_wind_valid_since_m) if self.measured_wind_valid_since_m is not None else 0.0
        measured_eligible = wind_candidate and wind_valid_s >= self.MEASURED_WIND_QUALIFY_S
        measured_ramp = clamp(
            (wind_valid_s - self.MEASURED_WIND_QUALIFY_S) / self.MEASURED_WIND_RAMP_S,
            0.0,
            1.0,
        ) if measured_eligible else 0.0
        if not self.airborne_confirmed:
            wind_rejection = flight_reason
        elif not credible_motion:
            wind_rejection = "motion_not_credible_or_stale"
        elif not wind_fresh:
            wind_rejection = "wind_stale"
        elif not wind_plausible:
            wind_rejection = "wind_invalid_or_implausible"
        elif not measured_eligible:
            wind_rejection = "wind_qualification_pending"
        else:
            wind_rejection = ""
        return {
            "armed": armed_value,
            "on_ground": bool(not self.airborne_confirmed),
            "airborne_qualified": bool(self.airborne_confirmed),
            "flight_state": flight_state,
            "flight_qualification_reason": flight_reason,
            "credible_motion": credible_motion,
            "motion_fresh": motion_fresh,
            "measured_wind_eligible": bool(measured_eligible),
            "measured_wind_rejection_reason": wind_rejection,
            "measured_wind_continuous_valid_s": round(wind_valid_s, 2),
            "measured_wind_ramp": round(measured_ramp, 3),
            "measured_wind_age_s": round(wind_age, 3) if wind_age is not None else None,
        }

    @staticmethod
    def _project_turn(snapshot: Dict[str, Any], tau_s: float) -> Tuple[Optional[Tuple[float, float]], str]:
        p = snapshot.get("position") or {}; n = snapshot.get("navigation") or {}; s = snapshot.get("speed") or {}; v = snapshot.get("vehicle") or {}
        lat, lon = finite(p.get("lat")), finite(p.get("lon"))
        if lat is None or lon is None:
            return None, "position_invalid"
        mode = str(v.get("mode") or "").upper()
        if mode == "LOITER" or (finite(s.get("groundspeed_m_s")) or 0.0) < 1.0:
            return (lat, lon), "loiter_hold"
        gs = clamp(finite(s.get("groundspeed_m_s")) or 0.0, 0.0, 80.0)
        if gs <= 0:
            return (lat, lon), "stationary_hold"
        if mode == "AUTO":
            b = finite(n.get("target_bearing_deg"))
            if b is not None:
                return destination(lat, lon, b, gs * max(0.0, tau_s)), "auto_active_leg_projection"
            b = finite(p.get("ground_course_deg"))
            if b is not None:
                return destination(lat, lon, b, min(gs * max(0.0, tau_s), 30000.0)), "auto_track_fallback"
            return (lat, lon), "auto_projection_degraded"
        b = finite(p.get("ground_course_deg"))
        if b is None:
            b = finite((snapshot.get("attitude") or {}).get("heading_deg"))
        if b is None:
            return (lat, lon), "manual_projection_degraded"
        return destination(lat, lon, b, min(gs * max(0.0, tau_s), 30000.0)), "track_projection"

    def _forecast_refresh_needed(self, now_m: float) -> bool:
        with self.lock:
            return now_m >= self.next_forecast_m

    def _forecast_worker(self, snapshot: Dict[str, Any], now_m: float) -> None:
        config = self.read_config()
        try:
            if not config.get("enabled") or config.get("provider") != "open_meteo":
                return
            n = snapshot.get("navigation") or {}; p = snapshot.get("position") or {}
            home_lat, home_lon = finite(n.get("home_lat")), finite(n.get("home_lon"))
            lat, lon = finite(p.get("lat")), finite(p.get("lon"))
            if None in (home_lat, home_lon, lat, lon):
                return
            with self.lock:
                anchor = finite(self.last_result.get("seconds")) or 0.0
            anchor = clamp(anchor, 0.0, 7200.0)
            turn, _ = self._project_turn(snapshot, anchor)
            if turn is None:
                turn = (lat, lon)
            coords = great_circle_points(turn[0], turn[1], home_lat, home_lon, int(config["route_sample_points"]))
            self.last_forecast_attempt_m = now_m
            secret = read_json(TURN_HOME_SECRET, {})
            adapter = OpenMeteoAdapter(
                str(config["provider_url"]), int(config["forecast_timeout_s"]),
                str(secret.get("api_key") or ""),
            )
            result = adapter.fetch(coords)
            result["anchor_turn"] = turn
            result["anchor_tau_s"] = anchor
            # Stable within one provider response and different for every
            # completed refresh. Flight samples reference this compact ID;
            # the full route/segment detail is logged once as a sparse event.
            result["snapshot_id"] = (
                f"{config['provider']}-{int(float(result.get('received_at') or time.time()) * 1000)}"
            )
            with self.lock:
                self.forecast = result
                self.forecast_error = ""
                self.forecast_anchor_tau_s = anchor
                self.next_forecast_m = time.monotonic() + float(config["forecast_refresh_s"])
        except Exception as exc:
            with self.lock:
                self.forecast_error = str(exc)[:300]
                self.next_forecast_m = time.monotonic() + min(float(config.get("forecast_refresh_s") or 600), 60.0 + random.random() * 60.0)
        finally:
            with self.lock:
                self.forecast_refresh_active = False

    def _kick_forecast_refresh(self, snapshot: Dict[str, Any], now_m: float) -> None:
        # Forecast networking is always asynchronous. The 1 Hz solver continues
        # using the last fresh cache or measured-wind fallback while HTTP is in flight.
        with self.lock:
            if self.forecast_refresh_active or now_m < self.next_forecast_m:
                return
            self.forecast_refresh_active = True
            # Prevent multiple solver ticks from spawning duplicate requests.
            self.next_forecast_m = now_m + 30.0
        snap = copy.deepcopy(snapshot)
        threading.Thread(target=self._forecast_worker, args=(snap, now_m), name="fc8-turn-home-forecast", daemon=True).start()

    def _record_battery_sample(self, snapshot: Dict[str, Any]) -> None:
        # Record exactly once per 1 Hz solver update.  V81 appended from every
        # binary-search evaluation, filling 1,800 entries in about 90 seconds.
        now = time.time(); b = snapshot.get("battery") or {}
        smooth, mah = finite(b.get("voltage_smooth_v")), finite(b.get("consumed_mah"))
        if smooth is not None and mah is not None:
            self.history.append((now, mah, smooth, finite(b.get("current_a")) or 0.0))

    def _voltage_slope_v_per_mah(self, snapshot: Dict[str, Any], config: Dict[str, Any]) -> Tuple[float, str]:
        if len(self.history) >= 10:
            newest = self.history[-1]
            for old in self.history:
                dmah = newest[1] - old[1]
                if dmah >= 250.0 and newest[0] - old[0] >= 120.0:
                    slope = (old[2] - newest[2]) / dmah
                    if 0.00001 <= slope <= 0.002:
                        return slope, "recent_smooth_v_per_mah"
        # bounded battery-curve fallback; experimental and exposed in diagnostics
        tl = read_json(Path("/var/lib/siyi-user-config/groundstation/telemetry_canvas.json"), {})
        bc = tl.get("battery_stabilization") if isinstance(tl, dict) else {}
        cells = finite((bc or {}).get("battery_series_cells")) or 6.0
        full = finite((bc or {}).get("battery_full_v_per_cell")) or 4.10
        empty = finite((bc or {}).get("battery_empty_v_per_cell")) or 3.00
        cap = float(config.get("max_consumed_mah") or 0.0)
        if cap > 100.0 and full > empty:
            return clamp(cells * (full - empty) / cap, 0.00001, 0.002), "configured_battery_curve"
        return 0.0, "unavailable"

    def _forecast_vectors(self, segment_count: int, arrival_epochs: List[float], agl_m: float) -> Tuple[List[Optional[Tuple[float, float, Optional[float], int]]], Optional[float], str]:
        with self.lock:
            fc = copy.deepcopy(self.forecast)
            err = self.forecast_error
            config = copy.deepcopy(self.config)
        if not isinstance(fc, dict):
            return [None] * segment_count, None, "forecast_unavailable" + ((":" + err) if err else "")
        age = max(0.0, time.time() - float(fc.get("received_at") or 0.0))
        if age > float(config.get("forecast_fresh_s") or 1800):
            return [None] * segment_count, age, "forecast_stale"
        rows = fc.get("rows") if isinstance(fc.get("rows"), list) else []
        if not rows:
            return [None] * segment_count, age, "forecast_empty"
        layer = _nearest_layer(agl_m)
        out: List[Optional[Tuple[float, float, Optional[float], int]]] = []
        for i in range(segment_count):
            row = rows[min(i, len(rows)-1)]
            out.append(_hourly_vector(row, layer, arrival_epochs[min(i, len(arrival_epochs)-1)]))
        return out, age, "forecast_fresh"

    def _evaluate(self, snapshot: Dict[str, Any], tau_s: float, config: Dict[str, Any]) -> Dict[str, Any]:
        p = snapshot.get("position") or {}; n = snapshot.get("navigation") or {}; speed = snapshot.get("speed") or {}; batt = snapshot.get("battery") or {}; wind = snapshot.get("wind") or {}
        qualification = snapshot.get("_turn_home_qualification") or {}
        home_lat, home_lon = finite(n.get("home_lat")), finite(n.get("home_lon"))
        smooth, consumed = finite(batt.get("voltage_smooth_v")), finite(batt.get("consumed_mah"))
        current = finite(batt.get("current_a")) or 0.0
        if None in (home_lat, home_lon, smooth, consumed):
            return {"safe": False, "invalid": True, "reason": "essential_battery_or_home_invalid"}
        vlimit = float(config["landing_zero_load_voltage_v"]); mlimit = float(config["max_consumed_mah"])
        qualification_summary = {
            "armed": qualification.get("armed"),
            "on_ground": qualification.get("on_ground"),
            "airborne_qualified": qualification.get("airborne_qualified"),
            "flight_state": qualification.get("flight_state"),
            "flight_qualification_reason": qualification.get("flight_qualification_reason"),
            "credible_motion": qualification.get("credible_motion"),
            "motion_fresh": qualification.get("motion_fresh"),
            "measured_wind_eligible": qualification.get("measured_wind_eligible"),
            "measured_wind_rejection_reason": qualification.get("measured_wind_rejection_reason"),
            "measured_wind_continuous_valid_s": qualification.get("measured_wind_continuous_valid_s"),
            "measured_wind_ramp": qualification.get("measured_wind_ramp"),
            "measured_wind_age_s": qualification.get("measured_wind_age_s"),
            "battery_voltage_margin_now_v": round(smooth - vlimit, 3),
            "battery_capacity_margin_now_mah": round(mlimit - consumed, 1),
        }
        turn, projection = self._project_turn(snapshot, tau_s)
        if turn is None:
            return {"safe": False, "invalid": True, "reason": "turn_projection_invalid"}
        home_dist = haversine_m(turn[0], turn[1], home_lat, home_lon)
        count = int(config["route_sample_points"])
        points = great_circle_points(turn[0], turn[1], home_lat, home_lon, count)
        tas = finite(speed.get("airspeed_m_s")) or finite(speed.get("groundspeed_m_s")) or 0.0
        tas = clamp(tas, 3.0, 80.0)
        return_current = max(0.5, finite(read_json(Path("/var/lib/siyi-user-config/groundstation/telemetry_canvas.json"), {}).get("battery_stabilization", {}).get("normal_cruise_current_a")) or 6.0)
        mission_current = max(0.5, 0.65 * return_current + 0.35 * clamp(current, 0.0, 100.0))
        measured_speed, measured_dir = finite(wind.get("speed_m_s")), finite(wind.get("direction_deg"))
        measured_vec = meteorological_to_motion(measured_speed, measured_dir) if (
            qualification.get("measured_wind_eligible")
            and measured_speed is not None and measured_dir is not None
        ) else None
        measured_ramp = clamp(finite(qualification.get("measured_wind_ramp")) or 0.0, 0.0, 1.0)
        agl = finite(p.get("relative_alt_m")) or 80.0
        # First ETA estimate uses no forecast; iterate up to 3 times as specified.
        segment_dist = home_dist / max(1, count - 1)
        etas = [time.time() + tau_s + (home_dist / max(3.0, tas)) * (i / max(1, count-1)) for i in range(count)]
        fvecs, forecast_age, forecast_status = self._forecast_vectors(count, etas, agl)
        total_return_s = 0.0; segments = []; infeasible = False; avg_tail = 0.0; tail_weight = 0.0
        forecast_e_sum = 0.0; forecast_n_sum = 0.0; forecast_tail_sum = 0.0; forecast_weight = 0.0
        for _iteration in range(3):
            segments = []; elapsed = 0.0; infeasible = False; avg_tail = 0.0; tail_weight = 0.0
            forecast_e_sum = 0.0; forecast_n_sum = 0.0; forecast_tail_sum = 0.0; forecast_weight = 0.0
            for i in range(count - 1):
                a, z = points[i], points[i+1]
                dist = haversine_m(a[0], a[1], z[0], z[1])
                route_b = math.radians(bearing_deg(a[0], a[1], z[0], z[1]))
                route_e, route_n = math.sin(route_b), math.cos(route_b)
                cross_e, cross_n = math.cos(route_b), -math.sin(route_b)
                fv = fvecs[min(i, len(fvecs)-1)] if fvecs else None
                frac = i / max(1, count - 2)
                alpha = (0.85 - 0.70 * frac) * measured_ramp
                if measured_vec is None and fv is None:
                    return {"safe": False, "invalid": True, "reason": "wind_data_unavailable", "projection": projection, "forecast_age_s": forecast_age, "forecast_status": forecast_status, **qualification_summary}

                elif fv is None:
                    used = measured_vec or (0.0, 0.0); alpha = 1.0; source = "measured_only"
                elif measured_vec is None:
                    used = (fv[0], fv[1]); alpha = 0.0; source = "forecast_only"
                else:
                    used = (alpha*measured_vec[0] + (1-alpha)*fv[0], alpha*measured_vec[1] + (1-alpha)*fv[1]); source = "blended"
                tail = used[0]*route_e + used[1]*route_n
                cross = used[0]*cross_e + used[1]*cross_n
                if abs(cross) >= tas:
                    infeasible = True; gs = 0.0
                else:
                    air_along = math.sqrt(max(0.0, tas*tas - cross*cross))
                    gs = air_along + tail
                    if gs < float(config["return_groundspeed_floor_m_s"]):
                        infeasible = True
                if infeasible:
                    seg_s = float("inf")
                else:
                    seg_s = dist / max(0.1, gs)
                elapsed += seg_s
                avg_tail += tail * dist; tail_weight += dist
                if fv is not None:
                    forecast_e_sum += fv[0] * dist
                    forecast_n_sum += fv[1] * dist
                    forecast_tail_sum += (fv[0] * route_e + fv[1] * route_n) * dist
                    forecast_weight += dist
                segments.append({
                    "index": i,
                    "from": {"lat": round(a[0], 6), "lon": round(a[1], 6)},
                    "to": {"lat": round(z[0], 6), "lon": round(z[1], 6)},
                    "distance_m": round(dist,1), "eta_epoch": etas[i],
                    "altitude_layer_m": fv[3] if fv else None,
                    "blend_alpha_measured": round(alpha,3), "wind_source": source,
                    "measured_wind_east_m_s": round(measured_vec[0],3) if measured_vec else None,
                    "measured_wind_north_m_s": round(measured_vec[1],3) if measured_vec else None,
                    "forecast_wind_east_m_s": round(fv[0],3) if fv else None,
                    "forecast_wind_north_m_s": round(fv[1],3) if fv else None,
                    "used_wind_east_m_s": round(used[0],3),
                    "used_wind_north_m_s": round(used[1],3),
                    "tailwind_m_s": round(tail,3), "crosswind_m_s": round(cross,3),
                    "groundspeed_m_s": round(gs,3) if math.isfinite(gs) else None,
                    "duration_s": round(seg_s,2) if math.isfinite(seg_s) else None,
                    "gust_m_s": fv[2] if fv else None,
                })
                if infeasible:
                    break
            if infeasible:
                break
            new_etas = [time.time() + tau_s]
            running = 0.0
            for seg in segments:
                running += float(seg["duration_s"] or 0.0)
                new_etas.append(time.time() + tau_s + running)
            delta = max(abs(new_etas[i]-etas[i]) for i in range(min(len(new_etas),len(etas))))
            etas = new_etas
            total_return_s = running
            if delta < 10.0:
                break
            fvecs, forecast_age, forecast_status = self._forecast_vectors(count, etas, agl)
        forecast_speed = None; forecast_from = None; forecast_headwind = None
        if forecast_weight > 0.0:
            forecast_e = forecast_e_sum / forecast_weight
            forecast_n = forecast_n_sum / forecast_weight
            forecast_speed, forecast_from = motion_to_meteorological(forecast_e, forecast_n)
            forecast_headwind = -(forecast_tail_sum / forecast_weight)
        with self.lock:
            forecast_snapshot_id = (self.forecast or {}).get("snapshot_id") if isinstance(self.forecast, dict) else None
        forecast_summary = {
            "forecast_snapshot_id": forecast_snapshot_id,
            "forecast_wind_speed_m_s": round(forecast_speed,3) if forecast_speed is not None else None,
            "forecast_wind_from_deg_true": round(forecast_from,1) if forecast_from is not None else None,
            "forecast_effective_headwind_m_s": round(forecast_headwind,3) if forecast_headwind is not None else None,
        }
        if infeasible:
            valid_groundspeeds = [finite(item.get("groundspeed_m_s")) for item in segments]
            valid_groundspeeds = [value for value in valid_groundspeeds if value is not None]
            return {"safe": False, "invalid": False, "reason": "wind_infeasible", "projection": projection, "forecast_age_s": forecast_age, "forecast_status": forecast_status, "measured_wind_valid": measured_vec is not None, "measured_wind_blend_weight": round(max((finite(item.get("blend_alpha_measured")) or 0.0) for item in segments), 3) if segments else 0.0, "return_feasible": False, "return_groundspeed_min_m_s": round(min(valid_groundspeeds), 3) if valid_groundspeeds else 0.0, **qualification_summary, **forecast_summary, "route_points": [{"lat": round(x[0],6), "lon": round(x[1],6)} for x in points], "segments": segments}
        return_mah = return_current * total_return_s / 3600.0 * 1000.0
        mission_mah = mission_current * tau_s / 3600.0 * 1000.0
        landing_mah = consumed + mission_mah + return_mah
        slope, slope_source = self._voltage_slope_v_per_mah(snapshot, config)
        added_mah = mission_mah + return_mah
        landing_v = smooth - slope * added_mah if slope > 0 else smooth
        voltage_ok = landing_v >= vlimit
        capacity_ok = landing_mah <= mlimit
        return_rate_mah_s = return_current * 1000.0 / 3600.0
        capacity_available_s = (mlimit - consumed) / max(0.000001, return_rate_mah_s)
        if slope > 0:
            voltage_available_s = ((smooth - vlimit) / slope) / max(0.000001, return_rate_mah_s)
        else:
            voltage_available_s = float("inf") if smooth >= vlimit else 0.0
        return_available_s = min(capacity_available_s, voltage_available_s)
        landing_margin_s = return_available_s - total_return_s
        controlling = "VOLTAGE" if voltage_available_s <= capacity_available_s else "CAPACITY"

        # When direct return is already late, estimate where the first configured
        # landing limit is reached by walking the wind-aware return segments.
        # This remains advisory data only and never commands a landing or RTL.
        usable_return_s = max(0.0, min(total_return_s, return_available_s))
        covered_m = 0.0
        remaining_s = usable_return_s
        for segment in segments:
            duration_s = finite(segment.get("duration_s")) or 0.0
            distance_m = finite(segment.get("distance_m")) or 0.0
            if duration_s <= 0:
                covered_m += distance_m
                continue
            if remaining_s >= duration_s:
                covered_m += distance_m
                remaining_s -= duration_s
            else:
                covered_m += distance_m * clamp(remaining_s / duration_s, 0.0, 1.0)
                break
        emergency_shortfall_m = max(0.0, home_dist - covered_m) if landing_margin_s < 0 else 0.0
        valid_groundspeeds = [finite(item.get("groundspeed_m_s")) for item in segments]
        valid_groundspeeds = [value for value in valid_groundspeeds if value is not None]
        return {"safe": bool(voltage_ok and capacity_ok), "invalid": False, "projection": projection, "turn_position": {"lat": turn[0], "lon": turn[1]}, "route_points": [{"lat": round(x[0],6), "lon": round(x[1],6)} for x in points], "direct_distance_m": round(home_dist,1), "return_eta_s": round(total_return_s,1), "return_current_a": round(return_current,2), "mission_current_a": round(mission_current,2), "return_mah": round(return_mah,1), "mission_mah": round(mission_mah,1), "projected_landing_mah": round(landing_mah,1), "capacity_limit_mah": mlimit, "projected_landing_zero_load_v": round(landing_v,3), "voltage_limit_v": vlimit, "projected_voltage_margin_v": round(landing_v - vlimit, 3), "projected_capacity_margin_mah": round(mlimit - landing_mah, 1), "voltage_slope_v_per_mah": slope, "voltage_slope_source": slope_source, "capacity_available_return_s": round(capacity_available_s,1), "voltage_available_return_s": round(voltage_available_s,1) if math.isfinite(voltage_available_s) else None, "landing_margin_s": round(landing_margin_s,1), "emergency_landing_required": bool(landing_margin_s < 0), "emergency_landing_distance_from_home_m": round(emergency_shortfall_m,1), "controlling_limit": controlling, "forecast_age_s": forecast_age, "forecast_status": forecast_status, **forecast_summary, **qualification_summary, "measured_wind_valid": measured_vec is not None, "measured_wind_blend_weight": round(max((finite(item.get("blend_alpha_measured")) or 0.0) for item in segments), 3) if segments else 0.0, "return_feasible": True, "return_groundspeed_min_m_s": round(min(valid_groundspeeds), 3) if valid_groundspeeds else None, "forecast_anchor_tau_s": round(self.forecast_anchor_tau_s,1), "average_return_tailwind_m_s": round(avg_tail/max(1.0,tail_weight),3), "segments": segments}

    def update(self, snapshot: Dict[str, Any]) -> Dict[str, Any]:
        config = self.read_config()
        now_m = time.monotonic()
        self._record_battery_sample(snapshot)
        qualification = self._flight_wind_qualification(snapshot, now_m)
        solver_snapshot = copy.deepcopy(snapshot)
        solver_snapshot["_turn_home_qualification"] = qualification
        if not config.get("enabled"):
            result = self._unavailable("disabled")
        elif float(config.get("landing_zero_load_voltage_v") or 0.0) <= 0 or float(config.get("max_consumed_mah") or 0.0) <= 0:
            result = self._unavailable("landing_limits_not_configured")
        elif not qualification.get("airborne_qualified"):
            result = self._unavailable(str(qualification.get("flight_qualification_reason") or "airborne_qualification_pending"))
            result.update(qualification)
        else:
            if self._forecast_refresh_needed(now_m):
                self._kick_forecast_refresh(snapshot, now_m)
            b = snapshot.get("battery") or {}; n = snapshot.get("navigation") or {}; p = snapshot.get("position") or {}
            if None in (finite(b.get("voltage_smooth_v")), finite(b.get("consumed_mah")), finite(n.get("home_lat")), finite(n.get("home_lon")), finite(p.get("lat")), finite(p.get("lon"))):
                result = self._unavailable("essential_telemetry_invalid")
            else:
                # Bound endurance search using remaining capacity at configured cruise current, max 2h.
                current_mah = finite(b.get("consumed_mah")) or 0.0
                bc = read_json(Path("/var/lib/siyi-user-config/groundstation/telemetry_canvas.json"), {}).get("battery_stabilization", {})
                cruise = max(0.5, finite((bc or {}).get("normal_cruise_current_a")) or 6.0)
                cap_left = max(0.0, float(config["max_consumed_mah"]) - current_mah)
                hi = min(7200.0, cap_left / cruise * 3.6)
                zero = self._evaluate(solver_snapshot, 0.0, config)
                if zero.get("invalid"):
                    result = self._unavailable(str(zero.get("reason") or "invalid"))
                elif not zero.get("safe"):
                    margin_s = finite(zero.get("landing_margin_s"))
                    if margin_s is not None:
                        sec = min(-1, int(math.floor(margin_s)))
                        minutes = int(math.floor(sec / 60.0))
                        result = {
                            **zero, "valid": True, "seconds": sec, "minutes": minutes,
                            "display": f"TURN HOME {minutes}m", "telemetry_value": f"{minutes}m",
                            "reason": "return_energy_shortfall", "overdue_seconds": abs(sec),
                            "confidence": "FULL" if (
                                str(zero.get("forecast_status") or "") == "forecast_fresh"
                                and bool(zero.get("measured_wind_valid"))
                                and float(zero.get("measured_wind_ramp") or 0.0) >= 0.999
                            ) else "DEGRADED",
                            "provider": "open_meteo", "updated_at": time.time(),
                        }
                    else:
                        result = {**zero, "valid": True, "seconds": 0, "minutes": 0, "display": "TURN HOME NOW", "telemetry_value": "NOW", "confidence": "FULL" if (
                            str(zero.get("forecast_status") or "") == "forecast_fresh"
                            and bool(zero.get("measured_wind_valid"))
                            and float(zero.get("measured_wind_ramp") or 0.0) >= 0.999
                        ) else "DEGRADED", "provider": "open_meteo", "updated_at": time.time()}
                else:
                    lo = 0.0
                    for _ in range(18):
                        mid = (lo + hi) / 2.0
                        ev = self._evaluate(solver_snapshot, mid, config)
                        if ev.get("safe"):
                            lo = mid
                        else:
                            hi = mid
                    final = self._evaluate(solver_snapshot, lo, config)
                    sec = max(0, int(round(lo)))
                    minutes = int(math.floor(sec/60.0 + 1e-9))
                    fstatus = str(final.get("forecast_status") or "")
                    anchor_delta = abs(float(final.get("forecast_anchor_tau_s") or 0.0) - float(sec))
                    confidence = "FULL" if (
                        fstatus == "forecast_fresh" and bool(final.get("measured_wind_valid"))
                        and float(final.get("measured_wind_ramp") or 0.0) >= 0.999
                        and anchor_delta <= 120.0
                        and "degraded" not in str(final.get("projection") or "")
                        and "fallback" not in str(final.get("projection") or "")
                    ) else "DEGRADED"
                    with self.lock:
                        forecast_meta = copy.deepcopy(self.forecast) if isinstance(self.forecast, dict) else {}
                    result = {
                        **final, "valid": True, "seconds": sec, "minutes": minutes,
                        "display": f"TURN HOME {minutes}m" if sec > 0 else "TURN HOME NOW",
                        "telemetry_value": f"{minutes}m" if sec > 0 else "NOW",
                        "confidence": confidence, "provider": "open_meteo",
                        "forecast_error": self.forecast_error,
                        "forecast_route_anchor_delta_s": round(anchor_delta,1),
                        "forecast_source_host": forecast_meta.get("url_host"),
                        "forecast_model": forecast_meta.get("models"),
                        "updated_at": time.time(),
                    }
                    # The first forecast is normally anchored near tau=0. Once the
                    # solver has a materially different latest-safe turn time, trigger
                    # one prompt asynchronous re-sample along that future route.
                    if fstatus == "forecast_fresh" and anchor_delta > 120.0 and now_m - self.last_anchor_refine_m > 60.0:
                        self.last_anchor_refine_m = now_m
                        with self.lock:
                            self.next_forecast_m = 0.0
        # Explicit advisory-only API invariant for UI/logging/tests.
        battery = snapshot.get("battery") or {}
        smooth = finite(battery.get("voltage_smooth_v"))
        consumed = finite(battery.get("consumed_mah"))
        if smooth is not None:
            result.setdefault("battery_voltage_margin_now_v", round(smooth - float(config.get("landing_zero_load_voltage_v") or 0.0), 3))
        if consumed is not None:
            result.setdefault("battery_capacity_margin_now_mah", round(float(config.get("max_consumed_mah") or 0.0) - consumed, 1))
        for key, value in qualification.items():
            result.setdefault(key, value)
        result["flight_control_effect"] = "none"
        with self.lock:
            forecast_meta = copy.deepcopy(self.forecast) if isinstance(self.forecast, dict) else {}
            result.setdefault("forecast_snapshot_id", forecast_meta.get("snapshot_id"))
            result.setdefault("forecast_source_host", forecast_meta.get("url_host"))
            result.setdefault("forecast_model", forecast_meta.get("models"))
            self.last_result = result
        return copy.deepcopy(result)


class LTEHealthEngine:
    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.config = normalize_lte(read_json(LTE_CONFIG, LTE_DEFAULT))
        self.session = ""
        self.samples: deque = deque(maxlen=8)
        self.current_state = "UNKNOWN"
        self.pending_state: Optional[str] = None
        self.pending_count = 0
        self.last_success = 0.0
        self.last_poll_m = 0.0
        self.last_context_m = 0.0
        self.last_mode_m = 0.0
        self.context: Dict[str, Any] = {}
        self.last_error = ""
        self.last_result = {"valid": False, "display": "LTE UNKNOWN", "telemetry_value": "UNKNOWN", "state": "UNKNOWN", "signal_dbm": None, "age_s": None, "updated_at": time.time(), "flight_control_effect": "none"}

    def read_config(self) -> Dict[str, Any]:
        with self.lock:
            self.config = normalize_lte(read_json(LTE_CONFIG, self.config))
            return copy.deepcopy(self.config)

    def write_config(self, value: Any, password: Optional[str] = None) -> Dict[str, Any]:
        cfg = normalize_lte(value)
        atomic_json(LTE_CONFIG, cfg, 0o640)
        if password is not None:
            pw = str(password)
            if len(pw) > 256:
                raise ValueError("router password too long")
            atomic_json(LTE_SECRET, {"password": pw}, 0o600)
        with self.lock:
            self.config = cfg; self.session = ""; self.samples.clear(); self.current_state = "UNKNOWN"; self.last_poll_m = 0.0
        return copy.deepcopy(cfg)

    def safe_config(self) -> Dict[str, Any]:
        cfg = self.read_config(); secret = read_json(LTE_SECRET, {})
        return {**cfg, "password_configured": bool(str(secret.get("password") or ""))}

    def snapshot(self) -> Dict[str, Any]:
        with self.lock:
            out = copy.deepcopy(self.last_result)
        age = max(0.0, time.time() - self.last_success) if self.last_success else None
        out["age_s"] = round(age, 2) if age is not None else None
        cfg = self.read_config()
        if age is None or age > float(cfg["stale_s"]):
            out.update({"valid": False, "state": "UNKNOWN", "display": "LTE UNKNOWN", "telemetry_value": "UNKNOWN"})
        return out

    @staticmethod
    def _gateway_auto() -> str:
        try:
            for line in Path("/proc/net/route").read_text().splitlines()[1:]:
                cols = line.split()
                if len(cols) >= 3 and cols[1] == "00000000":
                    raw = int(cols[2], 16)
                    return socket.inet_ntoa(raw.to_bytes(4, "little"))
        except Exception:
            pass
        return "192.168.100.1"

    def _gateway(self, cfg: Dict[str, Any]) -> str:
        g = str(cfg.get("gateway") or "auto").strip()
        return self._gateway_auto() if g.lower() == "auto" else g

    def _post(self, gateway: str, body: Dict[str, Any], session: str = "") -> Dict[str, Any]:
        raw = json.dumps(body, separators=(",", ":")).encode("utf-8")
        headers = {"Content-Type": "application/json;charset=UTF-8", "Accept": "application/json", "User-Agent": "FlightCore-RC8-LTE/4.3.0"}
        if session:
            headers["Authorization"] = session
        req = urllib.request.Request(f"http://{gateway}/himiapi/json", data=raw, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=3.0) as r:
            reply = r.read(512 * 1024)
        value = json.loads(reply.decode("utf-8"))
        if not isinstance(value, dict):
            raise RuntimeError("router returned non-object JSON")
        return value

    def _login(self, cfg: Dict[str, Any], gateway: str) -> str:
        secret = read_json(LTE_SECRET, {})
        password = str(secret.get("password") or "")
        if not password:
            raise RuntimeError("router credential not configured")
        value = self._post(gateway, {"cmdid": "login", "username": str(cfg["username"]), "password": password, "sessionId": None})
        if str(value.get("reply") or "").lower() != "ok" or not value.get("session"):
            raise RuntimeError("router authentication failed")
        return str(value["session"])

    def _command(self, cfg: Dict[str, Any], command: str) -> Dict[str, Any]:
        gateway = self._gateway(cfg)
        if not self.session:
            self.session = self._login(cfg, gateway)
        value = self._post(gateway, {"cmdid": command, "sessionId": self.session}, self.session)
        if str(value.get("reply") or "") == "SessionOut":
            self.session = self._login(cfg, gateway)
            value = self._post(gateway, {"cmdid": command, "sessionId": self.session}, self.session)
        if str(value.get("reply") or "").lower() not in {"ok", "success"}:
            # Some HiMILink variants return fields directly without an explicit reply=ok.
            if command == "getallstatus" and "signalStrength" in value:
                return value
            raise RuntimeError(f"router {command} failed: {str(value.get('reply') or 'unknown')[:60]}")
        return value

    @staticmethod
    def _data(value: Dict[str, Any]) -> Dict[str, Any]:
        # HiMILink/UFI firmware returns successful command payloads inside
        # {"reply":"ok", "params":{...}}.  V81 omitted this canonical wrapper
        # and therefore treated authenticated replies as empty LTE data.
        for key in ("params", "data", "result", "message"):
            if isinstance(value.get(key), dict):
                return value[key]
        return value

    def _hysteresis(self, filtered: float, raw_state: str) -> str:
        if raw_state in {"CRITICAL", "UNKNOWN"}:
            self.current_state = raw_state; self.pending_state = None; self.pending_count = 0; return raw_state
        cur = self.current_state
        if cur == "UNKNOWN":
            self.current_state = raw_state; return raw_state
        if raw_state == cur:
            self.pending_state = None; self.pending_count = 0; return cur
        # Require 2 dB recovery/degradation beyond vendor boundary, two filtered samples.
        ranges = {"EXCELLENT": (-95, 999), "GOOD": (-102, -96), "WEAK": (-108, -103), "CRITICAL": (-120, -109)}
        order = ["CRITICAL", "WEAK", "GOOD", "EXCELLENT"]
        ci, ri = order.index(cur) if cur in order else 0, order.index(raw_state) if raw_state in order else 0
        boundary_ok = True
        if ri > ci:  # improving
            threshold = {"WEAK": -106, "GOOD": -100, "EXCELLENT": -93}.get(raw_state, -999)
            boundary_ok = filtered >= threshold
        elif ri < ci:  # degrading
            threshold = {"CRITICAL": -111, "WEAK": -105, "GOOD": -98}.get(raw_state, 999)
            boundary_ok = filtered <= threshold
        if not boundary_ok:
            return cur
        if self.pending_state == raw_state:
            self.pending_count += 1
        else:
            self.pending_state = raw_state; self.pending_count = 1
        if self.pending_count >= 2:
            self.current_state = raw_state; self.pending_state = None; self.pending_count = 0
        return self.current_state

    def poll(self) -> Dict[str, Any]:
        cfg = self.read_config(); now_m = time.monotonic()
        if not cfg.get("enabled"):
            with self.lock:
                self.last_result = {"valid": False, "state": "UNKNOWN", "display": "LTE UNKNOWN", "telemetry_value": "UNKNOWN", "reason": "disabled", "flight_control_effect": "none", "updated_at": time.time()}
            return self.snapshot()
        if now_m - self.last_poll_m < float(cfg["poll_s"]):
            return self.snapshot()
        self.last_poll_m = now_m
        try:
            raw = self._data(self._command(cfg, "getallstatus"))
            # A reply=ok is transport/authentication success, not a usable LTE
            # sample.  Do not refresh last_success unless the router supplied at
            # least one actual cellular status value.
            cellular_keys = ("signalStrength", "internetState", "simCardState", "carrier")
            if not any(raw.get(key) not in (None, "") for key in cellular_keys):
                raise RuntimeError("router status missing cellular fields")
            signal = finite(raw.get("signalStrength"))
            internet = str(raw.get("internetState") or "").strip().lower()
            sim = str(raw.get("simCardState") or "").strip().lower()
            carrier = str(raw.get("carrier") or "")[:80]
            if signal is None or signal > -44 or signal < -120:
                state = "UNKNOWN"; filtered = None
            else:
                self.samples.append((time.time(), signal))
                filtered = float(statistics.median([x[1] for x in list(self.samples)[-3:]]))
                state = classify_lte(filtered)
            if sim and sim != "ok":
                state = "CRITICAL"
            if internet and internet != "connected":
                state = "CRITICAL"
            if filtered is not None:
                state = self._hysteresis(filtered, state)
            else:
                self.current_state = "UNKNOWN"
            if now_m - self.last_context_m >= float(cfg["context_poll_s"]):
                self.last_context_m = now_m
                try:
                    self.context.update(self._data(self._command(cfg, "getsysinfo")))
                except Exception:
                    pass
            if now_m - self.last_mode_m >= float(cfg["network_mode_poll_s"]):
                self.last_mode_m = now_m
                try:
                    self.context.update(self._data(self._command(cfg, "getnetworkmode")))
                except Exception:
                    pass
            trend = ""
            if len(self.samples) >= 2:
                old = min(self.samples, key=lambda x: abs((time.time()-10.0)-x[0]))
                delta = signal - old[1]
                trend = "up" if delta >= 4 else "down" if delta <= -4 else ""
            display = "LTE " + state + (" ↑" if trend == "up" else " ↓" if trend == "down" else "")
            self.last_success = time.time(); self.last_error = ""
            result = {"valid": state != "UNKNOWN", "state": state, "display": display, "telemetry_value": state + (" ↑" if trend == "up" else " ↓" if trend == "down" else ""), "signal_dbm": round(signal,1) if signal is not None else None, "filtered_signal_dbm": round(filtered,1) if filtered is not None else None, "signal_source": "signalStrength", "signal_primitive": "vendor_cellular_dbm", "internet_state": internet or None, "sim_state": sim or None, "carrier": carrier or None, "network_mode": "4G" if str(self.context.get("netmode")) == "1" else self.context.get("netmode"), "cell_id": self.context.get("cellid"), "bs_id": self.context.get("bsid"), "trend": trend or "stable", "reason": None if state != "UNKNOWN" else "router signal unavailable", "updated_at": self.last_success, "flight_control_effect": "none"}
            with self.lock:
                self.last_result = result
        except Exception as exc:
            self.last_error = str(exc)[:300]
            with self.lock:
                self.last_result = {**self.last_result, "valid": False, "state": "UNKNOWN", "display": "LTE UNKNOWN", "telemetry_value": "UNKNOWN", "reason": self.last_error, "updated_at": time.time(), "flight_control_effect": "none"}
        return self.snapshot()


class FeatureManager:
    """Low-rate advisory workers, isolated from MAVLink/control and from each other."""
    def __init__(self, base_snapshot_callable, publish_callable=None) -> None:
        self.base_snapshot_callable = base_snapshot_callable
        self.publish_callable = publish_callable
        self.turn_home = TurnHomeEngine()
        self.lte = LTEHealthEngine()
        self.stop_event = threading.Event()
        self.publish_lock = threading.Lock()
        self.turn_thread = threading.Thread(target=self._turn_loop, name="fc8-turn-home", daemon=True)
        self.lte_thread = threading.Thread(target=self._lte_loop, name="fc8-lte-health", daemon=True)
        self.turn_thread.start(); self.lte_thread.start()

    def _publish(self) -> None:
        if self.publish_callable is None:
            return
        if not self.publish_lock.acquire(blocking=False):
            return
        try:
            self.publish_callable(self.state())
        except Exception:
            pass
        finally:
            self.publish_lock.release()

    def _turn_loop(self) -> None:
        while not self.stop_event.is_set():
            started = time.monotonic()
            try:
                snapshot = self.base_snapshot_callable(False)
                self.turn_home.update(snapshot)
            except Exception as exc:
                with self.turn_home.lock:
                    self.turn_home.last_result = self.turn_home._unavailable("worker:" + str(exc)[:120])
            self._publish()
            elapsed = time.monotonic() - started
            self.stop_event.wait(max(0.1, 1.0 - min(0.9, elapsed)))

    def _lte_loop(self) -> None:
        while not self.stop_event.is_set():
            try:
                self.lte.poll()
            except Exception:
                pass
            self._publish()
            self.stop_event.wait(0.5)

    def stop(self) -> None:
        self.stop_event.set()
        self.turn_thread.join(timeout=2.0); self.lte_thread.join(timeout=2.0)

    def state(self) -> Dict[str, Any]:
        return {
            "turn_home": self.turn_home.snapshot(),
            "turn_home_config": self.turn_home.read_config(),
            "lte_health": self.lte.snapshot(),
        }
