# FlightCore 4.3.0 RC16

Canonical machine identity: `4.3.0-rc.16`.

RC16 corrects three confirmed defects without adding flight-control authority:

- TURN HOME remains inactive while disarmed or on the ground, and measured flight-controller wind is accepted only after fresh, plausible airborne motion and continuous wind qualification. A five-second airborne qualification, eight-second wind qualification and twelve-second blend ramp prevent ground wind from producing a false `NOW`; a genuine airborne infeasible return still reports `NOW`.
- TURN HOME diagnostics and flight logs now expose flight state, wind eligibility/rejection, blend, confidence, return feasibility, minimum groundspeed and independent voltage/capacity margins.
- ARSP Health is selectable through the normal Ground Station telemetry-value framework. The duplicate top-bar ARSP pill is removed while detection, polling, voice transitions and saved telemetry layouts remain intact.
- Native upgrades retain the ownership-aware live release fingerprint check and no longer reject an otherwise valid installed source by comparing it with an offline `--skip-ownership` digest. Exact source identity, build, status, manifest and controlled-file hashes remain enforced.

RC14 release discovery/installer-integrity corrections and RC15 SIYI cold-boot/stream-recovery corrections remain intact. RC16 changes no user settings, defaults, migrations, preservation rules, LTE Health, Smooth Voltage, battery-series selection or flight-control authority.
