#!/usr/bin/env python3
import argparse, json, os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
HTML = b'<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><title>FlightCore Installation</title><style>body{font-family:Arial,sans-serif;background:#0b1220;color:#e5e7eb;margin:0;padding:24px}.card{max-width:760px;margin:auto;background:#111827;border:1px solid #334155;border-radius:14px;padding:22px}h1{margin-top:0}.bar{height:16px;background:#1f2937;border-radius:999px;overflow:hidden}.fill{height:100%;background:#38bdf8;width:0;transition:width .3s}.stage{font-size:18px;margin:16px 0}.muted{color:#94a3b8}.bad{color:#fca5a5}.ok{color:#86efac}pre{white-space:pre-wrap;max-height:360px;overflow:auto}</style></head><body><div class="card"><h1>FlightCore installation</h1><div class="bar"><div class="fill" id="fill"></div></div><div class="stage" id="stage">Starting...</div><div id="pct">0%</div><p class="muted" id="status">This page follows the deterministic installer. Runtime and aircraft settings are configured after reboot in Setup Wizard.</p><details><summary>Technical details</summary><pre id="detail"></pre></details></div><script>async function tick(){try{const r=await fetch(\'/state?ts=\'+Date.now(),{cache:\'no-store\'}),s=await r.json();const p=Math.max(0,Math.min(100,Number(s.progress)||0));document.getElementById(\'fill\').style.width=p+\'%\';document.getElementById(\'pct\').textContent=Math.round(p)+\'%\';document.getElementById(\'stage\').textContent=s.stage||s.status||\'Installing\';const st=document.getElementById(\'status\');st.className=s.status===\'failed\'?\'bad\':(s.status===\'restarting\'||s.status===\'complete\'?\'ok\':\'muted\');st.textContent=s.error||(s.status===\'restarting\'?\'Installation complete. The Pi is restarting; open the normal FlightCore UI after it returns.\':\'Installation in progress.\');document.getElementById(\'detail\').textContent=s.log_tail||\'\';}catch(e){const st=document.getElementById(\'status\');st.className=\'muted\';st.textContent=\'Waiting for installer state...\';}setTimeout(tick,1000)}tick()</script></body></html>'
class H(BaseHTTPRequestHandler):
    state=Path('/run/flightcore-installer-ui/state.json')
    def log_message(self,*a): pass
    def sendb(self,code,typ,data):
        self.send_response(code); self.send_header('Content-Type',typ); self.send_header('Cache-Control','no-store'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        if self.path.startswith('/state'):
            try:
                obj=json.loads(self.state.read_text()); log=obj.get('log_path') or ''; obj['log_tail']=''
            except Exception:
                obj={'status':'starting','progress':0,'stage':'Waiting for installer'}; log=''
            try:
                if log and os.path.isfile(log): obj['log_tail']=''.join(Path(log).read_text(errors='replace').splitlines(True)[-80:])
            except Exception: pass
            return self.sendb(200,'application/json; charset=utf-8',(json.dumps(obj)+'\n').encode())
        return self.sendb(200,'text/html; charset=utf-8',HTML)
if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--port',type=int,default=8090); args=ap.parse_args(); ThreadingHTTPServer(('0.0.0.0',args.port),H).serve_forever()
