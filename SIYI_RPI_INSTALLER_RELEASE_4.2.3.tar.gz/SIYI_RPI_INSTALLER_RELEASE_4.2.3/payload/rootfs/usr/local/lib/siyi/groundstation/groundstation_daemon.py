#!/usr/bin/env python3
"""SIYI Ground Station read-only telemetry daemon.

Receives MAVLink from the dedicated mavlink-router UDP endpoint, maintains a
normalized state model, and exposes a loopback-only JSON/SSE interface for the
existing WebUI. This first live patch is deliberately monitor-only.
"""

# GROUND_STATION_CANONICAL_QGC_TELEMETRY_OVERHAUL_V4_1_0
# SIYI_4_2_2_TELEMETRY_WIND_AND_VOLTAGE_V1
# SIYI_4_2_2_RC2_WIND_LEGACY_SEMANTICS_AND_SPEED_V1
# SIYI_4_2_2_RC2_RESTING_VOLTAGE_TRACKER_V1
# SIYI_4_2_2_RC6_BATTERY_PERCENT_V1
# SIYI_4_2_2_RC12_GROUNDSTATION_LOAD_BOUNDS_V1
# FLIGHTCORE_4_2_3_RC3_RELAXED_VOLTAGE_ESTIMATOR_V1

from __future__ import annotations

import copy
import json
import math
import os
import threading
import time
from collections import deque
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Optional, Set, Tuple
from urllib.parse import parse_qs, urlparse

from pymavlink import mavutil

CONFIG_PATH = Path("/etc/siyi/groundstation.json")

TELEMETRY_LAYOUT_PATH = Path("/var/lib/siyi-user-config/groundstation/telemetry_canvas.json")
TELEMETRY_LAYOUT_SHADOW_PATH = Path("/home/pi/.config/siyi/telemetry_canvas.json")
TELEMETRY_LAYOUT_SCHEMA_VERSION = 1

NORMALIZED_TELEMETRY_FIELDS = [
    {"key": "norm.speed.groundspeed_kmh", "label": "Ground Speed", "unit": "km/h", "path": ["speed", "groundspeed_m_s"], "multiplier": 3.6, "digits": 1, "age_key": "speed", "category": "Flight"},
    {"key": "norm.speed.airspeed_kmh", "label": "Air Speed", "unit": "km/h", "path": ["speed", "airspeed_m_s"], "multiplier": 3.6, "digits": 1, "age_key": "speed", "category": "Flight"},
    {"key": "norm.position.relative_alt_m", "label": "Alt (Rel)", "unit": "m", "path": ["position", "relative_alt_m"], "digits": 1, "age_key": "position", "category": "Flight"},
    {"key": "norm.position.amsl_alt_m", "label": "Alt (AMSL)", "unit": "m", "path": ["position", "amsl_alt_m"], "digits": 1, "age_key": "position", "category": "Flight"},
    {"key": "norm.navigation.home_distance_m", "label": "Distance to Home", "unit": "m", "path": ["navigation", "home_distance_m"], "digits": 0, "age_key": "position", "category": "Navigation"},
    {"key": "norm.navigation.distance_to_waypoint_m", "label": "Distance to Waypoint", "unit": "m", "path": ["navigation", "distance_to_waypoint_m"], "digits": 0, "age_key": "navigation", "category": "Navigation"},
    {"key": "norm.navigation.flight_distance_m", "label": "Flight Distance", "unit": "m", "path": ["navigation", "flight_distance_m"], "digits": 0, "age_key": "position", "category": "Flight"},
    {"key": "norm.timers.flight_time_text", "label": "Flight Time", "unit": "", "path": ["timers", "flight_time_text"], "age_key": "heartbeat", "category": "Flight"},
    {"key": "norm.timers.local_time_text", "label": "Time", "unit": "", "path": ["timers", "local_time_text"], "age_key": "heartbeat", "category": "Flight"},
    {"key": "norm.speed.vertical_speed_m_s", "label": "Vertical Speed", "unit": "m/s", "path": ["speed", "vertical_speed_m_s"], "digits": 1, "age_key": "speed", "category": "Flight"},
    {"key": "norm.speed.throttle_pct", "label": "Throttle %", "unit": "%", "path": ["speed", "throttle_pct"], "digits": 0, "age_key": "speed", "category": "Flight"},
    {"key": "norm.attitude.heading_deg", "label": "Heading", "unit": "deg", "path": ["attitude", "heading_deg"], "digits": 0, "age_key": "attitude", "category": "Attitude"},
    {"key": "norm.position.ground_course_deg", "label": "Course Over Ground", "unit": "deg", "path": ["position", "ground_course_deg"], "digits": 0, "age_key": "position", "category": "Navigation"},
    {"key": "norm.attitude.roll_deg", "label": "Roll", "unit": "deg", "path": ["attitude", "roll_deg"], "digits": 1, "age_key": "attitude", "category": "Attitude"},
    {"key": "norm.attitude.pitch_deg", "label": "Pitch", "unit": "deg", "path": ["attitude", "pitch_deg"], "digits": 1, "age_key": "attitude", "category": "Attitude"},
    {"key": "norm.position.latitude", "label": "Latitude", "unit": "deg", "path": ["position", "lat"], "digits": 6, "age_key": "position", "category": "Navigation"},
    {"key": "norm.position.longitude", "label": "Longitude", "unit": "deg", "path": ["position", "lon"], "digits": 6, "age_key": "position", "category": "Navigation"},
    {"key": "norm.battery.voltage_v", "label": "Raw Voltage", "unit": "V", "path": ["battery", "voltage_v"], "digits": 2, "age_key": "battery", "category": "Battery"},
    {"key": "norm.battery.voltage_smooth_v", "label": "Smooth Voltage", "unit": "V", "path": ["battery", "voltage_smooth_v"], "digits": 2, "age_key": "battery", "category": "Battery", "renderer": "smooth_voltage"},
    {"key": "norm.battery.estimated_pct", "label": "Battery %", "unit": "%", "path": ["battery", "estimated_pct"], "digits": 0, "age_key": "battery", "category": "Battery", "renderer": "battery_percent"},
    {"key": "norm.battery.current_a", "label": "Current", "unit": "A", "path": ["battery", "current_a"], "digits": 1, "age_key": "battery", "category": "Battery"},
    {"key": "norm.battery.consumed_mah", "label": "Consumed", "unit": "mAh", "path": ["battery", "consumed_mah"], "digits": 0, "age_key": "battery", "category": "Battery"},
    {"key": "norm.battery.remaining_pct", "label": "Battery Remaining", "unit": "%", "path": ["battery", "remaining_pct"], "digits": 0, "age_key": "battery", "category": "Battery"},
    {"key": "norm.gps.fix", "label": "GPS Fix", "unit": "", "path": ["gps", "fix"], "age_key": "gps", "category": "GPS"},
    {"key": "norm.gps.fix_type", "label": "GPS Fix Type", "unit": "", "path": ["gps", "fix_type"], "digits": 0, "age_key": "gps", "category": "GPS"},
    {"key": "norm.gps.satellites", "label": "GPS Sats", "unit": "", "path": ["gps", "satellites"], "digits": 0, "age_key": "gps", "category": "GPS"},
    {"key": "norm.gps.hdop", "label": "GPS HDOP", "unit": "", "path": ["gps", "hdop"], "digits": 2, "age_key": "gps", "category": "GPS"},
    {"key": "norm.navigation.home_bearing_deg", "label": "Home Bearing", "unit": "deg", "path": ["navigation", "home_bearing_deg"], "digits": 0, "age_key": "position", "category": "Navigation"},
    {"key": "norm.navigation.waypoint_current", "label": "Current Waypoint", "unit": "", "path": ["navigation", "waypoint_current"], "digits": 0, "age_key": "navigation", "category": "Navigation"},
    {"key": "norm.navigation.target_bearing_deg", "label": "Target Bearing", "unit": "deg", "path": ["navigation", "target_bearing_deg"], "digits": 0, "age_key": "navigation", "category": "Navigation"},
    # SIYI_4_2_0_WIND_SPEED_MPS_FIX_V1
    # SIYI_4_2_2_WIND_INDICATOR_TELEMETRY_FIELD_V1
    {"key": "norm.wind.relative_indicator", "label": "Wind", "unit": "", "path": ["wind", "relative_indicator"], "age_keys": ["wind", "attitude"], "category": "Wind", "renderer": "wind_indicator"},
    {"key": "norm.wind.speed_m_s", "label": "Wind Spd", "unit": "m/s", "path": ["wind", "speed_m_s"], "digits": 1, "age_key": "wind", "category": "Wind"},
    {"key": "norm.wind.direction_deg", "label": "Wind Direction", "unit": "deg", "path": ["wind", "direction_deg"], "digits": 0, "age_key": "wind", "category": "Wind"},
    {"key": "norm.wind.vertical_m_s", "label": "Vertical Wind", "unit": "m/s", "path": ["wind", "vertical_m_s"], "digits": 1, "age_key": "wind", "category": "Wind"},
    {"key": "norm.link.rssi", "label": "RSSI", "unit": "", "path": ["link", "rssi"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.remote_rssi", "label": "Remote RSSI", "unit": "", "path": ["link", "remote_rssi"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.noise", "label": "Radio Noise", "unit": "", "path": ["link", "noise"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.remote_noise", "label": "Remote Noise", "unit": "", "path": ["link", "remote_noise"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.rx_errors", "label": "RX Errors", "unit": "", "path": ["link", "rx_errors"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.fixed_packets", "label": "Fixed Packets", "unit": "", "path": ["link", "fixed_packets"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.vehicle.mode", "label": "Flight Mode", "unit": "", "path": ["vehicle", "mode"], "age_key": "heartbeat", "category": "Vehicle"},
    {"key": "norm.vehicle.armed", "label": "Armed", "unit": "", "path": ["vehicle", "armed"], "age_key": "heartbeat", "category": "Vehicle"},
    {"key": "norm.timers.armed_s", "label": "Armed Time", "unit": "s", "path": ["timers", "armed_s"], "digits": 0, "age_key": "heartbeat", "category": "Vehicle"},
]

DEFAULT_TELEMETRY_LAYOUT = {
    "schema_version": TELEMETRY_LAYOUT_SCHEMA_VERSION,
    "visible": True,
    "layout": {
        "left": None,
        "top": None,
        "width": 320,
        "height": 280,
        "auto_fit": True,
        "columns": 2,
        "rows": 6,
        "flow": "row",
        "font_size": 17,
        "show_labels": True,
        "show_units": True,
    },

    "battery_stabilization": {
        "enabled": True,
        "pack_resistance_mohm": 0.0,
        "normal_cruise_current_a": 6.0,
        "battery_chemistry": "",
        "battery_series_cells": 6,
        "battery_full_v_per_cell": 4.10,
        "battery_empty_v_per_cell": 3.00,
    },

    "selected_fields": [
            "norm.speed.groundspeed_kmh",
            "norm.position.relative_alt_m",
            "norm.timers.flight_time_text",
            "norm.navigation.home_distance_m",
            "norm.navigation.flight_distance_m",
            "norm.battery.consumed_mah",
            "norm.battery.current_a",
            "norm.speed.airspeed_kmh",
            "norm.battery.voltage_v",
            "norm.battery.voltage_smooth_v",
            "norm.wind.relative_indicator",
            "norm.timers.local_time_text",
            "norm.speed.throttle_pct",
        ],}
DEFAULT_CONFIG: Dict[str, Any] = {
    "enabled": True,
    "mavlink": {
        "host": "0.0.0.0",
        "port": 14602,
        "system_id": 254,
        "component_id": 192,
        "manage_message_intervals": False,
    },
    "internal_api": {"host": "127.0.0.1", "port": 18765},
    "video": {
        "path": "main.264",
        "primary_protocol": "webrtc",
        "fallback_protocol": "hls",
    },
    "controls": {"enabled": False},
    "telemetry": {
        "airspeed_unit": "kmh",
        "altitude_unit": "m",
        "distance_unit": "metric",
    },
    "warnings": {
        "heartbeat_degraded_s": 3.0,
        "heartbeat_lost_s": 5.0,
    },
    "track": {"maximum_points": 3000, "minimum_interval_s": 0.8},
}


def deep_merge(base: Dict[str, Any], incoming: Dict[str, Any]) -> Dict[str, Any]:
    result = copy.deepcopy(base)
    for key, value in incoming.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def load_config() -> Dict[str, Any]:
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("configuration root is not an object")
        return deep_merge(DEFAULT_CONFIG, raw)
    except FileNotFoundError:
        return copy.deepcopy(DEFAULT_CONFIG)
    except Exception as exc:
        print(f"[GROUNDSTATION_CONFIG] using defaults: {exc!r}", flush=True)
        return copy.deepcopy(DEFAULT_CONFIG)



def _deep_get(payload: Dict[str, Any], path: list[str]) -> Any:
    value: Any = payload
    for item in path:
        if not isinstance(value, dict):
            return None
        value = value.get(item)
    return value


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace").rstrip("\\x00")
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    try:
        number = float(value)
        if math.isfinite(number):
            return number
    except (TypeError, ValueError):
        pass
    return str(value)



def _migrate_wind_speed_unit_overrides(value: Any) -> tuple[Any, bool]:
    field_key = "norm.wind.speed_m_s"
    unit_names = {
        "unit",
        "unit_override",
        "unitOverride",
        "display_unit",
        "displayUnit",
    }
    map_names = {
        "units",
        "unit_overrides",
        "unitOverrides",
        "display_units",
        "displayUnits",
    }

    def old_unit(candidate: Any) -> bool:
        return str(candidate or "").strip().lower().replace(" ", "") == "km/h"

    changed = False
    if isinstance(value, list):
        for index, child in enumerate(value):
            migrated, child_changed = _migrate_wind_speed_unit_overrides(child)
            if child_changed:
                value[index] = migrated
                changed = True
        return value, changed

    if not isinstance(value, dict):
        return value, False

    identifiers = (
        value.get("key"),
        value.get("field"),
        value.get("id"),
        value.get("telemetryKey"),
        value.get("telemetry_key"),
    )
    if any(str(candidate or "") == field_key for candidate in identifiers):
        for name in unit_names:
            if name in value and old_unit(value.get(name)):
                value[name] = "m/s"
                changed = True

    for name in map_names:
        unit_map = value.get(name)
        if isinstance(unit_map, dict) and old_unit(unit_map.get(field_key)):
            unit_map[field_key] = "m/s"
            changed = True

    for key, child in list(value.items()):
        migrated, child_changed = _migrate_wind_speed_unit_overrides(child)
        if child_changed:
            value[key] = migrated
            changed = True

    return value, changed

def _normalise_telemetry_layout(payload: Any) -> Dict[str, Any]:
    base = copy.deepcopy(DEFAULT_TELEMETRY_LAYOUT)
    if not isinstance(payload, dict):
        return base
    payload, _wind_unit_migrated = _migrate_wind_speed_unit_overrides(copy.deepcopy(payload))
    base["visible"] = bool(payload.get("visible", base["visible"]))
    incoming_layout = payload.get("layout") if isinstance(payload.get("layout"), dict) else {}
    layout = base["layout"]

    def number_or_none(name: str, minimum: float, maximum: float, fallback: Any) -> Any:
        value = incoming_layout.get(name, fallback)
        if value is None and name in {"left", "top"}:
            return None
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            return fallback
        if not math.isfinite(numeric):
            return fallback
        return max(minimum, min(maximum, numeric))

    layout["left"] = number_or_none("left", 0, 10000, layout["left"])
    layout["top"] = number_or_none("top", 0, 10000, layout["top"])
    layout["width"] = int(round(number_or_none("width", 20, 1600, layout["width"])))
    layout["height"] = int(round(number_or_none("height", 20, 1200, layout["height"])))
    layout["columns"] = int(round(number_or_none("columns", 1, 24, layout["columns"])))
    layout["rows"] = int(round(number_or_none("rows", 1, 24, layout["rows"])))
    layout["font_size"] = int(round(number_or_none("font_size", 10, 40, layout["font_size"])))
    layout["flow"] = "column" if incoming_layout.get("flow") == "column" else "row"
    layout["show_labels"] = bool(incoming_layout.get("show_labels", layout["show_labels"]))
    layout["show_units"] = bool(incoming_layout.get("show_units", layout["show_units"]))
    layout["auto_fit"] = bool(incoming_layout.get("auto_fit", layout["auto_fit"]))
    # GROUND_STATION_TELEMETRY_CANVAS_V2_CONTENT_FIT

    incoming_battery = payload.get("battery_stabilization")
    if not isinstance(incoming_battery, dict):
        incoming_battery = {}
    battery_config = base["battery_stabilization"]
    battery_config["enabled"] = bool(
        incoming_battery.get("enabled", battery_config["enabled"])
    )
    try:
        resistance_mohm = float(
            incoming_battery.get(
                "pack_resistance_mohm",
                battery_config["pack_resistance_mohm"],
            )
        )
    except (TypeError, ValueError):
        resistance_mohm = float(battery_config["pack_resistance_mohm"])
    if not math.isfinite(resistance_mohm):
        resistance_mohm = 0.0
    battery_config["pack_resistance_mohm"] = max(0.0, min(200.0, resistance_mohm))

    try:
        cruise_current = float(incoming_battery.get(
            "normal_cruise_current_a", battery_config["normal_cruise_current_a"]
        ))
    except (TypeError, ValueError):
        cruise_current = float(battery_config["normal_cruise_current_a"])
    if not math.isfinite(cruise_current):
        cruise_current = 6.0
    battery_config["normal_cruise_current_a"] = max(0.5, min(100.0, cruise_current))

    chemistry = str(incoming_battery.get("battery_chemistry", "") or "").strip().lower()
    if chemistry not in {"lipo", "liion"}:
        chemistry = ""
    battery_config["battery_chemistry"] = chemistry

    try:
        series_cells = int(round(float(incoming_battery.get(
            "battery_series_cells", battery_config["battery_series_cells"]
        ))))
    except (TypeError, ValueError):
        series_cells = int(battery_config["battery_series_cells"])
    battery_config["battery_series_cells"] = max(1, min(24, series_cells))

    defaults = {"lipo": (4.20, 3.50), "liion": (4.10, 3.00)}
    default_full, default_empty = defaults.get(chemistry, (4.10, 3.00))
    try:
        full_v = float(incoming_battery.get("battery_full_v_per_cell", default_full))
    except (TypeError, ValueError):
        full_v = default_full
    try:
        empty_v = float(incoming_battery.get("battery_empty_v_per_cell", default_empty))
    except (TypeError, ValueError):
        empty_v = default_empty
    if not math.isfinite(full_v):
        full_v = default_full
    if not math.isfinite(empty_v):
        empty_v = default_empty
    battery_config["battery_full_v_per_cell"] = full_v
    battery_config["battery_empty_v_per_cell"] = empty_v
    if not (3.50 <= full_v <= 4.40 and 2.50 <= empty_v <= 4.00 and full_v - empty_v >= 0.20):
        # Invalid endpoints are retained for UI correction, but chemistry is
        # cleared so Battery % cannot silently use an unsafe configuration.
        battery_config["battery_chemistry"] = ""

    selected: list[str] = []
    for item in payload.get("selected_fields", base["selected_fields"]):
        key = str(item or "").strip()
        if not key or len(key) > 180 or not (key.startswith("norm.") or key.startswith("raw.")):
            continue
        if key not in selected:
            selected.append(key)
        if len(selected) >= 1000:
            break
    base["selected_fields"] = selected or copy.deepcopy(DEFAULT_TELEMETRY_LAYOUT["selected_fields"])
    base["schema_version"] = TELEMETRY_LAYOUT_SCHEMA_VERSION
    return base


def _write_telemetry_layout_copy(path: Path, config: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}.{threading.get_ident()}")
    temporary.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.chmod(temporary, 0o664)
    os.replace(temporary, path)


def load_telemetry_layout() -> Dict[str, Any]:
    errors: list[str] = []
    for path in (TELEMETRY_LAYOUT_PATH, TELEMETRY_LAYOUT_SHADOW_PATH):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            config = _normalise_telemetry_layout(payload)
            for copy_path in (TELEMETRY_LAYOUT_PATH, TELEMETRY_LAYOUT_SHADOW_PATH):
                try:
                    _write_telemetry_layout_copy(copy_path, config)
                except Exception as exc:
                    errors.append(f"{copy_path}: {exc!r}")
            if errors:
                print("[GROUNDSTATION_TELEMETRY_CONFIG] mirror warning: " + "; ".join(errors), flush=True)
            return config
        except FileNotFoundError:
            continue
        except Exception as exc:
            errors.append(f"{path}: {exc!r}")
    if errors:
        print("[GROUNDSTATION_TELEMETRY_CONFIG] using defaults: " + "; ".join(errors), flush=True)
    return copy.deepcopy(DEFAULT_TELEMETRY_LAYOUT)


def save_telemetry_layout(payload: Any) -> Dict[str, Any]:
    config = _normalise_telemetry_layout(payload)
    failures: list[str] = []
    saved = 0
    for path in (TELEMETRY_LAYOUT_PATH, TELEMETRY_LAYOUT_SHADOW_PATH):
        try:
            _write_telemetry_layout_copy(path, config)
            saved += 1
        except Exception as exc:
            failures.append(f"{path}: {exc!r}")
    if saved == 0:
        raise OSError("could not save Telemetry Canvas configuration: " + "; ".join(failures))
    if failures:
        print("[GROUNDSTATION_TELEMETRY_CONFIG] mirror warning: " + "; ".join(failures), flush=True)
    return config


RAW_CANONICAL_FIELD_LABELS = {
    "groundspeed": "Ground Speed",
    "airspeed": "Air Speed",
    "relative_alt": "Alt (Rel)",
    "voltage_battery": "Voltage",
    "current_battery": "Current",
    "current_consumed": "Consumed",
    "battery_remaining": "Battery Remaining",
    "throttle": "Throttle %",
    "throttle_scaled": "Throttle %",
    "satellites_visible": "GPS Sats",
    "eph": "GPS HDOP",
    "hdop": "GPS HDOP",
    "wp_dist": "Distance to Waypoint",
    "target_bearing": "Target Bearing",
    "nav_bearing": "Navigation Bearing",
    "heading": "Heading",
    "cog": "Course Over Ground",
    "lat": "Latitude",
    "lon": "Longitude",
}

CANONICAL_ACRONYMS = {
    "gps": "GPS",
    "rssi": "RSSI",
    "hdop": "HDOP",
    "vdop": "VDOP",
    "uid": "UID",
    "id": "ID",
    "imu": "IMU",
    "rpm": "RPM",
    "rc": "RC",
    "wp": "WP",
    "mav": "MAV",
}

def canonical_field_label(field_name: str) -> str:
    key = str(field_name or "").strip().lower()
    if key in RAW_CANONICAL_FIELD_LABELS:
        return RAW_CANONICAL_FIELD_LABELS[key]
    words = [part for part in key.replace("[", " ").replace("]", " ").split("_") if part]
    if not words:
        return str(field_name or "")
    return " ".join(CANONICAL_ACRONYMS.get(word, word.capitalize()) for word in words)

def canonical_category_name(message_name: str) -> str:
    words = [part for part in str(message_name or "").strip().lower().split("_") if part]
    return " ".join(CANONICAL_ACRONYMS.get(word, word.capitalize()) for word in words)


def build_telemetry_catalog() -> list[Dict[str, Any]]:
    catalog: list[Dict[str, Any]] = []
    for item in NORMALIZED_TELEMETRY_FIELDS:
        catalog.append(
            {
                "key": item["key"],
                "label": item["label"],
                "unit": item.get("unit", ""),
                "category": item.get("category", "Ground Station"),
                "message": "NORMALIZED",
                "field": item["key"].rsplit(".", 1)[-1],
                "type": "normalized",
                "digits": item.get("digits"),
                "renderer": item.get("renderer", ""),
            }
        )
    mavlink_map = getattr(mavutil.mavlink, "mavlink_map", {}) or {}
    for message_id, message_class in sorted(mavlink_map.items(), key=lambda pair: int(pair[0])):
        name = str(
            getattr(message_class, "msgname", "")
            or getattr(message_class, "name", "")
            or f"MSG_{message_id}"
        ).upper()
        fields = list(getattr(message_class, "fieldnames", []) or [])
        types = list(getattr(message_class, "fieldtypes", []) or [])
        arrays = list(getattr(message_class, "array_lengths", []) or [])
        units_by_name = dict(getattr(message_class, "fieldunits_by_name", {}) or {})
        enums_by_name = dict(getattr(message_class, "fieldenums_by_name", {}) or {})
        for index, field in enumerate(fields):
            field_name = str(field)
            field_type = str(types[index]) if index < len(types) else ""
            array_length = int(arrays[index] or 0) if index < len(arrays) else 0
            unit = str(units_by_name.get(field_name) or "")
            enum = str(enums_by_name.get(field_name) or "")
            label_base = canonical_field_label(field_name)
            category_label = canonical_category_name(name)
            if array_length > 0 and field_type.lower() not in {"char", "char[]"}:
                for array_index in range(array_length):
                    catalog.append(
                        {
                            "key": f"raw.{name}.{field_name}[{array_index + 1}]",
                            "label": f"{label_base} {array_index + 1}",
                            "unit": unit,
                            "category": category_label,
                            "message": name,
                            "field": f"{field_name}[{array_index + 1}]",
                            "type": field_type,
                            "enum": enum,
                            "message_id": int(message_id),
                        }
                    )
            else:
                catalog.append(
                    {
                        "key": f"raw.{name}.{field_name}",
                        "label": label_base,
                        "unit": unit,
                        "category": category_label,
                        "message": name,
                        "field": field_name,
                        "type": field_type,
                        "enum": enum,
                        "message_id": int(message_id),
                    }
                )
    return catalog

def finite(value: Any) -> Optional[float]:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def degrees(value: Any) -> Optional[float]:
    number = finite(value)
    return math.degrees(number) if number is not None else None


def gps_fix_name(value: int) -> str:
    return {
        0: "NO GPS",
        1: "NO FIX",
        2: "2D",
        3: "3D",
        4: "DGPS",
        5: "RTK FLOAT",
        6: "RTK FIXED",
        7: "STATIC",
        8: "PPP",
    }.get(int(value or 0), "UNKNOWN")


def severity_name(value: int) -> str:
    return {
        0: "Emergency",
        1: "Alert",
        2: "Critical",
        3: "Error",
        4: "Warning",
        5: "Notice",
        6: "Info",
        7: "Debug",
    }.get(int(value or 6), "Info")


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    radius = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * radius * math.atan2(math.sqrt(a), math.sqrt(max(0.0, 1.0 - a)))


def bearing_deg(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    y = math.sin(dl) * math.cos(p2)
    x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(y, x)) + 360.0) % 360.0


def format_hms(total_seconds: Any) -> str:
    number = finite(total_seconds)
    if number is None or number < 0:
        number = 0.0
    seconds = int(round(number))
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


class VehicleState:
    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.lock = threading.RLock()
        self.started_monotonic = time.monotonic()
        self.started_wall = time.time()
        self.selected_vehicle: Optional[Tuple[int, int]] = None
        self.vehicle_heartbeats: Dict[Tuple[int, int], float] = {}
        self.field_times: Dict[str, float] = {}
        self.messages = deque(maxlen=250)
        self.track = deque(maxlen=int(config.get("track", {}).get("maximum_points", 3000)))
        self.track_sequence = 0
        self.last_track_time = 0.0
        self.last_track_position: Optional[Tuple[float, float]] = None
        self.armed_since: Optional[float] = None
        self.total_armed_s = 0.0
        self.flight_distance_m = 0.0
        self.flight_distance_last_position: Optional[Tuple[float, float]] = None
        self.flight_distance_last_time: Optional[float] = None
        self.raw_telemetry_values: Dict[str, Any] = {}
        self.raw_telemetry_times: Dict[str, float] = {}
        self.telemetry_catalog = build_telemetry_catalog()
        self.telemetry_layout = load_telemetry_layout()
        self.battery_voltage_samples = deque(maxlen=3)
        self.battery_voltage_envelope = deque(maxlen=1200)
        self.battery_voltage_cruise_samples = deque(maxlen=1200)
        self.battery_voltage_cruise_baseline_acquired = False
        self.battery_percentage_last: Optional[float] = None
        self.battery_percentage_source: str = "unavailable"
        self.battery_voltage_stable_v: Optional[float] = None
        self.battery_voltage_candidate_v: Optional[float] = None
        self.battery_voltage_last_update: Optional[float] = None
        self.battery_voltage_last_current_a: Optional[float] = None
        self.battery_voltage_hold_until = 0.0
        self.battery_voltage_drop_confirm_since: Optional[float] = None
        self.battery_voltage_compensation_was_active = False
        self.battery_voltage_armed_was = False
        # FLIGHTCORE_4_2_3_RC3_RELAXED_VOLTAGE_ESTIMATOR_V1
        self.battery_voltage_last_raw_v: Optional[float] = None
        self.battery_voltage_idle_current_a: Optional[float] = None
        self.battery_voltage_effective_resistance_ohm: Optional[float] = None
        self.battery_voltage_config_resistance_ohm: Optional[float] = None
        self.battery_voltage_resistance_samples = deque(maxlen=31)
        self.battery_voltage_slow_load_a = 0.0
        self.battery_voltage_polar_resistance_ohm: Optional[float] = None
        self.battery_voltage_polar_samples = deque(maxlen=31)
        self.battery_voltage_recovery_probe: Optional[Dict[str, float]] = None
        self.state: Dict[str, Any] = {
            "connection": {
                "state": "NO_VEHICLE",
                "heartbeat_age_s": None,
                "system_id": None,
                "component_id": None,
                "multiple_vehicles": False,
            },
            "vehicle": {
                "type": None,
                "autopilot": None,
                "armed": None,
                "mode": None,
                "system_status": None,
            },
            "attitude": {"roll_deg": None, "pitch_deg": None, "heading_deg": None},
            "position": {
                "lat": None,
                "lon": None,
                "relative_alt_m": None,
                "amsl_alt_m": None,
                "ground_course_deg": None,
            },
            "speed": {
                "airspeed_m_s": None,
                "groundspeed_m_s": None,
                "vertical_speed_m_s": None,
                "throttle_pct": None,
            },
            "battery": {
                "voltage_v": None,
                "voltage_compensated_v": None,
                "voltage_smooth_v": None,
                "voltage_filter_status": "unavailable",
                "voltage_tracker_state": "unavailable",
                "voltage_tracker_candidate_v": None,
                "voltage_compensation_active": False,
                "voltage_compensation_clamped": False,
                "voltage_effective_resistance_mohm": None,
                "voltage_polarization_v": None,
                "voltage_idle_current_a": None,
                "voltage_slow_load_a": None,
                "estimated_pct": None,
                "percentage_status": "unavailable",
                "percentage_source": "unavailable",
                "percentage_per_cell_v": None,
                "configured_cell_count": None,
                "cell_count": None,
                "current_a": None,
                "remaining_pct": None,
                "consumed_mah": None,
            },
            "gps": {"fix": "UNKNOWN", "fix_type": None, "satellites": None, "hdop": None},
            "navigation": {
                "home_lat": None,
                "home_lon": None,
                "home_distance_m": None,
                "home_bearing_deg": None,
                "waypoint_current": None,
                "waypoint_reached": None,
                "target_bearing_deg": None,
                "distance_to_waypoint_m": None,
                "flight_distance_m": 0.0,
            },
            "link": {
                "rssi": None,
                "remote_rssi": None,
                "noise": None,
                "remote_noise": None,
                "rx_errors": None,
                "fixed_packets": None,
            },
            "wind": {"speed_m_s": None, "direction_deg": None, "vertical_m_s": None, "relative_indicator": None},
            "rc": {"channels": []},
            "servo": {"outputs": []},
            "timers": {"connected_s": 0.0, "armed_s": 0.0, "flight_time_text": "00:00:00", "local_time_text": time.strftime("%H:%M:%S")},
            "messages": [],
            "track": [],
            "field_age_s": {},
            "service": {
                "monitor_only": True,
                "started_at": self.started_wall,
                "last_packet_at": None,
                "packet_count": 0,
            },
        }

    def _touch(self, field: str, now: float) -> None:
        self.field_times[field] = now

    def _battery_stabilization_config_locked(self) -> Dict[str, Any]:
        config = self.telemetry_layout.get("battery_stabilization", {})
        if not isinstance(config, dict):
            config = {}
        return {
            "enabled": bool(config.get("enabled", True)),
            "pack_resistance_mohm": max(
                0.0,
                min(200.0, finite(config.get("pack_resistance_mohm")) or 0.0),
            ),
            "normal_cruise_current_a": max(
                0.5,
                min(100.0, finite(config.get("normal_cruise_current_a")) or 6.0),
            ),
            "battery_chemistry": str(config.get("battery_chemistry", "") or "").strip().lower(),
            "battery_series_cells": max(
                1,
                min(24, int(round(finite(config.get("battery_series_cells")) or 6.0))),
            ),
            "battery_full_v_per_cell": finite(config.get("battery_full_v_per_cell")),
            "battery_empty_v_per_cell": finite(config.get("battery_empty_v_per_cell")),
        }

    def _reset_battery_voltage_tracker_locked(self, clear_stable: bool = True) -> None:
        self.battery_voltage_samples.clear()
        self.battery_voltage_envelope.clear()
        self.battery_voltage_cruise_samples.clear()
        self.battery_voltage_cruise_baseline_acquired = False
        self.battery_percentage_last = None
        self.battery_percentage_source = "unavailable"
        if clear_stable:
            self.battery_voltage_stable_v = None
        self.battery_voltage_candidate_v = None
        self.battery_voltage_last_update = None
        self.battery_voltage_last_current_a = None
        self.battery_voltage_hold_until = 0.0
        self.battery_voltage_drop_confirm_since = None
        self.battery_voltage_compensation_was_active = False
        self.battery_voltage_armed_was = False
        self.battery_voltage_last_raw_v = None
        self.battery_voltage_idle_current_a = None
        self.battery_voltage_effective_resistance_ohm = None
        self.battery_voltage_config_resistance_ohm = None
        self.battery_voltage_resistance_samples.clear()
        self.battery_voltage_slow_load_a = 0.0
        self.battery_voltage_polar_resistance_ohm = None
        self.battery_voltage_polar_samples.clear()
        self.battery_voltage_recovery_probe = None

    @staticmethod
    def _battery_upper_percentile(values: list[float], percentile: float = 0.90) -> Optional[float]:
        clean = sorted(value for value in values if math.isfinite(value))
        if not clean:
            return None
        index = int(round((len(clean) - 1) * max(0.0, min(1.0, percentile))))
        return clean[max(0, min(len(clean) - 1, index))]

    # SIYI_4_2_2_RC5_CRUISE_BASELINE_TRACKER_V1
    # SIYI_4_2_2_RC8_CONSERVATIVE_SMOOTH_VOLTAGE_AND_PERCENT_V1
    def _update_battery_stabilization_locked(self, now: float) -> None:
        """Estimate relaxed/resting battery voltage for display and voice only.

        RC3 separates immediate ohmic sag from delayed electrochemical recovery.
        The configured pack resistance is the starting prior for fast sag and is
        adapted from short load steps. A slow filtered propulsion-load state adds
        the remaining polarization/recovery term and is refined during low-load
        recovery windows. Normal cruise current only classifies stable/transient
        operating regions; it is never subtracted from sag compensation.

        Raw FC voltage, battery warnings and failsafes are not modified.
        """
        battery = self.state["battery"]
        raw_voltage = finite(battery.get("voltage_v"))
        if raw_voltage is None or raw_voltage <= 0.0 or raw_voltage > 100.0:
            battery.update({
                "voltage_compensated_v": None, "voltage_smooth_v": None,
                "voltage_filter_status": "unavailable", "voltage_tracker_state": "unavailable",
                "voltage_tracker_candidate_v": None, "voltage_compensation_active": False,
                "voltage_compensation_clamped": False,
                "voltage_effective_resistance_mohm": None,
                "voltage_polarization_v": None,
                "voltage_idle_current_a": None,
                "voltage_slow_load_a": None,
            })
            self._reset_battery_voltage_tracker_locked()
            return

        config = self._battery_stabilization_config_locked()
        if not bool(config["enabled"]):
            battery.update({
                "voltage_compensated_v": raw_voltage, "voltage_smooth_v": None,
                "voltage_filter_status": "disabled", "voltage_tracker_state": "disabled",
                "voltage_tracker_candidate_v": None, "voltage_compensation_active": False,
                "voltage_compensation_clamped": False,
                "voltage_effective_resistance_mohm": None,
                "voltage_polarization_v": None,
                "voltage_idle_current_a": None,
                "voltage_slow_load_a": None,
            })
            self._reset_battery_voltage_tracker_locked()
            return

        configured_r = float(config["pack_resistance_mohm"]) / 1000.0
        cruise_a = float(config["normal_cruise_current_a"])
        chemistry = str(config.get("battery_chemistry") or "")
        current_a = finite(battery.get("current_a"))
        configured_cells = int(config.get("battery_series_cells") or 0)
        try:
            telemetry_cells = int(battery.get("cell_count"))
        except (TypeError, ValueError):
            telemetry_cells = 0
        cell_count = configured_cells if 1 <= configured_cells <= 24 else telemetry_cells
        cell_count_valid = 1 <= cell_count <= 24
        current_valid = current_a is not None and 0.0 <= current_a <= 500.0
        compensation_active = bool(configured_r > 0.0 and current_valid and cell_count_valid)
        armed = self.state.get("vehicle", {}).get("armed") is True

        elapsed = None if self.battery_voltage_last_update is None else now - self.battery_voltage_last_update
        natural_gap = elapsed is None or elapsed > 3.0
        dt = 0.1 if elapsed is None else max(0.02, min(1.0, elapsed))
        mode_changed = compensation_active != self.battery_voltage_compensation_was_active
        just_armed = armed and not self.battery_voltage_armed_was
        just_disarmed = (not armed) and self.battery_voltage_armed_was
        self.battery_voltage_armed_was = armed

        if natural_gap or mode_changed:
            self.battery_voltage_samples.clear()
            self.battery_voltage_envelope.clear()
            self.battery_voltage_cruise_samples.clear()
            self.battery_voltage_drop_confirm_since = None
            self.battery_voltage_recovery_probe = None
        if self.battery_voltage_compensation_was_active and not compensation_active:
            self.battery_voltage_effective_resistance_ohm = None
            self.battery_voltage_config_resistance_ohm = None
            self.battery_voltage_resistance_samples.clear()
            self.battery_voltage_polar_resistance_ohm = None
            self.battery_voltage_polar_samples.clear()
            self.battery_voltage_slow_load_a = 0.0
        self.battery_voltage_compensation_was_active = compensation_active

        # Reinitialize adaptive electrical parameters when the user changes the
        # configured resistance. The user value remains the prior and bounding
        # reference; automatic learning cannot run if the user selects 0 mOhm.
        resistance_changed = (
            self.battery_voltage_config_resistance_ohm is None
            or abs(float(self.battery_voltage_config_resistance_ohm) - configured_r) > 1e-9
        )
        polar_ratio_default = 0.45 if chemistry == "liion" else (0.30 if chemistry == "lipo" else 0.40)
        if resistance_changed:
            self.battery_voltage_config_resistance_ohm = configured_r
            self.battery_voltage_effective_resistance_ohm = configured_r if configured_r > 0.0 else 0.0
            self.battery_voltage_resistance_samples.clear()
            self.battery_voltage_polar_resistance_ohm = configured_r * polar_ratio_default if configured_r > 0.0 else 0.0
            self.battery_voltage_polar_samples.clear()
            self.battery_voltage_recovery_probe = None

        effective_r = float(self.battery_voltage_effective_resistance_ohm or 0.0)
        polar_r = float(self.battery_voltage_polar_resistance_ohm or 0.0)

        # Learn the system-idle current (Pi/cameras/etc.) so "resting voltage"
        # means the practical low-load state seen on the aircraft, not theoretical
        # zero-current OCV. Disarmed/low-load evidence is favored.
        low_load_limit = max(1.5, cruise_a * 0.30)
        if current_valid:
            value = float(current_a)
            if self.battery_voltage_idle_current_a is None:
                self.battery_voltage_idle_current_a = value if (not armed or value <= low_load_limit) else 0.0
            elif not armed and value <= low_load_limit:
                alpha_idle = dt / (5.0 + dt)
                self.battery_voltage_idle_current_a += alpha_idle * (value - self.battery_voltage_idle_current_a)
            elif armed and value <= low_load_limit:
                tau_idle = 8.0 if value < self.battery_voltage_idle_current_a else 60.0
                alpha_idle = dt / (tau_idle + dt)
                self.battery_voltage_idle_current_a += alpha_idle * (value - self.battery_voltage_idle_current_a)
        idle_current = max(0.0, min(cruise_a * 0.50, float(self.battery_voltage_idle_current_a or 0.0)))

        previous_current = self.battery_voltage_last_current_a
        previous_raw = self.battery_voltage_last_raw_v
        delta_i = 0.0
        current_step_limit = max(1.5, cruise_a * 0.20)
        current_step = False
        if current_valid and previous_current is not None and not natural_gap:
            delta_i = float(current_a) - float(previous_current)
            current_step = abs(delta_i) >= current_step_limit

        # Adaptive fast resistance: a rapid current change with opposite voltage
        # movement is a direct in-flight R observation because SOC cannot change
        # materially over the same short interval. Median rejection prevents one
        # noisy telemetry pair from retuning the estimator.
        if (
            compensation_active and previous_current is not None and previous_raw is not None
            and elapsed is not None and 0.05 <= elapsed <= 2.5
            and abs(delta_i) >= current_step_limit
        ):
            delta_v = raw_voltage - float(previous_raw)
            if delta_i * delta_v < 0.0 and 0.03 <= abs(delta_v) <= 2.5:
                observed_r = -delta_v / delta_i
                lower_r = max(0.010, configured_r * 0.50)
                upper_r = min(0.200, configured_r * 1.80)
                if lower_r <= observed_r <= upper_r:
                    self.battery_voltage_resistance_samples.append(observed_r)
                    ordered_r = sorted(self.battery_voltage_resistance_samples)
                    median_r = ordered_r[len(ordered_r) // 2]
                    effective_r += 0.20 * (median_r - effective_r)
        if compensation_active and not self.battery_voltage_resistance_samples:
            alpha_r = dt / (120.0 + dt)
            effective_r += alpha_r * (configured_r - effective_r)
        if configured_r > 0.0:
            effective_r = max(max(0.010, configured_r * 0.50), min(min(0.200, configured_r * 1.80), effective_r))
        else:
            effective_r = 0.0
        self.battery_voltage_effective_resistance_ohm = effective_r

        # Slow load state models polarization: it rises under sustained propulsion
        # load and decays after unloading. This is the component the RC13/RC2
        # estimator missed when Raw remained ~0.17 V below its later relaxed value
        # even at ~0.9 A.
        load_current = max(0.0, float(current_a) - idle_current) if current_valid else 0.0
        slow_drive = min(load_current, cruise_a * 1.50)
        tau_slow = 18.0 if slow_drive > self.battery_voltage_slow_load_a else 25.0
        alpha_slow = dt / (tau_slow + dt)
        self.battery_voltage_slow_load_a += alpha_slow * (slow_drive - self.battery_voltage_slow_load_a)
        slow_load = max(0.0, self.battery_voltage_slow_load_a)

        # Begin a recovery probe when propulsion load drops sharply into the
        # low-load region. Subsequent Raw-voltage recovery divided by the decay of
        # slow-load state gives a direct estimate of the polarization resistance.
        if (
            compensation_active and previous_current is not None and current_valid
            and float(previous_current) - float(current_a) >= max(2.0, cruise_a * 0.30)
            and float(current_a) <= low_load_limit
        ):
            self.battery_voltage_recovery_probe = {
                "started": now, "raw_start": raw_voltage, "slow_start": slow_load
            }
        probe = self.battery_voltage_recovery_probe
        if probe is not None:
            if not current_valid or float(current_a) > low_load_limit or now - probe["started"] > 45.0:
                self.battery_voltage_recovery_probe = None
            elif now - probe["started"] >= 4.0:
                recovered_v = raw_voltage - probe["raw_start"]
                released_slow_a = probe["slow_start"] - slow_load
                if recovered_v >= 0.0 and released_slow_a >= 0.50:
                    observed_polar_r = recovered_v / released_slow_a
                    upper_polar_r = min(0.100, max(0.020, effective_r))
                    if 0.005 <= observed_polar_r <= upper_polar_r:
                        self.battery_voltage_polar_samples.append(observed_polar_r)
                        ordered_p = sorted(self.battery_voltage_polar_samples)
                        median_p = ordered_p[len(ordered_p) // 2]
                        polar_r += 0.15 * (median_p - polar_r)

        if compensation_active and not self.battery_voltage_polar_samples:
            target_polar_r = effective_r * polar_ratio_default
            alpha_p = dt / (60.0 + dt)
            polar_r += alpha_p * (target_polar_r - polar_r)
        polar_r = max(0.0, min(0.100, polar_r if compensation_active else 0.0))
        self.battery_voltage_polar_resistance_ohm = polar_r

        requested_fast_sag = load_current * effective_r if compensation_active else 0.0
        requested_polar_sag = slow_load * polar_r if compensation_active else 0.0
        requested_sag = requested_fast_sag + requested_polar_sag
        maximum_sag = 0.12 * cell_count if cell_count_valid else 0.0
        sag_v = max(0.0, min(maximum_sag, requested_sag)) if compensation_active else 0.0
        compensation_clamped = bool(compensation_active and requested_sag > maximum_sag + 1e-9)
        instantaneous_compensated = raw_voltage + sag_v
        self.battery_voltage_samples.append(instantaneous_compensated)
        ordered = sorted(self.battery_voltage_samples)
        compensated = ordered[len(ordered) // 2]

        if just_armed:
            self.battery_voltage_hold_until = max(self.battery_voltage_hold_until, now + 4.0)
        high_load = bool(current_valid and float(current_a) > max(cruise_a * 1.80, cruise_a + 8.0))
        if current_step:
            self.battery_voltage_hold_until = max(self.battery_voltage_hold_until, now + 3.0)
        if high_load or compensation_clamped:
            self.battery_voltage_hold_until = max(self.battery_voltage_hold_until, now + 3.0)

        evidence_weight = 0.0
        current_region = "unusable"
        if current_valid and not high_load and not current_step and now >= self.battery_voltage_hold_until:
            value = float(current_a)
            if value <= low_load_limit:
                evidence_weight = 1.20; current_region = "low_reference"
            elif abs(value - cruise_a) <= max(1.0, cruise_a * 0.30):
                evidence_weight = 1.00; current_region = "cruise"
            elif value <= cruise_a * 1.60:
                evidence_weight = 0.60; current_region = "moderate"
        if evidence_weight > 0.0:
            self.battery_voltage_cruise_samples.append((now, compensated, evidence_weight, dt))
            self.battery_voltage_envelope.append((now, compensated))
        while self.battery_voltage_cruise_samples and now - self.battery_voltage_cruise_samples[0][0] > 20.0:
            self.battery_voltage_cruise_samples.popleft()
        while self.battery_voltage_envelope and now - self.battery_voltage_envelope[0][0] > 20.0:
            self.battery_voltage_envelope.popleft()

        evidence_values = [sample for _ts, sample, _weight, _sample_dt in self.battery_voltage_cruise_samples]
        candidate = self._battery_upper_percentile(evidence_values, 0.65)
        if candidate is None:
            candidate = compensated
        self.battery_voltage_candidate_v = candidate

        if self.battery_voltage_stable_v is None:
            stable = raw_voltage if (not armed and current_valid and float(current_a) <= low_load_limit) else candidate
            tracker_state = "acquire"
        elif natural_gap and armed:
            stable = self.battery_voltage_stable_v
            tracker_state = "reacquire"
        elif not armed:
            alpha = dt / (6.0 + dt)
            stable = self.battery_voltage_stable_v + alpha * (candidate - self.battery_voltage_stable_v)
            tracker_state = "idle"
        elif now < self.battery_voltage_hold_until or high_load or current_step:
            stable = self.battery_voltage_stable_v
            tracker_state = "hold"
        else:
            previous = self.battery_voltage_stable_v
            error = candidate - previous
            deadband = 0.015
            if abs(error) <= deadband:
                stable = previous
                tracker_state = "track"
            else:
                # Downward movement represents real depletion and may track at a
                # practical pace. Upward correction is allowed (unlike RC13) but
                # is faster only when low-load evidence is available.
                if error < 0.0:
                    tau_output = 25.0
                elif current_region == "low_reference":
                    tau_output = 12.0
                else:
                    tau_output = 45.0
                alpha = dt / (tau_output + dt)
                stable = previous + alpha * error
                tracker_state = "track"

        display_stable = max(0.0, min(100.0, stable))
        if compensation_active and compensation_clamped:
            status = "compensated_limited"
        elif compensation_active:
            status = "compensated"
        else:
            status = "filtered_only"
            if configured_r > 0.0 and not compensation_active:
                tracker_state = "fallback"

        self.battery_voltage_stable_v = display_stable
        self.battery_voltage_last_update = now
        self.battery_voltage_last_current_a = float(current_a) if current_valid else None
        self.battery_voltage_last_raw_v = raw_voltage
        battery["voltage_compensated_v"] = round(compensated, 4)
        battery["voltage_smooth_v"] = round(display_stable, 4)
        battery["voltage_filter_status"] = status
        battery["voltage_tracker_state"] = tracker_state + ":" + current_region
        battery["voltage_tracker_candidate_v"] = round(candidate, 4)
        battery["voltage_compensation_active"] = compensation_active
        battery["voltage_compensation_clamped"] = compensation_clamped
        battery["voltage_effective_resistance_mohm"] = round(effective_r * 1000.0, 3) if compensation_active else None
        battery["voltage_polarization_v"] = round(requested_polar_sag, 4) if compensation_active else 0.0
        battery["voltage_idle_current_a"] = round(idle_current, 3) if current_valid else None
        battery["voltage_slow_load_a"] = round(slow_load, 3) if compensation_active else 0.0

    def _update_battery_percentage_locked(self) -> None:
        """Calculate display-only Battery % from user-defined pack endpoints."""
        battery = self.state["battery"]
        config = self._battery_stabilization_config_locked()
        chemistry = str(config.get("battery_chemistry") or "")
        cells = int(config.get("battery_series_cells") or 0)
        full_v = finite(config.get("battery_full_v_per_cell"))
        empty_v = finite(config.get("battery_empty_v_per_cell"))
        valid_config = bool(
            chemistry in {"lipo", "liion"}
            and 1 <= cells <= 24
            and full_v is not None
            and empty_v is not None
            and 3.50 <= full_v <= 4.40
            and 2.50 <= empty_v <= 4.00
            and full_v - empty_v >= 0.20
        )
        battery["configured_cell_count"] = cells if valid_config else None
        if not valid_config:
            battery.update({
                "estimated_pct": None,
                "percentage_status": "unconfigured",
                "percentage_source": "unavailable",
                "percentage_per_cell_v": None,
            })
            self.battery_percentage_last = None
            self.battery_percentage_source = "unavailable"
            return

        smooth_v = finite(battery.get("voltage_smooth_v"))
        raw_v = finite(battery.get("voltage_v"))
        if smooth_v is not None and smooth_v > 0.0:
            pack_v = smooth_v
            source = "smooth"
        elif raw_v is not None and raw_v > 0.0:
            pack_v = raw_v
            source = "raw"
        else:
            battery.update({
                "estimated_pct": None,
                "percentage_status": "voltage_unavailable",
                "percentage_source": "unavailable",
                "percentage_per_cell_v": None,
            })
            self.battery_percentage_last = None
            self.battery_percentage_source = "unavailable"
            return

        per_cell = pack_v / cells
        percentage = 100.0 * (per_cell - empty_v) / (full_v - empty_v)
        percentage = max(0.0, min(100.0, percentage))

        # RC8: calculate continuously from the current selected voltage. RC7's
        # armed-only min(previous, current) latch could capture a temporary
        # takeoff value (about 55% in the flight test) and then forbid recovery
        # when Smooth Voltage returned to its valid held value.
        self.battery_percentage_last = percentage
        self.battery_percentage_source = source
        battery.update({
            "estimated_pct": round(percentage, 2),
            "percentage_status": "ok",
            "percentage_source": source,
            "percentage_per_cell_v": round(per_cell, 4),
        })

    def _update_wind_indicator_locked(self) -> None:
        # Preserve the first-generation 4.2.1 convention exactly:
        # WIND.direction is treated as the incoming wind direction.
        # Equal wind direction and aircraft heading is direct headwind = 0 deg,
        # and the down-pointing SVG therefore points down. Tailwind = 180 deg.
        wind = self.state["wind"]
        speed = finite(wind.get("speed_m_s"))
        direction = finite(wind.get("direction_deg"))
        heading = finite(self.state["attitude"].get("heading_deg"))
        if speed is None and (direction is None or heading is None):
            wind["relative_indicator"] = None
            return
        relative = None
        if direction is not None and heading is not None:
            relative = (direction - heading) % 360.0
        wind["relative_indicator"] = {
            "speed_m_s": speed,
            "direction_deg": direction,
            "heading_deg": heading,
            "relative_deg": relative,
            "semantics": "incoming_headwind_down",
        }

    def _is_fc_heartbeat(self, msg: Any) -> bool:
        autopilot = int(getattr(msg, "autopilot", mavutil.mavlink.MAV_AUTOPILOT_INVALID))
        vehicle_type = int(getattr(msg, "type", mavutil.mavlink.MAV_TYPE_GENERIC))
        if autopilot == mavutil.mavlink.MAV_AUTOPILOT_INVALID:
            return False
        if vehicle_type in {
            mavutil.mavlink.MAV_TYPE_GCS,
            mavutil.mavlink.MAV_TYPE_ONBOARD_CONTROLLER,
            mavutil.mavlink.MAV_TYPE_GIMBAL,
        }:
            return False
        return True

    def _selected(self, msg: Any) -> bool:
        if self.selected_vehicle is None:
            return False
        return (msg.get_srcSystem(), msg.get_srcComponent()) == self.selected_vehicle

    def _capture_raw_telemetry(self, msg: Any, kind: str, now: float) -> None:
        try:
            payload = msg.to_dict()
        except Exception:
            payload = {}
            for field in getattr(msg, "get_fieldnames", lambda: [])():
                payload[field] = getattr(msg, field, None)
        for field, value in payload.items():
            if field == "mavpackettype":
                continue
            safe = _json_safe(value)
            base = f"raw.{kind}.{field}"
            if isinstance(safe, list):
                self.raw_telemetry_values[base] = copy.deepcopy(safe)
                self.raw_telemetry_times[base] = now
                for index, item in enumerate(safe, start=1):
                    key = f"{base}[{index}]"
                    self.raw_telemetry_values[key] = item
                    self.raw_telemetry_times[key] = now
            else:
                self.raw_telemetry_values[base] = safe
                self.raw_telemetry_times[base] = now

    def telemetry_catalog_snapshot(self) -> Dict[str, Any]:
        with self.lock:
            return {
                "ok": True,
                "schema_version": TELEMETRY_LAYOUT_SCHEMA_VERSION,
                "catalog_total": len(self.telemetry_catalog),
                "fields": copy.deepcopy(self.telemetry_catalog),
            }

    def telemetry_values_snapshot(self, requested_keys: Optional[Set[str]] = None) -> Dict[str, Any]:
        now = time.monotonic()
        with self.lock:
            self._refresh_dynamic_telemetry_locked(now)
            values: Dict[str, Any] = {}
            for item in NORMALIZED_TELEMETRY_FIELDS:
                if requested_keys is not None and item["key"] not in requested_keys:
                    continue
                value = _deep_get(self.state, item["path"])
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    multiplier = float(item.get("multiplier", 1.0))
                    value = float(value) * multiplier
                age_keys = item.get("age_keys")
                if isinstance(age_keys, (list, tuple)) and age_keys:
                    timestamps = [
                        self.field_times.get(str(key)) for key in age_keys
                    ]
                    if any(timestamp is None for timestamp in timestamps):
                        age = None
                    else:
                        age = max(max(0.0, now - float(timestamp)) for timestamp in timestamps)
                else:
                    age_key = str(item.get("age_key") or "")
                    timestamp = self.field_times.get(age_key)
                    age = max(0.0, now - timestamp) if timestamp is not None else None
                if value is not None or item["key"] in {"norm.battery.voltage_smooth_v", "norm.battery.estimated_pct"}:
                    entry = {
                        "value": _json_safe(value),
                        "age_s": round(age, 3) if age is not None else None,
                    }
                    if item["key"] == "norm.battery.estimated_pct":
                        battery = self.state["battery"]
                        entry.update({
                            "status": battery.get("percentage_status", "unavailable"),
                            "source": battery.get("percentage_source", "unavailable"),
                            "per_cell_v": battery.get("percentage_per_cell_v"),
                            "configured_cell_count": battery.get("configured_cell_count"),
                        })
                    if item["key"] == "norm.battery.voltage_smooth_v":
                        battery = self.state["battery"]
                        entry.update(
                            {
                                "status": battery.get("voltage_filter_status", "unavailable"),
                                "compensation_active": bool(
                                    battery.get("voltage_compensation_active")
                                ),
                                "compensation_clamped": bool(
                                    battery.get("voltage_compensation_clamped")
                                ),
                                "cell_count": battery.get("cell_count"),
                                "compensated_v": battery.get("voltage_compensated_v"),
                                "tracker_state": battery.get("voltage_tracker_state", "unavailable"),
                                "tracker_candidate_v": battery.get("voltage_tracker_candidate_v"),
                            }
                        )
                    values[item["key"]] = entry
            for key, value in self.raw_telemetry_values.items():
                if requested_keys is not None and key not in requested_keys:
                    continue
                timestamp = self.raw_telemetry_times.get(key)
                age = max(0.0, now - timestamp) if timestamp is not None else None
                values[key] = {"value": copy.deepcopy(value), "age_s": round(age, 3) if age is not None else None}
            return {
                "ok": True,
                "schema_version": TELEMETRY_LAYOUT_SCHEMA_VERSION,
                "values": values,
                "available_fields": len(values),
                "packet_count": self.state["service"]["packet_count"],
            }

    def telemetry_layout_snapshot(self) -> Dict[str, Any]:
        with self.lock:
            return {
                "ok": True,
                "config": copy.deepcopy(self.telemetry_layout),
                "path": str(TELEMETRY_LAYOUT_PATH),
                "shadow_path": str(TELEMETRY_LAYOUT_SHADOW_PATH),
            }

    def update_telemetry_layout(self, payload: Any) -> Dict[str, Any]:
        with self.lock:
            before = self._battery_stabilization_config_locked()
            self.telemetry_layout = save_telemetry_layout(payload)
            after = self._battery_stabilization_config_locked()
            if before != after:
                self._reset_battery_voltage_tracker_locked()
            return copy.deepcopy(self.telemetry_layout)

    def update(self, msg: Any) -> None:
        now = time.monotonic()
        kind = msg.get_type()
        if kind == "BAD_DATA":
            return
        with self.lock:
            self.state["service"]["packet_count"] += 1
            self.state["service"]["last_packet_at"] = time.time()

            if kind == "HEARTBEAT" and self._is_fc_heartbeat(msg):
                key = (msg.get_srcSystem(), msg.get_srcComponent())
                self.vehicle_heartbeats[key] = now
                active = [item for item, ts in self.vehicle_heartbeats.items() if now - ts <= 5.0]
                active.sort()
                self.state["connection"]["multiple_vehicles"] = len(active) > 1
                if self.selected_vehicle not in active:
                    self.selected_vehicle = active[0] if len(active) == 1 else None
                if self.selected_vehicle == key:
                    base_mode = int(getattr(msg, "base_mode", 0) or 0)
                    armed = bool(base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED)
                    previous = self.state["vehicle"].get("armed")
                    if armed and previous is not True:
                        self.armed_since = now
                        self._reset_flight_distance_locked(keep_current_position=True)
                    elif not armed and previous is True and self.armed_since is not None:
                        self.total_armed_s += max(0.0, now - self.armed_since)
                        self.armed_since = None
                    self.state["vehicle"].update(
                        {
                            "type": mavutil.mavlink.enums["MAV_TYPE"].get(int(msg.type), None).name
                            if int(msg.type) in mavutil.mavlink.enums["MAV_TYPE"]
                            else str(int(msg.type)),
                            "autopilot": mavutil.mavlink.enums["MAV_AUTOPILOT"].get(int(msg.autopilot), None).name
                            if int(msg.autopilot) in mavutil.mavlink.enums["MAV_AUTOPILOT"]
                            else str(int(msg.autopilot)),
                            "armed": armed,
                            "mode": mavutil.mode_string_v10(msg),
                            "system_status": mavutil.mavlink.enums["MAV_STATE"].get(int(msg.system_status), None).name
                            if int(msg.system_status) in mavutil.mavlink.enums["MAV_STATE"]
                            else str(int(msg.system_status)),
                        }
                    )
                    self._touch("vehicle", now)
                    self._touch("heartbeat", now)
                    self._capture_raw_telemetry(msg, kind, now)
                return

            if not self._selected(msg):
                return

            # GROUND_STATION_ATTITUDE_FALLBACK_V6
            if self._selected(msg):
                self._capture_raw_telemetry(msg, kind, now)

            if kind == "ATTITUDE":
                self.state["attitude"].update(
                    {
                        "roll_deg": degrees(msg.roll),
                        "pitch_deg": degrees(msg.pitch),
                        "heading_deg": (degrees(msg.yaw) or 0.0) % 360.0,
                    }
                )
                self._touch("attitude", now)

            elif kind == "ATTITUDE_QUATERNION":
                q1 = finite(getattr(msg, "q1", None))
                q2 = finite(getattr(msg, "q2", None))
                q3 = finite(getattr(msg, "q3", None))
                q4 = finite(getattr(msg, "q4", None))
                if None not in (q1, q2, q3, q4):
                    sinr_cosp = 2.0 * (q1 * q2 + q3 * q4)
                    cosr_cosp = 1.0 - 2.0 * (q2 * q2 + q3 * q3)
                    roll = math.atan2(sinr_cosp, cosr_cosp)
                    sinp = 2.0 * (q1 * q3 - q4 * q2)
                    pitch = math.copysign(math.pi / 2.0, sinp) if abs(sinp) >= 1.0 else math.asin(sinp)
                    siny_cosp = 2.0 * (q1 * q4 + q2 * q3)
                    cosy_cosp = 1.0 - 2.0 * (q3 * q3 + q4 * q4)
                    yaw = math.atan2(siny_cosp, cosy_cosp)
                    self.state["attitude"].update(
                        {
                            "roll_deg": degrees(roll),
                            "pitch_deg": degrees(pitch),
                            "heading_deg": (degrees(yaw) or 0.0) % 360.0,
                        }
                    )
                    self._touch("attitude", now)

            elif kind == "AHRS2":
                roll = finite(getattr(msg, "roll", None))
                pitch = finite(getattr(msg, "pitch", None))
                yaw = finite(getattr(msg, "yaw", None))
                if roll is not None and pitch is not None:
                    self.state["attitude"].update(
                        {
                            "roll_deg": degrees(roll),
                            "pitch_deg": degrees(pitch),
                            "heading_deg": (degrees(yaw) or 0.0) % 360.0 if yaw is not None else self.state["attitude"].get("heading_deg"),
                        }
                    )
                    self._touch("attitude", now)

            elif kind == "GLOBAL_POSITION_INT":
                lat = int(msg.lat) / 1e7
                lon = int(msg.lon) / 1e7
                heading = None if int(msg.hdg) == 65535 else int(msg.hdg) / 100.0
                self.state["position"].update(
                    {
                        "lat": lat,
                        "lon": lon,
                        "relative_alt_m": int(msg.relative_alt) / 1000.0,
                        "amsl_alt_m": int(msg.alt) / 1000.0,
                        "ground_course_deg": heading,
                    }
                )
                self.state["speed"]["groundspeed_m_s"] = math.hypot(int(msg.vx), int(msg.vy)) / 100.0
                self.state["speed"]["vertical_speed_m_s"] = -int(msg.vz) / 100.0
                self._touch("position", now)
                self._touch("speed", now)
                self._update_track(lat, lon, now)
                self._update_home_geometry()
                self._update_flight_distance_locked(lat, lon, now)

            elif kind == "VFR_HUD":
                self.state["speed"].update(
                    {
                        "airspeed_m_s": finite(msg.airspeed),
                        "groundspeed_m_s": finite(msg.groundspeed),
                        "vertical_speed_m_s": finite(msg.climb),
                        "throttle_pct": finite(msg.throttle),
                    }
                )
                if self.state["position"].get("amsl_alt_m") is None:
                    self.state["position"]["amsl_alt_m"] = finite(msg.alt)
                if self.state["attitude"].get("heading_deg") is None:
                    self.state["attitude"]["heading_deg"] = finite(msg.heading)
                self._touch("speed", now)

            elif kind == "GPS_RAW_INT":
                eph = int(getattr(msg, "eph", 65535))
                self.state["gps"].update(
                    {
                        "fix_type": int(msg.fix_type),
                        "fix": gps_fix_name(int(msg.fix_type)),
                        "satellites": int(msg.satellites_visible) if int(msg.satellites_visible) != 255 else None,
                        "hdop": None if eph == 65535 else eph / 100.0,
                    }
                )
                self._touch("gps", now)

            elif kind == "SYS_STATUS":
                voltage = int(getattr(msg, "voltage_battery", 65535))
                current = int(getattr(msg, "current_battery", -1))
                remaining = int(getattr(msg, "battery_remaining", -1))
                self.state["battery"].update(
                    {
                        "voltage_v": None if voltage == 65535 else voltage / 1000.0,
                        "current_a": None if current < 0 else current / 100.0,
                        "remaining_pct": None if remaining < 0 else remaining,
                    }
                )
                self._touch("battery", now)
                if voltage != 65535:
                    self._update_battery_stabilization_locked(now)

            elif kind == "BATTERY_STATUS":
                voltages = [int(value) for value in getattr(msg, "voltages", []) if 0 < int(value) < 65535]
                if voltages:
                    self.state["battery"]["voltage_v"] = sum(voltages) / 1000.0
                    self.state["battery"]["cell_count"] = len(voltages)
                current = int(getattr(msg, "current_battery", -1))
                remaining = int(getattr(msg, "battery_remaining", -1))
                consumed = int(getattr(msg, "current_consumed", -1))
                self.state["battery"]["current_a"] = None if current < 0 else current / 100.0
                if remaining >= 0:
                    self.state["battery"]["remaining_pct"] = remaining
                if consumed >= 0:
                    self.state["battery"]["consumed_mah"] = consumed
                self._touch("battery", now)
                if voltages:
                    self._update_battery_stabilization_locked(now)

            elif kind == "HOME_POSITION":
                self.state["navigation"]["home_lat"] = int(msg.latitude) / 1e7
                self.state["navigation"]["home_lon"] = int(msg.longitude) / 1e7
                self._touch("home", now)
                self._update_home_geometry()

            elif kind == "RADIO_STATUS":
                self.state["link"].update(
                    {
                        "rssi": int(msg.rssi),
                        "remote_rssi": int(msg.remrssi),
                        "noise": int(msg.noise),
                        "remote_noise": int(msg.remnoise),
                        "rx_errors": int(msg.rxerrors),
                        "fixed_packets": int(msg.fixed),
                    }
                )
                self._touch("link", now)

            elif kind == "MISSION_CURRENT":
                self.state["navigation"]["waypoint_current"] = int(msg.seq)
                self._touch("mission", now)

            elif kind == "MISSION_ITEM_REACHED":
                self.state["navigation"]["waypoint_reached"] = int(msg.seq)
                self._touch("mission", now)

            elif kind == "NAV_CONTROLLER_OUTPUT":
                self.state["navigation"]["target_bearing_deg"] = finite(msg.target_bearing)
                self.state["navigation"]["distance_to_waypoint_m"] = finite(msg.wp_dist)
                self._touch("navigation", now)

            elif kind == "WIND":
                self.state["wind"].update(
                    {
                        "direction_deg": finite(msg.direction),
                        "speed_m_s": finite(msg.speed),
                        "vertical_m_s": finite(msg.speed_z),
                    }
                )
                self._touch("wind", now)

            elif kind == "RC_CHANNELS":
                count = max(0, min(18, int(getattr(msg, "chancount", 18) or 18)))
                values = []
                for index in range(1, count + 1):
                    value = int(getattr(msg, f"chan{index}_raw", 65535))
                    values.append(None if value == 65535 else value)
                self.state["rc"]["channels"] = values
                self._touch("rc", now)

            elif kind == "SERVO_OUTPUT_RAW":
                values = []
                for index in range(1, 17):
                    if not hasattr(msg, f"servo{index}_raw"):
                        break
                    value = int(getattr(msg, f"servo{index}_raw", 0))
                    values.append(value if value > 0 else None)
                self.state["servo"]["outputs"] = values
                self._touch("servo", now)

            elif kind == "STATUSTEXT":
                text = str(getattr(msg, "text", "") or "").rstrip("\x00").strip()
                if text:
                    item = {
                        "ts": time.time(),
                        "severity": severity_name(int(getattr(msg, "severity", 6))),
                        "severity_id": int(getattr(msg, "severity", 6)),
                        "text": text,
                        "system_id": msg.get_srcSystem(),
                        "component_id": msg.get_srcComponent(),
                    }
                    self.messages.append(item)
                    self.state["messages"] = list(self.messages)[-50:]
                    print(f"[GROUNDSTATION_MESSAGE] {item['severity']}: {text}", flush=True)

    def _update_track(self, lat: float, lon: float, now: float) -> None:
        minimum_interval = float(self.config.get("track", {}).get("minimum_interval_s", 0.8))
        if now - self.last_track_time < minimum_interval:
            return
        if self.last_track_position is not None:
            distance = haversine_m(self.last_track_position[0], self.last_track_position[1], lat, lon)
            if distance < 1.0:
                return
        self.track_sequence += 1
        self.track.append({
            "seq": self.track_sequence,
            "lat": lat,
            "lon": lon,
            "ts": time.time(),
        })
        self.last_track_time = now
        self.last_track_position = (lat, lon)

    def track_snapshot_since(self, since_sequence: int = 0) -> Dict[str, Any]:
        with self.lock:
            points = list(self.track)
            latest = int(self.track_sequence)
            oldest = int(points[0].get("seq", latest + 1)) if points else latest + 1
            reset = (
                since_sequence <= 0
                or since_sequence > latest
                or since_sequence < oldest - 1
            )
            if reset:
                selected = points
            else:
                selected = [
                    point for point in points
                    if int(point.get("seq", 0)) > since_sequence
                ]
            return {
                "ok": True,
                "reset": reset,
                "from_seq": oldest if points else latest,
                "to_seq": latest,
                "maximum_points": self.track.maxlen,
                "points": copy.deepcopy(selected),
            }

    def _update_home_geometry(self) -> None:
        position = self.state["position"]
        navigation = self.state["navigation"]
        values = (position.get("lat"), position.get("lon"), navigation.get("home_lat"), navigation.get("home_lon"))
        if any(value is None for value in values):
            navigation["home_distance_m"] = None
            navigation["home_bearing_deg"] = None
            return
        lat, lon, home_lat, home_lon = values
        navigation["home_distance_m"] = haversine_m(lat, lon, home_lat, home_lon)
        navigation["home_bearing_deg"] = bearing_deg(lat, lon, home_lat, home_lon)



    def _reset_flight_distance_locked(self, keep_current_position: bool = False) -> None:
        self.flight_distance_m = 0.0
        self.state["navigation"]["flight_distance_m"] = 0.0
        if keep_current_position:
            lat = finite(self.state["position"].get("lat"))
            lon = finite(self.state["position"].get("lon"))
            if lat is not None and lon is not None:
                self.flight_distance_last_position = (lat, lon)
                self.flight_distance_last_time = time.monotonic()
                return
        self.flight_distance_last_position = None
        self.flight_distance_last_time = None


    def _valid_gps_for_distance_locked(self) -> bool:
        fix_type = self.state.get("gps", {}).get("fix_type")
        try:
            return int(fix_type or 0) >= 2
        except Exception:
            return False


    def _update_flight_distance_locked(self, lat: float, lon: float, now: float) -> None:
        armed = self.state.get("vehicle", {}).get("armed") is True
        if not armed:
            self.flight_distance_last_position = (lat, lon)
            self.flight_distance_last_time = now
            self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)
            return
        if not self._valid_gps_for_distance_locked():
            self.flight_distance_last_position = (lat, lon)
            self.flight_distance_last_time = now
            self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)
            return
        if self.flight_distance_last_position is None:
            self.flight_distance_last_position = (lat, lon)
            self.flight_distance_last_time = now
            self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)
            return
        last_lat, last_lon = self.flight_distance_last_position
        step_distance = haversine_m(last_lat, last_lon, lat, lon)
        delta_t = max(0.05, now - (self.flight_distance_last_time or now))
        groundspeed = finite(self.state.get("speed", {}).get("groundspeed_m_s")) or 0.0
        max_reasonable_step = max(35.0, groundspeed * delta_t * 4.0 + 25.0)
        if 0.5 <= step_distance <= max_reasonable_step:
            self.flight_distance_m += step_distance
        self.flight_distance_last_position = (lat, lon)
        self.flight_distance_last_time = now
        self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)


    def _refresh_dynamic_telemetry_locked(self, now: float) -> float:
        armed_s = self.total_armed_s
        if self.armed_since is not None:
            armed_s += max(0.0, now - self.armed_since)
        self.state["timers"]["armed_s"] = armed_s
        self.state["timers"]["flight_time_text"] = format_hms(armed_s)
        self.state["timers"]["local_time_text"] = time.strftime("%H:%M:%S")
        self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)
        self._update_battery_percentage_locked()
        self._update_wind_indicator_locked()
        return armed_s

    def snapshot(self, include_track: bool = False) -> Dict[str, Any]:
        now = time.monotonic()
        with self.lock:
            self._refresh_dynamic_telemetry_locked(now)
            result = copy.deepcopy(self.state)
            result["track"] = copy.deepcopy(list(self.track)) if include_track else []
            result["track_meta"] = {
                "latest_seq": int(self.track_sequence),
                "points": len(self.track),
                "maximum_points": self.track.maxlen,
            }
            active = {key: ts for key, ts in self.vehicle_heartbeats.items() if now - ts <= 5.0}
            multiple = len(active) > 1
            heartbeat_age = None
            if self.selected_vehicle in active:
                heartbeat_age = max(0.0, now - active[self.selected_vehicle])
            degraded = float(self.config.get("warnings", {}).get("heartbeat_degraded_s", 3.0))
            lost = float(self.config.get("warnings", {}).get("heartbeat_lost_s", 5.0))
            if multiple:
                connection_state = "DEGRADED"
            elif heartbeat_age is None:
                connection_state = "NO_VEHICLE"
            elif heartbeat_age < degraded:
                connection_state = "CONNECTED"
            elif heartbeat_age <= lost:
                connection_state = "DEGRADED"
            else:
                connection_state = "LINK_LOST"
            result["connection"].update(
                {
                    "state": connection_state,
                    "heartbeat_age_s": heartbeat_age,
                    "system_id": self.selected_vehicle[0] if self.selected_vehicle else None,
                    "component_id": self.selected_vehicle[1] if self.selected_vehicle else None,
                    "multiple_vehicles": multiple,
                }
            )
            result["timers"]["connected_s"] = max(0.0, now - self.started_monotonic)
            armed_s = result["timers"].get("armed_s", 0.0)
            result["field_age_s"] = {
                key: round(max(0.0, now - timestamp), 3)
                for key, timestamp in self.field_times.items()
            }
            result["service"]["uptime_s"] = max(0.0, now - self.started_monotonic)
            result["service"]["config_path"] = str(CONFIG_PATH)
            return result


class GroundStationRuntime:
    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.vehicle = VehicleState(config)
        self.stop_event = threading.Event()
        self.connection = None

    def stop(self, *_args: Any) -> None:
        self.stop_event.set()
        if self.connection is not None:
            try:
                self.connection.close()
            except Exception:
                pass

    def mavlink_loop(self) -> None:
        mav_cfg = self.config["mavlink"]
        endpoint = f"udpin:{mav_cfg.get('host', '0.0.0.0')}:{int(mav_cfg.get('port', 14602))}"
        while not self.stop_event.is_set():
            try:
                print(f"[GROUNDSTATION_MAVLINK] opening {endpoint}", flush=True)
                self.connection = mavutil.mavlink_connection(
                    endpoint,
                    source_system=int(mav_cfg.get("system_id", 254)),
                    source_component=int(mav_cfg.get("component_id", 192)),
                    dialect="ardupilotmega",
                )
                while not self.stop_event.is_set():
                    message = self.connection.recv_match(blocking=True, timeout=0.5)
                    if message is not None:
                        self.vehicle.update(message)
            except Exception as exc:
                print(f"[GROUNDSTATION_MAVLINK_ERROR] {exc!r}", flush=True)
                time.sleep(1.0)
            finally:
                if self.connection is not None:
                    try:
                        self.connection.close()
                    except Exception:
                        pass
                    self.connection = None


RUNTIME: Optional[GroundStationRuntime] = None


class ApiHandler(BaseHTTPRequestHandler):
    server_version = "SIYIGroundStation/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        print("[GROUNDSTATION_HTTP] " + (fmt % args), flush=True)

    def _json(self, payload: Any, status: int = 200) -> None:
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        assert RUNTIME is not None
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query, keep_blank_values=False)
        if path == "/health":
            snapshot = RUNTIME.vehicle.snapshot()
            self._json(
                {
                    "ok": True,
                    "service": "siyi-groundstation",
                    "monitor_only": True,
                    "connection": snapshot["connection"],
                    "packet_count": snapshot["service"]["packet_count"],
                    "uptime_s": snapshot["service"]["uptime_s"],
                    "telemetry_canvas": {
                        "schema_version": TELEMETRY_LAYOUT_SCHEMA_VERSION,
                        "catalog_total": len(RUNTIME.vehicle.telemetry_catalog),
                        "config_path": str(TELEMETRY_LAYOUT_PATH),
                        "shadow_path": str(TELEMETRY_LAYOUT_SHADOW_PATH),
                    },
                }
            )
            return
        if path == "/state":
            include_track = str((query.get("include_track") or [""])[0]).lower() in {"1", "true", "yes"}
            self._json(RUNTIME.vehicle.snapshot(include_track=include_track))
            return
        if path == "/track":
            try:
                since = int((query.get("since") or ["0"])[0])
            except (TypeError, ValueError):
                since = 0
            self._json(RUNTIME.vehicle.track_snapshot_since(since))
            return
        if path == "/messages":
            snapshot = RUNTIME.vehicle.snapshot()
            self._json({"messages": snapshot.get("messages", [])})
            return
        if path == "/telemetry/catalog":
            self._json(RUNTIME.vehicle.telemetry_catalog_snapshot())
            return
        if path == "/telemetry/values":
            requested_keys: Optional[Set[str]] = None
            raw_keys = query.get("key", [])
            if not raw_keys and query.get("keys"):
                raw_keys = [
                    item
                    for value in query.get("keys", [])
                    for item in value.split(",")
                ]
            cleaned = {str(item).strip() for item in raw_keys if str(item).strip()}
            if cleaned:
                requested_keys = cleaned
            self._json(RUNTIME.vehicle.telemetry_values_snapshot(requested_keys))
            return
        if path == "/telemetry/layout":
            self._json(RUNTIME.vehicle.telemetry_layout_snapshot())
            return
        if path == "/stream":
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
            self.send_header("Connection", "keep-alive")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            last_payload = None
            last_keepalive = 0.0
            last_track_sequence = 0
            first_payload = True
            try:
                while not RUNTIME.stop_event.is_set():
                    snapshot = RUNTIME.vehicle.snapshot(include_track=False)
                    track_update = RUNTIME.vehicle.track_snapshot_since(last_track_sequence)
                    if first_payload or track_update["points"] or track_update["reset"]:
                        snapshot["track_update"] = track_update
                        last_track_sequence = int(track_update["to_seq"])
                    payload = json.dumps(snapshot, ensure_ascii=False, separators=(",", ":"))
                    now = time.monotonic()
                    first_payload = False
                    if payload != last_payload:
                        self.wfile.write(("data: " + payload + "\n\n").encode("utf-8"))
                        self.wfile.flush()
                        last_payload = payload
                        last_keepalive = now
                    elif now - last_keepalive >= 10.0:
                        self.wfile.write(b": keepalive\n\n")
                        self.wfile.flush()
                        last_keepalive = now
                    time.sleep(0.2)
            except (BrokenPipeError, ConnectionResetError, TimeoutError):
                pass
            return
        self._json({"error": "not found"}, 404)


    def do_POST(self) -> None:
        assert RUNTIME is not None
        path = self.path.split("?", 1)[0]
        if path != "/telemetry/layout":
            self._json({"error": "not found"}, 404)
            return
        try:
            length = int(self.headers.get("Content-Length", "0") or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > 1024 * 1024:
            self._json({"ok": False, "error": "invalid content length"}, 400)
            return
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            config = RUNTIME.vehicle.update_telemetry_layout(payload)
            self._json({
                "ok": True,
                "config": config,
                "path": str(TELEMETRY_LAYOUT_PATH),
                "shadow_path": str(TELEMETRY_LAYOUT_SHADOW_PATH),
            })
        except Exception as exc:
            self._json({"ok": False, "error": str(exc)}, 400)


def main() -> int:
    global RUNTIME
    config = load_config()
    if not bool(config.get("enabled", True)):
        print("[GROUNDSTATION] disabled in configuration", flush=True)
        return 0
    RUNTIME = GroundStationRuntime(config)
    thread = threading.Thread(target=RUNTIME.mavlink_loop, name="mavlink", daemon=True)
    thread.start()
    api_cfg = config["internal_api"]
    server = ThreadingHTTPServer((str(api_cfg.get("host", "127.0.0.1")), int(api_cfg.get("port", 18765))), ApiHandler)
    server.daemon_threads = True
    print(
        "[GROUNDSTATION] monitor-only daemon ready on "
        f"{api_cfg.get('host', '127.0.0.1')}:{int(api_cfg.get('port', 18765))}",
        flush=True,
    )
    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        RUNTIME.stop()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
