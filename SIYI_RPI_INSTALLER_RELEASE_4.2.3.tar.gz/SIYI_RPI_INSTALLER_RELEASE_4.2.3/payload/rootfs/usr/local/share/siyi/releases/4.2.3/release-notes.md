# FlightCore 4.2.3 RC3 — Factory V45

Controlled parent: exact accepted FlightCore 4.2.2 RC13, replayed through the RC1/RC2 factory transformations.

## RC3 defect corrections
- Air Link video recovery: reset WHEP decoded-frame progress whenever the WebRTC MediaStream/session changes. A new stream remains black / NO VIDEO until actual decoded-frame progress is observed, then becomes live once and remains live. This closes the physical RC2 Live -> NO VIDEO -> Live reconnect loop after a Majestic restart.
- Smooth Voltage accuracy: estimate practical relaxed/resting pack voltage rather than a conservative cruise-reference voltage. Full propulsion load is compensated relative to a learned low-load aircraft idle current; effective fast resistance adapts from short load steps; slow load-history polarization/recovery compensation decays as Raw Voltage relaxes.
- Normal amp draw, cruise remains a user setting for load classification/filter aggressiveness only; it is no longer subtracted from voltage compensation.
- Smooth Voltage/Battery %/spoken voltage remain display/voice only. Raw flight-controller voltage and FC battery safety logic remain authoritative.

## Retained RC2 behavior
- Air Link Majestic apply/reconnect/restart/rollback uses independent SSH management.
- Lost video clears the stale frame to black / NO VIDEO and automatically recreates WHEP.
- All 4.2.3 RC1 sprint workstreams remain present.

## Validation state
Offline Factory V45 validation: required before handover.
Physical RC2 -> RC3 native upgrade, Air Link recovery acceptance, Smooth Voltage flight validation and fresh-SD validation: pending.
