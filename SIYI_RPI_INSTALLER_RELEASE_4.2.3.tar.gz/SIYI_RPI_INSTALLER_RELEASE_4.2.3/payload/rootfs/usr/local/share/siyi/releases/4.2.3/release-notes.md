# FlightCore 4.2.3 RC2 — Factory V44

Controlled parent: exact accepted FlightCore 4.2.2 RC13.

## RC2 scope
- Air Link camera-link management: Majestic video0/video1 enable, resolution, FPS and bitrate; atomic apply/rollback; deterministic RTSP and MediaMTX synchronization.
- RC2: Majestic apply/reconnect/rollback now runs through independent SSH management instead of Majestic's own HTTP/CGI channel.
- RC2: video-source loss clears frozen frames to black/NO VIDEO and WHEP receivers automatically recover when the source returns; no Ground Station reload is required.
- Air Link hardware configuration moved into First Setup Wizard/normal settings ownership.
- Fresh-SD temporary browser installation progress/failure UI with deterministic terminal fallback.
- Telemetry editor is movable; placement storage uses normalized geometry; cross-host synchronization transfers groups, options and placement.
- Parameters mobile layout is constrained so desktop/Mac rendering remains on the desktop path.
- Loaded Ground Station survives Pi/network loss with explicit stale/disconnected state and reconnect behavior.
- Shared Mac/Android Ground Station gains mouse-accessible Map control and browser-native audio behavior.
- Generic UI terminology moves to FlightCore/Air Link while actual SIYI hardware/protocol references and internal compatibility identifiers remain.

## Protected unchanged behavior
- RC13 joystick loss/native ArduPlane GCS failsafe authority. The Pi does not command RTL or force flight modes on connection/control loss.
- RC7-style MAV_CMD_DO_GIMBAL_MANAGER_PITCHYAW command path and passive GIMBAL_DEVICE_ATTITUDE_STATUS feedback.
- RC12/RC13 Ground Station load bounds and telemetry proxy correction.
- Smooth Voltage/Battery % remain display/voice only; raw FC voltage remains safety-authoritative.

## Supported routes
- Fresh Raspberry Pi OS 64-bit / Debian 13 -> 4.2.3 RC2.
- Exact accepted 4.2.2 RC13 -> 4.2.3 RC2 native transactional upgrade.
