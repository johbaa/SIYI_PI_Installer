# FlightCore 4.2.3 RC5 — Factory V47

## RC5 mandatory corrections
- Fixes RC4 Air Link black-screen flicker: ordinary WHEP automatic receiver recovery/reconnect no longer means NO VIDEO. The established receiver recovery algorithm is left unchanged, while the visual loss state now requires 10 continuous seconds without decoded-frame progress. A recovered frame cancels the pending loss immediately.
- Keeps the last visible frame during ordinary WHEP recovery instead of hiding it.
- Fixes the shipped manual acceptance tool that RC4 post-upgrade validation found still hard-coded to a 4.2.1 RC14 build identity.
- Carries forward RC4 GitHub main-HEAD commit pinning, RC3 Air Link session-counter protection, and the RC3/RC4 relaxed/resting Smooth Voltage estimator unchanged.

## Evidence basis
The physical RC4 180-second Air Link diagnostic captured repeated browser WHEP session closes/recreates while `gs_wifilink` remained continuously ready and Air Link ping stayed up. Those reconnects matched the observed NO VIDEO flashes, proving the visual wrapper—not repeated Air Link source outages—was causing the flicker.

## Validation state
Offline Factory V47 validation and independent audit are required before handover. Physical RC4 -> RC5 native upgrade, 3+ minute no-flicker test, sustained-loss test, FPS-save recovery, Smooth Voltage flight validation and fresh-SD validation remain pending.

---

# FlightCore 4.2.3 RC4 — Factory V46

## RC4 mandatory corrections
- Carries forward the intended RC3 Air Link session-safe recovery fix: one black / NO VIDEO interval while the source is unavailable, LIVE only after decoded frames, no RC2 Live/NO VIDEO oscillation.
- Carries forward the intended RC3 Smooth Voltage redesign: estimate practical relaxed/resting pack voltage using adaptive fast sag plus slow load-history/recovery compensation. Raw FC voltage remains safety-authoritative.
- Fixes the failed-RC3 packaging defect: `/etc/siyi/release_build` is written as RC4 before manifest generation. A hard cross-file identity invariant blocks packaging if target identities or hashes disagree.
- Fixes delayed GitHub candidate visibility: Software Update resolves fresh `main` HEAD through the GitHub API and fetches release metadata from the immutable commit SHA instead of relying on a potentially stale raw `main` cache. Upgrade downloads and publication verification are commit-pinned as well.

## Validation state
Offline Factory V46 validation and independent audit are required before handover. Physical RC2 -> RC4 native upgrade, Air Link recovery, Smooth Voltage flight validation and fresh-SD validation remain pending.

---

# FlightCore 4.2.3 RC3 — Factory V45

Controlled parent: exact accepted FlightCore 4.2.2 RC13, replayed through the RC1/RC2 factory transformations.

## RC3 defect corrections
- Air Link video recovery: reset WHEP decoded-frame progress whenever the WebRTC MediaStream/session changes. A new stream remains black / NO VIDEO until actual decoded-frame progress is observed, then becomes live once and remains live. This closes the physical RC2 Live -> NO VIDEO -> Live reconnect loop after a Majestic restart.
- Smooth Voltage accuracy: estimate practical relaxed/resting pack voltage rather than a conservative cruise-reference voltage. Full propulsion load is compensated relative to a learned low-load aircraft idle current; effective fast resistance adapts from short load steps; slow load-history polarization/recovery compensation decays as Raw Voltage relaxes.
- Normal amp draw, cruise remains a user setting for load classification/filter aggressiveness only; it is no longer subtracted from voltage compensation.
- Smooth Voltage/Battery %/spoken voltage remain display/voice only. Raw flight-controller voltage and FC battery safety logic remain authoritative.

## Retained RC2 behavior
- Air Link Majestic apply/reconnect/restart/rollback uses independent SSH management.
- Lost video clears the stale frame to black / NO VIDEO and automatically recreates WHEP.
- All 4.2.3 RC1 sprint workstreams remain present.

## Validation state
Offline Factory V45 validation: required before handover.
Physical RC2 -> RC3 native upgrade, Air Link recovery acceptance, Smooth Voltage flight validation and fresh-SD validation: pending.
