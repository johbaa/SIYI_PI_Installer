# FlightCore 4.2.3 RC7 / Factory V49

RC7 is a correction candidate built from exact RC6 / Factory V48. It addresses the RC6 physical findings: Air Link apply/recovery, dual-Ground-Station video load and stale-live latency recovery, telemetry editor movement, cross-host telemetry geometry/profile usability, Parameters group scrolling, loaded-session connection banner overlap, and Mac top-banner parity.

Protected behavior is intentionally unchanged: the Ground Station daemon (including Smooth Voltage anti-drift/rest-anchor and consumed-mAh reconnect guard), joystick/button bridge, gimbal transport, and Pi/FC failsafe boundary are carried forward byte-for-byte.

# FlightCore 4.2.3 RC6 — Factory V48

Controlled parent: FlightCore 4.2.3 RC5 / Factory V47, itself derived through the accepted 4.2.2 RC13 release line. Production upgrade source remains exact accepted 4.2.2 RC13.

## RC6 fixes
- Smooth Voltage anti-drift: preserve correct takeoff/early-cruise sag compensation, prevent time-accumulated positive cruise drift, and converge to measured Raw voltage at genuine disarmed/low-load rest. User settings remain 75 mΩ and 6 A for the validated aircraft setup.
- Remove pilot-facing Smooth Voltage `LIMIT` text while retaining the internal correction safety clamp.
- Air Link settings apply/reconnect/restart now signals already-loaded Ground Stations to recreate the Air Link WHEP session automatically; no Ground Station reload should be required.
- Telemetry editor drag made robust; named telemetry profiles preserve groups, contents, columns, font size and placement and are reusable across hosts on the same Pi; JSON export/import supports transfer across Pi systems.
- Telemetry geometry keeps a last-known-complete backup and repairs only accidentally missing geometry fields for groups that still exist.
- ArduPlane Parameter Groups gets its own scrollbar; obsolete phone drawer X removed.
- Loaded-session disconnect/reconnect: keep receivers alive/retrying, show disconnected top-bar state, announce regained connection, restart visible video, and guard consumed mAh against reconnect-to-zero artifacts.
- Mac/Android top-bar visual parity; Map top button is hidden while a joystick is connected.
- System-wide generic branding audit: product-facing generic SIYI naming is replaced by FlightCore while real SIYI hardware/protocol and internal compatibility identifiers remain.

## Protected unchanged behavior
- Joystick/GCS/link loss never makes the Pi command RTL or force flight mode; MANUAL_CONTROL/source-255 heartbeat withdrawal leaves failsafe authority to the flight controller.
- RC7-style gimbal command transport/passive feedback remains protected.
- RC12/RC13 Ground Station load bounds and telemetry proxy behavior remain protected.
- Raw FC battery voltage remains safety-authoritative; Smooth Voltage/Battery % are display/voice only.
- RC5 silent WHEP-maintenance behavior and 10-second confirmed NO VIDEO threshold remain intact.

## Supported routes
- Fresh Raspberry Pi OS 64-bit / Debian 13 -> 4.2.3 RC6.
- Exact accepted 4.2.2 RC13 -> 4.2.3 RC6 native transactional upgrade.

## Acceptance status at factory handover
Extensive offline factory/static/regression validation must pass before handover. Hardware-dependent Air Link, Android/Mac reconnect, fresh-SD and flight checks remain physical RC acceptance gates and are not claimed by offline validation.
