# FlightCore 4.3.0 RC15

Canonical machine identity: `4.3.0-rc.15`.

RC15 corrects the confirmed SIYI cold-boot and stream-recovery defect:

- `gs_siyi` is the single owner of the physical SIYI RTSP-over-TCP connection.
- `main.264` is an internal compatibility alias, eliminating the duplicate camera pull.
- SIYI ingest starts only after `eth0` carrier, camera-route and RTSP TCP readiness pass.
- MediaMTX and Air Link remain available while the SIYI camera is unavailable.
- Source-start failure and packet stalls recover with bounded backoff and no blind MediaMTX restart loop.
- SIYI health exposes source readiness, reconnect count and source epoch.
- Ground Station rebuilds only the SIYI WHEP/decoder session after an epoch change or decoded-frame stall.
- Air Link remains isolated from SIYI recovery.
- Release Notes, User Manual and Installation Guide describe the corrected behavior.

RC14 release discovery and installer-integrity corrections remain intact. RC15 changes no user settings, defaults, migrations, preservation rules, LTE Health, TURN HOME, Smooth Voltage or flight-control authority.
