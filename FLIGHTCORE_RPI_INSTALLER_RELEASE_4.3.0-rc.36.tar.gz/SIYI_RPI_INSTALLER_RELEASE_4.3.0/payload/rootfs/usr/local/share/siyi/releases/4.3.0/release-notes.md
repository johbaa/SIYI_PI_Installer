# FlightCore 4.3.0 RC36

Canonical machine identity: `4.3.0-rc.36`. Build: `20260822.003000-36f2c18`.

RC36 replaces the rejected RC35 candidate. RC35 edited the original Ground Station template before the historical compatibility wrappers ran. The RC12 wrapper therefore could not find its required marker, raised a runtime exception, and `/groundstation` returned an empty reply. The post-reboot acceptance gate correctly refused RC35.

## Correction

- Starts from the exact accepted RC34 source bytes.
- Applies the Airlink stale-media-element recovery only after every historical Ground Station wrapper has completed.
- Adds a factory runtime gate that imports the shipped `server.py`, renders both Ground Station routes, and verifies the resulting document before publication.
- Replaces only the stale Airlink video element on a genuine new MediaStream generation.
- Accepts recovery only after the browser reports a decoded frame; no Ground Station reload or manual recovery control is used.

## Preserved behaviour

- No WiFiLink firmware, WiFi profile, router, ZeroTier, telemetry, joystick, flight-control, SIYI video, Ground Station layout, Control Center or log-storage behaviour is changed from RC34.
- Existing clean historical upgrade routes remain checksum-pinned; exact accepted RC34 is the controlled parent for RC36.

## Acceptance

- Publication requires the full fifteen-phase factory gate, exact payload fingerprinting, a real server-module Ground Station render test and the browser media-element fixture.
- Physical Airlink power-interruption recovery and the continuity soak remain external bench gates and are not claimed by publication.
