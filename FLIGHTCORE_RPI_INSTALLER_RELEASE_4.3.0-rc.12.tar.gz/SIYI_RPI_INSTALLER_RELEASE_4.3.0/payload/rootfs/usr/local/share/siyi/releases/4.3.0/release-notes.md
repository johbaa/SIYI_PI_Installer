# FlightCore 4.3.0 RC12

Canonical machine identity: `4.3.0-rc.12`.

RC12 retains the complete RC11 scope and corrects final health validation to compare the installed marker with canonical release_identity while preserving the legacy metadata fallback. All advisory features retain no flight-control authority.
