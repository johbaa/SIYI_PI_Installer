# FlightCore 4.3.0 RC33

Canonical machine identity: `4.3.0-rc.33`. Build: `20260821.170000-33f4b76`.

RC33 completes the Airlink correction after RC32 proved that the original canonical receiver did not recover automatically after camera power interruption.

## Corrections

- Implements automatic Airlink recovery directly inside the canonical GroundStationWhepPlayer.
- Uses one readiness-gated retry timer with 2/4/8/15/30 second backoff.
- Keeps the current/last stream untouched while the Airlink source is unavailable.
- Creates one replacement WHEP connection only after source readiness returns.
- Requires decoded Airlink frames before resetting recovery backoff and declaring live.
- Detects decoded-frame stalls without reloading Ground Station.
- Includes no manual Recover Airlink button, injected recovery owner or startup takeover.

## Preserved behavior

SIYI video, telemetry, joystick, flight modes, flight-control authority, Flight Logs, cloud compatibility and storage controls are unchanged.

## Validation boundary

Factory validation covers canonical ownership, retry serialization, readiness gating, decoded-frame confirmation, exact RC32 upgrade identity, packaging and safety isolation. Physical Android power-interruption and recovery acceptance remains required.
