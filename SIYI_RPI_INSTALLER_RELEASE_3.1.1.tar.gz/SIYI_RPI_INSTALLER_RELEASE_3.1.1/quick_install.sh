#!/bin/bash

# === SIYI 3.1.1 FLAPS CONFIG START ===
SIYI_FLAPS_INSTALL_DIR="$(
    cd "$(dirname "$0")" &&
    pwd
)"

sudo mkdir -p /etc/siyi

if [ ! -e /etc/siyi/flaps.json ] &&
   [ -f "$SIYI_FLAPS_INSTALL_DIR/config/flaps.json" ]; then

    sudo install \
        -o pi \
        -g pi \
        -m 664 \
        "$SIYI_FLAPS_INSTALL_DIR/config/flaps.json" \
        /etc/siyi/flaps.json
fi
# === SIYI 3.1.1 FLAPS CONFIG END ===


set -e

echo "Downloading SIYI installer..."

cd /home/pi
wget -O siyi_installer.tar.gz "${SIYI_INSTALLER_URL:?Set SIYI_INSTALLER_URL to the release tarball URL}"

tar -xzf siyi_installer.tar.gz
cd SIYI_PUBLIC_INSTALLER

chmod +x install.sh
./install.sh
