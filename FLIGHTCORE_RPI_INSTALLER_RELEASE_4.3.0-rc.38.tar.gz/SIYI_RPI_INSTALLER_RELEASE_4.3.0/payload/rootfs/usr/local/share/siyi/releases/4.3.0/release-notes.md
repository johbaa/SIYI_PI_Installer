# FlightCore 4.3.0 RC38

Canonical machine identity: `4.3.0-rc.38`. Build: `20260824.182435-dd98547`.

RC38 corrects the Android Air Link media-recovery lifecycle identified during RC37 physical testing. RC37's optimized display-unit implementation is retained unchanged.

## Changes

- Makes the canonical `GroundStationWhepPlayer` the sole owner of the Air Link WebRTC lifecycle.
- Removes the legacy RC7 rendered-frame watchdog as an independent reconnect owner.
- Treats a decoded-frame stall as a browser-decoder condition while the WebRTC peer remains healthy.
- Retains the existing WebRTC session, media stream, track and video element during soft decoder recovery.
- Removes Air Link video-element cloning and explicit track stopping from transient recovery.
- Prevents a rejected `video.play()` request from initiating another destructive decoder/WHEP restart.
- Resumes the existing healthy Air Link session when Android returns from Control Center or the browser page resumes.
- Preserves automatic WHEP recovery for confirmed peer failure, sustained network disconnect, source-epoch changes and explicit manual resync.
- Adds exact checksum-pinned upgrade support from accepted RC37 while retaining the existing RC36, RC6 and historical supported routes.

## Evidence basis

The RC37 physical capture showed that the Pi, services, HTTP telemetry, SIYI stream and Air Link RTSP ingest remained healthy. The Android Air Link receiver nevertheless restarted repeatedly after `sustained decoded-frame stall`, including restart generations at approximately one-minute intervals and browser `play()` interruptions caused by new load requests. RC38 removes that competing/destructive recovery chain.

## Preserved behavior

- RC37 multi-unit display preferences and integrated single-pass unit rendering are unchanged.
- Canonical telemetry storage and transport remain in SI units.
- SIYI recovery, MediaMTX configuration, camera codec/resolution/frame rate and ZeroTier behavior are unchanged.
- No flight-control, MAVLink, joystick, gimbal, button, autopilot, failsafe, logging or cloud behavior changes.
- Flight-controller native GCS failsafe authority remains unchanged.
- Genuine fresh installation remains supported.

## Validation status

- Exact accepted RC37 parent archive and payload identity: passed.
- Python, shell, JSON and generated JavaScript validation: passed.
- Single-owner and non-destructive Air Link lifecycle assertions: passed.
- Protected runtime hashes and safety-negative checks: passed.
- Payload manifest, archive, publication bundle and deterministic replay: passed.
- Physical Android screen-recorder and dual-stream acceptance: pending after publication and native upgrade.
