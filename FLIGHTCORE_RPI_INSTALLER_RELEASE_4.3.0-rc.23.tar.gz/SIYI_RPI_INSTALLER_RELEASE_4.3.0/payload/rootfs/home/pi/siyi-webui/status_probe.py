#!/usr/bin/env python3
# FLIGHTCORE_4_3_0_RC7_STATUS_BAR_CACHE_RENDERER_V1
# Request-path safe: performs no ping, nmcli, zerotier-cli or other subprocess.
import html, json, time
from pathlib import Path
CACHE=Path('/run/flightcore/status-cache.json')
MAV=Path('/tmp/siyi_flight_mode.json')

def load(path,default):
    try:return json.loads(Path(path).read_text())
    except Exception:return default

def recent_mav():
    d=load(MAV,{})
    try:return time.time()-float(d.get('last_seen',0))<=6
    except Exception:return False

def battery():
    try:return Path('/tmp/siyi_battery_status.txt').read_text().strip() or 'Bat ?'
    except Exception:return 'Bat ?'
def loadtxt():
    try:return 'CPU '+Path('/proc/loadavg').read_text().split()[0]
    except Exception:return 'CPU ?'
def temp():
    try:return f"Temp {int(Path('/sys/class/thermal/thermal_zone0/temp').read_text())/1000:.1f}°C"
    except Exception:return 'Temp ?'

def pill(txt,cls,link=''):
    txt=html.escape(str(txt))
    if link:return f'<a class="status-pill {cls}" style="cursor:pointer;text-decoration:none" href="{link}">{txt}</a>'
    return f'<span class="status-pill {cls}">{txt}</span>'

d=load(CACHE,{})
age=999
try:age=time.time()-float(d.get('updated_at',0))
except Exception:pass
fresh=age<=35
items=[pill(battery(),'ok','/cpu_temp_voice')]
for key,label in [('network','Network'),('camera','Camera'),('zerotier','ZT')]:
    ok=fresh and bool((d.get(key) or {}).get('ok'))
    items.append(pill(label+' OK' if ok else label+' Down','ok' if ok else 'bad'))
items.append(pill('MAVLink OK' if recent_mav() else 'MAVLink Down','ok' if recent_mav() else 'bad'))
hosts=d.get('hosts') if fresh else []
if isinstance(hosts,list) and hosts:
    ok=sum(1 for h in hosts if isinstance(h,dict) and h.get('ok'))
    cls='ok' if ok==len(hosts) else ('warn' if ok else 'bad')
    items.append(pill(f'Ext MAV {ok}/{len(hosts)}',cls))
items.extend([pill(loadtxt(),'ok'),pill(temp(),'ok','/cpu_temp_voice')])
print('<div id="top-status-bar">'+''.join(items)+'</div>')
