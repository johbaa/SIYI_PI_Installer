# FlightCore 4.3.0 RC20

Canonical machine identity: `4.3.0-rc.20`. Build: `20260819.103000-6f8a2c1`. Factory model: `FLIGHTCORE_4_3_0_COMPLETE_TARGET_MODEL_V86`.

RC20 corrects the failures proven by the RC19 field diagnostic. Its native upgrade matrix includes exact RC6/Factory V71, accepted RC17, accepted RC18 and installed accepted RC19, plus genuine fresh installation.

## Local Flight Logs

- Selecting a flight immediately opens a visible loading state.
- The viewer receives only chart/event fields; original forensic JSONL is unchanged.
- Samples load in pages of 250 and events in pages of 125.
- Each page has a 20-second bound and up to three automatic attempts.
- The existing all-in-one detail API remains available for backward compatibility.
- RC18 chart bounds, visible-window Y scaling, viewer-local timestamps and source version/build display remain active.

## Cloud Flight Logs

- One completed flight is handled per invocation, newest first.
- Large logs upload samples and events as separate checksum-confirmed chunks.
- Confirmed chunk hashes persist across interruptions, so retries resume without retransmitting them.
- The service has a fifteen-minute execution budget.
- The final `chunked-v2` manifest contains only compact descriptors and remains below the Registry manifest ceiling.
- Registry v13 retains reads for sample-only `chunked-v1` and legacy single-object logs.
- A deferred RC18 receipt remains deferred across installation and retries automatically while disarmed after RC20 starts.
- Local source logs are never modified or deleted by synchronization.

## Preserved behavior

TURN HOME calculations and forecast isolation, SIYI H.265 1080p25 recovery, Air Link, joystick/control paths, and flight-controller failsafe authority are unchanged from RC18.

## Acceptance status

Factory automation includes the realistic 2,750-sample/1,289-event flight shape, composition tests and interrupted-upload resume tests. Physical RC19 upgrade, automatic deferred upload, Local UI and Cloud UI readback remain explicit external gates.
