#!/usr/bin/env python3
# FLIGHTCORE_4_3_0_RC7_ASYNC_STATUS_CACHE_V1
# Background-only reachability collector. No flight-control interaction.
import json, os, re, subprocess, tempfile, time
from pathlib import Path

CACHE=Path('/run/flightcore/status-cache.json')
ENDPOINTS=Path('/etc/siyi/endpoints.json')
CONFIG=Path('/home/pi/siyi-config.json')
INTERVAL=10.0

def run(argv, timeout=3.0):
    try:
        cp=subprocess.run(argv,text=True,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,timeout=timeout,check=False)
        return (cp.stdout or '').strip(), cp.returncode
    except Exception:
        return '',124

def ping(ip):
    ip=str(ip or '').strip()
    # Host addresses are configuration input. Never interpolate them into a shell.
    if not ip or len(ip)>253 or any(c.isspace() for c in ip):
        return {'ok':False,'latency_ms':None}
    out,rc=run(['/usr/bin/ping','-c','1','-W','1',ip],2.5)
    m=re.search(r'time[=<]([0-9.]+)',out)
    received=('1 received' in out or '1 packets received' in out)
    return {'ok':rc==0 and received,'latency_ms':float(m.group(1)) if m else None}

def read_json(path,default):
    try:return json.loads(Path(path).read_text())
    except Exception:return default

def default_gateway():
    out,_=run(['/usr/sbin/ip','route'],2.0)
    for line in out.splitlines():
        parts=line.split()
        if parts[:1]==['default'] and 'via' in parts:
            try:return parts[parts.index('via')+1]
            except Exception:return ''
    return ''

def wifi_state():
    out,_=run(['/usr/bin/nmcli','-t','-f','GENERAL.STATE','dev','show','wlan0'],2.5)
    return out.split(':',1)[1].strip() if ':' in out else out.strip()

def hosts():
    data=read_json(ENDPOINTS,[])
    if not isinstance(data,list):return []
    out=[]
    for e in data:
        if not isinstance(e,dict):continue
        ip=str(e.get('ip') or '').strip()
        if not ip:continue
        out.append({'name':str(e.get('name') or ip).strip() or ip,'ip':ip,**ping(ip)})
    return out

def collect():
    cfg=read_json(CONFIG,{})
    camera_ip=str(cfg.get('camera_ip') or '192.168.144.25').strip()
    nm=wifi_state(); gw=default_gateway(); gp=ping(gw) if gw else {'ok':False,'latency_ms':None}; cam=ping(camera_ip)
    zti,_=run(['/usr/sbin/zerotier-cli','info'],3.0)
    ztn,_=run(['/usr/sbin/zerotier-cli','listnetworks'],3.5)
    zt_ok=('ONLINE' in zti) and ((' OK ' in (' '+ztn.replace('\t',' ')+' ')) or any(Path('/sys/class/net').glob('zt*')))
    payload={
      'schema':1,'updated_at':time.time(),
      'network':{'ok':bool(gw) and gp['ok'],'wifi_state':nm,'gateway':gw,'gateway_ping':gp},
      'camera':{'ok':cam['ok'],'ip':camera_ip,'latency_ms':cam['latency_ms']},
      'zerotier':{'ok':zt_ok,'info':zti[:200]},
      'hosts':hosts(),
    }
    CACHE.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.status-cache.',dir=str(CACHE.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as f:
            json.dump(payload,f,separators=(',',':'));f.write('\n');f.flush();os.fsync(f.fileno())
        os.chmod(tmp,0o644);os.replace(tmp,CACHE)
    finally:
        try:
            if os.path.exists(tmp):os.unlink(tmp)
        except Exception:pass

def main():
    while True:
        started=time.monotonic()
        try:collect()
        except Exception:pass
        time.sleep(max(1.0,INTERVAL-(time.monotonic()-started)))
if __name__=='__main__':main()
