# FlightCore 4.3.0 RC13 acceptance checklist

- [x] RC12 Ground Station daemon retained byte-identically.
- [x] RC12 gimbal and FC-native failsafe bridge retained byte-identically.
- [x] Browser telemetry proxy parses URL and preserves queries.
- [x] Full telemetry catalogue/editor requests work through WebUI.
- [x] Selected flight telemetry requests work through WebUI.
- [x] Request-handler `time` shadowing removed.
- [x] Offline proxy-to-daemon, JavaScript, load and package tests passed.
- [x] Host-safe RC13 Registry, First Setup, branding, ZeroTier and negative TURN HOME regressions pass.
- [ ] Exact Registry compatibility freeze passes for RC13.
- [ ] Exact required-source -> RC13 native WebUI upgrades pass.
- [ ] Genuine fresh-SD public one-touch RC13 installation passes.
- [ ] All 15 factory phases pass against the exact immutable RC13 archive.
- [ ] Existing telemetry groups visibly update on Android.
- [ ] Physical gimbal regression check passes.
- [ ] 30-minute actual 4G/ZeroTier/video/joystick soak passes.
- [ ] Controlled flight acceptance passes.
