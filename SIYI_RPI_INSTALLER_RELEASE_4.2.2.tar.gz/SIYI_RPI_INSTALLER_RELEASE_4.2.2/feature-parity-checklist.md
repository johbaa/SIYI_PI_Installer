# SIYI 4.2.2 RC9 acceptance checklist

- [x] Candidate C physical gimbal acceptance: presets, pitch sign, center, absolute 1.0x zoom, hold ramp and live position feedback.
- [ ] Exact accepted RC8/Candidate C -> RC9 native same-version WebUI upgrade passes.
- [ ] 4.2.1 RC28 -> RC9 native WebUI upgrade passes.
- [ ] 4.2.0 RC23 -> RC9 native WebUI upgrade passes.
- [ ] Genuine fresh-SD installation passes.
- [ ] RC9 post-upgrade physical gimbal behavior matches Candidate C.
- [ ] Flight validation of Smooth Voltage and Battery % passes.
- [ ] Raw FC voltage and aircraft safety behavior remain unchanged.
