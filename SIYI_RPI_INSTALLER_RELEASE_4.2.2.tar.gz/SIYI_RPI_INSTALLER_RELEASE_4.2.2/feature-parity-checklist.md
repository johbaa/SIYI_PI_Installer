# SIYI 4.2.2 RC3 acceptance checklist

## RC3 source-gate acceptance

- [ ] Clean published 4.2.1 RC28 is identified as `published_4.2.1_rc28`.
- [ ] Exact patched development RC28 is identified as `development_compact_v2_thin_v4_bright_v5_bearing_v7`.
- [ ] Any different server or daemon checksum remains rejected.
- [ ] RC3 source verification performs no wildcard or marker-only acceptance.

## Upgrade paths

- [ ] Genuine 4.2.1 RC28 -> 4.2.2 RC3 WebUI upgrade passes.
- [ ] Genuine 4.2.0 RC23 -> 4.2.2 RC3 WebUI upgrade passes.
- [ ] Fresh public-curl installation passes.
- [ ] All paths converge to the same canonical fingerprint.

## Wind flight acceptance

- [ ] `x.x m/s` is visible whenever MAVLink WIND speed is available.
- [ ] Flying directly into the wind: arrow points downward.
- [ ] Flying directly with the wind: arrow points upward.
- [ ] Crosswind direction agrees with the 4.2.1 first-generation indicator.
- [ ] Heading-only fallback operates only while stationary/on the bench.
- [ ] Loss of wind direction in flight freezes the last valid arrow instead of following aircraft heading.

## Smooth Voltage flight acceptance

- [ ] Raw Voltage, Current, Throttle and Smooth Voltage are visible together.
- [ ] Short gust/turn current changes do not make Smooth Voltage pump down and back up.
- [ ] Smooth Voltage does not rise while armed.
- [ ] A genuine lower compensated baseline is confirmed before Smooth Voltage decreases.
- [ ] Takeoff clamp remains bounded by `0.20 V/cell` above instantaneous raw voltage.
- [ ] Raw warning colors, alerts and FC failsafes are never delayed or suppressed.
