# SIYI 4.2.2 RC10 acceptance checklist

- [x] Candidate C physical gimbal acceptance.
- [x] RC9 failure cause captured and rollback completed.
- [x] Runtime-state migration V4 preserves and relocates bridge backup artifacts before source verification.
- [ ] Exact accepted RC8/Candidate C -> RC10 native same-version WebUI upgrade passes.
- [ ] RC10 post-upgrade physical gimbal behavior matches Candidate C.
- [ ] 4.2.1 RC28 -> RC10 native WebUI upgrade passes.
- [ ] 4.2.0 RC23 -> RC10 native WebUI upgrade passes.
- [ ] Genuine fresh-SD installation passes.
- [ ] Flight validation of Smooth Voltage and Battery % passes.
