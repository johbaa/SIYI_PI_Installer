# SIYI 4.2.2 RC8 acceptance checklist

- [ ] Exact accepted RC7 -> RC8 native same-version WebUI upgrade passes.
- [ ] 4.2.1 RC28 -> RC8 native WebUI upgrade passes.
- [ ] 4.2.0 RC23 -> RC8 native WebUI upgrade passes.
- [ ] Genuine fresh-SD installation passes.
- [ ] Takeoff/high-current transient holds the last established Smooth Voltage without partial sag leakage.
- [ ] Stable cruise evidence can establish a realistic lower post-takeoff Smooth Voltage.
- [ ] Compensation is zero at configured Normal amp draw, cruise and applies only above that reference.
- [ ] Landing behavior contains no artificial low-current compensation.
- [ ] Battery % recalculates continuously while armed and does not latch an early low value.
- [ ] Battery % uses Smooth first, Raw fallback, fixed endpoints and strict 0–100% clamping.
- [ ] Left Motor and Right Motor gimbal presets move to their configured yaw/pitch angles.
- [ ] GIMBAL_CENTER_AND_ZOOM_OUT centers the primary gimbal and performs full zoom-out.
- [ ] Gimbal manager commands receive accepted/in-progress COMMAND_ACK results.
- [ ] Raw FC voltage and aircraft safety behavior remain unchanged.
