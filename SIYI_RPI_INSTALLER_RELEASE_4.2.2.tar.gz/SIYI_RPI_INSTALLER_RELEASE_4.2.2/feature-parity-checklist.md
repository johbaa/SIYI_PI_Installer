# SIYI 4.2.2 RC5 acceptance checklist

- [ ] RC4 -> RC5 native UI shows real progress through dependency install.
- [ ] Technical details update live without auto-scroll.
- [ ] Final WebUI restart preserves last real stage and percent.
- [ ] 4.2.1 RC28 -> RC5 passes.
- [ ] 4.2.0 RC23 -> RC5 passes.
- [ ] Fresh install passes.
- [ ] Normal amp draw, cruise setting persists.
- [ ] Smooth Voltage holds through gusts/turns and only declines on confirmed stable-load evidence.
- [ ] Stable current below preferred band remains usable.
- [ ] Moderately higher stable current uses longer weighted confirmation.
- [ ] Wind headwind-down/tailwind-up and m/s validated in flight.
