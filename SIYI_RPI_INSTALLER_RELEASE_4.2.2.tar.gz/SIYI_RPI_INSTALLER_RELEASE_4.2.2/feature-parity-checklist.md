# SIYI 4.2.2 RC11 acceptance checklist

- [x] Exact RC7 gimbal command and passive feedback functions restored.
- [x] RC9/RC10 direct SIYI attitude polling removed.
- [x] RC10 Smooth Voltage and Battery percentage corrections retained.
- [x] Automated preset/center/hold/ramp/stop command replay passes.
- [x] Passive gimbal idle soak produces no camera requests and no file writes.
- [x] 200,000-packet joystick/session/failsafe exposure soak passes with bounded memory.
- [x] Pi failsafe path sends no RTL or mode command.
- [ ] Exact accepted RC10 -> RC11 native WebUI upgrade passes.
- [ ] Physical left/right presets, four hold directions/ramp, live position and BACK center/zoom pass.
- [ ] FC-native GCS failsafe configuration is valid and observed on a propeller-removed bench test.
- [ ] 4.2.1 RC28 -> RC11 route passes.
- [ ] 4.2.0 RC23 -> RC11 route passes.
- [ ] Fresh SD -> RC11 route passes.
- [ ] Flight acceptance passes.
