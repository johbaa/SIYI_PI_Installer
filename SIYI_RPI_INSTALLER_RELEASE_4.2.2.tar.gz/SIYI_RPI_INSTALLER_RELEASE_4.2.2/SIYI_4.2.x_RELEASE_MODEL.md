# SIYI 4.2.x complete-target release model V13

Each release is one complete authoritative target package. Fresh installation and every supported upgrade route differ only in source verification and preservation preparation; all routes deploy the same target payload and must converge to the same immutable fingerprint.

Permanent rules:

1. The previous accepted release package is the build baseline.
2. Every supported source is validated by version, build, accepted status, exact source manifest, and complete immutable managed-file identity.
3. User-selectable and always-preserved settings are restored only through the declared preservation model.
4. A root-owned transaction snapshot is completed before target mutation.
5. Install, native upgrade, post-reboot acceptance, rollback, repair, and manual acceptance share one global lock.
6. Failed transactions restore content, type, ownership, mode, timestamps, symlinks, service state, boot files, package delta, runtime identity, and source release metadata.
7. Unexpected files in SIYI-managed namespaces are removed or rejected; explicit runtime state is excluded.
8. Post-reboot acceptance uses transaction-pinned checksum-verified recovery evidence.
9. Successful routes remove obsolete source release trees and full transaction backups, leaving compact acceptance history.
10. A release is not promoted until fresh, every supported upgrade source, rollback injection, hardware, and canonical convergence tests pass.

## V13 source identity refinement

The source gate verifies all active immutable managed files. Only explicitly classified non-active backup, diagnostic-log, and current native-installer staging artifacts are excluded. Symlink targets remain checksum-verified; symlink uid/gid is not identity-bearing.

## V13 native-upgrade health semantics

The installed source is health-checked before mutation. During the genuine native WebUI route, `/groundstation` and `/parameters` are deliberately HTTP 423 while the update lock is active. Only those exact failures may be waived, and only when the active state file proves the exact source and target and both endpoints are observed returning 423.

## V13 expected-failure and ERR-trap rule

Commands whose nonzero status is an expected input to a later decision must be executed in an `if`, `while`, `until`, `&&`, or `||` conditional context. `set +e` alone is forbidden for this purpose because an installed Bash `ERR` trap still fires. Factory validation executes a regression harness proving that the source-health nonzero result reaches the maintenance gate without rollback.

## V13 declarative directory-mode rule

Directory ownership and mode are release metadata, not properties to infer from a checkout, ZIP extraction directory, shared build volume, umask, default ACL, or setgid parent. The factory imports modes for inherited directories from the approved source manifest and requires an explicit mode for every target-only directory. Special mode bits are fail-closed. Runtime gates that require exact modes use separate creation, ownership and special-bit-clearing mode operations because `install -d -m` does not normalize every pre-existing directory state.


## RC18 / Factory V16

Pre-reboot source-release coexistence is passed explicitly across privilege boundaries.

## RC19 / Factory V17

Fresh-OS dependency provisioning is a prerequisite phase. It completes before package, unit-state, and filesystem transaction baselines are captured. The release transaction therefore remains exact without attempting unavailable package downgrades. The terminal progress renderer is column-bounded and single-line on every supported TTY width.

## RC20 / Factory V18

Adds markerless fresh-install namespace cleanup and immediate failed-fresh-runner termination. Immutable target verification is unchanged and remains mandatory after release markers are written.

## RC26 / Factory V20

Adds route-aware completion URL selection. The initiating SSH route is captured before sudo, preserved through the root re-exec, and preferred over all interface enumeration. Camera-management addresses are never advertised as the WebUI LAN URL.

## RC27 / Factory V26

RC27 removes a runtime diagnostic log from the immutable direct `/home/pi` namespace and makes the WebUI disconnect phase explicitly indeterminate with live elapsed/reconnect feedback. Release acceptance consists of the genuine native WebUI upgrade and fresh installation only.

## RC28 / Factory V27

Runtime artifacts produced by normal user configuration are stored outside immutable managed namespaces. Configured source systems are normalized before identity verification, and both physical acceptance paths include real initial configuration before final fingerprint and health acceptance.

## 4.2.2 RC1 / Factory V29

4.2.2 supports fresh installation and upgrades from accepted 4.2.0 and 4.2.1. Runtime-state migration occurs before source identity verification. Display-only battery stabilization never replaces raw FC safety data.

## 4.2.2 RC2 / Factory V30

RC2 preserves all RC1 install/upgrade routes. Wind rendering is explicitly regression-locked to 4.2.1 headwind-down/tailwind-up behavior and reads speed directly from normalized WIND telemetry. Smooth Voltage is a display-only robust resting-voltage tracker with transient hold, persistent-drop confirmation and monotonic armed behavior.

## 4.2.2 RC3 / Factory V31

RC3 preserves the RC2 functional target and repairs only the strict 4.2.1 source catalog. The verifier now supports checksum-pinned per-variant mode expectations. The exact known V1/V2/V4/V5/V7 development chain is accepted; all unlisted content remains rejected.

## 4.2.2 RC4 / Factory V32

RC4 preserves the functional target and repairs the native maintenance health decision. Exact source identity verification remains mandatory. The gate waives only enumerated consequences of the proven HTTP 423 maintenance lock and records the source-verification report in its evidence.

## RC5 / Factory V33

Cruise-aware downward-only voltage tracker, live native-upgrade progress, and checksum-pinned RC4 same-version candidate route.


## 4.2.2 RC8 / Factory V36

RC8 is based exactly on accepted RC7. It corrects the globally aggressive Smooth Voltage compensation model, removes takeoff partial-sag display clamping, removes the armed Battery % minimum latch, and repairs gimbal preset/center command transport with primary-device body-frame commands and matching COMMAND_ACK validation.


## 4.2.2 RC9 / Factory V37

RC9 is based exactly on RC8 plus the physically accepted Candidate C gimbal implementation. Preset taps and BACK use native SIYI UDP commands, manual hold retains the MAVLink 25→65°/s rate ramp, and displayed gimbal position comes from direct SIYI attitude feedback. The RC8 Smooth Voltage and Battery % corrections are retained unchanged.


## 4.2.2 RC10 / Factory V38

RC10 retains the exact physically accepted Candidate C gimbal implementation and RC8 battery correction. It supersedes rejected RC9 by adding runtime-state migration V4, which preserves and relocates direct bridge backup artifacts from the managed `/home/pi` namespace before source verification.

## 4.2.2 RC11 / Factory V39

RC11 is based exactly on accepted RC10 battery and Ground Station code, but restores the complete field-proven RC7 gimbal command and passive attitude path. The RC9/RC10 direct SIYI attitude polling loop is removed. Joystick/session loss now withdraws Pi source-system-255 manual-control and heartbeat paths without issuing any mode command, leaving the configured flight-controller MAVLink/GCS failsafe fully authoritative.

## 4.2.2 RC12 / Factory V40

RC12 retains the accepted RC11 gimbal and FC-native failsafe-exposure bridge byte-identically. It bounds Ground Station load by removing the full historical track from repeated state frames, sending per-client incremental track deltas, limiting telemetry values to selected keys, closing hidden WHEP receivers, reducing polling, fixing the WebUI body-fallthrough exception, and disabling NetworkManager Wi-Fi power saving.

## 4.2.2 RC13 / Factory V41

RC13 repairs the RC12 WebUI telemetry proxy regression. It retains the RC12 bounded Ground Station transport and the accepted RC11 gimbal/FC-failsafe bridge unchanged.

