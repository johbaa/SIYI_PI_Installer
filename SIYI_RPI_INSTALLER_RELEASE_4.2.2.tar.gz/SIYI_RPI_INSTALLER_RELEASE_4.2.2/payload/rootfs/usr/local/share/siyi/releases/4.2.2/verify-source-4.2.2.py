#!/usr/bin/env python3
from __future__ import annotations
import argparse, fnmatch, grp, hashlib, json, os, pwd, stat, sys
from pathlib import Path, PurePosixPath


def digest_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def mapped(root: Path, absolute: str) -> Path:
    if root == Path('/'):
        return Path(absolute)
    return root / absolute.lstrip('/')


def node_type(path: Path) -> str:
    st = os.lstat(path)
    if stat.S_ISLNK(st.st_mode):
        return 'symlink'
    if stat.S_ISREG(st.st_mode):
        return 'file'
    if stat.S_ISDIR(st.st_mode):
        return 'directory'
    return 'other'



def walk_rel(root_path: Path) -> set[str]:
    if not os.path.lexists(root_path): return set()
    found={'.'}
    if not root_path.is_dir() or root_path.is_symlink(): return found
    for current,dirs,files in os.walk(root_path,topdown=True,followlinks=False):
        dirs.sort(); files.sort(); cp=Path(current)
        for name in list(dirs):
            q=cp/name; found.add(q.relative_to(root_path).as_posix())
            if q.is_symlink(): dirs.remove(name)
        for name in files: found.add((cp/name).relative_to(root_path).as_posix())
    return found


def allowed_rel(rel: str, patterns: list[str]) -> bool:
    pp=PurePosixPath(rel)
    return any(fnmatch.fnmatchcase(rel,p) or pp.match(p) for p in patterns)


def verify_namespaces(root: Path, manifest: dict, identity: dict) -> list[str]:
    failures=[]
    files=manifest.get('files',[])
    for rule in identity.get('managed_namespace_rules',[]):
        kind=rule.get('kind'); absolute=rule['path']; path=mapped(root,absolute); unexpected=set()
        prefix=absolute.rstrip('/')+'/'
        if kind=='exact_tree':
            expected={'.'}
            for item in files:
                q=item['path']
                if q==absolute: expected.add('.')
                elif q.startswith(prefix): expected.add(q[len(prefix):])
            actual=walk_rel(path); allow_paths=set(rule.get('allow_paths',[])); globs=list(rule.get('allow_globs',[]))
            unexpected={rel for rel in actual-expected if absolute.rstrip('/')+'/'+rel not in allow_paths and not allowed_rel(rel,globs)}
        elif kind=='direct_match':
            expected=set(rule.get('expected_names',[]))
            for item in files:
                q=item['path']
                if q.startswith(prefix):
                    rel=q[len(prefix):]
                    if '/' not in rel: expected.add(rel)
            actual=set(os.listdir(path)) if path.is_dir() else set(); prefixes=tuple(rule.get('prefixes',[])); contains=tuple(rule.get('contains',[])); allow=rule.get('allow_globs',[])
            considered={n for n in actual if n in expected or (prefixes and n.startswith(prefixes)) or any(t in n for t in contains)}
            unexpected={n for n in considered-expected if not any(fnmatch.fnmatchcase(n,g) for g in allow)}
        elif kind=='release_set':
            actual=set(os.listdir(path)) if path.is_dir() else set(); unexpected=actual-set(rule.get('expected_releases',[]))
        else:
            failures.append(f'unsupported_namespace_rule:{kind}:{absolute}'); continue
        failures.extend(f'namespace_extra:{absolute}:{x}' for x in sorted(unexpected))
    return failures

def main() -> int:
    ap = argparse.ArgumentParser(description='Verify the exact accepted SIYI 4.2.2 RC11 source installation')
    ap.add_argument('--identity', required=True)
    ap.add_argument('--manifest', required=True)
    ap.add_argument('--root', default='/')
    ap.add_argument('--skip-ownership', action='store_true', help='offline fixture validation only')
    ap.add_argument('--json-output')
    args = ap.parse_args()

    root = Path(args.root).resolve()
    identity_path = Path(args.identity)
    manifest_path = Path(args.manifest)
    identity = json.loads(identity_path.read_text(encoding='utf-8'))
    manifest_bytes = manifest_path.read_bytes()
    manifest = json.loads(manifest_bytes.decode('utf-8'))
    failures: list[str] = []

    if identity.get('source_version') != '4.2.2':
        failures.append('identity_version')
    if manifest.get('release_version') != '4.2.2':
        failures.append('manifest_version')
    if digest_file(manifest_path) != identity.get('source_payload_manifest_sha256'):
        failures.append('embedded_source_manifest_checksum')

    version_path = mapped(root, '/etc/siyi/release_version')
    build_path = mapped(root, '/etc/siyi/release_build')
    status_path = mapped(root, '/etc/siyi/release_status')
    def read_text(path: Path) -> str:
        try:
            return path.read_text(encoding='utf-8-sig').replace('\x00', '').strip()
        except Exception:
            return ''
    if read_text(version_path) != identity.get('source_version'):
        failures.append('source_release_version')
    if read_text(build_path) != identity.get('source_build'):
        failures.append('source_release_build')
    if read_text(status_path) not in {'accepted', 'core_accepted_hardware_pending'}:
        failures.append('source_release_status')

    release_dir = mapped(root, '/usr/local/share/siyi/releases/4.2.2')
    expected_metadata = identity.get('installed_release_metadata', {})
    actual_names = set(os.listdir(release_dir)) if release_dir.is_dir() else set()
    if actual_names != set(expected_metadata):
        failures.append('source_release_metadata_set')
    for name, spec in sorted(expected_metadata.items()):
        path = release_dir / name
        if not path.is_file() or path.is_symlink():
            failures.append(f'source_metadata_missing:{name}')
            continue
        if digest_file(path) != spec['sha256']:
            failures.append(f'source_metadata_checksum:{name}')
        if not args.skip_ownership:
            st = os.lstat(path)
            owner = pwd.getpwuid(st.st_uid).pw_name
            group = grp.getgrgid(st.st_gid).gr_name
            mode = format(stat.S_IMODE(st.st_mode), '04o')
            if (owner, group, mode) != (spec['owner'], spec['group'], spec['mode']):
                failures.append(f'source_metadata_mode:{name}')

    variants = identity.get('variants', {})
    variant = ''
    variant_failures: dict[str, list[str]] = {}
    runtime_mutable = set(identity.get('runtime_mutable_paths', []))
    ignored_dirs = set(identity.get('ignored_shared_directory_metadata', []))

    for candidate, candidate_spec in variants.items():
        local_failures: list[str] = []
        overrides = candidate_spec.get('file_overrides', {})
        mode_overrides = candidate_spec.get('mode_overrides', {})
        for item in manifest.get('files', []):
            absolute = item['path']
            if item.get('persistent') or absolute in runtime_mutable:
                continue
            if item['type'] == 'directory' and absolute in ignored_dirs:
                continue
            path = mapped(root, absolute)
            if not os.path.lexists(path):
                local_failures.append(f'missing:{absolute}')
                continue
            typ = node_type(path)
            if typ != item['type']:
                local_failures.append(f'type:{absolute}')
                continue
            st = os.lstat(path)
            expected_mode = mode_overrides.get(absolute, item['mode'])
            if typ != 'symlink' and format(stat.S_IMODE(st.st_mode), '04o') != expected_mode:
                local_failures.append(f'mode:{absolute}')
            # Symlink ownership is not used for execution or access control and can
            # legitimately vary after backup/restore. The symlink target checksum
            # below remains mandatory, so changing the active target is rejected.
            if not args.skip_ownership and typ != 'symlink':
                try:
                    owner = pwd.getpwuid(st.st_uid).pw_name
                    group = grp.getgrgid(st.st_gid).gr_name
                except KeyError:
                    local_failures.append(f'ownership_lookup:{absolute}')
                else:
                    if owner != item['owner'] or group != item['group']:
                        local_failures.append(f'ownership:{absolute}')
            expected_sha = overrides.get(absolute, item.get('sha256', ''))
            if typ == 'file' and digest_file(path) != expected_sha:
                local_failures.append(f'checksum:{absolute}')
            elif typ == 'symlink':
                actual_sha = hashlib.sha256(os.readlink(path).encode()).hexdigest()
                if actual_sha != expected_sha:
                    local_failures.append(f'symlink:{absolute}')
        for absolute in manifest.get('obsolete_paths', []):
            if os.path.lexists(mapped(root, absolute)):
                local_failures.append(f'obsolete:{absolute}')
        variant_failures[candidate] = local_failures
        if not local_failures and not variant:
            variant = candidate

    if not variant:
        failures.append('no_approved_source_variant')
    failures.extend(verify_namespaces(root, manifest, identity))

    report = {
        'ok': not failures,
        'source_version': identity.get('source_version'),
        'source_build': identity.get('source_build'),
        'variant': variant or None,
        'failures': failures,
        'variant_failure_counts': {k: len(v) for k, v in variant_failures.items()},
    }
    if args.json_output:
        out = Path(args.json_output)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    if failures:
        for failure in failures:
            print(f'SOURCE VERIFY FAILED: {failure}', file=sys.stderr)
        if 'no_approved_source_variant' in failures:
            for candidate, items in variant_failures.items():
                print(f'  {candidate}: {len(items)} mismatches', file=sys.stderr)
                for item in items[:20]:
                    print(f'    {item}', file=sys.stderr)
        return 1
    print(variant)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
