# SIYI 4.2.2 RC7 / Factory V35

Build: `SIYI_4_2_2_RELEASE_CANDIDATE_V7`

## RC7 correction

- Spoken battery-voltage announcements now use Smooth Voltage by default when it is enabled, valid and fresh.
- Raw Voltage is used when Smooth Voltage is disabled, unavailable, invalid or stale.
- The existing raw-voltage cache remains the final fallback during Ground Station startup or restart.
- This changes voice presentation only. FC battery monitoring, warnings, failsafes, throttle and aircraft behaviour remain based on the raw FC data and are unchanged.

## Retained RC6 scope

- User-defined LiPo/Li-ion chemistry, series cell count and configurable 100%/0% per-cell endpoints.
- Selectable display-only Battery % telemetry using Smooth Voltage when valid and Raw Voltage as fallback.
- Raw Voltage and Smooth Voltage telemetry, wind telemetry redesign and the corrected native Software Upgrade workflow.
