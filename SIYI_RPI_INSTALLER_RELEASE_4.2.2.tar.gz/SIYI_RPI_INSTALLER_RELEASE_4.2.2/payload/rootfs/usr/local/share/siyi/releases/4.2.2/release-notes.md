# SIYI 4.2.2 RC13 / Factory V41

Build: `SIYI_4_2_2_RELEASE_CANDIDATE_V13`

## Critical telemetry repair

- Fixes RC12 browser telemetry being completely blank.
- Defines the parsed request URL before forwarding telemetry catalog, layout and selected-value queries.
- Preserves query strings exactly through the WebUI proxy to the Ground Station daemon.
- Removes the request-handler local `import time` that caused `INSTANT_MODE_CACHE_FAIL`.

## Retained RC12 load bounds and safety

- Compact 5 Hz state stream with incremental track deltas.
- Selected telemetry values outside the editor.
- Hidden WHEP receivers closed.
- Reduced browser polling and disabled Wi-Fi power saving.
- RC11/RC7 passive gimbal implementation unchanged.
- FC-native GCS failsafe exposure unchanged; the Pi sends no RTL/mode command.

## Acceptance

Offline telemetry proxy, browser, daemon, load and package gates passed. Genuine RC12 -> RC13 native upgrade, physical telemetry display and actual-link soak remain mandatory before flight.
