# SIYI 4.2.2 RC12 / Factory V40

Build: `SIYI_4_2_2_RELEASE_CANDIDATE_V12`

## Ground Station load and freeze prevention

- Removes the complete historical track from the repeated state stream.
- Sends the track once per client and then only sequence-numbered incremental points.
- Reduces state-stream cadence from 10 Hz to 5 Hz while retaining normal flight telemetry updates.
- Requests only telemetry fields selected for display; complete values are fetched only while editing telemetry.
- Runs only video receivers visible in the current layout and closes hidden WHEP sessions.
- Reduces voice/recording polling to 1 Hz and video-source polling to 0.2 Hz.
- Fixes the WebUI request fallthrough that produced repeated `UnboundLocalError: body` exceptions.
- Disables NetworkManager Wi-Fi power saving. Kernel/SDIO error monitoring remains mandatory during the live soak.

## Retained accepted behavior

- RC11 exact RC7 gimbal command transport and passive attitude feedback remain byte-identical.
- RC11 native FC-failsafe exposure remains byte-identical: the Pi withdraws control/heartbeat and sends no RTL or mode command.
- RC8/RC10 Smooth Voltage and continuous Battery percentage corrections remain retained.

## Acceptance

Offline load, API, JavaScript, source-route and package gates passed. A genuine RC11 to RC12 native upgrade and a 30-minute Android/video/joystick/4G soak remain mandatory before flight.
