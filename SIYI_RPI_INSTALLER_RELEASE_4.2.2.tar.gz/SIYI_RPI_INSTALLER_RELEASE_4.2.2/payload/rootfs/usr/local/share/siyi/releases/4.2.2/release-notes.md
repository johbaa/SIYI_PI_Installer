# SIYI 4.2.2 RC10 / Factory V38

Build: `SIYI_4_2_2_RELEASE_CANDIDATE_V10`

## RC10 upgrade-gate correction

- RC9 was rejected before deployment because physical-test bridge backup files remained directly under `/home/pi` and were correctly detected as unexpected managed-namespace entries.
- Runtime-state migration V4 now moves every `/home/pi/siyi_mav_button_bridge.py.*` backup node into `/home/pi/.local/state/siyi/bridge-backups` before immutable source verification.
- Backups are preserved with collision-safe names; the migration is idempotent.
- The active Candidate C bridge remains checksum-pinned and unchanged.
- RC9 failure evidence SHA256: `1dcff881e3a7c83460eef4255c26c91b3ad8387014a59bed7070f07807ca1570`.

## Retained physically accepted gimbal implementation

- D-pad left/right preset taps use native SIYI absolute-angle control.
- Preset pitch is translated at the SIYI transport boundary.
- BACK uses native auto-center and absolute `1.0×` zoom.
- D-pad hold remains on the working MAVLink rate path: `25°/s` initially and `65°/s` after `0.7 s`.
- Displayed yaw/pitch follows direct SIYI camera attitude.

## Retained RC8 battery correction

- Smooth Voltage compensates only current above configured normal cruise current.
- Battery % recalculates continuously without the RC7 armed minimum latch.
- Raw FC voltage and aircraft safety behavior remain unchanged.
