# SIYI 4.2.2 RC11 / Factory V39

Build: `SIYI_4_2_2_RELEASE_CANDIDATE_V11`

## RC7 gimbal restoration

- Restores the exact field-proven RC7 MAVLink gimbal command functions and passive `GIMBAL_DEVICE_ATTITUDE_STATUS` position source.
- Removes RC9/RC10 continuous direct-SIYI attitude polling, camera request loop and related repeated state-file writes.
- Retains the accepted D-pad hold ramp: 25 deg/s, increasing to 65 deg/s after 0.7 seconds, with zero-rate stop on release.

## Native flight-controller GCS failsafe exposure

- Active joystick disconnect, page/link timeout or bridge-input failure stops `MANUAL_CONTROL` and closes both Pi MAVLink paths using source system 255.
- The Pi sends no RTL or mode command. `FS_GCS_ENABL`, `FS_LONG_TIMEOUT`, `FS_LONG_ACTN` and `SYSID_MYGCS` remain authoritative in the flight controller.
- Delayed disconnect packets from an obsolete browser session cannot shut down a newer active session.

## Retained battery correction

RC8/RC10 Smooth Voltage and continuously derived Battery percentage behavior remain unchanged.

## Validation

Offline gates passed exact-function identity, deterministic gimbal command replay, passive-feedback idle soak, joystick-loss/session-race tests, a 200,000-packet joystick soak and RC7/RC10 Ground Station max-track load comparison. Physical aircraft/gimbal and configured FC-native failsafe behavior remain mandatory post-install bench gates.
