# FlightCore 4.2.2 RC14

Corrective candidate based on the exact accepted RC13 factory payload.

## Corrections

- Adds the always-on FlightCore Field Recorder V2 with six-hour circular retention.
- Drains duplicate inbound MAVLink fan-out on transmit-oriented command and browser-joystick TCP clients.
- Adds an adaptive link guardian: normal traffic remains unshaped; persistent port-8080 queueing triggers control/telemetry-priority protection that sacrifices WebRTC video first.
- Preserves the accepted RC13 Ground Station load bounds, telemetry proxy, passive gimbal feedback and FC-native GCS failsafe policy.

## Safety boundary

The Pi does not command RTL or force a flight mode on Ground Station, joystick or link loss. ArduPlane remains responsible for configured GCS failsafe action and timing.

## Required validation

RC14 is not for flight until the automated native-upgrade, rollback, MAVLink queue, adaptive QoS, Ground Station, gimbal and failsafe validation suite passes.
