# SIYI 4.2.2 RC8 / Factory V36

Build: `SIYI_4_2_2_RELEASE_CANDIDATE_V8`

## RC8 Smooth Voltage correction

- Reduces the whole compensation model by treating configured Normal amp draw, cruise as the reference condition.
- Compensates only current above the configured cruise value instead of adding current × resistance from zero load.
- Removes the RC7 display ceiling that exposed part of takeoff sag while the tracker was in hold state.
- Holds the last established Smooth Voltage through takeoff and high-current/current-step transients.
- Allows stable cruise evidence to establish a realistic lower post-takeoff value.
- Does not add a landing-only workaround; low-current landing compensation is naturally zero.
- Raw FC voltage and all FC safety behavior remain unchanged.

## RC8 Battery % correction

- Continues to use valid Smooth Voltage first and Raw Voltage only as fallback.
- Removes the RC7 armed minimum latch that could freeze a temporary takeoff value for the entire flight.
- Recalculates continuously from configured chemistry, cell count and fixed 100%/0% endpoints.
- Clamps strictly to 0–100%; voltage above the configured full endpoint reports 100% without redefining the endpoint.

## RC8 gimbal correction

- Repairs D-pad gimbal presets and `GIMBAL_CENTER_AND_ZOOM_OUT`.
- Uses body-frame/follow manager flags and the primary gimbal device ID.
- Requires a matching flight-controller `COMMAND_ACK`; rejected or unacknowledged commands are no longer reported as successful.
- Centering and full zoom-out remain independent, and the zoom stop command is guaranteed.

## Retained RC7 scope

- Spoken battery-voltage announcements prefer valid/fresh Smooth Voltage, with Raw Voltage and the raw cache as fallbacks.
- User-defined LiPo/Li-ion battery setup and selectable display-only Battery %.
- Wind telemetry redesign and corrected native Software Upgrade workflow.
