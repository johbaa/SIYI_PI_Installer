# SIYI 4.2.2 RC6 / Factory V34

Build: `SIYI_4_2_2_RELEASE_CANDIDATE_V6`

## RC6 changes

- Adds **Current battery setup** in Telemetry settings: LiPo or Li-ion, series cell count, user-defined 100% voltage per cell, and user-defined 0% voltage per cell.
- Defaults: LiPo 4.20 V/cell at 100% and 3.50 V/cell at 0%; Li-ion 4.10 V/cell at 100% and 3.00 V/cell at 0%.
- Adds selectable telemetry value **Battery %**. It uses Smooth Voltage when available, otherwise Raw Voltage, interpolates between the configured endpoints, and clamps to 0–100%.
- Battery % is display-only. Raw FC voltage, FC battery monitoring, warnings, failsafes, throttle and aircraft behavior are unchanged.
- Fixes persistence of the RC5 `Normal amp draw, cruise` setting in the telemetry-layout normalizer.
- Supports native same-version candidate upgrade from exact accepted RC5 without a preparation patch, plus accepted 4.2.1 RC28, accepted 4.2.0 RC23 and fresh installation.
