# SIYI 4.2.2 RC9 / Factory V37

Build: `SIYI_4_2_2_RELEASE_CANDIDATE_V9`

## RC9 physically accepted gimbal correction

- D-pad left/right preset taps use the camera's native SIYI absolute-angle command.
- Preset pitch is translated at the SIYI transport boundary so configured positive/negative pitch moves in the intended UI direction.
- BACK uses native SIYI auto-center and absolute zoom to `1.0×`.
- D-pad hold remains on the working MAVLink rate path: `25°/s` initially and `65°/s` after `0.7 s`.
- Releasing D-pad sends a zero-rate stop command.
- Starting manual hold cancels a still-running preset worker.
- Gimbal yaw/pitch display now follows direct camera attitude continuously instead of the frozen FC gimbal-status message.
- Physical Candidate C acceptance completed on 2026-08-04 with presets, center/zoom, all four hold directions, speed ramp and live position feedback working.

## Retained RC8 battery correction

- Smooth Voltage compensates only current above configured normal cruise current.
- Takeoff/current-step hold is not defeated by a raw-plus-limit display clamp.
- Battery % recalculates continuously without the RC7 armed minimum latch.
- Raw FC voltage and aircraft safety behavior remain unchanged.

## Retained RC7 scope

- Spoken battery-voltage announcements prefer valid/fresh Smooth Voltage, with Raw Voltage and raw cache fallbacks.
- User-defined LiPo/Li-ion battery setup and selectable display-only Battery %.
- Wind telemetry redesign and corrected native Software Upgrade workflow.
