#!/usr/bin/env python3
"""SIYI Ground Station read-only telemetry daemon.

Receives MAVLink from the dedicated mavlink-router UDP endpoint, maintains a
normalized state model, and exposes a loopback-only JSON/SSE interface for the
existing WebUI. This first live patch is deliberately monitor-only.
"""

# GROUND_STATION_CANONICAL_QGC_TELEMETRY_OVERHAUL_V4_1_0
# SIYI_4_2_2_TELEMETRY_WIND_AND_VOLTAGE_V1
# SIYI_4_2_2_RC2_WIND_LEGACY_SEMANTICS_AND_SPEED_V1
# SIYI_4_2_2_RC2_RESTING_VOLTAGE_TRACKER_V1
# SIYI_4_2_2_RC6_BATTERY_PERCENT_V1

from __future__ import annotations

import copy
import json
import math
import os
import threading
import time
from collections import deque
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from pymavlink import mavutil

CONFIG_PATH = Path("/etc/siyi/groundstation.json")

TELEMETRY_LAYOUT_PATH = Path("/var/lib/siyi-user-config/groundstation/telemetry_canvas.json")
TELEMETRY_LAYOUT_SHADOW_PATH = Path("/home/pi/.config/siyi/telemetry_canvas.json")
TELEMETRY_LAYOUT_SCHEMA_VERSION = 1

NORMALIZED_TELEMETRY_FIELDS = [
    {"key": "norm.speed.groundspeed_kmh", "label": "Ground Speed", "unit": "km/h", "path": ["speed", "groundspeed_m_s"], "multiplier": 3.6, "digits": 1, "age_key": "speed", "category": "Flight"},
    {"key": "norm.speed.airspeed_kmh", "label": "Air Speed", "unit": "km/h", "path": ["speed", "airspeed_m_s"], "multiplier": 3.6, "digits": 1, "age_key": "speed", "category": "Flight"},
    {"key": "norm.position.relative_alt_m", "label": "Alt (Rel)", "unit": "m", "path": ["position", "relative_alt_m"], "digits": 1, "age_key": "position", "category": "Flight"},
    {"key": "norm.position.amsl_alt_m", "label": "Alt (AMSL)", "unit": "m", "path": ["position", "amsl_alt_m"], "digits": 1, "age_key": "position", "category": "Flight"},
    {"key": "norm.navigation.home_distance_m", "label": "Distance to Home", "unit": "m", "path": ["navigation", "home_distance_m"], "digits": 0, "age_key": "position", "category": "Navigation"},
    {"key": "norm.navigation.distance_to_waypoint_m", "label": "Distance to Waypoint", "unit": "m", "path": ["navigation", "distance_to_waypoint_m"], "digits": 0, "age_key": "navigation", "category": "Navigation"},
    {"key": "norm.navigation.flight_distance_m", "label": "Flight Distance", "unit": "m", "path": ["navigation", "flight_distance_m"], "digits": 0, "age_key": "position", "category": "Flight"},
    {"key": "norm.timers.flight_time_text", "label": "Flight Time", "unit": "", "path": ["timers", "flight_time_text"], "age_key": "heartbeat", "category": "Flight"},
    {"key": "norm.timers.local_time_text", "label": "Time", "unit": "", "path": ["timers", "local_time_text"], "age_key": "heartbeat", "category": "Flight"},
    {"key": "norm.speed.vertical_speed_m_s", "label": "Vertical Speed", "unit": "m/s", "path": ["speed", "vertical_speed_m_s"], "digits": 1, "age_key": "speed", "category": "Flight"},
    {"key": "norm.speed.throttle_pct", "label": "Throttle %", "unit": "%", "path": ["speed", "throttle_pct"], "digits": 0, "age_key": "speed", "category": "Flight"},
    {"key": "norm.attitude.heading_deg", "label": "Heading", "unit": "deg", "path": ["attitude", "heading_deg"], "digits": 0, "age_key": "attitude", "category": "Attitude"},
    {"key": "norm.position.ground_course_deg", "label": "Course Over Ground", "unit": "deg", "path": ["position", "ground_course_deg"], "digits": 0, "age_key": "position", "category": "Navigation"},
    {"key": "norm.attitude.roll_deg", "label": "Roll", "unit": "deg", "path": ["attitude", "roll_deg"], "digits": 1, "age_key": "attitude", "category": "Attitude"},
    {"key": "norm.attitude.pitch_deg", "label": "Pitch", "unit": "deg", "path": ["attitude", "pitch_deg"], "digits": 1, "age_key": "attitude", "category": "Attitude"},
    {"key": "norm.position.latitude", "label": "Latitude", "unit": "deg", "path": ["position", "lat"], "digits": 6, "age_key": "position", "category": "Navigation"},
    {"key": "norm.position.longitude", "label": "Longitude", "unit": "deg", "path": ["position", "lon"], "digits": 6, "age_key": "position", "category": "Navigation"},
    {"key": "norm.battery.voltage_v", "label": "Raw Voltage", "unit": "V", "path": ["battery", "voltage_v"], "digits": 2, "age_key": "battery", "category": "Battery"},
    {"key": "norm.battery.voltage_smooth_v", "label": "Smooth Voltage", "unit": "V", "path": ["battery", "voltage_smooth_v"], "digits": 2, "age_key": "battery", "category": "Battery", "renderer": "smooth_voltage"},
    {"key": "norm.battery.estimated_pct", "label": "Battery %", "unit": "%", "path": ["battery", "estimated_pct"], "digits": 0, "age_key": "battery", "category": "Battery", "renderer": "battery_percent"},
    {"key": "norm.battery.current_a", "label": "Current", "unit": "A", "path": ["battery", "current_a"], "digits": 1, "age_key": "battery", "category": "Battery"},
    {"key": "norm.battery.consumed_mah", "label": "Consumed", "unit": "mAh", "path": ["battery", "consumed_mah"], "digits": 0, "age_key": "battery", "category": "Battery"},
    {"key": "norm.battery.remaining_pct", "label": "Battery Remaining", "unit": "%", "path": ["battery", "remaining_pct"], "digits": 0, "age_key": "battery", "category": "Battery"},
    {"key": "norm.gps.fix", "label": "GPS Fix", "unit": "", "path": ["gps", "fix"], "age_key": "gps", "category": "GPS"},
    {"key": "norm.gps.fix_type", "label": "GPS Fix Type", "unit": "", "path": ["gps", "fix_type"], "digits": 0, "age_key": "gps", "category": "GPS"},
    {"key": "norm.gps.satellites", "label": "GPS Sats", "unit": "", "path": ["gps", "satellites"], "digits": 0, "age_key": "gps", "category": "GPS"},
    {"key": "norm.gps.hdop", "label": "GPS HDOP", "unit": "", "path": ["gps", "hdop"], "digits": 2, "age_key": "gps", "category": "GPS"},
    {"key": "norm.navigation.home_bearing_deg", "label": "Home Bearing", "unit": "deg", "path": ["navigation", "home_bearing_deg"], "digits": 0, "age_key": "position", "category": "Navigation"},
    {"key": "norm.navigation.waypoint_current", "label": "Current Waypoint", "unit": "", "path": ["navigation", "waypoint_current"], "digits": 0, "age_key": "navigation", "category": "Navigation"},
    {"key": "norm.navigation.target_bearing_deg", "label": "Target Bearing", "unit": "deg", "path": ["navigation", "target_bearing_deg"], "digits": 0, "age_key": "navigation", "category": "Navigation"},
    # SIYI_4_2_0_WIND_SPEED_MPS_FIX_V1
    # SIYI_4_2_2_WIND_INDICATOR_TELEMETRY_FIELD_V1
    {"key": "norm.wind.relative_indicator", "label": "Wind", "unit": "", "path": ["wind", "relative_indicator"], "age_keys": ["wind", "attitude"], "category": "Wind", "renderer": "wind_indicator"},
    {"key": "norm.wind.speed_m_s", "label": "Wind Spd", "unit": "m/s", "path": ["wind", "speed_m_s"], "digits": 1, "age_key": "wind", "category": "Wind"},
    {"key": "norm.wind.direction_deg", "label": "Wind Direction", "unit": "deg", "path": ["wind", "direction_deg"], "digits": 0, "age_key": "wind", "category": "Wind"},
    {"key": "norm.wind.vertical_m_s", "label": "Vertical Wind", "unit": "m/s", "path": ["wind", "vertical_m_s"], "digits": 1, "age_key": "wind", "category": "Wind"},
    {"key": "norm.link.rssi", "label": "RSSI", "unit": "", "path": ["link", "rssi"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.remote_rssi", "label": "Remote RSSI", "unit": "", "path": ["link", "remote_rssi"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.noise", "label": "Radio Noise", "unit": "", "path": ["link", "noise"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.remote_noise", "label": "Remote Noise", "unit": "", "path": ["link", "remote_noise"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.rx_errors", "label": "RX Errors", "unit": "", "path": ["link", "rx_errors"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.link.fixed_packets", "label": "Fixed Packets", "unit": "", "path": ["link", "fixed_packets"], "digits": 0, "age_key": "link", "category": "Radio"},
    {"key": "norm.vehicle.mode", "label": "Flight Mode", "unit": "", "path": ["vehicle", "mode"], "age_key": "heartbeat", "category": "Vehicle"},
    {"key": "norm.vehicle.armed", "label": "Armed", "unit": "", "path": ["vehicle", "armed"], "age_key": "heartbeat", "category": "Vehicle"},
    {"key": "norm.timers.armed_s", "label": "Armed Time", "unit": "s", "path": ["timers", "armed_s"], "digits": 0, "age_key": "heartbeat", "category": "Vehicle"},
]

DEFAULT_TELEMETRY_LAYOUT = {
    "schema_version": TELEMETRY_LAYOUT_SCHEMA_VERSION,
    "visible": True,
    "layout": {
        "left": None,
        "top": None,
        "width": 320,
        "height": 280,
        "auto_fit": True,
        "columns": 2,
        "rows": 6,
        "flow": "row",
        "font_size": 17,
        "show_labels": True,
        "show_units": True,
    },

    "battery_stabilization": {
        "enabled": True,
        "pack_resistance_mohm": 0.0,
        "normal_cruise_current_a": 6.0,
        "battery_chemistry": "",
        "battery_series_cells": 6,
        "battery_full_v_per_cell": 4.10,
        "battery_empty_v_per_cell": 3.00,
    },

    "selected_fields": [
            "norm.speed.groundspeed_kmh",
            "norm.position.relative_alt_m",
            "norm.timers.flight_time_text",
            "norm.navigation.home_distance_m",
            "norm.navigation.flight_distance_m",
            "norm.battery.consumed_mah",
            "norm.battery.current_a",
            "norm.speed.airspeed_kmh",
            "norm.battery.voltage_v",
            "norm.battery.voltage_smooth_v",
            "norm.wind.relative_indicator",
            "norm.timers.local_time_text",
            "norm.speed.throttle_pct",
        ],}
DEFAULT_CONFIG: Dict[str, Any] = {
    "enabled": True,
    "mavlink": {
        "host": "0.0.0.0",
        "port": 14602,
        "system_id": 254,
        "component_id": 192,
        "manage_message_intervals": False,
    },
    "internal_api": {"host": "127.0.0.1", "port": 18765},
    "video": {
        "path": "main.264",
        "primary_protocol": "webrtc",
        "fallback_protocol": "hls",
    },
    "controls": {"enabled": False},
    "telemetry": {
        "airspeed_unit": "kmh",
        "altitude_unit": "m",
        "distance_unit": "metric",
    },
    "warnings": {
        "heartbeat_degraded_s": 3.0,
        "heartbeat_lost_s": 5.0,
    },
    "track": {"maximum_points": 3000, "minimum_interval_s": 0.8},
}


def deep_merge(base: Dict[str, Any], incoming: Dict[str, Any]) -> Dict[str, Any]:
    result = copy.deepcopy(base)
    for key, value in incoming.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def load_config() -> Dict[str, Any]:
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("configuration root is not an object")
        return deep_merge(DEFAULT_CONFIG, raw)
    except FileNotFoundError:
        return copy.deepcopy(DEFAULT_CONFIG)
    except Exception as exc:
        print(f"[GROUNDSTATION_CONFIG] using defaults: {exc!r}", flush=True)
        return copy.deepcopy(DEFAULT_CONFIG)



def _deep_get(payload: Dict[str, Any], path: list[str]) -> Any:
    value: Any = payload
    for item in path:
        if not isinstance(value, dict):
            return None
        value = value.get(item)
    return value


def _json_safe(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace").rstrip("\\x00")
    if isinstance(value, (list, tuple)):
        return [_json_safe(item) for item in value]
    try:
        number = float(value)
        if math.isfinite(number):
            return number
    except (TypeError, ValueError):
        pass
    return str(value)



def _migrate_wind_speed_unit_overrides(value: Any) -> tuple[Any, bool]:
    field_key = "norm.wind.speed_m_s"
    unit_names = {
        "unit",
        "unit_override",
        "unitOverride",
        "display_unit",
        "displayUnit",
    }
    map_names = {
        "units",
        "unit_overrides",
        "unitOverrides",
        "display_units",
        "displayUnits",
    }

    def old_unit(candidate: Any) -> bool:
        return str(candidate or "").strip().lower().replace(" ", "") == "km/h"

    changed = False
    if isinstance(value, list):
        for index, child in enumerate(value):
            migrated, child_changed = _migrate_wind_speed_unit_overrides(child)
            if child_changed:
                value[index] = migrated
                changed = True
        return value, changed

    if not isinstance(value, dict):
        return value, False

    identifiers = (
        value.get("key"),
        value.get("field"),
        value.get("id"),
        value.get("telemetryKey"),
        value.get("telemetry_key"),
    )
    if any(str(candidate or "") == field_key for candidate in identifiers):
        for name in unit_names:
            if name in value and old_unit(value.get(name)):
                value[name] = "m/s"
                changed = True

    for name in map_names:
        unit_map = value.get(name)
        if isinstance(unit_map, dict) and old_unit(unit_map.get(field_key)):
            unit_map[field_key] = "m/s"
            changed = True

    for key, child in list(value.items()):
        migrated, child_changed = _migrate_wind_speed_unit_overrides(child)
        if child_changed:
            value[key] = migrated
            changed = True

    return value, changed

def _normalise_telemetry_layout(payload: Any) -> Dict[str, Any]:
    base = copy.deepcopy(DEFAULT_TELEMETRY_LAYOUT)
    if not isinstance(payload, dict):
        return base
    payload, _wind_unit_migrated = _migrate_wind_speed_unit_overrides(copy.deepcopy(payload))
    base["visible"] = bool(payload.get("visible", base["visible"]))
    incoming_layout = payload.get("layout") if isinstance(payload.get("layout"), dict) else {}
    layout = base["layout"]

    def number_or_none(name: str, minimum: float, maximum: float, fallback: Any) -> Any:
        value = incoming_layout.get(name, fallback)
        if value is None and name in {"left", "top"}:
            return None
        try:
            numeric = float(value)
        except (TypeError, ValueError):
            return fallback
        if not math.isfinite(numeric):
            return fallback
        return max(minimum, min(maximum, numeric))

    layout["left"] = number_or_none("left", 0, 10000, layout["left"])
    layout["top"] = number_or_none("top", 0, 10000, layout["top"])
    layout["width"] = int(round(number_or_none("width", 20, 1600, layout["width"])))
    layout["height"] = int(round(number_or_none("height", 20, 1200, layout["height"])))
    layout["columns"] = int(round(number_or_none("columns", 1, 24, layout["columns"])))
    layout["rows"] = int(round(number_or_none("rows", 1, 24, layout["rows"])))
    layout["font_size"] = int(round(number_or_none("font_size", 10, 40, layout["font_size"])))
    layout["flow"] = "column" if incoming_layout.get("flow") == "column" else "row"
    layout["show_labels"] = bool(incoming_layout.get("show_labels", layout["show_labels"]))
    layout["show_units"] = bool(incoming_layout.get("show_units", layout["show_units"]))
    layout["auto_fit"] = bool(incoming_layout.get("auto_fit", layout["auto_fit"]))
    # GROUND_STATION_TELEMETRY_CANVAS_V2_CONTENT_FIT

    incoming_battery = payload.get("battery_stabilization")
    if not isinstance(incoming_battery, dict):
        incoming_battery = {}
    battery_config = base["battery_stabilization"]
    battery_config["enabled"] = bool(
        incoming_battery.get("enabled", battery_config["enabled"])
    )
    try:
        resistance_mohm = float(
            incoming_battery.get(
                "pack_resistance_mohm",
                battery_config["pack_resistance_mohm"],
            )
        )
    except (TypeError, ValueError):
        resistance_mohm = float(battery_config["pack_resistance_mohm"])
    if not math.isfinite(resistance_mohm):
        resistance_mohm = 0.0
    battery_config["pack_resistance_mohm"] = max(0.0, min(200.0, resistance_mohm))

    try:
        cruise_current = float(incoming_battery.get(
            "normal_cruise_current_a", battery_config["normal_cruise_current_a"]
        ))
    except (TypeError, ValueError):
        cruise_current = float(battery_config["normal_cruise_current_a"])
    if not math.isfinite(cruise_current):
        cruise_current = 6.0
    battery_config["normal_cruise_current_a"] = max(0.5, min(100.0, cruise_current))

    chemistry = str(incoming_battery.get("battery_chemistry", "") or "").strip().lower()
    if chemistry not in {"lipo", "liion"}:
        chemistry = ""
    battery_config["battery_chemistry"] = chemistry

    try:
        series_cells = int(round(float(incoming_battery.get(
            "battery_series_cells", battery_config["battery_series_cells"]
        ))))
    except (TypeError, ValueError):
        series_cells = int(battery_config["battery_series_cells"])
    battery_config["battery_series_cells"] = max(1, min(24, series_cells))

    defaults = {"lipo": (4.20, 3.50), "liion": (4.10, 3.00)}
    default_full, default_empty = defaults.get(chemistry, (4.10, 3.00))
    try:
        full_v = float(incoming_battery.get("battery_full_v_per_cell", default_full))
    except (TypeError, ValueError):
        full_v = default_full
    try:
        empty_v = float(incoming_battery.get("battery_empty_v_per_cell", default_empty))
    except (TypeError, ValueError):
        empty_v = default_empty
    if not math.isfinite(full_v):
        full_v = default_full
    if not math.isfinite(empty_v):
        empty_v = default_empty
    battery_config["battery_full_v_per_cell"] = full_v
    battery_config["battery_empty_v_per_cell"] = empty_v
    if not (3.50 <= full_v <= 4.40 and 2.50 <= empty_v <= 4.00 and full_v - empty_v >= 0.20):
        # Invalid endpoints are retained for UI correction, but chemistry is
        # cleared so Battery % cannot silently use an unsafe configuration.
        battery_config["battery_chemistry"] = ""

    selected: list[str] = []
    for item in payload.get("selected_fields", base["selected_fields"]):
        key = str(item or "").strip()
        if not key or len(key) > 180 or not (key.startswith("norm.") or key.startswith("raw.")):
            continue
        if key not in selected:
            selected.append(key)
        if len(selected) >= 1000:
            break
    base["selected_fields"] = selected or copy.deepcopy(DEFAULT_TELEMETRY_LAYOUT["selected_fields"])
    base["schema_version"] = TELEMETRY_LAYOUT_SCHEMA_VERSION
    return base


def _write_telemetry_layout_copy(path: Path, config: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}.{threading.get_ident()}")
    temporary.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.chmod(temporary, 0o664)
    os.replace(temporary, path)


def load_telemetry_layout() -> Dict[str, Any]:
    errors: list[str] = []
    for path in (TELEMETRY_LAYOUT_PATH, TELEMETRY_LAYOUT_SHADOW_PATH):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
            config = _normalise_telemetry_layout(payload)
            for copy_path in (TELEMETRY_LAYOUT_PATH, TELEMETRY_LAYOUT_SHADOW_PATH):
                try:
                    _write_telemetry_layout_copy(copy_path, config)
                except Exception as exc:
                    errors.append(f"{copy_path}: {exc!r}")
            if errors:
                print("[GROUNDSTATION_TELEMETRY_CONFIG] mirror warning: " + "; ".join(errors), flush=True)
            return config
        except FileNotFoundError:
            continue
        except Exception as exc:
            errors.append(f"{path}: {exc!r}")
    if errors:
        print("[GROUNDSTATION_TELEMETRY_CONFIG] using defaults: " + "; ".join(errors), flush=True)
    return copy.deepcopy(DEFAULT_TELEMETRY_LAYOUT)


def save_telemetry_layout(payload: Any) -> Dict[str, Any]:
    config = _normalise_telemetry_layout(payload)
    failures: list[str] = []
    saved = 0
    for path in (TELEMETRY_LAYOUT_PATH, TELEMETRY_LAYOUT_SHADOW_PATH):
        try:
            _write_telemetry_layout_copy(path, config)
            saved += 1
        except Exception as exc:
            failures.append(f"{path}: {exc!r}")
    if saved == 0:
        raise OSError("could not save Telemetry Canvas configuration: " + "; ".join(failures))
    if failures:
        print("[GROUNDSTATION_TELEMETRY_CONFIG] mirror warning: " + "; ".join(failures), flush=True)
    return config


RAW_CANONICAL_FIELD_LABELS = {
    "groundspeed": "Ground Speed",
    "airspeed": "Air Speed",
    "relative_alt": "Alt (Rel)",
    "voltage_battery": "Voltage",
    "current_battery": "Current",
    "current_consumed": "Consumed",
    "battery_remaining": "Battery Remaining",
    "throttle": "Throttle %",
    "throttle_scaled": "Throttle %",
    "satellites_visible": "GPS Sats",
    "eph": "GPS HDOP",
    "hdop": "GPS HDOP",
    "wp_dist": "Distance to Waypoint",
    "target_bearing": "Target Bearing",
    "nav_bearing": "Navigation Bearing",
    "heading": "Heading",
    "cog": "Course Over Ground",
    "lat": "Latitude",
    "lon": "Longitude",
}

CANONICAL_ACRONYMS = {
    "gps": "GPS",
    "rssi": "RSSI",
    "hdop": "HDOP",
    "vdop": "VDOP",
    "uid": "UID",
    "id": "ID",
    "imu": "IMU",
    "rpm": "RPM",
    "rc": "RC",
    "wp": "WP",
    "mav": "MAV",
}

def canonical_field_label(field_name: str) -> str:
    key = str(field_name or "").strip().lower()
    if key in RAW_CANONICAL_FIELD_LABELS:
        return RAW_CANONICAL_FIELD_LABELS[key]
    words = [part for part in key.replace("[", " ").replace("]", " ").split("_") if part]
    if not words:
        return str(field_name or "")
    return " ".join(CANONICAL_ACRONYMS.get(word, word.capitalize()) for word in words)

def canonical_category_name(message_name: str) -> str:
    words = [part for part in str(message_name or "").strip().lower().split("_") if part]
    return " ".join(CANONICAL_ACRONYMS.get(word, word.capitalize()) for word in words)


def build_telemetry_catalog() -> list[Dict[str, Any]]:
    catalog: list[Dict[str, Any]] = []
    for item in NORMALIZED_TELEMETRY_FIELDS:
        catalog.append(
            {
                "key": item["key"],
                "label": item["label"],
                "unit": item.get("unit", ""),
                "category": item.get("category", "Ground Station"),
                "message": "NORMALIZED",
                "field": item["key"].rsplit(".", 1)[-1],
                "type": "normalized",
                "digits": item.get("digits"),
                "renderer": item.get("renderer", ""),
            }
        )
    mavlink_map = getattr(mavutil.mavlink, "mavlink_map", {}) or {}
    for message_id, message_class in sorted(mavlink_map.items(), key=lambda pair: int(pair[0])):
        name = str(
            getattr(message_class, "msgname", "")
            or getattr(message_class, "name", "")
            or f"MSG_{message_id}"
        ).upper()
        fields = list(getattr(message_class, "fieldnames", []) or [])
        types = list(getattr(message_class, "fieldtypes", []) or [])
        arrays = list(getattr(message_class, "array_lengths", []) or [])
        units_by_name = dict(getattr(message_class, "fieldunits_by_name", {}) or {})
        enums_by_name = dict(getattr(message_class, "fieldenums_by_name", {}) or {})
        for index, field in enumerate(fields):
            field_name = str(field)
            field_type = str(types[index]) if index < len(types) else ""
            array_length = int(arrays[index] or 0) if index < len(arrays) else 0
            unit = str(units_by_name.get(field_name) or "")
            enum = str(enums_by_name.get(field_name) or "")
            label_base = canonical_field_label(field_name)
            category_label = canonical_category_name(name)
            if array_length > 0 and field_type.lower() not in {"char", "char[]"}:
                for array_index in range(array_length):
                    catalog.append(
                        {
                            "key": f"raw.{name}.{field_name}[{array_index + 1}]",
                            "label": f"{label_base} {array_index + 1}",
                            "unit": unit,
                            "category": category_label,
                            "message": name,
                            "field": f"{field_name}[{array_index + 1}]",
                            "type": field_type,
                            "enum": enum,
                            "message_id": int(message_id),
                        }
                    )
            else:
                catalog.append(
                    {
                        "key": f"raw.{name}.{field_name}",
                        "label": label_base,
                        "unit": unit,
                        "category": category_label,
                        "message": name,
                        "field": field_name,
                        "type": field_type,
                        "enum": enum,
                        "message_id": int(message_id),
                    }
                )
    return catalog

def finite(value: Any) -> Optional[float]:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def degrees(value: Any) -> Optional[float]:
    number = finite(value)
    return math.degrees(number) if number is not None else None


def gps_fix_name(value: int) -> str:
    return {
        0: "NO GPS",
        1: "NO FIX",
        2: "2D",
        3: "3D",
        4: "DGPS",
        5: "RTK FLOAT",
        6: "RTK FIXED",
        7: "STATIC",
        8: "PPP",
    }.get(int(value or 0), "UNKNOWN")


def severity_name(value: int) -> str:
    return {
        0: "Emergency",
        1: "Alert",
        2: "Critical",
        3: "Error",
        4: "Warning",
        5: "Notice",
        6: "Info",
        7: "Debug",
    }.get(int(value or 6), "Info")


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    radius = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * radius * math.atan2(math.sqrt(a), math.sqrt(max(0.0, 1.0 - a)))


def bearing_deg(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    y = math.sin(dl) * math.cos(p2)
    x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(y, x)) + 360.0) % 360.0


def format_hms(total_seconds: Any) -> str:
    number = finite(total_seconds)
    if number is None or number < 0:
        number = 0.0
    seconds = int(round(number))
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"


class VehicleState:
    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.lock = threading.RLock()
        self.started_monotonic = time.monotonic()
        self.started_wall = time.time()
        self.selected_vehicle: Optional[Tuple[int, int]] = None
        self.vehicle_heartbeats: Dict[Tuple[int, int], float] = {}
        self.field_times: Dict[str, float] = {}
        self.messages = deque(maxlen=250)
        self.track = deque(maxlen=int(config.get("track", {}).get("maximum_points", 3000)))
        self.last_track_time = 0.0
        self.last_track_position: Optional[Tuple[float, float]] = None
        self.armed_since: Optional[float] = None
        self.total_armed_s = 0.0
        self.flight_distance_m = 0.0
        self.flight_distance_last_position: Optional[Tuple[float, float]] = None
        self.flight_distance_last_time: Optional[float] = None
        self.raw_telemetry_values: Dict[str, Any] = {}
        self.raw_telemetry_times: Dict[str, float] = {}
        self.telemetry_catalog = build_telemetry_catalog()
        self.telemetry_layout = load_telemetry_layout()
        self.battery_voltage_samples = deque(maxlen=3)
        self.battery_voltage_envelope = deque(maxlen=1200)
        self.battery_voltage_cruise_samples = deque(maxlen=1200)
        self.battery_voltage_cruise_baseline_acquired = False
        self.battery_percentage_last: Optional[float] = None
        self.battery_percentage_source: str = "unavailable"
        self.battery_voltage_stable_v: Optional[float] = None
        self.battery_voltage_candidate_v: Optional[float] = None
        self.battery_voltage_last_update: Optional[float] = None
        self.battery_voltage_last_current_a: Optional[float] = None
        self.battery_voltage_hold_until = 0.0
        self.battery_voltage_drop_confirm_since: Optional[float] = None
        self.battery_voltage_compensation_was_active = False
        self.battery_voltage_armed_was = False
        self.state: Dict[str, Any] = {
            "connection": {
                "state": "NO_VEHICLE",
                "heartbeat_age_s": None,
                "system_id": None,
                "component_id": None,
                "multiple_vehicles": False,
            },
            "vehicle": {
                "type": None,
                "autopilot": None,
                "armed": None,
                "mode": None,
                "system_status": None,
            },
            "attitude": {"roll_deg": None, "pitch_deg": None, "heading_deg": None},
            "position": {
                "lat": None,
                "lon": None,
                "relative_alt_m": None,
                "amsl_alt_m": None,
                "ground_course_deg": None,
            },
            "speed": {
                "airspeed_m_s": None,
                "groundspeed_m_s": None,
                "vertical_speed_m_s": None,
                "throttle_pct": None,
            },
            "battery": {
                "voltage_v": None,
                "voltage_compensated_v": None,
                "voltage_smooth_v": None,
                "voltage_filter_status": "unavailable",
                "voltage_tracker_state": "unavailable",
                "voltage_tracker_candidate_v": None,
                "voltage_compensation_active": False,
                "voltage_compensation_clamped": False,
                "estimated_pct": None,
                "percentage_status": "unavailable",
                "percentage_source": "unavailable",
                "percentage_per_cell_v": None,
                "configured_cell_count": None,
                "cell_count": None,
                "current_a": None,
                "remaining_pct": None,
                "consumed_mah": None,
            },
            "gps": {"fix": "UNKNOWN", "fix_type": None, "satellites": None, "hdop": None},
            "navigation": {
                "home_lat": None,
                "home_lon": None,
                "home_distance_m": None,
                "home_bearing_deg": None,
                "waypoint_current": None,
                "waypoint_reached": None,
                "target_bearing_deg": None,
                "distance_to_waypoint_m": None,
                "flight_distance_m": 0.0,
            },
            "link": {
                "rssi": None,
                "remote_rssi": None,
                "noise": None,
                "remote_noise": None,
                "rx_errors": None,
                "fixed_packets": None,
            },
            "wind": {"speed_m_s": None, "direction_deg": None, "vertical_m_s": None, "relative_indicator": None},
            "rc": {"channels": []},
            "servo": {"outputs": []},
            "timers": {"connected_s": 0.0, "armed_s": 0.0, "flight_time_text": "00:00:00", "local_time_text": time.strftime("%H:%M:%S")},
            "messages": [],
            "track": [],
            "field_age_s": {},
            "service": {
                "monitor_only": True,
                "started_at": self.started_wall,
                "last_packet_at": None,
                "packet_count": 0,
            },
        }

    def _touch(self, field: str, now: float) -> None:
        self.field_times[field] = now

    def _battery_stabilization_config_locked(self) -> Dict[str, Any]:
        config = self.telemetry_layout.get("battery_stabilization", {})
        if not isinstance(config, dict):
            config = {}
        return {
            "enabled": bool(config.get("enabled", True)),
            "pack_resistance_mohm": max(
                0.0,
                min(200.0, finite(config.get("pack_resistance_mohm")) or 0.0),
            ),
            "normal_cruise_current_a": max(
                0.5,
                min(100.0, finite(config.get("normal_cruise_current_a")) or 6.0),
            ),
            "battery_chemistry": str(config.get("battery_chemistry", "") or "").strip().lower(),
            "battery_series_cells": max(
                1,
                min(24, int(round(finite(config.get("battery_series_cells")) or 6.0))),
            ),
            "battery_full_v_per_cell": finite(config.get("battery_full_v_per_cell")),
            "battery_empty_v_per_cell": finite(config.get("battery_empty_v_per_cell")),
        }

    def _reset_battery_voltage_tracker_locked(self, clear_stable: bool = True) -> None:
        self.battery_voltage_samples.clear()
        self.battery_voltage_envelope.clear()
        self.battery_voltage_cruise_samples.clear()
        self.battery_voltage_cruise_baseline_acquired = False
        self.battery_percentage_last = None
        self.battery_percentage_source = "unavailable"
        if clear_stable:
            self.battery_voltage_stable_v = None
        self.battery_voltage_candidate_v = None
        self.battery_voltage_last_update = None
        self.battery_voltage_last_current_a = None
        self.battery_voltage_hold_until = 0.0
        self.battery_voltage_drop_confirm_since = None
        self.battery_voltage_compensation_was_active = False
        self.battery_voltage_armed_was = False

    @staticmethod
    def _battery_upper_percentile(values: list[float], percentile: float = 0.90) -> Optional[float]:
        clean = sorted(value for value in values if math.isfinite(value))
        if not clean:
            return None
        index = int(round((len(clean) - 1) * max(0.0, min(1.0, percentile))))
        return clean[max(0, min(len(clean) - 1, index))]

    # SIYI_4_2_2_RC5_CRUISE_BASELINE_TRACKER_V1
    # SIYI_4_2_2_RC8_CONSERVATIVE_SMOOTH_VOLTAGE_AND_PERCENT_V1
    def _update_battery_stabilization_locked(self, now: float) -> None:
        """Display-only conservative voltage estimate using stable cruise evidence.

        The user-defined normal cruise current is a preferred measurement region,
        not a strict gate. Stable lower current remains valid; moderately higher
        stable current contributes more slowly. Rapid changes and high load freeze
        the armed baseline. Raw FC voltage, warnings and failsafes remain untouched.
        """
        battery = self.state["battery"]
        raw_voltage = finite(battery.get("voltage_v"))
        if raw_voltage is None or raw_voltage <= 0.0 or raw_voltage > 100.0:
            battery.update({
                "voltage_compensated_v": None, "voltage_smooth_v": None,
                "voltage_filter_status": "unavailable", "voltage_tracker_state": "unavailable",
                "voltage_tracker_candidate_v": None, "voltage_compensation_active": False,
                "voltage_compensation_clamped": False,
            })
            self._reset_battery_voltage_tracker_locked()
            return

        config = self._battery_stabilization_config_locked()
        if not bool(config["enabled"]):
            battery.update({
                "voltage_compensated_v": raw_voltage, "voltage_smooth_v": None,
                "voltage_filter_status": "disabled", "voltage_tracker_state": "disabled",
                "voltage_tracker_candidate_v": None, "voltage_compensation_active": False,
                "voltage_compensation_clamped": False,
            })
            self._reset_battery_voltage_tracker_locked()
            return

        resistance_ohm = float(config["pack_resistance_mohm"]) / 1000.0
        cruise_a = float(config["normal_cruise_current_a"])
        current_a = finite(battery.get("current_a"))
        configured_cells = int(config.get("battery_series_cells") or 0)
        try:
            telemetry_cells = int(battery.get("cell_count"))
        except (TypeError, ValueError):
            telemetry_cells = 0
        cell_count = configured_cells if 1 <= configured_cells <= 24 else telemetry_cells
        cell_count_valid = 1 <= cell_count <= 24
        current_valid = current_a is not None and 0.0 <= current_a <= 500.0
        compensation_active = bool(resistance_ohm > 0.0 and current_valid and cell_count_valid)

        # RC8: normal cruise current is the voltage reference condition. RC7
        # added I*R from zero current, which globally over-corrected the pack and
        # produced the conspicuous rebound when propulsion load disappeared.
        # Only current above the configured normal-cruise region is compensated.
        # This keeps the user-entered resistance meaningful while making the
        # estimate conservative across the complete flight, not just at landing.
        excess_current_a = (
            max(0.0, float(current_a) - cruise_a)
            if compensation_active
            else 0.0
        )
        requested_sag = excess_current_a * resistance_ohm

        # Retain an internal sanity ceiling for invalid or extreme configuration,
        # but never use it to pull the displayed Smooth Voltage below the held
        # tracker value. The RC7 display ceiling was what exposed part of the
        # takeoff sag even while the armed tracker was correctly in hold state.
        maximum_sag = 0.12 * cell_count if cell_count_valid else 0.0
        sag_v = max(0.0, min(maximum_sag, requested_sag)) if compensation_active else 0.0
        compensation_clamped = bool(compensation_active and requested_sag > maximum_sag + 1e-9)

        natural_gap = self.battery_voltage_last_update is None or now - self.battery_voltage_last_update > 3.0
        mode_changed = compensation_active != self.battery_voltage_compensation_was_active
        if natural_gap or mode_changed:
            self.battery_voltage_samples.clear()
            self.battery_voltage_envelope.clear()
            self.battery_voltage_cruise_samples.clear()
            self.battery_voltage_drop_confirm_since = None
        if self.battery_voltage_compensation_was_active and not compensation_active:
            self.battery_voltage_stable_v = None
            self.battery_voltage_candidate_v = None
            self.battery_voltage_last_update = None
            self.battery_voltage_cruise_baseline_acquired = False
            natural_gap = True
        self.battery_voltage_compensation_was_active = compensation_active

        instantaneous_compensated = raw_voltage + sag_v
        self.battery_voltage_samples.append(instantaneous_compensated)
        ordered = sorted(self.battery_voltage_samples)
        compensated = ordered[len(ordered) // 2]
        dt = 0.1 if self.battery_voltage_last_update is None else max(0.02, min(1.0, now - self.battery_voltage_last_update))

        armed = self.state.get("vehicle", {}).get("armed") is True
        just_armed = armed and not self.battery_voltage_armed_was
        just_disarmed = (not armed) and self.battery_voltage_armed_was
        self.battery_voltage_armed_was = armed
        if just_armed:
            self.battery_voltage_cruise_samples.clear()
            self.battery_voltage_cruise_baseline_acquired = False
            self.battery_voltage_hold_until = max(self.battery_voltage_hold_until, now + 4.0)
        if just_disarmed:
            self.battery_voltage_cruise_samples.clear()
            self.battery_voltage_cruise_baseline_acquired = False

        previous_current = self.battery_voltage_last_current_a
        current_delta = abs(float(current_a) - previous_current) if current_valid and previous_current is not None and not natural_gap else 0.0
        current_step_limit = max(1.0, cruise_a * 0.25)
        current_step = current_delta >= current_step_limit
        self.battery_voltage_last_current_a = float(current_a) if current_valid else None
        if current_step:
            self.battery_voltage_hold_until = max(self.battery_voltage_hold_until, now + 4.0)
        if compensation_clamped:
            self.battery_voltage_hold_until = max(self.battery_voltage_hold_until, now + 2.0)

        preferred_tolerance = max(1.0, cruise_a * 0.20)
        preferred_low = max(0.0, cruise_a - preferred_tolerance)
        preferred_high = cruise_a + preferred_tolerance
        usable_low = max(0.0, cruise_a * 0.50)
        usable_high = cruise_a * 1.60
        evidence_weight = 0.0
        current_region = "unusable"
        if current_valid and not current_step and now >= self.battery_voltage_hold_until:
            value = float(current_a)
            if preferred_low <= value <= preferred_high:
                evidence_weight = 1.0; current_region = "preferred"
            elif usable_low <= value < preferred_low:
                evidence_weight = 1.0; current_region = "lower"
            elif preferred_high < value <= usable_high:
                evidence_weight = 0.5; current_region = "higher"
        if evidence_weight > 0.0:
            self.battery_voltage_cruise_samples.append((now, compensated, evidence_weight, dt))
        while self.battery_voltage_cruise_samples and now - self.battery_voltage_cruise_samples[0][0] > 30.0:
            self.battery_voltage_cruise_samples.popleft()

        valid_values = [sample for _ts, sample, _weight, _dt in self.battery_voltage_cruise_samples]
        candidate = self._battery_upper_percentile(valid_values, 0.90)
        if candidate is None:
            candidate = compensated
        valid_evidence_s = sum(weight * sample_dt for _ts, _sample, weight, sample_dt in self.battery_voltage_cruise_samples)
        self.battery_voltage_candidate_v = candidate

        if natural_gap or self.battery_voltage_stable_v is None:
            stable = compensated; tracker_state = "acquire"
        elif not armed:
            alpha = dt / (3.0 + dt)
            stable = self.battery_voltage_stable_v + alpha * (compensated - self.battery_voltage_stable_v)
            self.battery_voltage_drop_confirm_since = None
            tracker_state = "idle"
        else:
            previous = self.battery_voltage_stable_v
            stable = previous
            deadband = 0.05
            if evidence_weight <= 0.0:
                self.battery_voltage_drop_confirm_since = None
                tracker_state = "hold_load"
            elif not self.battery_voltage_cruise_baseline_acquired:
                if valid_evidence_s >= 5.0:
                    stable = min(previous, candidate)
                    self.battery_voltage_cruise_baseline_acquired = True
                    tracker_state = "baseline"
                else:
                    tracker_state = "collect"
            elif candidate < previous - deadband:
                if self.battery_voltage_drop_confirm_since is None:
                    self.battery_voltage_drop_confirm_since = now
                if valid_evidence_s >= 12.0 and now - self.battery_voltage_drop_confirm_since >= 8.0:
                    alpha = dt / (45.0 + dt)
                    stable = previous + alpha * (candidate - previous)
                    tracker_state = "track"
                else:
                    tracker_state = "confirm"
            else:
                self.battery_voltage_drop_confirm_since = None
                tracker_state = "hold"
            stable = min(previous, stable)

        tracked_stable = stable

        # RC8: the tracker output is the display output. Do not apply RC7's
        # raw_voltage + maximum_sag display ceiling: during takeoff that ceiling
        # defeated the transient hold and deliberately exposed a portion of sag.
        display_stable = tracked_stable
        if compensation_active and compensation_clamped:
            status = "compensated_limited"
        elif compensation_active:
            status = "compensated"
        else:
            status = "filtered_only"
            if resistance_ohm > 0.0 and not compensation_active:
                tracker_state = "fallback"

        self.battery_voltage_stable_v = tracked_stable
        self.battery_voltage_last_update = now
        battery["voltage_compensated_v"] = round(compensated, 4)
        battery["voltage_smooth_v"] = round(display_stable, 4)
        battery["voltage_filter_status"] = status
        battery["voltage_tracker_state"] = tracker_state + ":" + current_region
        battery["voltage_tracker_candidate_v"] = round(candidate, 4)
        battery["voltage_compensation_active"] = compensation_active
        battery["voltage_compensation_clamped"] = compensation_clamped

    def _update_battery_percentage_locked(self) -> None:
        """Calculate display-only Battery % from user-defined pack endpoints."""
        battery = self.state["battery"]
        config = self._battery_stabilization_config_locked()
        chemistry = str(config.get("battery_chemistry") or "")
        cells = int(config.get("battery_series_cells") or 0)
        full_v = finite(config.get("battery_full_v_per_cell"))
        empty_v = finite(config.get("battery_empty_v_per_cell"))
        valid_config = bool(
            chemistry in {"lipo", "liion"}
            and 1 <= cells <= 24
            and full_v is not None
            and empty_v is not None
            and 3.50 <= full_v <= 4.40
            and 2.50 <= empty_v <= 4.00
            and full_v - empty_v >= 0.20
        )
        battery["configured_cell_count"] = cells if valid_config else None
        if not valid_config:
            battery.update({
                "estimated_pct": None,
                "percentage_status": "unconfigured",
                "percentage_source": "unavailable",
                "percentage_per_cell_v": None,
            })
            self.battery_percentage_last = None
            self.battery_percentage_source = "unavailable"
            return

        smooth_v = finite(battery.get("voltage_smooth_v"))
        raw_v = finite(battery.get("voltage_v"))
        if smooth_v is not None and smooth_v > 0.0:
            pack_v = smooth_v
            source = "smooth"
        elif raw_v is not None and raw_v > 0.0:
            pack_v = raw_v
            source = "raw"
        else:
            battery.update({
                "estimated_pct": None,
                "percentage_status": "voltage_unavailable",
                "percentage_source": "unavailable",
                "percentage_per_cell_v": None,
            })
            self.battery_percentage_last = None
            self.battery_percentage_source = "unavailable"
            return

        per_cell = pack_v / cells
        percentage = 100.0 * (per_cell - empty_v) / (full_v - empty_v)
        percentage = max(0.0, min(100.0, percentage))

        # RC8: calculate continuously from the current selected voltage. RC7's
        # armed-only min(previous, current) latch could capture a temporary
        # takeoff value (about 55% in the flight test) and then forbid recovery
        # when Smooth Voltage returned to its valid held value.
        self.battery_percentage_last = percentage
        self.battery_percentage_source = source
        battery.update({
            "estimated_pct": round(percentage, 2),
            "percentage_status": "ok",
            "percentage_source": source,
            "percentage_per_cell_v": round(per_cell, 4),
        })

    def _update_wind_indicator_locked(self) -> None:
        # Preserve the first-generation 4.2.1 convention exactly:
        # WIND.direction is treated as the incoming wind direction.
        # Equal wind direction and aircraft heading is direct headwind = 0 deg,
        # and the down-pointing SVG therefore points down. Tailwind = 180 deg.
        wind = self.state["wind"]
        speed = finite(wind.get("speed_m_s"))
        direction = finite(wind.get("direction_deg"))
        heading = finite(self.state["attitude"].get("heading_deg"))
        if speed is None and (direction is None or heading is None):
            wind["relative_indicator"] = None
            return
        relative = None
        if direction is not None and heading is not None:
            relative = (direction - heading) % 360.0
        wind["relative_indicator"] = {
            "speed_m_s": speed,
            "direction_deg": direction,
            "heading_deg": heading,
            "relative_deg": relative,
            "semantics": "incoming_headwind_down",
        }

    def _is_fc_heartbeat(self, msg: Any) -> bool:
        autopilot = int(getattr(msg, "autopilot", mavutil.mavlink.MAV_AUTOPILOT_INVALID))
        vehicle_type = int(getattr(msg, "type", mavutil.mavlink.MAV_TYPE_GENERIC))
        if autopilot == mavutil.mavlink.MAV_AUTOPILOT_INVALID:
            return False
        if vehicle_type in {
            mavutil.mavlink.MAV_TYPE_GCS,
            mavutil.mavlink.MAV_TYPE_ONBOARD_CONTROLLER,
            mavutil.mavlink.MAV_TYPE_GIMBAL,
        }:
            return False
        return True

    def _selected(self, msg: Any) -> bool:
        if self.selected_vehicle is None:
            return False
        return (msg.get_srcSystem(), msg.get_srcComponent()) == self.selected_vehicle

    def _capture_raw_telemetry(self, msg: Any, kind: str, now: float) -> None:
        try:
            payload = msg.to_dict()
        except Exception:
            payload = {}
            for field in getattr(msg, "get_fieldnames", lambda: [])():
                payload[field] = getattr(msg, field, None)
        for field, value in payload.items():
            if field == "mavpackettype":
                continue
            safe = _json_safe(value)
            base = f"raw.{kind}.{field}"
            if isinstance(safe, list):
                self.raw_telemetry_values[base] = copy.deepcopy(safe)
                self.raw_telemetry_times[base] = now
                for index, item in enumerate(safe, start=1):
                    key = f"{base}[{index}]"
                    self.raw_telemetry_values[key] = item
                    self.raw_telemetry_times[key] = now
            else:
                self.raw_telemetry_values[base] = safe
                self.raw_telemetry_times[base] = now

    def telemetry_catalog_snapshot(self) -> Dict[str, Any]:
        with self.lock:
            return {
                "ok": True,
                "schema_version": TELEMETRY_LAYOUT_SCHEMA_VERSION,
                "catalog_total": len(self.telemetry_catalog),
                "fields": copy.deepcopy(self.telemetry_catalog),
            }

    def telemetry_values_snapshot(self) -> Dict[str, Any]:
        now = time.monotonic()
        with self.lock:
            self._refresh_dynamic_telemetry_locked(now)
            values: Dict[str, Any] = {}
            for item in NORMALIZED_TELEMETRY_FIELDS:
                value = _deep_get(self.state, item["path"])
                if isinstance(value, (int, float)) and not isinstance(value, bool):
                    multiplier = float(item.get("multiplier", 1.0))
                    value = float(value) * multiplier
                age_keys = item.get("age_keys")
                if isinstance(age_keys, (list, tuple)) and age_keys:
                    timestamps = [
                        self.field_times.get(str(key)) for key in age_keys
                    ]
                    if any(timestamp is None for timestamp in timestamps):
                        age = None
                    else:
                        age = max(max(0.0, now - float(timestamp)) for timestamp in timestamps)
                else:
                    age_key = str(item.get("age_key") or "")
                    timestamp = self.field_times.get(age_key)
                    age = max(0.0, now - timestamp) if timestamp is not None else None
                if value is not None or item["key"] in {"norm.battery.voltage_smooth_v", "norm.battery.estimated_pct"}:
                    entry = {
                        "value": _json_safe(value),
                        "age_s": round(age, 3) if age is not None else None,
                    }
                    if item["key"] == "norm.battery.estimated_pct":
                        battery = self.state["battery"]
                        entry.update({
                            "status": battery.get("percentage_status", "unavailable"),
                            "source": battery.get("percentage_source", "unavailable"),
                            "per_cell_v": battery.get("percentage_per_cell_v"),
                            "configured_cell_count": battery.get("configured_cell_count"),
                        })
                    if item["key"] == "norm.battery.voltage_smooth_v":
                        battery = self.state["battery"]
                        entry.update(
                            {
                                "status": battery.get("voltage_filter_status", "unavailable"),
                                "compensation_active": bool(
                                    battery.get("voltage_compensation_active")
                                ),
                                "compensation_clamped": bool(
                                    battery.get("voltage_compensation_clamped")
                                ),
                                "cell_count": battery.get("cell_count"),
                                "compensated_v": battery.get("voltage_compensated_v"),
                                "tracker_state": battery.get("voltage_tracker_state", "unavailable"),
                                "tracker_candidate_v": battery.get("voltage_tracker_candidate_v"),
                            }
                        )
                    values[item["key"]] = entry
            for key, value in self.raw_telemetry_values.items():
                timestamp = self.raw_telemetry_times.get(key)
                age = max(0.0, now - timestamp) if timestamp is not None else None
                values[key] = {"value": copy.deepcopy(value), "age_s": round(age, 3) if age is not None else None}
            return {
                "ok": True,
                "schema_version": TELEMETRY_LAYOUT_SCHEMA_VERSION,
                "values": values,
                "available_fields": len(values),
                "packet_count": self.state["service"]["packet_count"],
            }

    def telemetry_layout_snapshot(self) -> Dict[str, Any]:
        with self.lock:
            return {
                "ok": True,
                "config": copy.deepcopy(self.telemetry_layout),
                "path": str(TELEMETRY_LAYOUT_PATH),
                "shadow_path": str(TELEMETRY_LAYOUT_SHADOW_PATH),
            }

    def update_telemetry_layout(self, payload: Any) -> Dict[str, Any]:
        with self.lock:
            before = self._battery_stabilization_config_locked()
            self.telemetry_layout = save_telemetry_layout(payload)
            after = self._battery_stabilization_config_locked()
            if before != after:
                self._reset_battery_voltage_tracker_locked()
            return copy.deepcopy(self.telemetry_layout)

    def update(self, msg: Any) -> None:
        now = time.monotonic()
        kind = msg.get_type()
        if kind == "BAD_DATA":
            return
        with self.lock:
            self.state["service"]["packet_count"] += 1
            self.state["service"]["last_packet_at"] = time.time()

            if kind == "HEARTBEAT" and self._is_fc_heartbeat(msg):
                key = (msg.get_srcSystem(), msg.get_srcComponent())
                self.vehicle_heartbeats[key] = now
                active = [item for item, ts in self.vehicle_heartbeats.items() if now - ts <= 5.0]
                active.sort()
                self.state["connection"]["multiple_vehicles"] = len(active) > 1
                if self.selected_vehicle not in active:
                    self.selected_vehicle = active[0] if len(active) == 1 else None
                if self.selected_vehicle == key:
                    base_mode = int(getattr(msg, "base_mode", 0) or 0)
                    armed = bool(base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED)
                    previous = self.state["vehicle"].get("armed")
                    if armed and previous is not True:
                        self.armed_since = now
                        self._reset_flight_distance_locked(keep_current_position=True)
                    elif not armed and previous is True and self.armed_since is not None:
                        self.total_armed_s += max(0.0, now - self.armed_since)
                        self.armed_since = None
                    self.state["vehicle"].update(
                        {
                            "type": mavutil.mavlink.enums["MAV_TYPE"].get(int(msg.type), None).name
                            if int(msg.type) in mavutil.mavlink.enums["MAV_TYPE"]
                            else str(int(msg.type)),
                            "autopilot": mavutil.mavlink.enums["MAV_AUTOPILOT"].get(int(msg.autopilot), None).name
                            if int(msg.autopilot) in mavutil.mavlink.enums["MAV_AUTOPILOT"]
                            else str(int(msg.autopilot)),
                            "armed": armed,
                            "mode": mavutil.mode_string_v10(msg),
                            "system_status": mavutil.mavlink.enums["MAV_STATE"].get(int(msg.system_status), None).name
                            if int(msg.system_status) in mavutil.mavlink.enums["MAV_STATE"]
                            else str(int(msg.system_status)),
                        }
                    )
                    self._touch("vehicle", now)
                    self._touch("heartbeat", now)
                    self._capture_raw_telemetry(msg, kind, now)
                return

            if not self._selected(msg):
                return

            # GROUND_STATION_ATTITUDE_FALLBACK_V6
            if self._selected(msg):
                self._capture_raw_telemetry(msg, kind, now)

            if kind == "ATTITUDE":
                self.state["attitude"].update(
                    {
                        "roll_deg": degrees(msg.roll),
                        "pitch_deg": degrees(msg.pitch),
                        "heading_deg": (degrees(msg.yaw) or 0.0) % 360.0,
                    }
                )
                self._touch("attitude", now)

            elif kind == "ATTITUDE_QUATERNION":
                q1 = finite(getattr(msg, "q1", None))
                q2 = finite(getattr(msg, "q2", None))
                q3 = finite(getattr(msg, "q3", None))
                q4 = finite(getattr(msg, "q4", None))
                if None not in (q1, q2, q3, q4):
                    sinr_cosp = 2.0 * (q1 * q2 + q3 * q4)
                    cosr_cosp = 1.0 - 2.0 * (q2 * q2 + q3 * q3)
                    roll = math.atan2(sinr_cosp, cosr_cosp)
                    sinp = 2.0 * (q1 * q3 - q4 * q2)
                    pitch = math.copysign(math.pi / 2.0, sinp) if abs(sinp) >= 1.0 else math.asin(sinp)
                    siny_cosp = 2.0 * (q1 * q4 + q2 * q3)
                    cosy_cosp = 1.0 - 2.0 * (q3 * q3 + q4 * q4)
                    yaw = math.atan2(siny_cosp, cosy_cosp)
                    self.state["attitude"].update(
                        {
                            "roll_deg": degrees(roll),
                            "pitch_deg": degrees(pitch),
                            "heading_deg": (degrees(yaw) or 0.0) % 360.0,
                        }
                    )
                    self._touch("attitude", now)

            elif kind == "AHRS2":
                roll = finite(getattr(msg, "roll", None))
                pitch = finite(getattr(msg, "pitch", None))
                yaw = finite(getattr(msg, "yaw", None))
                if roll is not None and pitch is not None:
                    self.state["attitude"].update(
                        {
                            "roll_deg": degrees(roll),
                            "pitch_deg": degrees(pitch),
                            "heading_deg": (degrees(yaw) or 0.0) % 360.0 if yaw is not None else self.state["attitude"].get("heading_deg"),
                        }
                    )
                    self._touch("attitude", now)

            elif kind == "GLOBAL_POSITION_INT":
                lat = int(msg.lat) / 1e7
                lon = int(msg.lon) / 1e7
                heading = None if int(msg.hdg) == 65535 else int(msg.hdg) / 100.0
                self.state["position"].update(
                    {
                        "lat": lat,
                        "lon": lon,
                        "relative_alt_m": int(msg.relative_alt) / 1000.0,
                        "amsl_alt_m": int(msg.alt) / 1000.0,
                        "ground_course_deg": heading,
                    }
                )
                self.state["speed"]["groundspeed_m_s"] = math.hypot(int(msg.vx), int(msg.vy)) / 100.0
                self.state["speed"]["vertical_speed_m_s"] = -int(msg.vz) / 100.0
                self._touch("position", now)
                self._touch("speed", now)
                self._update_track(lat, lon, now)
                self._update_home_geometry()
                self._update_flight_distance_locked(lat, lon, now)

            elif kind == "VFR_HUD":
                self.state["speed"].update(
                    {
                        "airspeed_m_s": finite(msg.airspeed),
                        "groundspeed_m_s": finite(msg.groundspeed),
                        "vertical_speed_m_s": finite(msg.climb),
                        "throttle_pct": finite(msg.throttle),
                    }
                )
                if self.state["position"].get("amsl_alt_m") is None:
                    self.state["position"]["amsl_alt_m"] = finite(msg.alt)
                if self.state["attitude"].get("heading_deg") is None:
                    self.state["attitude"]["heading_deg"] = finite(msg.heading)
                self._touch("speed", now)

            elif kind == "GPS_RAW_INT":
                eph = int(getattr(msg, "eph", 65535))
                self.state["gps"].update(
                    {
                        "fix_type": int(msg.fix_type),
                        "fix": gps_fix_name(int(msg.fix_type)),
                        "satellites": int(msg.satellites_visible) if int(msg.satellites_visible) != 255 else None,
                        "hdop": None if eph == 65535 else eph / 100.0,
                    }
                )
                self._touch("gps", now)

            elif kind == "SYS_STATUS":
                voltage = int(getattr(msg, "voltage_battery", 65535))
                current = int(getattr(msg, "current_battery", -1))
                remaining = int(getattr(msg, "battery_remaining", -1))
                self.state["battery"].update(
                    {
                        "voltage_v": None if voltage == 65535 else voltage / 1000.0,
                        "current_a": None if current < 0 else current / 100.0,
                        "remaining_pct": None if remaining < 0 else remaining,
                    }
                )
                self._touch("battery", now)
                if voltage != 65535:
                    self._update_battery_stabilization_locked(now)

            elif kind == "BATTERY_STATUS":
                voltages = [int(value) for value in getattr(msg, "voltages", []) if 0 < int(value) < 65535]
                if voltages:
                    self.state["battery"]["voltage_v"] = sum(voltages) / 1000.0
                    self.state["battery"]["cell_count"] = len(voltages)
                current = int(getattr(msg, "current_battery", -1))
                remaining = int(getattr(msg, "battery_remaining", -1))
                consumed = int(getattr(msg, "current_consumed", -1))
                self.state["battery"]["current_a"] = None if current < 0 else current / 100.0
                if remaining >= 0:
                    self.state["battery"]["remaining_pct"] = remaining
                if consumed >= 0:
                    self.state["battery"]["consumed_mah"] = consumed
                self._touch("battery", now)
                if voltages:
                    self._update_battery_stabilization_locked(now)

            elif kind == "HOME_POSITION":
                self.state["navigation"]["home_lat"] = int(msg.latitude) / 1e7
                self.state["navigation"]["home_lon"] = int(msg.longitude) / 1e7
                self._touch("home", now)
                self._update_home_geometry()

            elif kind == "RADIO_STATUS":
                self.state["link"].update(
                    {
                        "rssi": int(msg.rssi),
                        "remote_rssi": int(msg.remrssi),
                        "noise": int(msg.noise),
                        "remote_noise": int(msg.remnoise),
                        "rx_errors": int(msg.rxerrors),
                        "fixed_packets": int(msg.fixed),
                    }
                )
                self._touch("link", now)

            elif kind == "MISSION_CURRENT":
                self.state["navigation"]["waypoint_current"] = int(msg.seq)
                self._touch("mission", now)

            elif kind == "MISSION_ITEM_REACHED":
                self.state["navigation"]["waypoint_reached"] = int(msg.seq)
                self._touch("mission", now)

            elif kind == "NAV_CONTROLLER_OUTPUT":
                self.state["navigation"]["target_bearing_deg"] = finite(msg.target_bearing)
                self.state["navigation"]["distance_to_waypoint_m"] = finite(msg.wp_dist)
                self._touch("navigation", now)

            elif kind == "WIND":
                self.state["wind"].update(
                    {
                        "direction_deg": finite(msg.direction),
                        "speed_m_s": finite(msg.speed),
                        "vertical_m_s": finite(msg.speed_z),
                    }
                )
                self._touch("wind", now)

            elif kind == "RC_CHANNELS":
                count = max(0, min(18, int(getattr(msg, "chancount", 18) or 18)))
                values = []
                for index in range(1, count + 1):
                    value = int(getattr(msg, f"chan{index}_raw", 65535))
                    values.append(None if value == 65535 else value)
                self.state["rc"]["channels"] = values
                self._touch("rc", now)

            elif kind == "SERVO_OUTPUT_RAW":
                values = []
                for index in range(1, 17):
                    if not hasattr(msg, f"servo{index}_raw"):
                        break
                    value = int(getattr(msg, f"servo{index}_raw", 0))
                    values.append(value if value > 0 else None)
                self.state["servo"]["outputs"] = values
                self._touch("servo", now)

            elif kind == "STATUSTEXT":
                text = str(getattr(msg, "text", "") or "").rstrip("\x00").strip()
                if text:
                    item = {
                        "ts": time.time(),
                        "severity": severity_name(int(getattr(msg, "severity", 6))),
                        "severity_id": int(getattr(msg, "severity", 6)),
                        "text": text,
                        "system_id": msg.get_srcSystem(),
                        "component_id": msg.get_srcComponent(),
                    }
                    self.messages.append(item)
                    self.state["messages"] = list(self.messages)[-50:]
                    print(f"[GROUNDSTATION_MESSAGE] {item['severity']}: {text}", flush=True)

    def _update_track(self, lat: float, lon: float, now: float) -> None:
        minimum_interval = float(self.config.get("track", {}).get("minimum_interval_s", 0.8))
        if now - self.last_track_time < minimum_interval:
            return
        if self.last_track_position is not None:
            distance = haversine_m(self.last_track_position[0], self.last_track_position[1], lat, lon)
            if distance < 1.0:
                return
        self.track.append({"lat": lat, "lon": lon, "ts": time.time()})
        self.last_track_time = now
        self.last_track_position = (lat, lon)
        self.state["track"] = list(self.track)

    def _update_home_geometry(self) -> None:
        position = self.state["position"]
        navigation = self.state["navigation"]
        values = (position.get("lat"), position.get("lon"), navigation.get("home_lat"), navigation.get("home_lon"))
        if any(value is None for value in values):
            navigation["home_distance_m"] = None
            navigation["home_bearing_deg"] = None
            return
        lat, lon, home_lat, home_lon = values
        navigation["home_distance_m"] = haversine_m(lat, lon, home_lat, home_lon)
        navigation["home_bearing_deg"] = bearing_deg(lat, lon, home_lat, home_lon)



    def _reset_flight_distance_locked(self, keep_current_position: bool = False) -> None:
        self.flight_distance_m = 0.0
        self.state["navigation"]["flight_distance_m"] = 0.0
        if keep_current_position:
            lat = finite(self.state["position"].get("lat"))
            lon = finite(self.state["position"].get("lon"))
            if lat is not None and lon is not None:
                self.flight_distance_last_position = (lat, lon)
                self.flight_distance_last_time = time.monotonic()
                return
        self.flight_distance_last_position = None
        self.flight_distance_last_time = None


    def _valid_gps_for_distance_locked(self) -> bool:
        fix_type = self.state.get("gps", {}).get("fix_type")
        try:
            return int(fix_type or 0) >= 2
        except Exception:
            return False


    def _update_flight_distance_locked(self, lat: float, lon: float, now: float) -> None:
        armed = self.state.get("vehicle", {}).get("armed") is True
        if not armed:
            self.flight_distance_last_position = (lat, lon)
            self.flight_distance_last_time = now
            self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)
            return
        if not self._valid_gps_for_distance_locked():
            self.flight_distance_last_position = (lat, lon)
            self.flight_distance_last_time = now
            self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)
            return
        if self.flight_distance_last_position is None:
            self.flight_distance_last_position = (lat, lon)
            self.flight_distance_last_time = now
            self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)
            return
        last_lat, last_lon = self.flight_distance_last_position
        step_distance = haversine_m(last_lat, last_lon, lat, lon)
        delta_t = max(0.05, now - (self.flight_distance_last_time or now))
        groundspeed = finite(self.state.get("speed", {}).get("groundspeed_m_s")) or 0.0
        max_reasonable_step = max(35.0, groundspeed * delta_t * 4.0 + 25.0)
        if 0.5 <= step_distance <= max_reasonable_step:
            self.flight_distance_m += step_distance
        self.flight_distance_last_position = (lat, lon)
        self.flight_distance_last_time = now
        self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)


    def _refresh_dynamic_telemetry_locked(self, now: float) -> float:
        armed_s = self.total_armed_s
        if self.armed_since is not None:
            armed_s += max(0.0, now - self.armed_since)
        self.state["timers"]["armed_s"] = armed_s
        self.state["timers"]["flight_time_text"] = format_hms(armed_s)
        self.state["timers"]["local_time_text"] = time.strftime("%H:%M:%S")
        self.state["navigation"]["flight_distance_m"] = round(self.flight_distance_m, 1)
        self._update_battery_percentage_locked()
        self._update_wind_indicator_locked()
        return armed_s

    def snapshot(self) -> Dict[str, Any]:
        now = time.monotonic()
        with self.lock:
            self._refresh_dynamic_telemetry_locked(now)
            result = copy.deepcopy(self.state)
            active = {key: ts for key, ts in self.vehicle_heartbeats.items() if now - ts <= 5.0}
            multiple = len(active) > 1
            heartbeat_age = None
            if self.selected_vehicle in active:
                heartbeat_age = max(0.0, now - active[self.selected_vehicle])
            degraded = float(self.config.get("warnings", {}).get("heartbeat_degraded_s", 3.0))
            lost = float(self.config.get("warnings", {}).get("heartbeat_lost_s", 5.0))
            if multiple:
                connection_state = "DEGRADED"
            elif heartbeat_age is None:
                connection_state = "NO_VEHICLE"
            elif heartbeat_age < degraded:
                connection_state = "CONNECTED"
            elif heartbeat_age <= lost:
                connection_state = "DEGRADED"
            else:
                connection_state = "LINK_LOST"
            result["connection"].update(
                {
                    "state": connection_state,
                    "heartbeat_age_s": heartbeat_age,
                    "system_id": self.selected_vehicle[0] if self.selected_vehicle else None,
                    "component_id": self.selected_vehicle[1] if self.selected_vehicle else None,
                    "multiple_vehicles": multiple,
                }
            )
            result["timers"]["connected_s"] = max(0.0, now - self.started_monotonic)
            armed_s = result["timers"].get("armed_s", 0.0)
            result["field_age_s"] = {
                key: round(max(0.0, now - timestamp), 3)
                for key, timestamp in self.field_times.items()
            }
            result["service"]["uptime_s"] = max(0.0, now - self.started_monotonic)
            result["service"]["config_path"] = str(CONFIG_PATH)
            return result


class GroundStationRuntime:
    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.vehicle = VehicleState(config)
        self.stop_event = threading.Event()
        self.connection = None

    def stop(self, *_args: Any) -> None:
        self.stop_event.set()
        if self.connection is not None:
            try:
                self.connection.close()
            except Exception:
                pass

    def mavlink_loop(self) -> None:
        mav_cfg = self.config["mavlink"]
        endpoint = f"udpin:{mav_cfg.get('host', '0.0.0.0')}:{int(mav_cfg.get('port', 14602))}"
        while not self.stop_event.is_set():
            try:
                print(f"[GROUNDSTATION_MAVLINK] opening {endpoint}", flush=True)
                self.connection = mavutil.mavlink_connection(
                    endpoint,
                    source_system=int(mav_cfg.get("system_id", 254)),
                    source_component=int(mav_cfg.get("component_id", 192)),
                    dialect="ardupilotmega",
                )
                while not self.stop_event.is_set():
                    message = self.connection.recv_match(blocking=True, timeout=0.5)
                    if message is not None:
                        self.vehicle.update(message)
            except Exception as exc:
                print(f"[GROUNDSTATION_MAVLINK_ERROR] {exc!r}", flush=True)
                time.sleep(1.0)
            finally:
                if self.connection is not None:
                    try:
                        self.connection.close()
                    except Exception:
                        pass
                    self.connection = None


RUNTIME: Optional[GroundStationRuntime] = None


class ApiHandler(BaseHTTPRequestHandler):
    server_version = "SIYIGroundStation/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        print("[GROUNDSTATION_HTTP] " + (fmt % args), flush=True)

    def _json(self, payload: Any, status: int = 200) -> None:
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        assert RUNTIME is not None
        path = self.path.split("?", 1)[0]
        if path == "/health":
            snapshot = RUNTIME.vehicle.snapshot()
            self._json(
                {
                    "ok": True,
                    "service": "siyi-groundstation",
                    "monitor_only": True,
                    "connection": snapshot["connection"],
                    "packet_count": snapshot["service"]["packet_count"],
                    "uptime_s": snapshot["service"]["uptime_s"],
                    "telemetry_canvas": {
                        "schema_version": TELEMETRY_LAYOUT_SCHEMA_VERSION,
                        "catalog_total": len(RUNTIME.vehicle.telemetry_catalog),
                        "config_path": str(TELEMETRY_LAYOUT_PATH),
                        "shadow_path": str(TELEMETRY_LAYOUT_SHADOW_PATH),
                    },
                }
            )
            return
        if path == "/state":
            self._json(RUNTIME.vehicle.snapshot())
            return
        if path == "/messages":
            snapshot = RUNTIME.vehicle.snapshot()
            self._json({"messages": snapshot.get("messages", [])})
            return
        if path == "/telemetry/catalog":
            self._json(RUNTIME.vehicle.telemetry_catalog_snapshot())
            return
        if path == "/telemetry/values":
            self._json(RUNTIME.vehicle.telemetry_values_snapshot())
            return
        if path == "/telemetry/layout":
            self._json(RUNTIME.vehicle.telemetry_layout_snapshot())
            return
        if path == "/stream":
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
            self.send_header("Connection", "keep-alive")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            last_payload = None
            last_keepalive = 0.0
            try:
                while not RUNTIME.stop_event.is_set():
                    payload = json.dumps(RUNTIME.vehicle.snapshot(), ensure_ascii=False, separators=(",", ":"))
                    now = time.monotonic()
                    if payload != last_payload:
                        self.wfile.write(("data: " + payload + "\n\n").encode("utf-8"))
                        self.wfile.flush()
                        last_payload = payload
                        last_keepalive = now
                    elif now - last_keepalive >= 10.0:
                        self.wfile.write(b": keepalive\n\n")
                        self.wfile.flush()
                        last_keepalive = now
                    time.sleep(0.1)
            except (BrokenPipeError, ConnectionResetError, TimeoutError):
                pass
            return
        self._json({"error": "not found"}, 404)


    def do_POST(self) -> None:
        assert RUNTIME is not None
        path = self.path.split("?", 1)[0]
        if path != "/telemetry/layout":
            self._json({"error": "not found"}, 404)
            return
        try:
            length = int(self.headers.get("Content-Length", "0") or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > 1024 * 1024:
            self._json({"ok": False, "error": "invalid content length"}, 400)
            return
        try:
            payload = json.loads(self.rfile.read(length).decode("utf-8"))
            config = RUNTIME.vehicle.update_telemetry_layout(payload)
            self._json({
                "ok": True,
                "config": config,
                "path": str(TELEMETRY_LAYOUT_PATH),
                "shadow_path": str(TELEMETRY_LAYOUT_SHADOW_PATH),
            })
        except Exception as exc:
            self._json({"ok": False, "error": str(exc)}, 400)


def main() -> int:
    global RUNTIME
    config = load_config()
    if not bool(config.get("enabled", True)):
        print("[GROUNDSTATION] disabled in configuration", flush=True)
        return 0
    RUNTIME = GroundStationRuntime(config)
    thread = threading.Thread(target=RUNTIME.mavlink_loop, name="mavlink", daemon=True)
    thread.start()
    api_cfg = config["internal_api"]
    server = ThreadingHTTPServer((str(api_cfg.get("host", "127.0.0.1")), int(api_cfg.get("port", 18765))), ApiHandler)
    server.daemon_threads = True
    print(
        "[GROUNDSTATION] monitor-only daemon ready on "
        f"{api_cfg.get('host', '127.0.0.1')}:{int(api_cfg.get('port', 18765))}",
        flush=True,
    )
    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        RUNTIME.stop()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
