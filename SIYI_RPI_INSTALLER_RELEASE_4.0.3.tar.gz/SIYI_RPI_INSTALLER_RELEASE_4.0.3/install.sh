#!/usr/bin/env bash

# SIYI_403_WIFILINK2_PROFILE_PAYLOAD
SIYI_RELEASE_ROOT_403="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
install_wifilink2_profile_payload_403() {
    local source_dir="$SIYI_RELEASE_ROOT_403/files/usr/local/share/siyi/wifilink2"
    sudo install -d -m 0755 /usr/local/share/siyi/wifilink2
    sudo install -m 0755 \
        "$source_dir/siyi-wifi-profile-manager-v7b" \
        /usr/local/share/siyi/wifilink2/siyi-wifi-profile-manager-v7b
    sudo install -m 0755 \
        "$source_dir/S96siyi-wifi-profiles-v7b" \
        /usr/local/share/siyi/wifilink2/S96siyi-wifi-profiles-v7b
}
install_wifilink2_profile_payload_403
# SIYI_403_WIFILINK2_PROFILE_PAYLOAD_END

set -euo pipefail

PAYLOAD_DIR="$(cd "$(dirname "$0")" && pwd)"
VERSION_FILE="$PAYLOAD_DIR/release_version"

if [ ! -s "$VERSION_FILE" ]; then
  echo "INSTALL FAILED: missing or empty package version file: $VERSION_FILE" >&2
  exit 1
fi

SIYI_INSTALL_VERSION="$(tr -d '[:space:]' < "$VERSION_FILE")"
if [[ ! "$SIYI_INSTALL_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  echo "INSTALL FAILED: invalid package version: $SIYI_INSTALL_VERSION" >&2
  exit 1
fi

cd "$PAYLOAD_DIR"

# === BUTTON SAFETY VALIDATION 4.0.3 START ===
ensure_button_safety_json() {
  local target="/etc/siyi/button_safety.json"
  local source="$PAYLOAD_DIR/config/button_safety.json"
  local backup_dir
  sudo mkdir -p /etc/siyi
  if sudo python3 - "$target" <<'PYBUTTONSAFE'
import json, sys
from pathlib import Path
p=Path(sys.argv[1])
if not p.is_file() or p.stat().st_size == 0: raise SystemExit(1)
try: d=json.loads(p.read_text(encoding='utf-8'))
except Exception: raise SystemExit(1)
if not isinstance(d,dict): raise SystemExit(1)
if not isinstance(d.get('block_when_armed'),list): raise SystemExit(1)
if not isinstance(d.get('block_disarm_in_air'),bool): raise SystemExit(1)
if not isinstance(d.get('block_toggle_arm_disarm_in_air'),bool): raise SystemExit(1)
PYBUTTONSAFE
  then
    sudo chown pi:pi "$target"
    sudo chmod 664 "$target"
    echo "BUTTON_SAFETY_PRESERVED"
    return 0
  fi
  backup_dir="/home/pi/SIYI_BACKUPS/button_safety_repair_4.0.3_$(date +%Y%m%d_%H%M%S)"
  sudo mkdir -p "$backup_dir"
  if sudo test -e "$target"; then sudo cp -a "$target" "$backup_dir/button_safety.json.invalid"; else sudo touch "$backup_dir/button_safety.absent"; fi
  sudo install -o pi -g pi -m 664 "$source" "$target"
  sudo python3 -m json.tool "$target" >/dev/null
  sudo chown -R pi:pi "$backup_dir"
  echo "BUTTON_SAFETY_DEFAULT_INSTALLED"
  echo "BUTTON_SAFETY_BACKUP=$backup_dir"
}
# === BUTTON SAFETY VALIDATION 4.0.3 END ===


# === GROUND STATION CONFIG 4.0.3 START ===
ensure_groundstation_json() {
  local target="/etc/siyi/groundstation.json"
  local source="$PAYLOAD_DIR/config/groundstation.json"
  sudo mkdir -p /etc/siyi
  sudo python3 - "$source" "$target" <<'PYGROUNDSTATIONCFG'
import grp, json, os, pwd, sys, tempfile
from pathlib import Path

source = Path(sys.argv[1])
target = Path(sys.argv[2])
defaults = json.loads(source.read_text(encoding="utf-8"))
try:
    existing = json.loads(target.read_text(encoding="utf-8"))
    if not isinstance(existing, dict):
        existing = {}
except Exception:
    existing = {}

def merge(base, incoming):
    result = dict(base)
    for key, value in incoming.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = merge(result[key], value)
        else:
            result[key] = value
    return result

merged = merge(defaults, existing)
merged.setdefault("controls", {})["enabled"] = False
fd, temporary = tempfile.mkstemp(prefix=".groundstation.", dir=str(target.parent))
try:
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump(merged, handle, indent=2)
        handle.write("\n")
    os.chmod(temporary, 0o664)
    os.chown(temporary, pwd.getpwnam("pi").pw_uid, grp.getgrnam("pi").gr_gid)
    os.replace(temporary, target)
finally:
    if os.path.exists(temporary):
        os.unlink(temporary)
PYGROUNDSTATIONCFG
  sudo python3 -m json.tool "$target" >/dev/null
}
# === GROUND STATION CONFIG 4.0.3 END ===

# === SIYI FLAPS CONFIG START ===
SIYI_FLAPS_INSTALL_DIR="$PAYLOAD_DIR"

sudo mkdir -p /etc/siyi

if [ ! -e /etc/siyi/flaps.json ] &&
   [ -f "$SIYI_FLAPS_INSTALL_DIR/config/flaps.json" ]; then

    sudo install \
        -o pi \
        -g pi \
        -m 664 \
        "$SIYI_FLAPS_INSTALL_DIR/config/flaps.json" \
        /etc/siyi/flaps.json
fi
# === SIYI FLAPS CONFIG END ===

# === VIDEO SOURCE CONFIG START ===
SIYI_VIDEO_CONFIG_CREATED=0
if [ ! -e /etc/siyi/video_source.json ] && [ -f "$PAYLOAD_DIR/config/video_source.json" ]; then
  sudo install -o pi -g pi -m 660 "$PAYLOAD_DIR/config/video_source.json" /etc/siyi/video_source.json
  SIYI_VIDEO_CONFIG_CREATED=1
fi

# One-time migration when upgrading from a release that predates selectable
# video sources. This preserves the existing SIYI RTSP URL, transport,
# receiver latency and UDP port. Existing selectable-video settings are never
# modified here.
if [ "$SIYI_VIDEO_CONFIG_CREATED" -eq 1 ] && [ -s /etc/siyi/release_version ]; then
  SIYI_PREVIOUS_VERSION="$(tr -d '[:space:]' < /etc/siyi/release_version)"
  if python3 - "$SIYI_PREVIOUS_VERSION" <<'PYVERSION'
import re, sys
value=sys.argv[1]
if not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+', value):
    raise SystemExit(1)
raise SystemExit(0 if tuple(map(int,value.split('.'))) < (3,1,17) else 1)
PYVERSION
  then
    sudo python3 - <<'PYVIDEO'
import json, os, pwd, grp, re, tempfile
from pathlib import Path
path=Path('/etc/siyi/video_source.json')
try:
    cfg=json.loads(path.read_text(encoding='utf-8'))
except Exception:
    raise SystemExit(0)
try:
    core=json.loads(Path('/home/pi/siyi-config.json').read_text(encoding='utf-8'))
except Exception:
    core={}
cfg.setdefault('siyi', {})
cfg.setdefault('udp', {})
cfg['source']='siyi_rtsp'
cfg['switch_mode']='direct-redirect'
if isinstance(core, dict):
    if core.get('camera_rtsp'):
        cfg['siyi']['url']=str(core['camera_rtsp'])
    if core.get('video_port'):
        try: cfg['udp']['port']=int(core['video_port'])
        except Exception: pass
old=Path('/etc/systemd/system/siyi-video-dual.service')
if old.exists():
    text=old.read_text(encoding='utf-8', errors='replace')
    m=re.search(r'location=([^ ]+)', text)
    if m: cfg['siyi']['url']=m.group(1)
    m=re.search(r'protocols=([^ ]+)', text)
    if m and m.group(1) in {'tcp','udp'}: cfg['siyi']['transport']=m.group(1)
    m=re.search(r'latency=([0-9]+)', text)
    if m: cfg['siyi']['latency_ms']=int(m.group(1))
    m=re.search(r'udpsink host=[^ ]+ port=([0-9]+)', text)
    if m: cfg['udp']['port']=int(m.group(1))
fd,tmp=tempfile.mkstemp(prefix='.video_source.',dir=str(path.parent))
try:
    with os.fdopen(fd,'w',encoding='utf-8') as handle:
        json.dump(cfg,handle,indent=2); handle.write('\n')
    os.chmod(tmp,0o660)
    os.chown(tmp,pwd.getpwnam('pi').pw_uid,grp.getgrnam('pi').gr_gid)
    os.replace(tmp,path)
finally:
    if os.path.exists(tmp): os.unlink(tmp)
PYVIDEO
  fi
fi
# === VIDEO SOURCE CONFIG END ===

# Add WiFiLink2 defaults without changing any existing video setting.
sudo python3 - <<'PYWIFILINKMIGRATE'
import json, os, pwd, grp, tempfile
from pathlib import Path
path = Path('/etc/siyi/video_source.json')
try:
    cfg = json.loads(path.read_text(encoding='utf-8'))
except Exception:
    raise SystemExit(0)
if not isinstance(cfg, dict):
    raise SystemExit(0)
changed = False
if not isinstance(cfg.get('wifilink'), dict):
    cfg['wifilink'] = {}
    changed = True
defaults = {
    'url': 'rtsp://192.168.191.199:554/stream=0',
    'username': 'root',
    'password': '',
    'transport': 'tcp',
    'latency_ms': 0,
}
for key, value in defaults.items():
    if key not in cfg['wifilink']:
        cfg['wifilink'][key] = value
        changed = True
if not changed:
    raise SystemExit(0)
fd, tmp = tempfile.mkstemp(prefix='.video_source.', dir=str(path.parent))
try:
    with os.fdopen(fd, 'w', encoding='utf-8') as handle:
        json.dump(cfg, handle, indent=2)
        handle.write('\n')
    os.chmod(tmp, 0o660)
    os.chown(tmp, pwd.getpwnam('pi').pw_uid, grp.getgrnam('pi').gr_gid)
    os.replace(tmp, path)
finally:
    if os.path.exists(tmp):
        os.unlink(tmp)
print('WIFILINK2_VIDEO_DEFAULTS_ADDED')
PYWIFILINKMIGRATE

# Add 4.0.3 source-enable flags. Existing user choices are preserved.
sudo python3 - <<'PYVIDEOACTIVE'
import json, os, pwd, grp, tempfile
from pathlib import Path
path = Path('/etc/siyi/video_source.json')
try:
    cfg = json.loads(path.read_text(encoding='utf-8'))
except Exception:
    raise SystemExit(0)
if not isinstance(cfg, dict):
    raise SystemExit(0)
changed = False
for section in ('siyi', 'hdmi', 'wifilink'):
    if not isinstance(cfg.get(section), dict):
        cfg[section] = {}
        changed = True
    if 'enabled' not in cfg[section]:
        cfg[section]['enabled'] = True
        changed = True
if cfg.get('switch_mode') != 'direct-redirect':
    cfg['switch_mode'] = 'direct-redirect'
    changed = True
source_to_section = {
    'siyi_rtsp': 'siyi',
    'hdmi_usb': 'hdmi',
    'wifilink_rtsp': 'wifilink',
}
selected = cfg.get('source', 'siyi_rtsp')
if selected not in source_to_section:
    selected = 'siyi_rtsp'
    cfg['source'] = selected
    changed = True
if not cfg[source_to_section[selected]].get('enabled', True):
    for source, section in source_to_section.items():
        if cfg[section].get('enabled', True):
            cfg['source'] = source
            changed = True
            break
if not any(cfg[section].get('enabled', True) for section in source_to_section.values()):
    cfg['siyi']['enabled'] = True
    cfg['source'] = 'siyi_rtsp'
    changed = True
if not changed:
    raise SystemExit(0)
fd, tmp = tempfile.mkstemp(prefix='.video_source.', dir=str(path.parent))
try:
    with os.fdopen(fd, 'w', encoding='utf-8') as handle:
        json.dump(cfg, handle, indent=2)
        handle.write('\n')
    os.chmod(tmp, 0o660)
    os.chown(tmp, pwd.getpwnam('pi').pw_uid, grp.getgrnam('pi').gr_gid)
    os.replace(tmp, path)
finally:
    if os.path.exists(tmp):
        os.unlink(tmp)
print('VIDEO_SOURCE_ACTIVE_FLAGS_READY')
PYVIDEOACTIVE



# Add configured video-source names without replacing any existing non-empty name.
sudo python3 - <<'PYVIDEOSOURCENAMES'
import json, os, pwd, grp, tempfile
from pathlib import Path
path=Path('/etc/siyi/video_source.json')
try: cfg=json.loads(path.read_text(encoding='utf-8'))
except Exception: raise SystemExit(0)
if not isinstance(cfg,dict): raise SystemExit(0)
changed=False
def clean(v): return ' '.join(str(v or '').split())
for section, default in (('siyi','SIYI'),('hdmi','HDMI'),('wifilink','Air Link')):
    if not isinstance(cfg.get(section),dict): cfg[section]={}; changed=True
    if not clean(cfg[section].get('name')): cfg[section]['name']=default; changed=True
if not changed: raise SystemExit(0)
fd,tmp=tempfile.mkstemp(prefix='.video_source.',dir=str(path.parent))
try:
    with os.fdopen(fd,'w',encoding='utf-8') as h: json.dump(cfg,h,indent=2); h.write('\n')
    os.chmod(tmp,0o660); os.chown(tmp,pwd.getpwnam('pi').pw_uid,grp.getgrnam('pi').gr_gid); os.replace(tmp,path)
finally:
    if os.path.exists(tmp): os.unlink(tmp)
print('VIDEO_SOURCE_NAMES_READY')
PYVIDEOSOURCENAMES

# === HARD GATE: /etc/siyi must be writable by WebUI user ===
echo "[$SIYI_INSTALL_VERSION] Preflight: fixing /etc/siyi permissions"
sudo mkdir -p /etc/siyi
sudo touch /etc/siyi/zerotier_api_token
sudo touch /etc/siyi/zerotier_config.json
sudo touch /etc/siyi/setup_complete.json
ensure_button_safety_json

if [ ! -s /etc/siyi/setup_complete.json ]; then
  echo '{"complete": false}' | sudo tee /etc/siyi/setup_complete.json >/dev/null
fi

sudo chown -R pi:pi /etc/siyi || true
sudo chmod 664 /etc/siyi/button_safety.json || true
chmod 664 /etc/siyi/zerotier_api_token || true
sudo chmod 664 /etc/siyi/zerotier_config.json || true
sudo chmod 664 /etc/siyi/setup_complete.json || true

sudo -u pi test -w /etc/siyi/zerotier_api_token || {
  echo "INSTALL FAILED: pi cannot write /etc/siyi/zerotier_api_token"
  exit 1
}
sudo -u pi test -w /etc/siyi/zerotier_config.json || {
  echo "INSTALL FAILED: pi cannot write /etc/siyi/zerotier_config.json"
  exit 1
}
sudo -u pi test -w /etc/siyi/setup_complete.json || {
  echo "INSTALL FAILED: pi cannot write /etc/siyi/setup_complete.json"
  exit 1
}
# === end hard gate ===

# === UART PREFLIGHT / END-OF-INSTALL REBOOT ===
SIYI_UART_REBOOT_REQUIRED=0
export SIYI_UART_REBOOT_REQUIRED

if [ ! -e /dev/serial0 ]; then
  echo "=== SIYI $SIYI_INSTALL_VERSION UART PREFLIGHT ==="
  echo "Hardware UART missing. Enabling UART now; reboot will happen after installation completes."

  sudo raspi-config nonint do_serial_hw 0

  SIYI_UART_REBOOT_REQUIRED=1
  export SIYI_UART_REBOOT_REQUIRED
fi
# === END UART PREFLIGHT ===

POST_LOG="/home/pi/siyi_install_${SIYI_INSTALL_VERSION}_postdeploy_$(date +%Y%m%d_%H%M%S).log"

echo "=== SIYI INSTALLER $SIYI_INSTALL_VERSION ==="
echo "=== RUN ORIGINAL INSTALLER ==="
bash "$PAYLOAD_DIR/install_original_pre_231.sh"
if [ -f /tmp/siyi_webui_update.log ]; then
  sudo chown root:pi /tmp/siyi_webui_update.log 2>/dev/null || true
  sudo chmod 664 /tmp/siyi_webui_update.log 2>/dev/null || true
fi

echo "Core installer returned successfully."
sync

{
echo "=== SIYI $SIYI_INSTALL_VERSION POSTDEPLOY START ==="
date

echo "=== RUNTIME PERMISSION FIX ==="
sudo mkdir -p /etc/siyi

sudo touch /etc/siyi/zerotier_api_token
sudo touch /etc/siyi/zerotier_config.json
sudo touch /etc/siyi/setup_complete.json
ensure_button_safety_json

if [ ! -s /etc/siyi/zerotier_config.json ]; then
  echo '{}' | sudo tee /etc/siyi/zerotier_config.json >/dev/null
fi

if [ ! -s /etc/siyi/setup_complete.json ]; then
  echo '{"complete": false}' | sudo tee /etc/siyi/setup_complete.json >/dev/null
fi

sudo chown pi:pi /etc/siyi/zerotier_api_token /etc/siyi/zerotier_config.json /etc/siyi/setup_complete.json
sudo chmod 600 /etc/siyi/zerotier_api_token
sudo chmod 664 /etc/siyi/zerotier_config.json /etc/siyi/setup_complete.json

touch /tmp/siyi_webui_last_action
chown pi:pi /tmp/siyi_webui_last_action || true

echo "=== REQUIRED RUNTIME DEPLOY ==="

echo "=== $SIYI_INSTALL_VERSION BUTTON BRIDGE DEPLOY ==="
sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/scripts/siyi_mav_button_bridge.py" /home/pi/siyi_mav_button_bridge.py
sudo install -o root -g root -m 644 "$PAYLOAD_DIR/services/siyi-button-bridge.service" /etc/systemd/system/siyi-button-bridge.service
sudo install -d -o root -g root -m 755 /etc/systemd/system/siyi-button-bridge.service.d
sudo install -o root -g root -m 644 "$PAYLOAD_DIR/systemd-overrides/siyi-button-bridge.service.d/wait-for-zt.conf" /etc/systemd/system/siyi-button-bridge.service.d/wait-for-zt.conf
/home/pi/siyi-bridge-venv/bin/python -m py_compile /home/pi/siyi_mav_button_bridge.py

echo "=== $SIYI_INSTALL_VERSION SUDOERS DEPLOY ==="
sudo install -o root -g root -m 440 "$PAYLOAD_DIR/files/etc/sudoers.d/siyi-webui" /etc/sudoers.d/siyi-webui
sudo visudo -cf /etc/sudoers.d/siyi-webui

sudo install -o root -g root -m 755 "$PAYLOAD_DIR/files/usr/local/sbin/siyi-github-upgrade-launch" /usr/local/sbin/siyi-github-upgrade-launch
sudo install -o root -g root -m 755 "$PAYLOAD_DIR/files/usr/local/sbin/siyi-github-upgrade-worker" /usr/local/sbin/siyi-github-upgrade-worker
sudo install -o root -g root -m 755 "$PAYLOAD_DIR/files/usr/local/sbin/siyi-video-source-control" /usr/local/sbin/siyi-video-source-control
sudo install -o root -g root -m 755 "$PAYLOAD_DIR/files/usr/local/bin/siyi-video-source" /usr/local/bin/siyi-video-source
sudo install -o root -g root -m 755 "$PAYLOAD_DIR/files/usr/local/bin/siyi-video-udp-forward" /usr/local/bin/siyi-video-udp-forward
sudo install -o root -g root -m 644 "$PAYLOAD_DIR/services/siyi-video-source.service" /etc/systemd/system/siyi-video-source.service
sudo install -o root -g root -m 644 "$PAYLOAD_DIR/services/siyi-video-dual.service" /etc/systemd/system/siyi-video-dual.service
sudo install -d -o root -g root -m 755 /var/log
sudo touch /var/log/siyi-video-source.log
sudo chown pi:pi /var/log/siyi-video-source.log
sudo chmod 664 /var/log/siyi-video-source.log

sudo install -d -o pi -g pi -m 750 /var/lib/siyi-param-import
sudo install -d -o pi -g pi -m 750 /var/lib/siyi-param-import/sessions
sudo install -d -o pi -g pi -m 750 /var/backups/siyi-param-import
sudo install -m 755 "$PAYLOAD_DIR/files/usr/local/bin/siyi-paramd" /usr/local/bin/siyi-paramd

sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/siyi_param_full_cache.py" /home/pi/siyi_param_full_cache.py
sudo install -o root -g root -m 755 "$PAYLOAD_DIR/siyi_param_metadata_refresh.py" /home/pi/siyi_param_metadata_refresh.py
sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/siyi_param_read_one.py" /home/pi/siyi_param_read_one.py
sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/siyi_param_write_one.py" /home/pi/siyi_param_write_one.py
sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/siyi_param_refresh_wrapper.sh" /home/pi/siyi_param_refresh_wrapper.sh

echo "=== $SIYI_INSTALL_VERSION GROUND STATION DEPLOY ==="
sudo install -d -o root -g root -m 755 /usr/local/lib/siyi/groundstation
sudo install -o root -g root -m 755 "$PAYLOAD_DIR/scripts/groundstation_daemon.py" /usr/local/lib/siyi/groundstation/groundstation_daemon.py
sudo install -o root -g root -m 644 "$PAYLOAD_DIR/services/siyi-groundstation.service" /etc/systemd/system/siyi-groundstation.service
sudo install -d -o pi -g pi -m 755 /var/lib/siyi /var/log/siyi /run/siyi
sudo install -d -o pi -g pi -m 750 /var/lib/siyi/flight-logs /var/lib/siyi/groundstation
/home/pi/siyi-bridge-venv/bin/python -m py_compile /usr/local/lib/siyi/groundstation/groundstation_daemon.py

sudo install -m 644 "$PAYLOAD_DIR/services/siyi-webui.service" /etc/systemd/system/siyi-webui.service
sudo install -m 644 "$PAYLOAD_DIR/files/etc/systemd/system/siyi-paramd.service" /etc/systemd/system/siyi-paramd.service
sudo install -d -m 755 /usr/local/etc/mediamtx
sudo install -m 600 "$PAYLOAD_DIR/mediamtx.yml" /usr/local/etc/mediamtx/mediamtx.yml
sudo install -m 644 "$PAYLOAD_DIR/services/mediamtx.service" /etc/systemd/system/mediamtx.service
sudo install -m 644 "$PAYLOAD_DIR/services/siyi-rtsp-redirect.service" /etc/systemd/system/siyi-rtsp-redirect.service

echo "=== $SIYI_INSTALL_VERSION DEFAULT SIYI CONFIG DEPLOY ==="
sudo mkdir -p /etc/siyi

for f in endpoints.json cpu_temp_voice.json gimbal_zero.json gimbal_presets.json gimbal_virtual_config.json; do
  if [ -f "$PAYLOAD_DIR/config/$f" ] && [ ! -s "/etc/siyi/$f" ]; then
    sudo install -o pi -g pi -m 664 "$PAYLOAD_DIR/config/$f" "/etc/siyi/$f"
  fi
done
ensure_button_safety_json
ensure_groundstation_json

# Ensure JSON defaults exist even if source files were empty/missing
[ -s /etc/siyi/endpoints.json ] || echo "[]" | sudo tee /etc/siyi/endpoints.json >/dev/null
[ -s /etc/siyi/cpu_temp_voice.json ] || echo '{"enabled": false, "interval": 60}' | sudo tee /etc/siyi/cpu_temp_voice.json >/dev/null
[ -s /etc/siyi/gimbal_zero.json ] || echo '{}' | sudo tee /etc/siyi/gimbal_zero.json >/dev/null
[ -s /etc/siyi/gimbal_presets.json ] || echo '[]' | sudo tee /etc/siyi/gimbal_presets.json >/dev/null
[ -s /etc/siyi/gimbal_virtual_config.json ] || echo '{}' | sudo tee /etc/siyi/gimbal_virtual_config.json >/dev/null
[ -s /etc/siyi/video_source.json ] || sudo cp -f "$PAYLOAD_DIR/config/video_source.json" /etc/siyi/video_source.json
[ -s /etc/siyi/groundstation.json ] || sudo cp -f "$PAYLOAD_DIR/config/groundstation.json" /etc/siyi/groundstation.json
sudo chown pi:pi /etc/siyi/*.json || true
sudo chmod 664 /etc/siyi/*.json || true
sudo chmod 660 /etc/siyi/video_source.json || true

# On a fresh installation, select an attached stable USB capture path without
# hard-coding any vendor-specific device name. Existing selections are kept.
sudo python3 - <<'PYVIDEOAUTODETECT'
import glob, json, os, tempfile, pwd, grp
from pathlib import Path
path = Path('/etc/siyi/video_source.json')
try:
    cfg = json.loads(path.read_text(encoding='utf-8'))
except Exception:
    raise SystemExit(0)
hdmi = cfg.setdefault('hdmi', {})
if str(hdmi.get('device', '')).strip():
    raise SystemExit(0)
candidates = sorted(glob.glob('/dev/v4l/by-id/*-video-index0'))
if not candidates:
    raise SystemExit(0)
hdmi['device'] = candidates[0]
fd, tmp = tempfile.mkstemp(prefix='.video_source.', dir=str(path.parent))
try:
    with os.fdopen(fd, 'w', encoding='utf-8') as handle:
        json.dump(cfg, handle, indent=2)
        handle.write('\n')
    os.chmod(tmp, 0o660)
    os.chown(tmp, pwd.getpwnam('pi').pw_uid, grp.getgrnam('pi').gr_gid)
    os.replace(tmp, path)
finally:
    if os.path.exists(tmp):
        os.unlink(tmp)
print('HDMI_CAPTURE_DEFAULT=' + candidates[0])
PYVIDEOAUTODETECT

# Match MediaMTX to the preserved selected source before services start.
sudo /usr/local/sbin/siyi-video-source-control configure

echo "=== $SIYI_INSTALL_VERSION ENDPOINT APPLY ==="
sudo install -o pi -g pi -m 755 "$PAYLOAD_DIR/apply_siyi_endpoints.sh" /home/pi/apply_siyi_endpoints.sh
/home/pi/apply_siyi_endpoints.sh || true

printf "%s\n" "$SIYI_INSTALL_VERSION" | sudo tee /etc/siyi/release_version >/dev/null

sudo systemctl daemon-reload
sudo systemctl enable siyi-webui.service
sudo systemctl enable siyi-groundstation.service
sudo systemctl enable siyi-button-bridge.service
sudo systemctl enable siyi-paramd.service
sudo systemctl enable mediamtx.service
sudo systemctl enable siyi-rtsp-redirect.service
sudo systemctl enable siyi-video-source.service
sudo systemctl enable siyi-video-dual.service

# Dependency-safe restart order
sudo systemctl restart mavlink-router || true
sleep 2
sudo systemctl restart siyi-groundstation.service
sudo systemctl restart siyi-button-bridge || true
sudo systemctl restart siyi-paramd.service
sudo systemctl restart mediamtx.service
sudo systemctl restart siyi-rtsp-redirect.service || true
sudo systemctl restart siyi-video-source.service
sudo systemctl restart siyi-video-dual.service

sudo systemctl restart siyi-webui.service

echo "=== PARAM METADATA CACHE GENERATION ==="
if [ -f /home/pi/siyi_param_metadata_refresh.py ]; then
  timeout 60 sudo /usr/bin/python3 /home/pi/siyi_param_metadata_refresh.py || true
fi

if [ -x /home/pi/siyi-bridge-venv/bin/python ] && [ -f /home/pi/siyi_param_full_cache.py ]; then
  timeout 120 /home/pi/siyi-bridge-venv/bin/python /home/pi/siyi_param_full_cache.py || true
fi

if [ -s /tmp/siyi_param_cache.json ]; then
  sudo cp -f /tmp/siyi_param_cache.json /etc/siyi/param_metadata_cache.json
  sudo chmod 644 /etc/siyi/param_metadata_cache.json
  echo "PARAM_METADATA_CACHE_INSTALLED"
else
  echo "WARNING_PARAM_METADATA_CACHE_NOT_CREATED"
fi


echo "=== $SIYI_INSTALL_VERSION HARD POSTDEPLOY VALIDATION ==="


test -x /usr/local/bin/siyi-paramd
test -f /etc/systemd/system/siyi-paramd.service
test -f /etc/sudoers.d/siyi-webui
test -x /usr/local/bin/siyi-video-source
test -x /usr/local/bin/siyi-video-udp-forward
test -x /usr/local/sbin/siyi-video-source-control
test -s /etc/siyi/video_source.json
test -x /home/pi/siyi_mav_button_bridge.py
test -x /usr/local/lib/siyi/groundstation/groundstation_daemon.py
test -f /etc/systemd/system/siyi-groundstation.service
test -s /etc/siyi/groundstation.json
grep -q 'GROUND_STATION_PHONE_UI_V15' /home/pi/siyi-webui/server.py
grep -q 'GROUND_STATION_DUAL_VIDEO_PATHS_RELEASE_V3' /usr/local/sbin/siyi-video-source-control
grep -q '^\[UdpEndpoint groundstation\]' /home/pi/apply_siyi_endpoints.sh
grep -q 'FC_COMMAND_TRANSPORT_RELEASE_4_0_2' /home/pi/siyi_mav_button_bridge.py
grep -q 'GIMBAL_COMMAND_TRANSPORT_RELEASE_4_0_2' /home/pi/siyi_mav_button_bridge.py
grep -q 'VIDEO_SOURCE_CONFIGURED_NAMES_RELEASE_4_0_2' /usr/local/sbin/siyi-video-source-control
/home/pi/siyi-bridge-venv/bin/python -m py_compile /home/pi/siyi_mav_button_bridge.py
/home/pi/siyi-bridge-venv/bin/python -m py_compile /usr/local/lib/siyi/groundstation/groundstation_daemon.py
python3 -m json.tool /etc/siyi/button_safety.json >/dev/null
python3 -m json.tool /etc/siyi/groundstation.json >/dev/null
python3 - /etc/siyi/video_source.json <<'PYVALIDVIDEOSOURCENAMES'
import json,sys
cfg=json.load(open(sys.argv[1],encoding='utf-8'))
for section in ('siyi','hdmi','wifilink'):
    value=' '.join(str((cfg.get(section) or {}).get('name') or '').split())
    assert value, f'missing source name: {section}'
PYVALIDVIDEOSOURCENAMES
test -s /usr/local/etc/mediamtx/mediamtx.yml
systemctl is-enabled siyi-video-source.service >/dev/null
systemctl is-enabled siyi-video-dual.service >/dev/null
systemctl is-enabled siyi-groundstation.service >/dev/null
systemctl is-active --quiet siyi-groundstation.service

systemctl is-enabled siyi-paramd.service >/dev/null
systemctl is-active --quiet siyi-paramd.service

curl -fsS --max-time 5 http://127.0.0.1:8765/health >/dev/null
curl -fsS --max-time 5 http://127.0.0.1:18765/health >/dev/null
curl -fsS --max-time 5 http://127.0.0.1:8080/api/groundstation/health >/dev/null
curl -fsS --max-time 5 http://127.0.0.1:8080/groundstation | grep -q 'GROUND_STATION_PHONE_UI_V15'

test -s /etc/siyi/param_metadata_cache.json

python3 - <<'PYMETA'
import json
from pathlib import Path
paths = [
    Path('/etc/siyi/arduplane_param_metadata.json'),
    Path('/etc/siyi/param_metadata_cache.json'),
]
valid = False
for path in paths:
    try:
        raw = json.loads(path.read_text(encoding='utf-8'))
        entry = (raw.get('params') or {}).get('AIRSPEED_CRUISE') or {}
        if entry.get('humanName') or entry.get('documentation') or entry.get('fields') or entry.get('values'):
            valid = True
            print('PARAM_METADATA_LOOKUP_READY', path)
            break
    except Exception:
        pass
if not valid:
    print('WARNING_PARAM_METADATA_DESCRIPTIONS_NOT_AVAILABLE')
PYMETA

sudo -n systemctl restart mavlink-router
sleep 1
sudo -n systemctl restart siyi-groundstation.service
sudo -n systemctl restart siyi-button-bridge
sudo -n nmcli dev status >/dev/null

echo "=== $SIYI_INSTALL_VERSION HARD POSTDEPLOY VALIDATION OK ==="

echo "=== SIYI $SIYI_INSTALL_VERSION POSTDEPLOY COMPLETE ==="
date
} >> "$POST_LOG" 2>&1

# Print the full completion screen for a manual install. During a WebUI
# upgrade, the worker owns the concise final status shown in the browser.
if [ "${SIYI_WEBUI_UPGRADE:-0}" = "1" ]; then
  echo "Post-deployment validation complete."
  echo "Post-deployment log: ${POST_LOG}"
  if [ "${SIYI_UART_REBOOT_REQUIRED:-0}" = "1" ]; then
    echo "Reboot required: the Raspberry Pi hardware UART was enabled."
  fi
else
  if [ -n "$SSH_CONNECTION" ]; then
      CLIENT_IP="$(echo "$SSH_CONNECTION" | awk '{print $1}')"
      PRIMARY_IP="$(ip route get "$CLIENT_IP" 2>/dev/null | sed -n 's/.* src \([^ ]*\).*/\1/p')"
  fi

  if [ -z "$PRIMARY_IP" ]; then
      PRIMARY_IP="$(hostname -I | awk '{print $1}')"
  fi
  if [ -z "${PRIMARY_IP:-}" ]; then
    PRIMARY_IP="installertest.local"
  fi

  echo
  echo "========================================"
  echo "✅ SIYI Installer $SIYI_INSTALL_VERSION complete"
  echo "========================================"
  echo
  echo "Web UI:"
  echo "  http://${PRIMARY_IP}:8080"
  echo
  echo "Ground Station:"
  echo "  http://${PRIMARY_IP}:8080/groundstation"
  echo
  echo "Log:"
  echo "  ${POST_LOG}"
  echo

  echo "========================================"
  echo "IMPORTANT"
  echo "========================================"
  echo
  echo "If this is a fresh Raspberry Pi installation,"
  echo "please reboot the Raspberry Pi before using"
  echo "the SIYI system."
  echo
  echo "Run:"
  echo "  sudo reboot"
  echo

  if [ "${SIYI_UART_REBOOT_REQUIRED:-0}" = "1" ]; then
    echo "Hardware UART has been enabled."
    echo "The Raspberry Pi must reboot once before MAVLink UART telemetry is available."
    echo
    read -r -p "Reboot now? [Y/n] " answer
    answer="${answer:-Y}"
    case "$answer" in
      y|Y|yes|YES|Yes)
        echo "Rebooting now..."
        sleep 3
        sudo reboot
        ;;
      *)
        echo "Reboot skipped. Reboot manually later with: sudo reboot"
        ;;
    esac
  fi
fi

exit 0
