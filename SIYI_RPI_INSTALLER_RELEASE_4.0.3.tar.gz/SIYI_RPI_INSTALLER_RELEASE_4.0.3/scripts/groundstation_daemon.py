#!/usr/bin/env python3
"""SIYI Ground Station read-only telemetry daemon.

Receives MAVLink from the dedicated mavlink-router UDP endpoint, maintains a
normalized state model, and exposes a loopback-only JSON/SSE interface for the
existing WebUI. This first live patch is deliberately monitor-only.
"""

from __future__ import annotations

import copy
import json
import math
import os
import threading
import time
from collections import deque
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from pymavlink import mavutil

CONFIG_PATH = Path("/etc/siyi/groundstation.json")
DEFAULT_CONFIG: Dict[str, Any] = {
    "enabled": True,
    "mavlink": {
        "host": "0.0.0.0",
        "port": 14602,
        "system_id": 254,
        "component_id": 192,
        "manage_message_intervals": False,
    },
    "internal_api": {"host": "127.0.0.1", "port": 18765},
    "video": {
        "path": "main.264",
        "primary_protocol": "webrtc",
        "fallback_protocol": "hls",
    },
    "controls": {"enabled": False},
    "telemetry": {
        "airspeed_unit": "kmh",
        "altitude_unit": "m",
        "distance_unit": "metric",
    },
    "warnings": {
        "heartbeat_degraded_s": 3.0,
        "heartbeat_lost_s": 5.0,
    },
    "track": {"maximum_points": 3000, "minimum_interval_s": 0.8},
}


def deep_merge(base: Dict[str, Any], incoming: Dict[str, Any]) -> Dict[str, Any]:
    result = copy.deepcopy(base)
    for key, value in incoming.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def load_config() -> Dict[str, Any]:
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("configuration root is not an object")
        return deep_merge(DEFAULT_CONFIG, raw)
    except FileNotFoundError:
        return copy.deepcopy(DEFAULT_CONFIG)
    except Exception as exc:
        print(f"[GROUNDSTATION_CONFIG] using defaults: {exc!r}", flush=True)
        return copy.deepcopy(DEFAULT_CONFIG)


def finite(value: Any) -> Optional[float]:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def degrees(value: Any) -> Optional[float]:
    number = finite(value)
    return math.degrees(number) if number is not None else None


def gps_fix_name(value: int) -> str:
    return {
        0: "NO GPS",
        1: "NO FIX",
        2: "2D",
        3: "3D",
        4: "DGPS",
        5: "RTK FLOAT",
        6: "RTK FIXED",
        7: "STATIC",
        8: "PPP",
    }.get(int(value or 0), "UNKNOWN")


def severity_name(value: int) -> str:
    return {
        0: "Emergency",
        1: "Alert",
        2: "Critical",
        3: "Error",
        4: "Warning",
        5: "Notice",
        6: "Info",
        7: "Debug",
    }.get(int(value or 6), "Info")


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    radius = 6371000.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * radius * math.atan2(math.sqrt(a), math.sqrt(max(0.0, 1.0 - a)))


def bearing_deg(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dl = math.radians(lon2 - lon1)
    y = math.sin(dl) * math.cos(p2)
    x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dl)
    return (math.degrees(math.atan2(y, x)) + 360.0) % 360.0


class VehicleState:
    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.lock = threading.RLock()
        self.started_monotonic = time.monotonic()
        self.started_wall = time.time()
        self.selected_vehicle: Optional[Tuple[int, int]] = None
        self.vehicle_heartbeats: Dict[Tuple[int, int], float] = {}
        self.field_times: Dict[str, float] = {}
        self.messages = deque(maxlen=250)
        self.track = deque(maxlen=int(config.get("track", {}).get("maximum_points", 3000)))
        self.last_track_time = 0.0
        self.last_track_position: Optional[Tuple[float, float]] = None
        self.armed_since: Optional[float] = None
        self.total_armed_s = 0.0
        self.state: Dict[str, Any] = {
            "connection": {
                "state": "NO_VEHICLE",
                "heartbeat_age_s": None,
                "system_id": None,
                "component_id": None,
                "multiple_vehicles": False,
            },
            "vehicle": {
                "type": None,
                "autopilot": None,
                "armed": None,
                "mode": None,
                "system_status": None,
            },
            "attitude": {"roll_deg": None, "pitch_deg": None, "heading_deg": None},
            "position": {
                "lat": None,
                "lon": None,
                "relative_alt_m": None,
                "amsl_alt_m": None,
                "ground_course_deg": None,
            },
            "speed": {
                "airspeed_m_s": None,
                "groundspeed_m_s": None,
                "vertical_speed_m_s": None,
                "throttle_pct": None,
            },
            "battery": {
                "voltage_v": None,
                "current_a": None,
                "remaining_pct": None,
                "consumed_mah": None,
            },
            "gps": {"fix": "UNKNOWN", "fix_type": None, "satellites": None, "hdop": None},
            "navigation": {
                "home_lat": None,
                "home_lon": None,
                "home_distance_m": None,
                "home_bearing_deg": None,
                "waypoint_current": None,
                "waypoint_reached": None,
                "target_bearing_deg": None,
                "distance_to_waypoint_m": None,
            },
            "link": {
                "rssi": None,
                "remote_rssi": None,
                "noise": None,
                "remote_noise": None,
                "rx_errors": None,
                "fixed_packets": None,
            },
            "wind": {"speed_m_s": None, "direction_deg": None, "vertical_m_s": None},
            "rc": {"channels": []},
            "servo": {"outputs": []},
            "timers": {"connected_s": 0.0, "armed_s": 0.0},
            "messages": [],
            "track": [],
            "field_age_s": {},
            "service": {
                "monitor_only": True,
                "started_at": self.started_wall,
                "last_packet_at": None,
                "packet_count": 0,
            },
        }

    def _touch(self, field: str, now: float) -> None:
        self.field_times[field] = now

    def _is_fc_heartbeat(self, msg: Any) -> bool:
        autopilot = int(getattr(msg, "autopilot", mavutil.mavlink.MAV_AUTOPILOT_INVALID))
        vehicle_type = int(getattr(msg, "type", mavutil.mavlink.MAV_TYPE_GENERIC))
        if autopilot == mavutil.mavlink.MAV_AUTOPILOT_INVALID:
            return False
        if vehicle_type in {
            mavutil.mavlink.MAV_TYPE_GCS,
            mavutil.mavlink.MAV_TYPE_ONBOARD_CONTROLLER,
            mavutil.mavlink.MAV_TYPE_GIMBAL,
        }:
            return False
        return True

    def _selected(self, msg: Any) -> bool:
        if self.selected_vehicle is None:
            return False
        return (msg.get_srcSystem(), msg.get_srcComponent()) == self.selected_vehicle

    def update(self, msg: Any) -> None:
        now = time.monotonic()
        kind = msg.get_type()
        if kind == "BAD_DATA":
            return
        with self.lock:
            self.state["service"]["packet_count"] += 1
            self.state["service"]["last_packet_at"] = time.time()

            if kind == "HEARTBEAT" and self._is_fc_heartbeat(msg):
                key = (msg.get_srcSystem(), msg.get_srcComponent())
                self.vehicle_heartbeats[key] = now
                active = [item for item, ts in self.vehicle_heartbeats.items() if now - ts <= 5.0]
                active.sort()
                self.state["connection"]["multiple_vehicles"] = len(active) > 1
                if self.selected_vehicle not in active:
                    self.selected_vehicle = active[0] if len(active) == 1 else None
                if self.selected_vehicle == key:
                    base_mode = int(getattr(msg, "base_mode", 0) or 0)
                    armed = bool(base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED)
                    previous = self.state["vehicle"].get("armed")
                    if armed and previous is not True:
                        self.armed_since = now
                    elif not armed and previous is True and self.armed_since is not None:
                        self.total_armed_s += max(0.0, now - self.armed_since)
                        self.armed_since = None
                    self.state["vehicle"].update(
                        {
                            "type": mavutil.mavlink.enums["MAV_TYPE"].get(int(msg.type), None).name
                            if int(msg.type) in mavutil.mavlink.enums["MAV_TYPE"]
                            else str(int(msg.type)),
                            "autopilot": mavutil.mavlink.enums["MAV_AUTOPILOT"].get(int(msg.autopilot), None).name
                            if int(msg.autopilot) in mavutil.mavlink.enums["MAV_AUTOPILOT"]
                            else str(int(msg.autopilot)),
                            "armed": armed,
                            "mode": mavutil.mode_string_v10(msg),
                            "system_status": mavutil.mavlink.enums["MAV_STATE"].get(int(msg.system_status), None).name
                            if int(msg.system_status) in mavutil.mavlink.enums["MAV_STATE"]
                            else str(int(msg.system_status)),
                        }
                    )
                    self._touch("vehicle", now)
                return

            if not self._selected(msg):
                return

            # GROUND_STATION_ATTITUDE_FALLBACK_V6
            if kind == "ATTITUDE":
                self.state["attitude"].update(
                    {
                        "roll_deg": degrees(msg.roll),
                        "pitch_deg": degrees(msg.pitch),
                        "heading_deg": (degrees(msg.yaw) or 0.0) % 360.0,
                    }
                )
                self._touch("attitude", now)

            elif kind == "ATTITUDE_QUATERNION":
                q1 = finite(getattr(msg, "q1", None))
                q2 = finite(getattr(msg, "q2", None))
                q3 = finite(getattr(msg, "q3", None))
                q4 = finite(getattr(msg, "q4", None))
                if None not in (q1, q2, q3, q4):
                    sinr_cosp = 2.0 * (q1 * q2 + q3 * q4)
                    cosr_cosp = 1.0 - 2.0 * (q2 * q2 + q3 * q3)
                    roll = math.atan2(sinr_cosp, cosr_cosp)
                    sinp = 2.0 * (q1 * q3 - q4 * q2)
                    pitch = math.copysign(math.pi / 2.0, sinp) if abs(sinp) >= 1.0 else math.asin(sinp)
                    siny_cosp = 2.0 * (q1 * q4 + q2 * q3)
                    cosy_cosp = 1.0 - 2.0 * (q3 * q3 + q4 * q4)
                    yaw = math.atan2(siny_cosp, cosy_cosp)
                    self.state["attitude"].update(
                        {
                            "roll_deg": degrees(roll),
                            "pitch_deg": degrees(pitch),
                            "heading_deg": (degrees(yaw) or 0.0) % 360.0,
                        }
                    )
                    self._touch("attitude", now)

            elif kind == "AHRS2":
                roll = finite(getattr(msg, "roll", None))
                pitch = finite(getattr(msg, "pitch", None))
                yaw = finite(getattr(msg, "yaw", None))
                if roll is not None and pitch is not None:
                    self.state["attitude"].update(
                        {
                            "roll_deg": degrees(roll),
                            "pitch_deg": degrees(pitch),
                            "heading_deg": (degrees(yaw) or 0.0) % 360.0 if yaw is not None else self.state["attitude"].get("heading_deg"),
                        }
                    )
                    self._touch("attitude", now)

            elif kind == "GLOBAL_POSITION_INT":
                lat = int(msg.lat) / 1e7
                lon = int(msg.lon) / 1e7
                heading = None if int(msg.hdg) == 65535 else int(msg.hdg) / 100.0
                self.state["position"].update(
                    {
                        "lat": lat,
                        "lon": lon,
                        "relative_alt_m": int(msg.relative_alt) / 1000.0,
                        "amsl_alt_m": int(msg.alt) / 1000.0,
                        "ground_course_deg": heading,
                    }
                )
                self.state["speed"]["groundspeed_m_s"] = math.hypot(int(msg.vx), int(msg.vy)) / 100.0
                self.state["speed"]["vertical_speed_m_s"] = -int(msg.vz) / 100.0
                self._touch("position", now)
                self._touch("speed", now)
                self._update_track(lat, lon, now)
                self._update_home_geometry()

            elif kind == "VFR_HUD":
                self.state["speed"].update(
                    {
                        "airspeed_m_s": finite(msg.airspeed),
                        "groundspeed_m_s": finite(msg.groundspeed),
                        "vertical_speed_m_s": finite(msg.climb),
                        "throttle_pct": finite(msg.throttle),
                    }
                )
                if self.state["position"].get("amsl_alt_m") is None:
                    self.state["position"]["amsl_alt_m"] = finite(msg.alt)
                if self.state["attitude"].get("heading_deg") is None:
                    self.state["attitude"]["heading_deg"] = finite(msg.heading)
                self._touch("speed", now)

            elif kind == "GPS_RAW_INT":
                eph = int(getattr(msg, "eph", 65535))
                self.state["gps"].update(
                    {
                        "fix_type": int(msg.fix_type),
                        "fix": gps_fix_name(int(msg.fix_type)),
                        "satellites": int(msg.satellites_visible) if int(msg.satellites_visible) != 255 else None,
                        "hdop": None if eph == 65535 else eph / 100.0,
                    }
                )
                self._touch("gps", now)

            elif kind == "SYS_STATUS":
                voltage = int(getattr(msg, "voltage_battery", 65535))
                current = int(getattr(msg, "current_battery", -1))
                remaining = int(getattr(msg, "battery_remaining", -1))
                self.state["battery"].update(
                    {
                        "voltage_v": None if voltage == 65535 else voltage / 1000.0,
                        "current_a": None if current < 0 else current / 100.0,
                        "remaining_pct": None if remaining < 0 else remaining,
                    }
                )
                self._touch("battery", now)

            elif kind == "BATTERY_STATUS":
                voltages = [int(value) for value in getattr(msg, "voltages", []) if 0 < int(value) < 65535]
                if voltages:
                    self.state["battery"]["voltage_v"] = sum(voltages) / 1000.0
                current = int(getattr(msg, "current_battery", -1))
                remaining = int(getattr(msg, "battery_remaining", -1))
                consumed = int(getattr(msg, "current_consumed", -1))
                if current >= 0:
                    self.state["battery"]["current_a"] = current / 100.0
                if remaining >= 0:
                    self.state["battery"]["remaining_pct"] = remaining
                if consumed >= 0:
                    self.state["battery"]["consumed_mah"] = consumed
                self._touch("battery", now)

            elif kind == "HOME_POSITION":
                self.state["navigation"]["home_lat"] = int(msg.latitude) / 1e7
                self.state["navigation"]["home_lon"] = int(msg.longitude) / 1e7
                self._touch("home", now)
                self._update_home_geometry()

            elif kind == "RADIO_STATUS":
                self.state["link"].update(
                    {
                        "rssi": int(msg.rssi),
                        "remote_rssi": int(msg.remrssi),
                        "noise": int(msg.noise),
                        "remote_noise": int(msg.remnoise),
                        "rx_errors": int(msg.rxerrors),
                        "fixed_packets": int(msg.fixed),
                    }
                )
                self._touch("link", now)

            elif kind == "MISSION_CURRENT":
                self.state["navigation"]["waypoint_current"] = int(msg.seq)
                self._touch("mission", now)

            elif kind == "MISSION_ITEM_REACHED":
                self.state["navigation"]["waypoint_reached"] = int(msg.seq)
                self._touch("mission", now)

            elif kind == "NAV_CONTROLLER_OUTPUT":
                self.state["navigation"]["target_bearing_deg"] = finite(msg.target_bearing)
                self.state["navigation"]["distance_to_waypoint_m"] = finite(msg.wp_dist)
                self._touch("navigation", now)

            elif kind == "WIND":
                self.state["wind"].update(
                    {
                        "direction_deg": finite(msg.direction),
                        "speed_m_s": finite(msg.speed),
                        "vertical_m_s": finite(msg.speed_z),
                    }
                )
                self._touch("wind", now)

            elif kind == "RC_CHANNELS":
                count = max(0, min(18, int(getattr(msg, "chancount", 18) or 18)))
                values = []
                for index in range(1, count + 1):
                    value = int(getattr(msg, f"chan{index}_raw", 65535))
                    values.append(None if value == 65535 else value)
                self.state["rc"]["channels"] = values
                self._touch("rc", now)

            elif kind == "SERVO_OUTPUT_RAW":
                values = []
                for index in range(1, 17):
                    if not hasattr(msg, f"servo{index}_raw"):
                        break
                    value = int(getattr(msg, f"servo{index}_raw", 0))
                    values.append(value if value > 0 else None)
                self.state["servo"]["outputs"] = values
                self._touch("servo", now)

            elif kind == "STATUSTEXT":
                text = str(getattr(msg, "text", "") or "").rstrip("\x00").strip()
                if text:
                    item = {
                        "ts": time.time(),
                        "severity": severity_name(int(getattr(msg, "severity", 6))),
                        "severity_id": int(getattr(msg, "severity", 6)),
                        "text": text,
                        "system_id": msg.get_srcSystem(),
                        "component_id": msg.get_srcComponent(),
                    }
                    self.messages.append(item)
                    self.state["messages"] = list(self.messages)[-50:]
                    print(f"[GROUNDSTATION_MESSAGE] {item['severity']}: {text}", flush=True)

    def _update_track(self, lat: float, lon: float, now: float) -> None:
        minimum_interval = float(self.config.get("track", {}).get("minimum_interval_s", 0.8))
        if now - self.last_track_time < minimum_interval:
            return
        if self.last_track_position is not None:
            distance = haversine_m(self.last_track_position[0], self.last_track_position[1], lat, lon)
            if distance < 1.0:
                return
        self.track.append({"lat": lat, "lon": lon, "ts": time.time()})
        self.last_track_time = now
        self.last_track_position = (lat, lon)
        self.state["track"] = list(self.track)

    def _update_home_geometry(self) -> None:
        position = self.state["position"]
        navigation = self.state["navigation"]
        values = (position.get("lat"), position.get("lon"), navigation.get("home_lat"), navigation.get("home_lon"))
        if any(value is None for value in values):
            navigation["home_distance_m"] = None
            navigation["home_bearing_deg"] = None
            return
        lat, lon, home_lat, home_lon = values
        navigation["home_distance_m"] = haversine_m(lat, lon, home_lat, home_lon)
        navigation["home_bearing_deg"] = bearing_deg(lat, lon, home_lat, home_lon)

    def snapshot(self) -> Dict[str, Any]:
        now = time.monotonic()
        with self.lock:
            result = copy.deepcopy(self.state)
            active = {key: ts for key, ts in self.vehicle_heartbeats.items() if now - ts <= 5.0}
            multiple = len(active) > 1
            heartbeat_age = None
            if self.selected_vehicle in active:
                heartbeat_age = max(0.0, now - active[self.selected_vehicle])
            degraded = float(self.config.get("warnings", {}).get("heartbeat_degraded_s", 3.0))
            lost = float(self.config.get("warnings", {}).get("heartbeat_lost_s", 5.0))
            if multiple:
                connection_state = "DEGRADED"
            elif heartbeat_age is None:
                connection_state = "NO_VEHICLE"
            elif heartbeat_age < degraded:
                connection_state = "CONNECTED"
            elif heartbeat_age <= lost:
                connection_state = "DEGRADED"
            else:
                connection_state = "LINK_LOST"
            result["connection"].update(
                {
                    "state": connection_state,
                    "heartbeat_age_s": heartbeat_age,
                    "system_id": self.selected_vehicle[0] if self.selected_vehicle else None,
                    "component_id": self.selected_vehicle[1] if self.selected_vehicle else None,
                    "multiple_vehicles": multiple,
                }
            )
            result["timers"]["connected_s"] = max(0.0, now - self.started_monotonic)
            armed_s = self.total_armed_s
            if self.armed_since is not None:
                armed_s += max(0.0, now - self.armed_since)
            result["timers"]["armed_s"] = armed_s
            result["field_age_s"] = {
                key: round(max(0.0, now - timestamp), 3)
                for key, timestamp in self.field_times.items()
            }
            result["service"]["uptime_s"] = max(0.0, now - self.started_monotonic)
            result["service"]["config_path"] = str(CONFIG_PATH)
            return result


class GroundStationRuntime:
    def __init__(self, config: Dict[str, Any]) -> None:
        self.config = config
        self.vehicle = VehicleState(config)
        self.stop_event = threading.Event()
        self.connection = None

    def stop(self, *_args: Any) -> None:
        self.stop_event.set()
        if self.connection is not None:
            try:
                self.connection.close()
            except Exception:
                pass

    def mavlink_loop(self) -> None:
        mav_cfg = self.config["mavlink"]
        endpoint = f"udpin:{mav_cfg.get('host', '0.0.0.0')}:{int(mav_cfg.get('port', 14602))}"
        while not self.stop_event.is_set():
            try:
                print(f"[GROUNDSTATION_MAVLINK] opening {endpoint}", flush=True)
                self.connection = mavutil.mavlink_connection(
                    endpoint,
                    source_system=int(mav_cfg.get("system_id", 254)),
                    source_component=int(mav_cfg.get("component_id", 192)),
                    dialect="ardupilotmega",
                )
                while not self.stop_event.is_set():
                    message = self.connection.recv_match(blocking=True, timeout=0.5)
                    if message is not None:
                        self.vehicle.update(message)
            except Exception as exc:
                print(f"[GROUNDSTATION_MAVLINK_ERROR] {exc!r}", flush=True)
                time.sleep(1.0)
            finally:
                if self.connection is not None:
                    try:
                        self.connection.close()
                    except Exception:
                        pass
                    self.connection = None


RUNTIME: Optional[GroundStationRuntime] = None


class ApiHandler(BaseHTTPRequestHandler):
    server_version = "SIYIGroundStation/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        print("[GROUNDSTATION_HTTP] " + (fmt % args), flush=True)

    def _json(self, payload: Any, status: int = 200) -> None:
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        assert RUNTIME is not None
        path = self.path.split("?", 1)[0]
        if path == "/health":
            snapshot = RUNTIME.vehicle.snapshot()
            self._json(
                {
                    "ok": True,
                    "service": "siyi-groundstation",
                    "monitor_only": True,
                    "connection": snapshot["connection"],
                    "packet_count": snapshot["service"]["packet_count"],
                    "uptime_s": snapshot["service"]["uptime_s"],
                }
            )
            return
        if path == "/state":
            self._json(RUNTIME.vehicle.snapshot())
            return
        if path == "/messages":
            snapshot = RUNTIME.vehicle.snapshot()
            self._json({"messages": snapshot.get("messages", [])})
            return
        if path == "/stream":
            self.send_response(HTTPStatus.OK)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
            self.send_header("Connection", "keep-alive")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            last_payload = None
            last_keepalive = 0.0
            try:
                while not RUNTIME.stop_event.is_set():
                    payload = json.dumps(RUNTIME.vehicle.snapshot(), ensure_ascii=False, separators=(",", ":"))
                    now = time.monotonic()
                    if payload != last_payload:
                        self.wfile.write(("data: " + payload + "\n\n").encode("utf-8"))
                        self.wfile.flush()
                        last_payload = payload
                        last_keepalive = now
                    elif now - last_keepalive >= 10.0:
                        self.wfile.write(b": keepalive\n\n")
                        self.wfile.flush()
                        last_keepalive = now
                    time.sleep(0.1)
            except (BrokenPipeError, ConnectionResetError, TimeoutError):
                pass
            return
        self._json({"error": "not found"}, 404)


def main() -> int:
    global RUNTIME
    config = load_config()
    if not bool(config.get("enabled", True)):
        print("[GROUNDSTATION] disabled in configuration", flush=True)
        return 0
    RUNTIME = GroundStationRuntime(config)
    thread = threading.Thread(target=RUNTIME.mavlink_loop, name="mavlink", daemon=True)
    thread.start()
    api_cfg = config["internal_api"]
    server = ThreadingHTTPServer((str(api_cfg.get("host", "127.0.0.1")), int(api_cfg.get("port", 18765))), ApiHandler)
    server.daemon_threads = True
    print(
        "[GROUNDSTATION] monitor-only daemon ready on "
        f"{api_cfg.get('host', '127.0.0.1')}:{int(api_cfg.get('port', 18765))}",
        flush=True,
    )
    try:
        server.serve_forever(poll_interval=0.5)
    finally:
        RUNTIME.stop()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
