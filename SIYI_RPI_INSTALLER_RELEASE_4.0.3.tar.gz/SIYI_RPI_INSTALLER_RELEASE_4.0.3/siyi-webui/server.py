import threading

# === CONFIG LOAD ===
import json
from email.utils import parsedate_to_datetime
from zoneinfo import ZoneInfo
try:
    with open("/home/pi/siyi-config.json") as cf:
        CFG = json.load(cf)
except Exception:
    CFG = {}

CAM_IP = CFG.get("camera_ip", "192.168.144.25")
QGC_HOSTS = CFG.get("qgc_hosts", [])
VIDEO_PORT = CFG.get("video_port", 5600)
# === END CONFIG ===

RELEASE_VERSION_FILE = "/etc/siyi/release_version"

def get_release_version():
    try:
        with open(RELEASE_VERSION_FILE, "r", encoding="utf-8") as f:
            v = f.read().strip()
        return v if v else "unknown"
    except Exception:
        return "unknown"

VERSION = get_release_version()


# === SOFTWARE_UPDATE_V3 ===
SOFTWARE_UPDATE_MANIFEST_URL = (
    "https://raw.githubusercontent.com/"
    "johbaa/SIYI_PI_Installer/main/manifest.json"
)
SOFTWARE_UPDATE_LOG_FILE = "/tmp/siyi_webui_update.log"
SOFTWARE_UPDATE_PID_FILE = "/run/siyi-github-upgrade.pid"
SOFTWARE_UPDATE_STATE_FILE = "/var/lib/siyi-upgrade/state.json"
SOFTWARE_UPDATE_LAUNCHER = "/usr/local/sbin/siyi-github-upgrade-launch"
SOFTWARE_UPDATE_PREFERENCES_FILE = "/var/lib/siyi-upgrade/preserve_preferences.json"
# SOFTWARE_UPDATE_NO_WIZARD_AFTER_UPGRADE_V1
SOFTWARE_UPDATE_COMPLETED_FILE = "/var/lib/siyi-upgrade/upgrade_completed"
SOFTWARE_UPDATE_ACTIVE_STATUSES = {
    "starting", "checking", "downloading", "verifying", "backing_up",
    "installing", "restoring", "restarting",
}
SOFTWARE_UPDATE_PRESERVE_GROUPS = (
    ("buttons", "Button assignments and safety"),
    ("flaps", "Flap configuration"),
    ("mavlink", "MAVLink router, hosts and endpoints"),
    ("camera", "Camera and core SIYI configuration"),
    ("gimbal", "Gimbal presets, zero and virtual settings"),
    ("voice", "CPU temperature voice settings"),
    ("video", "Video sources and Air Link device connection"),
)
SOFTWARE_UPDATE_DEFAULT_PRESERVE = tuple(
    key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS
)


def _software_version_tuple(value):
    value = str(value or "").strip()
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+", value):
        raise ValueError("Invalid release version: " + value)
    return tuple(int(part) for part in value.split("."))


def software_update_is_newer(candidate, current):
    return _software_version_tuple(candidate) > _software_version_tuple(current)


# SOFTWARE_UPDATE_MANIFEST_CACHE_BYPASS_V1
def software_update_manifest():
    separator = "&" if "?" in SOFTWARE_UPDATE_MANIFEST_URL else "?"
    manifest_url = (
        SOFTWARE_UPDATE_MANIFEST_URL
        + separator
        + "cache_bust="
        + str(time.time_ns())
    )
    req = urllib.request.Request(
        manifest_url,
        headers={
            "User-Agent": "SIYI-Pi-Updater/4",
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
        },
    )
    with urllib.request.urlopen(req, timeout=8) as response:
        raw = response.read(65536)
    data = json.loads(raw.decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("GitHub manifest is not a JSON object")
    stable = str(data.get("stable", "")).strip()
    _software_version_tuple(stable)
    return {"stable": stable}


# SOFTWARE_UPDATE_PID_EPERM_FIX_V1
# The upgrade worker runs as root while the WebUI runs as pi. On Linux,
# os.kill(pid, 0) raises PermissionError when the process exists but the
# caller is not allowed to signal it. That means "running", not "stopped".
def software_update_pid_running():
    try:
        with open(SOFTWARE_UPDATE_PID_FILE, "r", encoding="utf-8") as f:
            pid = int(f.read().strip())
    except (OSError, ValueError):
        return False

    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError:
        return False
    return True


def software_update_state():
    state = {
        "running": False,
        "status": "idle",
        "progress": 0,
        "stage": "No upgrade is running",
        "from_version": get_release_version(),
        "to_version": "",
        "started_at": "",
        "updated_at": "",
        "technical_log": "",
        "error": "",
    }
    state_mtime = 0.0
    try:
        state_mtime = os.path.getmtime(SOFTWARE_UPDATE_STATE_FILE)
        with open(SOFTWARE_UPDATE_STATE_FILE, "r", encoding="utf-8") as f:
            loaded = json.load(f)
        if isinstance(loaded, dict):
            state.update(loaded)
    except Exception:
        pass

    pid_running = software_update_pid_running()
    declared_running = bool(state.get("running"))
    status = str(state.get("status", "idle"))
    startup_grace = (
        declared_running
        and status == "starting"
        and state_mtime > 0
        and (time.time() - state_mtime) < 30
    )
    running = bool(pid_running or startup_grace)
    state["running"] = running

    if declared_running and not running and status in SOFTWARE_UPDATE_ACTIVE_STATUSES:
        state["status"] = "failed"
        state["progress"] = round(max(0.0, min(99.0, float(state.get("progress", 0) or 0))), 1)
        state["stage"] = "Upgrade process stopped unexpectedly"
        if not state.get("error"):
            state["error"] = "The upgrade process is no longer running."

    try:
        state["progress"] = round(max(0.0, min(100.0, float(state.get("progress", 0) or 0))), 1)
    except Exception:
        state["progress"] = 0
    for key in (
        "status", "stage", "from_version", "to_version", "started_at",
        "updated_at", "technical_log", "error",
    ):
        state[key] = str(state.get(key, "") or "")
    return state


def software_update_running():
    return bool(software_update_state().get("running"))


def software_update_lock_active():
    return software_update_running()


def software_update_log_tail(limit=30000):
    try:
        with open(SOFTWARE_UPDATE_LOG_FILE, "rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            f.seek(max(0, size - limit), os.SEEK_SET)
            return f.read().decode("utf-8", errors="replace")
    except Exception:
        return "Waiting for upgrade status..."


def software_update_status_payload():
    state = software_update_state()
    state["current"] = get_release_version()
    state["log"] = software_update_log_tail()
    return state


def software_update_preserve_preferences():
    allowed = {key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS}
    try:
        with open(SOFTWARE_UPDATE_PREFERENCES_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        values = data.get("preserve", [])
        if not isinstance(values, list):
            raise ValueError("preserve is not a list")
        requested = {str(value) for value in values}
        # Preferences written before video-source support had no schema marker.
        # Preserve the new setting by default once, while still respecting a
        # deliberate unchecked choice saved by the new UI.
        if int(data.get("schema_version", 1) or 1) < 2:
            requested.add("video")
        if not requested.issubset(allowed):
            raise ValueError("unknown preservation group")
        return tuple(
            key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS
            if key in requested
        )
    except FileNotFoundError:
        return SOFTWARE_UPDATE_DEFAULT_PRESERVE
    except Exception:
        return SOFTWARE_UPDATE_DEFAULT_PRESERVE


def software_update_validate_preserve_groups(values):
    allowed = {key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS}
    requested = [str(value).strip() for value in values if str(value).strip()]
    unknown = [value for value in requested if value not in allowed]
    if unknown:
        raise ValueError("Unknown preservation option: " + ", ".join(unknown))
    requested_set = set(requested)
    return tuple(
        key for key, _label in SOFTWARE_UPDATE_PRESERVE_GROUPS
        if key in requested_set
    )


def software_update_page():
    current = get_release_version()
    state = software_update_state()
    running = bool(state.get("running"))
    latest = "Unavailable"
    error = ""
    update_available = False

    try:
        latest = software_update_manifest()["stable"]
        update_available = software_update_is_newer(latest, current)
    except Exception as exc:
        error = str(exc)

    if running:
        state_text = "Installation is running"
        state_class = "warn"
    elif error:
        state_text = "Could not check GitHub"
        state_class = "bad"
    elif update_available:
        state_text = "A newer published release is available"
        state_class = "ok"
    else:
        state_text = "This system is up to date"
        state_class = "ok"

    disabled = "disabled" if (running or not update_available) else ""
    button_text = "Installation running..." if running else "Install published update"
    error_html = (
        "<p class='bad'><b>GitHub check failed:</b> " + esc(error) + "</p>"
        if error else ""
    )

    selected_preferences = set(software_update_preserve_preferences())
    selectable_rows = []
    for key, label in SOFTWARE_UPDATE_PRESERVE_GROUPS:
        checked = "checked" if key in selected_preferences else ""
        selectable_rows.append(
            "<label style='display:flex;align-items:center;gap:10px;"
            "padding:7px 0;cursor:pointer;'>"
            f"<input style='pointer-events:auto;width:auto;' type='checkbox' "
            f"name='preserve' value='{esc(key)}' data-label='{esc(label)}' {checked}>"
            f"<span>{esc(label)}</span>"
            "</label>"
        )
    selectable_html = "".join(selectable_rows)

    return f"""
    <h1>Software Update</h1>

    <div class='card'>
      <h2>Published release</h2>
      <table>
        <tr><th>Current installed version</th><td><b>{esc(current)}</b></td></tr>
        <tr><th>Latest published version</th><td><b>{esc(latest)}</b></td></tr>
        <tr><th>Status</th><td class='{state_class}'><b>{esc(state_text)}</b></td></tr>
      </table>
      {error_html}
    </div>

    <form method='post' action='/software_update_start'
          data-current='{esc(current)}' data-latest='{esc(latest)}'
          onsubmit='return softwareUpdateConfirm(this);'>
      <div class='card'>
        <h2>Settings to preserve</h2>
        <p class='small'>
          Checked user settings are restored after a successful upgrade.
          Unchecked groups are reset to the defaults supplied by the new release.
          A complete safety backup is always retained for rollback.
        </p>

        <h3>Always preserved</h3>
        <label style='display:flex;align-items:center;gap:10px;padding:7px 0;opacity:.85;'>
          <input style='width:auto;' type='checkbox' checked disabled>
          <span><b>Pi Wi-Fi profiles and saved passwords</b> — Always preserved</span>
        </label>
        <label style='display:flex;align-items:center;gap:10px;padding:7px 0;opacity:.85;'>
          <input style='width:auto;' type='checkbox' checked disabled>
          <span><b>ZeroTier identity and membership</b> — Always preserved</span>
        </label>
        <label style='display:flex;align-items:center;gap:10px;padding:7px 0;opacity:.85;'>
          <input style='width:auto;' type='checkbox' checked disabled>
          <span><b>Air Link Wi-Fi profiles and camera settings</b> — Stored on Air Link and not modified by Pi upgrades</span>
        </label>

        <h3>User-selectable settings</h3>
        {selectable_html}

        <label style='display:flex;align-items:center;gap:10px;padding:12px 0;cursor:pointer;'>
          <input style='pointer-events:auto;width:auto;' type='checkbox'
                 name='remember' value='1' checked>
          <span>Remember these choices for future upgrades</span>
        </label>

        <button style='pointer-events:auto;min-width:220px;' {disabled}>{esc(button_text)}</button>

        <p class='small'>
          The button is enabled only when the GitHub version is newer than the installed version.
          The release checksum is verified before installation.
        </p>
      </div>
    </form>

    <script>
    function softwareUpdateConfirm(form){{
      const selected = Array.from(form.querySelectorAll("input[name='preserve']:checked"))
        .map(function(input){{ return input.dataset.label || input.value; }});
      let message = 'Upgrade ' + form.dataset.current + ' → ' + form.dataset.latest + '?\\n\\n';
      message += 'Always preserved:\\n• Pi Wi-Fi profiles and saved passwords\\n• ZeroTier identity and membership\\n• Air Link profiles/camera settings remain on the Air Link device\\n\\n';
      if(selected.length){{
        message += 'Also preserve:\\n• ' + selected.join('\\n• ');
      }}else{{
        message += 'No selectable user settings are selected.\\n'
          + 'Release defaults will be used for all selectable groups.';
      }}
      message += '\\n\\nThe WebUI will be locked during installation.';
      if(!confirm(message)) return false;
      if(window.siyiUpgradeShowStarting){{
        window.siyiUpgradeShowStarting(form.dataset.current, form.dataset.latest);
      }}
      return true;
    }}
    </script>
    """
# === SOFTWARE_UPDATE_V3 END ===
#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse, parse_qsl
import subprocess
import socket
socket.setdefaulttimeout(5)
from pymavlink.dialects.v20 import common as mavlink2
from pymavlink.dialects.v20 import ardupilotmega as mavlink2
import shlex, os, csv, html, time, shutil, re, json, urllib.request, urllib.parse, urllib.error, zipfile, tempfile

PORT=8080

BUTTON_MAP="/home/pi/button_map.csv"
MAVCONF="/etc/mavlink-router/main.conf"
VIDEO_SERVICE="/etc/systemd/system/siyi-video-dual.service"
VIDEO_SOURCE_CONFIG="/etc/siyi/video_source.json"
VIDEO_SOURCE_STATUS="/run/siyi-video-source/status.json"
VIDEO_SOURCE_CONTROL="/usr/local/sbin/siyi-video-source-control"
BACKUP_DIR="/home/pi/siyi-webui/backups"
ENDPOINTS_FILE="/etc/siyi/endpoints.json"
ZT_CONFIG_FILE="/etc/siyi/zerotier_config.json"
ZT_TOKEN_FILE="/etc/siyi/zerotier_api_token"
BUTTON_SAFETY_FILE="/etc/siyi/button_safety.json"
GIMBAL_PRESETS_FILE="/etc/siyi/gimbal_presets.json"
GIMBAL_STATE_FILE="/home/pi/siyi_gimbal_state.json"
GIMBAL_ZERO_FILE="/etc/siyi/gimbal_zero.json"
FLIGHT_SAFETY_ACTIONS=["MANUAL","FBWA","AUTOTUNE","CRUISE","AUTO","LOITER","RTL","TAKEOFF","QHOVER","QLOITER","QLAND","QRTL"]



def send_mavlink_tcp5760(pkt):
    try:
        with socket.create_connection(("127.0.0.1", 5760), timeout=0.8) as sock:
            sock.sendall(pkt)
        return True
    except Exception as e:
        print("[WEBUI_TCP5760_SEND_FAIL]", repr(e), flush=True)
        return False

FLIGHT_MODE_CACHE_FILE="/tmp/siyi_flight_mode.json"
BUTTON_SAFETY_FILE="/etc/siyi/button_safety.json"

def read_pi_ui_mode_safety_blockers():

    default_block = {"MANUAL", "TAKEOFF"}

    try:
        with open(BUTTON_SAFETY_FILE, encoding="utf-8") as f:
            data = json.load(f)

        vals = data.get("block_when_armed", list(default_block))

        if not isinstance(vals, list):
            return default_block

        allowed = {
            "MANUAL", "FBWA", "AUTOTUNE", "CRUISE", "LOITER", "RTL",
            "TAKEOFF", "QHOVER", "QLOITER", "QLAND", "QRTL"
        }

        return {
            str(x).strip()
            for x in vals
            if str(x).strip() in allowed
        }

    except Exception:
        return default_block

def vehicle_is_armed_now():

    try:
        data = flight_mode_state_read_once()
        base_mode = int(data.get("base_mode", 0) or 0)
        return bool(base_mode & 128)

    except Exception:
        return False



ARDUPLANE_MODE_NAMES = {
    0:"MANUAL", 1:"CIRCLE", 2:"STABILIZE", 3:"TRAINING", 4:"ACRO",
    5:"FBWA", 6:"FBWB", 7:"CRUISE", 8:"AUTOTUNE", 10:"AUTO",
    11:"RTL", 12:"LOITER", 13:"TAKEOFF", 15:"GUIDED", 16:"INITIALISING",
    17:"QSTABILIZE", 18:"QHOVER", 19:"QLOITER", 20:"QLAND",
    21:"QRTL", 22:"QAUTOTUNE", 23:"QACRO", 24:"THERMAL",
    25:"LOITER_TO_QLAND", 26:"AUTOLAND"
}

def _parse_autopilot_heartbeat(pkt):
    try:
        if pkt and pkt[0] == 0xFD and len(pkt) >= 21:
            length = pkt[1]
            msgid = pkt[7] | (pkt[8] << 8) | (pkt[9] << 16)
            payload = pkt[10:10+length]
            if msgid == 0 and len(payload) >= 9:
                custom_mode = int.from_bytes(payload[0:4], "little", signed=False)
                mav_type = payload[4]
                autopilot = payload[5]
                base_mode = payload[6]
                if autopilot == 3 and mav_type != 6:
                    return (ARDUPLANE_MODE_NAMES.get(custom_mode, f"MODE {custom_mode}"), custom_mode, base_mode)

        if pkt and pkt[0] == 0xFE and len(pkt) >= 17:
            length = pkt[1]
            msgid = pkt[5]
            payload = pkt[6:6+length]
            if msgid == 0 and len(payload) >= 9:
                custom_mode = int.from_bytes(payload[0:4], "little", signed=False)
                mav_type = payload[4]
                autopilot = payload[5]
                base_mode = payload[6]
                if autopilot == 3 and mav_type != 6:
                    return (ARDUPLANE_MODE_NAMES.get(custom_mode, f"MODE {custom_mode}"), custom_mode, base_mode)
    except Exception:
        pass
    return None

def _write_flight_mode_cache(mode, custom_mode, base_mode):
    try:
        tmp = FLIGHT_MODE_CACHE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({
                "mode": mode,
                "custom_mode": custom_mode,
                "base_mode": base_mode,
                "last_seen": time.time(),
                "source": "server_mode_monitor"
            }, f)
        os.replace(tmp, FLIGHT_MODE_CACHE_FILE)
    except Exception as e:
        print("[MODE_MONITOR_CACHE_WRITE_FAIL]", repr(e), flush=True)

def _mode_monitor_loop():
    while True:
        try:
            print("[MODE_MONITOR_TCP5760] connecting to 127.0.0.1:5760", flush=True)

            with socket.create_connection(("127.0.0.1", 5760), timeout=3.0) as sock:
                sock.settimeout(1.0)
                mav = mavlink2.MAVLink(None)

                print("[MODE_MONITOR_TCP5760] connected", flush=True)

                while True:
                    try:
                        data = sock.recv(4096)
                        if not data:
                            raise RuntimeError("TCP5760 closed")

                        for b in data:
                            try:
                                msg = mav.parse_char(bytes([b]))
                            except Exception:
                                msg = None

                            if not msg:
                                continue

                            if msg.get_type() == "HEARTBEAT":
                                try:
                                    autopilot = int(getattr(msg, "autopilot", -1))
                                    mav_type = int(getattr(msg, "type", -1))
                                    custom_mode = int(getattr(msg, "custom_mode", -1))
                                    base_mode = int(getattr(msg, "base_mode", 0))

                                    if autopilot == 3 and mav_type != 6:
                                        mode = ARDUPLANE_MODE_NAMES.get(custom_mode, f"MODE {custom_mode}")
                                        _write_flight_mode_cache(mode, custom_mode, base_mode)
                                except Exception as e:
                                    print("[MODE_MONITOR_TCP5760_HEARTBEAT_FAIL]", repr(e), flush=True)

                    except socket.timeout:
                        pass

        except Exception as e:
            print("[MODE_MONITOR_TCP5760_FAIL]", repr(e), flush=True)
            time.sleep(1)

def start_mode_monitor_once():
    try:
        if getattr(start_mode_monitor_once, "_started", False):
            return
        start_mode_monitor_once._started = True
        t = threading.Thread(target=_mode_monitor_loop, daemon=True)
        t.start()
    except Exception as e:
        print("[MODE_MONITOR_START_FAIL]", repr(e), flush=True)

start_mode_monitor_once()

def flight_mode_state_read_once(timeout=0):
    try:
        data=json.load(open(FLIGHT_MODE_CACHE_FILE, encoding="utf-8"))
        last=float(data.get("last_seen",0) or 0)
        age=round(time.time()-last,1) if last else None
        return {
            "mode":data.get("mode","UNKNOWN"),
            "custom_mode":data.get("custom_mode"),
            "age_s":age,
            "last_seen":last,
            "base_mode":data.get("base_mode"),
            "source":data.get("source","cache_only")
        }
    except Exception:
        return {
            "mode":"UNKNOWN",
            "custom_mode":None,
            "age_s":None,
            "last_seen":0,
            "base_mode":None,
            "source":"none"
        }


SETUP_COMPLETE_FILE="/etc/siyi/setup_complete.json"
SETUP_SKIP_FILE="/tmp/siyi_setup_skip"

WIFI_PASSWORD_STORE="/home/pi/siyi-webui/wifi_passwords.json"

def wifi_pw_store_read():
    try:
        if os.path.exists(WIFI_PASSWORD_STORE):
            return json.load(open(WIFI_PASSWORD_STORE, encoding="utf-8"))
    except Exception:
        pass
    return {}

def wifi_pw_store_write(d):
    try:
        os.makedirs(os.path.dirname(WIFI_PASSWORD_STORE), exist_ok=True)
        with open(WIFI_PASSWORD_STORE, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=2)
        os.chmod(WIFI_PASSWORD_STORE, 0o600)
    except Exception as e:
        print("wifi password store write failed:", e)

def wifi_nm_password_get(name):
    try:
        result = subprocess.run(
            [
                "sudo", "-n", "nmcli", "--show-secrets",
                "-g", "802-11-wireless-security.psk",
                "connection", "show", str(name),
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            timeout=8,
            check=False,
        )
        value = (result.stdout or "").strip()
        if result.returncode == 0 and value and value not in {"--", "(none)"}:
            return value
    except Exception:
        pass
    return ""


def wifi_pw_get(name):
    store = wifi_pw_store_read()
    value = str(store.get(name, "") or "")
    if value:
        return value

    value = wifi_nm_password_get(name)
    if value:
        store[name] = value
        wifi_pw_store_write(store)
    return value

def wifi_pw_set(name, password):
    d = wifi_pw_store_read()
    d[name] = password
    wifi_pw_store_write(d)

def wifi_pw_delete(name):
    d = wifi_pw_store_read()
    if name in d:
        del d[name]
        wifi_pw_store_write(d)


def setup_config_is_valid():
    try:
        eps = load_endpoints()
        return (
            len([e for e in eps if e.get("ip","").strip()]) >= 1
            and bool(zt_network_id_current())
            and bool(zt_read_token())
        )
    except Exception:
        return False

def setup_is_complete():
    try:
        if os.path.exists(SETUP_COMPLETE_FILE):
            return setup_config_is_valid()

        return False
    except Exception:
        return False

def setup_should_force():
    # A software upgrade must return to the normal WebUI, not reopen the
    # first-install wizard. The wizard remains available manually.
    if os.path.exists(SOFTWARE_UPDATE_COMPLETED_FILE):
        return False
    return (not setup_is_complete()) and (not os.path.exists(SETUP_SKIP_FILE))

def setup_banner():
    if setup_config_is_valid():
        return ""
    return """
    <div class='card' style='margin-bottom:16px;border:2px solid #d39e00;background:#fff3cd;color:#3b2f00;'>
      <h2 style='margin-top:0;color:#3b2f00;'>⚠ First setup incomplete</h2>
      <p>ZeroTier and at least one endpoint host should be configured.</p>
      <a href='/first_setup'><button style='pointer-events:auto;'>Open Setup Wizard</button></a>
    </div>
    """

def first_setup_page():
    return f"""
    <h1>First Setup Wizard</h1>

    <div class='card'>
      <p>This setup appears until completed.</p>
      <p>You can skip for now and continue using the UI during this boot.</p>
    </div>

    <form method='post' action='/first_setup_save'>

      <div class='card'>
        <h2>ZeroTier</h2>

        <label>Network ID</label>
        <input style='pointer-events:auto;' name='nwid'
               value='{esc(zt_network_id_current())}'
               placeholder='ZeroTier network ID'>

        <label>API Token</label>
        <input style='pointer-events:auto;'
               id='fstoken'
               type='password'
               name='token'
               value='{esc(zt_read_token())}'
               placeholder='ZeroTier API token'>

        <label style='display:block;margin-top:8px;'>
          <input type='checkbox'
                 style='width:auto;'
                 onclick="document.getElementById('fstoken').type=this.checked?'text':'password'">
          Show token
        </label>
      </div>

      <div class='card'>
        <h2>Host Endpoint</h2>

        <label>Host name</label>
        <input style='pointer-events:auto;' name='name'
               placeholder='Mac / Android / QGC'>

        <label>Host IP</label>
        <input style='pointer-events:auto;' name='ip'
               placeholder='192.168.x.x'>
      </div>

      <div class='card'>
        <h2>Optional Additional WiFi</h2>

        <label>SSID</label>
        <input style='pointer-events:auto;' name='ssid'
               placeholder='Optional SSID'>

        <label>Password</label>
        <input style='pointer-events:auto;'
               id='fswifi'
               type='password'
               name='password'
               autocomplete='new-password'
               data-secret-state='new'
               placeholder='Optional new network password'>

        <label style='display:block;margin-top:8px;'>
          <input type='checkbox'
                 style='width:auto;'
                 onclick="document.getElementById('fswifi').type=this.checked?'text':'password'">
          Show password
        </label>
      </div>

      <div class='card'>
        <button style='pointer-events:auto;'>
          Save and Finish Setup
        </button>

        <button style='pointer-events:auto;margin-left:12px;'
                formaction='/first_setup_skip'>
          Skip for now
        </button>
      </div>

    </form>
    """

SERVICES=[
 "siyi-button-bridge",
 "siyi-video-source",
 "siyi-video-dual",
 "mediamtx",
 "mavlink-router",
 "zerotier-one",
 "siyi-rec-proxy",
 "siyi-rec-redirect",
 "siyi-webui",
]



STATUS_LABELS={
    "active":"Running",
    "activating":"Waiting / Starting",
    "failed":"Error",
    "inactive":"Stopped",
    "unknown":"Unknown",
}


SERVICE_GROUPS = {
    "Flight Control": ["mavlink-router"],
    "Video System": ["siyi-video-source", "siyi-video-dual", "mediamtx", "siyi-rec-proxy", "siyi-rec-redirect"],
    "Control System": ["siyi-button-bridge"],
    "Network": ["zerotier-one"],
    "System": ["siyi-webui"],
}

SERVICE_LABELS={
    "siyi-button-bridge":"Button Control Bridge",
    "siyi-video-source":"Selected Video Source",
    "siyi-video-dual":"Video UDP Forwarder",
    "mavlink-router":"MAVLink Router",
    "zerotier-one":"ZeroTier Network",
    "siyi-rec-proxy":"Camera / Recording Proxy",
    "siyi-rec-redirect":"Camera Control Redirect",
    "siyi-webui":"Web Interface",
}

ACTIONS=[
"NO_ACTION","MANUAL","FBWA","AUTOTUNE","CRUISE","AUTO","FLAPS",
"VIDEO_SOURCE","VIDEO_SOURCE_SIYI","VIDEO_SOURCE_HDMI","VIDEO_SOURCE_WIFILINK","LOITER","RTL",
"TAKEOFF","QHOVER","QLOITER","QLAND","QRTL",
"ARM","DISARM","TOGGLE_ARM",
"RECORD_TOGGLE","SNAPSHOT",
"ZOOM_IN","ZOOM_OUT","ZOOM_STOP",
"GIMBAL_YAW_RIGHT","GIMBAL_YAW_LEFT","GIMBAL_PITCH_UP","GIMBAL_PITCH_DOWN",
"GIMBAL_STOP","GIMBAL_CENTER","GIMBAL_CENTER_AND_ZOOM_OUT",
"GIMBAL_LOCK","GIMBAL_FOLLOW"
]

def sh(cmd):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT).strip()
    except subprocess.CalledProcessError as e:
        return e.output.strip()



BATTERY_STATUS_FILE="/tmp/siyi_battery_status.txt"

def battery_status():
    try:
        txt=open(BATTERY_STATUS_FILE).read().strip()
        if txt:
            return txt
    except:
        pass
    return "Bat ?"

def esc(x):
    return html.escape(str(x or ""))

def backup(path):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    if os.path.exists(path):
        dst=f"{BACKUP_DIR}/{os.path.basename(path)}.{time.strftime('%Y%m%d_%H%M%S')}.bak"
        shutil.copy2(path,dst)

def read_file(path):
    try:
        return open(path, encoding="utf-8", errors="replace").read()
    except Exception:
        return ""

def write_file(path, content):
    backup(path)
    open(path, "w", encoding="utf-8").write(content)


# === VIDEO_SOURCE_WEBUI_V1 START ===
def video_source_default_config():
    return {
        "source": "siyi_rtsp",
        "switch_mode": "direct-redirect",
        "output_url": "rtsp://127.0.0.1:8554/main.264",
        "siyi": {
            "enabled": True,
            "name": "SIYI",
            "url": "rtsp://192.168.144.25:8554/main.264",
            "transport": "tcp",
            "latency_ms": 0,
        },
        "hdmi": {
            "enabled": True,
            "name": "HDMI",
            "device": "",
            "input_format": "mjpeg",
            "width": 1280,
            "height": 720,
            "fps": 25,
            "audio_enabled": False,
            "encoder": "auto",
            "bitrate_kbps": 4000,
        },
        "wifilink": {
            "enabled": True,
            "name": "Air Link",
            "url": "rtsp://192.168.191.199:554/stream=0",
            "username": "root",
            "password": "",
            "transport": "tcp",
            "latency_ms": 0,
        },
        "udp": {"enabled": True, "port": 5600, "latency_ms": 0},
        "switch": {
            "verify_timeout_seconds": 15,
            "restore_on_failure": True,
            "debounce_seconds": 2,
        },
    }


def _video_source_merge(base, incoming):
    result = json.loads(json.dumps(base))
    if not isinstance(incoming, dict):
        return result
    for key, value in incoming.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _video_source_merge(result[key], value)
        else:
            result[key] = value
    return result


VIDEO_SOURCE_DEFAULT_NAMES = {
    "siyi_rtsp": "SIYI",
    "hdmi_usb": "HDMI",
    "wifilink_rtsp": "Air Link",
}


def video_source_clean_name(value, default):
    text = " ".join(str(value or "").split())
    text = "".join(ch for ch in text if ch.isprintable())
    if not text:
        return default
    return text[:40]


def video_source_names(cfg):
    return {
        "siyi_rtsp": video_source_clean_name(
            (cfg.get("siyi") or {}).get("name"),
            VIDEO_SOURCE_DEFAULT_NAMES["siyi_rtsp"],
        ),
        "hdmi_usb": video_source_clean_name(
            (cfg.get("hdmi") or {}).get("name"),
            VIDEO_SOURCE_DEFAULT_NAMES["hdmi_usb"],
        ),
        "wifilink_rtsp": video_source_clean_name(
            (cfg.get("wifilink") or {}).get("name"),
            VIDEO_SOURCE_DEFAULT_NAMES["wifilink_rtsp"],
        ),
    }


def video_source_read_config():
    cfg = video_source_default_config()
    try:
        with open(VIDEO_SOURCE_CONFIG, encoding="utf-8") as f:
            raw = json.load(f)
        cfg = _video_source_merge(cfg, raw)
    except Exception:
        pass
    source_sections = {
        "siyi_rtsp": "siyi",
        "hdmi_usb": "hdmi",
        "wifilink_rtsp": "wifilink",
    }
    for source_id, section in source_sections.items():
        cfg[section]["name"] = video_source_clean_name(
            cfg[section].get("name"), VIDEO_SOURCE_DEFAULT_NAMES[source_id]
        )
    enabled = [source for source, section in source_sections.items() if cfg[section].get("enabled", True)]
    if not enabled:
        cfg["siyi"]["enabled"] = True
        enabled = ["siyi_rtsp"]
    if cfg.get("source") not in enabled:
        cfg["source"] = enabled[0]
    return cfg


def video_source_read_status():
    try:
        with open(VIDEO_SOURCE_STATUS, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def video_source_devices():
    try:
        result = subprocess.run(
            ["sudo", "-n", VIDEO_SOURCE_CONTROL, "devices"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            timeout=12, check=False,
        )
        data = json.loads(result.stdout or "{}")
        devices = data.get("devices", [])
        return devices if isinstance(devices, list) else []
    except Exception:
        return []


def video_source_detected_paths():
    paths = set()
    for item in video_source_devices():
        if isinstance(item, dict):
            for key in ("path", "real_path"):
                value = str(item.get(key, ""))
                if value:
                    paths.add(value)
                    try:
                        paths.add(os.path.realpath(value))
                    except Exception:
                        pass
    return paths


def video_source_write_config(cfg):
    os.makedirs(os.path.dirname(VIDEO_SOURCE_CONFIG), exist_ok=True)
    previous = VIDEO_SOURCE_CONFIG + ".previous"
    if os.path.exists(VIDEO_SOURCE_CONFIG):
        shutil.copy2(VIDEO_SOURCE_CONFIG, previous)
    fd, tmp = tempfile.mkstemp(prefix=".video_source.", dir=os.path.dirname(VIDEO_SOURCE_CONFIG))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
            f.write("\n")
        os.chmod(tmp, 0o660)
        os.replace(tmp, VIDEO_SOURCE_CONFIG)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def video_source_int(value, minimum, maximum, label):
    try:
        parsed = int(str(value).strip())
    except Exception:
        raise ValueError(label + " must be a whole number")
    if not minimum <= parsed <= maximum:
        raise ValueError(label + f" must be between {minimum} and {maximum}")
    return parsed


def video_source_config_from_form(data):
    cfg = video_source_read_config()
    source = data.get("source", [cfg["source"]])[0]
    if source not in {"siyi_rtsp", "hdmi_usb", "wifilink_rtsp"}:
        raise ValueError("Invalid video source")
    siyi_enabled = "siyi_enabled" in data
    hdmi_enabled = "hdmi_enabled" in data
    wifilink_enabled = "wifilink_enabled" in data
    enabled_map = {
        "siyi_rtsp": siyi_enabled,
        "hdmi_usb": hdmi_enabled,
        "wifilink_rtsp": wifilink_enabled,
    }
    if not any(enabled_map.values()):
        raise ValueError("At least one video source must be active")
    if not enabled_map[source]:
        raise ValueError("The selected source must also be marked Active")
    siyi_url = data.get("siyi_url", [cfg["siyi"]["url"]])[0].strip()
    parsed = urllib.parse.urlparse(siyi_url)
    if parsed.scheme not in {"rtsp", "rtsps"} or not parsed.hostname:
        raise ValueError("SIYI source must be a valid RTSP URL")
    transport = data.get("transport", [cfg["siyi"].get("transport", "tcp")])[0]
    if transport not in {"tcp", "udp"}:
        raise ValueError("Invalid RTSP transport")
    wifilink_url = data.get("wifilink_url", [cfg["wifilink"]["url"]])[0].strip()
    parsed_wifilink = urllib.parse.urlparse(wifilink_url)
    if parsed_wifilink.scheme not in {"rtsp", "rtsps"} or not parsed_wifilink.hostname:
        raise ValueError("RunCam WiFiLink2 source must be a valid RTSP URL")
    wifilink_transport = data.get("wifilink_transport", [cfg["wifilink"].get("transport", "tcp")])[0]
    if wifilink_transport not in {"tcp", "udp"}:
        raise ValueError("Invalid WiFiLink2 RTSP transport")
    device = data.get("hdmi_device", [cfg["hdmi"].get("device", "")])[0].strip()
    if device and hdmi_enabled:
        allowed = video_source_detected_paths()
        if device not in allowed and os.path.realpath(device) not in allowed:
            raise ValueError("The selected HDMI capture device is not currently detected")
    input_format = data.get("input_format", [cfg["hdmi"].get("input_format", "mjpeg")])[0]
    if input_format not in {"auto", "h264", "mjpeg", "yuyv422", "uyvy422", "nv12"}:
        raise ValueError("Invalid HDMI input format")
    encoder = data.get("encoder", [cfg["hdmi"].get("encoder", "auto")])[0]
    if encoder not in {"auto", "hardware", "software", "h264_v4l2m2m", "libx264"}:
        raise ValueError("Invalid HDMI encoder")
    cfg["source"] = source
    cfg["switch_mode"] = "direct-redirect"
    cfg["siyi"].update({
        "enabled": siyi_enabled,
        "name": video_source_clean_name(
            data.get("siyi_name", [""])[0], VIDEO_SOURCE_DEFAULT_NAMES["siyi_rtsp"]
        ),
        "url": siyi_url,
        "transport": transport,
        "latency_ms": video_source_int(data.get("siyi_latency", ["0"])[0], 0, 5000, "SIYI latency"),
    })
    cfg["hdmi"].update({
        "enabled": hdmi_enabled,
        "name": video_source_clean_name(
            data.get("hdmi_name", [""])[0], VIDEO_SOURCE_DEFAULT_NAMES["hdmi_usb"]
        ),
        "device": device,
        "input_format": input_format,
        "width": video_source_int(data.get("width", ["1280"])[0], 160, 7680, "Width"),
        "height": video_source_int(data.get("height", ["720"])[0], 120, 4320, "Height"),
        "fps": video_source_int(data.get("fps", ["25"])[0], 1, 120, "Frame rate"),
        "encoder": encoder,
        "bitrate_kbps": video_source_int(data.get("bitrate_kbps", ["4000"])[0], 500, 100000, "Bitrate"),
        "audio_enabled": False,
    })
    cfg["wifilink"].update({
        "enabled": wifilink_enabled,
        "name": video_source_clean_name(
            data.get("wifilink_name", [""])[0], VIDEO_SOURCE_DEFAULT_NAMES["wifilink_rtsp"]
        ),
        "url": wifilink_url,
        "username": data.get("wifilink_username", [cfg["wifilink"].get("username", "root")])[0].strip(),
        "transport": wifilink_transport,
        "latency_ms": video_source_int(data.get("wifilink_latency", ["0"])[0], 0, 5000, "WiFiLink2 latency"),
    })
    submitted_password = data.get("wifilink_password", [""])[0]
    if submitted_password:
        cfg["wifilink"]["password"] = submitted_password
    cfg["udp"].update({
        "enabled": "udp_enabled" in data,
        "port": video_source_int(data.get("udp_port", ["5600"])[0], 1, 65535, "UDP port"),
        "latency_ms": video_source_int(data.get("udp_latency", ["0"])[0], 0, 5000, "UDP latency"),
    })
    return cfg


def video_source_control(action, source=""):
    cmd = ["sudo", "-n", VIDEO_SOURCE_CONTROL, action]
    if source:
        cmd.append(source)
    result = subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
        timeout=45, check=False,
    )
    output = (result.stdout or "").strip()
    if result.returncode != 0:
        raise RuntimeError(output or "Video source operation failed")
    return output



def video_source_page():
    cfg = video_source_read_config()
    status = video_source_read_status()
    devices = video_source_devices()
    options = ["<option value=''>No HDMI capture device selected</option>"]
    selected_device = str(cfg["hdmi"].get("device", ""))
    for item in devices:
        if not isinstance(item, dict):
            continue
        path = str(item.get("path", ""))
        name = str(item.get("name", "USB video device"))
        formats = ", ".join(str(x) for x in item.get("formats", [])) or "formats unknown"
        selected = "selected" if path == selected_device or os.path.realpath(path) == os.path.realpath(selected_device or "/nonexistent") else ""
        options.append(f"<option value='{esc(path)}' {selected}>{esc(name)} — {esc(path)} — {esc(formats)}</option>")
    if selected_device and not any(selected_device in option for option in options):
        options.append(f"<option value='{esc(selected_device)}' selected>{esc(selected_device)} — currently unavailable</option>")
    device_options = "".join(options)

    source = cfg["source"]
    source_name_map = video_source_names(cfg)
    siyi_name = source_name_map["siyi_rtsp"]
    hdmi_name = source_name_map["hdmi_usb"]
    wifilink_name = source_name_map["wifilink_rtsp"]
    active_label = source_name_map.get(source, siyi_name)
    state = str(status.get("state", "unknown"))
    state_class = "ok" if state == "running" else ("warn" if state in {"starting", "waiting"} else "bad")

    siyi_enabled = bool(cfg["siyi"].get("enabled", True))
    hdmi_enabled = bool(cfg["hdmi"].get("enabled", True))
    wifilink_enabled = bool(cfg["wifilink"].get("enabled", True))
    siyi_enabled_checked = "checked" if siyi_enabled else ""
    hdmi_enabled_checked = "checked" if hdmi_enabled else ""
    wifilink_enabled_checked = "checked" if wifilink_enabled else ""
    siyi_switch_disabled = "" if siyi_enabled else "disabled"
    hdmi_switch_disabled = "" if hdmi_enabled else "disabled"
    wifilink_switch_disabled = "" if wifilink_enabled else "disabled"
    udp_checked = "checked" if cfg["udp"].get("enabled", True) else ""
    fmt = str(cfg["hdmi"].get("input_format", "mjpeg"))
    encoder = str(cfg["hdmi"].get("encoder", "auto"))
    transport = str(cfg["siyi"].get("transport", "tcp"))
    wifilink_transport = str(cfg["wifilink"].get("transport", "tcp"))

    external_output = "rtsp://192.168.191.10:8554/main.264"
    mediamtx_pid = ""
    try:
        mediamtx_pid = subprocess.check_output(
            ["systemctl", "show", "-p", "MainPID", "--value", "mediamtx.service"],
            text=True, timeout=3,
        ).strip()
    except Exception:
        mediamtx_pid = ""
    mediamtx_running = bool(mediamtx_pid and mediamtx_pid != "0")
    mediamtx_label = "Running" if mediamtx_running else "Unavailable"
    mediamtx_class = "ok" if mediamtx_running else "bad"

    def source_button(source_id, label, enabled):
        active = source_id == source
        button_class = "ui-source-button active" if active else "ui-source-button"
        disabled = "" if enabled else " disabled"
        suffix = " · active" if active else (" · disabled" if not enabled else "")
        return (
            "<form method='post' action='/video_source_select' class='ui-inline-form'>"
            "<input type='hidden' name='source' value='" + esc(source_id) + "'>"
            "<button class='" + button_class + "' style='pointer-events:auto'" + disabled + ">"
            + esc(label + suffix) + "</button></form>"
        )

    siyi_active_lock = "disabled" if source == "siyi_rtsp" else ""
    hdmi_active_lock = "disabled" if source == "hdmi_usb" else ""
    wifilink_active_lock = "disabled" if source == "wifilink_rtsp" else ""
    siyi_hidden = "<input type='hidden' name='siyi_enabled' value='1'>" if source == "siyi_rtsp" else ""
    hdmi_hidden = "<input type='hidden' name='hdmi_enabled' value='1'>" if source == "hdmi_usb" else ""
    wifilink_hidden = "<input type='hidden' name='wifilink_enabled' value='1'>" if source == "wifilink_rtsp" else ""

    return f"""
    <!-- VIDEO_WIFI_UI_RESTRUCTURE_V8 -->
    <style>
      .ui-page-head{{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:16px;flex-wrap:wrap}}
      .ui-page-head h1{{margin:0}}
      .ui-tabbar{{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 16px}}
      .ui-tabbtn{{background:#1e293b;color:#cbd5e1;border:1px solid #334155;margin:0}}
      .ui-tabbtn.active{{background:#2563eb;color:white;border-color:#3b82f6}}
      .ui-tabpanel{{display:none}}
      .ui-tabpanel.active{{display:block}}
      .ui-source-strip{{display:grid;grid-template-columns:repeat(3,minmax(180px,1fr));gap:10px}}
      .ui-inline-form{{margin:0}}
      .ui-source-button{{width:100%;margin:0;background:#1e293b;border:1px solid #475569;text-align:left}}
      .ui-source-button.active{{background:#166534;border-color:#22c55e}}
      .ui-kpi{{background:#0b1220;border:1px solid #334155;border-radius:10px;padding:13px}}
      .ui-kpi-label{{color:#94a3b8;font-size:12px;margin-bottom:5px}}
      .ui-kpi-value{{font-size:17px;font-weight:700;word-break:break-word}}
      .ui-source-card{{background:#0b1220;border:1px solid #334155;border-radius:12px;padding:15px;margin-bottom:14px}}
      .ui-source-card.active{{border-color:#22c55e;box-shadow:0 0 0 1px rgba(34,197,94,.22)}}
      .ui-card-title{{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:12px;flex-wrap:wrap}}
      .ui-card-title h2,.ui-card-title h3{{margin:0}}
      .ui-copy{{display:flex;gap:8px;align-items:center}}
      .ui-copy code{{background:#020617;border:1px solid #334155;border-radius:7px;padding:9px;display:block;overflow:auto;flex:1}}
      .ui-secondary{{background:#475569}}
      .ui-link-button{{display:inline-block;background:#2563eb;color:white;border-radius:8px;padding:9px 13px;text-decoration:none}}
      details.ui-details{{background:#0b1220;border:1px solid #334155;border-radius:10px;padding:12px;margin-bottom:10px}}
      details.ui-details summary{{cursor:pointer;font-weight:700}}
      @media(max-width:800px){{.ui-source-strip{{grid-template-columns:1fr}}}}
    </style>

    <div class='ui-page-head'>
      <div><h1>Video</h1><div class='small'>Select, configure and monitor the video delivered to QGroundControl.</div></div>
      <a class='ui-link-button ui-secondary' href='/connectivity?tab=airlink' target='_top'>Open Air Link connectivity</a>
    </div>

    <div class='card'>
      <div class='ui-card-title'><h2>Current video output</h2><span id='videoSourceState' class='pill {state_class}'>{esc(state.upper())}</span></div>
      <div class='grid'>
        <div class='ui-kpi'><div class='ui-kpi-label'>Active source</div><div id='videoActiveSource' class='ui-kpi-value'>{esc(active_label)}</div></div>
        <div class='ui-kpi'><div class='ui-kpi-label'>QGC stream</div><div class='ui-kpi-value' style='font-size:14px'>{esc(external_output)}</div></div>
        <div class='ui-kpi'><div class='ui-kpi-label'>MediaMTX</div><div class='ui-kpi-value {mediamtx_class}'>{esc(mediamtx_label)}</div></div>
        <div class='ui-kpi'><div class='ui-kpi-label'>Switching mode</div><div class='ui-kpi-value' style='font-size:14px'>Direct redirect / hot reload</div></div>
      </div>
      <p id='videoSourceMessage' class='small'>{esc(status.get('message', 'Waiting for status'))}</p>
      <p id='videoStandbyMessage' class='small'>{esc(status.get('standby_message', ''))}</p>
      <div class='ui-source-strip'>
        {source_button('siyi_rtsp', siyi_name, siyi_enabled)}
        {source_button('hdmi_usb', hdmi_name, hdmi_enabled)}
        {source_button('wifilink_rtsp', wifilink_name, wifilink_enabled)}
      </div>
      <div style='display:flex;gap:10px;margin-top:12px;flex-wrap:wrap'>
        <form method='post' action='/video_source_toggle' style='margin:0'><button style='pointer-events:auto;margin:0'>Cycle source</button></form>
        <a class='ui-link-button ui-secondary' href='/video'>Refresh status and devices</a>
      </div>
    </div>

    <div class='ui-tabbar' data-tab-group='video'>
      <button type='button' class='ui-tabbtn active' data-tab='sources'>Sources</button>
      <button type='button' class='ui-tabbtn' data-tab='routing'>Output &amp; routing</button>
      <button type='button' class='ui-tabbtn' data-tab='preview'>Preview</button>
      <button type='button' class='ui-tabbtn' data-tab='diagnostics'>Diagnostics</button>
    </div>

    <form method='post' action='/save_video_source' id='videoSettingsForm'>
      <input type='hidden' name='source' value='{esc(source)}'>
      <section class='ui-tabpanel active' data-panel='sources'>
        <div class='ui-source-card {'active' if source == 'siyi_rtsp' else ''}'>
          <div class='ui-card-title'><h2>{esc(siyi_name)}</h2><span class='pill {'active' if source == 'siyi_rtsp' else 'inactive'}'>{'ACTIVE OUTPUT' if source == 'siyi_rtsp' else 'SOURCE'}</span></div>
          {siyi_hidden}<label style='display:flex;gap:8px;align-items:center;margin-bottom:12px'><input style='width:auto;pointer-events:auto' type='checkbox' name='siyi_enabled' value='1' {siyi_enabled_checked} {siyi_active_lock}>Include this source in the source cycle</label>
          <div class='grid'>
            <div><label>Source name and spoken announcement</label><input style='pointer-events:auto' name='siyi_name' maxlength='40' value='{esc(siyi_name)}'></div>
            <div><label>RTSP URL</label><input style='pointer-events:auto' name='siyi_url' value='{esc(cfg['siyi']['url'])}'></div>
            <div><label>Transport</label><select style='pointer-events:auto' name='transport'><option value='tcp' {'selected' if transport == 'tcp' else ''}>TCP</option><option value='udp' {'selected' if transport == 'udp' else ''}>UDP</option></select></div>
            <div><label>Receiver latency (ms)</label><input style='pointer-events:auto' name='siyi_latency' value='{esc(cfg['siyi'].get('latency_ms', 0))}'></div>
          </div>
          <p class='small'>The original SIYI RTSP stream is relayed without video re-encoding.</p>
        </div>

        <div class='ui-source-card {'active' if source == 'hdmi_usb' else ''}'>
          <div class='ui-card-title'><h2>{esc(hdmi_name)}</h2><span class='pill {'active' if source == 'hdmi_usb' else 'inactive'}'>{'ACTIVE OUTPUT' if source == 'hdmi_usb' else 'SOURCE'}</span></div>
          {hdmi_hidden}<label style='display:flex;gap:8px;align-items:center;margin-bottom:12px'><input style='width:auto;pointer-events:auto' type='checkbox' name='hdmi_enabled' value='1' {hdmi_enabled_checked} {hdmi_active_lock}>Include this source in the source cycle</label>
          <div class='grid'>
            <div><label>Source name and spoken announcement</label><input style='pointer-events:auto' name='hdmi_name' maxlength='40' value='{esc(hdmi_name)}'></div>
            <div style='grid-column:1/-1'><label>Capture device</label><select style='pointer-events:auto' name='hdmi_device'>{device_options}</select></div>
            <div><label>Input format</label><select style='pointer-events:auto' name='input_format'>{''.join(f"<option value='{x}' {'selected' if fmt == x else ''}>{x}</option>" for x in ('auto','h264','mjpeg','yuyv422','uyvy422','nv12'))}</select></div>
            <div><label>Encoder</label><select style='pointer-events:auto' name='encoder'>{''.join(f"<option value='{x}' {'selected' if encoder == x else ''}>{x}</option>" for x in ('auto','hardware','software'))}</select></div>
            <div><label>Width</label><input style='pointer-events:auto' name='width' value='{esc(cfg['hdmi'].get('width', 1280))}'></div>
            <div><label>Height</label><input style='pointer-events:auto' name='height' value='{esc(cfg['hdmi'].get('height', 720))}'></div>
            <div><label>Frame rate</label><input style='pointer-events:auto' name='fps' value='{esc(cfg['hdmi'].get('fps', 25))}'></div>
            <div><label>Bitrate (kbps)</label><input style='pointer-events:auto' name='bitrate_kbps' value='{esc(cfg['hdmi'].get('bitrate_kbps', 4000))}'></div>
          </div>
          <p class='small'>HDMI input is captured over USB and encoded to H.264 for the fixed output stream.</p>
        </div>

        <div class='ui-source-card {'active' if source == 'wifilink_rtsp' else ''}'>
          <div class='ui-card-title'><h2>{esc(wifilink_name)}</h2><span class='pill {'active' if source == 'wifilink_rtsp' else 'inactive'}'>{'ACTIVE OUTPUT' if source == 'wifilink_rtsp' else 'SOURCE'}</span></div>
          {wifilink_hidden}<label style='display:flex;gap:8px;align-items:center;margin-bottom:12px'><input style='width:auto;pointer-events:auto' type='checkbox' name='wifilink_enabled' value='1' {wifilink_enabled_checked} {wifilink_active_lock}>Include this source in the source cycle</label>
          <div class='grid'>
            <div><label>Source name and spoken announcement</label><input style='pointer-events:auto' name='wifilink_name' maxlength='40' value='{esc(wifilink_name)}'></div>
            <div><label>RTSP URL</label><input style='pointer-events:auto' name='wifilink_url' value='{esc(cfg['wifilink']['url'])}'></div>
            <div><label>Fallback probe transport</label><select style='pointer-events:auto' name='wifilink_transport'><option value='tcp' {'selected' if wifilink_transport == 'tcp' else ''}>TCP</option><option value='udp' {'selected' if wifilink_transport == 'udp' else ''}>UDP</option></select></div>
            <div><label>Receiver latency (ms)</label><input style='pointer-events:auto' name='wifilink_latency' value='{esc(cfg['wifilink'].get('latency_ms', 0))}'></div>
          </div>
          <p class='small'>QGC is redirected directly to WiFiLink2. Device login and Wi-Fi settings are maintained on the dedicated WiFiLink2 page.</p>
          <a class='ui-link-button' href='/connectivity?tab=airlink' target='_top'>Open Air Link device settings</a>
        </div>
        <div class='card'><button style='pointer-events:auto;margin:0'>Save video-source settings</button></div>
      </section>

      <section class='ui-tabpanel' data-panel='routing'>
        <div class='card'>
          <h2>Output and routing</h2>
          <div class='grid'>
            <div class='ui-kpi'><div class='ui-kpi-label'>Fixed QGC URL</div><div class='ui-kpi-value' style='font-size:14px'>{esc(external_output)}</div></div>
            <div class='ui-kpi'><div class='ui-kpi-label'>Internal MediaMTX path</div><div class='ui-kpi-value' style='font-size:14px'>{esc(cfg.get('output_url'))}</div></div>
            <div class='ui-kpi'><div class='ui-kpi-label'>MediaMTX process</div><div class='ui-kpi-value'>{esc(mediamtx_pid or 'Unavailable')}</div></div>
            <div class='ui-kpi'><div class='ui-kpi-label'>Active routing mode</div><div class='ui-kpi-value' style='font-size:14px'>{esc(cfg.get('switch_mode', 'direct-redirect'))}</div></div>
          </div>
          <div class='ui-copy' style='margin-top:12px'><code id='qgcVideoUrl'>{esc(external_output)}</code><button type='button' class='ui-secondary' onclick="navigator.clipboard.writeText(document.getElementById('qgcVideoUrl').textContent)">Copy</button></div>
        </div>
        <div class='card'>
          <h2>UDP forwarding</h2>
          <label><input style='width:auto;pointer-events:auto' type='checkbox' name='udp_enabled' value='1' {udp_checked}> Forward selected video to hosts enabled for Video on the MAVLink Hosts page</label>
          <div class='grid' style='margin-top:12px'>
            <div><label>UDP port</label><input style='pointer-events:auto' name='udp_port' value='{esc(cfg['udp'].get('port', 5600))}'></div>
            <div><label>UDP receiver latency (ms)</label><input style='pointer-events:auto' name='udp_latency' value='{esc(cfg['udp'].get('latency_ms', 0))}'></div>
          </div>
          <button style='pointer-events:auto;margin-top:14px'>Save routing settings</button>
        </div>
      </section>
    </form>

    <section class='ui-tabpanel' data-panel='preview'>
      <div class='card'>
        <h2>Live preview</h2>
        <p class='small'>On-demand browser preview from MediaMTX. WiFiLink2 redirect mode is intended primarily for RTSP clients such as QGC.</p>
        <div style='display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px'>
          <button type='button' style='pointer-events:auto;margin:0' onclick='startVideoPreview()'>Start preview</button>
          <button type='button' class='ui-secondary' style='pointer-events:auto;margin:0' onclick='stopVideoPreview()'>Stop preview</button>
          <span id='videoPreviewStatus' class='pill warn'>PREVIEW OFF</span>
        </div>
        <div id='videoPreviewBox' style='display:none;border:1px solid #334155;border-radius:10px;overflow:hidden;background:#111'>
          <iframe id='videoPreviewFrame' style='width:100%;height:420px;border:0;background:#111' allow='autoplay; fullscreen'></iframe>
        </div>
      </div>
    </section>

    <section class='ui-tabpanel' data-panel='diagnostics'>
      <div class='card'>
        <h2>Video diagnostics</h2>
        <div class='grid'>
          <div><b>Configured source</b><br>{esc(source)}</div>
          <div><b>Service state</b><br><span class='{state_class}'>{esc(state)}</span></div>
          <div><b>MediaMTX PID</b><br>{esc(mediamtx_pid or 'Unavailable')}</div>
          <div><b>Output path</b><br>{esc(cfg.get('output_url'))}</div>
        </div>
        <details class='ui-details' style='margin-top:14px' open><summary>Current status message</summary><pre>{esc(status.get('message', 'No status message'))}</pre></details>
        <details class='ui-details'><summary>Standby-source status</summary><pre>{esc(status.get('standby_message', 'No standby status'))}</pre></details>
        <a class='ui-link-button ui-secondary' href='/logs'>Open full diagnostics</a>
      </div>
    </section>

    <script>
    function activateUiTab(group, name){{
      document.querySelectorAll(".ui-tabbar[data-tab-group='"+group+"'] .ui-tabbtn").forEach(btn=>btn.classList.toggle('active',btn.dataset.tab===name));
      document.querySelectorAll('.ui-tabpanel').forEach(panel=>panel.classList.toggle('active',panel.dataset.panel===name));
      try{{localStorage.setItem('siyi-tab-'+group,name)}}catch(_e){{}}
    }}
    document.querySelectorAll(".ui-tabbar[data-tab-group='video'] .ui-tabbtn").forEach(btn=>btn.addEventListener('click',()=>activateUiTab('video',btn.dataset.tab)));
    const initialVideoTab=(location.hash||'').replace('#','') || (()=>{{try{{return localStorage.getItem('siyi-tab-video')}}catch(_e){{return ''}}}})() || 'sources';
    if(['sources','routing','preview','diagnostics'].includes(initialVideoTab)) activateUiTab('video',initialVideoTab);
    function startVideoPreview(){{
      const url=location.protocol+'//'+location.hostname+':8889/main.264/';
      document.getElementById('videoPreviewFrame').src=url;
      document.getElementById('videoPreviewBox').style.display='block';
      const st=document.getElementById('videoPreviewStatus');st.textContent='PREVIEW ON';st.className='pill ok';
    }}
    function stopVideoPreview(){{
      document.getElementById('videoPreviewFrame').src='about:blank';
      document.getElementById('videoPreviewBox').style.display='none';
      const st=document.getElementById('videoPreviewStatus');st.textContent='PREVIEW OFF';st.className='pill warn';
    }}
    async function pollVideoSource(){{
      try{{
        const r=await fetch('/video_source_status?ts='+Date.now(),{{cache:'no-store'}});
        const s=await r.json();
        const state=String(s.state||'unknown');
        const pill=document.getElementById('videoSourceState');
        pill.textContent=state.toUpperCase();
        pill.className='pill '+(state==='running'?'ok':((state==='starting'||state==='waiting')?'warn':'bad'));
        const sourceLabels=s.source_names||{{}};
        document.getElementById('videoActiveSource').textContent=sourceLabels[s.active_source]||sourceLabels[s.configured_source]||'SIYI';
        document.getElementById('videoSourceMessage').textContent=s.message||'';
        document.getElementById('videoStandbyMessage').textContent=s.standby_message||'';
      }}catch(_e){{}}
    }}
    setInterval(pollVideoSource,2000);
    </script>"""
# === VIDEO_SOURCE_WEBUI_V8 END ===


# === FLAPS_WEBUI_V1 START ===
FLAPS_CONFIG_FILE = "/etc/siyi/flaps.json"


def flaps_default_config():
    return {
        "enabled": False,
        "left_servo": 9,
        "right_servo": 10,
        "left_reverse": False,
        "right_reverse": False,
        "up_pwm": 1000,
        "takeoff_pwm": 1500,
        "landing_pwm": 2000,
        "current_position": "UP",
    }


def flaps_read_config():
    cfg = flaps_default_config()

    try:
        with open(
            FLAPS_CONFIG_FILE,
            encoding="utf-8",
        ) as f:
            saved = json.load(f)

        if isinstance(saved, dict):
            cfg.update(saved)

    except Exception:
        pass

    return cfg


def flaps_write_config(cfg):
    current = flaps_read_config()

    clean = {
        "enabled": bool(
            cfg.get("enabled", False)
        ),
        "left_servo": int(
            cfg.get("left_servo", 9)
        ),
        "right_servo": int(
            cfg.get("right_servo", 10)
        ),
        "left_reverse": bool(
            cfg.get("left_reverse", False)
        ),
        "right_reverse": bool(
            cfg.get("right_reverse", False)
        ),
        "up_pwm": int(
            cfg.get("up_pwm", 1000)
        ),
        "takeoff_pwm": int(
            cfg.get("takeoff_pwm", 1500)
        ),
        "landing_pwm": int(
            cfg.get("landing_pwm", 2000)
        ),
        "current_position": str(
            current.get(
                "current_position",
                "UP",
            )
        ).upper(),
    }

    if (
        clean["left_servo"]
        == clean["right_servo"]
    ):
        raise ValueError(
            "Left and right outputs must be different"
        )

    if not (
        1 <= clean["left_servo"] <= 16
        and 1 <= clean["right_servo"] <= 16
    ):
        raise ValueError(
            "Outputs must be SERVO1 through SERVO16"
        )

    for key in (
        "up_pwm",
        "takeoff_pwm",
        "landing_pwm",
    ):
        if not 800 <= clean[key] <= 2200:
            raise ValueError(
                "PWM values must be between 800 and 2200"
            )

    os.makedirs(
        os.path.dirname(FLAPS_CONFIG_FILE),
        exist_ok=True,
    )

    tmp = FLAPS_CONFIG_FILE + ".tmp"

    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(clean, f, indent=2)
        f.write("\n")

    os.replace(tmp, FLAPS_CONFIG_FILE)
    os.chmod(FLAPS_CONFIG_FILE, 0o664)

    return clean


def flaps_page():
    cfg = flaps_read_config()

    checked = (
        "checked"
        if cfg.get("enabled")
        else ""
    )

    left_is_reverse = bool(
        cfg.get("left_reverse", False)
    )

    right_is_reverse = bool(
        cfg.get("right_reverse", False)
    )

    left_normal_selected = (
        "" if left_is_reverse else "selected"
    )

    left_reverse_selected = (
        "selected" if left_is_reverse else ""
    )

    right_normal_selected = (
        "" if right_is_reverse else "selected"
    )

    right_reverse_selected = (
        "selected" if right_is_reverse else ""
    )

    position = str(
        cfg.get("current_position", "UP")
    ).upper()

    msg = esc(
        sh(
            "cat /tmp/siyi_webui_last_action "
            "2>/dev/null || true"
        )
    )

    return f"""
    <h1>Flap Control</h1>

    <div class='card'>
      <h2>Status</h2>

      <div class='grid'>
        <div>
          <b>Current commanded position</b><br>
          {esc(position)}
        </div>

        <div>
          <b>Ownership rule</b><br>
          Both configured SERVOx_FUNCTION parameters
          must be Disabled (0).
        </div>
      </div>

      <p class='small'>
        If either output has any ArduPilot function
        other than Disabled, every flap command is blocked.
      </p>
    </div>

    <div class='card'>
      <h2>Configuration</h2>

      <form method='post' action='/save_flaps'>

        <label style='display:flex;align-items:center;
                      gap:8px;margin-bottom:14px;'>

          <input
            style='pointer-events:auto;width:auto;'
            type='checkbox'
            name='enabled'
            value='1'
            {checked}>

          Enable button-controlled flaps
        </label>

        <div class='grid'>

          <div>
            <label>Left flap output</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='1'
              max='16'
              name='left_servo'
              value='{esc(cfg.get("left_servo", 9))}'>
          </div>

          <div>
            <label>Right flap output</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='1'
              max='16'
              name='right_servo'
              value='{esc(cfg.get("right_servo", 10))}'>
          </div>

          <div>
            <label>Left servo direction</label>
            <select
              style='pointer-events:auto;'
              name='left_reverse'>

              <option
                value='0'
                {left_normal_selected}>
                Normal
              </option>

              <option
                value='1'
                {left_reverse_selected}>
                Reversed
              </option>
            </select>
          </div>

          <div>
            <label>Right servo direction</label>
            <select
              style='pointer-events:auto;'
              name='right_reverse'>

              <option
                value='0'
                {right_normal_selected}>
                Normal
              </option>

              <option
                value='1'
                {right_reverse_selected}>
                Reversed
              </option>
            </select>
          </div>

          <div>
            <label>UP PWM</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='800'
              max='2200'
              name='up_pwm'
              value='{esc(cfg.get("up_pwm", 1000))}'>
          </div>

          <div>
            <label>MID PWM</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='800'
              max='2200'
              name='takeoff_pwm'
              value='{esc(cfg.get("takeoff_pwm", 1500))}'>
          </div>

          <div>
            <label>DOWN PWM</label>
            <input
              style='pointer-events:auto;'
              type='number'
              min='800'
              max='2200'
              name='landing_pwm'
              value='{esc(cfg.get("landing_pwm", 2000))}'>
          </div>

        </div>

        <button style='pointer-events:auto;'>
          Save flap configuration
        </button>

      </form>
    </div>

    <div class='card'>
      <h2>Button action</h2>

      <p>
        Assign <b>FLAPS</b> on the Buttons page.
        Each activation cycles
        UP → MID → DOWN → UP.
      </p>
    </div>

    <div class='card'>
      <h2>Last action</h2>
      <pre>{msg}</pre>
    </div>
    """

# === FLAPS_WEBUI_V1 END ===

def zt_save_config(cfg):
    try:
        os.makedirs("/etc/siyi", exist_ok=True)
        open(ZT_CONFIG_FILE, "w").write(json.dumps(cfg, indent=2))
        return True
    except Exception as e:
        print("zt_save_config failed:", e)
        return False


def zt_read_config():
    try:
        if os.path.exists(ZT_CONFIG_FILE):
            with open(ZT_CONFIG_FILE, encoding="utf-8") as f:
                data=json.load(f)
                if isinstance(data, dict):
                    return data
    except Exception:
        pass
    return {}

def zt_write_config(data):
    os.makedirs(os.path.dirname(ZT_CONFIG_FILE), exist_ok=True)
    with open(ZT_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    try:
        os.chmod(ZT_CONFIG_FILE, 0o600)
    except Exception:
        pass

def zt_save_token(token):
    token=(token or "").strip()
    if not token:
        return
    os.makedirs(os.path.dirname(ZT_TOKEN_FILE), exist_ok=True)
    with open(ZT_TOKEN_FILE, "w", encoding="utf-8") as f:
        f.write(token + "\n")
    try:
        os.chmod(ZT_TOKEN_FILE, 0o600)
    except Exception:
        pass

def zt_read_token():
    try:
        return open(ZT_TOKEN_FILE, encoding="utf-8").read().strip()
    except Exception:
        return ""

def zt_token_saved():
    return bool(zt_read_token())

def zt_node_id():
    out=sh("sudo zerotier-cli info 2>/dev/null || true")
    parts=out.split()
    if len(parts) >= 3 and parts[0] == "200" and parts[1] == "info":
        return parts[2]
    return ""

def zt_current_ip():
    out=sh("sudo zerotier-cli listnetworks 2>/dev/null || true")
    for line in out.splitlines():
        if " OK " in line and "/" in line:
            parts=line.split()
            for part in reversed(parts):
                if "/" in part and "." in part:
                    return part.split("/")[0]
    out=sh("ip -4 -br addr | awk '/zt/ {print $3}' | head -n1 | cut -d/ -f1")
    return out.strip()

def zt_network_id_current():
    cfg=zt_read_config()
    nwid=(cfg.get("network_id") or "").strip()
    if nwid:
        return nwid
    out=sh("sudo zerotier-cli listnetworks 2>/dev/null || true")
    for line in out.splitlines():
        parts=line.split()
        if len(parts) >= 3 and parts[0] == "200" and parts[1] == "listnetworks" and parts[2] != "<nwid>":
            return parts[2]
    return ""

def zt_api_request(method, path, payload=None):
    token=zt_read_token()
    if not token:
        return False, "No API token saved"
    url="https://api.zerotier.com/api/v1" + path
    data=None
    headers={
        "Authorization": "Bearer " + token,
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "curl/8.0 SIYI-Pi-WebUI",
    }
    if payload is not None:
        data=json.dumps(payload).encode("utf-8")
    req=urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=12) as r:
            body=r.read().decode("utf-8", errors="replace")
            return True, body
    except Exception as e:
        return False, str(e)

def zt_test_token():
    nwid=zt_network_id_current()
    if not nwid:
        return "ZT API test failed: no network ID saved/found"
    ok, body=zt_api_request("GET", "/network/" + nwid)
    if ok:
        return "ZT API token OK for network " + nwid
    return "ZT API token test failed for network " + nwid + ": " + body


def zt_authorize_this_pi(default_name="New_PI"):
    nwid=zt_network_id_current()
    node=zt_node_id()

    if not nwid:
        return "ZT authorize failed: no network ID configured"

    if not node:
        return "ZT authorize failed: no local node ID"

    hostname=sh("hostname").strip() or default_name

    payload={
        "config":{"authorized":True},
        "name":hostname
    }

    ok, body=zt_api_request(
        "POST",
        "/network/" + nwid + "/member/" + node,
        payload
    )

    if not ok:
        return "ZT authorize failed: " + body

    for i in range(1,11):
        time.sleep(2)

        ok2, verify_body=zt_api_request(
            "GET",
            "/network/" + nwid + "/member/" + node
        )

        if ok2:
            try:
                obj=json.loads(verify_body)

                if obj.get("config",{}).get("authorized") is True:
                    return "ZT authorize OK verified for node " + node + " as " + hostname

            except Exception:
                pass

    return "ZT authorize failed verification for node " + node


def zt_update_camera_route():
    nwid=zt_network_id_current()
    ip=zt_current_ip()
    if not nwid:
        return "ZT route update failed: no network ID"
    if not ip:
        return "ZT route update failed: no Pi ZeroTier IP"

    ok, body=zt_api_request("GET", "/network/" + nwid)
    if not ok:
        return "ZT route update failed reading network: " + body

    try:
        obj=json.loads(body)
        cfg=obj.get("config",{})
        routes=cfg.get("routes") or []
        if not isinstance(routes, list):
            routes=[]
    except Exception as e:
        return "ZT route update failed parsing network JSON: " + str(e)

    # Replace only the camera subnet route, preserve all other routes.
    routes=[r for r in routes if not (isinstance(r,dict) and r.get("target")=="192.168.144.0/24")]
    routes.append({"target":"192.168.144.0/24","via":ip})

    payload={"config":{"routes":routes}}
    ok, body=zt_api_request("POST", "/network/" + nwid, payload)
    if ok:
        return "ZT managed route updated OK: 192.168.144.0/24 via " + ip
    return "ZT managed route update failed: " + body

def zt_full_setup():
    out=[]

    nwid=zt_network_id_current()

    if not nwid:
        return "ZT setup failed: no network ID configured"

    out.append("=== ZT FULL SETUP START ===")
    out.append("Network ID: " + nwid)

    # Step 1: Join network
    out.append("")
    out.append("=== JOIN NETWORK ===")
    join_out=sh(f"sudo zerotier-cli join {nwid}")
    out.append(join_out)

    # Step 2: Authorize/update member
    out.append("")
    out.append("=== AUTHORIZE MEMBER ===")
    auth_out=zt_authorize_this_pi()
    out.append(auth_out)

    # Step 3: Wait for operational state
    out.append("")
    out.append("=== WAIT FOR ZT IP ===")

    zt_ip=None
    status_txt=""

    for i in range(1,16):
        time.sleep(2)

        try:
            status_txt=sh("sudo zerotier-cli listnetworks")
        except Exception as e:
            status_txt=str(e)

        out.append(f"TRY {i}/15")
        out.append(status_txt)

        current=zt_current_ip()

        if current:
            zt_ip=current
            break

    # Step 4: Validate operational success
    if not zt_ip:
        out.append("")
        out.append("ZT SETUP FAILED")
        out.append("No managed ZeroTier IP received.")
        out.append("Current status:")
        out.append(status_txt)

        if "REQUESTING_CONFIGURATION" in status_txt:
            out.append("")
            out.append("Likely causes:")
            out.append("- Member not authorized")
            out.append("- Managed IP assignment disabled")
            out.append("- Broken/stale node state")
            out.append("- Invalid API token")
            out.append("- Network controller issue")

        if "ACCESS_DENIED" in status_txt:
            out.append("")
            out.append("Member exists but is NOT authorized in ZeroTier Central.")

        return "\\n".join(out)

    out.append("")
    out.append("ZT ONLINE OK")
    out.append("Pi ZT IP: " + zt_ip)

    # Step 5: Route update
    out.append("")
    out.append("=== UPDATE CAMERA ROUTE ===")
    out.append(zt_update_camera_route())

    out.append("")
    out.append("=== ZT SETUP COMPLETE ===")

    return "\\n".join(out)

def zt_status_html():
    cfg=zt_read_config()
    nwid=zt_network_id_current()
    token_status="saved" if zt_token_saved() else "not saved"
    node=zt_node_id() or "-"
    ip=zt_current_ip() or "-"
    raw=sh("sudo zerotier-cli info; sudo zerotier-cli listnetworks")
    return f"""
    <div class='grid'>
      <div><b>Network ID</b><br><span class='small'>{esc(nwid or "-")}</span></div>
      <div><b>API token</b><br><span class='small'>{esc(token_status)}</span></div>
      <div><b>This Pi node ID</b><br><span class='small'>{esc(node)}</span></div>
      <div><b>This Pi ZeroTier IP</b><br><span class='small'>{esc(ip)}</span></div>
    </div>
    <details style='margin-top:12px;'><summary>Show ZeroTier raw status</summary><pre>{esc(raw)}</pre></details>
    """

def get_video_values():
    txt=read_file(VIDEO_SERVICE)
    vals={"rtsp":"rtsp://"+CAM_IP+":8554/main.264","protocols":"tcp","latency":"0","host1":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","host2":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","port":"5600"}
    m=re.search(r"location=([^ ]+)", txt)
    if m: vals["rtsp"]=m.group(1)
    m=re.search(r"protocols=([^ ]+)", txt)
    if m: vals["protocols"]=m.group(1)
    m=re.search(r"latency=([^ ]+)", txt)
    if m: vals["latency"]=m.group(1)
    hosts=re.findall(r"udpsink host=([^ ]+) port=([0-9]+)", txt)
    if len(hosts)>0:
        vals["host1"], vals["port"]=hosts[0]
    if len(hosts)>1:
        vals["host2"], _=hosts[1]
    return vals

def make_video_service(rtsp, protocols, latency, host1, host2, port):
    return f"""[Unit]
Description=SIYI RTSP to dual UDP forwarder
After=network-online.target zerotier-one.service NetworkManager.service
Wants=network-online.target zerotier-one.service

[Service]
Type=simple
Restart=always
RestartSec=3
ExecStart=/usr/bin/gst-launch-1.0 -e rtspsrc location={rtsp} latency={latency} protocols={protocols} ! rtph265depay ! h265parse ! rtph265pay config-interval=1 pt=96 ! tee name=t t. ! queue ! udpsink host={host1} port={port} t. ! queue ! udpsink host={host2} port={port}
ExecStop=/usr/bin/pkill -f "gst-launch-1.0"
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
"""

def get_mav_values():
    txt=read_file(MAVCONF)
    vals={"device":"/dev/ttyAMA0","baud":"57600","android":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","mac":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","port":"14550","tcp":"5760"}
    m=re.search(r"TcpServerPort=([0-9]+)", txt)
    if m: vals["tcp"]=m.group(1)
    m=re.search(r"Device=(.+)", txt)
    if m: vals["device"]=m.group(1).strip()
    m=re.search(r"Baud=([0-9]+)", txt)
    if m: vals["baud"]=m.group(1)
    m=re.search(r"\[UdpEndpoint android\].*?Address=([0-9.]+).*?Port=([0-9]+)", txt, re.S)
    if m: vals["android"], vals["port"]=m.group(1), m.group(2)
    m=re.search(r"\[UdpEndpoint mac\].*?Address=([0-9.]+)", txt, re.S)
    if m: vals["mac"]=m.group(1)
    return vals

def make_mav_conf(device, baud, android, mac, port, tcp):
    return f"""[General]
TcpServerPort={tcp}
ReportStats=false

[UartEndpoint fc]
Device={device}
Baud={baud}

[UdpEndpoint android]
Mode=Normal
Address={android}
Port={port}

[UdpEndpoint mac]
Mode=Normal
Address={mac}
Port={port}

[UdpEndpoint button_safety]
Mode=Normal
Address=127.0.0.1
Port=14600
"""



def system_summary():
    problems = []
    warnings = []

    for s in SERVICES:
        state = sh(f"systemctl is-active {s} 2>/dev/null || true")
        if state == "failed":
            problems.append(s)
        elif state == "activating":
            warnings.append(s)

    if problems:
        return f"<div style='color:#ef4444;font-weight:bold'>❌ Issues: {', '.join(problems)}</div>"
    if warnings:
        return f"<div style='color:#f59e0b;font-weight:bold'>⚠ Waiting: {', '.join(warnings)}</div>"
    return "<div style='color:#22c55e;font-weight:bold'>✔ All systems running</div>"

def service_rows():
    rows = ""
    for group, services in SERVICE_GROUPS.items():
        rows += f"<tr><td colspan='3' style='padding-top:10px;font-weight:bold;color:#93c5fd'>{group}</td></tr>"
        for s in services:
            active = sh(f"systemctl is-active {s} 2>/dev/null || true")
            cls = "ok" if active == "active" else ("bad" if active in ["failed"] else "")
            disabled = "disabled" if s == "siyi-webui" else ""
            label = SERVICE_LABELS.get(s, s)
            status_label = STATUS_LABELS.get(active, active)
            rows += f"<tr><td><b>{esc(label)}</b><br><span class='small'>{esc(s)}</span></td><td class='{cls}'><b>{esc(status_label)}</b><br><span class='small'>{esc(active)}</span></td><td><form method='post' action='/restart'><input style='pointer-events:auto;' type='hidden' name='service' value='{s}'><button style='pointer-events:auto;' {disabled}>Restart</button></form></td></tr>"
    return rows


def action_select(name, current):
    dyn = []
    try:
        dyn = gimbal_preset_actions()
    except Exception as e:
        print("[GIMBAL_PRESET_ACTIONS_FAIL]", e, flush=True)

    merged = list(ACTIONS)

    for a in dyn:
        if a not in merged:
            merged.append(a)

    return "<select style='pointer-events:auto;' name='%s'>%s</select>" % (
        name,
        "".join([f"<option {'selected' if a==current else ''}>{a}</option>" for a in merged])
    )

def read_button_rows():
    if not os.path.exists(BUTTON_MAP):
        return []
    with open(BUTTON_MAP,encoding="utf-8-sig") as f:
        return list(csv.DictReader(f,delimiter=";"))


def read_button_safety_config():
    default={
        "block_when_armed":["MANUAL","TAKEOFF"],
        "block_disarm_in_air":True,
        "block_toggle_arm_disarm_in_air":True,
    }

    try:
        if os.path.exists(BUTTON_SAFETY_FILE):
            with open(BUTTON_SAFETY_FILE, encoding="utf-8") as f:
                data=json.load(f)

            vals=data.get("block_when_armed", default["block_when_armed"])

            if not isinstance(vals, list):
                vals=default["block_when_armed"]

            allowed=set(FLIGHT_SAFETY_ACTIONS)

            vals=[
                str(v).strip()
                for v in vals
                if str(v).strip() in allowed
            ]

            return {
                "block_when_armed":vals,
                "block_disarm_in_air":bool(data.get("block_disarm_in_air", True)),
                "block_toggle_arm_disarm_in_air":bool(data.get("block_toggle_arm_disarm_in_air", True)),
            }

    except Exception:
        pass

    return default


def write_button_safety_config(vals, block_disarm_in_air=True, block_toggle_arm_disarm_in_air=True):
    allowed=set(FLIGHT_SAFETY_ACTIONS)

    vals=[
        str(v).strip()
        for v in vals
        if str(v).strip() in allowed
    ]

    # Preserve UI/action ordering.
    ordered=[a for a in FLIGHT_SAFETY_ACTIONS if a in vals]

    os.makedirs("/etc/siyi", exist_ok=True)

    with open(BUTTON_SAFETY_FILE, "w", encoding="utf-8") as f:
        json.dump({
            "block_when_armed":ordered,
            "block_disarm_in_air":bool(block_disarm_in_air),
            "block_toggle_arm_disarm_in_air":bool(block_toggle_arm_disarm_in_air),
        }, f, indent=2)

    try:
        os.chmod(BUTTON_SAFETY_FILE, 0o644)
    except Exception:
        pass



def read_gimbal_presets():
    try:
        if os.path.exists(GIMBAL_PRESETS_FILE):
            with open(GIMBAL_PRESETS_FILE, encoding="utf-8") as f:
                data=json.load(f)
            if isinstance(data, list):
                return data
    except Exception as e:
        print("[GIMBAL_PRESETS_READ_FAIL]", e, flush=True)
    return []
def normalize_preset_name(name):
    name=str(name or "").strip()
    out=[]
    for ch in name:
        if ch.isalnum():
            out.append(ch)
        else:
            out.append("_")
    name="".join(out).strip("_")
    while "__" in name:
        name=name.replace("__","_")
    return name or "PRESET"

def write_gimbal_presets(presets):
    clean=[]
    seen=set()
    for r in presets:
        name=normalize_preset_name(r.get("name") or r.get("label") or "PRESET")
        base=name
        n=2
        while name in seen:
            name="%s_%d"%(base,n)
            n+=1
        seen.add(name)
        label=str(r.get("label") or name.replace("_"," ").title()).strip()
        try:
            yaw=float(r.get("yaw",0))
        except Exception:
            yaw=0.0
        try:
            pitch=float(r.get("pitch",0))
        except Exception:
            pitch=0.0
        clean.append({"name":name,"label":label,"yaw":yaw,"pitch":pitch})
    os.makedirs(os.path.dirname(GIMBAL_PRESETS_FILE), exist_ok=True)
    with open(GIMBAL_PRESETS_FILE,"w",encoding="utf-8") as f:
        json.dump(clean,f,indent=2)
    try:
        os.chmod(GIMBAL_PRESETS_FILE,0o644)
    except Exception:
        pass
    return clean

def gimbal_preset_actions():
    return ["GIMBAL_PRESET_"+p.get("name","") for p in read_gimbal_presets() if p.get("name")]


def gimbal_presets_card():
    presets=read_gimbal_presets()
    presets_json=json.dumps(presets)
    return """
    <div class='card'>
      <h2>Gimbal Presets</h2>
      <p class='small'>Create named gimbal preset positions. These become selectable button actions as <b>GIMBAL_PRESET_NAME</b>.</p>

      <div class='small' style='margin:8px 0 12px 0;color:#cbd5e1;'>
        Current zeroed gimbal position:
        Yaw: <b id='gimbalCurrentYaw'>--</b>
        &nbsp; Pitch: <b id='gimbalCurrentPitch'>--</b>
        &nbsp;
<br><button type='button' style='pointer-events:auto;margin-top:8px;' onclick='gimbalSetZero()'>Set current gimbal position as center / zero</button>
      </div>

      <table id='gimbalPresetTable'>
        <tr><th>Preset</th><th>Yaw</th><th>Pitch</th><th></th></tr>
      </table>

      <button type='button' style='pointer-events:auto;' onclick='gimbalPresetAdd()'>Add preset</button>
      <button type='button' style='pointer-events:auto;' onclick='gimbalPresetAddCurrent()'>Add preset from current position</button>
      <div id='gimbalPresetSaveStatus' class='small' style='margin-top:8px;color:#94a3b8;'>Saved automatically</div>
    </div>

    <script>
      let gimbalPresets = __PRESETS_JSON__;
      let gimbalPresetSaveTimer = null;
      window.gimbalLastCurrent = {yaw:0,pitch:0};

      function gimbalPresetNormalizeName(v){
        v=String(v||'').trim().replace(/^_+|_+$/g,'');
        return v || 'PRESET';
      }

      function gimbalPresetRender(){
        const tbl=document.getElementById('gimbalPresetTable');
        if(!tbl) return;
        let html="<tr><th>Preset</th><th>Yaw</th><th>Pitch</th><th></th></tr>";
        gimbalPresets.forEach((p,i)=>{
          html += `
            <tr>
              <td><input style="pointer-events:auto;" value="${p.label||p.name||''}" onchange="gimbalPresetSet(${i},'name',this.value)"></td>
              <td><input style="pointer-events:auto;" type="number" step="0.1" value="${p.yaw||0}" onchange="gimbalPresetSet(${i},'yaw',this.value)"></td>
              <td><input style="pointer-events:auto;" type="number" step="0.1" value="${p.pitch||0}" onchange="gimbalPresetSet(${i},'pitch',this.value)"></td>
              <td><button type="button" class="danger" style="pointer-events:auto;" onclick="gimbalPresetDelete(${i})">Delete</button></td>
            </tr>`;
        });
        tbl.innerHTML=html;
      }

      function gimbalPresetSet(i,k,v){
        if(k==='name') { v=String(v||'').trim(); gimbalPresets[i].label=v; }
        if(k==='yaw' || k==='pitch') v=parseFloat(v||0);
        gimbalPresets[i][k]=v;
        gimbalPresetAutosave();
      }

      function gimbalPresetAdd(){
        gimbalPresets.push({name:'NEW_PRESET',label:'New preset',yaw:0,pitch:0});
        gimbalPresetRender();
        gimbalPresetAutosave();
      }


      function gimbalPresetNudge(i,k,d){
        gimbalPresets[i][k]=parseFloat(gimbalPresets[i][k]||0)+d;
        gimbalPresetRender();
        gimbalPresetAutosave();
      }

      function gimbalPresetDelete(i){
        gimbalPresets.splice(i,1);
        gimbalPresetRender();
        gimbalPresetAutosave();
      }

      async function gimbalCurrentRead(){
        try{
          const r=await fetch('/gimbal_current?ts='+Date.now());
          const j=await r.json();
          const y=document.getElementById('gimbalCurrentYaw');
          const p=document.getElementById('gimbalCurrentPitch');
          if(y) y.textContent=j.yaw;
          if(p) p.textContent=j.pitch;
          window.gimbalLastCurrent=j;
        }catch(e){
          console.log("gimbalCurrentRead fail", e);
        }
      }


      async function gimbalSetZero(){
        try{
          const r=await fetch('/gimbal_set_zero?ts='+Date.now());
          const j=await r.json();
          if(!j.ok) throw new Error(j.error || 'zero failed');
          await gimbalCurrentRead();
          alert('Gimbal center/zero saved');
        }catch(e){
          alert('Failed to set gimbal zero: '+e);
        }
      }

      function gimbalPresetAddCurrent(){
        const j=window.gimbalLastCurrent || {yaw:0,pitch:0};
        const idx=gimbalPresets.length+1;
        gimbalPresets.push({
          name:'Preset '+idx,
          label:'Preset '+idx,
          yaw:parseFloat(j.yaw||0),
          pitch:parseFloat(j.pitch||0)
        });
        gimbalPresetRender();
        gimbalPresetAutosave();
      }

      function gimbalPresetAutosave(){
        clearTimeout(gimbalPresetSaveTimer);
        gimbalPresetSaveTimer=setTimeout(async function(){
          const st=document.getElementById('gimbalPresetSaveStatus');
          try{
            if(st) st.textContent='Saving...';
            const body=new URLSearchParams();
            body.set('presets_json', JSON.stringify(gimbalPresets));
            const r=await fetch('/save_gimbal_presets', {
              method:'POST',
              headers:{'Content-Type':'application/x-www-form-urlencoded'},
              body:body.toString()
            });
            if(!r.ok) throw new Error('HTTP '+r.status);
            if(st) st.textContent='Saved. Refresh page to update button action dropdowns.';
          }catch(e){
            if(st) st.textContent='Save failed: '+e;
          }
        },400);
      }

      gimbalPresetRender();
      gimbalCurrentRead();
      setInterval(gimbalCurrentRead,700);
    </script>
    """.replace("__PRESETS_JSON__", presets_json)


def button_safety_card():
    cfg=read_button_safety_config()
    selected=[a for a in FLIGHT_SAFETY_ACTIONS if a in set(cfg.get("block_when_armed", []))]

    selected_json=json.dumps(selected)
    actions_json=json.dumps(FLIGHT_SAFETY_ACTIONS)

    disarm_checked="checked" if cfg.get("block_disarm_in_air", True) else ""
    toggle_checked="checked" if cfg.get("block_toggle_arm_disarm_in_air", True) else ""

    return f"""
    <div class='card'>
      <h2 style='margin-top:0;'>Flight Safety Blockers</h2>

      <p class='small' style='margin-top:0;'>
        Prevent selected flight actions while the aircraft is armed.
      </p>

      <form method='post' action='/save_button_safety'>

        <label class='small'>Add blocker</label>

        <div style='display:flex;gap:8px;align-items:flex-start;max-width:520px;margin-top:6px;margin-bottom:10px;'>
          <div style='position:relative;max-width:260px;flex:1;'>
            <button id='safetyDropdownButton'
                    type='button'
                    onclick='safetyToggleDropdown()'
                    style='pointer-events:auto;width:100%;margin:0;text-align:left;background:#020617;color:#e5e7eb;border:1px solid #334155;border-radius:6px;padding:7px 32px 7px 10px;min-height:36px;font-size:14px;position:relative;box-sizing:border-box;'>
              Select mode <span style='position:absolute;right:10px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:12px;pointer-events:none;'>▾</span>
            </button>

            <div id='safetyDropdownMenu'
                 style='display:none;position:absolute;left:0;right:0;top:39px;z-index:60;background:#020617;border:1px solid #334155;border-radius:6px;box-shadow:0 10px 22px rgba(0,0,0,.35);overflow:hidden;'>
            </div>
          </div>
        </div>

        <div class='small' style='margin-bottom:6px;'>Active blockers while armed</div>

        <div id='safetySelectedChips'
             style='display:flex;flex-wrap:wrap;gap:8px;min-height:34px;background:#020617;border:1px solid #334155;border-radius:8px;padding:8px;margin-bottom:12px;'>
        </div>

        <input type='hidden' name='block_when_armed_csv' id='blockWhenArmedCsv'>

        <div style='border-top:1px solid #334155;margin-top:12px;padding-top:12px;'>
          <h3 style='font-size:15px;margin:0 0 6px 0;color:#e5e7eb;'>Airborne arm/disarm protection</h3>

          <p class='small' style='margin:0 0 10px 0;'>
            These protections are visible here, but locked by default. Unlock only if you intentionally want to change them.
          </p>

          <label style='display:flex;align-items:center;gap:8px;margin-bottom:10px;font-size:14px;'>
            <input style='pointer-events:auto;width:auto;margin:0;' type='checkbox' id='unlockAirborneSafety'
                   name='unlock_airborne_safety' value='1'
                   onchange='safetyToggleAirborneUnlock()'>
            <span>Unlock advanced airborne safety settings</span>
          </label>

          <div id='airborneWarn' class='small' style='display:none;color:#fbbf24;margin-bottom:10px;'>
            Advanced safety override enabled. Disabling these can allow disarm commands while the aircraft is airborne.
          </div>

          <div style='display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:8px;margin-bottom:12px;'>
            <label style='display:flex;align-items:center;gap:7px;background:#020617;border:1px solid #334155;border-radius:6px;padding:7px 8px;font-size:14px;line-height:1.2;min-height:32px;'>
              <input class='airborneSafety' disabled style='pointer-events:auto;width:auto;margin:0;' type='checkbox' name='block_disarm_in_air' value='1' {disarm_checked}>
              <span>Block DISARM while in air</span>
            </label>

            <label style='display:flex;align-items:center;gap:7px;background:#020617;border:1px solid #334155;border-radius:6px;padding:7px 8px;font-size:14px;line-height:1.2;min-height:32px;'>
              <input class='airborneSafety' disabled style='pointer-events:auto;width:auto;margin:0;' type='checkbox' name='block_toggle_arm_disarm_in_air' value='1' {toggle_checked}>
              <span>Block TOGGLE_ARM disarm while in air</span>
            </label>
          </div>
        </div>

        <div id='safetySaveStatus' class='small' style='min-height:18px;color:#94a3b8;'>Saved automatically</div>

      </form>

      <script>
      const safetyAllActions = {actions_json};
      let safetySelected = {selected_json};
      let safetySaveTimer=null;

      function safetyRender(){{
        const chipBox=document.getElementById('safetySelectedChips');
        const hidden=document.getElementById('blockWhenArmedCsv');
        const menu=document.getElementById('safetyDropdownMenu');
        const btn=document.getElementById('safetyDropdownButton');

        if(!chipBox || !hidden || !menu || !btn) return;

        hidden.value=safetySelected.join(',');
        btn.textContent='Select mode';

        if(safetySelected.length===0){{
          chipBox.innerHTML="<span class='small'>No flight actions are blocked while armed.</span>";
        }} else {{
          chipBox.innerHTML=safetySelected.map(a =>
            "<span style='display:inline-flex;align-items:center;gap:7px;background:#1e293b;border:1px solid #475569;border-radius:999px;padding:5px 9px;font-size:14px;line-height:1;'>" +
            "<span>" + a + "</span>" +
            "<button type='button' onclick=\\"safetyRemoveBlocker('" + a + "')\\" style='pointer-events:auto;background:#334155;color:#e5e7eb;border:0;border-radius:999px;margin:0;padding:1px 6px;font-size:13px;line-height:1.3;'>×</button>" +
            "</span>"
          ).join("");
        }}

        const available=safetyAllActions.filter(a => !safetySelected.includes(a));

        if(available.length===0){{
          menu.innerHTML="<div class='small' style='padding:9px 10px;'>All modes selected</div>";
          btn.textContent='All modes selected';
        }} else {{
          menu.innerHTML=available.map(a =>
            "<button type='button' onclick=\\"safetyAddBlocker('" + a + "')\\" style='display:block;width:100%;text-align:left;margin:0;background:#020617;color:#e5e7eb;border:0;border-bottom:1px solid #1f2937;border-radius:0;padding:8px 10px;font-size:14px;cursor:pointer;'>" +
            a +
            "</button>"
          ).join("");
        }}
      }}

      function safetyToggleDropdown(){{
        const menu=document.getElementById('safetyDropdownMenu');
        if(!menu) return;
        menu.style.display = menu.style.display==='block' ? 'none' : 'block';
      }}

      function safetyAutosave(){{
        clearTimeout(safetySaveTimer);
        safetySaveTimer=setTimeout(async function(){{
          const st=document.getElementById('safetySaveStatus');
          if(st) st.textContent='Saving...';

          const form=document.querySelector("form[action='/save_button_safety']");
          const fd=new FormData(form);

          try {{
            await fetch('/save_button_safety', {{
              method:'POST',
              body:new URLSearchParams(fd)
            }});
            if(st) st.textContent='Saved automatically';
          }} catch(e) {{
            if(st) st.textContent='Save failed';
          }}
        }}, 1200);
      }}

      function safetyAddBlocker(action){{
        if(!action) return;
        if(!safetySelected.includes(action)){{
          safetySelected.push(action);
        }}
        const menu=document.getElementById('safetyDropdownMenu');
        if(menu) menu.style.display='none';
        safetyRender();
        safetyAutosave();
      }}

      function safetyRemoveBlocker(action){{
        safetySelected=safetySelected.filter(a => a!==action);
        safetyRender();
        safetyAutosave();
      }}

      function safetyToggleAirborneUnlock(){{
        const unlock=document.getElementById('unlockAirborneSafety');
        const warn=document.getElementById('airborneWarn');
        document.querySelectorAll('.airborneSafety').forEach(e => e.disabled = !unlock.checked);
        if(warn) warn.style.display = unlock.checked ? 'block' : 'none';
      }}

      document.addEventListener('click', function(e){{
        const menu=document.getElementById('safetyDropdownMenu');
        const btn=document.getElementById('safetyDropdownButton');
        if(!menu || !btn) return;
        if(menu.contains(e.target) || btn.contains(e.target)) return;
        menu.style.display='none';
      }});

      document.addEventListener('change', function(e){{
        if(e.target && e.target.classList && e.target.classList.contains('airborneSafety')) {{
          safetyAutosave();
        }}
      }});

      safetyRender();
      safetyToggleAirborneUnlock();
      </script>
    </div>
    """

def wifi_profiles_cards():
    active_ssid = sh("iwgetid -r 2>/dev/null || true").strip()
    active_conn = sh("nmcli -g GENERAL.CONNECTION dev show wlan0 2>/dev/null || true").strip()

    # --- LIVE SCAN ---
    scan_map = {}
    try:
        sh("timeout 3s sudo -n nmcli dev wifi rescan ifname wlan0 >/dev/null 2>&1 || true")
        scan = sh("nmcli -t -f SSID,SIGNAL dev wifi list ifname wlan0 2>/dev/null")
        for line in scan.splitlines():
            parts = line.rsplit(":", 1)
            if len(parts) == 2:
                ssid = parts[0].replace("\\:", ":").strip()
                sig = int(parts[1]) if parts[1].isdigit() else 0

                if ssid and ssid != "--":
                    scan_map[ssid] = max(sig, scan_map.get(ssid, 0))
    except Exception:
        pass

    lines = sh("nmcli -t -f NAME,TYPE,DEVICE,AUTOCONNECT connection show").splitlines()

    active_list = []
    visible_list = []
    saved_list = []

    for line in lines:
        parts = line.split(":")
        if len(parts) < 4:
            continue

        name, typ, device, autoconnect = parts[0], parts[1], parts[2], parts[3]

        if typ not in ("wifi", "802-11-wireless"):
            continue

        ssid = sh(f"nmcli -g 802-11-wireless.ssid connection show '{name}' 2>/dev/null || true").strip()

        if not ssid and name == active_conn and active_ssid:
            ssid = active_ssid

        if not ssid:
            ssid = "(unknown)"

        prio = sh(f"nmcli -g connection.autoconnect-priority connection show '{name}' 2>/dev/null || true").strip() or "0"
        psk = wifi_pw_get(name)

        active = (name == active_conn or device == "wlan0")
        visible = ssid in scan_map
        signal = scan_map.get(ssid, 0)

        # --- CLASSIFY ---
        if active:
            state = "active"
        elif visible:
            state = "visible"
        else:
            state = "saved"

        entry = (ssid, name, device, autoconnect, prio, signal, state, psk)

        if state == "active":
            active_list.append(entry)
        elif state == "visible":
            visible_list.append(entry)
        else:
            saved_list.append(entry)

    # --- SORT ---
    visible_list.sort(key=lambda x: -x[5])
    saved_list.sort(key=lambda x: -int(x[4]))

    def render_card(e, highlight=False):
        ssid, name, device, autoconnect, prio, signal, state, psk = e

        if state == "active":
            label = "🟢 Connected"
            cls = "ok"
        elif state == "visible":
            label = f"🔵 In range ({signal}%)"
            cls = "warn"
        else:
            label = "🟡 Saved"
            cls = "bad"

        bars = int(signal / 20)
        signal_bar = "▮" * bars + "▯" * (5 - bars)

        is_system = name.startswith("netplan-")

        if is_system:
            controls = "<div class='readonlybox'>System network (read-only)</div>"
        else:
            controls = f"""
            <div class='inlineform'>
              <button style='pointer-events:auto;' class='switchbtn'   onclick="location.href='/wifi_switch?name={esc(name)}'">Connect</button>
              <label>Priority</label>
              <input style='pointer-events:auto;' value='{esc(prio)}' class='smallinput' readonly>
              <label>Auto</label>
              <span>{esc(autoconnect)}</span>
            </div>
            """

        bg = "#0f1b2e" if highlight else "#0b1220"

        try:
            in_range = int(signal) > 0
        except Exception:
            in_range = False

        wifi_actions = ""
        if not highlight:
            if in_range:
                wifi_actions += f"""
<form method='post' action='/wifi_switch' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<button class='switchbtn'>Connect now</button>
</form>"""

            wifi_actions += f"""
<form method='post' action='/wifi_update_password' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<input style='pointer-events:auto;width:170px;' type='password' name='password' value='{esc(psk)}' placeholder='Wi-Fi password'>
<label class='small'>
<input style='pointer-events:auto;width:auto;' type='checkbox' onclick="this.closest('form').querySelector('input[name=password]').type=this.checked?'text':'password'">
Show
</label>
<button style='pointer-events:auto;' type='submit'>Update password</button>
</form>

<form method='post' action='/wifi_delete' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<button class='danger'>Delete</button>
</form>"""

        return f"""
        <div class='ssidcard' style="background:{bg}; border:1px solid #334155;">
          <div class='ssidtop'>
            <div>
              <div class='ssidtitle'>{esc(ssid)} <span class='status-pill {cls}'>{label}</span></div>
              <div class='ssidmeta'>{signal_bar} {signal}%</div>
              <div class='ssidmeta'> {esc(name)}</div>
            </div>
            <div class='ssidfacts'>
              <div><b>Priority</b><br>{esc(prio)}</div>
              <div><b>Auto</b><br>{esc(autoconnect)}</div>
            </div>
          </div>
          <div class='ssidcontrols'>
<form method='post' action='/wifi_update' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<label>Priority</label>
<input name='priority' value='{esc(prio)}' class='smallinput'>
<label>Autoconnect</label>
<select name='autoconnect' class='smallselect'>
<option {'selected' if autoconnect=='yes' else ''}>yes</option>
<option {'selected' if autoconnect=='no' else ''}>no</option>
</select>
<button>Apply</button>
</form>
{wifi_actions}
</div>
        </div>
        """

    html = ""

    if active_list:
        html += "<h2>Connected</h2>"
        for e in active_list:
            html += render_card(e, True)

    if visible_list:
        html += "<h2>Available Networks</h2>"
        for e in visible_list:
            html += render_card(e)

    if saved_list:
        html += "<h2>Saved Networks</h2>"
        for e in saved_list:
            html += render_card(e)

    return html or "<p>No Wi-Fi profiles found</p>"





# === ARDUPLANE PARAMETER IMPORT V1 ===
PARAM_IMPORT_DAEMON_BASE = "http://127.0.0.1:8765"
PARAM_IMPORT_MAX_REQUEST = 8 * 1024 * 1024
PARAM_IMPORT_METADATA_CACHE_FILES = (
    "/etc/siyi/arduplane_param_metadata.json",
    "/etc/siyi/param_metadata_cache.json",
    "/tmp/siyi_param_cache.json",
)
PARAM_IMPORT_METADATA_HOVER_MARKER = "PARAM_IMPORT_METADATA_HOVER_V3"
PARAM_IMPORT_METADATA_EMBED_MARKER = "PARAM_IMPORT_METADATA_EMBED_V1"
_param_import_metadata_lock = threading.Lock()
_param_import_metadata_signature = None
_param_import_metadata_params = {}
_param_import_metadata_sources = []
_param_import_metadata_errors = []


def _param_import_metadata_signature_now():
    signature = []
    for path in PARAM_IMPORT_METADATA_CACHE_FILES:
        try:
            stat = os.stat(path)
            signature.append((path, stat.st_mtime_ns, stat.st_size))
        except OSError:
            continue
    return tuple(signature)


def _param_import_reload_metadata():
    global _param_import_metadata_signature
    global _param_import_metadata_params
    global _param_import_metadata_sources
    global _param_import_metadata_errors

    signature = _param_import_metadata_signature_now()
    if signature == _param_import_metadata_signature:
        return

    merged = {}
    sources = []
    errors = []

    for path, _mtime, _size in signature:
        try:
            with open(path, "r", encoding="utf-8") as handle:
                raw = json.load(handle)
            params = raw.get("params", {}) if isinstance(raw, dict) else {}
            if not isinstance(params, dict):
                raise ValueError("top-level params field is not an object")

            added = 0
            for param_name, meta in params.items():
                normalized = str(param_name or "").strip().upper()
                if not normalized or normalized in merged or not isinstance(meta, dict):
                    continue
                merged[normalized] = meta
                added += 1

            sources.append({"path": path, "entries": len(params), "added": added})
            metadata_error = raw.get("metadata_error") if isinstance(raw, dict) else None
            if metadata_error:
                errors.append(path + ": " + str(metadata_error))
        except Exception as exc:
            errors.append(path + ": " + str(exc))

    _param_import_metadata_params = merged
    _param_import_metadata_sources = sources
    _param_import_metadata_errors = errors
    _param_import_metadata_signature = signature


def param_import_metadata_lookup(name):
    """Return sanitized ArduPilot metadata for one parameter."""
    name = str(name or "").strip().upper()
    if not re.fullmatch(r"[A-Z0-9_]{1,64}", name):
        raise ValueError("Invalid parameter name")

    with _param_import_metadata_lock:
        _param_import_reload_metadata()
        meta = _param_import_metadata_params.get(name)
        sources = list(_param_import_metadata_sources)
        errors = list(_param_import_metadata_errors)

    if not isinstance(meta, dict):
        if not sources:
            message = (
                "Parameter metadata cache is not available. "
                "Run the metadata refresh or perform a full parameter refresh."
            )
        else:
            message = "No ArduPilot metadata is available for this parameter."
        if errors:
            message += " " + errors[-1]
        return {
            "ok": True,
            "name": name,
            "available": False,
            "message": message,
            "sources": sources,
        }

    fields = meta.get("fields") or {}
    values = meta.get("values") or {}
    if not isinstance(fields, dict):
        fields = {}
    if not isinstance(values, dict):
        values = {}

    human_name = str(meta.get("humanName") or "")
    documentation = str(meta.get("documentation") or "")
    user_level = str(meta.get("user") or "")
    descriptive = bool(human_name or documentation or user_level or fields or values)

    if not descriptive:
        message = "The parameter exists in the value cache, but descriptive ArduPilot metadata is missing."
        if errors:
            message += " " + errors[-1]
        return {
            "ok": True,
            "name": name,
            "available": False,
            "message": message,
            "sources": sources,
        }

    return {
        "ok": True,
        "name": name,
        "available": True,
        "humanName": human_name,
        "documentation": documentation,
        "user": user_level,
        "type": meta.get("type"),
        "fields": {str(key): str(value) for key, value in fields.items()},
        "values": {str(key): str(value) for key, value in values.items()},
        "sources": sources,
    }


def param_import_attach_metadata(result):
    """Embed metadata in import preview entries so hover does not need a second request."""
    if not isinstance(result, dict):
        return result
    entries = result.get("entries")
    if not isinstance(entries, list):
        return result

    for entry in entries:
        if not isinstance(entry, dict):
            continue
        name = str(entry.get("name") or "").strip().upper()
        if not name:
            continue
        try:
            entry["metadata"] = param_import_metadata_lookup(name)
        except Exception as exc:
            entry["metadata"] = {
                "ok": False,
                "name": name,
                "available": False,
                "message": "Metadata lookup failed: " + str(exc),
            }
    return result


def param_import_daemon_request(path, method="GET", payload=None, timeout=35):
    url = PARAM_IMPORT_DAEMON_BASE + path
    body = None
    headers = {"Accept": "application/json"}
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read(PARAM_IMPORT_MAX_REQUEST)
    except urllib.error.HTTPError as exc:
        raw = exc.read(PARAM_IMPORT_MAX_REQUEST)
    data = json.loads(raw.decode("utf-8", errors="replace"))
    if not isinstance(data, dict):
        raise ValueError("Parameter daemon returned an invalid response")
    return data


def send_json_response(handler, payload, status=200):
    raw = json.dumps(payload).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def send_param_import_download(handler, daemon_path):
    result = param_import_daemon_request(daemon_path)
    if not result.get("ok"):
        send_json_response(handler, result, 400)
        return
    filename = re.sub(r"[^A-Za-z0-9._-]+", "_", str(result.get("filename", "download.txt")))
    raw = str(result.get("content", "")).encode("utf-8")
    handler.send_response(200)
    handler.send_header("Content-Type", "text/plain; charset=utf-8")
    handler.send_header("Content-Disposition", f'attachment; filename="{filename}"')
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)
# === ARDUPLANE PARAMETER IMPORT V1 END ===

def arduplane_parameters_page():

    import json
    from html import escape as esc

    cache="/etc/siyi/param_metadata_cache.json"

    QGC_LEVELS = {
        "Standard": [
            "ACRO","AHRS","AIRSPEED","ARMING","ARSPD","AUTOTUNE","BATT","BRD",
            "CAM","CHUTE","COMPASS","FBWB","FENCE","FLTMODE","FRSKY","FS",
            "GROUND","KFF","LAND","LGR","LOG","MAN","MIXING","MNT","MSP",
            "NAVL","OSD","PTCH2SRV","PTCH","RC","RLL","SERIAL","SERVO",
            "TECS","THR","TKOFF","YAW","Misc"
        ],
        "Advanced": [
            "AHRS","ARMING","ARSPD","AUTOTUNE","BARO","BATT","BRD","BTN",
            "COMPASS","CRASH","DSPOILER","EK","FLAP","FLTMODE","FRSKY","FS",
            "FWD","GLIDE","GPS","GROUND","INS","KFF","LAND","LOG","MIS",
            "MNT","NAVL","NTF","OSD","PTCH2SRV","PTCH","Q","RALLY","RC",
            "RLL","RNGFND","RNGFNDA","RPM","RSSI","RTL","SERIAL","SERVO",
            "STAT","STEER2SRV","TECS","TERRAIN","THR","TKOFF","TUNE","WP","Misc"
        ],
        "Other": [
            "BARO","CAM","COMPASS","EK","INS","NTF","OSD","PTCH","RELAY","RLL","VTX"
        ],
    }

    try:
        with open(cache) as f:
            raw=json.load(f)
            data=raw.get("params", {})
            received=raw.get("received_count", len(data))
            expected=raw.get("expected_count", "?")
            meta_error=raw.get("metadata_error", "")
    except Exception:
        data={}
        received=0
        expected="?"
        meta_error=""

    # Live paramd fallback: if metadata cache is empty/stale, build page from live /state.
    if not data:
        try:
            import urllib.request
            with urllib.request.urlopen("http://127.0.0.1:8765/state", timeout=5) as r:
                live=json.loads(r.read().decode("utf-8", errors="ignore"))
            live_params=live.get("params", {})
            if live_params:
                data={k: {"value": v.get("value"), "type": v.get("type")} for k,v in live_params.items()}
                received=len(data)
                expected=received
        except Exception as e:
            meta_error = "Live paramd fallback failed: " + repr(e)

    def qgc_group(name):
        special = ["PTCH2SRV", "STEER2SRV", "RNGFNDA", "RNGFND"]
        for sp in special:
            if name.startswith(sp):
                return sp

        first = name.split("_", 1)[0]
        first = re.sub(r"\d+$", "", first)

        if not first:
            first = "Misc"

        return first

    groups={}

    for k,v in sorted(data.items()):
        grp=qgc_group(k)
        groups.setdefault(grp,[]).append((k,v))

    all_groups = sorted(groups.keys())

    def level_for_group(grp):
        levels=[]
        for level, names in QGC_LEVELS.items():
            if grp in names:
                levels.append(level)
        if not levels:
            levels.append("Other")
        return " ".join(levels)

    def group_buttons_for_level(level):
        if level == "All":
            ordered = all_groups
        else:
            ordered = [g for g in QGC_LEVELS.get(level, []) if g in groups]
            extras = [g for g in all_groups if g not in ordered and level in level_for_group(g)]
            ordered += extras

        out = ""
        for grp in ordered:
            safe_grp=esc(grp)
            level_attr=esc(level_for_group(grp))
            out += f"""
            <button type='button'
                    class='paramGroupBtn'
                    data-group='{safe_grp}'
                    data-levels='{level_attr}'
                    onclick="paramFilterGroup('{safe_grp}')">
              {safe_grp}
              <span class='small'>({len(groups.get(grp, []))})</span>
            </button>
            """
        return out

    body=f"""

    <h1>ArduPlane Parameters</h1>

    <div class='card paramTopCompact'>
      <span class='paramTopTitle'>ArduPlane parameter configurator</span>
      <span class='paramTopDivider'></span>
      <span class='small paramTopLoaded'>Loaded parameters: {received}/{expected}</span>
      {("<span class='small' style='color:#f97316;'>Metadata warning: " + esc(meta_error) + "</span>") if meta_error else ""}

      <form onsubmit='return paramManualFullSync(event);' class='paramTopRefreshForm'>
        <button style='pointer-events:auto;'>Refresh Parameters From FC</button>
      </form>

      <a id='fcParamExportBtn'
         class='paramTopRefreshForm'
         href='/fc_parameter_export'
         onclick='return fcParameterExportClick(event);'
         style='pointer-events:auto;display:inline-block;text-decoration:none;background:#2563eb;color:white;border:0;border-radius:8px;padding:9px 13px;margin:4px;cursor:pointer;'>
        FC Parameter Export
      </a>
      <span id='fcExportChromeNote' class='small' style='display:none;color:#94a3b8;margin-left:8px;'>If Chrome blocks the download, open download history and choose Keep.</span>

      <input id='paramImportFileInput'
             type='file'
             accept='.params,.param,.txt,text/plain'
             style='display:none;'
             onchange='paramImportFileSelected(this)'>
      <button type='button'
              class='paramTopRefreshForm'
              style='pointer-events:auto;background:#0f766e;'
              onclick="document.getElementById('paramImportFileInput').click()">
        Import Parameter File
      </button>

      <span class='small paramTopStatus' id='paramRefreshStatus'></span>
    </div>


    <div id='paramImportOverlay' class='paramImportOverlay' aria-hidden='true'>
      <div class='paramImportDialog' role='dialog' aria-modal='true' aria-labelledby='paramImportTitle'>
        <div class='paramImportHeader'>
          <div>
            <h2 id='paramImportTitle'>Import ArduPlane parameters</h2>
            <div id='paramImportSubtitle' class='small'>Select a parameter file to begin.</div>
          </div>
          <button id='paramImportCloseTop' type='button' class='paramImportClose' onclick='paramImportClose()'>&times;</button>
        </div>

        <div id='paramImportLoading' class='paramImportLoading' style='display:none;'>
          <span class='paramImportSpinner'></span>
          <span id='paramImportLoadingText'>Reading and comparing parameters...</span>
        </div>

        <div id='paramImportPreviewPanel' style='display:none;'>
          <div id='paramImportSummary' class='paramImportSummary'></div>
          <div id='paramImportSafety' class='paramImportSafety'></div>
          <div class='paramImportToolbar'>
            <label>Show
              <select id='paramImportFilter' onchange='paramImportApplyFilter()'>
                <option value='changed'>Changed only</option>
                <option value='warnings'>Warnings</option>
                <option value='all'>All parsed parameters</option>
              </select>
            </label>
            <label class='paramImportSelectAll'>
              <input id='paramImportSelectAll' type='checkbox' checked onchange='paramImportToggleAll(this.checked)'>
              Select all applicable changes
            </label>
            <span id='paramImportSelectedCount' class='small'></span>
          </div>
          <div class='paramImportTableWrap'>
            <table class='paramImportTable'>
              <thead><tr><th>Apply</th><th>Parameter</th><th>Current</th><th>Imported</th><th>Status</th><th>Warning</th></tr></thead>
              <tbody id='paramImportRows'></tbody>
            </table>
          </div>
        </div>

        <div id='paramImportProgressPanel' style='display:none;'>
          <div class='paramImportRunStatus'>
            <span id='paramImportRunSpinner' class='paramImportSpinner'></span>
            <div>
              <strong id='paramImportRunTitle'>Applying parameters</strong>
              <div id='paramImportRunMessage' class='small'>Preparing...</div>
            </div>
          </div>
          <div class='paramImportProgressTrack'><div id='paramImportProgressBar'></div></div>
          <div class='paramImportProgressFacts'>
            <span id='paramImportProgressText'>0 of 0 verified</span>
            <strong id='paramImportProgressPercent'>0.0%</strong>
          </div>
          <div id='paramImportCurrentParam' class='paramImportCurrent'></div>
          <div id='paramImportEventLog' class='paramImportEventLog'></div>
        </div>

        <div id='paramImportError' class='paramImportError' style='display:none;'></div>

        <div class='paramImportFooter'>
          <button id='paramImportCancelBtn' type='button' class='danger' style='display:none;' onclick='paramImportCancelJob()'>Cancel operation</button>
          <a id='paramImportBackupBtn' class='paramImportDownload' style='display:none;'>Download pre-import backup</a>
          <a id='paramImportReportBtn' class='paramImportDownload' style='display:none;'>Download result report</a>
          <button id='paramImportRollbackBtn' type='button' class='danger' style='display:none;' onclick='paramImportRollback()'>Restore verified changes</button>
          <button id='paramImportApplyBtn' type='button' style='display:none;' onclick='paramImportApply()'>Apply selected parameters</button>
          <button id='paramImportCloseBtn' type='button' onclick='paramImportClose()'>Close</button>
        </div>
      </div>
      <div id='paramImportMetaPopup'
           class='paramImportMetaPopup'
           role='tooltip'
           aria-hidden='true'>
        <div class='paramImportMetaHeader'>
          <div>
            <div id='paramImportMetaName' class='paramImportMetaName'></div>
            <div id='paramImportMetaHuman' class='paramImportMetaHuman'></div>
          </div>
          <span class='paramImportMetaHint'>Parameter metadata</span>
        </div>
        <div id='paramImportMetaBody' class='paramImportMetaBody'></div>
      </div>
    </div>

    <style>
      .paramImportOverlay{{position:fixed;inset:0;background:rgba(2,6,23,.86);backdrop-filter:blur(4px);z-index:12000;display:none;align-items:center;justify-content:center;padding:24px;}}
      .paramImportOverlay.open{{display:flex;}}
      .paramImportDialog{{width:min(1180px,96vw);height:min(820px,92vh);background:#0f172a;border:1px solid #475569;border-radius:16px;box-shadow:0 24px 80px rgba(0,0,0,.55);display:flex;flex-direction:column;overflow:hidden;}}
      .paramImportHeader{{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;padding:18px 20px;border-bottom:1px solid #334155;background:#111827;}}
      .paramImportHeader h2{{margin:0 0 5px 0;}}
      .paramImportClose{{background:transparent;border:1px solid #475569;font-size:24px;line-height:1;padding:4px 10px;margin:0;}}
      .paramImportLoading{{flex:1;display:flex;align-items:center;justify-content:center;gap:14px;font-size:18px;}}
      .paramImportSpinner{{display:inline-block;width:24px;height:24px;border:3px solid #475569;border-top-color:#38bdf8;border-radius:50%;animation:paramImportSpin .85s linear infinite;flex:0 0 auto;}}
      @keyframes paramImportSpin{{to{{transform:rotate(360deg)}}}}
      #paramImportPreviewPanel,#paramImportProgressPanel{{padding:16px 20px;min-height:0;overflow:hidden;flex:1;}}
      #paramImportPreviewPanel{{display:flex;flex-direction:column;}}
      .paramImportSummary{{display:grid;grid-template-columns:repeat(auto-fit,minmax(135px,1fr));gap:8px;margin-bottom:10px;}}
      .paramImportSummaryItem{{background:#111827;border:1px solid #334155;border-radius:9px;padding:9px 11px;}}
      .paramImportSummaryItem strong{{display:block;font-size:20px;}}
      .paramImportSafety{{display:none;background:#451a03;border:1px solid #f97316;color:#fed7aa;border-radius:9px;padding:10px 12px;margin-bottom:10px;}}
      .paramImportToolbar{{display:flex;align-items:center;gap:16px;flex-wrap:wrap;margin-bottom:10px;}}
      .paramImportToolbar label{{display:flex;align-items:center;gap:8px;}}
      .paramImportToolbar select{{width:auto;min-width:150px;}}
      .paramImportSelectAll input{{width:auto;}}
      .paramImportTableWrap{{overflow:auto;border:1px solid #334155;border-radius:10px;flex:1;min-height:0;}}
      .paramImportTable{{min-width:920px;}}
      .paramImportTable thead{{position:sticky;top:0;background:#111827;z-index:1;}}
      .paramImportTable input{{width:auto;}}
      .paramImportStatus{{display:inline-block;padding:3px 8px;border-radius:999px;background:#334155;font-size:12px;white-space:nowrap;}}
      .paramImportStatus.changed{{background:#1e3a8a;color:#bfdbfe}}.paramImportStatus.same{{background:#14532d;color:#bbf7d0}}.paramImportStatus.unsupported,.paramImportStatus.duplicate{{background:#7c2d12;color:#fed7aa;}}
      .paramImportWarning{{color:#fbbf24;font-size:12px;max-width:360px;}}
      .paramImportMetaRow{{cursor:help;}}
      .paramImportMetaRow:hover{{background:#172033;}}
      .paramImportMetaParamName{{font-weight:800;color:#bae6fd;text-decoration:underline;text-decoration-style:dotted;text-underline-offset:3px;}}
      .paramImportMetaPopup{{position:fixed;display:none;width:min(480px,calc(100vw - 24px));max-height:min(580px,calc(100vh - 24px));overflow:auto;background:#020617;border:1px solid #64748b;border-radius:12px;box-shadow:0 18px 55px rgba(0,0,0,.72);z-index:12050;padding:0;pointer-events:none;}}
      .paramImportMetaPopup.open{{display:block;}}
      .paramImportMetaHeader{{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;padding:13px 15px;border-bottom:1px solid #334155;background:#111827;position:sticky;top:0;}}
      .paramImportMetaName{{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-weight:900;color:#7dd3fc;font-size:16px;}}
      .paramImportMetaHuman{{font-weight:700;color:#e2e8f0;margin-top:3px;}}
      .paramImportMetaHint{{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:#94a3b8;white-space:nowrap;}}
      .paramImportMetaBody{{padding:13px 15px;color:#dbeafe;font-size:13px;line-height:1.45;}}
      .paramImportMetaDescription{{white-space:pre-wrap;margin-bottom:11px;}}
      .paramImportMetaGrid{{display:grid;grid-template-columns:max-content 1fr;gap:5px 12px;margin:8px 0 12px;}}
      .paramImportMetaKey{{color:#94a3b8;font-weight:700;}}
      .paramImportMetaValue{{color:#e2e8f0;overflow-wrap:anywhere;}}
      .paramImportMetaEnums{{border-top:1px solid #334155;padding-top:9px;margin-top:9px;}}
      .paramImportMetaEnumsTitle{{font-weight:800;color:#cbd5e1;margin-bottom:5px;}}
      .paramImportMetaEnumLine{{display:grid;grid-template-columns:minmax(52px,max-content) 1fr;gap:10px;padding:2px 0;}}
      .paramImportMetaEnumCode{{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;color:#7dd3fc;}}
      .paramImportMetaMuted{{color:#94a3b8;font-style:italic;}}
      .paramImportRunStatus{{display:flex;align-items:center;gap:14px;margin-bottom:18px;}}
      .paramImportProgressTrack{{height:18px;border-radius:999px;background:#020617;border:1px solid #334155;overflow:hidden;}}
      #paramImportProgressBar{{height:100%;width:0;background:linear-gradient(90deg,#0284c7,#22c55e);transition:width .3s ease;}}
      .paramImportProgressFacts{{display:flex;justify-content:space-between;margin:9px 0 12px;}}
      .paramImportCurrent{{min-height:24px;color:#bae6fd;font-weight:700;margin-bottom:10px;}}
      .paramImportEventLog{{height:calc(100% - 145px);min-height:220px;overflow:auto;background:#020617;border:1px solid #334155;border-radius:10px;padding:12px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:13px;white-space:pre-wrap;}}
      .paramImportEventLine{{padding:2px 0}}.paramImportEventLine.ok,.paramImportEventLine.complete{{color:#86efac}}.paramImportEventLine.warning{{color:#fbbf24}}.paramImportEventLine.error{{color:#fca5a5;}}
      .paramImportError{{margin:12px 20px 0;padding:10px 12px;background:#450a0a;border:1px solid #ef4444;color:#fecaca;border-radius:9px;}}
      .paramImportFooter{{display:flex;justify-content:flex-end;align-items:center;gap:8px;flex-wrap:wrap;padding:14px 20px;border-top:1px solid #334155;background:#111827;}}
      .paramImportDownload{{display:inline-block;background:#334155;color:white;border-radius:8px;padding:9px 13px;text-decoration:none;cursor:pointer;}}
      @media(max-width:700px){{.paramImportOverlay{{padding:5px}}.paramImportDialog{{width:99vw;height:98vh}}.paramImportHeader{{padding:12px}}.paramImportFooter{{padding:10px}}.paramImportSummary{{grid-template-columns:repeat(2,1fr)}}}}
    </style>

    <div class='paramLayout'>

      <div class='paramSide'>
        <h2>Parameter Groups</h2>

        <div class='paramLevelTabs'>

        </div>

        <div id='paramGroupButtons'>
          <button type='button' class='paramGroupBtn active' data-group='__ALL__' data-levels='All Standard Advanced Other' onclick="paramFilterGroup('__ALL__')">
            All <span class='small'>({len(data)})</span>
          </button>

          {group_buttons_for_level("All")}
        </div>
      </div>

      <div class='paramMain'>
        <div class='card paramToolbar'>
          <div class='paramSearchMainRow'>

            <input id='paramSearch'
                   style='pointer-events:auto;width:100%;'
                   placeholder='Search parameter, e.g. MNT_ or SERIAL4'
                   oninput='paramSaveState(); paramApplyFilter()'>

            <select id='paramSearchMode'
                    style='pointer-events:auto;'
                    onchange='paramSaveState(); paramApplyFilter()'>
              <option value='contains'>Contains</option>
              <option value='startswith' selected>Begins with</option>
            </select>

            <button type='button'
                    onclick='paramClearSearch()'
                    title="Clear search" aria-label="Clear search" style="width:28px;height:28px;min-width:28px;padding:0;display:inline-flex;align-items:center;justify-content:center;font-size:20px;font-weight:800;line-height:1;color:#fca5a5;background:transparent;border:1px solid #c8ccd2;border-radius:6px;cursor:pointer;">&times;</button>

          </div>

          <div class='paramSearchSecondaryRow'>

            <select id='paramQuickSearch'
                    class='paramQuickSearchSelect'
                    onchange='paramApplyQuickSearch(this)'>
              <option value=''>Quick search...</option>
            </select>

            <button type='button'
                    class='paramQuickActionBtn'
                    title='Freeze current search'
                    onclick='paramFreezeCurrentSearch()'>
              ❄ Freeze
            </button>

            <button type='button'
                    class='paramQuickActionBtn'
                    title='Unfreeze current search'
                    onclick='paramUnfreezeCurrentSearch()'>
              ↺ Unfreeze
            </button>

            <button type='button'
                    class='paramQuickActionBtn paramQuickDeleteBtn'
                    title='Delete current search from quick list'
                    onclick='paramDeleteCurrentSearch()'>
              × Remove
            </button>

          </div>

          <div class='paramSearchFooterRow'>
            <p class='small' id='paramResultCount'></p>

            <span class='small paramWildcardHint'>
              * = any chars&nbsp;&nbsp;? = one char
            </span>
          </div>
        </div>
    """

    body += "<div class='paramScrollArea'>"

    for grp in all_groups:

        body += f"""
        <div class='card paramGroupCard' data-group='{esc(grp)}' data-levels='{esc(level_for_group(grp))}'>
          <h2>{esc(grp)}</h2>
          <div class='paramList'>
        """

        for name,val in groups[grp]:

            search_blob = name

            if val is None:
                value_display="<span style='color:#ef4444;'>Missing</span>"
                desc_html="<span class='small'>Timeout reading parameter</span>"
                level="Other"
            else:
                raw_val=str(val.get("value"))
                label=val.get("value_label") or ""
                values=val.get("values") or {}

                if values:
                    opts=""
                    current_key=str(int(float(raw_val))) if str(raw_val).replace(".0","").lstrip("-").isdigit() else str(raw_val)
                    for code,text in sorted(values.items(), key=lambda x: float(x[0]) if str(x[0]).replace(".","",1).lstrip("-").isdigit() else 999999):
                        selected="selected" if str(code)==current_key else ""
                        opts += f"<option value='{esc(str(code))}' {selected}>{esc(str(text))} ({esc(str(code))})</option>"

                    editor=f"""
                    <select name='value' class='paramEditInput'>
                      {opts}
                    </select>
                    """
                else:
                    editor=f"<input name='value' class='paramEditInput' value='{esc(raw_val)}'>"

                if label:
                    value_display=f"<b>{esc(label)}</b> <span class='small'>({esc(raw_val)})</span>"
                else:
                    value_display=f"<b>{esc(raw_val)}</b>"

                value_display += f"""
                <form method='post'
                      action='/param_write'
                      class='paramWriteForm'
                      onsubmit="return confirm('Write parameter {esc(name)} ?');">
                  <input type='hidden' name='name' value='{esc(name)}'>
                  {editor}
                  <button type='submit' class='paramWriteBtn'>Write</button>
                </form>
                """

                human=val.get("humanName") or ""
                doc=val.get("documentation") or ""
                user=val.get("user") or ""

                if human or doc:
                    desc_html=f"<span>{esc(human)}</span><br><span class='small'>{esc(doc)}</span>"
                else:
                    desc_html="<span class='small'>No metadata description</span>"

                level=user or "Other"

                search_blob = " ".join([
                    name,
                    str(label),
                    str(human),
                    str(doc),
                    str(grp),
                    str(level),
                ])

            body += f"""
            <div class='paramRow'
                 data-group='{esc(grp)}'
                 data-levels='{esc(level_for_group(grp))}'
                 data-param='{esc(name)}'
                 data-paramname='{esc(name)}'
                 data-search='{esc(search_blob.lower())}'>
              <div class='paramName'>{esc(name)}</div>
              <div class='paramValue' id='paramValue_{esc(name)}'>{value_display}</div>
              <div class='paramDesc'>{desc_html}</div>
            </div>
            """

        body += "</div></div>"

    body += """
      </div>
      </div>
    </div>

    <style>
      .paramLayout{
        display:grid;
        grid-template-columns:270px 1fr;
        gap:16px;
        align-items:start;
        overflow:visible;
      }
      .paramTopCompact{
        display:flex;
        align-items:center;
        gap:16px;
        flex-wrap:wrap;
        padding:10px 16px;
        margin-bottom:10px;
      }
      .paramTopCompact p,
      .paramTopCompact form{
        margin:0;
      }
      .paramTopTitle{
        font-weight:bold;
      }
      .paramTopDivider{
        width:1px;
        height:24px;
        background:#475569;
      }
      .paramTopRefreshForm{
        display:inline-flex;
        align-items:center;
      }
      .paramTopStatus{
        color:#22c55e;
        font-weight:bold;
      }

      .paramSide{
        height:calc(100vh - var(--paramPaneTop, 190px) - 24px);
        min-height:0;
        overflow:auto;
        box-sizing:border-box;
        background:#0b1220;
        border:1px solid #334155;
        border-radius:10px;
        padding:12px;
      }
      .paramSide h2{
        margin-top:0;
        position:sticky;
        top:-12px;
        z-index:20;
        background:#0b1220;
        padding:4px 0 10px 0;
      }
      .paramLevelTabs{
        display:grid;
        grid-template-columns:1fr 1fr;
        gap:6px;
        margin-bottom:12px;
      }
      .paramLevelBtn{
        margin:0;
        padding:8px 6px;
        background:#374151;
        border:1px solid #4b5563;
        color:#e5e7eb;
      }
      .paramLevelBtn.active{
        background:#fff27a;
        color:#111827;
        border-color:#fde047;
      }
      .paramGroupBtn{
        display:block;
        width:100%;
        text-align:center;
        margin:6px 0;
        padding:10px 8px;
        background:#747484;
        border:1px solid #747484;
        color:white;
        border-radius:5px;
      }
      .paramGroupBtn.active{
        background:#fff27a;
        color:#111827;
        border-color:#fde047;
      }
      .paramMain{
        min-width:0;
        height:calc(100vh - var(--paramPaneTop, 190px) - 24px);
        min-height:0;
        box-sizing:border-box;
        display:flex;
        flex-direction:column;
        overflow:hidden;
      }
      .paramToolbar{
        flex:0 0 auto;
        margin-bottom:0;
      }
      .paramScrollArea{
        flex:1 1 auto;
        overflow-y:auto;
        padding-right:6px;
        min-height:0;
      }
      .paramSearchBar{
        display:grid;
        grid-template-columns:minmax(260px, 1fr) minmax(180px, 260px) auto minmax(220px, auto);
        gap:10px;
        align-items:center;
      }
      .paramSearchMainRow{
        display:grid;
        grid-template-columns:minmax(320px,1fr) 180px auto;
        gap:10px;
        align-items:center;
      }

      .paramSearchSecondaryRow{
        margin-top:8px;
        display:flex;
        align-items:center;
        gap:8px;
        flex-wrap:wrap;
        opacity:.88;
      }

      .paramSearchFooterRow{
        margin-top:8px;
        display:flex;
        justify-content:space-between;
        align-items:center;
        gap:12px;
      }

      .paramQuickSearchSelect{
        min-width:220px;
        max-width:320px;
        pointer-events:auto;
      }

      .paramWildcardHint{
        color:#94a3b8;
        white-space:nowrap;
      }

      .paramQuickActionBtn{
        height:28px;
        padding:0 10px;
        border-radius:999px;
        font-size:12px;
        background:#0f172a;
        color:#94a3b8;
        border:1px solid #334155;
      }

      .paramQuickActionBtn:hover{
        color:#e5e7eb;
        border-color:#64748b;
        background:#111827;
      }

      .paramQuickDeleteBtn{
        color:#fca5a5;
      }

      .paramQuickDeleteBtn:hover{
        color:#fecaca;
      }
      .paramSearchBar input,
      .paramSearchBar select{
        width:100% !important;
        max-width:none !important;
        box-sizing:border-box;
      }
      .paramSearchBar select{
        background:#020617;
        color:#e5e7eb;
        border:1px solid #334155;
        border-radius:8px;
        padding:9px 10px;
      }
      .paramQuickActionBtn{
        pointer-events:auto;
        width:30px;
        height:30px;
        padding:0;
        margin:0;
        border-radius:999px;
        border:1px solid #334155;
        background:#0b1220;
        color:#94a3b8;
        font-size:14px;
        line-height:1;
        opacity:.78;
      }
      .paramQuickActionBtn:hover{
        opacity:1;
        color:#e5e7eb;
        border-color:#64748b;
        background:#111827;
      }
      .paramQuickDeleteBtn{
        color:#fca5a5;
      }
      .paramQuickDeleteBtn:hover{
        color:#fecaca;
        border-color:#7f1d1d;
      }
      .paramToolbar{
        padding:10px 12px;
      }
      #paramResultCount{
        margin:8px 0 0 0;
      }
      .paramList{display:flex;flex-direction:column;}
      .paramRow{
        display:grid;
        grid-template-columns:210px 170px 1fr;
        gap:16px;
        padding:7px 4px;
        border-bottom:1px solid rgba(148,163,184,.18);
        align-items:start;
        cursor:pointer;
      }
      .paramRow:hover{background:#111827;}
      .paramName{
        color:#dbeafe;
        font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size:14px;
      }
      .paramValue{
        color:#e5e7eb;
        font-size:14px;
      }
      .paramDesc{
        color:#cbd5e1;
        font-size:13px;
      }
      .paramWriteForm{
        margin-top:7px;
        display:flex;
        gap:6px;
        align-items:center;
        flex-wrap:wrap;
      }
      .paramEditInput{
        pointer-events:auto;
        width:130px;
        background:#020617;
        color:#e5e7eb;
        border:1px solid #334155;
        border-radius:7px;
        padding:6px 8px;
      }
      .paramWriteBtn{
        pointer-events:auto;
        padding:6px 9px;
        font-size:12px;
        background:#14532d;
      }
      .paramHidden{display:none !important;}
      @media (max-width:1000px){
        .paramLayout{
          grid-template-columns:1fr;
          height:auto;
          overflow:visible;
        }
        .paramSide{position:relative;max-height:none;}
        .paramMain{
          height:auto;
          overflow:visible;
          display:block;
        }
        .paramScrollArea{
          overflow:visible;
        }
        .paramRow{grid-template-columns:1fr;}
      }


      /* ===== PARAM TOOLBAR FINAL POLISH ===== */

      .paramSearchMainRow{
        grid-template-columns:340px 180px auto !important;
        align-items:center !important;
      }

      .paramSearchSecondaryRow{
        margin-top:8px !important;
        display:grid !important;
        grid-template-columns:340px 36px 36px 36px !important;
        gap:8px !important;
        align-items:center !important;
      }

      .paramSearchMainRow input{
        width:340px !important;
        max-width:340px !important;
      }

      .paramQuickSearchSelect{
        width:340px !important;
        max-width:340px !important;
        min-width:340px !important;
      }

      .paramIconBtn,
      .paramQuickActionBtn{
        width:36px !important;
        height:36px !important;
        min-width:36px !important;
        padding:0 !important;
        border-radius:8px !important;

        display:flex !important;
        align-items:center !important;
        justify-content:center !important;

        font-size:16px !important;
        line-height:1 !important;

        background:#0f172a !important;
        border:1px solid #334155 !important;

        overflow:hidden !important;
        text-indent:-9999px !important;
        position:relative !important;
      }

      .paramIconBtn::before,
      .paramQuickActionBtn::before{
        position:absolute;
        inset:0;
        display:flex;
        align-items:center;
        justify-content:center;
        text-indent:0;
        font-size:16px;
      }

      button[onclick*='Freeze']::before{
        content:'❄';
        color:#93c5fd;
      }

      button[onclick*='Unfreeze']::before{
        content:'↺';
        color:#cbd5e1;
      }

      button[onclick*='Delete']::before{
        content:'×';
        color:#fca5a5;
        font-size:18px;
        font-weight:700;
      }

      .paramIconBtn:hover,
      .paramQuickActionBtn:hover{
        border-color:#64748b !important;
        background:#111827 !important;
      }


    </style>

    <script>
      let selectedParamLevel='All';
      let selectedParamGroup='__ALL__';

      function paramUpdatePaneHeights(){
        try{
          const side=document.querySelector('.paramSide');
          const main=document.querySelector('.paramMain');
          const el=side || main;
          if(!el){return;}
          const top=Math.ceil(el.getBoundingClientRect().top);
          document.documentElement.style.setProperty('--paramPaneTop', top + 'px');
        }catch(e){}
      }

      function paramDeleteCurrentSearch(){
        const input=document.getElementById('paramSearch');
        const value=String(input?.value || '').trim();

        if(!value){return;}

        let data=paramHistoryLoad();
        const key=value.toLowerCase();

        data.frozen=data.frozen.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.recent=data.recent.filter(function(v){
          return v.toLowerCase() !== key;
        });

        paramHistorySave(data);
        paramHistoryRender();
      }

      window.addEventListener('load', function(){
        paramUpdatePaneHeights();
        setTimeout(paramUpdatePaneHeights, 50);
      });
      window.addEventListener('resize', paramUpdatePaneHeights);

      function paramSaveState(){
        try{
          localStorage.setItem('siyi_param_level', selectedParamLevel);
          localStorage.setItem('siyi_param_group', selectedParamGroup);
          localStorage.setItem('siyi_param_search', document.getElementById('paramSearch')?.value || '');
          localStorage.setItem('siyi_param_search_mode', document.getElementById('paramSearchMode')?.value || 'startswith');
        }catch(e){}
      }

      function paramRestoreState(){
        try{
          selectedParamLevel = localStorage.getItem('siyi_param_level') || 'All';
          selectedParamGroup = localStorage.getItem('siyi_param_group') || '__ALL__';

          const search=document.getElementById('paramSearch');
          if(search){ search.value = localStorage.getItem('siyi_param_search') || ''; }

          const mode=document.getElementById('paramSearchMode');
          if(mode){ mode.value = localStorage.getItem('siyi_param_search_mode') || 'startswith'; }
        }catch(e){
          selectedParamLevel='All';
          selectedParamGroup='__ALL__';
        }
      }

      function paramFilterLevel(level){
        selectedParamLevel=level;
        selectedParamGroup='__ALL__';
        paramSaveState();

        document.querySelectorAll('.paramLevelBtn').forEach(btn=>{
          btn.classList.toggle('active', btn.dataset.level===level);
        });

        document.querySelectorAll('.paramGroupBtn').forEach(btn=>{
          const g=btn.dataset.group || '';
          const levels=btn.dataset.levels || '';
          let visible = (g==='__ALL__' || level==='All' || levels.split(' ').includes(level));
          btn.classList.toggle('paramHidden', !visible);
          btn.classList.toggle('active', g==='__ALL__');
        });
        paramApplyFilter();
        // paramSyncVisibleAfterFilterChange(); // disabled: live /state polling handles normal updates
      }

      function paramFilterGroup(group){
        selectedParamGroup=group;

        const search=document.getElementById('paramSearch');
        if(search){ search.value=''; }

        paramSaveState();

        document.querySelectorAll('.paramGroupBtn').forEach(btn=>{
          btn.classList.toggle('active', btn.dataset.group===group);
        });
        paramApplyFilter();
        // paramSyncVisibleAfterFilterChange(); // disabled: live /state polling handles normal updates
      }

      const PARAM_SEARCH_HISTORY_KEY='siyi_param_search_history_v2_clean';

      function paramHistoryEmpty(){
        return {frozen:[], recent:[]};
      }

      function paramHistoryNormalize(data){
        let frozen=[];
        let recent=[];

        if(Array.isArray(data)){
          recent=data;
        }else if(data && typeof data === 'object'){
          frozen=Array.isArray(data.frozen) ? data.frozen : [];
          recent=Array.isArray(data.recent) ? data.recent : [];
        }

        frozen=frozen
          .map(function(v){return String(v || '').trim();})
          .filter(function(v){return v.length > 0;});

        recent=recent
          .map(function(v){return String(v || '').trim();})
          .filter(function(v){return v.length > 0;});

        const seen=new Set();

        frozen=frozen.filter(function(v){
          const k=v.toLowerCase();
          if(seen.has(k)){return false;}
          seen.add(k);
          return true;
        });

        recent=recent.filter(function(v){
          const k=v.toLowerCase();
          if(seen.has(k)){return false;}
          seen.add(k);
          return true;
        }).slice(0,10);

        return {frozen:frozen, recent:recent};
      }

      function paramHistoryLoad(){
        try{
          const raw=localStorage.getItem(PARAM_SEARCH_HISTORY_KEY) || '[]';
          return paramHistoryNormalize(JSON.parse(raw));
        }catch(e){
          return paramHistoryEmpty();
        }
      }

      function paramHistorySave(data){
        try{
          localStorage.setItem(
            PARAM_SEARCH_HISTORY_KEY,
            JSON.stringify(paramHistoryNormalize(data))
          );
        }catch(e){}
      }

      function paramHistoryRender(){
        const sel=document.getElementById('paramQuickSearch');
        if(!sel){return;}

        while(sel.options.length > 1){
          sel.remove(1);
        }

        const data=paramHistoryLoad();
        const arr=data.frozen.concat(data.recent);

        arr.forEach(function(v){
          const opt=document.createElement('option');
          opt.value=v;
          opt.textContent=(data.frozen.map(function(x){return x.toLowerCase();}).includes(v.toLowerCase()) ? '❄ ' : '') + v;
          sel.appendChild(opt);
        });
      }

      function paramHistoryRemember(){
        const input=document.getElementById('paramSearch');
        if(!input){return;}

        const value=String(input.value || '').trim();
        if(!value){return;}

        let data=paramHistoryLoad();
        const key=value.toLowerCase();

        if(data.frozen.map(function(v){return v.toLowerCase();}).includes(key)){
          paramHistoryRender();
          return;
        }

        data.recent=data.recent.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.recent.unshift(value);
        data=paramHistoryNormalize(data);

        paramHistorySave(data);
        paramHistoryRender();
      }

      function paramFreezeCurrentSearch(){
        const input=document.getElementById('paramSearch');
        const value=String(input?.value || '').trim();
        if(!value){return;}

        let data=paramHistoryLoad();
        const key=value.toLowerCase();

        data.frozen=data.frozen.filter(function(v){
          return v.toLowerCase() !== key;
        });
        data.recent=data.recent.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.frozen.unshift(value);
        data=paramHistoryNormalize(data);

        paramHistorySave(data);
        paramHistoryRender();
      }

      function paramUnfreezeCurrentSearch(){
        const input=document.getElementById('paramSearch');
        const value=String(input?.value || '').trim();
        if(!value){return;}

        let data=paramHistoryLoad();
        const key=value.toLowerCase();

        data.frozen=data.frozen.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.recent=data.recent.filter(function(v){
          return v.toLowerCase() !== key;
        });

        data.recent.unshift(value);
        data=paramHistoryNormalize(data);

        paramHistorySave(data);
        paramHistoryRender();
      }

      window.addEventListener('load', function(){
        paramHistoryRender();

        const input=document.getElementById('paramSearch');
        if(input){
          input.addEventListener('change', paramHistoryRemember);
          input.addEventListener('keydown', function(ev){
            if(ev.key === 'Enter'){
              paramHistoryRemember();
            }
          });
        }
      });

      function paramApplyQuickSearch(sel){
        const search=document.getElementById('paramSearch');
        const value=sel?.value || '';

        if(value && search){
          search.value=value;
          paramSaveState();
          paramApplyFilter();
          // paramSyncVisibleAfterFilterChange(); // disabled: live /state polling handles normal updates
        }

        if(sel){
          sel.value='';
        }
      }

      function paramClearSearch(){
        const search=document.getElementById('paramSearch');
        if(search){ search.value=''; }

        paramSaveState();
        paramApplyFilter(); // auto visible sync disabled; live state polling handles updates

        try{
          localStorage.removeItem('siyi_param_search');
        }catch(e){}
      }

      function paramWildcardMatch(text, pattern){
        text=(text || '').toLowerCase();
        pattern=(pattern || '').toLowerCase();

        let ti=0, pi=0, star=-1, match=0;

        while(ti < text.length){
          if(pi < pattern.length && (pattern[pi] === '?' || pattern[pi] === text[ti])){
            ti++;
            pi++;
          }else if(pi < pattern.length && pattern[pi] === '*'){
            star=pi;
            match=ti;
            pi++;
          }else if(star !== -1){
            pi=star+1;
            match++;
            ti=match;
          }else{
            return false;
          }
        }

        while(pi < pattern.length && pattern[pi] === '*'){
          pi++;
        }

        return pi === pattern.length;
      }

      function paramWildcardContains(text, pattern){
        text=(text || '').toLowerCase();
        pattern=(pattern || '').toLowerCase();

        for(let i=0; i<=text.length; i++){
          if(paramWildcardMatch(text.slice(i), pattern)){
            return true;
          }
        }
        return false;
      }

      function paramApplyFilter(){
        const q=(document.getElementById('paramSearch')?.value || '').toLowerCase().trim();
        const mode=(document.getElementById('paramSearchMode')?.value || 'startswith');
        const hasWildcard=(q.includes('*') || q.includes('?'));
        let visibleRows=0;

        document.querySelectorAll('.paramGroupCard').forEach(card=>{
          const group=card.dataset.group || '';
          const levels=card.dataset.levels || '';
          let groupVisibleRows=0;

          card.querySelectorAll('.paramRow').forEach(row=>{
            const rowGroup=row.dataset.group || '';
            const rowLevels=row.dataset.levels || '';
            const param=row.dataset.param || '';
            const blob=row.dataset.search || '';

            let okLevel=(selectedParamLevel==='All' || rowLevels.split(' ').includes(selectedParamLevel));
            let okGroup=(selectedParamGroup==='__ALL__' || rowGroup===selectedParamGroup);

            let okSearch=true;
            if(q){
              if(hasWildcard){
                if(mode === 'contains'){
                  okSearch = paramWildcardContains(blob, q);
                }else{
                  let pattern=q;

                  if(!pattern.endsWith('*')){
                    pattern += '*';
                  }

                  okSearch = paramWildcardMatch(
                    param.toLowerCase(),
                    pattern
                  );
                }
              }else if(mode === 'contains'){
                okSearch = blob.includes(q);
              }else{
                okSearch = param.toLowerCase().startsWith(q);
              }
            }

            const show=okLevel && okGroup && okSearch;
            row.classList.toggle('paramHidden', !show);

            if(show){
              groupVisibleRows++;
              visibleRows++;
            }
          });

          card.classList.toggle('paramHidden', groupVisibleRows===0);
        });

        const c=document.getElementById('paramResultCount');
        if(c){
          c.textContent = 'Showing ' + visibleRows + ' parameter(s)';
        }
      }

      async function paramPollRefreshState(){
        try{
          const r=await fetch('/param_sync_status?ts=' + Date.now());
          const j=await r.json();
          const el=document.getElementById('paramRefreshStatus');

          if(el){
            el.textContent = j.message || '';
            el.style.color = j.running ? '#facc15' : (j.ok ? '#22c55e' : '#ef4444');
          }

          if(j.running){
            setTimeout(paramPollRefreshState, 1000);
          }else if(j.ok && sessionStorage.getItem('siyi_param_refresh_pending') === '1'){

            // IMPORTANT:
            // Do NOT start additional PARAM_REQUEST_READ traffic immediately
            // after full PARAM_REQUEST_LIST refresh.
            //
            // Multiple concurrent pymavlink param readers can steal
            // PARAM_VALUE messages from each other and corrupt refresh stability.
            //
            // Simply reload once stable full cache completed.
            sessionStorage.removeItem('siyi_param_refresh_pending');
            // Disabled: caused reload loop after paramd sync completed.
            // Cached values are now updated through /param_state polling.
            paramPollVisibleState();
          }
        }catch(e){
          setTimeout(paramPollRefreshState, 2000);
        }
      }

      document.addEventListener('submit', (e)=>{
        if(e.target && e.target.getAttribute('action') === '/params_refresh'){
          sessionStorage.setItem('siyi_param_refresh_pending', '1');
        }
      });

      let paramLiveRefreshRunning=false;
      let paramLiveRefreshGeneration=0;
      let paramLiveRefreshAbortController=null;

      function paramApplyCachedStateUpdate(pname, item){
        try{
          if(!pname || !item || item.missing) return;

          const box=document.getElementById('paramValue_' + pname);
          if(!box) return;

          const row=box.closest('.paramRow');
          if(row && row.classList.contains('paramHidden')) return;

          const val=String(item.value).replace(/\\.0$/, '');
          const input=box.querySelector('.paramEditInput');

          // Do not overwrite a value while the user is actively editing it.
          if(input && document.activeElement === input){
            return;
          }

          if(input){
            input.value=val;
          }

          const b=box.querySelector('b');
          if(b){
            if(input && input.tagName === 'SELECT'){
              const opt=[...input.options].find(o => String(o.value) === val);
              if(opt){
                input.value=opt.value;
                b.textContent=opt.textContent.replace(/ \\([^)]*\\)$/, '');
              }else{
                b.textContent=val;
              }
            }else{
              b.textContent=val;
            }
          }

          box.dataset.liveTs=String(item.ts || Date.now()/1000);
        }catch(e){
          console.log('paramApplyCachedStateUpdate failed', e);
        }
      }

      let paramStatePollRunning=false;

      async function paramPollVisibleState(){
        if(paramStatePollRunning) return;
        paramStatePollRunning=true;

        try{
          let rows=[...document.querySelectorAll('.paramRow')]
            .filter(r => !r.classList.contains('paramHidden'))
            .slice(0,120);

          const names=rows
            .map(r => r.dataset.paramname || r.dataset.param || '')
            .filter(Boolean);

          if(!names.length) return;

          const r=await fetch('/param_state?names=' + encodeURIComponent(names.join(',')) + '&ts=' + Date.now(), {cache:'no-store'});
          const j=await r.json();

          if(j && j.ok && j.params){
            Object.entries(j.params).forEach(([name,item]) => {
              paramApplyCachedStateUpdate(name,item);
            });
          }
        }catch(e){
          console.log('paramPollVisibleState failed', e);
        }finally{
          paramStatePollRunning=false;
        }
      }

      async function paramManualFullSync(event){
        if(event) event.preventDefault();

        const el=document.getElementById('paramRefreshStatus');
        if(el){
          el.textContent='Synchronizing parameters from FC...';
          el.style.color='#facc15';
        }

        try{
          const r=await fetch('/param_trigger_full_sync?ts=' + Date.now(), {cache:'no-store'});
          const j=await r.json();
          if(!j || !j.ok){
            if(el){
              el.textContent='Parameter sync failed';
              el.style.color='#ef4444';
            }
            alert('Parameter sync failed: ' + ((j && j.error) ? j.error : 'unknown error'));
            return false;
          }
          paramPollSyncStatus();
        }catch(e){
          if(el){
            el.textContent='Parameter sync failed';
            el.style.color='#ef4444';
          }
          alert('Parameter sync failed: ' + e.message);
        }

        return false;
      }

      async function paramPollSyncStatus(){
        try{
          const el=document.getElementById('paramRefreshStatus');
          if(!el) return;
          const r=await fetch('/param_sync_status?ts=' + Date.now(), {cache:'no-store'});
          const j=await r.json();
          if(!j || !j.ok) return;

          if(j.running){
            el.textContent=j.message || 'Synchronizing parameters from FC...';
            el.style.color='#facc15';
          }else if(j.last_ok){
            el.textContent='Parameters synchronized from FC';
            el.style.color='#22c55e';
          }
        }catch(e){
          console.log('paramPollSyncStatus failed', e);
        }
      }

      function paramStartSyncStatusPolling(){
        if(window.siyiParamSyncStatusTimer) return;
        window.siyiParamSyncStatusTimer=setInterval(paramPollSyncStatus, 1000);
        setTimeout(paramPollSyncStatus, 250);
      }

      function paramStartStatePolling(){
        if(window.siyiParamStatePollTimer) return;
        window.siyiParamStatePollTimer=setInterval(paramPollVisibleState, 500);
        setTimeout(paramPollVisibleState, 200);
      }

      async function paramLiveReadVisibleSerial(syncGeneration){

        const myGeneration = syncGeneration || paramLiveRefreshGeneration;

        if(paramLiveRefreshRunning){
          return;
        }

        paramLiveRefreshRunning=true;

        const el=document.getElementById('paramRefreshStatus');
        let rows=[...document.querySelectorAll('.paramRow')];

        // Older/restored backups may not consistently preserve .paramRow.
        // Fall back to any element carrying parameter metadata.
        if(!rows.length){
          rows=[...document.querySelectorAll('[data-paramname]')];
        }

        rows = rows
          .filter(r => !r.classList.contains('paramHidden'))
          .slice(0,80);

        if(el){
          el.textContent='Synchronizing parameters from FC...';  // only for explicit/manual sync paths
          el.style.color='#facc15';
        }

        let n=0;
        let failed=[];
        for(const row of rows){

          if(myGeneration !== paramLiveRefreshGeneration){
            break;
          }

          try{
            const pname=row.dataset.paramname;
            if(!pname) continue;

            const controller = new AbortController();
            paramLiveRefreshAbortController = controller;

            const timeout = setTimeout(()=>{
              controller.abort();
            }, 5000);

            let j=null;

            try{
              const r=await fetch(
                '/param_live_read?name=' + encodeURIComponent(pname) + '&ts=' + Date.now(),
                {signal: controller.signal}
              );

              j=await r.json();
            }finally{
              clearTimeout(timeout);
            }

            if(!j){
              failed.push(pname + ': no response');
              continue;
            }

            if(j.ok){
              const box=document.getElementById('paramValue_' + pname);
              if(box){
                const input=box.querySelector('.paramEditInput');
                if(input){ input.value = String(j.value).replace(/\\.0$/, ''); }

                const b=box.querySelector('b');
                if(b){
                  if(input && input.tagName === 'SELECT'){
                    const opt=input.options[input.selectedIndex];
                    b.textContent = opt ? opt.textContent.replace(/ \\([^)]*\\)$/, '') : j.value;
                  }else{
                    b.textContent = j.value;
                  }
                }
              }
              n++;
            }else{
              failed.push(pname + ': ' + (j.error || 'not ok'));
            }
          }catch(e){
            if(myGeneration !== paramLiveRefreshGeneration){
              break;
            }
            failed.push((row && row.dataset ? row.dataset.paramname : '?') + ': ' + e);
          }
        }

        if(el && myGeneration === paramLiveRefreshGeneration){
          el.textContent='Parameters synchronized from FC';
          el.style.color='#22c55e';
        }

        paramLiveRefreshAbortController=null;
        paramLiveRefreshRunning=false;
      }

      document.addEventListener('DOMContentLoaded', ()=>{
        paramRestoreState();

        document.querySelectorAll('.paramLevelBtn').forEach(btn=>{
          btn.classList.toggle('active', btn.dataset.level===selectedParamLevel);
        });

        document.querySelectorAll('.paramGroupBtn').forEach(btn=>{
          const g=btn.dataset.group || '';
          const levels=btn.dataset.levels || '';
          let visible = (g==='__ALL__' || selectedParamLevel==='All' || levels.split(' ').includes(selectedParamLevel));
          btn.classList.toggle('paramHidden', !visible);
          btn.classList.toggle('active', g===selectedParamGroup);
        });

        paramApplyFilter();
        paramStartStatePolling();
        paramStartSyncStatusPolling();
        paramPollRefreshState();

        // Auto live param reads enabled: siyi-paramd serializes MAVLink parameter access safely
        
// setTimeout(paramLiveReadVisibleSerial, 700); // disabled
// setTimeout(paramLiveReadVisibleSerial, 1800); // disabled
// setTimeout(paramLiveReadVisibleSerial, 3200); // disabled

      });

      // window load auto live sync disabled; paramd startup sync + state polling handles normal updates

      // pageshow auto live sync disabled; paramd startup sync + state polling handles normal updates

      // FORCE live FC reads whenever /parameters is opened/refreshed.
      // This avoids relying on stale rendered/cache values.
      let paramFilterSyncTimer=null;

      function fcParameterExportClick(event){
      if(event) event.preventDefault();

      const st=document.getElementById('paramRefreshStatus');
      const n=document.getElementById('fcExportChromeNote');
      const b=document.getElementById('fcParamExportBtn');

      if(st) st.innerText='Synchronizing parameters from FC… export will download when ready';
      if(n) n.style.display='inline';
      if(b) {
        b.innerText='Export running…';
        b.style.opacity='0.75';
        b.style.pointerEvents='none';
      }

      fetch('/fc_parameter_export?ts='+Date.now())
        .then(function(r){
          if(!r.ok){
            return r.text().then(function(t){
              throw new Error(t || ('HTTP '+r.status));
            });
          }
          const cd=r.headers.get('Content-Disposition') || '';
          const m=cd.match(/filename="?([^";]+)"?/);
          const fn=m ? m[1] : 'fc_parameters.params';
          return r.blob().then(function(blob){
            const u=URL.createObjectURL(blob);
            const a=document.createElement('a');
            a.href=u;
            a.download=fn;
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(function(){ URL.revokeObjectURL(u); }, 1000);
          });
        })
        .catch(function(e){
          alert('FC Parameter Export failed: ' + e.message);
        })
        .finally(function(){
          if(st) st.innerText='';
          if(n) n.style.display='none';
          if(b) {
            b.innerText='FC Parameter Export';
            b.style.opacity='1';
            b.style.pointerEvents='auto';
          }
        });

      return false;
    }

    function paramSyncVisibleAfterFilterChange(){
        try{
          // Any page/filter/search/group change invalidates the currently running sync.
          paramLiveRefreshGeneration++;

          if(paramFilterSyncTimer){
            clearTimeout(paramFilterSyncTimer);
            paramFilterSyncTimer=null;
          }

          if(paramLiveRefreshAbortController){
            try{ paramLiveRefreshAbortController.abort(); }catch(e){}
            paramLiveRefreshAbortController=null;
          }

          const thisGeneration = paramLiveRefreshGeneration;

          const el=document.getElementById('paramRefreshStatus');
          if(el){
            el.textContent='Waiting to synchronize parameters from FC...';
            el.style.color='#facc15';
          }

          paramFilterSyncTimer=setTimeout(function(){
            if(typeof paramLiveReadVisibleSerial === 'function'){
              // paramLiveReadVisibleSerial(thisGeneration); // disabled: /state polling handles normal updates
            }
          }, 2500);

        }catch(e){
          console.log('paramSyncVisibleAfterFilterChange failed', e);
        }
      }


      function paramForceRefreshFromFC(){
        try{
          sessionStorage.setItem('siyi_param_refresh_pending', '1');

          if(typeof paramApplyFilter === 'function'){
            paramApplyFilter();
          }

          if(typeof paramLiveReadVisibleSerial === 'function'){
            // setTimeout(paramLiveReadVisibleSerial, 200); // disabled
            // setTimeout(paramLiveReadVisibleSerial, 1200); // disabled
            // setTimeout(paramLiveReadVisibleSerial, 2500); // disabled
          }
        }catch(e){
          console.log('paramForceRefreshFromFC failed', e);
        }
      }

      window.addEventListener('load', paramForceRefreshFromFC);

      window.addEventListener('pageshow', paramForceRefreshFromFC);

      // === ARDUPLANE PARAMETER IMPORT V1 ===
      let paramImportSessionId='';
      let paramImportPreview=null;
      let paramImportStatusTimer=null;
      const paramImportMetadataCache=new Map();
      let paramImportMetaHoverTimer=null;
      let paramImportMetaRequestSerial=0;
      let paramImportMetaLastPointer={x:0,y:0};

      function paramImportMetaHide(){
        clearTimeout(paramImportMetaHoverTimer);
        const popup=document.getElementById('paramImportMetaPopup');
        if(popup){ popup.classList.remove('open'); popup.setAttribute('aria-hidden','true'); }
      }

      function paramImportMetaPosition(clientX,clientY){
        const popup=document.getElementById('paramImportMetaPopup');
        if(!popup) return;
        paramImportMetaLastPointer={x:clientX,y:clientY};
        const gap=18;
        const margin=12;
        const rect=popup.getBoundingClientRect();
        let left=clientX+gap;
        let top=clientY+gap;
        if(left+rect.width+margin>window.innerWidth) left=clientX-rect.width-gap;
        if(top+rect.height+margin>window.innerHeight) top=window.innerHeight-rect.height-margin;
        left=Math.max(margin,left);
        top=Math.max(margin,top);
        popup.style.left=Math.round(left)+'px';
        popup.style.top=Math.round(top)+'px';
      }

      function paramImportMetaText(parent,className,text){
        const node=document.createElement('div');
        if(className) node.className=className;
        node.textContent=text;
        parent.appendChild(node);
        return node;
      }

      function paramImportMetaGridRow(grid,key,value){
        if(value===null || value===undefined || String(value).trim()==='') return;
        paramImportMetaText(grid,'paramImportMetaKey',String(key));
        paramImportMetaText(grid,'paramImportMetaValue',String(value));
      }

      function paramImportRenderMetadata(data,item){
        const name=document.getElementById('paramImportMetaName');
        const human=document.getElementById('paramImportMetaHuman');
        const body=document.getElementById('paramImportMetaBody');
        name.textContent=item.name;
        human.textContent=(data && data.available && data.humanName) ? data.humanName : '';
        body.replaceChildren();

        const grid=document.createElement('div');
        grid.className='paramImportMetaGrid';
        paramImportMetaGridRow(grid,'Current value',item.current===null || item.current===undefined ? 'Not present on FC':item.current);
        paramImportMetaGridRow(grid,'Imported value',item.imported);
        paramImportMetaGridRow(grid,'Import status',item.status);
        if(item.type!==null && item.type!==undefined) paramImportMetaGridRow(grid,'MAVLink type',item.type);

        if(!data || !data.available){
          body.appendChild(grid);
          paramImportMetaText(body,'paramImportMetaMuted',(data && data.message) || 'No ArduPilot metadata is available for this parameter.');
          return;
        }

        if(data.documentation) paramImportMetaText(body,'paramImportMetaDescription',data.documentation);
        paramImportMetaGridRow(grid,'User level',data.user);
        Object.entries(data.fields || {}).forEach(([key,value])=>paramImportMetaGridRow(grid,key,value));
        body.appendChild(grid);

        const entries=Object.entries(data.values || {});
        if(entries.length){
          const enumBox=document.createElement('div');
          enumBox.className='paramImportMetaEnums';
          paramImportMetaText(enumBox,'paramImportMetaEnumsTitle','Allowed / enumerated values');
          entries.slice(0,60).forEach(([code,label])=>{
            const line=document.createElement('div'); line.className='paramImportMetaEnumLine';
            paramImportMetaText(line,'paramImportMetaEnumCode',code);
            paramImportMetaText(line,'',label);
            enumBox.appendChild(line);
          });
          if(entries.length>60) paramImportMetaText(enumBox,'paramImportMetaMuted','+'+(entries.length-60)+' additional values');
          body.appendChild(enumBox);
        }
      }

      async function paramImportMetaShowNow(item,event){
        const popup=document.getElementById('paramImportMetaPopup');
        if(!popup) return;
        popup.classList.add('open');
        popup.setAttribute('aria-hidden','false');
        document.getElementById('paramImportMetaName').textContent=item.name;
        document.getElementById('paramImportMetaHuman').textContent='';
        const body=document.getElementById('paramImportMetaBody');
        body.replaceChildren();
        paramImportMetaText(body,'paramImportMetaMuted','Loading parameter metadata...');
        paramImportMetaPosition(event.clientX,event.clientY);

        const serial=++paramImportMetaRequestSerial;
        try{
          let data=item.metadata || paramImportMetadataCache.get(item.name);
          if(data){
            paramImportMetadataCache.set(item.name,data);
          }else{
            const response=await fetch('/param_metadata?name='+encodeURIComponent(item.name),{cache:'no-store'});
            data=await response.json();
            if(!response.ok || !data.ok) throw new Error(data.error || ('HTTP '+response.status));
            paramImportMetadataCache.set(item.name,data);
          }
          if(serial!==paramImportMetaRequestSerial || !popup.classList.contains('open')) return;
          paramImportRenderMetadata(data,item);
          paramImportMetaPosition(paramImportMetaLastPointer.x,paramImportMetaLastPointer.y);
        }catch(error){
          if(serial!==paramImportMetaRequestSerial) return;
          paramImportRenderMetadata({available:false,message:'Metadata lookup failed: '+error.message},item);
          paramImportMetaPosition(paramImportMetaLastPointer.x,paramImportMetaLastPointer.y);
        }
      }

      function paramImportMetaSchedule(item,event){
        clearTimeout(paramImportMetaHoverTimer);
        paramImportMetaLastPointer={x:event.clientX,y:event.clientY};
        paramImportMetaHoverTimer=setTimeout(()=>paramImportMetaShowNow(item,event),220);
      }

      function paramImportMetaMove(event){
        paramImportMetaLastPointer={x:event.clientX,y:event.clientY};
        const popup=document.getElementById('paramImportMetaPopup');
        if(popup && popup.classList.contains('open')) paramImportMetaPosition(event.clientX,event.clientY);
      }

      function paramImportOpen(){
        const overlay=document.getElementById('paramImportOverlay');
        if(overlay){ overlay.classList.add('open'); overlay.setAttribute('aria-hidden','false'); }
      }

      function paramImportClose(){
        paramImportMetaHide();
        const state=document.getElementById('paramImportOverlay');
        const cancel=document.getElementById('paramImportCancelBtn');
        if(cancel && cancel.style.display!=='none'){
          alert('The parameter operation is still running. Cancel it or wait for completion.');
          return;
        }
        if(state){ state.classList.remove('open'); state.setAttribute('aria-hidden','true'); }
      }

      function paramImportSetError(message){
        const box=document.getElementById('paramImportError');
        if(!box) return;
        box.textContent=message || '';
        box.style.display=message ? 'block' : 'none';
      }

      function paramImportShowLoading(message){
        paramImportMetaHide();
        paramImportOpen();
        paramImportSetError('');
        document.getElementById('paramImportLoadingText').textContent=message || 'Working...';
        document.getElementById('paramImportLoading').style.display='flex';
        document.getElementById('paramImportPreviewPanel').style.display='none';
        document.getElementById('paramImportProgressPanel').style.display='none';
        document.getElementById('paramImportApplyBtn').style.display='none';
        document.getElementById('paramImportCancelBtn').style.display='none';
        document.getElementById('paramImportRollbackBtn').style.display='none';
        document.getElementById('paramImportBackupBtn').style.display='none';
        document.getElementById('paramImportReportBtn').style.display='none';
      }

      async function paramImportFileSelected(input){
        const file=input.files && input.files[0];
        input.value='';
        if(!file) return;
        if(file.size > 2*1024*1024){ alert('Parameter file is larger than 2 MB.'); return; }
        paramImportShowLoading('Reading file and comparing it with the connected flight controller...');
        try{
          const content=await file.text();
          const response=await fetch('/param_import_preview',{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({filename:file.name,content:content}),
            cache:'no-store'
          });
          const result=await response.json();
          if(!response.ok || !result.ok) throw new Error(result.error || ('HTTP '+response.status));
          paramImportPreview=result;
          paramImportSessionId=result.session_id;
          paramImportRenderPreview(result);
        }catch(error){
          document.getElementById('paramImportLoading').style.display='none';
          paramImportSetError('Parameter-file preview failed: '+error.message);
        }
      }

      function paramImportSummaryItem(label,value){
        const box=document.createElement('div');
        box.className='paramImportSummaryItem';
        const strong=document.createElement('strong'); strong.textContent=String(value);
        const text=document.createElement('span'); text.className='small'; text.textContent=label;
        box.append(strong,text); return box;
      }

      function paramImportRenderPreview(result){
        document.getElementById('paramImportLoading').style.display='none';
        const panel=document.getElementById('paramImportPreviewPanel');
        panel.style.display='flex';
        document.getElementById('paramImportSubtitle').textContent=result.filename;
        const summary=document.getElementById('paramImportSummary');
        summary.replaceChildren(
          paramImportSummaryItem('Changed',result.summary.changed),
          paramImportSummaryItem('Already match',result.summary.same),
          paramImportSummaryItem('Unsupported',result.summary.unsupported),
          paramImportSummaryItem('Duplicate',result.summary.duplicates),
          paramImportSummaryItem('Invalid lines',result.summary.invalid_lines),
          paramImportSummaryItem('Critical changes',result.summary.critical_changes)
        );
        const safety=document.getElementById('paramImportSafety');
        const messages=[];
        if(result.summary.flap_conflicts){
          messages.push(result.summary.flap_conflicts+' imported SERVOx_FUNCTION change(s) conflict with the servo outputs currently configured for Pi flap control. They are unselected by default.');
        }
        if(result.summary.critical_changes){
          messages.push('Critical flight-control or hardware parameters are present. Type IMPORT when applying them.');
        }
        safety.textContent=messages.join(' ');
        safety.style.display=messages.length ? 'block' : 'none';
        const body=document.getElementById('paramImportRows');
        body.replaceChildren();
        (result.entries || []).forEach(item=>{
          const row=document.createElement('tr');
          row.dataset.status=item.status;
          row.dataset.warning=(item.warning || item.critical || item.flap_conflict) ? '1':'0';
          row.dataset.name=item.name;
          row.dataset.critical=item.critical ? '1':'0';
          const apply=document.createElement('td');
          const check=document.createElement('input');
          check.type='checkbox'; check.className='paramImportCheck'; check.value=item.name;
          check.checked=!!item.selected; check.disabled=item.status!=='changed';
          check.addEventListener('change',paramImportUpdateSelectedCount);
          apply.appendChild(check);
          const name=document.createElement('td');
          name.textContent=item.name;
          name.className='paramImportMetaParamName';
          name.title='Hover to show ArduPilot parameter metadata';
          row.classList.add('paramImportMetaRow');
          row.tabIndex=0;
          row.addEventListener('mouseenter',event=>paramImportMetaSchedule(item,event));
          row.addEventListener('mousemove',paramImportMetaMove);
          row.addEventListener('mouseleave',paramImportMetaHide);
          row.addEventListener('focus',()=>{
            const rect=row.getBoundingClientRect();
            paramImportMetaSchedule(item,{clientX:Math.min(rect.right,window.innerWidth-20),clientY:Math.min(rect.top+24,window.innerHeight-20)});
          });
          row.addEventListener('blur',paramImportMetaHide);
          const current=document.createElement('td'); current.textContent=item.current===null || item.current===undefined ? '—':String(item.current);
          const imported=document.createElement('td'); imported.textContent=String(item.imported);
          const status=document.createElement('td');
          const pill=document.createElement('span'); pill.className='paramImportStatus '+item.status; pill.textContent=item.status; status.appendChild(pill);
          const warning=document.createElement('td'); warning.className='paramImportWarning'; warning.textContent=item.warning || '';
          row.append(apply,name,current,imported,status,warning);
          body.appendChild(row);
        });
        document.getElementById('paramImportFilter').value='changed';
        document.getElementById('paramImportSelectAll').checked=true;
        document.getElementById('paramImportApplyBtn').style.display='inline-block';
        document.getElementById('paramImportCloseBtn').style.display='inline-block';
        paramImportApplyFilter();
        paramImportUpdateSelectedCount();
      }

      function paramImportApplyFilter(){
        const filter=document.getElementById('paramImportFilter').value;
        document.querySelectorAll('#paramImportRows tr').forEach(row=>{
          let show=true;
          if(filter==='changed') show=row.dataset.status==='changed';
          if(filter==='warnings') show=row.dataset.warning==='1';
          row.style.display=show ? 'table-row':'none';
        });
      }

      function paramImportToggleAll(checked){
        document.querySelectorAll('.paramImportCheck:not(:disabled)').forEach(box=>{ box.checked=checked; });
        paramImportUpdateSelectedCount();
      }

      function paramImportUpdateSelectedCount(){
        const selected=[...document.querySelectorAll('.paramImportCheck:checked:not(:disabled)')];
        document.getElementById('paramImportSelectedCount').textContent=selected.length+' selected';
        document.getElementById('paramImportApplyBtn').textContent='Apply '+selected.length+' parameter'+(selected.length===1?'':'s');
      }

      async function paramImportApply(){
        const selected=[...document.querySelectorAll('.paramImportCheck:checked:not(:disabled)')];
        if(!selected.length){ alert('Select at least one changed parameter.'); return; }
        const critical=selected.some(box=>box.closest('tr').dataset.critical==='1');
        let confirmation='';
        if(critical){
          confirmation=window.prompt('Critical flight-control or hardware parameters are selected. Type IMPORT to continue:') || '';
          if(confirmation!=='IMPORT') return;
        }
        if(!confirm('Apply '+selected.length+' selected parameter changes to the connected flight controller?')) return;
        paramImportShowProgress('Starting parameter import...');
        try{
          const response=await fetch('/param_import_apply',{
            method:'POST',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({session_id:paramImportSessionId,parameters:selected.map(box=>box.value),confirmation:confirmation}),
            cache:'no-store'
          });
          const result=await response.json();
          if(!response.ok || !result.ok) throw new Error(result.error || ('HTTP '+response.status));
          paramImportStartPolling();
        }catch(error){
          paramImportSetError('Unable to start import: '+error.message);
          document.getElementById('paramImportCancelBtn').style.display='none';
        }
      }

      function paramImportShowProgress(message){
        paramImportOpen(); paramImportSetError('');
        document.getElementById('paramImportLoading').style.display='none';
        document.getElementById('paramImportPreviewPanel').style.display='none';
        document.getElementById('paramImportProgressPanel').style.display='block';
        document.getElementById('paramImportRunMessage').textContent=message || '';
        document.getElementById('paramImportApplyBtn').style.display='none';
        document.getElementById('paramImportCancelBtn').style.display='inline-block';
        document.getElementById('paramImportCloseTop').style.display='none';
        document.getElementById('paramImportCloseBtn').style.display='none';
      }

      function paramImportStartPolling(){
        if(paramImportStatusTimer) clearInterval(paramImportStatusTimer);
        paramImportStatusTimer=setInterval(paramImportPollStatus,700);
        paramImportPollStatus();
      }

      async function paramImportPollStatus(){
        try{
          const response=await fetch('/param_import_status?ts='+Date.now(),{cache:'no-store'});
          const state=await response.json();
          if(!state.ok) return;
          if(state.session_id) paramImportSessionId=state.session_id;
          if(state.running || ['applying','rolling_back','complete','failed','cancelled','rolled_back'].includes(state.status)){
            paramImportShowProgress(state.message || state.status);
            const pct=Math.max(0,Math.min(100,Number(state.progress)||0));
            document.getElementById('paramImportProgressBar').style.width=pct+'%';
            document.getElementById('paramImportProgressPercent').textContent=pct.toFixed(1)+'%';
            document.getElementById('paramImportProgressText').textContent=(state.verified||0)+' of '+(state.total||0)+' verified';
            document.getElementById('paramImportCurrentParam').textContent=state.current_parameter ? 'Current parameter: '+state.current_parameter : '';
            document.getElementById('paramImportRunMessage').textContent=state.message || '';
            document.getElementById('paramImportRunTitle').textContent=state.operation==='rollback' ? 'Restoring parameters':'Applying parameters';
            const log=document.getElementById('paramImportEventLog');
            log.replaceChildren();
            (state.events || []).forEach(event=>{
              const line=document.createElement('div'); line.className='paramImportEventLine '+(event.level||'info'); line.textContent=(event.level==='ok'?'✓ ':event.level==='error'?'✕ ':event.level==='warning'?'⚠ ':'→ ')+(event.text||''); log.appendChild(line);
            });
            log.scrollTop=log.scrollHeight;
            const running=!!state.running;
            document.getElementById('paramImportCancelBtn').style.display=running ? 'inline-block':'none';
            document.getElementById('paramImportCloseTop').style.display=running ? 'none':'inline-block';
            document.getElementById('paramImportCloseBtn').style.display=running ? 'none':'inline-block';
            document.getElementById('paramImportRunSpinner').style.display=running ? 'inline-block':'none';
            if(!running){
              if(paramImportStatusTimer){ clearInterval(paramImportStatusTimer); paramImportStatusTimer=null; }
              const sid=encodeURIComponent(paramImportSessionId);
              if(state.backup_file){ const b=document.getElementById('paramImportBackupBtn'); b.href='/param_import_backup?session_id='+sid; b.style.display='inline-block'; }
              const r=document.getElementById('paramImportReportBtn'); r.href='/param_import_report?session_id='+sid; r.style.display='inline-block';
              document.getElementById('paramImportRollbackBtn').style.display=state.can_rollback ? 'inline-block':'none';
              if(state.status==='complete' || state.status==='rolled_back'){
                document.getElementById('paramImportRunTitle').textContent=state.status==='rolled_back' ? 'Rollback complete':'Parameter import complete';
              }else if(state.error){ paramImportSetError(state.error); }
            }
          }
        }catch(error){ console.log('paramImportPollStatus failed',error); }
      }

      async function paramImportCancelJob(){
        if(!confirm('Cancel after the current parameter write finishes?')) return;
        await fetch('/param_import_cancel',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
      }

      async function paramImportRollback(){
        const confirmation=window.prompt('Restore all verified changes from the pre-import backup? Type RESTORE to continue:') || '';
        if(confirmation!=='RESTORE') return;
        paramImportShowProgress('Starting rollback...');
        try{
          const response=await fetch('/param_import_rollback',{
            method:'POST',headers:{'Content-Type':'application/json'},
            body:JSON.stringify({session_id:paramImportSessionId,confirmation:confirmation})
          });
          const result=await response.json();
          if(!response.ok || !result.ok) throw new Error(result.error || ('HTTP '+response.status));
          paramImportStartPolling();
        }catch(error){ paramImportSetError('Unable to start rollback: '+error.message); }
      }

      document.addEventListener('DOMContentLoaded',()=>{
        fetch('/param_import_status?ts='+Date.now(),{cache:'no-store'})
          .then(response=>response.json())
          .then(state=>{ if(state && state.ok && state.running){ paramImportSessionId=state.session_id||''; paramImportStartPolling(); } })
          .catch(()=>{});
      });
      // === ARDUPLANE PARAMETER IMPORT V1 END ===

    </script>
    """

    return page("ArduPlane Parameters", body)

def page(title, body):
    initial_upgrade_state = json.dumps(software_update_status_payload(), ensure_ascii=False)
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>{title}</title>
<style>
body{{margin:0;background:#0f172a;color:#e5e7eb;font-family:Arial}}
header{{background:#020617;padding:10px 20px;font-size:22px;font-weight:bold;border-bottom:1px solid #334155;position:fixed;top:0;left:0;right:0;z-index:2;height:36px}}
nav{{width:180px;background:#020617;height:calc(100vh - 58px);position:fixed;left:0;top:58px;padding:15px;border-right:1px solid #334155;overflow-y:auto}}
nav a{{display:block;color:#cbd5e1;text-decoration:none;padding:11px;border-radius:8px;margin-bottom:4px}}
nav a:hover{{background:#1f2937;color:white}}
main{{margin-left:210px;padding:82px 24px 24px 24px}}
.card{{background:#111827;border:1px solid #334155;border-radius:12px;padding:16px;margin-bottom:16px}}
.grid{{display:grid;grid-template-columns:repeat(2,minmax(220px,1fr));gap:12px}}
table{{border-collapse:collapse;width:100%;font-size:14px}}
td,th{{border-bottom:1px solid #334155;padding:8px;text-align:left;vertical-align:top}}
input,select,textarea{{background:#020617;color:#e5e7eb;border:1px solid #334155;border-radius:6px;padding:7px;width:100%}}
button{{background:#2563eb;color:white;border:0;border-radius:8px;padding:9px 13px;margin:4px;cursor:pointer}}
button.danger{{background:#991b1b}}
pre{{background:#020617;border:1px solid #334155;border-radius:8px;padding:12px;overflow:auto;white-space:pre-wrap}}
.ok{{color:#22c55e}} .bad{{color:#ef4444}} .small{{font-size:13px;color:#94a3b8}}
.pill{{padding:3px 8px;border-radius:999px;font-size:12px;margin-left:8px}}
.pill.active{{background:#14532d;color:#86efac}}
.pill.inactive{{background:#334155;color:#cbd5e1}}
.ssidcard{{border:1px solid #334155;border-radius:10px;padding:14px;margin-bottom:12px;background:#0b1220}}
.ssidtop{{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}}
.ssidtitle{{font-size:18px;font-weight:bold;margin-bottom:6px}}
.ssidmeta{{color:#94a3b8;font-size:13px;line-height:1.5}}
.ssidfacts{{display:flex;gap:18px;margin-top:10px}}
.ssidcontrols{{margin-top:12px;border-top:1px solid #334155;padding-top:10px}}
.inlineform{{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:6px 0}}
.smallinput{{width:80px}}
.smallselect{{width:120px}}
.switchbtn{{background:#16a34a}}
.readonlybox{{color:#94a3b8}}

.statusdotimg{{width:14px;height:14px;margin-left:12px;vertical-align:middle}}
.statuslabel{{font-size:13px;color:#94a3b8;margin-left:6px;font-weight:normal}}

.statusdot{{display:inline-block;width:13px;height:13px;border-radius:50%;background:#ef4444;margin-left:12px;vertical-align:middle;box-shadow:0 0 8px #ef4444}}
.statusdot.ok{{background:#22c55e;box-shadow:0 0 8px #22c55e}}
.statuslabel{{font-size:13px;color:#94a3b8;margin-left:6px;font-weight:normal}}


#top-status-bar{{display:inline-flex;gap:6px;align-items:center;white-space:nowrap}}
.status-pill{{font-size:13px;font-weight:bold;padding:5px 10px;border-radius:999px;color:white;margin-left:6px}}
.status-pill.ok{{background:#166534;color:white}}
.status-pill.bad{{background:#991b1b;color:white}}
.status-pill.warn{{background:#92400e;color:white}}


/* SOFTWARE_UPDATE_MODAL_V1 */
body.siyi-upgrade-locked{{overflow:hidden}}
#siyiUpgradeOverlay{{
  display:none;position:fixed;inset:0;z-index:1000000;
  background:rgba(2,6,23,.88);backdrop-filter:blur(5px);
  align-items:center;justify-content:center;padding:24px;box-sizing:border-box;
}}
#siyiUpgradeOverlay.visible{{display:flex}}
#siyiUpgradeDialog{{
  width:min(920px,94vw);height:min(720px,90vh);box-sizing:border-box;
  background:#0b1220;border:1px solid #475569;border-radius:16px;
  box-shadow:0 24px 80px rgba(0,0,0,.65);padding:22px;
  display:flex;flex-direction:column;gap:14px;
}}
.siyi-upgrade-title-row{{display:flex;align-items:center;justify-content:space-between;gap:16px}}
.siyi-upgrade-title{{font-size:25px;font-weight:800}}
.siyi-upgrade-version{{font-size:14px;color:#94a3b8}}
.siyi-upgrade-running-row{{display:flex;align-items:center;gap:12px;font-size:18px;font-weight:700}}
.siyi-upgrade-spinner{{
  width:28px;height:28px;border:4px solid #334155;border-top-color:#60a5fa;
  border-radius:50%;animation:siyiUpgradeSpin .8s linear infinite;flex:0 0 auto;
}}
@keyframes siyiUpgradeSpin{{to{{transform:rotate(360deg)}}}}
.siyi-upgrade-result-icon{{display:none;font-size:30px;font-weight:900;line-height:1}}
.siyi-upgrade-result-icon.ok{{color:#22c55e}}
.siyi-upgrade-result-icon.bad{{color:#ef4444}}
.siyi-upgrade-progress-shell{{height:18px;border-radius:999px;background:#1e293b;overflow:hidden;border:1px solid #334155}}
.siyi-upgrade-progress-bar{{
  height:100%;width:0%;background:#2563eb;transition:width .45s ease;
  position:relative;overflow:hidden;
}}
.siyi-upgrade-progress-bar.running::after{{
  content:'';position:absolute;inset:0;
  background:linear-gradient(110deg,transparent 0%,rgba(255,255,255,.25) 45%,transparent 70%);
  transform:translateX(-100%);animation:siyiUpgradeSweep 1.2s linear infinite;
}}
@keyframes siyiUpgradeSweep{{to{{transform:translateX(100%)}}}}
.siyi-upgrade-stage{{font-size:16px;font-weight:700;color:#e2e8f0}}
.siyi-upgrade-meta{{display:flex;justify-content:space-between;gap:12px;color:#94a3b8;font-size:13px}}
#siyiUpgradeLog{{
  flex:1;min-height:250px;margin:0;background:#020617;border:1px solid #334155;
  border-radius:10px;padding:14px;overflow:auto;white-space:pre-wrap;
  font:14px/1.55 ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;
}}
.siyi-upgrade-warning{{color:#fbbf24;font-size:14px;font-weight:700}}
.siyi-upgrade-actions{{display:none;gap:10px;justify-content:flex-end;align-items:center}}
.siyi-upgrade-actions.visible{{display:flex}}
.siyi-upgrade-detail{{display:none;border-top:1px solid #334155;padding-top:10px;color:#94a3b8;font-size:13px}}
.siyi-upgrade-detail.visible{{display:block}}
@media(max-width:700px){{
  #siyiUpgradeOverlay{{padding:8px}}
  #siyiUpgradeDialog{{width:98vw;height:96vh;padding:15px}}
  .siyi-upgrade-title{{font-size:21px}}
}}

</style></head>
<body>
<header>
SIYI Pi Control Center {VERSION}<span id="statusbar" style="display:inline-block;margin-left:14px;vertical-align:middle;"></span>
</header>
<nav>
<a href="/">Operations</a>
{'' if setup_is_complete() else '<a href="/first_setup">Wizard</a>'}
<a href="/wifi">WiFi</a>
<a href="/zerotier">ZeroTier</a>
<a href="/endpoints">Hosts</a>
<a href="/mavlink">MAVLink</a>
<a href="/video">Video</a>
<a href="/buttons">Buttons</a>
<a href="/flaps">Flaps</a>
<a href="/parameters">ArduPlane Parameters</a>
<a href="/camera_controls">Camera</a>
<a href="/camera_sd">Camera SD</a>
<a href="/logs">Diagnostics</a>
<a href="/software_update">Software Update</a>
</nav>
<main>{body}</main>

<div id="siyiUpgradeOverlay" role="dialog" aria-modal="true" aria-labelledby="siyiUpgradeTitle" aria-hidden="true">
  <div id="siyiUpgradeDialog">
    <div class="siyi-upgrade-title-row">
      <div>
        <div id="siyiUpgradeTitle" class="siyi-upgrade-title">Software update</div>
        <div id="siyiUpgradeVersion" class="siyi-upgrade-version">Preparing upgrade...</div>
      </div>
      <div id="siyiUpgradePercent" style="font-size:22px;font-weight:800;">0%</div>
    </div>

    <div class="siyi-upgrade-running-row">
      <div id="siyiUpgradeSpinner" class="siyi-upgrade-spinner"></div>
      <div id="siyiUpgradeResultOk" class="siyi-upgrade-result-icon ok">✓</div>
      <div id="siyiUpgradeResultBad" class="siyi-upgrade-result-icon bad">✕</div>
      <div id="siyiUpgradeHeadline">Installing</div>
    </div>

    <div class="siyi-upgrade-progress-shell">
      <div id="siyiUpgradeProgressBar" class="siyi-upgrade-progress-bar running"></div>
    </div>

    <div id="siyiUpgradeStage" class="siyi-upgrade-stage">Starting upgrade</div>
    <div class="siyi-upgrade-meta">
      <span id="siyiUpgradeConnection">Connected to WebUI</span>
      <span id="siyiUpgradeStarted"></span>
    </div>

    <pre id="siyiUpgradeLog">Waiting for upgrade status...</pre>

    <div id="siyiUpgradeWarning" class="siyi-upgrade-warning">
      Do not power off the Raspberry Pi during installation.
    </div>

    <div id="siyiUpgradeDetail" class="siyi-upgrade-detail"></div>

    <div id="siyiUpgradeActions" class="siyi-upgrade-actions">
      <button type="button" onclick="siyiUpgradeToggleDetails()">View details</button>
      <button id="siyiUpgradePrimaryAction" type="button" onclick="siyiUpgradeReload()">Reload WebUI</button>
    </div>
  </div>
</div>

<script>
(function(){{
  const initialState = {initial_upgrade_state};
  const overlay = document.getElementById('siyiUpgradeOverlay');
  const dialog = document.getElementById('siyiUpgradeDialog');
  const spinner = document.getElementById('siyiUpgradeSpinner');
  const okIcon = document.getElementById('siyiUpgradeResultOk');
  const badIcon = document.getElementById('siyiUpgradeResultBad');
  const headline = document.getElementById('siyiUpgradeHeadline');
  const version = document.getElementById('siyiUpgradeVersion');
  const percent = document.getElementById('siyiUpgradePercent');
  const bar = document.getElementById('siyiUpgradeProgressBar');
  const stage = document.getElementById('siyiUpgradeStage');
  const log = document.getElementById('siyiUpgradeLog');
  const connection = document.getElementById('siyiUpgradeConnection');
  const started = document.getElementById('siyiUpgradeStarted');
  const warning = document.getElementById('siyiUpgradeWarning');
  const actions = document.getElementById('siyiUpgradeActions');
  const detail = document.getElementById('siyiUpgradeDetail');
  const primaryAction = document.getElementById('siyiUpgradePrimaryAction');
  let lastState = initialState || {{}};
  let sawRunning = sessionStorage.getItem('siyiUpgradeSawRunning') === '1';
  let logWasNearBottom = true;

  function stateToken(s){{
    return String((s && s.updated_at) || '') + '|' + String((s && s.status) || '');
  }}

  function setLocked(locked){{
    document.body.classList.toggle('siyi-upgrade-locked', locked);
    ['header','nav','main','flightModeMenu'].forEach(function(idOrTag){{
      const el = idOrTag === 'header' || idOrTag === 'nav'
        ? document.querySelector(idOrTag)
        : document.getElementById(idOrTag) || document.querySelector(idOrTag);
      if(!el) return;
      if(locked) el.setAttribute('inert','');
      else el.removeAttribute('inert');
    }});
  }}

  function showOverlay(){{
    overlay.classList.add('visible');
    overlay.setAttribute('aria-hidden','false');
    setLocked(true);
  }}

  function hideOverlay(){{
    overlay.classList.remove('visible');
    overlay.setAttribute('aria-hidden','true');
    setLocked(false);
  }}

  function shouldShowTerminal(s){{
    if(!s || (s.status !== 'complete' && s.status !== 'failed')) return false;
    const dismissed = sessionStorage.getItem('siyiUpgradeDismissed');
    return sawRunning && dismissed !== stateToken(s);
  }}

  function applyState(s){{
    if(!s) return;
    lastState = s;
    const running = !!s.running;
    if(running){{
      sawRunning = true;
      sessionStorage.setItem('siyiUpgradeSawRunning','1');
    }}
    const terminal = shouldShowTerminal(s);
    if(!running && !terminal){{
      hideOverlay();
      return;
    }}

    showOverlay();
    const p = Math.max(0, Math.min(100, Number(s.progress || 0)));
    percent.textContent = running ? p.toFixed(1) + '%' : Math.round(p) + '%';
    bar.style.width = p + '%';
    bar.classList.toggle('running', running);
    stage.textContent = s.stage || (running ? 'Installing update' : 'Upgrade finished');
    const fromV = s.from_version || s.current || '';
    const toV = s.to_version || '';
    version.textContent = toV ? ('Updating ' + fromV + ' → ' + toV) : ('Installed version ' + fromV);
    started.textContent = s.started_at ? ('Started ' + s.started_at) : '';

    const nearBottom = (log.scrollHeight - log.scrollTop - log.clientHeight) < 80;
    log.textContent = s.log || 'Waiting for upgrade status...';
    if(logWasNearBottom || nearBottom) log.scrollTop = log.scrollHeight;
    logWasNearBottom = nearBottom;

    spinner.style.display = running ? 'block' : 'none';
    okIcon.style.display = (!running && s.status === 'complete') ? 'block' : 'none';
    badIcon.style.display = (!running && s.status === 'failed') ? 'block' : 'none';
    actions.classList.toggle('visible', !running);

    if(running){{
      headline.textContent = 'Installing';
      warning.textContent = 'Do not power off the Raspberry Pi during installation.';
    }}else if(s.status === 'complete'){{
      headline.textContent = 'Upgrade complete';
      warning.textContent = 'The new release is installed. Continue to the WebUI.';
      primaryAction.textContent = 'Go to WebUI';
    }}else{{
      headline.textContent = 'Upgrade failed';
      warning.textContent = 'The previous configuration was restored when rollback was required.';
      primaryAction.textContent = 'Reload WebUI';
    }}

    const detailParts = [];
    if(s.error) detailParts.push('Error: ' + s.error);
    if(s.technical_log) detailParts.push('Technical log: ' + s.technical_log);
    detail.textContent = detailParts.join('\\n');
    detail.style.display = 'none';
    detail.classList.remove('visible');
  }}

  async function pollUpgradeState(){{
    try{{
      const response = await fetch('/software_update_status?ts=' + Date.now(), {{cache:'no-store'}});
      if(!response.ok) throw new Error('HTTP ' + response.status);
      const state = await response.json();
      connection.textContent = 'Connected to WebUI';
      applyState(state);
    }}catch(error){{
      if(overlay.classList.contains('visible')){{
        connection.textContent = 'Reconnecting to WebUI...';
        if(lastState && lastState.running){{
          stage.textContent = lastState.stage || 'Installation continues in the background';
        }}
      }}
    }}
  }}

  window.siyiUpgradeShowStarting = function(fromVersion, toVersion){{
    sawRunning = true;
    sessionStorage.setItem('siyiUpgradeSawRunning','1');
    applyState({{
      running:true,status:'starting',progress:2,stage:'Starting upgrade',
      from_version:fromVersion || '',to_version:toVersion || '',
      started_at:'',updated_at:'',technical_log:'',error:'',
      log:'[INFO] Starting software update...'
    }});
  }};

  window.siyiUpgradeToggleDetails = function(){{
    detail.classList.toggle('visible');
    detail.style.display = detail.classList.contains('visible') ? 'block' : 'none';
  }};

  window.siyiUpgradeReload = function(){{
    sessionStorage.setItem('siyiUpgradeDismissed', stateToken(lastState));
    sessionStorage.removeItem('siyiUpgradeSawRunning');
    const destination = lastState && lastState.status === 'complete'
      ? '/'
      : '/software_update';
    window.location.replace(destination);
  }};

  document.addEventListener('keydown', function(event){{
    if(overlay.classList.contains('visible') && event.key === 'Escape'){{
      event.preventDefault();
      event.stopPropagation();
    }}
  }}, true);

  applyState(initialState);
  pollUpgradeState();
  setInterval(pollUpgradeState, 1000);
}})();
</script>


<script>
function setPiStatus(ok){{
  var d=document.getElementById('pidot');
  var l=document.getElementById('pilabel');
  if(!d || !l) return;
  if(ok){{
    d.classList.add('ok');
    l.textContent='Pi connected';
  }} else {{
    d.classList.remove('ok');
    l.textContent='Pi disconnected';
  }}
}}
async function checkPi(){{
  try{{
    const r = await fetch('/health?ts=' + Date.now(), {{cache:'no-store'}});
    setPiStatus(r.ok);
  }} catch(e){{
    setPiStatus(false);
  }}
}}
async function refreshStatusBar(){{
  const el = document.getElementById('statusbar');
  try {{
    const r = await fetch('/status_bar?ts=' + Date.now(), {{cache:'no-store'}});
    if(!r.ok) throw new Error('status fetch failed');
    let statusHtml = await r.text();

    try {{

      const prevHtml = window.__siyiLastStatusHtml || '';
      const prevHadOk = prevHtml.includes('MAVLink OK');
      const newHasDown = statusHtml.includes('MAVLink Down');

      if(prevHadOk && newHasDown){{

        window.__siyiMavDownCount =
          (window.__siyiMavDownCount || 0) + 1;

        if(window.__siyiMavDownCount < 3){{
          statusHtml = prevHtml;
        }}

      }} else {{

        window.__siyiMavDownCount = 0;
      }}

      window.__siyiLastStatusHtml = statusHtml;

    }} catch(e){{}}

    const oldModeText =
      window.__siyiLastGoodModeText || 'MODE: ...';

    el.innerHTML =
      statusHtml +
      '<span id="flightModePill" class="status-pill ok" title="Current FC flight mode">' +
      oldModeText +
      '</span>';
    refreshFlightModePill();
  }} catch(e) {{
    el.innerHTML = '<span style="font-size:13px;font-weight:bold;padding:5px 10px;border-radius:999px;color:white;background:#991b1b">Network Lost / Stale</span>';
  }}
}}



async function refreshFlightModePill(){{
  const pill=document.getElementById('flightModePill');
  if(!pill) return;
  try{{
    const r=await fetch('/flight_mode_state?ts=' + Date.now(), {{cache:'no-store'}});
    if(!r.ok) throw new Error('mode fetch failed');
    const j=await r.json();
    const mode=j.mode || 'UNKNOWN';
    pill.textContent='MODE: ' + mode;
    window.__siyiModeFetchFailCount = 0;

    if(mode !== 'UNKNOWN'){{
      window.__siyiLastGoodModeText = 'MODE: ' + mode;
      pill.textContent = window.__siyiLastGoodModeText;
      pill.className='status-pill ok';
      pill.title='Current FC flight mode';
    }}else{{
      pill.textContent = window.__siyiLastGoodModeText || 'MODE: UNKNOWN';
      pill.className='status-pill warn';
      pill.title='No FC flight mode data yet';
    }}
  }}catch(e){{

    window.__siyiModeFetchFailCount =
      (window.__siyiModeFetchFailCount || 0) + 1;

    if(window.__siyiModeFetchFailCount >= 3){{
      pill.textContent = window.__siyiLastGoodModeText || pill.textContent || 'MODE: UNKNOWN';
      pill.className='status-pill warn';
      pill.title='Flight mode update temporarily unavailable';
    }}

  }}
}}

refreshStatusBar();
setInterval(refreshStatusBar,3000);

refreshFlightModePill();
setInterval(refreshFlightModePill,100);

function closeFlightModeMenu(){{
  const m=document.getElementById('flightModeMenu');
  if(m) m.style.display='none';
}}

function openFlightModeMenu(){{
  const pill=document.getElementById('flightModePill');
  const menu=document.getElementById('flightModeMenu');
  if(!pill || !menu) return;
  const r=pill.getBoundingClientRect();
  menu.style.left=(r.left)+'px';
  menu.style.top=(r.bottom + 8)+'px';
  menu.style.display='block';
}}

async function setFlightMode(mode, el){{
  try{{
    if(window.event){{
      window.event.stopPropagation();
    }}
    const r = await fetch(
      '/set_flight_mode?mode=' + encodeURIComponent(mode),
      {{cache:'no-store'}}
    );

    const j = await r.json();

    if(!j.ok && j.error){{
      alert(j.error);
    }}

  }}catch(e){{
    console.log(e);
  }}

  closeFlightModeMenu();
}}

document.addEventListener('click', function(ev){{
  const pill=document.getElementById('flightModePill');
  const menu=document.getElementById('flightModeMenu');
  if(!pill || !menu) return;

  if(pill.contains(ev.target)){{
    ev.stopPropagation();
    if(menu.style.display==='block') closeFlightModeMenu();
    else openFlightModeMenu();
    return;
  }}

  if(!menu.contains(ev.target)) closeFlightModeMenu();
}});

checkPi();
setInterval(checkPi,3000);
</script>

<div id="flightModeMenu" style="
display:none;
position:fixed;
z-index:99999;
background:#1e293b;
border:1px solid #475569;
border-radius:10px;
padding:6px;
min-width:160px;
box-shadow:0 8px 30px rgba(0,0,0,0.45);
color:#e5e7eb;
font-size:13px;
font-weight:700;
">
<div onclick="setFlightMode('MANUAL', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">MANUAL</div>
<div onclick="setFlightMode('FBWA', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">FBWA</div>
<div onclick="setFlightMode('AUTOTUNE', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">AUTOTUNE</div>
<div onclick="setFlightMode('CRUISE', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">CRUISE</div>
<div onclick="setFlightMode('AUTO', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">AUTO</div>
<div onclick="setFlightMode('RTL', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">RTL</div>
<div onclick="setFlightMode('LOITER', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">LOITER</div>
<div onclick="setFlightMode('TAKEOFF', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">TAKEOFF</div>
<div onclick="setFlightMode('QHOVER', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">QHOVER</div>
<div onclick="setFlightMode('QLOITER', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">QLOITER</div>
<div onclick="setFlightMode('QLAND', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">QLAND</div>
<div onclick="setFlightMode('QRTL', this)" onmouseenter="this.style.background='#334155'" onmouseleave="this.style.background=''" style="padding:8px 10px;cursor:pointer;">QRTL</div>
</div>


</body></html>"""


SERVICE_LABELS = {
    "siyi-button-bridge": "Button Control Bridge",
    "siyi-video-source": "Selected Video Source",
    "siyi-video-dual": "Video UDP Forwarder",
    "mavlink-router": "MAVLink Router (FC ↔ Hosts)",
    "zerotier-one": "ZeroTier Network",
    "siyi-rec-proxy": "Camera / Recording Proxy",
    "siyi-rec-redirect": "Camera Control Redirect",
    "siyi-webui": "Web Interface"
}


CAM_SD_BASE="http://"+CAM_IP+":82"
CAM_SD_DIR="100SIYI_VID"
CAM_SD_MEDIA_TYPE=1
UNIGCS_FIFO="/tmp/siyi_record_proxy"
BYTES_PER_SECOND_2K = int(2.5 * 1024 * 1024)
SD_TOTAL_BYTES = 68719476736

def camera_sd_json(url, timeout=5):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="replace"))


def probe_resolution(url):
    try:
        out = subprocess.check_output([
            "ffprobe","-v","error",
            "-select_streams","v:0",
            "-show_entries","stream=width,height",
            "-of","csv=p=0",
            url
        ], timeout=2).decode().strip()
        if out:
            w,h = out.split(",")
            return f"{w}x{h}"
    except Exception:
        pass
    return ""

def camera_sd_files():
    count_url=f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getmediacount?media_type={CAM_SD_MEDIA_TYPE}&path={urllib.parse.quote(CAM_SD_DIR)}"
    count_data=camera_sd_json(count_url)
    count=int(count_data.get("data",{}).get("count",0))
    list_url=f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getmedialist?media_type={CAM_SD_MEDIA_TYPE}&path={urllib.parse.quote(CAM_SD_DIR)}&start=0&count={count}"
    list_data=camera_sd_json(list_url)
    return list_data.get("data",{}).get("list",[])


def camera_sd_head(url, timeout=5):
    try:
        req=urllib.request.Request(url, method="HEAD")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            size=r.headers.get("Content-Length","")
            mod=r.headers.get("Last-Modified","")
            try:
                # SIYI camera now appears to emit local wall-clock timestamps
                # while still labeling HTTP Last-Modified as GMT.
                # Do NOT timezone-convert or new recordings become +2h wrong.
                dt = parsedate_to_datetime(mod)
                mod = dt.strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                pass
            return size, mod
    except Exception:
        return "", ""

def camera_sd_local_date(mod):
    try:
        if not mod:
            return "-"
        dt = parsedate_to_datetime(mod)
        if dt.tzinfo is None:
            return mod
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return mod or "-"

def human_size(n):
    try:
        n=int(n)
        for unit in ["B","KB","MB","GB"]:
            if n < 1024:
                return f"{n:.1f} {unit}" if unit!="B" else f"{n} {unit}"
            n = n / 1024
        return f"{n:.1f} TB"
    except Exception:
        return "-"


def camera_sd_capacity():
    """
    Try to read SD card capacity from SIYI camera API.
    Returns: total_bytes, free_bytes
    If unknown, returns: None, None
    """
    candidates = [
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getsdinfo",
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getmediainfo",
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getstorageinfo",
    ]

    for url in candidates:
        try:
            with urllib.request.urlopen(url, timeout=3) as r:
                raw = r.read().decode(errors="ignore")
                data = json.loads(raw)

            def find_number(obj, keys):
                if isinstance(obj, dict):
                    for k, v in obj.items():
                        lk = str(k).lower()
                        if lk in keys:
                            try:
                                return int(v)
                            except Exception:
                                pass
                        found = find_number(v, keys)
                        if found is not None:
                            return found
                elif isinstance(obj, list):
                    for item in obj:
                        found = find_number(item, keys)
                        if found is not None:
                            return found
                return None

            total = find_number(data, {"total", "totalsize", "total_size", "capacity", "sd_total", "sdtotal"})
            free = find_number(data, {"free", "freesize", "free_size", "available", "avail", "sd_free", "sdfree"})

            if total and free is not None:
                return total, free

        except Exception:
            pass

    return None, None


def camera_sd_page():
    try:
        files=camera_sd_files()

        # SORT: newest -> oldest by SIYI filename
        try:
            files = sorted(files, key=lambda x: x.get("name",""), reverse=True)
        except Exception:
            pass

        # Fast metadata fetch: get file size/date in parallel instead of slow sequential HEAD calls
        meta = {}
        try:
            from concurrent.futures import ThreadPoolExecutor, as_completed
            urls = [x.get("url","") for x in files if x.get("url","")]
            with ThreadPoolExecutor(max_workers=16) as ex:
                futs = {ex.submit(camera_sd_head, u, 1.5): u for u in urls}
                for fut in as_completed(futs):
                    u = futs[fut]
                    try:
                        meta[u] = fut.result()
                    except Exception:
                        meta[u] = ("", "")
        except Exception:
            meta = {}

        rows=""
        total_used = 0
        for idx, f in enumerate(files):
            name=f.get("name","")
            url=f.get("url","")
            size,lastmod = meta.get(url, ("",""))

            res = ""
            label = name

            if size:
                try:
                    total_used += int(size)
                except Exception:
                    pass
            rows+=f"""<tr>
<td><input style='pointer-events:auto;' type="checkbox" class="sdcheck" name="urls" value="{esc(url)}"></td>
<td><b>{esc(label)}</b><br>
<span class='small'>{esc(url)}</span> <span class="sd-res small" data-url="{esc(url)}"></span><br>
<a href="{esc(url)}" target="_blank">Stream / Open</a>
&nbsp;|&nbsp;
<a href="/camera_sd_download?url={urllib.parse.quote(url)}">Download</a>
&nbsp;|&nbsp;
<a class="danger" href="/camera_sd_delete?url={urllib.parse.quote(url)}" onclick="return confirm('Delete this file from camera SD card?');">Delete</a>
</td>
<td>{esc(human_size(size))}</td>
<td>{esc(camera_sd_local_date(lastmod))}</td>
</tr>"""
        total_cap, free_cap = camera_sd_capacity()
        used_str = human_size(total_used)

        if SD_TOTAL_BYTES:
            total_str = human_size(SD_TOTAL_BYTES)
            free_bytes = SD_TOTAL_BYTES - total_used
            free_bytes = max(0, free_bytes)
            free_str = human_size(free_bytes)
            percent = int((total_used / SD_TOTAL_BYTES) * 100)

            # Estimate recording time left (2K)
            try:
                seconds_left = int(free_bytes / BYTES_PER_SECOND_2K)
                hours = seconds_left // 3600
                minutes = (seconds_left % 3600) // 60
                time_str = f"{hours}h {minutes:02d}m"
            except:
                time_str = "unknown"

            sd_summary = f"Used: {used_str} / {total_str} ({percent}%) | Free: {free_str} | Approx {time_str} 2K recording"
        else:
            sd_summary = f"Used: {used_str}"

        return f"""<h1>Camera SD Card</h1>
<span style="font-size:12px;opacity:.65;margin-left:10px;">v{VERSION}</span>
<div class='card' ><h2>Files on Camera SD</h2>
<p class='small'>Directory: {esc(CAM_SD_DIR)} | Count: {len(files)}<br>{esc(sd_summary)}</p>
<form id="sdform" method="post">
<div style="margin-bottom:10px;display:flex;gap:8px;flex-wrap:wrap;">
<button style='pointer-events:auto;' type="button" onclick="document.querySelectorAll('.sdcheck').forEach(c=>c.checked=true)">Select all</button>
<button style='pointer-events:auto;' type="button" onclick="document.querySelectorAll('.sdcheck').forEach(c=>c.checked=false)">Clear selection</button>
<button style='pointer-events:auto;' type="submit" formaction="/camera_sd_zip">Download selected as ZIP</button>
<button style='pointer-events:auto;' class="danger" type="submit" formaction="/camera_sd_delete_selected" onclick="return confirm('Delete all selected files from camera SD card?');">Delete selected</button>
</div>
<table><tr><th>Select</th><th>File</th><th>Size</th><th>Camera Date</th></tr>{rows}</table>
</form>

<script>
(function(){{
  async function loadSdRes(){{
    const spans = Array.from(document.querySelectorAll(".sd-res[data-url]"));
    for (const span of spans){{
      const url = span.dataset.url;
      if (!url) {{
        span.textContent = "-";
        continue;
      }}
      span.textContent = "...";
      try {{
        const r = await fetch("/camera_sd_res?url=" + encodeURIComponent(url), {{cache:"no-store"}});
        const j = await r.json();
        span.textContent = j.res || "-";
      }} catch(e) {{
        span.textContent = "ERR";
      }}
      await new Promise(resolve => setTimeout(resolve, 80));
    }}
  }}

  if (document.readyState === "loading") {{
    document.addEventListener("DOMContentLoaded", function(){{ setTimeout(loadSdRes, 200); }});
  }} else {{
    setTimeout(loadSdRes, 200);
  }}
}})();
</script>

</div>"""
    except Exception as e:
        return f"<h1>Camera SD Card</h1><div class='card'><h2 class='bad'>Could not read camera SD</h2><pre>{esc(str(e))}</pre></div>"


def camera_sd_delete_many(urls):
    data=json.dumps({"media_type":CAM_SD_MEDIA_TYPE,"paths":urls}).encode()
    req=urllib.request.Request(
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/deletemedialist",
        data=data,
        headers={"Content-Type":"application/json","Accept":"application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read().decode("utf-8", errors="replace")

def camera_sd_delete(url):
    data=json.dumps({"media_type":CAM_SD_MEDIA_TYPE,"paths":[url]}).encode()
    req=urllib.request.Request(
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/deletemedialist",
        data=data,
        headers={"Content-Type":"application/json","Accept":"application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=8) as r:
        return r.read().decode("utf-8", errors="replace")


def unigcs_controls_page():
    return """<div class="cam-full"><h1>Camera Controls</h1>\n




<style>/* CAMERA_CONTROLS_COMPACT_SAFE_V3 */
.cam-grid{
  display:grid;
  grid-template-columns: repeat(2, minmax(280px, 1fr));
  gap:12px 14px;
  width:100%;
  max-width:none;
  margin:0;
}
.cam-full{
  width:100%;
  max-width:none;
  margin:0 0 10px 0;
}
.card{
  max-width:none;
  width:100%;
  margin:0;
  padding:10px 12px;
  box-sizing:border-box;
}
.card h2{
  margin:0 0 8px 0;
  font-size:18px;
}
.card form{margin:6px 0;}
.gimbal-row{
  display:flex;
  gap:20px;
  align-items:center;
  flex-wrap:wrap;
}
.gimbal-row label{
  display:flex;
  align-items:center;
  gap:6px;
  white-space:nowrap;
}
.cam-grid .card:nth-child(5) form{
  display:inline-block;
  margin-right:4px;
  white-space:nowrap;
}
.cam-grid .card:nth-child(5) button{
  margin-left:0;
  margin-right:6px;
}
.card button{margin:3px 4px 3px 0;padding:6px 10px;}
.card input[type=range]{width:calc(100% - 55px);max-width:none;}
.image-row{
  display:grid;
  grid-template-columns:90px 1fr 38px;
  gap:8px;
  align-items:center;
  margin:4px 0;
}
.image-row label{
  white-space:nowrap;
  color:#cbd5e1;
}
.image-row input[type=range]{
  width:100%;
  max-width:none;
}

.exposure-row{
  display:grid;
  grid-template-columns:110px 1fr;
  gap:8px;
  align-items:center;
  margin:6px 0;
}
.exposure-row label{
  white-space:nowrap;
  color:#cbd5e1;
}
.exposure-row select{
  width:100%;
}

.image-row output{
  text-align:right;
  color:#e5e7eb;
}

.card output{display:inline-block;width:38px;text-align:right;}
.cam-grid .card:first-child button[type=submit]{display:none;}
@media(max-width:900px){
  .cam-grid{grid-template-columns:1fr;}
}
</style>





<script>
function sendSlider(el){
  const data = new URLSearchParams();
  data.append(el.name, el.value);

  fetch('/unigcs_control', {method:'POST', body:data})
    .then(()=>{ document.getElementById('unigcs_status').innerText='Sent: '+el.value; })
    .catch(()=>{ document.getElementById('unigcs_status').innerText='Failed'; });
}

function sendCmd(cmd){
  const data = new URLSearchParams();
  data.append('cmd', cmd);
  fetch('/unigcs_control', {method:'POST', body:data})
    .then(()=>{ document.getElementById('unigcs_status').innerText='Sent: '+cmd; })
    .catch(()=>{ document.getElementById('unigcs_status').innerText='Failed: '+cmd; });
  return false;
}

function sendForm(form){
  const data = new URLSearchParams(new FormData(form));
  fetch('/unigcs_control', {method:'POST', body:data})
    .then(()=>{ document.getElementById('unigcs_status').innerText='Sent'; })
    .catch(e=>{ document.getElementById('unigcs_status').innerText='Failed'; });
  return false;
}

// UI_ACTIVE_STATE_TRACKER_V1
(function(){
  const groups = {
    stream_720p: "stream_res",
    stream_1080p: "stream_res",
    rec_720p: "rec_res",
    rec_1080p: "rec_res",
    rec_2k: "rec_res",
    rec_4k: "rec_res",
    autorecord_on: "auto_rec",
    autorecord_off: "auto_rec",
    gimbal_lock: "gimbal_mode",
    gimbal_follow: "gimbal_mode",
    gimbal_fpv: "gimbal_mode"
  };

  function restoreRadio(group){
    const cmd = localStorage.getItem("siyi_state_" + group);
    if(!cmd) return;
    document.querySelectorAll('input[type="radio"][name="' + group + '"]').forEach(function(r){
      const onclick = r.getAttribute("onclick") || "";
      if(onclick.indexOf(cmd) >= 0) r.checked = true;
    });
  }

  const oldSendCmd = window.sendCmd;
  window.sendCmd = function(cmd){
    const group = groups[cmd];
    if(group) localStorage.setItem("siyi_state_" + group, cmd);
    return oldSendCmd(cmd);
  };

  function restoreValues(){
    ["brightness","contrast","saturation"].forEach(function(name){
      const val = localStorage.getItem("siyi_value_" + name);
      if(val === null) return;
      const el = document.querySelector('input[type="range"][name="' + name + '"]');
      if(el){
        el.value = val;
        const out = el.parentElement ? el.parentElement.querySelector("output") : null;
        if(out) out.value = val;
      }
    });

    ["ev","ss"].forEach(function(name){
      const val = localStorage.getItem("siyi_value_" + name);
      if(val === null) return;
      const el = document.querySelector('select[name="' + name + '"]');
      if(el) el.value = val;
    });
  }

  const oldSendSlider = window.sendSlider;
  window.sendSlider = function(el){
    if(el && el.name){
      localStorage.setItem("siyi_value_" + el.name, el.value);
    }
    return oldSendSlider(el);
  };

  const oldSendForm = window.sendForm;
  window.sendForm = function(form){
    if(form){
      const field = form.querySelector("select[name], input[name]");
      if(field && field.name){
        localStorage.setItem("siyi_value_" + field.name, field.value);
      }
    }
    return oldSendForm(form);
  };

  document.addEventListener("DOMContentLoaded", function(){
    restoreRadio("stream_res");
    restoreRadio("rec_res");
    restoreRadio("auto_rec");
    restoreRadio("gimbal_mode");
    restoreValues();
  });
})();


// PI_SHARED_STATE_SIDECAR_V1
(function(){
  const STATE_URL = "http://" + window.location.hostname + ":8081/ui_state";

  const groups = {
    stream_720p: "stream_res",
    stream_1080p: "stream_res",
    rec_720p: "rec_res",
    rec_1080p: "rec_res",
    rec_2k: "rec_res",
    rec_4k: "rec_res",
    autorecord_on: "auto_rec",
    autorecord_off: "auto_rec",
    gimbal_lock: "gimbal_mode",
    gimbal_follow: "gimbal_mode",
    gimbal_fpv: "gimbal_mode"
  };

  function postState(obj){
    fetch(STATE_URL, {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(obj)
    }).catch(function(){});
  }

  function applyState(st){
    if(!st) return;

    ["stream_res","rec_res","auto_rec","gimbal_mode"].forEach(function(group){
      const cmd = st[group];
      if(!cmd) return;
      document.querySelectorAll('input[type="radio"][name="' + group + '"]').forEach(function(r){
        const onclick = r.getAttribute("onclick") || "";
        if(onclick.indexOf(cmd) >= 0) r.checked = true;
      });
    });

    ["brightness","contrast","saturation"].forEach(function(name){
      const val = st[name];
      if(val === undefined || val === null) return;
      const el = document.querySelector('input[type="range"][name="' + name + '"]');
      if(el){
        el.value = val;
        const out = el.parentElement ? el.parentElement.querySelector("output") : null;
        if(out) out.value = val;
      }
    });

    ["ev","ss"].forEach(function(name){
      const val = st[name];
      if(val === undefined || val === null) return;
      const el = document.querySelector('select[name="' + name + '"]');
      if(el) el.value = val;
    });
  }

  const prevSendCmd = window.sendCmd;
  window.sendCmd = function(cmd){
    const group = groups[cmd];
    if(group){
      const obj = {};
      obj[group] = cmd;
      postState(obj);
    }
    return prevSendCmd(cmd);
  };

  const prevSendSlider = window.sendSlider;
  window.sendSlider = function(el){
    if(el && el.name){
      const obj = {};
      obj[el.name] = el.value;
      postState(obj);
    }
    return prevSendSlider(el);
  };

  const prevSendForm = window.sendForm;
  window.sendForm = function(form){
    if(form){
      const field = form.querySelector("select[name], input[name]");
      if(field && field.name){
        const obj = {};
        obj[field.name] = field.value;
        postState(obj);
      }
    }
    return prevSendForm(form);
  };

  document.addEventListener("DOMContentLoaded", function(){
    setTimeout(function(){
      fetch(STATE_URL, {cache:"no-store"})
        .then(function(r){ return r.json(); })
        .then(applyState)
        .catch(function(){});
    }, 250);
  });
})();

</script>
<div id="unigcs_status" class="small">Ready</div></div>
<div class="cam-grid">
<div class='card'>
<h2>Image</h2>

<form class="image-row" onsubmit="return false;">
<label>Brightness</label>
<input style='pointer-events:auto;' type="range" onchange="sendSlider(this)" name="brightness" min="0" max="100" value="50" oninput="bval.value=this.value">
<output id="bval">50</output>
</form>

<form class="image-row" onsubmit="return false;">
<label>Contrast</label>
<input style='pointer-events:auto;' type="range" onchange="sendSlider(this)" name="contrast" min="0" max="100" value="50" oninput="cval.value=this.value">
<output id="cval">50</output>
</form>

<form class="image-row" onsubmit="return false;">
<label>Saturation</label>
<input style='pointer-events:auto;' type="range" onchange="sendSlider(this)" name="saturation" min="0" max="100" value="50" oninput="sval.value=this.value">
<output id="sval">50</output>
</form>
</div>

<div class='card'>
<h2>Exposure <span style="color:#9ca3af;font-size:11px;font-style:italic;">(currently unsupported)</span></h2>

<form class="exposure-row" onsubmit="return false;">
<label>EV</label>
<select style='pointer-events:auto;' name="ev" onchange="sendForm(this.form)">
<option value="0">Auto</option>
<option value="1">-2.0</option>
<option value="2">-1.5</option>
<option value="3">-1.0</option>
<option value="4">-0.5</option>
<option value="5">0</option>
<option value="6">+0.5</option>
<option value="7">+1.0</option>
<option value="8">+1.5</option>
<option value="9">+2.0</option>
</select>
</form>

<form class="exposure-row" onsubmit="return false;">
<label>Shutter Speed</label>
<select style='pointer-events:auto;' name="ss" onchange="sendForm(this.form)">
<option value="0">Auto</option>
<option value="1">1/30</option>
<option value="2">1/60</option>
<option value="3">1/120</option>
<option value="4">1/250</option>
<option value="5">1/500</option>
<option value="6">1/1000</option>
<option value="7">1/2000</option>
</select>
</form>
</div>

<div class='card'>
<h2>Stream Resolution</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">720p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="stream_res" onclick="sendCmd('stream_720p')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">1080p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="stream_res" onclick="sendCmd('stream_1080p')"></span>
</form>
</div>

<div class='card'>
<h2>Recording Resolution</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">720p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_720p')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">1080p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_1080p')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">2K <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_2k')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">4K <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_4k')"></span>
</form>
</div>

<div class='card'>
<h2>Gimbal Mode</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">Lock <input style='pointer-events:auto;' style="width:auto;" type="radio" name="gimbal_mode" onclick="sendCmd('gimbal_lock')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">Follow <input style='pointer-events:auto;' style="width:auto;" type="radio" name="gimbal_mode" onclick="sendCmd('gimbal_follow')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">FPV <input style='pointer-events:auto;' style="width:auto;" type="radio" name="gimbal_mode" onclick="sendCmd('gimbal_fpv')"></span>
</form>
</div>

<div class='card'>
<h2>Auto Recording</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">On <input style='pointer-events:auto;' style="width:auto;" type="radio" name="auto_rec" onclick="sendCmd('autorecord_on')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">Off <input style='pointer-events:auto;' style="width:auto;" type="radio" name="auto_rec" onclick="sendCmd('autorecord_off')"></span>
</form>
</div>

</div>
<p class="small cam-full"></p>
"""

def send_unigcs_fifo(command):
    command = (command or "").strip()
    if not command:
        return "No command"

    allowed_prefixes = ("brightness:", "saturation:", "contrast:", "ev:", "ss:")
    allowed_exact = {
        "stream_720p", "stream_1080p",
        "rec_720p", "rec_1080p", "rec_2k", "rec_4k",
        "gimbal_lock", "gimbal_follow", "gimbal_fpv",
        "autorecord_on", "autorecord_off",
        "start", "stop",
    }

    commands = [c.strip() for c in command.split(";") if c.strip()]

    for c in commands:
        if c not in allowed_exact and not c.startswith(allowed_prefixes):
            return "Rejected command: " + c

    import os, errno, time

    try:
        # retry open FIFO safely
        fd = None
        for _ in range(20):
            try:
                fd = os.open(UNIGCS_FIFO, os.O_WRONLY | os.O_NONBLOCK)
                break
            except OSError:
                time.sleep(0.05)
        if fd is None:
            return "FIFO not ready"

        try:
            for c in commands:
                os.write(fd, (c + "\n").encode())
                time.sleep(0.05)
        finally:
            os.close(fd)
    except OSError as e:
        if e.errno == errno.ENXIO:
            return "FIFO has no active reader / SIYI proxy not ready"
        return "FIFO write failed: " + str(e)

    return "Sent UniGCS control: " + command



# ENDPOINTS_SHARED_CONFIG_V1
def load_endpoints():
    defaults = [
        {"name":"Host 1","ip":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","video":True,"mavlink":True},
        {"name":"Host 2","ip":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","video":True,"mavlink":True},
    ]
    try:
        if os.path.exists(ENDPOINTS_FILE):
            data=json.loads(read_file(ENDPOINTS_FILE))
            if isinstance(data,list) and data:
                return data
    except Exception:
        pass
    return defaults

def save_endpoints_from_params(data):
    names=data.get("name",[])
    ips=data.get("ip",[])
    delete_on=set(data.get("delete_host",[]))
    endpoints=[]
    for i,ip in enumerate(ips):
        if str(i) in delete_on:
            continue
        ip=(ip or "").strip()
        if not ip:
            continue
        name=(names[i].strip() if i < len(names) and names[i].strip() else f"Host {i+1}")
        endpoints.append({
            "name": name,
            "ip": ip,
            "video": False,
            "mavlink": True,
        })
    if not endpoints:
        try:
            existing = load_endpoints()
            if existing:
                endpoints = existing
        except Exception:
            pass

    if not endpoints:
        endpoints=[
            {"name":"Host 1","ip":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","video":True,"mavlink":True},
            {"name":"Host 2","ip":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","video":True,"mavlink":True},
        ]
    write_file(ENDPOINTS_FILE, json.dumps(endpoints, indent=2))
    apply_siyi_endpoints_now()
    apply_siyi_endpoints_now()


def host_ping_status(ip):
    if not ip:
        return ("bad", "No IP")

    out=sh(f"ping -c 1 -W 1 {ip} 2>/dev/null || true")

    if "1 received" in out or "1 packets received" in out:
        m=re.search(r"time=([0-9.]+)", out)
        return ("ok", "OK" + (f" {m.group(1)} ms" if m else ""))

    return ("bad", "No ping")

def host_mavlink_status(ip):
    if not ip:
        return ("bad", "No IP")

    conf=read_file(MAVCONF)
    configured=(ip in conf)

    if not configured:
        return ("bad", "Not configured")

    # Real MAVLink activity is tracked by background tcpdump monitor.
    # UI should not run tcpdump during page rendering.
    try:
        data=json.loads(read_file("/tmp/siyi_mavlink_host_activity.json") or "{}")
        item=data.get(ip,{})
        last=float(item.get("last_seen",0))
        age=time.time()-last
        if last > 0 and age < 15:
            return ("ok", "ACTIVE")
        if last > 0:
            return ("warn", "STALE")
    except Exception:
        pass

    return ("ok", "MAVLink endpoint configured")
def host_video_status(ip):
    if not ip:
        return ("bad", "No IP")

    # Current architecture: QGC pulls RTSP from MediaMTX on :8554.
    # A host is video-active if it has an established TCP session to local :8554
    # or recent MediaMTX logs show that host reading main.264.
    ss_out=sh("ss -tunap 2>/dev/null | grep ':8554' || true")
    logs=sh("journalctl -u mediamtx.service -n 160 --no-pager 2>/dev/null || true")

    active_tcp=(ip in ss_out and ":8554" in ss_out and "ESTAB" in ss_out)
    active_log=(ip in logs and ("is reading from path" in logs or "session" in logs))

    if active_tcp:
        return ("ok", "ACTIVE")

    if active_log:
        return ("warn", "RECENT")

    mediamtx=sh("systemctl is-active mediamtx.service 2>/dev/null || true").strip()
    if mediamtx=="active":
        return ("warn", "NO CLIENT")

    return ("bad", "OFFLINE")


def host_qgc_status(ip):
    if not ip:
        return ("bad", "No IP")

    ss_out=sh("ss -tunap 2>/dev/null || true")
    medialog=sh("journalctl -u mediamtx.service -n 180 --no-pager 2>/dev/null || true")

    # Strong QGC confirmation signals:
    # 1) Host has active RTSP TCP session to MediaMTX :8554.
    # 2) Host has REC/control TCP session to :37256.
    # 3) Recent MediaMTX log from host reading stream.
    active_rtsp=(ip in ss_out and ":8554" in ss_out and "ESTAB" in ss_out)
    active_control=(ip in ss_out and ":37256" in ss_out and "ESTAB" in ss_out)
    recent_rtsp=(ip in medialog and ("is reading from path" in medialog or "created by" in medialog))

    if active_rtsp and active_control:
        return ("ok", "VIDEO + CTRL")

    if active_rtsp:
        return ("ok", "VIDEO")

    if active_control:
        return ("ok", "CTRL")

    if recent_rtsp:
        return ("warn", "RECENT")

    return ("warn", "NOT CONFIRMED")


def host_operational_table():
    eps=load_endpoints()

    if not eps:
        return "<p class='small'>No endpoint hosts configured.</p>"

    rows=""

    for e in eps:
        name=e.get("name","")
        ip=e.get("ip","")

        ping_cls,ping_txt=host_ping_status(ip)

        if e.get("mavlink",True):
            mav_cls,mav_txt=host_mavlink_status(ip)
        else:
            mav_cls,mav_txt=("warn","Disabled")

        vid_cls,vid_txt=host_video_status(ip)
        qgc_cls,qgc_txt=host_qgc_status(ip)

        # If host is unreachable on network level,
        # suppress stale/recent subsystem activity states.
        if ping_cls == "bad":
            if mav_txt != "Disabled":
                mav_cls,mav_txt=("bad","HOST OFFLINE")
            vid_cls,vid_txt=("bad","HOST OFFLINE")
            qgc_cls,qgc_txt=("bad","HOST OFFLINE")

        rows += f"""
        <tr>
          <td><b>{esc(name)}</b><br><span class='small'>{esc(ip)}</span></td>
          <td><span class='status-pill {ping_cls}'>{esc(ping_txt)}</span></td>
          <td><span class='status-pill {mav_cls}'>{esc(mav_txt)}</span></td>
          <td><span class='status-pill {vid_cls}'>{esc(vid_txt)}</span></td>
          <td><span class='status-pill {qgc_cls}'>{esc(qgc_txt)}</span></td>
        </tr>
        """

    return f"""
    <style>
    .hoststatus table {{
      width:100%;
      table-layout:auto;
    }}

    .hoststatus td,
    .hoststatus th {{
      vertical-align:middle;
      white-space:nowrap;
    }}

    .hoststatus .status-pill {{
      display:inline-block;
      padding:5px 10px;
      border-radius:999px;
      font-size:12px;
      font-weight:700;
      line-height:1.0;
      white-space:nowrap;
    }}

    .hoststatus th:nth-child(2),
    .hoststatus td:nth-child(2),
    .hoststatus th:nth-child(3),
    .hoststatus td:nth-child(3),
    .hoststatus th:nth-child(4),
    .hoststatus td:nth-child(4) {{
      width:120px;
    }}

    .hoststatus th:nth-child(5),
    .hoststatus td:nth-child(5) {{
      width:150px;
    }}
    </style>

    <div class='hoststatus'>
    <table>
      <tr>
        <th>Host</th>
        <th>Network</th>
        <th>MAVLink</th>
        <th>Video</th>
        <th>QGC</th>
      </tr>
      {rows}
    </table>

    <p class='small'>
    Network = ICMP ping reachability only.<br>
    MAVLink sent = Pi has recently sent UDP telemetry packets to this host on port 14550.<br>
    Video = active/recent RTSP client session from this host via MediaMTX.<br>
    QGC = confirmed only by host-side RTSP/control activity back to the Pi.
    </p></div>
    """


def endpoints_summary(kind):
    eps=load_endpoints()
    rows=""
    for e in eps:
        enabled=e.get(kind,False)
        rows+=f"<tr><td>{esc(e.get('name',''))}</td><td>{esc(e.get('ip',''))}</td><td>{'Yes' if enabled else 'No'}</td></tr>"
    return f"<table><tr><th>Host</th><th>IP</th><th>{kind.capitalize()}</th></tr>{rows}</table><p class='small'>Edit hosts on the Endpoints page.</p>"

def endpoints_page():
    eps=load_endpoints()
    rows=""
    for i,e in enumerate(eps):
        rows+=f"""
        <tr>
          <td><input style='pointer-events:auto;' name='name' value='{esc(e.get("name",f"Host {i+1}"))}'></td>
          <td><input style='pointer-events:auto;' name='ip' value='{esc(e.get("ip",""))}'></td>
          <td style='text-align:center'><input style='pointer-events:auto;width:auto;' type='checkbox' name='delete_host' value='{i}'></td>
        </tr>"""
    rows += """
        <tr>
          <td><input style='pointer-events:auto;' name='name' placeholder='Host 3'></td>
          <td><input style='pointer-events:auto;' name='ip' placeholder='192.168.191.xxx'></td>
          <td></td>
        </tr>"""
    return f"""<h1>MAVLink Hosts</h1>

    <div class='card'>
    <h2>Host Operational Status</h2>
    {host_operational_table()}
    </div>

    <div class='card'>
    <div style='display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;'>
      <p class='small' style='margin:0;'>Saved hosts are automatically used as MAVLink destinations.</p>

      <button id='matrixOpenBtn'
              type='button'
              style='pointer-events:auto;background:#1d4ed8;color:white;border:0;border-radius:10px;padding:8px 14px;font-weight:700;cursor:pointer;'>
        Host status reference
      </button>
    </div>

<div id='matrixFloat'
     class='card'
     style='display:none;position:fixed;right:40px;top:90px;width:900px;min-width:340px;max-width:92vw;max-height:88vh;overflow:auto;z-index:50;box-shadow:0 12px 30px rgba(0,0,0,.45);'>

  <h2 id='matrixDragHandle'
      style='cursor:move;margin-top:0;display:flex;justify-content:space-between;align-items:center;gap:12px;'>

    <span>Host status reference</span>

    <button id='matrixCloseBtn'
            type='button'
            style='pointer-events:auto;background:#334155;color:#e5e7eb;border:0;border-radius:999px;margin:0;padding:2px 8px;font-size:14px;line-height:1.3;cursor:pointer;'>
      ×
    </button>
  </h2>

  <img src='/static/mavlink_qgc_matrix.png'
       style='width:100%;height:auto;border-radius:12px;display:block;'>

  <div id='matrixResizeHandle'
       style='position:absolute;left:0;bottom:0;width:26px;height:26px;cursor:nesw-resize;'></div>
</div>

<script>
(function(){{
  const openBtn=document.getElementById('matrixOpenBtn');
  const box=document.getElementById('matrixFloat');
  const handle=document.getElementById('matrixDragHandle');
  const closeBtn=document.getElementById('matrixCloseBtn');
  const resize=document.getElementById('matrixResizeHandle');

  if(!openBtn || !box || !handle || !resize) return;

  openBtn.addEventListener('click', function(){{
    box.style.display='block';
  }});

  if(closeBtn){{
    closeBtn.addEventListener('mousedown', function(e){{
      e.stopPropagation();
    }});

    closeBtn.addEventListener('click', function(e){{
      e.preventDefault();
      e.stopPropagation();
      box.style.display='none';
    }});
  }}

  let dragging=false;
  let startX=0;
  let startY=0;
  let startLeft=0;
  let startTop=0;

  handle.addEventListener('mousedown', function(e){{
    dragging=true;

    const r=box.getBoundingClientRect();

    startX=e.clientX;
    startY=e.clientY;
    startLeft=r.left;
    startTop=r.top;

    box.style.left=r.left+'px';
    box.style.top=r.top+'px';
    box.style.right='auto';

    e.preventDefault();
  }});

  document.addEventListener('mousemove', function(e){{
    if(!dragging) return;

    box.style.left=(startLeft + (e.clientX-startX))+'px';
    box.style.top=(startTop + (e.clientY-startY))+'px';
  }});

  document.addEventListener('mouseup', function(){{
    dragging=false;
    resizing=false;
  }});

  let resizing=false;
  let startWidth=0;
  let startHeight=0;
  let resizeStartX=0;
  let resizeStartY=0;
  let resizeStartLeft=0;

  resize.addEventListener('mousedown', function(e){{
    resizing=true;

    const r=box.getBoundingClientRect();

    startWidth=r.width;
    startHeight=r.height;
    resizeStartX=e.clientX;
    resizeStartY=e.clientY;
    resizeStartLeft=r.left;

    e.preventDefault();
    e.stopPropagation();
  }});

  document.addEventListener('mousemove', function(e){{
    if(!resizing) return;

    let rightEdge=resizeStartLeft + startWidth;

    let newWidth=rightEdge - e.clientX;
    let newHeight=startHeight + (e.clientY-resizeStartY);

    newWidth=Math.max(340,newWidth);
    newHeight=Math.max(260,newHeight);

    box.style.width=newWidth+'px';
    box.style.height=newHeight+'px';
  }});
}})();
</script>


    <form method='post' action='/save_endpoints'>
    <table><tr><th>Preset</th><th>IP</th><th>Delete</th></tr>{rows}</table>
    <button style='pointer-events:auto;'>Save endpoints</button>
    </form>
    </div>"""

def make_video_service_from_endpoints(rtsp, protocols, latency, port):
    eps=[e for e in load_endpoints() if e.get("video",False) and e.get("ip")]
    if not eps:
        eps=[{"ip":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+""},{"ip":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+""}]
    branches=" ".join([f"t. ! queue ! udpsink host={e['ip']} port={port}" for e in eps])
    return f"""[Unit]
Description=SIYI RTSP to UDP forwarder
After=network-online.target zerotier-one.service NetworkManager.service
Wants=network-online.target zerotier-one.service

[Service]
Type=simple
Restart=always
RestartSec=3
ExecStart=/usr/bin/gst-launch-1.0 -e rtspsrc location={rtsp} latency={latency} protocols={protocols} ! rtph265depay ! h265parse ! rtph265pay config-interval=1 pt=96 ! tee name=t {branches}
ExecStop=/usr/bin/pkill -f "gst-launch-1.0"
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
"""

def make_mav_conf_from_endpoints(device, baud, port, tcp):
    eps=[e for e in load_endpoints() if e.get("ip")]

    lines=[f"""[UartEndpoint fc]
Device={device}
Baud={baud}

[UdpEndpoint webui_status_monitor]
Mode=Normal
Address=127.0.0.1
Port=14601

[UdpEndpoint button_safety]
Mode=Normal
Address=127.0.0.1
Port=14600
"""]

    for i,e in enumerate(eps,1):
        lines.append(f"""
[UdpEndpoint host{i}]
Mode=Normal
Address={e['ip']}
Port={port}
""")

    lines.append(f"""
[TcpEndpoint server]
Mode=Server
Address=0.0.0.0
Port={tcp}
""")

    return "".join(lines)

# ENDPOINTS_SHARED_CONFIG_V1_END



def apply_siyi_endpoints_now():
    try:
        subprocess.run(["/home/pi/apply_siyi_endpoints.sh"], timeout=10, check=False)
    except Exception as e:
        print("apply_siyi_endpoints failed:", e)


def fc_parameter_export_handler(self):
    import json, time, subprocess
    from pathlib import Path

    cache_path = Path("/etc/siyi/param_metadata_cache.json")
    fresh_snapshot_path = Path("/tmp/siyi_param_cache.json")
    refresh_script = "/home/pi/siyi_param_full_cache.py"
    log_path = Path("/tmp/fc_parameter_export.log")

    try:
        with open(log_path, "w") as log:
            rc = subprocess.run(
                ["/home/pi/siyi-bridge-venv/bin/python", refresh_script],
                stdout=log,
                stderr=subprocess.STDOUT,
                timeout=180
            ).returncode

        if rc != 0:
            try:
                tail = log_path.read_text(errors="ignore")[-1500:]
            except Exception:
                tail = "unknown error"
            body = ("FC Parameter Export failed: could not synchronize parameters from FC.\n\n" + tail).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        if not cache_path.exists():
            body = b"FC Parameter Export failed: parameter cache was not created."
            self.send_response(500)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        # Truth source for export is the fresh full FC snapshot just collected by refresh_script.
        # The WebUI/cache is not the authority for export values.
        data = json.loads(fresh_snapshot_path.read_text())
        params = data.get("params", {})
        expected = int(data.get("expected_count", 0) or 0)
        received = int(data.get("received_count", 0) or 0)

        if not params or expected <= 0 or received <= 0 or expected != received or len(params) != received:
            body = (
                "FC Parameter Export refused: fresh FC parameter snapshot is incomplete.\n"
                f"expected_count={expected}, received_count={received}, params={len(params)}\n"
            ).encode("utf-8")
            self.send_response(500)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        def fmt_value(v):
            try:
                f = float(v)
                if f.is_integer():
                    return str(int(f))
                return ("%.10g" % f)
            except Exception:
                return str(v)

        lines = [
            "# Onboard parameters for Vehicle 1",
            "#",
            "# Stack: ArduPilot",
            "# Vehicle: Fixed wing aircraft",
            "# Version: 4.5.7",
            "# Git Revision: exported-by-siyi-pi",
            "#",
            "# Vehicle-Id Component-Id Name Value Type",
        ]

        def sort_key(item):
            name, info = item
            try:
                return (int(info.get("index", 999999)), name)
            except Exception:
                return (999999, name)

        # Export values directly from the fresh FC snapshot.
        # No WebUI state, no stale metadata value cache, no per-param /get loop.
        for name, info in sorted(params.items(), key=sort_key):
            val = fmt_value(info.get("value", 0))
            ptype = int(info.get("type", 9) or 9)
            lines.append(f"1\t1\t{name}\t{val}\t{ptype}")

        body = ("\n".join(lines) + "\n").encode("utf-8")
        filename = "fc_parameters_" + time.strftime("%Y%m%d_%H%M%S") + ".params"

        self.send_response(200)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Set-Cookie", "fc_export_done=1; Path=/; Max-Age=20; SameSite=Lax")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    except subprocess.TimeoutExpired:
        body = b"FC Parameter Export failed: FC parameter synchronization timed out."
        self.send_response(504)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    except Exception as e:
        body = ("FC Parameter Export failed: " + repr(e)).encode("utf-8")
        self.send_response(500)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class H(BaseHTTPRequestHandler):

    def do_POST(self):
        # CPU_TEMP_VOICE_PAGE_V1
        if self.path.startswith("/cpu_temp_voice_save"):
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                raw = self.rfile.read(length).decode()
                data = dict(urllib.parse.parse_qsl(raw))

                enabled = data.get("enabled", "") == "1"
                try:
                    interval = float(str(data.get("interval", "5")).replace(",", "."))
                except Exception:
                    interval = 5

                if interval <= 0:
                    enabled = False
                    interval = 5

                if enabled and interval < 0.25:
                    raise ValueError("Minimum enabled interval is 0.25 minutes")

                cfg = {"enabled": enabled, "interval_minutes": interval}
                cfg_path = "/etc/siyi/cpu_temp_voice.json"

                print("[CPU_TEMP_SAVE] writing cfg=%r path=%s" % (cfg, cfg_path), flush=True)

                with open(cfg_path, "w") as f:
                    json.dump(cfg, f)

                print("[CPU_TEMP_SAVE] write complete", flush=True)

                try:
                    with open(cfg_path, "r") as f:
                        verify = f.read()
                    print("[CPU_TEMP_SAVE] verify=%s" % verify, flush=True)
                except Exception as e:
                    print("[CPU_TEMP_SAVE] verify failed: %s" % e, flush=True)

                self.send_response(303)
                self.send_header("Location", "/cpu_temp_voice")
                self.end_headers()
                return

            except Exception as e:
                self.send_error(400, str(e))
                return

        length = int(self.headers.get("Content-Length", 0))
        data = self.rfile.read(length).decode()
        params = dict(parse_qsl(data))

        if self.path == "/unigcs_control":
            cmd = params.get("cmd", "")
            send_unigcs_fifo(cmd)
            self.send_response(303)
            self.send_header("Location", "/camera_controls")
            self.end_headers()
            return

    def do_GET(self):

        request_path = urllib.parse.urlparse(self.path).path
        upgrade_allowed_paths = {
            "/software_update_status",
            "/health",
        }
        if (
            software_update_lock_active()
            and request_path not in upgrade_allowed_paths
            and not request_path.startswith("/static/")
        ):
            body = """
            <h1>Software update in progress</h1>
            <div class='card'>
              <p>The WebUI is locked until the software update finishes.</p>
              <p class='small'>Installation progress is shown in the update dialog.</p>
            </div>
            """
            payload = page("Software update in progress", body).encode("utf-8")
            self.send_response(423)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if self.path.startswith("/static/"):
            path = "/home/pi/siyi-webui" + self.path

            if not os.path.isfile(path):
                self.send_error(404)
                return

            ctype = "application/octet-stream"

            if path.endswith(".png"):
                ctype = "image/png"
            elif path.endswith(".jpg") or path.endswith(".jpeg"):
                ctype = "image/jpeg"

            with open(path, "rb") as f:
                data = f.read()

            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/video_source_status"):
            payload = video_source_read_status()
            cfg = video_source_read_config()
            payload["configured_source"] = cfg.get("source", "siyi_rtsp")
            payload["source_names"] = video_source_names(cfg)
            send_json_response(self, payload, 200)
            return

        if self.path.startswith("/camera_sd_meta"):
            qs = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(self.path).query))
            url = qs.get("url", "")
            size, mod = camera_sd_head(url, timeout=3)
            data = json.dumps({"size": human_size(size), "date": mod if mod else "-"}).encode()
            self.send_response(200)
            self.send_header("Content-Type","application/json")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/camera_sd_res"):
            qs = dict(urllib.parse.parse_qsl(urllib.parse.urlparse(self.path).query))
            url = qs.get("url","")
            res = ""
            try:
                if url:
                    res = probe_resolution(url)
            except:
                res = ""
            data = json.dumps({"res": res}).encode()
            self.send_response(200)
            self.send_header("Content-Type","application/json")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/camera_sd_stream"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            url = q.get("url", [""])[0]

            if not url.startswith(CAM_SD_BASE + "/"):
                self.send_error(400, "Invalid camera SD URL")
                return

            try:
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=20) as r:
                    self.send_response(200)
                    self.send_header("Content-Type", "video/mp4")
                    self.send_header("Content-Disposition", "inline")
                    self.end_headers()
                    shutil.copyfileobj(r, self.wfile, length=1024*1024)
                return
            except Exception as e:
                self.send_error(502, "Camera SD stream failed: " + str(e))
                return

        if self.path in ("/camera_controls", "/unigcs_controls"):
            body = page("Camera Controls", unigcs_controls_page())
            self.send_response(200)
            self.send_header("Content-Type","text/html")
            self.end_headers()
            self.wfile.write(body.encode())
            return

        if self.path.startswith("/camera_sd_download"):
            qs=dict(urllib.parse.parse_qsl(urllib.parse.urlparse(self.path).query))
            url=qs.get("url","")
            if not url.startswith(CAM_SD_BASE + "/"):
                self.send_error(400, "Invalid camera SD URL"); return
            filename=os.path.basename(urllib.parse.urlparse(url).path) or "camera_file.mp4"
            try:
                with urllib.request.urlopen(url, timeout=10) as r:
                    data=r.read()
                self.send_response(200)
                self.send_header("Content-Type","video/mp4")
                self.send_header("Content-Disposition",f'attachment; filename="{filename}"')
                self.send_header("Content-Length",str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            except Exception as e:
                self.send_error(502, str(e))
            return

        # CPU_TEMP_VOICE_UI_V1
        # CPU_TEMP_VOICE_PAGE_V1
        if self.path.startswith("/cpu_temp_voice") and not self.path.startswith("/cpu_temp_voice_config"):
            cfg_path = "/etc/siyi/cpu_temp_voice.json"

            def read_cpu_temp_voice_cfg():
                try:
                    with open(cfg_path, "r") as f:
                        d = json.load(f)
                except Exception:
                    d = {"enabled": False, "interval_minutes": 5}
                return {
                    "enabled": bool(d.get("enabled", False)),
                    "interval_minutes": float(d.get("interval_minutes", 5) or 5),
                    "battery_enabled": bool(d.get("battery_enabled", False)),
                    "battery_interval_minutes": float(d.get("battery_interval_minutes", 5) or 5),
                    "battery_low_voltage": float(d.get("battery_low_voltage", 10.5) or 10.5),
                }

            cfg = read_cpu_temp_voice_cfg()
            checked = "checked" if cfg["enabled"] else ""
            interval = cfg["interval_minutes"]
            cfg["battery_enabled_checked"] = "checked" if cfg.get("battery_enabled", False) else ""

            body = f"""
            <h1>Voice Alerts</h1>
            <div class='card'>
              <form method='get' action='/cpu_temp_voice_config'>
                <label style='display:block;margin-bottom:12px;'>
                  <input type='checkbox' name='enabled' value='1' {checked} style='width:auto;'>
                  Enable spoken CPU temperature alerts
                </label>

                <label>Interval in minutes</label>
                <input name='interval' value='{interval}' inputmode='decimal' style='max-width:160px;'>

                <hr style='border-color:#334155;margin:18px 0;'>

                <h2>Battery Voltage</h2>
                <label style='display:block;margin-bottom:12px;'>
                  <input type='checkbox' name='battery_enabled' value='1' {cfg.get("battery_enabled_checked","")} style='width:auto;'>
                  Enable spoken battery voltage alerts
                </label>

                <label>Battery voltage interval in minutes</label>
                <input name='battery_interval' value='{cfg.get("battery_interval_minutes",5)}' inputmode='decimal' style='max-width:160px;'>

                <label>Low voltage threshold</label>
                <input name='battery_low_voltage' value='{cfg.get("battery_low_voltage",10.5)}' inputmode='decimal' style='max-width:160px;'>

                <p class='small'>
                  Enter 0 or uncheck Enable to disable each alert. Low-voltage warning is spoken when current voltage is equal to or below the threshold.
                </p>

                <button type='submit'>Save</button>
                <a class='button' href='/' style='margin-left:8px;text-decoration:none;'>Back</a>
              </form>
            </div>
            """

            html_body = page("Voice Alerts", body)
            self.send_response(200)
            self.send_header("Content-Type","text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(html_body.encode())
            return

        if self.path.startswith("/cpu_temp_voice_config"):
            try:
                cfg_path = "/etc/siyi/cpu_temp_voice.json"
                qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)

                def read_cfg():
                    try:
                        with open(cfg_path, "r") as f:
                            d = json.load(f)
                    except Exception:
                        d = {"enabled": False, "interval_minutes": 5}
                    return {
                        "enabled": bool(d.get("enabled", False)),
                        "interval_minutes": float(d.get("interval_minutes", 5) or 5),
                    }

                cfg = read_cfg()

                if "enabled" in qs or "interval" in qs or "battery_enabled" in qs or "battery_interval" in qs or "battery_low_voltage" in qs:
                    enabled = qs.get("enabled", ["1" if cfg["enabled"] else "0"])[0].strip() in ("1","true","yes","on")
                    try:
                        interval = float(qs.get("interval", [str(cfg["interval_minutes"])])[0])
                    except Exception:
                        interval = cfg["interval_minutes"]

                    if interval <= 0:
                        enabled = False
                        interval = cfg["interval_minutes"] if cfg["interval_minutes"] > 0 else 5

                    if enabled and interval < 0.25:
                        raise ValueError("Minimum enabled interval is 0.25 minutes")

                    battery_enabled = qs.get("battery_enabled", ["1" if cfg.get("battery_enabled", False) else "0"])[0].strip() in ("1","true","yes","on")

                    try:
                        battery_interval = float(qs.get("battery_interval", [str(cfg.get("battery_interval_minutes", 5))])[0])
                    except Exception:
                        battery_interval = cfg.get("battery_interval_minutes", 5)

                    try:
                        battery_low_voltage = float(qs.get("battery_low_voltage", [str(cfg.get("battery_low_voltage", 10.5))])[0])
                    except Exception:
                        battery_low_voltage = cfg.get("battery_low_voltage", 10.5)

                    if battery_interval <= 0:
                        battery_enabled = False
                        battery_interval = 5

                    cfg = {
                        "enabled": enabled,
                        "interval_minutes": interval,
                        "battery_enabled": battery_enabled,
                        "battery_interval_minutes": battery_interval,
                        "battery_low_voltage": battery_low_voltage,
                    }
                    tmp = cfg_path + ".tmp"
                    with open(tmp, "w") as f:
                        json.dump(cfg, f)
                    os.replace(tmp, cfg_path)

                if "enabled" in qs or "interval" in qs or "battery_enabled" in qs or "battery_interval" in qs or "battery_low_voltage" in qs:
                    self.send_response(303)
                    self.send_header("Location", "/cpu_temp_voice")
                    self.end_headers()
                    return

                data = json.dumps({"ok": True, **cfg}).encode()
                self.send_response(200)
                self.send_header("Content-Type","application/json")
                self.send_header("Cache-Control","no-store")
                self.send_header("Content-Length",str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return
            except Exception as e:
                data = json.dumps({"ok": False, "error": str(e)}).encode()
                self.send_response(500)
                self.send_header("Content-Type","application/json")
                self.send_header("Cache-Control","no-store")
                self.send_header("Content-Length",str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return

        if self.path.startswith("/status_bar"):
            out = sh("/usr/bin/python3 /home/pi/siyi-webui/status_probe.py")
            data = out.encode()
            self.send_response(200)
            self.send_header("Content-Type","text/html; charset=utf-8")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/set_flight_mode"):

            try:
                qs = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                mode = qs.get("mode", [""])[0].strip()

                allowed = {
                    "MANUAL", "FBWA", "AUTOTUNE", "CRUISE", "AUTO",
                    "RTL", "LOITER", "TAKEOFF", "QHOVER", "QLOITER",
                    "QLAND", "QRTL"
                }

                if mode not in allowed:
                    out = {
                        "ok": False,
                        "error": "invalid mode",
                        "mode": mode
                    }
                else:
                    blockers = read_pi_ui_mode_safety_blockers()

                    try:
                        st = flight_mode_state_read_once()
                        armed = bool(int(st.get("base_mode", 0) or 0) & 128)
                    except Exception:
                        armed = False

                    if armed and mode in blockers:
                        out = {
                            "ok": False,
                            "blocked": True,
                            "error": "Safety block: %s disabled while armed" % mode,
                            "mode": mode
                        }
                    else:
                        mode_map = {
                            "MANUAL": 0,
                            "FBWA": 5,
                            "CRUISE": 7,
                            "AUTOTUNE": 8,
                            "AUTO": 10,
                            "RTL": 11,
                            "LOITER": 12,
                            "TAKEOFF": 13,
                            "QHOVER": 18,
                            "QLOITER": 19,
                            "QLAND": 20,
                            "QRTL": 21,
                        }

                        mav = mavlink2.MAVLink(None)
                        pkt = mav.set_mode_encode(1, 1, mode_map[mode]).pack(mav)
                        ok = send_mavlink_tcp5760(pkt)

                        try:
                            tmp = FLIGHT_MODE_CACHE_FILE + ".tmp"
                            with open(tmp, "w", encoding="utf-8") as f:
                                json.dump({
                                    "mode": mode,
                                    "custom_mode": mode_map[mode],
                                    "base_mode": 81,
                                    "last_seen": time.time(),
                                    "source": "instant_webui_tx"
                                }, f)
                            os.replace(tmp, FLIGHT_MODE_CACHE_FILE)
                        except Exception as e:
                            print("[INSTANT_MODE_CACHE_FAIL]", repr(e), flush=True)

                        print("[WEBUI_MODE_TCP5760]", mode, "ok=" + str(ok), flush=True)

                        out = {
                            "ok": bool(ok),
                            "mode": mode,
                            "tx": "mavlink_tcp5760"
                        }

            except Exception as e:
                out = {
                    "ok": False,
                    "error": str(e)
                }

            data = json.dumps(out).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/flight_mode_state"):
            data = json.dumps(flight_mode_state_read_once()).encode()
            self.send_response(200)
            self.send_header("Content-Type","application/json")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/software_update_status"):
            payload = json.dumps(software_update_status_payload()).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if self.path.startswith("/health"):
            self.send_response(200)
            self.send_header("Content-type", "text/plain")
            self.end_headers()
            self.wfile.write(b"OK")
            return

        if self.path=="/first_setup":
            body=first_setup_page()

        elif self.path=="/":
            if setup_should_force():
                self.send_response(303)
                self.send_header("Location","/first_setup")
                self.end_headers()
                return

            body=f"""
            <h1>Operations</h1>

            <div class='card'>
              <h2>Operations</h2>
              <p class='small'>Use these controls to restart the main operational areas shown in the top status bar.</p>

              <table>
                <tr><th>System</th><th>Purpose</th><th>Action</th></tr>

                <tr>
                  <td><b>MAVLink</b></td>
                  <td class='small'>Telemetry routing to configured hosts.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='mavlink-router'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart MAVLink</button></form></td>
                </tr>

                <tr>
                  <td><b>Video</b></td>
                  <td class='small'>MediaMTX, selected source publisher and UDP forwarder.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='mediamtx'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart Video</button></form></td>
                </tr>

                

                <tr>
                  <td><b>ZT</b></td>
                  <td class='small'>ZeroTier overlay network.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='zerotier-one'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart ZT</button></form></td>
                </tr>

                <tr>
                  <td><b>Buttons</b></td>
                  <td class='small'>MAVLink button bridge.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='siyi-button-bridge'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart Buttons</button></form></td>
                </tr>

                <tr>
                  <td><b>WebUI</b></td>
                  <td class='small'>This control interface.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='siyi-webui'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart WebUI</button></form></td>
                </tr>
              </table>
            </div>
            """

        elif self.path.startswith("/param_trigger_full_sync"):
            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()
            out=sh("curl -fsS http://127.0.0.1:8765/trigger_full_sync 2>&1")
            try:
                j=json.loads(out.strip())
            except Exception:
                j={"ok":False,"error":out[-300:]}
            self.wfile.write(json.dumps(j).encode())
            return

        elif self.path.startswith("/param_sync_status"):
            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()
            out=sh("curl -fsS http://127.0.0.1:8765/sync_status 2>&1")
            try:
                j=json.loads(out.strip())
            except Exception:
                j={"ok":False,"error":out[-300:]}
            self.wfile.write(json.dumps(j).encode())
            return

        elif self.path.startswith("/param_state?"):
            from urllib.parse import urlparse, parse_qs
            q=parse_qs(urlparse(self.path).query)
            names=q.get("names",[""])[0].strip()

            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()

            if not names:
                self.wfile.write(b'{"ok":true,"params":{}}')
                return

            url="http://127.0.0.1:8765/state?names=" + urllib.parse.quote(names)
            out=sh("curl -fsS " + shlex.quote(url) + " 2>&1")

            try:
                j=json.loads(out.strip())
            except Exception:
                j={"ok":False,"error":out[-300:]}

            self.wfile.write(json.dumps(j).encode())
            return

        elif self.path.startswith("/param_live_read?"):

            from urllib.parse import urlparse, parse_qs

            q=parse_qs(urlparse(self.path).query)
            name=q.get("name",[""])[0].strip()

            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()

            if not name:
                self.wfile.write(b'{"ok":false,"error":"missing name"}')
                return

            url="http://127.0.0.1:8765/get?name=" + urllib.parse.quote(name)
            out=sh("curl -fsS " + shlex.quote(url) + " 2>&1")

            try:
                j=json.loads(out.strip())
            except Exception:
                j={"ok":False,"error":out[-300:]}

            self.wfile.write(json.dumps(j).encode())

        elif self.path.startswith("/param_metadata?"):
            query = parse_qs(urlparse(self.path).query)
            name = query.get("name", [""])[0]
            try:
                send_json_response(self, param_import_metadata_lookup(name), 200)
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 400)
            return

        elif self.path.startswith("/param_import_status"):
            try:
                result = param_import_daemon_request("/import/status")
                send_json_response(self, result, 200 if result.get("ok") else 400)
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 502)
            return

        elif self.path.startswith("/param_import_backup?"):
            query = parse_qs(urlparse(self.path).query)
            session_id = query.get("session_id", [""])[0]
            try:
                send_param_import_download(
                    self,
                    "/import/backup?session_id=" + urllib.parse.quote(session_id),
                )
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 400)
            return

        elif self.path.startswith("/param_import_report?"):
            query = parse_qs(urlparse(self.path).query)
            session_id = query.get("session_id", [""])[0]
            try:
                send_param_import_download(
                    self,
                    "/import/report?session_id=" + urllib.parse.quote(session_id),
                )
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 400)
            return

        elif self.path=="/param_sync_status":
            self.send_response(200)
            self.send_header("Content-type","application/json")
            self.end_headers()
            try:
                body=open("/etc/siyi/param_refresh_state.json").read()
            except Exception:
                body='{"running":false,"ok":true,"message":"Idle"}'
            self.wfile.write(body.encode())

        elif self.path.startswith("/fc_parameter_export"):
            return fc_parameter_export_handler(self)

        elif self.path=="/parameters":
            self.send_response(200)
            self.send_header("Content-type","text/html")
            self.end_headers()
            self.wfile.write(arduplane_parameters_page().encode())










        elif self.path.startswith("/gimbal_set_zero"):
            try:
                import time

                state_file="/home/pi/siyi_gimbal_state.json"

                with open(state_file,"r",encoding="utf-8") as f:
                    j=json.load(f)

                q=j.get("raw_q")
                if not q:
                    raise Exception("No raw_q in telemetry")

                out={
                    "q_ref": q,
                    "raw_yaw": j.get("raw_yaw",0),
                    "raw_pitch": j.get("raw_pitch",0),
                    "raw_roll": j.get("raw_roll",0),
                    "ts": time.time()
                }

                with open("/etc/siyi/gimbal_zero.json","w",encoding="utf-8") as f:
                    json.dump(out,f,indent=2)

                self.send_response(200)
                self.send_header("Content-Type","application/json")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "ok":True,
                    "yaw":j.get("yaw"),
                    "pitch":j.get("pitch")
                }).encode())
                return

            except Exception as e:
                self.send_response(500)
                self.send_header("Content-Type","application/json")
                self.end_headers()
                self.wfile.write(json.dumps({
                    "ok":False,
                    "error":str(e)
                }).encode())
                return

        elif self.path.startswith("/gimbal_current"):
            try:
                if os.path.exists(GIMBAL_STATE_FILE):
                    with open(GIMBAL_STATE_FILE, encoding="utf-8") as f:
                        payload=f.read()
                else:
                    payload=json.dumps({"ok":False,"yaw":0,"pitch":0,"source":"no_state_yet"})
                self.send_response(200)
                self.send_header("Content-Type","application/json")
                self.end_headers()
                self.wfile.write(payload.encode())
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(json.dumps({"ok":False,"error":str(e)}).encode())


        elif self.path=="/software_update":
            body=software_update_page()

        elif self.path=="/flaps":
            body=flaps_page()

        elif self.path=="/buttons":
            body=buttons_workspace_page()

        elif self.path=="/video":
            body=video_source_page()

        elif self.path=="/mavlink":
            m=get_mav_values()
            body=f"""<h1>MAVLink Settings</h1>
            <div class='card'><h2>Telemetry Routing</h2><form method='post' action='/save_mavlink_form'><div class='grid'>
            <div><label>Serial device</label><input style='pointer-events:auto;' name='device' value='{esc(m["device"])}'></div>
            <div><label>Baud</label><input style='pointer-events:auto;' name='baud' value='{esc(m["baud"])}'></div>
            <div><label>UDP MAVLink port</label><input style='pointer-events:auto;' name='port' value='{esc(m["port"])}'></div>
            <div><label>TCP server port</label><input style='pointer-events:auto;' name='tcp' value='{esc(m["tcp"])}'></div>
            </div><button style='pointer-events:auto;'>Save MAVLink config + restart mavlink-router</button></form></div>
            <div class='card'><h2>MAVLink Destination Hosts</h2>{endpoints_summary("mavlink")}<a href='/endpoints'><button style='pointer-events:auto;'>Edit endpoints</button></a></div>"""

        elif self.path=="/endpoints":
            body=endpoints_page()

        elif self.path=="/wifi":
            msg=esc(sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true"))
            body=f"""<h1>WiFi</h1>
            <div class='card'>{wifi_profiles_cards()}</div>
            <div class='card'><h2>Add / Replace Saved Wi-Fi SSID</h2><p class='small'>Saves profile without forcing reconnect.</p>
            <form method='post' action='/wifi_add'><div class='grid'><div><label>SSID</label><input style='pointer-events:auto;' name='ssid'></div><div><label>Password</label><input id='wifi_add_password' style='pointer-events:auto;' name='password' type='password'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="this.closest('div').querySelector('input[name=password]').type=this.checked?'text':'password'"> Show password</label></div><div><label>Priority</label><input style='pointer-events:auto;' name='priority' value='10'></div><div><label>Autoconnect</label><select style='pointer-events:auto;' name='autoconnect'><option selected>yes</option><option>no</option></select></div></div><button style='pointer-events:auto;'>Save Wi-Fi profile only</button></form></div>"""

        elif self.path=="/zerotier":
            msg=esc(sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true"))
            body=f"""<h1>ZeroTier</h1>
            <div class='card'>
            {zt_status_html()}
            <form method='post' action='/zt_save_config'>
              <div class='grid'>
                <div><label>ZeroTier Network ID</label><input style='pointer-events:auto;' name='nwid' value='{esc(zt_network_id_current())}' placeholder='ZeroTier network ID'></div>
                <div><label>ZeroTier API Token</label><input id='zt_token_field' style='pointer-events:auto;' name='token' type='password' value='{esc(zt_read_token())}' placeholder='Paste token to save/update'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="document.getElementById('zt_token_field').type=this.checked?'text':'password'"> Show token</label></div>
              </div>
              <button style='pointer-events:auto;'>Save ZeroTier config</button>
            </form>
            <p class='small'>Saving ZeroTier config also runs setup: join network, authorize/name this Pi, and update camera managed route 192.168.144.0/24 via this Pi.</p>
            </div>"""

        elif self.path=="/network":
            msg=esc(sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true"))
            body=f"""<h1>Network</h1>
            <div class='card'>{wifi_profiles_cards()}</div>
            <div class='card'><h2>Add / Replace Saved Wi-Fi SSID</h2><p class='small'>Saves profile without forcing reconnect.</p>
            <form method='post' action='/wifi_add'><div class='grid'><div><label>SSID</label><input style='pointer-events:auto;' name='ssid'></div><div><label>Password</label><input id='wifi_add_password' style='pointer-events:auto;' name='password' type='password'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="this.closest('div').querySelector('input[name=password]').type=this.checked?'text':'password'"> Show password</label></div><div><label>Priority</label><input style='pointer-events:auto;' name='priority' value='10'></div><div><label>Autoconnect</label><select style='pointer-events:auto;' name='autoconnect'><option selected>yes</option><option>no</option></select></div></div><button style='pointer-events:auto;'>Save Wi-Fi profile only</button></form></div>
            <div class='card'><h2>ZeroTier</h2>
            {zt_status_html()}
            <form method='post' action='/zt_save_config'>
              <div class='grid'>
                <div><label>ZeroTier Network ID</label><input style='pointer-events:auto;' name='nwid' value='{esc(zt_network_id_current())}' placeholder='ZeroTier network ID'></div>
                <div><label>ZeroTier API Token</label><input id='zt_token_field' style='pointer-events:auto;' name='token' type='password' value='{esc(zt_read_token())}' placeholder='Paste token to save/update'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="document.getElementById('zt_token_field').type=this.checked?'text':'password'"> Show token</label></div>
              </div>
              <button style='pointer-events:auto;'>Save ZeroTier config</button>
            </form>
            <p class='small'>Saving ZeroTier config also runs setup: join network, authorize/name this Pi, and update camera managed route 192.168.144.0/24 via this Pi.</p>
            </div>"""

        elif self.path=="/camera_sd":
            body=camera_sd_page()

        elif self.path=="/logs":
            body="<h1>Logs</h1>"
            for s in SERVICES:
                body+=f"<div class='card'><h2>{s}</h2><pre>{esc(sh(f'journalctl -u {s} -n 80 --no-pager -l'))}</pre></div>"

        elif self.path=="/safety":
            body="<h1>Safety / Failsafe</h1><div class='card'><p>The Web UI edits configuration files and restarts services.</p><p>The button bridge remains the runtime executor.</p><p>ArduPlane / FC failsafe remains independent from this UI.</p><form method='post' action='/stop_bridge'><button style='pointer-events:auto;' class='danger'>Disable Button Bridge</button></form></div>"

        else:
            self.send_error(404); return

        if self.path != "/first_setup":
            if 'body' in locals():
                body = setup_banner() + body

        data=page("SIYI Pi Control Center",body).encode()
        self.send_response(200)
        self.send_header("Content-Type","text/html; charset=utf-8")
        self.send_header("Content-Length",str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        if software_update_lock_active():
            payload = json.dumps({
                "error": "Software upgrade in progress"
            }).encode("utf-8")
            self.send_response(423)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)
            return

        if self.path == "/unigcs_control":
            length = int(self.headers.get("Content-Length", "0"))
            data = self.rfile.read(length).decode(errors="ignore")
            q = dict(parse_qsl(data))

            cmd = ""

            if "cmd" in q:
                cmd = q.get("cmd", "")
            elif "brightness" in q:
                cmd = "brightness:" + q.get("brightness", "50")
            elif "saturation" in q:
                cmd = "saturation:" + q.get("saturation", "60")
            elif "contrast" in q:
                cmd = "contrast:" + q.get("contrast", "50")
            elif "ev" in q:
                cmd = "ev:" + q.get("ev", "0")
            elif "ss" in q:
                cmd = "ss:" + q.get("ss", "0")

            try:
                out = send_unigcs_fifo(cmd)
            except Exception as e:
                out = "UniGCS control failed: " + str(e)

            try:
                open("/tmp/siyi_webui_last_action", "w").write(out)
            except Exception:
                pass

            self.send_response(303)
            self.send_header("Location", "/camera_controls")
            self.end_headers()
            return

        if self.path in {
            "/param_import_preview",
            "/param_import_apply",
            "/param_import_cancel",
            "/param_import_rollback",
        }:
            try:
                length = int(self.headers.get("Content-Length", "0") or "0")
                if length > PARAM_IMPORT_MAX_REQUEST:
                    raise ValueError("Parameter import request is too large")
                raw = self.rfile.read(length)
                payload = json.loads(raw.decode("utf-8")) if raw else {}
                if not isinstance(payload, dict):
                    raise ValueError("JSON request must be an object")
                daemon_path = {
                    "/param_import_preview": "/import/preview",
                    "/param_import_apply": "/import/apply",
                    "/param_import_cancel": "/import/cancel",
                    "/param_import_rollback": "/import/rollback",
                }[self.path]
                result = param_import_daemon_request(
                    daemon_path,
                    method="POST",
                    payload=payload,
                    timeout=45 if self.path == "/param_import_preview" else 15,
                )
                if self.path == "/param_import_preview" and result.get("ok"):
                    result = param_import_attach_metadata(result)
                send_json_response(self, result, 200 if result.get("ok") else 400)
            except Exception as exc:
                send_json_response(self, {"ok": False, "error": str(exc)}, 400)
            return

        length=int(self.headers.get("Content-Length",0))
        data=parse_qs(self.rfile.read(length).decode())


        if self.path=="/save_video_source":
            try:
                cfg = video_source_config_from_form(data)
                video_source_write_config(cfg)
                message = video_source_control("apply")
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(message)
            except Exception as exc:
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(
                    "Video source save failed: " + str(exc)
                )
            self.send_response(303)
            self.send_header("Location", "/video")
            self.end_headers()
            return

        if self.path=="/video_source_select":
            try:
                source = data.get("source", [""])[0]
                if source not in {"siyi_rtsp", "hdmi_usb", "wifilink_rtsp"}:
                    raise ValueError("Invalid video source")
                message = video_source_control("select", source)
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(message)
            except Exception as exc:
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(
                    "Video source switch failed: " + str(exc)
                )
            self.send_response(303)
            self.send_header("Location", "/video")
            self.end_headers()
            return

        if self.path=="/video_source_toggle":
            try:
                message = video_source_control("toggle")
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(message)
            except Exception as exc:
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write(
                    "Video source toggle failed: " + str(exc)
                )
            self.send_response(303)
            self.send_header("Location", "/video")
            self.end_headers()
            return

        if self.path=="/software_update_start":
            try:
                current = get_release_version()
                latest = software_update_manifest()["stable"]
                preserve_groups = software_update_validate_preserve_groups(
                    data.get("preserve", [])
                )
                remember_selection = (
                    "1" if data.get("remember", ["0"])[0] == "1" else "0"
                )

                if software_update_running():
                    message = "Upgrade is already running."
                elif not software_update_is_newer(latest, current):
                    message = (
                        "Upgrade blocked: published version " + latest
                        + " is not newer than installed version " + current + "."
                    )
                else:
                    result = subprocess.run(
                        [
                            "sudo", "-n", SOFTWARE_UPDATE_LAUNCHER,
                            "--from", current,
                            "--target", latest,
                            "--preserve", ",".join(preserve_groups),
                            "--remember", remember_selection,
                        ],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT,
                        text=True,
                        timeout=15,
                        check=False,
                    )
                    if result.returncode != 0:
                        raise RuntimeError(
                            (result.stdout or "Upgrade launcher failed").strip()
                        )
                    message = (
                        "Upgrade started: " + current + " -> " + latest
                    )
                try:
                    with open("/tmp/siyi_webui_last_action", "w", encoding="utf-8") as f:
                        f.write(message)
                except Exception:
                    pass
            except Exception as exc:
                try:
                    with open(SOFTWARE_UPDATE_LOG_FILE, "a", encoding="utf-8") as f:
                        f.write("\nUpgrade start failed: " + str(exc) + "\n")
                except Exception:
                    pass

            self.send_response(303)
            self.send_header("Location", "/software_update")
            self.end_headers()
            return

        elif self.path=="/first_setup_skip":
            open(SETUP_SKIP_FILE,"w").write("skip\n")

        elif self.path=="/first_setup_save":

            nwid=data.get("nwid",[""])[0].strip()
            token=data.get("token",[""])[0].strip()

            if nwid:
                cfg=zt_read_config()
                cfg["network_id"]=nwid
                zt_save_config(cfg)

            if token:
                zt_save_token(token)

            save_endpoints_from_params(data)

            ssid=data.get("ssid",[""])[0].strip()
            password=data.get("password",[""])[0]

            if ssid:
                sh(f"nmcli connection add type wifi ifname wlan0 con-name webui-wifi-{ssid.replace(' ','_')} ssid {shlex.quote(ssid)} 2>/dev/null || true")
                con_name = "webui-wifi-" + ssid.replace(" ","_")
                sh(f"nmcli connection modify {shlex.quote(con_name)} wifi-sec.key-mgmt wpa-psk wifi-sec.psk {shlex.quote(password)} 2>/dev/null || true")
                wifi_pw_set(con_name, password)

            out=zt_full_setup()

            if setup_config_is_valid():
                os.makedirs("/etc/siyi",exist_ok=True)
                open(SETUP_COMPLETE_FILE,"w").write(json.dumps({"complete":True},indent=2))
                if os.path.exists(SETUP_SKIP_FILE):
                    os.remove(SETUP_SKIP_FILE)

            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/restart":
            s=data.get("service",[""])[0]
            if s == "mavlink-router":
                sh("sudo -n systemctl stop mavlink-router")
                time.sleep(5)
                sh("sudo -n systemctl start mavlink-router")
                time.sleep(2)
                sh("sudo -n systemctl restart siyi-button-bridge")
            elif s == "zerotier-one":
                sh("sudo -n systemctl stop zerotier-one")
                time.sleep(5)
                sh("sudo -n systemctl start zerotier-one")
                time.sleep(3)

                sh("sudo -n systemctl stop mavlink-router")
                time.sleep(5)
                sh("sudo -n systemctl start mavlink-router")
                time.sleep(2)
                sh("sudo -n systemctl restart siyi-button-bridge")

            elif s == "siyi-webui":
                sh("systemd-run --unit=siyi-webui-delayed-restart --on-active=2 /bin/systemctl restart siyi-webui 2>/dev/null || true")
            elif s == "mediamtx":
                sh("sudo -n systemctl restart mediamtx")
                time.sleep(1)
                sh("sudo -n systemctl restart siyi-video-source")
                sh("sudo -n systemctl restart siyi-video-dual")
            elif s in SERVICES:
                sh(f"sudo -n systemctl restart {s}")

        elif self.path=="/param_write":
            name=data.get("name",[""])[0].strip()
            value=data.get("value",[""])[0].strip()

            if name and value:
                cmd=(
                    "curl -fsS -X POST "
                    "--data-urlencode " + shlex.quote("name=" + name) + " "
                    "--data-urlencode " + shlex.quote("value=" + value) + " "
                    "http://127.0.0.1:8765/set"
                )
                out=sh(cmd + " 2>&1")

                try:
                    j=json.loads(out.strip())
                    if j.get("ok"):
                        msg=f"OK {name} = {j.get('value')}"
                    else:
                        msg=f"FAILED {name}: {j.get('error')}"
                except Exception:
                    msg=f"FAILED {name}: {out[-300:]}"

                try:
                    open("/tmp/siyi_param_write_status.txt","w").write(msg)
                except Exception:
                    pass

            self.send_response(303)
            self.send_header("Location", "/parameters")
            self.end_headers()
            return

        elif self.path=="/params_refresh":

            sh("/home/pi/siyi_param_refresh_wrapper.sh >/tmp/siyi_param_refresh_wrapper.log 2>&1 &")
            self.send_response(303)
            self.send_header("Location", "/parameters")
            self.end_headers()
            return

        elif self.path=="/save_flaps":
            try:
                flaps_write_config({
                    "enabled": "enabled" in data,
                    "left_servo": data.get(
                        "left_servo", ["9"]
                    )[0],
                    "right_servo": data.get(
                        "right_servo", ["10"]
                    )[0],
                    "left_reverse": data.get(
                        "left_reverse", ["0"]
                    )[0] == "1",
                    "right_reverse": data.get(
                        "right_reverse", ["0"]
                    )[0] == "1",
                    "up_pwm": data.get(
                        "up_pwm", ["1000"]
                    )[0],
                    "takeoff_pwm": data.get(
                        "takeoff_pwm", ["1500"]
                    )[0],
                    "landing_pwm": data.get(
                        "landing_pwm", ["2000"]
                    )[0],
                })

                open(
                    "/tmp/siyi_webui_last_action",
                    "w",
                ).write(
                    "Flap configuration saved"
                )

                sh(
                    "sudo -n systemctl restart "
                    "siyi-button-bridge"
                )

            except Exception as e:
                open(
                    "/tmp/siyi_webui_last_action",
                    "w",
                ).write(
                    "Flap configuration save failed: "
                    + str(e)
                )

        elif self.path=="/save_button_safety":

            csv_vals=data.get("block_when_armed_csv", [""])[0]
            vals=[x.strip() for x in csv_vals.split(",") if x.strip()]

            current_safety=read_button_safety_config()

            if "unlock_airborne_safety" in data:
                block_disarm=("block_disarm_in_air" in data)
                block_toggle=("block_toggle_arm_disarm_in_air" in data)
            else:
                block_disarm=current_safety.get("block_disarm_in_air", True)
                block_toggle=current_safety.get("block_toggle_arm_disarm_in_air", True)

            write_button_safety_config(vals, block_disarm, block_toggle)

            sh("sudo -n systemctl restart siyi-button-bridge")
        elif self.path=="/save_gimbal_presets":
            try:
                raw=data.get("presets_json",["[]"])[0]
                presets=json.loads(raw)
                if not isinstance(presets,list):
                    presets=[]
                write_gimbal_presets(presets)
                sh("sudo -n systemctl restart siyi-button-bridge")
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"OK")
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(("ERR: %s"%e).encode())

        elif self.path=="/save_buttons":
            backup(BUTTON_MAP)
            count=int(data.get("count",["0"])[0])
            with open(BUTTON_MAP,"w",encoding="utf-8",newline="") as f:
                w=csv.writer(f,delimiter=";")
                w.writerow(["Button","Tap","Hold","ReleaseAfterTap","ReleaseAfterHold","DoubleTap","Notes"])
                for i in range(count):
                    w.writerow([data.get(f"Button_{i}",[""])[0],data.get(f"Tap_{i}",["NO_ACTION"])[0],data.get(f"Hold_{i}",["NO_ACTION"])[0],data.get(f"ReleaseAfterTap_{i}",["NO_ACTION"])[0],data.get(f"ReleaseAfterHold_{i}",["NO_ACTION"])[0],data.get(f"DoubleTap_{i}",["NO_ACTION"])[0],data.get(f"Notes_{i}",[""])[0]])
            sh("sudo -n systemctl restart siyi-button-bridge")

        elif self.path=="/save_endpoints":
            save_endpoints_from_params(data)

        elif self.path=="/save_video":
            try:
                cfg = video_source_read_config()
                cfg["siyi"]["url"] = data.get("rtsp", [cfg["siyi"]["url"]])[0]
                cfg["siyi"]["transport"] = data.get("protocols", ["tcp"])[0]
                cfg["siyi"]["latency_ms"] = video_source_int(data.get("latency", ["0"])[0], 0, 5000, "Latency")
                cfg["udp"]["port"] = video_source_int(data.get("port", ["5600"])[0], 1, 65535, "UDP port")
                video_source_write_config(cfg)
                video_source_control("apply")
            except Exception as exc:
                open("/tmp/siyi_webui_last_action", "w", encoding="utf-8").write("Video save failed: " + str(exc))

        elif self.path=="/save_mavlink_form":
            write_file(MAVCONF, make_mav_conf_from_endpoints(data.get("device",["/dev/ttyAMA0"])[0],data.get("baud",["57600"])[0],data.get("port",["14550"])[0],data.get("tcp",["5760"])[0]))
            sh("sudo -n systemctl restart mavlink-router")

        elif self.path=="/wifi_add":
            ssid=data.get("ssid",[""])[0].strip()
            pw=data.get("password",[""])[0]
            prio=data.get("priority",["10"])[0].strip() or "10"
            ac=data.get("autoconnect",["yes"])[0].strip()
            if ssid and pw:
                safe="webui-wifi-" + ssid.replace(" ","_")
                out=[]
                out.append(sh(f"sudo -n nmcli connection delete '{safe}' 2>/dev/null || true"))
                out.append(sh(f"sudo nmcli connection add type wifi ifname wlan0 con-name '{safe}' ssid '{ssid}'"))
                out.append(sh(f"sudo nmcli connection modify '{safe}' wifi-sec.key-mgmt wpa-psk wifi-sec.psk '{pw}'"))
                wifi_pw_set(safe, pw)
                out.append(sh(f"sudo nmcli connection modify '{safe}' connection.autoconnect {ac} connection.autoconnect-priority {prio}"))
                out.append("Saved Wi-Fi profile without forcing reconnect: " + safe)
                open("/tmp/siyi_webui_last_action","w").write("\\n".join([x for x in out if x]))

        elif self.path=="/wifi_update":
            name=data.get("name",[""])[0]
            prio=data.get("priority",["0"])[0]
            ac=data.get("autoconnect",["yes"])[0]
            if name and not name.startswith("netplan-"):
                sh(f"sudo -n nmcli connection modify '{name}' connection.autoconnect {ac}")
                sh(f"sudo -n nmcli connection modify '{name}' connection.autoconnect-priority {prio}")
                open("/tmp/siyi_webui_last_action","w").write(f"Updated {name}: priority={prio}, autoconnect={ac}")

        elif self.path=="/wifi_switch":
            name=data.get("name",[""])[0]
            if name:
                out=sh(f"sudo nmcli connection up '{name}'")
                open("/tmp/siyi_webui_last_action","w").write(out or f"Switched to {name}")
                sh("systemd-run --unit=siyi-webui-delayed-restart --on-active=3 /bin/systemctl restart siyi-webui 2>/dev/null || true")

        elif self.path=="/wifi_update_password":
            name=data.get("name",[""])[0]
            pw=data.get("password",[""])[0]
            if name and pw:
                out=sh(f"sudo -n nmcli connection modify '{name}' wifi-sec.psk '{pw}'")
                wifi_pw_set(name, pw)
                open("/tmp/siyi_webui_last_action","w").write(out or f"Updated Wi-Fi password for {name}")

        elif self.path=="/wifi_delete":
            name=data.get("name",[""])[0]
            if name and not name.startswith("netplan-"):
                out=sh(f"sudo -n nmcli connection delete '{name}'")
                wifi_pw_delete(name)
                open("/tmp/siyi_webui_last_action","w").write(out or f"Deleted {name}")



        elif self.path=="/camera_sd_zip":
            urls=data.get("urls",[])
            urls=[u for u in urls if u.startswith(CAM_SD_BASE + "/")]
            if urls:
                tmp=tempfile.NamedTemporaryFile(delete=False,suffix=".zip")
                tmp.close()
                try:
                    with zipfile.ZipFile(tmp.name,"w",compression=zipfile.ZIP_STORED) as z:
                        for url in urls:
                            name=os.path.basename(urllib.parse.urlparse(url).path) or "camera_file.mp4"
                            with urllib.request.urlopen(url, timeout=30) as r:
                                z.writestr(name, r.read())
                    with open(tmp.name,"rb") as f:
                        payload=f.read()
                    os.unlink(tmp.name)
                    self.send_response(200)
                    self.send_header("Content-Type","application/zip")
                    self.send_header("Content-Disposition",'attachment; filename="camera_sd_selected.zip"')
                    self.send_header("Content-Length",str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                    return
                except Exception as e:
                    try:
                        os.unlink(tmp.name)
                    except Exception:
                        pass
                    self.send_error(502, str(e))
                    return


        elif self.path=="/camera_sd_delete_selected":
            urls=data.get("urls",[])
            urls=[u for u in urls if u.startswith(CAM_SD_BASE + "/")]
            if urls:
                out=camera_sd_delete_many(urls)
                open("/tmp/siyi_webui_last_action","w").write("Camera SD batch delete: " + out)

        elif self.path=="/camera_sd_delete":
            url=data.get("url",[""])[0]
            if url.startswith(CAM_SD_BASE + "/"):
                out=camera_sd_delete(url)
                open("/tmp/siyi_webui_last_action","w").write("Camera SD delete: " + out)

        elif self.path=="/zt_save_config":
            nwid=data.get("nwid",[""])[0].strip()
            token=data.get("token",[""])[0].strip()
            cfg=zt_read_config()
            if nwid:
                cfg["network_id"]=nwid
                zt_write_config(cfg)
            if token:
                zt_save_token(token)

            saved_msg="Saved ZeroTier config. Network ID=" + (nwid or cfg.get("network_id",""))
            if token:
                saved_msg += " API token=saved"
            else:
                saved_msg += " API token=unchanged"

            setup_msg=zt_full_setup()
            open("/tmp/siyi_webui_last_action","w").write(saved_msg + "\n\n" + setup_msg)

        elif self.path=="/zt_test_token":
            out=zt_test_token()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_authorize_pi":
            out=zt_authorize_this_pi()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_update_route":
            out=zt_update_camera_route()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_full_setup":
            out=zt_full_setup()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_join":
            nwid=data.get("nwid",[""])[0].strip() or zt_network_id_current()
            if nwid:
                cfg=zt_read_config()
                cfg["network_id"]=nwid
                zt_write_config(cfg)
                out=sh(f"sudo zerotier-cli join {nwid}")
                open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/stop_bridge":
            sh("systemctl stop siyi-button-bridge")

        loc="/"
        if self.path.startswith("/save_video"): loc="/video"
        elif self.path.startswith("/save_mavlink"): loc="/mavlink"
        elif self.path.startswith("/save_endpoints"): loc="/endpoints"
        elif self.path.startswith("/save_buttons"): loc="/buttons"
        elif self.path.startswith("/save_flaps"): loc="/flaps"
        elif self.path.startswith("/wifi") or self.path.startswith("/zt"):
            loc="/wifi" if self.path.startswith("/wifi") else "/zerotier"

        elif self.path == "/unigcs_control":
            length = int(self.headers.get("Content-Length", "0"))
            data = self.rfile.read(length).decode(errors="ignore")
            q = dict(parse_qsl(data))

            cmd = ""

            if "cmd" in q:
                cmd = q.get("cmd", "")
            elif "brightness" in q:
                cmd = "brightness:" + q.get("brightness", "50")
            elif "saturation" in q:
                cmd = "saturation:" + q.get("saturation", "60")
            elif "contrast" in q:
                cmd = "contrast:" + q.get("contrast", "50")
            elif "ev" in q:
                cmd = "ev:" + q.get("ev", "0")
            elif "ss" in q:
                cmd = "ss:" + q.get("ss", "0")

            try:
                out = send_unigcs_fifo(cmd)
            except Exception as e:
                out = "UniGCS control failed: " + str(e)

            try:
                open("/tmp/siyi_webui_last_action", "w").write(out)
            except Exception:
                pass

            self.send_response(303)
            self.send_header("Location", "/camera_controls")
            self.end_headers()
            return

        self.send_response(303)
        self.send_header("Location",loc)
        self.end_headers()


# REAL_HTTP_LOGS_PAGE_FIX_START
def _real_logs_cmd(cmd, timeout=6):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT, timeout=timeout)
    except Exception as e:
        return str(e)

def _log_level(line):
    low = line.lower()
    if any(x in low for x in ["error", "failed", "failure", "traceback", "exception", "critical", "panic"]):
        return "ERROR"
    if any(x in low for x in ["warning", "warn", "denied", "timeout", "unreachable"]):
        return "WARN"
    return "INFO"

def _log_category(line):
    low = line.lower()
    if "mavlink-router" in low or "mavlink" in low or "/dev/ttyama0" in low:
        return "MAVLINK"
    if "siyi-video" in low or "gstreamer" in low or "rtsp" in low or "udp" in low or "video" in low:
        return "VIDEO"
    if "siyi-button" in low or "siyi-rec" in low or "unigcs" in low or "camera" in low:
        return "SIYI"
    if "zerotier" in low or "wlan" in low or "network" in low:
        return "NETWORK"
    if "siyi-webui" in low or "python3" in low or "webui" in low or "get /" in low:
        return "WEBUI"
    return "SYSTEM"

def _noise(line):
    low = line.lower()
    noise_words = [
        "pipewire", "wireplumber", "xdg-desktop", "rtkit", "bluez",
        "bcm2835", "vc_sm_cma", "alsa", "portal", "upower",
        "pam_unix(sudo:session): session opened",
        "pam_unix(sudo:session): session closed",
        "command=/usr/sbin/sudo zerotier-cli info",
        "get /status_bar", "get /health", "get /api/logs",
    ]
    return any(w in low for w in noise_words)

def _simplify(line):
    raw = line.strip()
    msg = raw

    # Remove noisy syslog prefix as much as possible
    m = re.match(r"^([A-Z][a-z]{2}\s+\d+\s+\d\d:\d\d:\d\d)\s+\S+\s+(.*)$", raw)
    ts = ""
    if m:
        ts = m.group(1)
        msg = m.group(2)

    msg = re.sub(r"^\S+\[\d+\]:\s*", "", msg)
    msg = msg.replace('"GET ', "GET ").replace(' HTTP/1.1" 200 -', "")

    low = msg.lower()

    if "opened uart" in low and "/dev/ttyama0" in low:
        msg = "FC serial opened: /dev/ttyAMA0"
    elif "uart" in low and "speed = 57600" in low:
        msg = "FC serial speed: 57600"
    elif "opened udp client" in low and ""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"" in low:
        msg = "MAVLink endpoint opened: Mac "+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+":14550"
    elif "opened udp client" in low and ""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"" in low:
        msg = "MAVLink endpoint opened: Android "+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+":14550"
    elif "started mavlink-router" in low:
        msg = "MAVLink Router started"
    elif "started siyi-webui" in low:
        msg = "Web UI service started"
    elif "get /logs" in low:
        msg = "Logs page opened"
    elif "get /camera_controls" in low:
        msg = "Camera Controls page opened"
    elif "get /safety" in low:
        msg = "Safety page opened"
    elif "permissions for /lib/netplan" in low:
        msg = "Netplan file permissions are too open"
    elif "registration to specific type not supported" in low:
        msg = "WiFi driver capability warning"
    elif "bgscan simple" in low:
        msg = "WiFi background scan warning"

    return ts, msg

def _real_logs_events(mode="important"):
    raw = _real_logs_cmd("journalctl --since '6 hours ago' --no-pager -n 1200")
    events = []

    for line in raw.splitlines():
        if not line.strip():
            continue
        if _noise(line):
            continue

        cat = _log_category(line)
        lvl = _log_level(line)
        ts, msg = _simplify(line)

        keep = False
        if mode == "full":
            keep = True
        elif mode == "important":
            keep = (
                lvl in ("ERROR", "WARN")
                or cat in ("MAVLINK", "VIDEO", "SIYI", "NETWORK")
                or "started" in msg.lower()
                or "opened" in msg.lower()
            )
        else:
            keep = (cat.lower() == mode.lower())

        if keep:
            events.append((ts, lvl, cat, msg))

    # Newest first. journalctl is chronological, so reverse after filtering.
    events = list(reversed(events))[:250]

    if not events:
        return "No important events found. This usually means the system is quiet/healthy."

    lines = []
    for ts, lvl, cat, msg in events:
        lines.append(f"{ts:<15}  {lvl:<5}  {cat:<8}  {msg}")
    return "\n".join(lines)

def _real_logs_text(mode="important"):
    return _real_logs_events(mode)

def _send_bytes(self, data, ctype="text/html; charset=utf-8"):
    if isinstance(data, str):
        data = data.encode("utf-8", "replace")
    self.send_response(200)
    self.send_header("Content-Type", ctype)
    self.send_header("Cache-Control", "no-store")
    self.send_header("Content-Length", str(len(data)))
    self.end_headers()
    self.wfile.write(data)

def _real_logs_page():
    return f"""<style>
.logbar{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;align-items:center}}
.logbtn{{background:#253244;color:#e8eef5;border:1px solid #3c4b5f;border-radius:8px;padding:8px 11px;cursor:pointer}}
.logbtn:hover{{background:#314158}}
.loghint{{opacity:.75;font-size:13px;margin-left:4px}}
#logs{{height:calc(100vh - 230px);min-height:420px;overflow-y:auto;padding:14px;white-space:pre-wrap;word-break:break-word;font-family:Menlo,Consolas,monospace;font-size:12px;line-height:1.4;background:#101418;color:#e8eef5;border-radius:12px;border:1px solid #2b3440}}
.err{{color:#ff9b9b;font-weight:bold}}
.warn{{color:#ffd28a;font-weight:bold}}
.info{{color:#a8ffbf;font-weight:bold}}
</style>

<h2>Logs <span style="font-size:13px;opacity:.65">v{VERSION}</span></h2>
<p style="opacity:.8;margin-top:-4px">Filtered diagnostic timeline. Newest first. Desktop/audio noise is hidden.</p>

<div class="logbar">
  <button class="logbtn" onclick="setMode('important')">Important</button>
  <button class="logbtn" onclick="setMode('mavlink')">MAVLink</button>
  <button class="logbtn" onclick="setMode('video')">Video</button>
  <button class="logbtn" onclick="setMode('siyi')">SIYI</button>
  <button class="logbtn" onclick="setMode('network')">Network</button>
  <button class="logbtn" onclick="setMode('webui')">Web UI</button>
  <button class="logbtn" onclick="setMode('system')">System</button>
  <button class="logbtn" onclick="setMode('full')">Full Filtered</button>
  <button class="logbtn" onclick="copyLogs()">Copy</button>
  <span class="loghint" id="status">Loading…</span>
</div>

<pre id="logs"></pre>

<script>
let mode='important';
let follow=true;

function colorize(t){{
  return t
    .replace(/(ERROR)/g,'<span class="err">$1</span>')
    .replace(/(WARN)/g,'<span class="warn">$1</span>')
    .replace(/(INFO)/g,'<span class="info">$1</span>');
}}

async function loadLogs(){{
  const box=document.getElementById('logs');
  const status=document.getElementById('status');
  try{{
    const r=await fetch('/api/logs?mode='+encodeURIComponent(mode)+'&t='+Date.now(), {{cache:'no-store'}});
    const t=await r.text();
    box.innerHTML=colorize(t);
    status.innerText='Mode: '+mode+' | Updated: '+new Date().toLocaleTimeString();
    if(follow) box.scrollTop=0;
  }}catch(e){{
    status.innerText='Failed to load logs';
  }}
}}

function setMode(m){{
  mode=m;
  loadLogs();
}}

function copyLogs(){{
  navigator.clipboard.writeText(document.getElementById('logs').innerText);
  document.getElementById('status').innerText='Copied diagnostics';
}}

loadLogs();
setInterval(loadLogs,5000);
</script>"""

_old_do_GET = H.do_GET
def _patched_do_GET(self):
    parsed = urlparse(self.path)
    path = parsed.path
    qs = dict(parse_qsl(parsed.query))

    if path == "/logs":
        return _send_bytes(self, page("Logs", _real_logs_page()), "text/html; charset=utf-8")

    if path == "/api/logs":
        mode = qs.get("mode", "important")
        return _send_bytes(self, _real_logs_text(mode), "text/plain; charset=utf-8")

    return _old_do_GET(self)

H.do_GET = _patched_do_GET
# REAL_HTTP_LOGS_PAGE_FIX_END


# WIFILINK2_SETTINGS_PAGE_V1_START
import base64 as _wl2_base64
import secrets as _wl2_secrets
import threading as _wl2_threading
import shlex as _wl2_shlex
from html.parser import HTMLParser as _Wl2HTMLParser

WIFILINK2_MAX_PROFILES = 20
WIFILINK2_STATUS_CACHE_SECONDS = 3.0
_wl2_status_cache = {"at": 0.0, "payload": {"online": False, "temperature_c": None, "error": "Not checked"}}
_wl2_status_lock = _wl2_threading.Lock()


def _wl2_credentials():
    cfg = video_source_read_config()
    item = cfg.get("wifilink") if isinstance(cfg, dict) else {}
    if not isinstance(item, dict):
        item = {}
    raw_url = str(item.get("url") or "rtsp://192.168.191.199:554/stream=0")
    parsed = urllib.parse.urlparse(raw_url)
    host = parsed.hostname or "192.168.191.199"
    username = str(item.get("username") or "root")
    password = str(item.get("password") or "")
    return host, username, password


def _wl2_http_request(path, method="GET", form=None, json_body=None, timeout=4.0, max_bytes=1048576):
    host, username, password = _wl2_credentials()
    url = "http://" + host + path
    headers = {"User-Agent": "SIYI-Pi-WiFiLink2/1", "Cache-Control": "no-cache"}
    token = _wl2_base64.b64encode((username + ":" + password).encode("utf-8")).decode("ascii")
    headers["Authorization"] = "Basic " + token
    body = None
    if form is not None:
        body = urllib.parse.urlencode(form).encode("utf-8")
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    elif json_body is not None:
        body = json.dumps(json_body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = urllib.request.Request(url, data=body, headers=headers, method=method)
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = response.read(max_bytes + 1)
        if len(payload) > max_bytes:
            raise ValueError("WiFiLink2 response was too large")
        return int(getattr(response, "status", 200) or 200), payload, dict(response.headers)


class _Wl2InputParser(_Wl2HTMLParser):
    """Small tolerant HTML form parser for old and new OpenIPC WebUI builds."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.fields = {}
        self.forms = []
        self._form = None
        self._select_name = ""
        self._select_value = ""
        self._select_first = ""

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        values = {str(k): ("" if v is None else str(v)) for k, v in attrs}

        if tag == "form":
            self._form = {
                "action": values.get("action", ""),
                "method": values.get("method", "GET").upper(),
                "fields": {},
            }
            self.forms.append(self._form)
            return

        if tag == "input":
            name = values.get("name", "")
            if not name:
                return
            input_type = values.get("type", "text").lower()
            if input_type in {"checkbox", "radio"} and "checked" not in values:
                return
            value = values.get("value", "on" if input_type in {"checkbox", "radio"} else "")
            self.fields[name] = value
            if self._form is not None:
                self._form["fields"][name] = value
            return

        if tag == "select":
            self._select_name = values.get("name", "")
            self._select_value = ""
            self._select_first = ""
            return

        if tag == "option" and self._select_name:
            value = values.get("value", "")
            if not self._select_first:
                self._select_first = value
            if "selected" in values:
                self._select_value = value

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag == "select" and self._select_name:
            value = self._select_value if self._select_value != "" else self._select_first
            self.fields[self._select_name] = value
            if self._form is not None:
                self._form["fields"][self._select_name] = value
            self._select_name = ""
            self._select_value = ""
            self._select_first = ""
        elif tag == "form":
            self._form = None


def _wl2_remote_command(command, timeout=10.0, max_bytes=262144):
    """Run a small command through the WiFiLink2 legacy authenticated CGI."""
    encoded = _wl2_base64.b64encode(str(command).encode("utf-8")).decode("ascii")
    # This legacy CGI reads QUERY_STRING with shell eval and does not URL-decode
    # the cmd value. Send the Base64 payload verbatim; percent-encoding breaks it.
    path = "/cgi-bin/j/run.cgi?cmd=" + encoded
    _status, raw, _headers = _wl2_http_request(
        path,
        timeout=timeout,
        max_bytes=max_bytes,
    )
    text = raw.decode("utf-8", errors="replace")
    if "No command!" in text:
        raise ValueError("WiFiLink2 command endpoint rejected the request")
    return text

def _wl2_network_form():
    """Discover the network form exposed by this exact OpenIPC WebUI build."""
    errors = []
    for endpoint in ("/cgi-bin/network.cgi", "/cgi-bin/fw-network.cgi"):
        try:
            _status, raw, _headers = _wl2_http_request(endpoint, timeout=5.0)
        except urllib.error.HTTPError as exc:
            errors.append(endpoint + ": HTTP " + str(exc.code))
            continue
        except Exception as exc:
            errors.append(endpoint + ": " + str(exc))
            continue

        parser = _Wl2InputParser()
        parser.feed(raw.decode("utf-8", errors="replace"))
        forms = parser.forms or [{"action": endpoint, "method": "POST", "fields": dict(parser.fields)}]
        selected = None
        for form in forms:
            names = [str(name).lower() for name in form.get("fields", {})]
            if any("ssid" in name or "wlan" in name or "wifi" in name for name in names):
                selected = form
                break
        if selected is None:
            selected = forms[0] if forms else {
                "action": endpoint,
                "method": "POST",
                "fields": dict(parser.fields),
            }

        fields = dict(selected.get("fields") or {})
        lower_to_actual = {str(name).lower(): str(name) for name in fields}

        def pick(exact, contains):
            for candidate in exact:
                actual = lower_to_actual.get(candidate.lower())
                if actual:
                    return actual
            for actual in fields:
                low = str(actual).lower()
                if all(token in low for token in contains):
                    return str(actual)
            return ""

        ssid_name = pick(
            ("network_wlan_ssid", "wlan_ssid", "wlanssid", "ssid"),
            ("ssid",),
        )
        password_name = pick(
            ("network_wlan_password", "wlan_password", "wlanpass", "password", "psk"),
            ("pass",),
        )
        hostname_name = pick(
            ("network_hostname", "hostname"),
            ("host", "name"),
        )

        action = str(selected.get("action") or endpoint)
        parsed_action = urllib.parse.urlparse(action)
        if parsed_action.scheme or parsed_action.netloc:
            action = parsed_action.path or endpoint
            if parsed_action.query:
                action += "?" + parsed_action.query
        elif not action.startswith("/"):
            action = "/cgi-bin/" + action.rsplit("/", 1)[-1]

        if not ssid_name:
            ssid_name = "network_wlan_ssid"
        if not password_name:
            password_name = "network_wlan_password"

        return {
            "endpoint": endpoint,
            "action": action,
            "method": str(selected.get("method") or "POST").upper(),
            "fields": fields,
            "ssid_name": ssid_name,
            "password_name": password_name,
            "hostname_name": hostname_name,
        }

    raise ValueError("WiFiLink2 network page was not found (" + "; ".join(errors) + ")")


def _wl2_device_network():
    """Read the WiFiLink2 WLAN configuration directly from firmware variables."""
    command = r'''ssid="$(fw_printenv -n wlanssid 2>/dev/null || true)"
password="$(fw_printenv -n wlanpass 2>/dev/null || true)"
hostname_value="$(hostname 2>/dev/null || echo wifilink2)"
active="$(iwgetid -r 2>/dev/null || true)"
if [ -z "$active" ]; then
  active="$(iwconfig wlan0 2>/dev/null | sed -n 's/.*ESSID:"\([^"]*\)".*/\1/p' | head -n1)"
fi
printf '__WL2_SSID_B64__'; printf '%s' "$ssid" | base64; echo
printf '__WL2_PASS_B64__'; printf '%s' "$password" | base64; echo
printf '__WL2_HOST_B64__'; printf '%s' "$hostname_value" | base64; echo
printf '__WL2_ACTIVE_B64__'; printf '%s' "$active" | base64; echo'''
    try:
        output = _wl2_remote_command(command, timeout=8.0)

        def decode_marker(marker):
            match = re.search(r"(?m)^" + re.escape(marker) + r"([^\r\n]*)$", output)
            if not match:
                return ""
            raw = match.group(1).strip()
            try:
                return _wl2_base64.b64decode(raw.encode("ascii"), validate=False).decode("utf-8", errors="replace")
            except Exception:
                return ""

        ssid = decode_marker("__WL2_SSID_B64__").strip()
        password = decode_marker("__WL2_PASS_B64__")
        hostname = decode_marker("__WL2_HOST_B64__").strip() or "wifilink2"
        active_ssid = decode_marker("__WL2_ACTIVE_B64__").strip()
        if not ssid and active_ssid:
            ssid = active_ssid
        if not ssid:
            raise ValueError("WiFiLink2 did not report a configured SSID")
        return {
            "online": True,
            "ssid": ssid,
            "active_ssid": active_ssid,
            "password": password,
            "hostname": hostname,
            "error": "",
        }
    except Exception as direct_error:
        try:
            form = _wl2_network_form()
            fields = form["fields"]
            ssid = str(fields.get(form["ssid_name"], "")).strip()
            password = str(fields.get(form["password_name"], ""))
            hostname = str(fields.get(form["hostname_name"], "")) if form["hostname_name"] else "wifilink2"
            if not ssid:
                raise ValueError("network page contained no SSID")
            return {
                "online": True,
                "ssid": ssid,
                "active_ssid": ssid,
                "password": password,
                "hostname": hostname or "wifilink2",
                "error": "",
                "form": form,
            }
        except Exception as fallback_error:
            error = "Direct read failed: " + str(direct_error) + "; network-page fallback failed: " + str(fallback_error)
    return {
        "online": False,
        "ssid": "",
        "active_ssid": "",
        "password": "",
        "hostname": "wifilink2",
        "error": error,
    }

def _wl2_profiles_default():
    return {"profiles": [], "active_id": "", "last_applied_ssid": ""}


def _wl2_profile_clean(profile):
    if not isinstance(profile, dict):
        return None
    profile_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(profile.get("id") or ""))[:40]
    ssid = str(profile.get("ssid") or "").strip()[:64]
    password = str(profile.get("password") or "")[:128]
    if not profile_id or not ssid:
        return None
    return {"id": profile_id, "ssid": ssid, "password": password}


def _wl2_profiles_read():
    data = _wl2_profiles_default()
    try:
        cfg = video_source_read_config()
        section = cfg.get("wifilink", {}) if isinstance(cfg, dict) else {}
        if not isinstance(section, dict):
            section = {}
        cleaned = []
        seen = set()
        for raw in section.get("saved_networks", []):
            item = _wl2_profile_clean(raw)
            if item and item["id"] not in seen and len(cleaned) < WIFILINK2_MAX_PROFILES:
                cleaned.append(item)
                seen.add(item["id"])
        data["profiles"] = cleaned
        data["active_id"] = str(section.get("active_network_id") or "")
        data["last_applied_ssid"] = str(section.get("last_applied_ssid") or "")[:64]
    except Exception:
        pass
    return data


def _wl2_profiles_write(data):
    clean = _wl2_profiles_default()
    clean["profiles"] = []
    seen = set()
    for raw in data.get("profiles", []):
        item = _wl2_profile_clean(raw)
        if item and item["id"] not in seen and len(clean["profiles"]) < WIFILINK2_MAX_PROFILES:
            clean["profiles"].append(item)
            seen.add(item["id"])
    clean["active_id"] = str(data.get("active_id") or "")
    clean["last_applied_ssid"] = str(data.get("last_applied_ssid") or "")[:64]
    cfg = video_source_read_config()
    section = cfg.get("wifilink")
    if not isinstance(section, dict):
        section = {}
        cfg["wifilink"] = section
    section["saved_networks"] = clean["profiles"]
    section["active_network_id"] = clean["active_id"]
    section["last_applied_ssid"] = clean["last_applied_ssid"]
    video_source_write_config(cfg)


def _wl2_profile_upsert(params):
    data = _wl2_profiles_read()
    profile_id = re.sub(r"[^a-zA-Z0-9_-]", "", str(params.get("id", "")))[:40]
    ssid = str(params.get("ssid", "")).strip()
    password = str(params.get("password", ""))
    if not ssid:
        raise ValueError("SSID cannot be empty")
    if len(ssid) > 64:
        raise ValueError("SSID is too long")
    existing = None
    for item in data["profiles"]:
        if profile_id and item["id"] == profile_id:
            existing = item
            break
    if existing is None:
        if len(data["profiles"]) >= WIFILINK2_MAX_PROFILES:
            raise ValueError("Maximum number of saved networks reached")
        existing = {"id": _wl2_secrets.token_hex(8), "ssid": ssid, "password": ""}
        data["profiles"].append(existing)
    existing["ssid"] = ssid
    if password or not existing.get("password"):
        existing["password"] = password
    if not existing.get("password"):
        raise ValueError("A Wi-Fi password is required")
    _wl2_profiles_write(data)
    return data, existing


def _wl2_profile_delete(profile_id):
    data = _wl2_profiles_read()
    before = len(data["profiles"])
    data["profiles"] = [item for item in data["profiles"] if item["id"] != profile_id]
    if len(data["profiles"]) == before:
        raise ValueError("Saved network was not found")
    if data.get("active_id") == profile_id:
        data["active_id"] = ""
    _wl2_profiles_write(data)


def _wl2_ensure_device_profile(device):
    """Import/update the currently configured WiFiLink2 network in Pi storage."""
    ssid = str(device.get("ssid") or "").strip()
    if not ssid:
        return _wl2_profiles_read()
    password = str(device.get("password") or "")
    data = _wl2_profiles_read()
    match = None
    for item in data["profiles"]:
        if item["ssid"] == ssid:
            match = item
            break
    changed = False
    if match is None:
        match = {
            "id": _wl2_secrets.token_hex(8),
            "ssid": ssid,
            "password": password,
        }
        data["profiles"].append(match)
        changed = True
    elif password and match.get("password") != password:
        match["password"] = password
        changed = True
    if data.get("active_id") != match["id"]:
        data["active_id"] = match["id"]
        changed = True
    if data.get("last_applied_ssid") != ssid:
        data["last_applied_ssid"] = ssid
        changed = True
    if changed:
        _wl2_profiles_write(data)
    return data

def _wl2_apply_network(profile):
    device = _wl2_device_network()
    hostname = str(device.get("hostname") or "wifilink2")[:64]
    ssid_q = _wl2_shlex.quote(profile["ssid"])
    password_q = _wl2_shlex.quote(profile["password"])
    hostname_q = _wl2_shlex.quote(hostname)

    # The older OpenIPC WebUI used by this WiFiLink2 calls setnetiface.sh.
    # Keep a fallback for builds that expose the newer setnetwork helper.
    command = (
        "set -e; "
        "wlandev=\"$(fw_printenv -n wlandev 2>/dev/null || true)\"; "
        "if command -v setnetiface.sh >/dev/null 2>&1; then "
        "  setnetiface.sh -i wlan0 -m dhcp -h " + hostname_q
        + " -r \"$wlandev\" -s " + ssid_q + " -p " + password_q + "; "
        "elif command -v setnetwork >/dev/null 2>&1; then "
        "  setnetwork -i wlan0 -m dhcp -h " + hostname_q
        + " -s " + ssid_q + " -p " + password_q + "; "
        "else "
        "  echo __WL2_NO_NETWORK_HELPER__; exit 127; "
        "fi; "
        "echo __WL2_NETWORK_SENT__"
    )
    try:
        output = _wl2_remote_command(command, timeout=30.0)
        if "__WL2_NO_NETWORK_HELPER__" in output:
            raise ValueError("WiFiLink2 network helper was not found")
        if "__WL2_NETWORK_SENT__" not in output:
            raise ValueError("WiFiLink2 did not confirm the network command")
        detail = "WiFiLink2 accepted the network configuration."
    except (TimeoutError, ConnectionResetError, ConnectionAbortedError, urllib.error.URLError) as exc:
        detail = "The network change was sent. WiFiLink2 disconnected while applying it: " + str(exc)

    data = _wl2_profiles_read()
    data["active_id"] = profile["id"]
    data["last_applied_ssid"] = profile["ssid"]
    _wl2_profiles_write(data)
    return detail

def _wl2_scan_networks():
    command = r'''if command -v iwlist >/dev/null 2>&1; then
  iwlist wlan0 scan 2>&1
elif command -v iw >/dev/null 2>&1; then
  iw dev wlan0 scan 2>&1
else
  echo __WL2_NO_SCANNER__
fi'''
    output = _wl2_remote_command(command, timeout=20.0, max_bytes=524288)
    if "__WL2_NO_SCANNER__" in output:
        return {"networks": [], "error": "Wireless scanning is not available in this firmware."}

    results = {}
    current = {"ssid": "", "signal": -999, "security": "Open"}

    def flush():
        ssid = str(current.get("ssid") or "").strip()
        if not ssid:
            return
        existing = results.get(ssid)
        item = {
            "ssid": ssid[:64],
            "signal": int(current.get("signal", -999)),
            "security": str(current.get("security") or "Open")[:20],
        }
        if existing is None or item["signal"] > existing["signal"]:
            results[ssid] = item

    for raw_line in output.splitlines():
        line = raw_line.strip()
        if line.startswith("Cell " ) or line.startswith("BSS " ):
            flush()
            current = {"ssid": "", "signal": -999, "security": "Open"}
            continue
        match = re.search(r'ESSID:"(.*)"', line)
        if match:
            current["ssid"] = match.group(1)
            continue
        match = re.match(r"SSID:\s*(.*)$", line)
        if match:
            current["ssid"] = match.group(1).strip()
            continue
        match = re.search(r"Signal level[= :](-?[0-9]+)\s*dBm", line, re.I)
        if not match:
            match = re.search(r"signal:\s*(-?[0-9]+(?:\.[0-9]+)?)\s*dBm", line, re.I)
        if match:
            current["signal"] = int(float(match.group(1)))
        low = line.lower()
        if "wpa3" in low or "sae" in low:
            current["security"] = "WPA3"
        elif "wpa2" in low or "802.11i" in low or low.startswith("rsn:"):
            if current.get("security") != "WPA3":
                current["security"] = "WPA2"
        elif "wpa" in low:
            if current.get("security") == "Open":
                current["security"] = "WPA"
        elif "encryption key:on" in low and current.get("security") == "Open":
            current["security"] = "Encrypted"
    flush()

    networks = sorted(results.values(), key=lambda item: item["signal"], reverse=True)
    if not networks:
        message = "No networks were returned by the WiFiLink2 scanner."
        if "resource busy" in output.lower() or "device or resource busy" in output.lower():
            message = "WiFiLink2 could not scan while its wireless interface was busy. Enter the SSID manually."
        return {"networks": [], "error": message}
    return {"networks": networks[:100], "error": ""}

def _wl2_human_label(value):
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", str(value))
    text = text.replace("_", " ").replace("-", " ")
    return " ".join(part.capitalize() for part in text.split())


def _wl2_get_nested(data, path, default=None):
    current = data
    for part in path.split("."):
        if not isinstance(current, dict) or part not in current:
            return default
        current = current[part]
    return current



# WIFILINK2_SAFE_READONLY_V6

def _wl2_signal_percent(signal_dbm):
    "Convert dBm to an easy-to-read 0-100% Wi-Fi scale."
    try:
        value = float(signal_dbm)
    except (TypeError, ValueError):
        return None
    if value <= -100:
        return 0
    if value >= -50:
        return 100
    return int(round((value + 100.0) * 2.0))



# WIFILINK2_PASSWORD_MANAGEMENT_V7B
# WIFILINK2_PROFILE_ACTION_RESULT_V7D
# VIDEO_WIFI_UI_RESTRUCTURE_V8
WIFILINK2_PROFILE_MANAGER = "/usr/bin/siyi-wifi-profile-manager-v7b"

WIFILINK2_PROFILE_PAYLOAD_DIR = "/usr/local/share/siyi/wifilink2"
WIFILINK2_PROFILE_MANAGER_PAYLOAD = (
    WIFILINK2_PROFILE_PAYLOAD_DIR + "/siyi-wifi-profile-manager-v7b"
)
WIFILINK2_PROFILE_BOOT_HELPER_PAYLOAD = (
    WIFILINK2_PROFILE_PAYLOAD_DIR + "/S96siyi-wifi-profiles-v7b"
)


def _wl2_upload_payload_file(local_path, remote_b64_path):
    try:
        with open(local_path, "rb") as handle:
            payload = handle.read()
    except Exception as exc:
        raise ValueError(
            "WiFiLink2 manager payload is unavailable on the Pi: " + str(exc)
        )

    if not payload:
        raise ValueError("WiFiLink2 manager payload is empty on the Pi")

    encoded = _wl2_base64.b64encode(payload).decode("ascii")
    _wl2_remote_command(
        "rm -f " + _wl2_shlex.quote(remote_b64_path)
        + "; : > " + _wl2_shlex.quote(remote_b64_path),
        timeout=8.0,
        max_bytes=65536,
    )

    # The legacy CGI carries commands in the URL. Send modest chunks so the
    # manager payload works with conservative URL-length limits.
    for offset in range(0, len(encoded), 2048):
        chunk = encoded[offset:offset + 2048]
        _wl2_remote_command(
            "printf '%s' " + _wl2_shlex.quote(chunk)
            + " >> " + _wl2_shlex.quote(remote_b64_path),
            timeout=8.0,
            max_bytes=65536,
        )


def _wl2_install_profile_manager_payload():
    manager_tmp = "/tmp/siyi-wifi-profile-manager-v7b.b64"
    helper_tmp = "/tmp/S96siyi-wifi-profiles-v7b.b64"

    _wl2_upload_payload_file(
        WIFILINK2_PROFILE_MANAGER_PAYLOAD,
        manager_tmp,
    )
    _wl2_upload_payload_file(
        WIFILINK2_PROFILE_BOOT_HELPER_PAYLOAD,
        helper_tmp,
    )

    command = (
        "set -e; "
        "base64 -d " + _wl2_shlex.quote(manager_tmp)
        + " > /usr/bin/siyi-wifi-profile-manager-v7b; "
        "base64 -d " + _wl2_shlex.quote(helper_tmp)
        + " > /etc/init.d/S96siyi-wifi-profiles-v7b; "
        "chmod 0755 /usr/bin/siyi-wifi-profile-manager-v7b "
        "/etc/init.d/S96siyi-wifi-profiles-v7b; "
        "rm -f " + _wl2_shlex.quote(manager_tmp) + " "
        + _wl2_shlex.quote(helper_tmp) + "; "
        "/usr/bin/siyi-wifi-profile-manager-v7b sync "
        ">/tmp/siyi-wifi-profiles-v7b-bootstrap.log 2>&1 || true; "
        "/etc/init.d/S96siyi-wifi-profiles-v7b start "
        ">>/tmp/siyi-wifi-profiles-v7b-bootstrap.log 2>&1 || true; "
        "test -x /usr/bin/siyi-wifi-profile-manager-v7b; "
        "echo __WL2_MANAGER_BOOTSTRAP_OK__"
    )
    output = _wl2_remote_command(command, timeout=20.0, max_bytes=131072)
    if not re.search(
        r"(?m)^[ \t]*__WL2_MANAGER_BOOTSTRAP_OK__[ \t]*\r?$",
        output,
    ):
        raise ValueError("WiFiLink2 profile manager installation was not confirmed")




def _wl2_manager_command(action, args=(), timeout=12.0):
    safe_action = re.sub(r"[^a-z]", "", str(action).lower())
    if safe_action not in {"list", "upsert", "delete", "sync"}:
        raise ValueError("Unsupported WiFiLink2 profile action")
    quoted = " ".join(_wl2_shlex.quote(str(item)) for item in args)
    command = (
        "test -x " + _wl2_shlex.quote(WIFILINK2_PROFILE_MANAGER)
        + " || { echo __WL2_MANAGER_MISSING__; exit 127; }; "
        + _wl2_shlex.quote(WIFILINK2_PROFILE_MANAGER) + " " + safe_action
        + ((" " + quoted) if quoted else "")
    )
    output = _wl2_remote_command(command, timeout=timeout, max_bytes=262144)
    # The legacy run.cgi response can echo the submitted shell command.
    # Therefore the marker text may appear inside the echoed command even
    # when the manager exists and the requested action succeeds. Treat the
    # manager as missing only when the marker is returned as its own line.
    missing_pattern = r"(?m)^[ \t]*__WL2_MANAGER_MISSING__[ \t]*\r?$"
    if re.search(missing_pattern, output):
        _wl2_install_profile_manager_payload()
        output = _wl2_remote_command(command, timeout=timeout, max_bytes=262144)
        if re.search(missing_pattern, output):
            raise ValueError("WiFiLink2 profile manager is not installed")
    if "ERROR:" in output and not any(marker in output for marker in ("UPSERT_OK", "DELETE_OK", "SYNC_OK")):
        message = output.split("ERROR:", 1)[1].splitlines()[0].strip()
        raise ValueError(message or "WiFiLink2 profile manager rejected the change")
    return output


def _wl2_manager_profiles():
    output = _wl2_manager_command("list", timeout=8.0)
    profiles = {}
    current_ssid = ""
    wpa_state = ""
    for raw_line in output.splitlines():
        if raw_line.startswith("__WL2_CURRENT_B64__"):
            raw = raw_line[len("__WL2_CURRENT_B64__"):].strip()
            try:
                current_ssid = _wl2_base64.b64decode(raw.encode("ascii"), validate=False).decode("utf-8", errors="replace")
            except Exception:
                current_ssid = ""
        elif raw_line.startswith("__WL2_WPA_STATE__"):
            wpa_state = raw_line[len("__WL2_WPA_STATE__"):].strip()
        elif raw_line.startswith("__WL2_PROFILE__"):
            payload = raw_line[len("__WL2_PROFILE__"):]
            parts = payload.split("\t")
            if len(parts) != 5:
                continue
            raw_ssid, raw_password, raw_priority, raw_enabled, security = parts
            try:
                ssid = _wl2_base64.b64decode(raw_ssid.encode("ascii"), validate=False).decode("utf-8", errors="replace")
                password = _wl2_base64.b64decode(raw_password.encode("ascii"), validate=False).decode("utf-8", errors="replace") if raw_password else ""
                priority = int(raw_priority)
                enabled = raw_enabled == "1"
            except Exception:
                continue
            profiles[ssid] = {
                "ssid": ssid,
                "password": password,
                "password_known": security in {"wpa", "open"},
                "security": security if security in {"wpa", "open", "unknown"} else "unknown",
                "priority": max(0, min(999, priority)),
                "enabled": enabled,
                "managed": True,
            }
    return {"profiles": profiles, "current_ssid": current_ssid, "wpa_state": wpa_state}


def _wl2_b64_arg(value):
    return _wl2_base64.b64encode(str(value).encode("utf-8")).decode("ascii")


def _wl2_native_network_save(params):
    old_ssid = str(params.get("old_ssid") or "").strip()
    ssid = str(params.get("ssid") or "").strip()
    password = str(params.get("password") or "")
    if not ssid:
        raise ValueError("SSID cannot be empty")
    if len(ssid.encode("utf-8")) > 32:
        raise ValueError("SSID is longer than 32 bytes")
    try:
        priority = int(str(params.get("priority") or "50"))
    except ValueError:
        raise ValueError("Priority must be a number")
    if priority < 0 or priority > 999:
        raise ValueError("Priority must be between 0 and 999")
    enabled = "1" if str(params.get("enabled") or "") in {"1", "true", "on", "yes"} else "0"
    open_network = str(params.get("open_network") or "") in {"1", "true", "on", "yes"}
    current_security = str(params.get("current_security") or "unknown")
    if open_network:
        security = "open"
        password = ""
    elif password:
        security = "wpa"
        length = len(password)
        if not (8 <= length <= 63 or (length == 64 and re.fullmatch(r"[0-9A-Fa-f]{64}", password))):
            raise ValueError("WPA password must be 8-63 characters or 64 hexadecimal characters")
    elif old_ssid and current_security in {"wpa", "unknown"}:
        security = "keep"
    else:
        raise ValueError("Enter a Wi-Fi password or select Open network")

    output = _wl2_manager_command(
        "upsert",
        (
            _wl2_b64_arg(old_ssid),
            _wl2_b64_arg(ssid),
            _wl2_b64_arg(password),
            str(priority),
            enabled,
            security,
        ),
        timeout=15.0,
    )
    if "UPSERT_OK" not in output:
        raise ValueError("WiFiLink2 did not confirm the saved profile")
    return "Saved WiFiLink2 profile: " + ssid


def _wl2_native_network_delete(params):
    ssid = str(params.get("ssid") or "").strip()
    if not ssid:
        raise ValueError("SSID cannot be empty")
    output = _wl2_manager_command("delete", (_wl2_b64_arg(ssid),), timeout=12.0)
    if "DELETE_OK" not in output:
        raise ValueError("WiFiLink2 did not confirm the deleted profile")
    return "Deleted WiFiLink2 profile: " + ssid

def _wl2_native_wifi_inventory():
    "Read all profiles currently loaded by WiFiLink2, without changing WLAN."
    command = r'''wpa_cli_bin="$(command -v wpa_cli 2>/dev/null || echo /usr/sbin/wpa_cli)"
active="$($wpa_cli_bin -i wlan0 status 2>/dev/null | sed -n 's/^ssid=//p' | head -n1)"
signal="$(iwconfig wlan0 2>/dev/null | sed -n 's/.*Signal level=\(-\{0,1\}[0-9][0-9]*\) dBm.*/\1/p' | head -n1)"
quality="$(iwconfig wlan0 2>/dev/null | sed -n 's/.*Link Quality=\([0-9][0-9]*\/[0-9][0-9]*\).*/\1/p' | head -n1)"
printf '__WL2_ACTIVE_B64__'; printf '%s' "$active" | base64; echo
printf '__WL2_SIGNAL_DBM__%s\n' "$signal"
printf '__WL2_QUALITY__%s\n' "$quality"
echo '__WL2_LIST_BEGIN__'
$wpa_cli_bin -i wlan0 list_networks 2>/dev/null || true
echo '__WL2_LIST_END__'
echo '__WL2_SCAN_BEGIN__'
$wpa_cli_bin -i wlan0 scan_results 2>/dev/null || true
echo '__WL2_SCAN_END__' '''
    output = _wl2_remote_command(command, timeout=8.0, max_bytes=262144)

    def marker_value(name):
        match = re.search(r"(?m)^" + re.escape(name) + r"([^\r\n]*)$", output)
        return match.group(1).strip() if match else ""

    active_ssid = ""
    raw_active = marker_value("__WL2_ACTIVE_B64__")
    if raw_active:
        try:
            active_ssid = _wl2_base64.b64decode(raw_active.encode("ascii"), validate=False).decode("utf-8", errors="replace").strip()
        except Exception:
            active_ssid = ""

    signal_dbm = None
    raw_signal = marker_value("__WL2_SIGNAL_DBM__")
    try:
        signal_dbm = int(float(raw_signal)) if raw_signal else None
    except (TypeError, ValueError):
        signal_dbm = None

    quality_text = marker_value("__WL2_QUALITY__")

    list_match = re.search(r"(?s)__WL2_LIST_BEGIN__\s*(.*?)\s*__WL2_LIST_END__", output)
    list_text = list_match.group(1) if list_match else ""
    scan_match = re.search(r"(?s)__WL2_SCAN_BEGIN__\s*(.*?)\s*__WL2_SCAN_END__", output)
    scan_text = scan_match.group(1) if scan_match else ""

    visible = {}
    for raw_line in scan_text.splitlines():
        line = raw_line.strip("\r\n")
        if not line or line.lower().startswith("bssid"):
            continue
        parts = line.split("\t", 4)
        if len(parts) < 5:
            continue
        _bssid, _frequency, raw_dbm, flags, ssid = parts
        ssid = ssid.strip()
        if not ssid:
            continue
        try:
            dbm = int(float(raw_dbm.strip()))
        except (TypeError, ValueError):
            continue
        previous = visible.get(ssid)
        if previous is None or dbm > previous["signal_dbm"]:
            visible[ssid] = {
                "signal_dbm": dbm,
                "signal_percent": _wl2_signal_percent(dbm),
                "scan_flags": flags.strip(),
            }

    profiles = []
    seen = set()
    for raw_line in list_text.splitlines():
        line = raw_line.strip("\r\n")
        if not line or line.lower().startswith("network id"):
            continue
        parts = line.split("\t")
        if len(parts) < 2:
            continue
        network_id = parts[0].strip()
        ssid = parts[1].strip()
        bssid = parts[2].strip() if len(parts) >= 3 else "any"
        flags = parts[3].strip() if len(parts) >= 4 else ""
        if not ssid or ssid in seen:
            continue
        seen.add(ssid)
        current = "[CURRENT]" in flags or (active_ssid and ssid == active_ssid)
        disabled = "[DISABLED]" in flags
        scan_item = visible.get(ssid, {})
        item_signal = signal_dbm if current and signal_dbm is not None else scan_item.get("signal_dbm")
        profiles.append({
            "id": network_id,
            "ssid": ssid,
            "bssid": bssid,
            "flags": flags,
            "current": current,
            "disabled": disabled,
            "visible": current or ssid in visible,
            "signal_dbm": item_signal,
            "signal_percent": _wl2_signal_percent(item_signal),
        })

    if active_ssid and active_ssid not in seen:
        profiles.insert(0, {
            "id": "",
            "ssid": active_ssid,
            "bssid": "any",
            "flags": "[CURRENT]",
            "current": True,
            "disabled": False,
            "visible": True,
            "signal_dbm": signal_dbm,
            "signal_percent": _wl2_signal_percent(signal_dbm),
        })

    try:
        manager = _wl2_manager_profiles()
        stored_profiles = manager.get("profiles", {})
    except Exception:
        manager = {"profiles": {}, "current_ssid": "", "wpa_state": ""}
        stored_profiles = {}

    by_ssid = {item.get("ssid", ""): item for item in profiles}
    for ssid, stored in stored_profiles.items():
        item = by_ssid.get(ssid)
        if item is None:
            item = {
                "id": "",
                "ssid": ssid,
                "bssid": "any",
                "flags": "",
                "current": active_ssid == ssid,
                "disabled": not bool(stored.get("enabled", True)),
                "visible": ssid in visible or active_ssid == ssid,
                "signal_dbm": visible.get(ssid, {}).get("signal_dbm"),
                "signal_percent": visible.get(ssid, {}).get("signal_percent"),
            }
            profiles.append(item)
            by_ssid[ssid] = item
        item.update({
            "password": str(stored.get("password") or ""),
            "password_known": bool(stored.get("password_known")),
            "security": str(stored.get("security") or "unknown"),
            "priority": int(stored.get("priority", 50)),
            "enabled": bool(stored.get("enabled", True)),
            "managed": True,
        })
        item["disabled"] = not item["enabled"]

    for item in profiles:
        item.setdefault("password", "")
        item.setdefault("password_known", False)
        item.setdefault("security", "unknown")
        item.setdefault("priority", 50)
        item.setdefault("enabled", not item.get("disabled", False))
        item.setdefault("managed", False)

    profiles.sort(key=lambda item: (
        0 if item.get("current") else 1,
        0 if item.get("visible") else 1,
        -(item.get("signal_percent") if isinstance(item.get("signal_percent"), int) else -1),
        item.get("ssid", "").lower(),
    ))

    nearby_networks = []
    for ssid, visible_item in visible.items():
        nearby_networks.append({
            "ssid": ssid,
            "signal_dbm": visible_item.get("signal_dbm"),
            "signal_percent": visible_item.get("signal_percent"),
            "scan_flags": visible_item.get("scan_flags", ""),
            "configured": ssid in by_ssid,
        })
    nearby_networks.sort(key=lambda item: (
        0 if item.get("configured") else 1,
        -(item.get("signal_dbm") if isinstance(item.get("signal_dbm"), int) else -999),
        item.get("ssid", "").lower(),
    ))

    return {
        "profiles": profiles,
        "nearby_networks": nearby_networks,
        "active_ssid": active_ssid,
        "signal_dbm": signal_dbm,
        "signal_percent": _wl2_signal_percent(signal_dbm),
        "quality": quality_text,
        "manager_available": bool(stored_profiles),
        "error": "",
    }


def _wl2_camera_active_values(paths):
    "Read active Majestic values through yaml-cli's native config path."
    quoted_paths = " ".join(_wl2_shlex.quote("." + str(path).lstrip(".")) for path in paths)
    command = (
        "for setting in " + quoted_paths + "; do "
        "value=\"$(yaml-cli -g \"$setting\" 2>/dev/null || true)\"; "
        "printf '__WL2_CAMERA_VALUE__%s\\t' \"$setting\"; "
        "printf '%s' \"$value\" | base64; echo; "
        "done"
    )
    output = _wl2_remote_command(command, timeout=8.0, max_bytes=131072)
    values = {}
    for raw_line in output.splitlines():
        if not raw_line.startswith("__WL2_CAMERA_VALUE__"):
            continue
        payload = raw_line[len("__WL2_CAMERA_VALUE__"):]
        if "\t" not in payload:
            continue
        raw_path, raw_value = payload.split("\t", 1)
        path = raw_path.strip().lstrip(".")
        try:
            value = _wl2_base64.b64decode(raw_value.strip().encode("ascii"), validate=False).decode("utf-8", errors="replace")
        except Exception:
            continue
        values[path] = value.strip()
    return values

def _wl2_camera_controls():
    _s1, raw_schema, _h1 = _wl2_http_request("/api/v1/config.schema.json", timeout=5.0)
    _s2, raw_config, _h2 = _wl2_http_request("/api/v1/config.json", timeout=5.0)
    schema = json.loads(raw_schema.decode("utf-8"))
    config = json.loads(raw_config.decode("utf-8"))
    if not isinstance(schema, dict) or not isinstance(config, dict):
        raise ValueError("Invalid Majestic configuration response")

    safe_paths = (
        "isp.antiFlicker",
        "image.contrast",
        "image.hue",
        "image.saturation",
        "image.luminance",
        "image.mirror",
        "image.flip",
        "image.rotate",
    )
    active_values = _wl2_camera_active_values(safe_paths)

    root = schema.get("properties", {})
    if not isinstance(root, dict):
        root = {}
    controls = []
    for path in safe_paths:
        section, key = path.split(".", 1)
        section_schema = root.get(section, {})
        props = section_schema.get("properties", {}) if isinstance(section_schema, dict) else {}
        spec = props.get(key, {}) if isinstance(props, dict) else {}
        if not isinstance(spec, dict):
            spec = {}

        api_section = config.get(section)
        api_value = api_section.get(key) if isinstance(api_section, dict) and key in api_section else None
        raw_active = active_values.get(path)
        if raw_active is None or raw_active == "":
            if api_value is None:
                continue
            value = api_value
        else:
            value_type = str(spec.get("type") or "string")
            if value_type == "boolean":
                value = str(raw_active).strip().lower() in {"1", "true", "yes", "on"}
            elif value_type == "integer":
                try:
                    value = int(float(str(raw_active).strip()))
                except (TypeError, ValueError):
                    value = api_value
            elif value_type == "number":
                try:
                    value = float(str(raw_active).strip())
                except (TypeError, ValueError):
                    value = api_value
            else:
                value = str(raw_active)

        value_type = str(spec.get("type") or ("boolean" if isinstance(value, bool) else "integer" if isinstance(value, int) else "number" if isinstance(value, float) else "string"))
        controls.append({
            "path": path,
            "section": section,
            "key": key,
            "label": str(spec.get("title") or _wl2_human_label(key))[:80],
            "description": str(spec.get("description") or "")[:240],
            "type": value_type,
            "value": value,
            "enum": (spec.get("enum") if isinstance(spec.get("enum"), list) else [])[:100],
            "minimum": spec.get("minimum"),
            "maximum": spec.get("maximum"),
            "default": spec.get("default"),
        })
    return controls

def _wl2_camera_apply(params):
    controls = _wl2_camera_controls()
    allowed = {item["path"]: item for item in controls}
    changed_values = {}

    def normalized(value, spec):
        if spec["type"] == "boolean":
            return "true" if str(value).lower() in {"1", "true", "yes", "on"} else "false"
        if spec["type"] == "integer":
            return str(int(value))
        if spec["type"] == "number":
            number = float(value)
            return str(int(number)) if number.is_integer() else str(number)
        return str(value)

    for key, raw_value in params.items():
        if not key.startswith("camera."):
            continue
        dotted = key[len("camera."):]
        spec = allowed.get(dotted)
        if not spec:
            continue
        value = str(raw_value)
        if spec["type"] in {"integer", "number"}:
            if value.strip() == "":
                continue
            number = float(value) if spec["type"] == "number" else int(value)
            minimum = spec.get("minimum")
            maximum = spec.get("maximum")
            if minimum is not None and number < float(minimum):
                raise ValueError(spec["label"] + " is below the supported minimum")
            if maximum is not None and number > float(maximum):
                raise ValueError(spec["label"] + " is above the supported maximum")
        elif spec.get("enum") and value not in {str(item) for item in spec["enum"]}:
            raise ValueError("Invalid value for " + spec["label"])
        value = normalized(value, spec)
        current = normalized(spec.get("value", ""), spec)
        if value != current:
            changed_values[dotted] = value

    if not changed_values:
        return "No values changed"

    commands = [
        "set -e",
        "tmp=/tmp/siyi-majestic-$$.yaml",
        "cp -f /etc/majestic.yaml \"$tmp\"",
        "trap 'rm -f \"$tmp\"' EXIT",
    ]
    for dotted, value in changed_values.items():
        commands.append(
            "yaml-cli -s " + _wl2_shlex.quote("." + dotted) + " " + _wl2_shlex.quote(value)
            + " -i \"$tmp\" -o \"$tmp\""
        )
    commands.extend([
        "cp -f \"$tmp\" /etc/majestic.yaml",
        "killall -1 majestic",
        "echo __WL2_CAMERA_APPLIED__",
    ])
    output = _wl2_remote_command("; ".join(commands), timeout=20.0)
    if "__WL2_CAMERA_APPLIED__" not in output:
        raise ValueError("WiFiLink2 did not confirm the camera update")
    return "Applied " + str(len(changed_values)) + " camera setting(s)"

def _wl2_temperature_status(force=False):
    now = time.monotonic()
    with _wl2_status_lock:
        if not force and now - float(_wl2_status_cache.get("at", 0.0)) < WIFILINK2_STATUS_CACHE_SECONDS:
            return dict(_wl2_status_cache["payload"])

    try:
        _status, raw, _headers = _wl2_http_request(
            "/metrics/isp",
            timeout=3.0,
            max_bytes=131072,
        )
        metrics = raw.decode("utf-8", errors="replace")
        match = re.search(
            r"(?m)^node_hwmon_temp_celsius(?:\{[^}]*\})?\s+(-?[0-9]+(?:[.,][0-9]+)?)\s*$",
            metrics,
        )
        temperature = float(match.group(1).replace(",", ".")) if match else None
        error = "" if temperature is not None else "Temperature metric was not present"
        payload = {
            "online": True,
            "temperature_c": temperature,
            "error": error,
            "updated": int(time.time()),
        }
    except urllib.error.HTTPError as exc:
        error = "Authentication failed" if exc.code in {401, 403} else "HTTP " + str(exc.code)
        payload = {
            "online": False,
            "temperature_c": None,
            "error": error,
            "updated": int(time.time()),
        }
    except Exception as exc:
        payload = {
            "online": False,
            "temperature_c": None,
            "error": str(exc),
            "updated": int(time.time()),
        }

    with _wl2_status_lock:
        _wl2_status_cache["at"] = now
        _wl2_status_cache["payload"] = dict(payload)
    return payload


def _wl2_camera_field_html(control):
    path = control["path"]
    label = esc(control["label"])
    description = esc(control.get("description") or "")
    value = control.get("value")
    field_name = "camera." + path
    input_html = ""
    enum = control.get("enum") or []
    if enum:
        options = []
        for item in enum:
            selected = " selected" if str(item) == str(value) else ""
            options.append("<option value='" + esc(item) + "'" + selected + ">" + esc(item) + "</option>")
        input_html = "<select style='pointer-events:auto;' name='" + esc(field_name) + "'>" + "".join(options) + "</select>"
    elif control["type"] == "boolean":
        current = str(value).lower() in {"1", "true", "yes", "on"}
        input_html = (
            "<select style='pointer-events:auto;' name='" + esc(field_name) + "'>"
            + "<option value='true'" + (" selected" if current else "") + ">On</option>"
            + "<option value='false'" + ("" if current else " selected") + ">Off</option></select>"
        )
    elif control["type"] in {"integer", "number"}:
        attrs = ""
        if control.get("minimum") is not None:
            attrs += " min='" + esc(control["minimum"]) + "'"
        if control.get("maximum") is not None:
            attrs += " max='" + esc(control["maximum"]) + "'"
        step = "any" if control["type"] == "number" else "1"
        input_html = "<input style='pointer-events:auto;' type='number' step='" + step + "' name='" + esc(field_name) + "' value='" + esc(value) + "'" + attrs + ">"
    else:
        input_html = "<input style='pointer-events:auto;' name='" + esc(field_name) + "' value='" + esc(value) + "'>"
    help_text = ("<div class='small' style='margin-top:5px'>" + description + "</div>") if description else ""
    return "<div><label>" + label + "</label>" + input_html + help_text + "</div>"


def _wl2_last_action():
    try:
        text = open("/tmp/siyi_wifilink2_last_action", encoding="utf-8", errors="replace").read().strip()
        if text.lower().startswith("wifilink2") or "wifilink2" in text.lower():
            return text[:1000]
    except Exception:
        pass
    return ""


def _wl2_signal_bars(percent):
    if not isinstance(percent, int):
        return "▯▯▯▯▯"
    filled = max(0, min(5, int(round(percent / 20.0))))
    return "▮" * filled + "▯" * (5 - filled)


def _wl2_password_toggle(input_id, checkbox_id):
    return (
        "<label class='small' style='display:flex;gap:7px;align-items:center;margin-top:7px'>"
        "<input id='" + esc(checkbox_id) + "' style='width:auto;pointer-events:auto' type='checkbox' "
        "onclick=\"document.getElementById('" + esc(input_id) + "').type=this.checked?'text':'password'\">"
        "Show password</label>"
    )



def _wl2_native_profile_card(item, index):
    ssid = str(item.get("ssid") or "(unknown)")
    current = bool(item.get("current"))
    visible = bool(item.get("visible"))
    enabled = bool(item.get("enabled", not item.get("disabled", False)))
    percent = item.get("signal_percent")
    dbm = item.get("signal_dbm")
    password = str(item.get("password") or "")
    password_known = bool(item.get("password_known"))
    security = str(item.get("security") or "unknown")
    priority = int(item.get("priority", 50))

    if current:
        label = "Connected"
        badge_class = "active"
    elif not enabled:
        label = "Disabled"
        badge_class = "bad"
    elif visible:
        label = "Available"
        badge_class = "warn"
    else:
        label = "Out of range"
        badge_class = "inactive"

    if isinstance(percent, int) and isinstance(dbm, (int, float)):
        signal_text = _wl2_signal_bars(percent) + " " + str(percent) + "% · " + str(int(dbm)) + " dBm"
    elif isinstance(dbm, (int, float)):
        signal_text = str(int(dbm)) + " dBm"
    else:
        signal_text = "Not detected in the latest scan"

    input_id = "wl2-pass-" + str(index)
    checkbox_id = "wl2-show-pass-" + str(index)
    editor_id = "wl2-profile-editor-" + str(index)
    ssid_attr = " readonly" if current else ""
    password_placeholder = "Password unavailable — enter one to manage it" if not password_known else ""
    enabled_control = (
        "<input type='hidden' name='enabled' value='1'><span class='small'>Connected profile stays enabled</span>"
        if current else
        "<label style='display:flex;gap:7px;align-items:center'><input style='width:auto;pointer-events:auto' type='checkbox' name='enabled' value='1'"
        + (" checked" if enabled else "") + ">Enabled</label>"
    )
    delete_html = (
        "<button class='danger' type='button' disabled title='The connected profile cannot be deleted'>Delete</button>"
        if current else
        "<button class='danger' style='pointer-events:auto' type='submit' formaction='/wifilink2/native-network/delete' onclick=\"return confirm('Delete this WiFiLink2 profile?');\">Delete</button>"
    )

    return (
        "<div class='wl2-profile-row'>"
        "<div class='wl2-profile-summary'>"
        "<div><div class='ssidtitle'>" + esc(ssid) + " <span class='pill " + esc(badge_class) + "'>" + esc(label) + "</span></div>"
        "<div class='ssidmeta'>" + esc(signal_text) + " · Priority " + esc(priority) + "</div></div>"
        "<button type='button' class='wl2-secondary' onclick=\"toggleWl2Editor('" + esc(editor_id) + "',this)\">Edit</button>"
        "</div>"
        "<div id='" + esc(editor_id) + "' class='wl2-profile-editor'>"
        "<form method='post' action='/wifilink2/native-network/save'>"
        "<input type='hidden' name='old_ssid' value='" + esc(ssid) + "'>"
        "<input type='hidden' name='current_security' value='" + esc(security) + "'>"
        "<div class='grid'>"
        "<div><label>SSID</label><input style='pointer-events:auto' name='ssid' value='" + esc(ssid) + "'" + ssid_attr + "></div>"
        "<div><label>Password</label><input id='" + esc(input_id) + "' style='pointer-events:auto' type='password' autocomplete='off' name='password' value='" + esc(password) + "' placeholder='" + esc(password_placeholder) + "'>"
        + _wl2_password_toggle(input_id, checkbox_id) + "</div>"
        "<div><label>Priority</label><input style='pointer-events:auto' type='number' min='0' max='999' name='priority' value='" + esc(priority) + "'><div class='small'>Higher number is preferred.</div></div>"
        "<div><label>Network state</label>" + enabled_control + "<label class='small' style='display:flex;gap:7px;align-items:center;margin-top:9px'><input style='width:auto;pointer-events:auto' type='checkbox' name='open_network' value='1'" + (" checked" if security == "open" else "") + ">Open network (no password)</label></div>"
        "</div><div style='display:flex;gap:10px;margin-top:14px'>"
        "<button style='pointer-events:auto' type='submit'>Save changes</button>" + delete_html +
        "</div></form></div></div>"
    )


def _wl2_legacy_profile_card(item, index):
    password = str(item.get("password") or "")
    input_id = "wl2-legacy-pass-" + str(index)
    checkbox_id = "wl2-legacy-show-pass-" + str(index)
    return (
        "<div class='wl2-profile-row'>"
        "<div class='wl2-profile-summary'><div><div class='ssidtitle'>" + esc(item.get("ssid") or "(unknown)") + " <span class='pill warn'>Stored on Pi only</span></div>"
        "<div class='ssidmeta'>Import this legacy profile to WiFiLink2.</div></div></div>"
        "<div style='margin-top:10px'><label>Stored password</label><input id='" + esc(input_id) + "' type='password' readonly value='" + esc(password) + "'>"
        + _wl2_password_toggle(input_id, checkbox_id) + "</div>"
        "<form method='post' action='/wifilink2/native-network/save' style='margin-top:12px'>"
        "<input type='hidden' name='old_ssid' value=''><input type='hidden' name='ssid' value='" + esc(item.get("ssid") or "") + "'>"
        "<input type='hidden' name='password' value='" + esc(password) + "'><input type='hidden' name='priority' value='30'>"
        "<input type='hidden' name='enabled' value='1'><input type='hidden' name='current_security' value='unknown'>"
        "<button style='pointer-events:auto' type='submit'>Import to WiFiLink2</button></form></div>"
    )


def _wl2_add_profile_form():
    return """
    <div id='wl2AddModal' class='wl2-modal' aria-hidden='true'>
      <div class='wl2-modal-dialog'>
        <div class='wl2-modal-head'><h2>Add Wi-Fi network</h2><button type='button' class='wl2-close' onclick='closeWl2Add()'>×</button></div>
        <p class='small'>The profile is stored directly on WiFiLink2 and loaded without restarting WLAN.</p>
        <form method='post' action='/wifilink2/native-network/save'>
          <input type='hidden' name='old_ssid' value=''><input type='hidden' name='current_security' value='unknown'>
          <div class='grid'>
            <div><label>SSID</label><input id='wl2-new-ssid' style='pointer-events:auto' name='ssid' maxlength='32' required></div>
            <div><label>Password</label><input id='wl2-new-pass' style='pointer-events:auto' type='password' autocomplete='off' name='password'><label class='small' style='display:flex;gap:7px;align-items:center;margin-top:7px'><input style='width:auto;pointer-events:auto' type='checkbox' onclick=\"document.getElementById('wl2-new-pass').type=this.checked?'text':'password'\">Show password</label></div>
            <div><label>Priority</label><input style='pointer-events:auto' type='number' min='0' max='999' name='priority' value='30'><div class='small'>Higher number is preferred.</div></div>
            <div><label>Network state</label><label style='display:flex;gap:7px;align-items:center'><input style='width:auto;pointer-events:auto' type='checkbox' name='enabled' value='1' checked>Enabled</label><label class='small' style='display:flex;gap:7px;align-items:center;margin-top:9px'><input id='wl2-new-open' style='width:auto;pointer-events:auto' type='checkbox' name='open_network' value='1'>Open network (no password)</label></div>
          </div>
          <div style='display:flex;justify-content:flex-end;gap:10px;margin-top:16px'><button type='button' class='wl2-secondary' onclick='closeWl2Add()'>Cancel</button><button style='pointer-events:auto' type='submit'>Add network</button></div>
        </form>
      </div>
    </div>
    """


def _wl2_device_runtime_summary():
    command = r"""hostname_value="$(hostname 2>/dev/null || echo wifilink2)"
wpa_state="$(/usr/sbin/wpa_cli -i wlan0 status 2>/dev/null | sed -n 's/^wpa_state=//p' | head -n1)"
lan_ip="$(/usr/sbin/wpa_cli -i wlan0 status 2>/dev/null | sed -n 's/^ip_address=//p' | head -n1)"
uptime_value="$(cut -d. -f1 /proc/uptime 2>/dev/null || echo 0)"
manager_state="$(/etc/init.d/S96siyi-wifi-profiles-v7b status 2>/dev/null | head -n1 || true)"
zt_state="$(zerotier-cli info 2>/dev/null | awk '{print $5}' | head -n1 || true)"
if netstat -lnt 2>/dev/null | grep -q ':554 '; then rtsp_state=online; else rtsp_state=offline; fi
for pair in hostname "$hostname_value" wpa_state "$wpa_state" lan_ip "$lan_ip" uptime "$uptime_value" manager "$manager_state" zerotier "$zt_state" rtsp "$rtsp_state"; do :; done
printf '__WL2_RUNTIME_HOST_B64__'; printf '%s' "$hostname_value" | base64; echo
printf '__WL2_RUNTIME_WPA__%s\n' "$wpa_state"
printf '__WL2_RUNTIME_LAN__%s\n' "$lan_ip"
printf '__WL2_RUNTIME_UPTIME__%s\n' "$uptime_value"
printf '__WL2_RUNTIME_MANAGER_B64__'; printf '%s' "$manager_state" | base64; echo
printf '__WL2_RUNTIME_ZT__%s\n' "$zt_state"
printf '__WL2_RUNTIME_RTSP__%s\n' "$rtsp_state"""
    summary = {
        "hostname": "wifilink2", "wpa_state": "", "lan_ip": "", "uptime_seconds": 0,
        "manager_state": "unknown", "zerotier_state": "", "rtsp_state": "unknown",
    }
    try:
        output = _wl2_remote_command(command, timeout=8.0, max_bytes=131072)
        def marker(name):
            match = re.search(r"(?m)^" + re.escape(name) + r"([^\r\n]*)$", output)
            return match.group(1).strip() if match else ""
        def decoded(name):
            raw = marker(name)
            if not raw:
                return ""
            try:
                return _wl2_base64.b64decode(raw.encode("ascii"), validate=False).decode("utf-8", errors="replace").strip()
            except Exception:
                return ""
        summary["hostname"] = decoded("__WL2_RUNTIME_HOST_B64__") or summary["hostname"]
        summary["wpa_state"] = marker("__WL2_RUNTIME_WPA__")
        summary["lan_ip"] = marker("__WL2_RUNTIME_LAN__")
        try:
            summary["uptime_seconds"] = int(marker("__WL2_RUNTIME_UPTIME__") or 0)
        except Exception:
            summary["uptime_seconds"] = 0
        summary["manager_state"] = decoded("__WL2_RUNTIME_MANAGER_B64__") or "unknown"
        summary["zerotier_state"] = marker("__WL2_RUNTIME_ZT__")
        summary["rtsp_state"] = marker("__WL2_RUNTIME_RTSP__") or "unknown"
    except Exception as exc:
        summary["error"] = str(exc)
    return summary


def _wl2_format_uptime(seconds):
    try:
        seconds = max(0, int(seconds))
    except Exception:
        return "Unavailable"
    days, remainder = divmod(seconds, 86400)
    hours, remainder = divmod(remainder, 3600)
    minutes, _seconds = divmod(remainder, 60)
    if days:
        return f"{days}d {hours}h {minutes}m"
    if hours:
        return f"{hours}h {minutes}m"
    return f"{minutes}m"


def _wl2_device_settings_save(params):
    cfg = video_source_read_config()
    section = cfg.get("wifilink") if isinstance(cfg, dict) else None
    if not isinstance(section, dict):
        section = {}
        cfg["wifilink"] = section
    url = str(params.get("wifilink_url") or section.get("url") or "").strip()
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in {"rtsp", "rtsps"} or not parsed.hostname:
        raise ValueError("WiFiLink2 RTSP URL must be a valid RTSP URL")
    username = str(params.get("wifilink_username") or section.get("username") or "root").strip()
    if not username:
        raise ValueError("WiFiLink2 username cannot be empty")
    transport = str(params.get("wifilink_transport") or section.get("transport") or "tcp")
    if transport not in {"tcp", "udp"}:
        raise ValueError("Invalid WiFiLink2 RTSP transport")
    latency = video_source_int(params.get("wifilink_latency", section.get("latency_ms", 0)), 0, 5000, "WiFiLink2 latency")
    password = str(params.get("wifilink_password") or "")
    section.update({"url": url, "username": username, "transport": transport, "latency_ms": latency})
    if password:
        section["password"] = password
    video_source_write_config(cfg)
    if cfg.get("source") == "wifilink_rtsp":
        video_source_control("apply")
        return "WiFiLink2 device settings saved and applied to the active video source"
    return "WiFiLink2 device settings saved"


def _wl2_device_connection_test():
    host, _username, _password = _wl2_credentials()
    _wl2_remote_command("echo __WL2_SSH_OK__", timeout=8.0)
    sock = None
    try:
        sock = socket.create_connection((host, 554), timeout=5.0)
    finally:
        if sock is not None:
            sock.close()
    return "WiFiLink2 SSH and RTSP connection test passed"


def _wl2_nearby_rows(nearby_networks, configured_ssids):
    rows = []
    for item in nearby_networks:
        ssid = str(item.get("ssid") or "")
        if not ssid:
            continue
        percent = item.get("signal_percent")
        dbm = item.get("signal_dbm")
        signal = (str(percent) + "% · " + str(int(dbm)) + " dBm") if isinstance(percent, int) and isinstance(dbm, (int, float)) else "Signal unavailable"
        configured = ssid in configured_ssids
        status = "Configured" if configured else "Nearby"
        action = "<span class='pill active'>Configured</span>" if configured else (
            "<button type='button' class='wl2-secondary' onclick='openWl2Add(" + esc(json.dumps(ssid)) + ",false)'>Add</button>"
        )
        rows.append("<div class='wl2-nearby-row'><div><b>" + esc(ssid) + "</b><div class='small'>" + esc(signal) + "</div></div><div>" + action + "</div></div>")
    if not rows:
        return "<p class='small'>No nearby networks are present in the current scan cache.</p>"
    return "".join(rows)


def wifilink2_settings_page():
    device = _wl2_device_network()
    runtime = _wl2_device_runtime_summary()
    status = _wl2_temperature_status(force=True)
    host, username, password = _wl2_credentials()
    video_cfg = video_source_read_config()
    wl_video = video_cfg.get("wifilink", {}) if isinstance(video_cfg, dict) else {}

    try:
        inventory = _wl2_native_wifi_inventory()
        inventory_error = ""
    except Exception as exc:
        inventory = {
            "profiles": [], "nearby_networks": [],
            "active_ssid": str(device.get("active_ssid") or device.get("ssid") or ""),
            "signal_dbm": None, "signal_percent": None, "quality": "",
        }
        inventory_error = str(exc)

    current_ssid = inventory.get("active_ssid") or device.get("active_ssid") or device.get("ssid") or "Unavailable"
    online_class = "ok" if status.get("online") else "bad"
    online_label = "Online" if status.get("online") else "Unavailable"
    temperature = status.get("temperature_c")
    temperature_text = (f"{temperature:.1f} °C" if isinstance(temperature, (int, float)) else "Unavailable")

    signal_percent = inventory.get("signal_percent")
    signal_dbm = inventory.get("signal_dbm")
    if isinstance(signal_percent, int) and isinstance(signal_dbm, (int, float)):
        signal_text = _wl2_signal_bars(signal_percent) + " " + str(signal_percent) + "% · " + str(int(signal_dbm)) + " dBm"
    elif inventory.get("quality"):
        signal_text = str(inventory.get("quality"))
    else:
        signal_text = "Unavailable"

    native_profiles = list(inventory.get("profiles") or [])
    native_html = "".join(_wl2_native_profile_card(item, index) for index, item in enumerate(native_profiles))
    if not native_html:
        native_html = "<p class='small'>No WiFiLink2 profiles could be read.</p>"

    native_ssids = {str(item.get("ssid") or "") for item in native_profiles}
    current_profile = next((item for item in native_profiles if item.get("current")), None)
    current_priority = current_profile.get("priority", 50) if current_profile else 50
    current_card = (
        "<div class='wl2-current-card'><div><div class='ssidtitle'>" + esc(current_ssid) + " <span class='pill active'>Connected</span></div>"
        "<div class='ssidmeta'>" + esc(signal_text) + " · Priority " + esc(current_priority) + "</div>"
        "<div class='ssidmeta'>LAN address: " + esc(runtime.get("lan_ip") or "Unavailable") + "</div></div>"
        "<button type='button' class='wl2-secondary' onclick=\"activateWl2Tab('wifi');const e=document.querySelector('.wl2-profile-row .ssidtitle');if(e)e.scrollIntoView({behavior:'smooth'});\">Manage profile</button></div>"
    )

    nearby_html = _wl2_nearby_rows(list(inventory.get("nearby_networks") or []), native_ssids)
    legacy_profiles = [item for item in _wl2_profiles_read().get("profiles", []) if str(item.get("ssid") or "") not in native_ssids]
    legacy_html = "".join(_wl2_legacy_profile_card(item, index) for index, item in enumerate(legacy_profiles))

    try:
        camera_controls = _wl2_camera_controls()
        camera_error = ""
    except Exception as exc:
        camera_controls = []
        camera_error = str(exc)
    camera_groups = []
    for section in ("isp", "image", "video0"):
        fields = [_wl2_camera_field_html(item) for item in camera_controls if item["section"] == section]
        if fields:
            camera_groups.append(
                "<section class='wl2-camera-group'><h3>"
                + esc(_wl2_human_label(section))
                + "</h3><div class='wl2-camera-grid'>"
                + "".join(fields)
                + "</div></section>"
            )
    if camera_groups:
        camera_html = (
            "<form method='post' action='/wifilink2/camera/apply' class='wl2-camera-form'>"
            + "".join(camera_groups)
            + "<div class='wl2-camera-actions'><button style='pointer-events:auto'>Apply camera settings</button>"
            + "<a class='wl2-link-button wl2-secondary' href='/wifilink2?reload=1#camera'>Reload active values</a>"
            + "<span class='small'>Sliders and radio choices are applied together.</span></div></form>"
        )
    else:
        camera_html = "<p class='bad'>Camera settings unavailable: " + esc(camera_error or "No supported image controls were reported by this firmware") + "</p>"

    network_error = ""
    if inventory_error:
        network_error = "<p class='bad'>WiFiLink2 profile read failed: " + esc(inventory_error) + "</p>"
    elif not device.get("online"):
        network_error = "<p class='bad'>Device network status unavailable: " + esc(device.get("error") or "Unknown error") + "</p>"

    last_action = _wl2_last_action()
    action_html = ("<div class='wl2-action'><b>Last action:</b> " + esc(last_action) + "</div>") if last_action else ""
    legacy_section = ""
    if legacy_html:
        legacy_section = "<details class='wl2-details'><summary>Profiles stored on the Pi but not WiFiLink2</summary><p class='small'>Import these only when they are still needed.</p>" + legacy_html + "</details>"

    rtsp_online = str(runtime.get("rtsp_state") or "").lower() == "online"
    rtsp_label = "Online" if rtsp_online else "Unavailable"
    rtsp_class = "ok" if rtsp_online else "bad"
    zt_state = str(runtime.get("zerotier_state") or "").upper()
    zt_online = zt_state == "ONLINE" or bool(host)
    zt_label = host + ((" · " + zt_state) if zt_state else "")
    manager_state = str(runtime.get("manager_state") or "unknown")
    wpa_state = str(runtime.get("wpa_state") or "Unavailable")
    password_value = str(wl_video.get("password") or password or "")
    transport = str(wl_video.get("transport") or "tcp")

    body = f"""
    <!-- VIDEO_WIFI_UI_RESTRUCTURE_V8 -->
    <style>
      .wl2-head{{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:16px;flex-wrap:wrap}}
      .wl2-head h1{{margin:0}}
      .wl2-summary{{display:grid;grid-template-columns:repeat(6,minmax(135px,1fr));gap:10px}}
      .wl2-kpi{{background:#0b1220;border:1px solid #334155;border-radius:10px;padding:12px;min-height:62px}}
      .wl2-kpi-label{{font-size:12px;color:#94a3b8;margin-bottom:5px}}
      .wl2-kpi-value{{font-weight:700;word-break:break-word}}
      .wl2-tabbar{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px}}
      .wl2-tabbtn{{background:#1e293b;color:#cbd5e1;border:1px solid #334155;margin:0}}
      .wl2-tabbtn.active{{background:#2563eb;color:white;border-color:#3b82f6}}
      .wl2-tabpanel{{display:none}}
      .wl2-tabpanel.active{{display:block}}
      .wl2-action{{background:#172554;border:1px solid #1d4ed8;border-radius:10px;padding:11px 13px;margin-bottom:16px}}
      .wl2-current-card{{display:flex;justify-content:space-between;gap:18px;align-items:center;background:#0b1220;border:1px solid #22c55e;border-radius:12px;padding:15px;flex-wrap:wrap}}
      .wl2-profile-row{{background:#0b1220;border:1px solid #334155;border-radius:10px;padding:13px;margin-bottom:10px}}
      .wl2-profile-summary{{display:flex;justify-content:space-between;gap:16px;align-items:center;flex-wrap:wrap}}
      .wl2-profile-editor{{display:none;border-top:1px solid #334155;margin-top:12px;padding-top:12px}}
      .wl2-profile-editor.open{{display:block}}
      .wl2-secondary{{background:#475569}}
      .wl2-link-button{{display:inline-block;background:#2563eb;color:white;border-radius:8px;padding:9px 13px;text-decoration:none}}
      .wl2-nearby-row{{display:flex;justify-content:space-between;gap:16px;align-items:center;padding:10px 0;border-bottom:1px solid #243244}}
      .wl2-nearby-row:last-child{{border-bottom:0}}
      .wl2-details{{background:#0b1220;border:1px solid #334155;border-radius:10px;padding:12px;margin-top:12px}}
      .wl2-details summary{{cursor:pointer;font-weight:700}}
      .wl2-modal{{display:none;position:fixed;inset:0;background:rgba(2,6,23,.82);z-index:10000;align-items:center;justify-content:center;padding:20px}}
      .wl2-modal.open{{display:flex}}
      .wl2-modal-dialog{{width:min(760px,96vw);background:#111827;border:1px solid #475569;border-radius:14px;padding:18px;box-shadow:0 24px 80px rgba(0,0,0,.6)}}
      .wl2-modal-head{{display:flex;justify-content:space-between;align-items:center;gap:12px}}
      .wl2-modal-head h2{{margin:0}}
      .wl2-close{{background:transparent;font-size:28px;padding:0 8px;color:#cbd5e1}}
      .wl2-camera-form{{display:grid;gap:12px}}
      .wl2-camera-group{{background:#0b1220;border:1px solid #334155;border-radius:14px;padding:14px}}
      .wl2-camera-group h3{{margin:0 0 12px;font-size:17px}}
      .wl2-camera-grid{{display:grid;grid-template-columns:repeat(2,minmax(260px,1fr));gap:14px}}
      .wl2-camera-field{{background:#111827;border:1px solid #334155;border-radius:11px;padding:12px}}
      .wl2-camera-field>label{{display:block;margin-bottom:9px;color:#e2e8f0;font-weight:700}}
      .wl2-camera-slider-row{{display:grid;grid-template-columns:1fr 58px;gap:10px;align-items:center}}
      .wl2-camera-slider-row input[type=range]{{width:100%;accent-color:#3b82f6}}
      .wl2-camera-slider-row output{{background:#020617;border:1px solid #334155;border-radius:7px;padding:6px;text-align:center}}
      .wl2-camera-radio-group{{display:flex;gap:8px;flex-wrap:wrap}}
      .wl2-camera-radio{{display:inline-flex;align-items:center;gap:7px;background:#020617;border:1px solid #334155;border-radius:999px;padding:8px 12px;cursor:pointer}}
      .wl2-camera-radio:has(input:checked){{background:#172554;border-color:#3b82f6;color:#dbeafe}}
      .wl2-camera-radio input{{width:auto;margin:0;accent-color:#3b82f6}}
      .wl2-camera-actions{{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:2px}}
      @media(max-width:900px){{.wl2-camera-grid{{grid-template-columns:1fr}}}}
      @media(max-width:1100px){{.wl2-summary{{grid-template-columns:repeat(3,minmax(150px,1fr))}}}}
      @media(max-width:700px){{.wl2-summary{{grid-template-columns:1fr 1fr}}}}
    </style>

    <div class='wl2-head'><div><h1>Air Link</h1><div class='small'>Wireless link, onboard camera and device connection settings.</div></div><a class='wl2-link-button wl2-secondary' href='/media?tab=video' target='_top'>Open Cameras &amp; Video</a></div>
    {action_html}
    <div class='card'>
      <div class='wl2-summary'>
        <div class='wl2-kpi'><div class='wl2-kpi-label'>Device</div><div id='wl2-online' class='wl2-kpi-value {online_class}'>{online_label}</div></div>
        <div class='wl2-kpi'><div class='wl2-kpi-label'>Current network</div><div class='wl2-kpi-value'>{esc(current_ssid)}</div></div>
        <div class='wl2-kpi'><div class='wl2-kpi-label'>Signal</div><div class='wl2-kpi-value' style='font-size:13px'>{esc(signal_text)}</div></div>
        <div class='wl2-kpi'><div class='wl2-kpi-label'>LAN address</div><div class='wl2-kpi-value'>{esc(runtime.get('lan_ip') or 'Unavailable')}</div></div>
        <div class='wl2-kpi'><div class='wl2-kpi-label'>ZeroTier</div><div class='wl2-kpi-value' style='font-size:13px'>{esc(zt_label)}</div></div>
        <div class='wl2-kpi'><div class='wl2-kpi-label'>CPU / RTSP</div><div class='wl2-kpi-value'><span id='wl2-temperature'>{temperature_text}</span> · <span class='{rtsp_class}'>{rtsp_label}</span></div></div>
      </div>
      <p id='wl2-status-error' class='small'>{esc(status.get('error') or '')}</p>{network_error}
    </div>

    <div class='wl2-tabbar'>
      <button type='button' class='wl2-tabbtn active' data-tab='wifi'>Wi-Fi</button>
      <button type='button' class='wl2-tabbtn' data-tab='camera'>Camera</button>
      <button type='button' class='wl2-tabbtn' data-tab='device'>Device</button>
      <button type='button' class='wl2-tabbtn' data-tab='diagnostics'>Diagnostics</button>
    </div>

    <section class='wl2-tabpanel active' data-panel='wifi'>
      <div class='card'><div class='wl2-card-title'><h2>Current connection</h2></div>{current_card}</div>
      <div class='card'>
        <div style='display:flex;justify-content:space-between;gap:14px;align-items:center;flex-wrap:wrap'><div><h2 style='margin-bottom:4px'>Configured networks</h2><div class='small'>Profiles stored directly on WiFiLink2. Higher priority is preferred.</div></div><button type='button' onclick='openWl2Add()'>+ Add Wi-Fi network</button></div>
        <div style='margin-top:14px'>{native_html}</div>{legacy_section}
      </div>
      <div class='card'>
        <div style='display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap'><div><h2 style='margin-bottom:4px'>Nearby networks</h2><div class='small'>Current scan cache from WiFiLink2. Out-of-range saved profiles remain configured.</div></div><button type='button' class='wl2-secondary' onclick='refreshNearbyNetworks(this)'>Scan networks</button></div>
        <div id='wl2NearbyNetworks' style='margin-top:10px'>{nearby_html}</div>
      </div>
    </section>

    <section class='wl2-tabpanel' data-panel='camera'>
      <div class='card'><h2>Air Link Camera</h2><p class='small'>Live image settings read from <code>/etc/majestic.yaml</code>. Use sliders for levels and radio buttons for discrete choices, then apply the group.</p>{camera_html}</div>
    </section>

    <section class='wl2-tabpanel' data-panel='device'>
      <div class='card'>
        <h2>Device connection</h2>
        <p class='small'>This is the authoritative location for WiFiLink2 address, login and RTSP connection settings. The Video page uses the same stored configuration.</p>
        <form method='post' action='/wifilink2/device/save'>
          <div class='grid'>
            <div style='grid-column:1/-1'><label>RTSP URL</label><input name='wifilink_url' value='{esc(wl_video.get('url') or '')}' required></div>
            <div><label>SSH / WebUI username</label><input name='wifilink_username' value='{esc(username)}' required></div>
            <div><label>Password</label><input id='wl2-device-password' type='password' name='wifilink_password' value='{esc(password_value)}' autocomplete='off'>{_wl2_password_toggle('wl2-device-password','wl2-show-device-password')}</div>
            <div><label>RTSP probe transport</label><select name='wifilink_transport'><option value='tcp' {'selected' if transport == 'tcp' else ''}>TCP</option><option value='udp' {'selected' if transport == 'udp' else ''}>UDP</option></select></div>
            <div><label>Receiver latency (ms)</label><input type='number' min='0' max='5000' name='wifilink_latency' value='{esc(wl_video.get('latency_ms',0))}'></div>
          </div>
          <div style='display:flex;gap:10px;margin-top:14px;flex-wrap:wrap'><button type='submit'>Save device settings</button></div>
        </form>
        <form method='post' action='/wifilink2/device/test' style='margin-top:8px'><button type='submit' class='wl2-secondary'>Test saved SSH and RTSP connection</button></form>
      </div>
    </section>

    <section class='wl2-tabpanel' data-panel='diagnostics'>
      <div class='card'>
        <h2>Device diagnostics</h2>
        <div class='grid'>
          <div class='wl2-kpi'><div class='wl2-kpi-label'>Hostname</div><div class='wl2-kpi-value'>{esc(runtime.get('hostname') or 'Unavailable')}</div></div>
          <div class='wl2-kpi'><div class='wl2-kpi-label'>Uptime</div><div class='wl2-kpi-value'>{esc(_wl2_format_uptime(runtime.get('uptime_seconds',0)))}</div></div>
          <div class='wl2-kpi'><div class='wl2-kpi-label'>wpa_supplicant</div><div class='wl2-kpi-value'>{esc(wpa_state)}</div></div>
          <div class='wl2-kpi'><div class='wl2-kpi-label'>Profile manager</div><div class='wl2-kpi-value' style='font-size:13px'>{esc(manager_state)}</div></div>
          <div class='wl2-kpi'><div class='wl2-kpi-label'>ZeroTier state</div><div class='wl2-kpi-value'>{esc(zt_state or 'Unavailable')}</div></div>
          <div class='wl2-kpi'><div class='wl2-kpi-label'>RTSP service</div><div class='wl2-kpi-value {rtsp_class}'>{rtsp_label}</div></div>
        </div>
        <details class='wl2-details' style='margin-top:14px'><summary>Configuration notes</summary><p class='small'>Wi-Fi profiles are maintained by the V7B profile manager. WLAN is not restarted when a profile is added or edited. The currently connected profile cannot be deleted or disabled.</p></details>
        <a class='wl2-link-button wl2-secondary' href='/system?tab=diagnostics' target='_top'>Open full system diagnostics</a>
      </div>
    </section>

    {_wl2_add_profile_form()}

    <script>
    const configuredWl2Ssids=new Set({json.dumps(sorted(native_ssids), ensure_ascii=False)});
    function activateWl2Tab(name){{
      document.querySelectorAll('.wl2-tabbtn').forEach(btn=>btn.classList.toggle('active',btn.dataset.tab===name));
      document.querySelectorAll('.wl2-tabpanel').forEach(panel=>panel.classList.toggle('active',panel.dataset.panel===name));
      if(history.replaceState) history.replaceState(null,'','#'+name);
      try{{localStorage.setItem('siyi-tab-wifilink2',name)}}catch(_e){{}}
    }}
    document.querySelectorAll('.wl2-tabbtn').forEach(btn=>btn.addEventListener('click',()=>activateWl2Tab(btn.dataset.tab)));
    const requestedTab=(location.hash||'').replace('#','') || (()=>{{try{{return localStorage.getItem('siyi-tab-wifilink2')}}catch(_e){{return ''}}}})() || 'wifi';
    if(['wifi','camera','device','diagnostics'].includes(requestedTab)) activateWl2Tab(requestedTab);
    function toggleWl2Editor(id,button){{const editor=document.getElementById(id);const open=editor.classList.toggle('open');button.textContent=open?'Close':'Edit';}}
    function openWl2Add(ssid='',openNetwork=false){{
      document.getElementById('wl2-new-ssid').value=ssid||'';
      document.getElementById('wl2-new-open').checked=Boolean(openNetwork);
      document.getElementById('wl2AddModal').classList.add('open');
      document.getElementById('wl2AddModal').setAttribute('aria-hidden','false');
      setTimeout(()=>document.getElementById(ssid?'wl2-new-pass':'wl2-new-ssid').focus(),50);
    }}
    function closeWl2Add(){{document.getElementById('wl2AddModal').classList.remove('open');document.getElementById('wl2AddModal').setAttribute('aria-hidden','true');}}
    document.getElementById('wl2AddModal').addEventListener('click',event=>{{if(event.target.id==='wl2AddModal')closeWl2Add();}});
    async function refreshNearbyNetworks(button){{
      const old=button.textContent;button.disabled=true;button.textContent='Scanning…';
      const target=document.getElementById('wl2NearbyNetworks');
      try{{
        const response=await fetch('/wifilink2/api/scan?ts='+Date.now(),{{cache:'no-store'}});
        const data=await response.json();
        if(data.error){{target.innerHTML='<p class="bad"></p>';target.querySelector('p').textContent=data.error;return;}}
        target.innerHTML='';
        (data.networks||[]).forEach(item=>{{
          const row=document.createElement('div');row.className='wl2-nearby-row';
          const info=document.createElement('div');const title=document.createElement('b');title.textContent=item.ssid||'(hidden)';const meta=document.createElement('div');meta.className='small';meta.textContent=String(item.signal)+' dBm · '+String(item.security||'Unknown');info.append(title,meta);
          let action;if(configuredWl2Ssids.has(item.ssid||'')){{action=document.createElement('span');action.className='pill active';action.textContent='Configured';}}else{{action=document.createElement('button');action.type='button';action.className='wl2-secondary';action.textContent='Add';action.onclick=()=>openWl2Add(item.ssid||'',String(item.security||'').toLowerCase()==='open');}}
          row.append(info,action);target.appendChild(row);
        }});
        if(!(data.networks||[]).length) target.innerHTML='<p class="small">No nearby networks were returned.</p>';
      }}catch(error){{target.innerHTML='<p class="bad">Scan failed.</p>';}}
      finally{{button.disabled=false;button.textContent=old;}}
    }}
    async function refreshWl2Status(){{
      try{{
        const response=await fetch('/wifilink2/api/status?ts='+Date.now(),{{cache:'no-store'}});const data=await response.json();
        const online=document.getElementById('wl2-online');const temp=document.getElementById('wl2-temperature');const error=document.getElementById('wl2-status-error');
        online.textContent=data.online?'Online':'Unavailable';online.className='wl2-kpi-value '+(data.online?'ok':'bad');
        temp.textContent=(typeof data.temperature_c==='number')?data.temperature_c.toFixed(1)+' °C':'Unavailable';error.textContent=data.error||'';
      }}catch(error){{document.getElementById('wl2-online').textContent='Unavailable';document.getElementById('wl2-temperature').textContent='Unavailable';}}
    }}
    refreshWl2Status();setInterval(refreshWl2Status,5000);
    </script>
    """
    return body


_wl2_original_page = page

def page(title, body):
    document = _wl2_original_page(title, body)
    if 'href="/wifilink2"' not in document:
        document = document.replace('<a href="/video">Video</a>', '<a href="/video">Video</a>\n<a href="/wifilink2">WiFiLink2</a>')
    return document


def _wl2_send_json(handler, payload, status=200):
    raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def _wl2_send_html(handler, body, status=200):
    raw = page("WiFiLink2 Settings", setup_banner() + body).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "text/html; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def _wl2_set_action(message):
    try:
        with open("/tmp/siyi_wifilink2_last_action", "w", encoding="utf-8") as handle:
            handle.write(str(message))
    except Exception:
        pass


def _wl2_redirect(handler, tab="wifi"):
    safe_tab = tab if tab in {"wifi", "camera", "device", "diagnostics"} else "wifi"
    handler.send_response(303)
    handler.send_header("Location", "/wifilink2#" + safe_tab)
    handler.end_headers()


def _wl2_parse_post(handler):
    length = int(handler.headers.get("Content-Length", "0") or "0")
    if length > 262144:
        raise ValueError("Request is too large")
    raw = handler.rfile.read(length).decode("utf-8", errors="replace")
    parsed = urllib.parse.parse_qs(raw, keep_blank_values=True)
    return {key: values[-1] if values else "" for key, values in parsed.items()}


_wl2_previous_get = H.do_GET

def _wl2_do_GET(self):
    path = urllib.parse.urlparse(self.path).path
    if software_update_lock_active():
        return _wl2_previous_get(self)
    if path == "/wifilink2":
        try:
            return _wl2_send_html(self, wifilink2_settings_page())
        except Exception as exc:
            return _wl2_send_html(self, "<h1>WiFiLink2 Settings</h1><div class='card'><p class='bad'>Page failed: " + esc(exc) + "</p></div>", 500)
    if path == "/wifilink2/api/status":
        return _wl2_send_json(self, _wl2_temperature_status())
    if path == "/wifilink2/api/scan":
        try:
            return _wl2_send_json(self, _wl2_scan_networks())
        except Exception as exc:
            return _wl2_send_json(self, {"networks": [], "error": str(exc)}, 502)
    return _wl2_previous_get(self)

H.do_GET = _wl2_do_GET


_wl2_previous_post = H.do_POST

def _wl2_do_POST(self):
    path = urllib.parse.urlparse(self.path).path
    wl2_paths = {
        "/wifilink2/native-network/save",
        "/wifilink2/native-network/delete",
        "/wifilink2/camera/apply",
        "/wifilink2/device/save",
        "/wifilink2/device/test",
    }
    if path not in wl2_paths:
        return _wl2_previous_post(self)
    if software_update_lock_active():
        return _wl2_previous_post(self)
    try:
        params = _wl2_parse_post(self)
        redirect_tab = "wifi"
        if path == "/wifilink2/native-network/save":
            result = _wl2_native_network_save(params)
            _wl2_set_action(result)
        elif path == "/wifilink2/native-network/delete":
            result = _wl2_native_network_delete(params)
            _wl2_set_action(result)
        elif path == "/wifilink2/camera/apply":
            redirect_tab = "camera"
            result = _wl2_camera_apply(params)
            _wl2_set_action("WiFiLink2 camera settings applied" + ((": " + result) if result else ""))
        elif path == "/wifilink2/device/save":
            redirect_tab = "device"
            result = _wl2_device_settings_save(params)
            _wl2_set_action(result)
        elif path == "/wifilink2/device/test":
            redirect_tab = "device"
            result = _wl2_device_connection_test()
            _wl2_set_action(result)
        return _wl2_redirect(self, redirect_tab)
    except Exception as exc:
        failed_tab = "camera" if path == "/wifilink2/camera/apply" else ("device" if path.startswith("/wifilink2/device/") else "wifi")
        _wl2_set_action("WiFiLink2 change failed: " + str(exc))
        return _wl2_redirect(self, failed_tab)

H.do_POST = _wl2_do_POST
# WIFILINK2_SETTINGS_PAGE_V1_END



# CONTROL_CENTER_WORKSPACES_V9_START
# Presentation-only workspace shell. Existing configuration endpoints and services remain unchanged.

_v9_previous_page = page
_v9_previous_get = H.do_GET

def _v9_nav_html():
    wizard = "" if setup_is_complete() else "<a class='v9-nav-link' data-workspace='system' href='/first_setup'><span class='v9-nav-icon'>W</span><span>Setup Wizard</span></a>"
    return f"""
<nav class='v9-sidebar'>
  <div class='v9-nav-label'>Workspaces</div>
  <a class='v9-nav-link' data-workspace='dashboard' href='/'><span class='v9-nav-icon'>O</span><span>Overview</span></a>
  <a class='v9-nav-link' data-workspace='connectivity' href='/connectivity'><span class='v9-nav-icon'>C</span><span>Connectivity</span></a>
  <a class='v9-nav-link' data-workspace='media' href='/media'><span class='v9-nav-icon'>V</span><span>Cameras &amp; Video</span></a>
  <a class='v9-nav-link' data-workspace='aircraft' href='/aircraft'><span class='v9-nav-icon'>A</span><span>Aircraft</span></a>
  <a class='v9-nav-link' data-workspace='system' href='/system'><span class='v9-nav-icon'>S</span><span>System</span></a>
  {wizard}
  <div class='v9-nav-foot'>
    <span>SIYI Pi Control Center</span>
    <span class='small'>Control Center 4.0.3</span>
  </div>
</nav>
"""

def page(title, body):
    document = _v9_previous_page(title, body)
    document = re.sub(r"<nav>.*?</nav>", _v9_nav_html(), document, count=1, flags=re.S)

    v9_css = r"""
/* CONTROL_CENTER_WORKSPACES_V9 */
header{height:42px;padding:12px 22px;display:flex;align-items:center;background:linear-gradient(90deg,#020617,#071226);box-shadow:0 8px 28px rgba(0,0,0,.25)}
.v9-sidebar{width:210px;background:#020617;height:calc(100vh - 66px);position:fixed;left:0;top:66px;padding:16px 13px;border-right:1px solid #334155;overflow-y:auto;box-sizing:border-box}
.v9-nav-label{font-size:11px;text-transform:uppercase;letter-spacing:.12em;color:#64748b;padding:2px 11px 10px}
.v9-nav-link{display:flex!important;align-items:center;gap:11px;color:#cbd5e1!important;text-decoration:none;padding:11px 12px!important;border-radius:10px;margin-bottom:5px!important;border:1px solid transparent}
.v9-nav-link:hover{background:#111827!important;color:white!important;border-color:#334155}
.v9-nav-link.active{background:linear-gradient(135deg,#1d4ed8,#2563eb)!important;color:white!important;border-color:#60a5fa;box-shadow:0 9px 25px rgba(37,99,235,.22)}
.v9-nav-icon{display:grid;place-items:center;width:27px;height:27px;border-radius:8px;background:#111827;border:1px solid #334155;font-size:12px;font-weight:800;flex:0 0 auto}
.v9-nav-link.active .v9-nav-icon{background:rgba(2,6,23,.28);border-color:rgba(255,255,255,.28)}
.v9-nav-foot{position:absolute;left:14px;right:14px;bottom:14px;border-top:1px solid #1e293b;padding-top:12px;color:#64748b;font-size:12px;display:flex;flex-direction:column;gap:4px}
main{margin-left:210px;padding:92px 26px 30px 26px;max-width:1700px}
.v9-hero{display:flex;justify-content:space-between;gap:20px;align-items:flex-start;margin-bottom:18px;padding:20px 22px;border:1px solid #334155;border-radius:16px;background:linear-gradient(135deg,#111827,#0b1220)}
.v9-hero h1{margin:0 0 7px;font-size:29px}
.v9-hero p{margin:0;color:#94a3b8;max-width:850px;line-height:1.5}
.v9-hero-badge{border-radius:999px;padding:7px 11px;background:#172554;color:#bfdbfe;border:1px solid #1d4ed8;font-size:12px;font-weight:700;white-space:nowrap}
.v9-dashboard-grid{display:grid;grid-template-columns:repeat(2,minmax(280px,1fr));gap:16px}
.v9-status-card{background:#111827;border:1px solid #334155;border-radius:15px;padding:18px;min-height:150px;display:flex;flex-direction:column}
.v9-status-card h2{margin:0 0 5px;font-size:19px}
.v9-status-card .v9-card-sub{color:#94a3b8;font-size:13px;margin-bottom:14px}
.v9-status-list{display:grid;grid-template-columns:minmax(120px,.7fr) 1.3fr;gap:8px 13px;font-size:14px}
.v9-status-list .label{color:#94a3b8}
.v9-status-card .v9-card-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:auto;padding-top:16px}
.v9-link-button{display:inline-flex;align-items:center;justify-content:center;background:#2563eb;color:white!important;text-decoration:none;border-radius:9px;padding:9px 13px;font-size:13px;font-weight:700}
.v9-link-button.secondary{background:#1e293b;border:1px solid #475569}
.v9-tabs-shell{background:#0b1220;border:1px solid #334155;border-radius:16px;overflow:hidden}
.v9-tabs{display:flex;gap:6px;flex-wrap:wrap;padding:12px;background:#111827;border-bottom:1px solid #334155}
.v9-tab-button{background:#1e293b;border:1px solid #334155;color:#cbd5e1;padding:9px 13px;border-radius:9px;margin:0}
.v9-tab-button:hover{background:#263449}
.v9-tab-button.active{background:#2563eb;border-color:#60a5fa;color:white}
.v9-tab-tools{margin-left:auto;display:flex;gap:7px}
.v9-frame-panel{display:none;background:#0f172a}
.v9-frame-panel.active{display:block}
.v9-workspace-frame{display:block;width:100%;height:calc(100vh - 225px);min-height:620px;border:0;background:#0f172a}
.v9-native-panel{padding:18px;min-height:620px}
.v9-context-strip{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:-4px 0 14px;padding:10px 13px;border:1px solid #334155;border-radius:10px;background:#0b1220;color:#94a3b8;font-size:13px}
.v9-context-strip a{color:#93c5fd;text-decoration:none;font-weight:700}
body.v9-embedded{background:#0f172a}
body.v9-embedded header,body.v9-embedded .v9-sidebar{display:none!important}
body.v9-embedded main{margin:0!important;padding:12px!important;max-width:none!important}
body.v9-embedded .v9-context-strip{display:none!important}
body.v9-embedded .card:first-child{margin-top:0}
@media(max-width:900px){
  .v9-sidebar{width:74px;padding:14px 9px}
  .v9-nav-link span:last-child,.v9-nav-label,.v9-nav-foot{display:none}
  .v9-nav-link{justify-content:center;padding:9px!important}
  main{margin-left:74px;padding-left:14px;padding-right:14px}
  .v9-dashboard-grid{grid-template-columns:1fr}
  .v9-hero{flex-direction:column}
}
"""
    document = document.replace("</style></head>", v9_css + "\n</style></head>", 1)

    v9_js = r"""
<script>
(function(){
  const params=new URLSearchParams(location.search);
  const embedded=(window.self!==window.top)||params.get('embed')==='1';
  if(embedded) document.body.classList.add('v9-embedded');

  const path=location.pathname;
  let workspace='dashboard';
  if(path==='/connectivity'||['/wifi','/network','/zerotier','/endpoints','/wifilink2'].includes(path)) workspace='connectivity';
  else if(path==='/media'||['/video','/camera_controls','/unigcs_controls','/camera_sd'].includes(path)) workspace='media';
  else if(path==='/aircraft'||['/operations','/mavlink','/buttons','/flaps','/parameters'].includes(path)) workspace='aircraft';
  else if(path==='/system'||['/logs','/software_update','/first_setup','/cpu_temp_voice'].includes(path)) workspace='system';
  document.querySelectorAll('.v9-nav-link').forEach(a=>a.classList.toggle('active',a.dataset.workspace===workspace));

  if(embedded){
    const topMap={
      '/wifi':'/connectivity?tab=pi',
      '/network':'/connectivity?tab=pi',
      '/wifilink2':'/connectivity?tab=airlink',
      '/zerotier':'/connectivity?tab=remote',
      '/endpoints':'/connectivity?tab=hosts',
      '/video':'/media?tab=video',
      '/camera_controls':'/media?tab=siyi-camera',
      '/unigcs_controls':'/media?tab=siyi-camera',
      '/camera_sd':'/media?tab=storage',
      '/mavlink':'/aircraft?tab=mavlink',
      '/buttons':'/aircraft?tab=buttons',
      '/flaps':'/aircraft?tab=flaps',
      '/parameters':'/aircraft?tab=parameters',
      '/logs':'/system?tab=diagnostics',
      '/software_update':'/system?tab=update'
    };
    document.addEventListener('click',event=>{
      const link=event.target.closest('a[href]');
      if(!link||link.target==='_blank')return;
      let url;
      try{url=new URL(link.href,location.origin)}catch(_e){return}
      if(url.origin===location.origin&&topMap[url.pathname]){
        event.preventDefault();
        window.top.location.href=topMap[url.pathname];
      }
    });
  }

  if(!embedded && !['/','/connectivity','/media','/aircraft','/system'].includes(path)){
    const labels={
      '/wifi':['Connectivity','Pi Wi-Fi','/connectivity?tab=pi'],
      '/zerotier':['Connectivity','Remote access','/connectivity?tab=remote'],
      '/endpoints':['Connectivity','Hosts & routing','/connectivity?tab=hosts'],
      '/wifilink2':['Connectivity','Air Link','/connectivity?tab=airlink'],
      '/video':['Cameras & Video','Video sources','/media?tab=video'],
      '/camera_controls':['Cameras & Video','SIYI camera','/media?tab=siyi-camera'],
      '/camera_sd':['Cameras & Video','Camera storage','/media?tab=storage'],
      '/mavlink':['Aircraft','MAVLink','/aircraft?tab=mavlink'],
      '/buttons':['Aircraft','Button mapping','/aircraft?tab=buttons'],
      '/flaps':['Aircraft','Flaps','/aircraft?tab=flaps'],
      '/parameters':['Aircraft','ArduPlane parameters','/aircraft?tab=parameters'],
      '/logs':['System','Diagnostics','/system?tab=diagnostics'],
      '/software_update':['System','Software update','/system?tab=update']
    };
    if(labels[path]){
      const [group,item,back]=labels[path];
      const strip=document.createElement('div');strip.className='v9-context-strip';
      strip.innerHTML='<span>'+group+' / <b style="color:#e2e8f0">'+item+'</b></span><a href="'+back+'">Back to '+group+'</a>';
      const main=document.querySelector('main');if(main)main.prepend(strip);
    }
  }

  const wl2Mode=params.get('workspace');
  if(wl2Mode && typeof activateWl2Tab==='function'){
    const hide=(selector)=>document.querySelectorAll(selector).forEach(el=>el.style.display='none');
    const head=document.querySelector('.wl2-head h1');
    const desc=document.querySelector('.wl2-head .small');
    if(wl2Mode==='camera'){
      hide(".wl2-tabbtn:not([data-tab='camera'])");
      hide(".wl2-tabpanel:not([data-panel='camera'])");
      const tabs=document.querySelector('.wl2-tabs');if(tabs)tabs.style.display='none';
      if(head)head.textContent='Air Link Camera';
      if(desc)desc.textContent='Onboard camera image controls and active values.';
      activateWl2Tab('camera');
    }else if(wl2Mode==='connectivity'){
      hide(".wl2-tabbtn[data-tab='camera']");
      hide(".wl2-tabpanel[data-panel='camera']");
      if(head)head.textContent='Air Link Connectivity';
      if(desc)desc.textContent='Wi-Fi profiles, link credentials and device diagnostics.';
      const requested=(location.hash||'').replace('#','');
      activateWl2Tab(['wifi','device','diagnostics'].includes(requested)?requested:'wifi');
    }
  }
})();
</script>
"""
    document = document.replace("</body>", v9_js + "\n</body>", 1)
    return document


def _v9_redirect_response(handler, location):
    handler.send_response(303)
    handler.send_header("Location", location)
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()


def _v9_is_embedded(handler, query):
    if str(query.get("embed") or "") == "1":
        return True
    return str(handler.headers.get("Sec-Fetch-Dest") or "").lower() == "iframe"


def _v9_safe_text(value, fallback="Unavailable"):
    text = str(value or "").strip()
    return text if text else fallback


def _v9_dashboard_page():
    cfg = video_source_read_config()
    status = video_source_read_status()
    source_names = video_source_names(cfg)
    active_id = str(cfg.get("source") or "siyi_rtsp")
    active_name = source_names.get(active_id, active_id)
    video_state = _v9_safe_text(status.get("state") or status.get("status"), "Unknown")
    pi_ssid = _v9_safe_text(sh("iwgetid -r 2>/dev/null || true"), "Not connected")
    pi_ip = _v9_safe_text(sh("hostname -I 2>/dev/null | awk '{print $1}'"), "Unavailable")
    zt_ip = _v9_safe_text(zt_current_ip(), "Unavailable")

    wl_ssid = "Unavailable"
    wl_signal = "Unavailable"
    wl_rtsp = "Unknown"
    try:
        inv = _wl2_native_wifi_inventory()
        runtime = _wl2_device_runtime_summary()
        wl_ssid = _v9_safe_text(inv.get("active_ssid"), "Not connected")
        if isinstance(inv.get("signal_dbm"), (int, float)):
            pct = inv.get("signal_percent")
            wl_signal = f"{int(inv['signal_dbm'])} dBm" + (f" · {pct}%" if isinstance(pct, int) else "")
        wl_rtsp = _v9_safe_text(runtime.get("rtsp_state"), "Unknown").title()
    except Exception:
        pass

    mode = "Unavailable"
    try:
        mode_data = flight_mode_state_read_once()
        mode = _v9_safe_text(mode_data.get("mode") if isinstance(mode_data, dict) else "", "Unavailable")
    except Exception:
        pass

    last_action = _v9_safe_text(read_file("/tmp/siyi_webui_last_action").strip(), "No recent system action")
    wl_action = _v9_safe_text(read_file("/tmp/siyi_wifilink2_last_action").strip(), "No recent Air Link action")

    return f"""
<div class='v9-hero'>
  <div><h1>System overview</h1><p>One starting point for connectivity, cameras, aircraft controls and system maintenance. Existing backend functions are unchanged.</p></div>
  <span class='v9-hero-badge'>Control Center 4.0.3</span>
</div>
<div class='v9-dashboard-grid'>
  <section class='v9-status-card'>
    <h2>Connectivity</h2><div class='v9-card-sub'>Raspberry Pi, Air Link and remote access</div>
    <div class='v9-status-list'>
      <span class='label'>Pi Wi-Fi</span><b>{esc(pi_ssid)}</b>
      <span class='label'>Pi address</span><span>{esc(pi_ip)}</span>
      <span class='label'>Air Link network</span><b>{esc(wl_ssid)}</b>
      <span class='label'>Air Link signal</span><span>{esc(wl_signal)}</span>
      <span class='label'>ZeroTier address</span><span>{esc(zt_ip)}</span>
    </div>
    <div class='v9-card-actions'><a class='v9-link-button' href='/connectivity'>Open Connectivity</a></div>
  </section>

  <section class='v9-status-card'>
    <h2>Cameras &amp; Video</h2><div class='v9-card-sub'>Active source, output and onboard cameras</div>
    <div class='v9-status-list'>
      <span class='label'>Active source</span><b>{esc(active_name)}</b>
      <span class='label'>Video state</span><span>{esc(video_state)}</span>
      <span class='label'>QGC URL</span><span>rtsp://192.168.191.10:8554/main.264</span>
      <span class='label'>Air Link RTSP</span><span>{esc(wl_rtsp)}</span>
    </div>
    <div class='v9-card-actions'><a class='v9-link-button' href='/media'>Open Cameras &amp; Video</a></div>
  </section>

  <section class='v9-status-card'>
    <h2>Aircraft</h2><div class='v9-card-sub'>Operational controls and flight configuration</div>
    <div class='v9-status-list'>
      <span class='label'>Flight mode</span><b>{esc(mode)}</b>
      <span class='label'>Battery</span><span>{esc(battery_status())}</span>
      <span class='label'>Controls</span><span>Buttons, flaps and parameters</span>
      <span class='label'>Operations</span><span>Service restart controls</span>
    </div>
    <div class='v9-card-actions'><a class='v9-link-button' href='/aircraft'>Open Aircraft</a><a class='v9-link-button secondary' href='/aircraft?tab=operations'>Operations</a></div>
  </section>

  <section class='v9-status-card'>
    <h2>System</h2><div class='v9-card-sub'>Health, diagnostics and software lifecycle</div>
    <div>{system_summary()}</div>
    <div class='v9-status-list' style='margin-top:14px'>
      <span class='label'>Last system action</span><span>{esc(last_action)}</span>
      <span class='label'>Last Air Link action</span><span>{esc(wl_action)}</span>
    </div>
    <div class='v9-card-actions'><a class='v9-link-button' href='/system'>Open System</a><a class='v9-link-button secondary' href='/system?tab=diagnostics'>Diagnostics</a></div>
  </section>
</div>
"""


def _v9_workspace_page(title, description, tabs, active):
    valid_ids = [item["id"] for item in tabs]
    if active not in valid_ids:
        active = valid_ids[0]
    buttons = []
    panels = []
    for item in tabs:
        item_id = item["id"]
        selected = item_id == active
        buttons.append(
            "<button type='button' class='v9-tab-button" + (" active" if selected else "") +
            "' data-v9-tab='" + esc(item_id) + "'>" + esc(item["label"]) + "</button>"
        )
        if item.get("html") is not None:
            content = "<div class='v9-native-panel'>" + str(item["html"]) + "</div>"
        else:
            src = str(item.get("src") or "")
            content = (
                "<iframe class='v9-workspace-frame' title='" + esc(item["label"]) +
                "' data-src='" + esc(src) + "'" +
                (" src='" + esc(src) + "'" if selected else "") +
                " loading='eager'></iframe>"
            )
        panels.append(
            "<section class='v9-frame-panel" + (" active" if selected else "") +
            "' data-v9-panel='" + esc(item_id) + "'>" + content + "</section>"
        )

    return f"""
<div class='v9-hero'>
  <div><h1>{esc(title)}</h1><p>{esc(description)}</p></div>
  <span class='v9-hero-badge'>Unified workspace</span>
</div>
<div class='v9-tabs-shell'>
  <div class='v9-tabs'>{''.join(buttons)}
    <div class='v9-tab-tools'><button type='button' class='v9-tab-button' id='v9-refresh-tab'>Reload current tab</button></div>
  </div>
  {''.join(panels)}
</div>
<script>
(function(){{
  const buttons=[...document.querySelectorAll('[data-v9-tab]')];
  const panels=[...document.querySelectorAll('[data-v9-panel]')];
  function selectTab(id,update=true){{
    if(!buttons.some(b=>b.dataset.v9Tab===id))id={__import__('json').dumps(active)};
    buttons.forEach(b=>b.classList.toggle('active',b.dataset.v9Tab===id));
    panels.forEach(panel=>{{
      const on=panel.dataset.v9Panel===id;panel.classList.toggle('active',on);
      if(on){{
        const frame=panel.querySelector('iframe[data-src]');
        if(frame&&!frame.getAttribute('src'))frame.setAttribute('src',frame.dataset.src);
      }}
    }});
    if(update){{
      const url=new URL(location.href);url.searchParams.set('tab',id);history.replaceState(null,'',url);
      try{{localStorage.setItem('siyi-workspace-'+location.pathname,id)}}catch(_e){{}}
    }}
  }}
  buttons.forEach(b=>b.addEventListener('click',()=>selectTab(b.dataset.v9Tab)));
  document.getElementById('v9-refresh-tab').addEventListener('click',()=>{{
    const panel=document.querySelector('.v9-frame-panel.active');const frame=panel&&panel.querySelector('iframe');
    if(frame)frame.contentWindow.location.reload();
    else location.reload();
  }});
  let requested=new URLSearchParams(location.search).get('tab');
  if(!requested){{try{{requested=localStorage.getItem('siyi-workspace-'+location.pathname)}}catch(_e){{}}}}
  selectTab(requested||{__import__('json').dumps(active)},false);
}})();
</script>
"""


def _v9_connectivity_page(active):
    tabs = [
        {"id":"pi","label":"Pi Wi-Fi","src":"/wifi?embed=1"},
        {"id":"airlink","label":"Air Link","src":"/wifilink2?embed=1&workspace=connectivity#wifi"},
        {"id":"remote","label":"Remote access","src":"/zerotier?embed=1"},
        {"id":"hosts","label":"Hosts & routing","src":"/endpoints?embed=1"},
    ]
    return _v9_workspace_page(
        "Connectivity",
        "All network configuration in one place: Raspberry Pi Wi-Fi, Air Link profiles, ZeroTier and destination hosts.",
        tabs, active,
    )


def _v9_media_page(active):
    tabs = [
        {"id":"video","label":"Video output & sources","src":"/video?embed=1"},
        {"id":"siyi-camera","label":"SIYI Camera","src":"/camera_controls?embed=1"},
        {"id":"airlink-camera","label":"Air Link Camera","src":"/wifilink2?embed=1&workspace=camera#camera"},
        {"id":"storage","label":"Camera storage","src":"/camera_sd?embed=1"},
    ]
    return _v9_workspace_page(
        "Cameras & Video",
        "Video selection, stream routing, both camera-control surfaces and camera storage in one workspace.",
        tabs, active,
    )


def _v9_aircraft_page(active):
    tabs = [
        {"id":"operations","label":"Operations","src":"/operations?embed=1"},
        {"id":"mavlink","label":"MAVLink","src":"/mavlink?embed=1"},
        {"id":"buttons","label":"Buttons","src":"/buttons?embed=1"},
        {"id":"flaps","label":"Flaps","src":"/flaps?embed=1"},
        {"id":"parameters","label":"Parameters","src":"/parameters?embed=1"},
    ]
    return _v9_workspace_page(
        "Aircraft",
        "Operational controls, telemetry routing, button actions, flap control and ArduPlane parameters.",
        tabs, active,
    )


def _v9_system_overview():
    return f"""
<div class='card'>
  <h2>System health</h2>
  {system_summary()}
  <p class='small'>The service controls below are the existing live controls. This UI patch does not change service definitions.</p>
  <table><tr><th>Service</th><th>Status</th><th>Action</th></tr>{service_rows()}</table>
</div>
<div class='card'>
  <h2>UI rollback</h2>
  <p>This workspace layout is backed up before installation. Use the supplied Mac rollback script to restore the exact previous V8 interface.</p>
</div>
"""


def _v9_system_page(active):
    tabs = [
        {"id":"health","label":"Health & services","html":_v9_system_overview()},
        {"id":"diagnostics","label":"Diagnostics","src":"/logs?embed=1"},
        {"id":"update","label":"Software update","src":"/software_update?embed=1"},
    ]
    if not setup_is_complete():
        tabs.append({"id":"setup","label":"Setup wizard","src":"/first_setup?embed=1"})
    return _v9_workspace_page(
        "System",
        "Service health, diagnostics, updates and setup—kept separate from flight and media configuration.",
        tabs, active,
    )


def _v9_send_workspace(handler, title, body):
    raw = page(title, setup_banner() + body).encode("utf-8")
    handler.send_response(200)
    handler.send_header("Content-Type", "text/html; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def _v9_do_GET(self):
    parsed = urllib.parse.urlparse(self.path)
    path = parsed.path
    query = dict(urllib.parse.parse_qsl(parsed.query, keep_blank_values=True))
    embedded = _v9_is_embedded(self, query)

    if software_update_lock_active():
        return _v9_previous_get(self)

    if path == "/":
        if setup_should_force():
            return _v9_redirect_response(self, "/first_setup")
        return _v9_send_workspace(self, "Overview", _v9_dashboard_page())

    if path == "/connectivity":
        return _v9_send_workspace(self, "Connectivity", _v9_connectivity_page(query.get("tab","pi")))
    if path == "/media":
        return _v9_send_workspace(self, "Cameras & Video", _v9_media_page(query.get("tab","video")))
    if path == "/aircraft":
        return _v9_send_workspace(self, "Aircraft", _v9_aircraft_page(query.get("tab","operations")))
    if path == "/system":
        return _v9_send_workspace(self, "System", _v9_system_page(query.get("tab","health")))

    if path == "/operations":
        if not embedded:
            return _v9_redirect_response(self, "/aircraft?tab=operations")
        old_path = self.path
        self.path = "/"
        try:
            return _v9_previous_get(self)
        finally:
            self.path = old_path

    legacy_map = {
        "/wifi": "/connectivity?tab=pi",
        "/network": "/connectivity?tab=pi",
        "/wifilink2": "/connectivity?tab=airlink",
        "/zerotier": "/connectivity?tab=remote",
        "/endpoints": "/connectivity?tab=hosts",
        "/video": "/media?tab=video",
        "/camera_controls": "/media?tab=siyi-camera",
        "/unigcs_controls": "/media?tab=siyi-camera",
        "/camera_sd": "/media?tab=storage",
        "/mavlink": "/aircraft?tab=mavlink",
        "/buttons": "/aircraft?tab=buttons",
        "/flaps": "/aircraft?tab=flaps",
        "/parameters": "/aircraft?tab=parameters",
        "/logs": "/system?tab=diagnostics",
        "/software_update": "/system?tab=update",
    }
    if path in legacy_map and not embedded and not query.get("workspace"):
        return _v9_redirect_response(self, legacy_map[path])

    exact_embedded_paths = set(legacy_map) | {"/first_setup"}
    if embedded and path in exact_embedded_paths and path != "/wifilink2":
        old_path = self.path
        self.path = path
        try:
            return _v9_previous_get(self)
        finally:
            self.path = old_path

    return _v9_previous_get(self)


H.do_GET = _v9_do_GET


def _wl2_redirect(handler, tab="wifi"):
    if tab == "camera":
        location = "/wifilink2?workspace=camera#camera"
    else:
        safe_tab = tab if tab in {"wifi", "device", "diagnostics"} else "wifi"
        location = "/wifilink2?workspace=connectivity#" + safe_tab
    handler.send_response(303)
    handler.send_header("Location", location)
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()

# CONTROL_CENTER_WORKSPACES_V9_END



# CONTROL_CENTER_HARMONIZATION_V10_START
# Unified service operations, harmonized Pi/Air Link Wi-Fi, and single-scroll workspace frames.

_v10_previous_page = page
_v10_previous_get = H.do_GET
_v10_previous_dashboard_page = _v9_dashboard_page


def _v10_nmcli_split(line):
    fields = []
    current = []
    escaped = False
    for char in str(line or ""):
        if escaped:
            current.append(char)
            escaped = False
        elif char == "\\":
            escaped = True
        elif char == ":":
            fields.append("".join(current))
            current = []
        else:
            current.append(char)
    if escaped:
        current.append("\\")
    fields.append("".join(current))
    return fields


def _v10_pi_wifi_scan(refresh=False):
    def read_scan():
        raw = sh("nmcli -t -f IN-USE,SSID,SIGNAL,SECURITY dev wifi list ifname wlan0 2>/dev/null")
        networks = {}
        for raw_line in raw.splitlines():
            parts = _v10_nmcli_split(raw_line)
            if len(parts) < 4:
                continue
            in_use = parts[0]
            ssid = parts[1].strip()
            signal_text = parts[2]
            security = parts[3].strip()
            if not ssid or ssid == "--":
                continue
            try:
                signal = max(0, min(100, int(signal_text)))
            except Exception:
                signal = 0
            item = networks.get(ssid)
            if item is None or signal > item["signal"]:
                networks[ssid] = {
                    "ssid": ssid,
                    "signal": signal,
                    "security": "Open" if security in {"", "--"} else security,
                    "current": in_use.strip() == "*",
                }
            elif in_use.strip() == "*":
                item["current"] = True

        return sorted(
            networks.values(),
            key=lambda item: (
                not item["current"],
                -int(item["signal"]),
                item["ssid"].lower(),
            ),
        )

    if not refresh:
        return read_scan()

    # NetworkManager rescan is asynchronous. Waiting only one second can
    # return the currently connected SSID before the new scan is complete.
    before_stamp = sh(
        "nmcli -g GENERAL.LAST-SCAN device show wlan0 2>/dev/null || true"
    ).strip()
    sh(
        "timeout 12s sudo -n nmcli device wifi rescan ifname wlan0 "
        ">/dev/null 2>&1 || true"
    )

    deadline = time.monotonic() + 10.0
    best = read_scan()
    previous_signature = None
    stable_polls = 0

    while time.monotonic() < deadline:
        time.sleep(0.75)
        current = read_scan()
        if len(current) > len(best):
            best = current

        signature = tuple(
            (item.get("ssid"), item.get("signal"), item.get("security"))
            for item in current
        )
        if signature and signature == previous_signature:
            stable_polls += 1
        else:
            previous_signature = signature
            stable_polls = 0

        after_stamp = sh(
            "nmcli -g GENERAL.LAST-SCAN device show wlan0 2>/dev/null || true"
        ).strip()
        stamp_changed = bool(
            after_stamp
            and after_stamp not in {"0", "--"}
            and after_stamp != before_stamp
        )
        has_non_current = any(not item.get("current") for item in current)

        if stamp_changed:
            time.sleep(0.5)
            final = read_scan()
            return final if len(final) >= len(best) else best

        if has_non_current and stable_polls >= 1:
            return current if len(current) >= len(best) else best

    return best or read_scan()


def _v10_pi_wifi_current_signal_dbm():
    text = sh("iw dev wlan0 link 2>/dev/null | sed -n 's/^[[:space:]]*signal:[[:space:]]*\\(-\\?[0-9][0-9]*\\).*/\\1/p' | head -n1")
    try:
        return int(text.strip())
    except Exception:
        return None


def _v10_pi_wifi_inventory(refresh=False):
    scan = _v10_pi_wifi_scan(refresh=refresh)
    scan_map = {item["ssid"]: item for item in scan}

    active_ssid = sh("iwgetid -r 2>/dev/null || true").strip()
    active_conn = sh("nmcli -g GENERAL.CONNECTION dev show wlan0 2>/dev/null || true").strip()
    ip_address = sh("ip -4 -o addr show dev wlan0 2>/dev/null | awk '{print $4}' | cut -d/ -f1 | head -n1").strip()
    manager_state = sh("systemctl is-active NetworkManager 2>/dev/null || true").strip() or "unknown"
    current_dbm = _v10_pi_wifi_current_signal_dbm()

    raw_profiles = sh("nmcli -t -f NAME,TYPE,DEVICE,AUTOCONNECT connection show 2>/dev/null")
    profiles = []
    for raw_line in raw_profiles.splitlines():
        parts = _v10_nmcli_split(raw_line)
        if len(parts) < 4:
            continue
        name, kind, device, autoconnect = parts[:4]
        if kind not in {"wifi", "802-11-wireless"}:
            continue

        quoted_name = shlex.quote(name)
        ssid = sh(
            "nmcli -g 802-11-wireless.ssid connection show "
            + quoted_name
            + " 2>/dev/null || true"
        ).strip()
        if not ssid and (name == active_conn or device == "wlan0"):
            ssid = active_ssid
        if not ssid:
            ssid = name

        priority_text = sh(
            "nmcli -g connection.autoconnect-priority connection show "
            + quoted_name
            + " 2>/dev/null || true"
        ).strip()
        try:
            priority = int(priority_text or "0")
        except Exception:
            priority = 0

        visible_item = scan_map.get(ssid) or {}
        current = bool(name == active_conn or device == "wlan0" or visible_item.get("current"))
        enabled = str(autoconnect).lower() == "yes"
        password = str(wifi_pw_get(name) or "")
        profiles.append(
            {
                "ssid": ssid,
                "name": name,
                "current": current,
                "enabled": enabled,
                "visible": bool(visible_item),
                "signal": int(visible_item.get("signal") or 0),
                "security": str(visible_item.get("security") or "Unknown"),
                "priority": priority,
                "password": password,
                "password_known": bool(password),
                "system": name.startswith("netplan-"),
            }
        )

    profiles.sort(
        key=lambda item: (
            not item["current"],
            not item["enabled"],
            -int(item["priority"]),
            item["ssid"].lower(),
        )
    )

    current_signal = None
    if active_ssid and active_ssid in scan_map:
        current_signal = int(scan_map[active_ssid].get("signal") or 0)

    return {
        "active_ssid": active_ssid,
        "active_connection": active_conn,
        "ip_address": ip_address,
        "manager_state": manager_state,
        "signal_percent": current_signal,
        "signal_dbm": current_dbm,
        "profiles": profiles,
        "scan": scan,
    }


def _v10_wifi_signal_bars(percent):
    try:
        value = max(0, min(100, int(percent)))
    except Exception:
        return "▯▯▯▯▯"
    filled = max(0, min(5, int(round(value / 20.0))))
    return "▮" * filled + "▯" * (5 - filled)


def _v10_pi_wifi_profile_card(item, index):
    current = bool(item.get("current"))
    visible = bool(item.get("visible"))
    enabled = bool(item.get("enabled"))
    system = bool(item.get("system"))
    signal = int(item.get("signal") or 0)

    if current:
        label, badge = "Connected", "active"
    elif not enabled:
        label, badge = "Disabled", "bad"
    elif visible:
        label, badge = "Available", "warn"
    else:
        label, badge = "Out of range", "inactive"

    signal_text = (
        _v10_wifi_signal_bars(signal) + " " + str(signal) + "%"
        if visible or current
        else "Not detected in the latest scan"
    )
    editor_id = "piwifi-editor-" + str(index)
    password_id = "piwifi-password-" + str(index)

    if system:
        system_password = str(item.get("password") or "")
        system_password_known = bool(item.get("password_known"))
        editor = (
            "<div id='" + esc(editor_id) + "' class='piwifi-profile-editor'>"
            "<div class='piwifi-readonly'>This is a system-managed NetworkManager profile. "
            "Its password can be viewed, but profile editing and deletion remain disabled.</div>"
            "<div style='margin-top:12px'><label>Password</label><input id='" + esc(password_id)
            + "' type='password' autocomplete='off' readonly data-secret-state='"
            + ("known" if system_password_known else "unknown") + "' value='" + esc(system_password)
            + "' placeholder='" + ("Password unavailable" if not system_password_known else "")
            + "'><label class='small piwifi-checkbox'><input type='checkbox' "
            "onclick=\"document.getElementById('" + esc(password_id)
            + "').type=this.checked?'text':'password'\">Show password</label></div></div>"
        )
    else:
        connect_button = ""
        if visible and not current:
            connect_button = (
                "<form method='post' action='/wifi_switch'>"
                "<input type='hidden' name='name' value='" + esc(item["name"]) + "'>"
                "<button type='submit' class='piwifi-secondary'>Connect now</button></form>"
            )

        delete_button = ""
        if not current:
            delete_button = (
                "<form method='post' action='/wifi_delete' "
                "onsubmit=\"return confirm('Delete this Pi Wi-Fi profile?');\">"
                "<input type='hidden' name='name' value='" + esc(item["name"]) + "'>"
                "<button type='submit' class='danger'>Delete</button></form>"
            )

        editor = (
            "<div id='" + esc(editor_id) + "' class='piwifi-profile-editor'>"
            "<div class='grid'>"
            "<form method='post' action='/wifi_update' class='piwifi-editor-form'>"
            "<input type='hidden' name='name' value='" + esc(item["name"]) + "'>"
            "<div><label>Priority</label><input type='number' name='priority' value='"
            + esc(item["priority"]) + "'><div class='small'>Higher number is preferred.</div></div>"
            "<div><label>Automatic connection</label><select name='autoconnect'>"
            "<option value='yes'" + (" selected" if enabled else "") + ">Enabled</option>"
            "<option value='no'" + ("" if enabled else " selected") + ">Disabled</option>"
            "</select></div><div class='piwifi-form-actions'><button type='submit'>Save profile settings</button></div>"
            "</form>"
            "<form method='post' action='/wifi_update_password' class='piwifi-editor-form'>"
            "<input type='hidden' name='name' value='" + esc(item["name"]) + "'>"
            "<div style='grid-column:1/-1'><label>Password</label><input id='" + esc(password_id)
            + "' type='password' autocomplete='off' name='password' data-secret-state='"
            + ("known" if item.get("password_known") else "unknown") + "' value='" + esc(item.get("password") or "")
            + "' placeholder='" + ("Password unavailable — enter a new one" if not item.get("password_known") else "")
            + "'><label class='small piwifi-checkbox'><input type='checkbox' "
            "onclick=\"document.getElementById('" + esc(password_id)
            + "').type=this.checked?'text':'password'\">Show password</label></div>"
            "<div class='piwifi-form-actions'><button type='submit'>Update password</button></div>"
            "</form></div>"
            "<div class='piwifi-row-actions'>" + connect_button + delete_button + "</div></div>"
        )

    return (
        "<div class='piwifi-profile-row'>"
        "<div class='piwifi-profile-summary'><div>"
        "<div class='ssidtitle'>" + esc(item.get("ssid") or "(unknown)")
        + " <span class='pill " + esc(badge) + "'>" + esc(label) + "</span></div>"
        "<div class='ssidmeta'>" + esc(signal_text) + " · Priority " + esc(item.get("priority", 0))
        + " · " + esc(item.get("name") or "") + "</div></div>"
        "<button type='button' class='piwifi-secondary' data-system='" + ("1" if system else "0") + "' "
        "onclick=\"togglePiWifiEditor('" + esc(editor_id) + "',this)\">"
        + ("Details" if system else "Edit") + "</button></div>"
        + editor + "</div>"
    )


def _v10_pi_wifi_nearby_html(networks, configured_ssids):
    if not networks:
        return "<p class='small'>No nearby networks were returned by NetworkManager.</p>"

    networks = sorted(
        networks,
        key=lambda item: (
            str(item.get("ssid") or "") in configured_ssids,
            not bool(item.get("current")),
            -int(item.get("signal") or 0),
            str(item.get("ssid") or "").lower(),
        ),
    )

    rows = []
    for item in networks:
        ssid = str(item.get("ssid") or "")
        configured = ssid in configured_ssids
        action = (
            "<span class='pill active'>Configured</span>"
            if configured else
            "<button type='button' class='piwifi-secondary' data-piwifi-add='"
            + esc(ssid) + "' data-piwifi-open='" + ("1" if str(item.get("security")) == "Open" else "0")
            + "'>Add</button>"
        )
        status = "Connected · " if item.get("current") else ""
        rows.append(
            "<div class='piwifi-nearby-row'><div><b>" + esc(ssid)
            + "</b><div class='small'>" + esc(status + _v10_wifi_signal_bars(item.get("signal"))
            + " " + str(item.get("signal") or 0) + "% · " + str(item.get("security") or "Unknown"))
            + "</div></div>" + action + "</div>"
        )
    return "".join(rows)


def _v10_pi_wifi_page():
    inventory = _v10_pi_wifi_inventory(refresh=False)
    profiles = inventory["profiles"]
    configured_ssids = {str(item.get("ssid") or "") for item in profiles}
    active_ssid = inventory.get("active_ssid") or "Not connected"
    active_ip = inventory.get("ip_address") or "Unavailable"
    active_signal = inventory.get("signal_percent")
    active_dbm = inventory.get("signal_dbm")

    signal_text = "Unavailable"
    if isinstance(active_signal, int):
        signal_text = _v10_wifi_signal_bars(active_signal) + " " + str(active_signal) + "%"
    if isinstance(active_dbm, int):
        signal_text += " · " + str(active_dbm) + " dBm"

    current_profile = next((item for item in profiles if item.get("current")), None)
    if current_profile:
        current_card = (
            "<div class='piwifi-current'><div><div class='ssidtitle'>"
            + esc(current_profile.get("ssid") or active_ssid)
            + " <span class='pill active'>Connected</span></div>"
            + "<div class='ssidmeta'>" + esc(signal_text)
            + " · " + esc(active_ip) + "</div></div>"
            + "<div class='small'>Priority " + esc(current_profile.get("priority", 0))
            + "</div></div>"
        )
    else:
        current_card = "<p class='bad'>The Raspberry Pi is not currently connected through wlan0.</p>"

    profile_html = "".join(
        _v10_pi_wifi_profile_card(item, index)
        for index, item in enumerate(profiles)
    ) or "<p class='small'>No saved Pi Wi-Fi profiles were found.</p>"

    nearby_html = _v10_pi_wifi_nearby_html(inventory["scan"], configured_ssids)
    visible_count = len(inventory["scan"])
    addable_count = sum(
        1
        for item in inventory["scan"]
        if str(item.get("ssid") or "") not in configured_ssids
    )
    scan_summary = (
        str(addable_count)
        + " available to add · "
        + str(visible_count)
        + " visible total"
    )
    last_action = sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true").strip()
    action_html = (
        "<div class='piwifi-notice'>" + esc(last_action[:1200]) + "</div>"
        if last_action else ""
    )

    return f"""
    <div class='piwifi-head'>
      <div><h1>Pi Wi-Fi</h1><div class='small'>NetworkManager profiles used by the Raspberry Pi control system.</div></div>
      <a class='piwifi-link-button piwifi-secondary' href='/connectivity?tab=airlink' target='_top'>Open Air Link Wi-Fi</a>
    </div>

    <div class='piwifi-summary'>
      <div class='piwifi-kpi'><div class='piwifi-kpi-label'>Connection</div><div class='piwifi-kpi-value'>{esc(active_ssid)}</div></div>
      <div class='piwifi-kpi'><div class='piwifi-kpi-label'>Signal</div><div class='piwifi-kpi-value'>{esc(signal_text)}</div></div>
      <div class='piwifi-kpi'><div class='piwifi-kpi-label'>wlan0 address</div><div class='piwifi-kpi-value'>{esc(active_ip)}</div></div>
      <div class='piwifi-kpi'><div class='piwifi-kpi-label'>NetworkManager</div><div class='piwifi-kpi-value'>{esc(str(inventory.get('manager_state') or 'unknown').title())}</div></div>
    </div>

    {action_html}

    <div class='card'><div class='piwifi-card-title'><h2>Current connection</h2></div>{current_card}</div>

    <div class='card'>
      <div class='piwifi-section-head'><div><h2>Configured networks</h2><div class='small'>Profiles stored on the Pi. Higher priority is preferred.</div></div>
      <button type='button' onclick='openPiWifiAdd()'>+ Add Wi-Fi network</button></div>
      <div style='margin-top:14px'>{profile_html}</div>
    </div>

    <div class='card'>
      <div class='piwifi-section-head'><div><h2>Nearby networks</h2><div class='small'>Fresh scan from the Raspberry Pi wireless adapter. Networks available to add are shown first.</div></div>
      <button id='piwifiScanButton' type='button' class='piwifi-secondary' onclick='refreshPiWifiNetworks(this)'>Scan networks</button></div>
      <div id='piwifiScanSummary' class='small' style='margin-top:10px'>{esc(scan_summary)}</div>
      <div id='piwifiNearbyNetworks' style='margin-top:6px'>{nearby_html}</div>
    </div>

    <div id='piwifiAddModal' class='piwifi-modal' aria-hidden='true'>
      <div class='piwifi-modal-dialog'>
        <div class='piwifi-modal-head'><h2>Add Pi Wi-Fi network</h2><button type='button' class='piwifi-close' onclick='closePiWifiAdd()'>×</button></div>
        <p class='small'>The profile is saved without forcing the Pi to disconnect from its current network.</p>
        <form method='post' action='/wifi_add'>
          <div class='grid'>
            <div><label>SSID</label><input id='piwifi-new-ssid' name='ssid' maxlength='32' required></div>
            <div><label>Password</label><input id='piwifi-new-pass' name='password' type='password' autocomplete='new-password' data-secret-state='new' required>
              <label class='small piwifi-checkbox'><input type='checkbox' onclick="document.getElementById('piwifi-new-pass').type=this.checked?'text':'password'">Show password</label>
            </div>
            <div><label>Priority</label><input name='priority' type='number' value='10'></div>
            <div><label>Automatic connection</label><select name='autoconnect'><option value='yes' selected>Enabled</option><option value='no'>Disabled</option></select></div>
          </div>
          <div class='piwifi-form-actions'><button type='submit'>Save network</button><button type='button' class='piwifi-secondary' onclick='closePiWifiAdd()'>Cancel</button></div>
        </form>
      </div>
    </div>

    <script>
    const configuredPiWifiSsids=new Set({json.dumps(sorted(configured_ssids), ensure_ascii=False)});
    function togglePiWifiEditor(id,button){{
      const editor=document.getElementById(id);const open=editor.classList.toggle('open');button.textContent=open?'Close':(button.dataset.system==='1'?'Details':'Edit');
      window.dispatchEvent(new Event('resize'));
    }}
    function openPiWifiAdd(ssid=''){{
      document.getElementById('piwifi-new-ssid').value=ssid||'';
      document.getElementById('piwifiAddModal').classList.add('open');
      document.getElementById('piwifiAddModal').setAttribute('aria-hidden','false');
      setTimeout(()=>document.getElementById(ssid?'piwifi-new-pass':'piwifi-new-ssid').focus(),50);
    }}
    function closePiWifiAdd(){{
      document.getElementById('piwifiAddModal').classList.remove('open');
      document.getElementById('piwifiAddModal').setAttribute('aria-hidden','true');
    }}
    document.getElementById('piwifiAddModal').addEventListener('click',event=>{{if(event.target.id==='piwifiAddModal')closePiWifiAdd();}});
    document.querySelectorAll('[data-piwifi-add]').forEach(button=>button.addEventListener('click',()=>openPiWifiAdd(button.dataset.piwifiAdd||'')));
    let piWifiScanRunning=false;
    async function refreshPiWifiNetworks(button){{
      if(piWifiScanRunning)return;
      piWifiScanRunning=true;
      const target=document.getElementById('piwifiNearbyNetworks');
      const summary=document.getElementById('piwifiScanSummary');
      const old=button?button.textContent:'Scan networks';
      if(button){{button.disabled=true;button.textContent='Scanning…';}}
      if(summary)summary.textContent='Scanning… this can take several seconds.';
      try{{
        const response=await fetch('/wifi/api/scan?ts='+Date.now(),{{cache:'no-store'}});
        const data=await response.json();
        if(data.error)throw new Error(data.error);
        const networks=[...(data.networks||[])];
        networks.sort((a,b)=>{{
          const aConfigured=configuredPiWifiSsids.has(a.ssid||'')?1:0;
          const bConfigured=configuredPiWifiSsids.has(b.ssid||'')?1:0;
          return aConfigured-bConfigured
            || Number(Boolean(b.current))-Number(Boolean(a.current))
            || Number(b.signal||0)-Number(a.signal||0)
            || String(a.ssid||'').localeCompare(String(b.ssid||''));
        }});
        target.innerHTML='';
        let addable=0;
        networks.forEach(item=>{{
          const row=document.createElement('div');row.className='piwifi-nearby-row';
          const info=document.createElement('div');
          const title=document.createElement('b');title.textContent=item.ssid||'(hidden)';
          const meta=document.createElement('div');meta.className='small';
          meta.textContent=(item.current?'Connected · ':'')+String(item.signal||0)+'% · '+String(item.security||'Unknown');
          info.append(title,meta);
          let action;
          if(configuredPiWifiSsids.has(item.ssid||'')){{
            action=document.createElement('span');
            action.className='pill active';
            action.textContent='Configured';
          }}else{{
            addable+=1;
            action=document.createElement('button');
            action.type='button';
            action.className='piwifi-secondary';
            action.textContent='Add';
            action.onclick=()=>openPiWifiAdd(item.ssid||'');
          }}
          row.append(info,action);
          target.appendChild(row);
        }});
        if(!networks.length)target.innerHTML='<p class="small">No nearby networks were returned.</p>';
        if(summary)summary.textContent=String(addable)+' available to add · '+String(networks.length)+' visible total';
      }}catch(error){{
        target.innerHTML='<p class="bad"></p>';
        target.querySelector('p').textContent='Scan failed: '+error.message;
        if(summary)summary.textContent='Scan failed.';
      }}finally{{
        piWifiScanRunning=false;
        if(button){{button.disabled=false;button.textContent=old;}}
        window.dispatchEvent(new Event('resize'));
      }}
    }}
    setTimeout(()=>{{
      const button=document.getElementById('piwifiScanButton');
      if(button)refreshPiWifiNetworks(button);
    }},250);
    </script>
    """


def _v10_service_operations_html():
    purposes = {
        "siyi-button-bridge": "Joystick and button actions sent to the aircraft.",
        "siyi-video-source": "Publishes the selected local or relayed video source.",
        "siyi-video-dual": "Maintains dual-source video support and forwarding.",
        "mediamtx": "RTSP routing and the fixed QGC video endpoint.",
        "mavlink-router": "Routes aircraft telemetry to configured destinations.",
        "zerotier-one": "Remote overlay connectivity for the Pi and Air Link.",
        "siyi-rec-proxy": "Camera recording proxy functions.",
        "siyi-rec-redirect": "Camera recording redirect functions.",
        "siyi-webui": "This control interface.",
    }

    rows = []
    for group, services in SERVICE_GROUPS.items():
        rows.append(
            "<tr class='v10-service-group'><td colspan='4'>" + esc(group) + "</td></tr>"
        )
        for service in services:
            active = sh("systemctl is-active " + shlex.quote(service) + " 2>/dev/null || true").strip() or "unknown"
            cls = "ok" if active == "active" else ("bad" if active == "failed" else "warn")
            label = SERVICE_LABELS.get(service, service)
            status_label = STATUS_LABELS.get(active, active.title())
            action_html = (
                "<form method='post' action='/restart'><input type='hidden' name='service' value='"
                + esc(service) + "'><button type='submit'>Restart</button></form>"
            )
            if service == "siyi-button-bridge":
                action_html += (
                    "<form method='post' action='/stop_bridge' style='margin-top:7px' "
                    "onsubmit=\"return confirm('Disable the Button Bridge service?')\">"
                    "<button type='submit' class='danger'>Disable</button></form>"
                )
            rows.append(
                "<tr><td><b>" + esc(label) + "</b><div class='small'>" + esc(service) + "</div></td>"
                "<td class='" + esc(cls) + "'><b>" + esc(status_label) + "</b><div class='small'>" + esc(active) + "</div></td>"
                "<td class='small'>" + esc(purposes.get(service, "System service.")) + "</td>"
                "<td>" + action_html + "</td></tr>"
            )

    return f"""
    <div class='v10-operations-head'>
      <div><h2>Operations &amp; services</h2><p class='small'>One authoritative page for operational restarts and service health. Aircraft configuration is kept in the Aircraft workspace.</p></div>
      <div>{system_summary()}</div>
    </div>
    <div class='card'>
      <table class='v10-service-table'>
        <tr><th>Service</th><th>Status</th><th>Purpose</th><th>Action</th></tr>
        {''.join(rows)}
      </table>
    </div>
    """


def _v9_aircraft_page(active):
    tabs = [
        {"id":"mavlink","label":"MAVLink","src":"/mavlink?embed=1"},
        {"id":"buttons","label":"Buttons","src":"/buttons?embed=1"},
        {"id":"flaps","label":"Flaps","src":"/flaps?embed=1"},
        {"id":"parameters","label":"Parameters","src":"/parameters?embed=1"},
    ]
    return _v9_workspace_page(
        "Aircraft",
        "Aircraft-facing telemetry, button actions, flap control and ArduPlane parameters. Service operations are maintained under System.",
        tabs, active if active in {"mavlink","buttons","flaps","parameters"} else "mavlink",
    )


def _v9_system_page(active):
    tabs = [
        {"id":"operations","label":"Operations & Services","html":_v10_service_operations_html()},
        {"id":"diagnostics","label":"Diagnostics","src":"/logs?embed=1"},
        {"id":"update","label":"Software update","src":"/software_update?embed=1"},
    ]
    if not setup_is_complete():
        tabs.append({"id":"setup","label":"Setup wizard","src":"/first_setup?embed=1"})
    valid = {item["id"] for item in tabs}
    return _v9_workspace_page(
        "System",
        "Operational restarts, service health, diagnostics, updates and setup in one workspace.",
        tabs, active if active in valid else "operations",
    )


def _v9_dashboard_page():
    html = _v10_previous_dashboard_page()
    html = html.replace(
        "<a class='v9-link-button secondary' href='/aircraft?tab=operations'>Operations</a>",
        "<a class='v9-link-button secondary' href='/system?tab=operations'>Operations &amp; Services</a>",
    )
    return html.replace("Control Center 4.0.3", "Control Center 4.0.3")


def _v9_workspace_page(title, description, tabs, active):
    valid_ids = [item["id"] for item in tabs]
    if active not in valid_ids:
        active = valid_ids[0]

    buttons = []
    panels = []
    for item in tabs:
        item_id = item["id"]
        selected = item_id == active
        buttons.append(
            "<button type='button' class='v9-tab-button" + (" active" if selected else "")
            + "' data-v9-tab='" + esc(item_id) + "'>" + esc(item["label"]) + "</button>"
        )
        if item.get("html") is not None:
            content = "<div class='v9-native-panel'>" + str(item["html"]) + "</div>"
        else:
            src = str(item.get("src") or "")
            content = (
                "<iframe class='v9-workspace-frame v10-auto-frame' title='" + esc(item["label"])
                + "' data-src='" + esc(src) + "' scrolling='no'"
                + (" src='" + esc(src) + "'" if selected else "")
                + " loading='eager'></iframe>"
            )
        panels.append(
            "<section class='v9-frame-panel" + (" active" if selected else "")
            + "' data-v9-panel='" + esc(item_id) + "'>" + content + "</section>"
        )

    return f"""
<div class='v9-hero'>
  <div><h1>{esc(title)}</h1><p>{esc(description)}</p></div>
  <span class='v9-hero-badge'>Unified workspace</span>
</div>
<div class='v9-tabs-shell'>
  <div class='v9-tabs'>{''.join(buttons)}
    <div class='v9-tab-tools'><button type='button' class='v9-tab-button' id='v9-refresh-tab'>Reload current tab</button></div>
  </div>
  {''.join(panels)}
</div>
<script>
(function(){{
  const buttons=[...document.querySelectorAll('[data-v9-tab]')];
  const panels=[...document.querySelectorAll('[data-v9-panel]')];
  const frameObservers=new WeakMap();
  const frameListeners=new WeakSet();

  function resizeWorkspaceFrame(frame){{
    if(!frame||!frame.contentDocument)return;
    try{{
      const doc=frame.contentDocument;
      doc.documentElement.style.overflow='hidden';
      if(doc.body)doc.body.style.overflow='hidden';
      const height=Math.max(
        doc.body?doc.body.scrollHeight:0,
        doc.documentElement?doc.documentElement.scrollHeight:0,
        480
      );
      frame.style.height=(height+4)+'px';
    }}catch(_error){{}}
  }}

  function attachWorkspaceDocument(frame){{
    try{{
      const previous=frameObservers.get(frame)||[];
      previous.forEach(observer=>{{try{{observer.disconnect()}}catch(_error){{}}}});
      const doc=frame.contentDocument;
      if(!doc||!doc.body)return;
      resizeWorkspaceFrame(frame);
      const resizeObserver=new ResizeObserver(()=>resizeWorkspaceFrame(frame));
      resizeObserver.observe(doc.body);
      const mutationObserver=new MutationObserver(()=>resizeWorkspaceFrame(frame));
      mutationObserver.observe(doc.body,{{subtree:true,childList:true,attributes:true,characterData:true}});
      frameObservers.set(frame,[resizeObserver,mutationObserver]);
      setTimeout(()=>resizeWorkspaceFrame(frame),250);
      setTimeout(()=>resizeWorkspaceFrame(frame),1000);
    }}catch(_error){{}}
  }}

  function bindWorkspaceFrame(frame){{
    if(!frame)return;
    if(!frameListeners.has(frame)){{
      frame.addEventListener('load',()=>attachWorkspaceDocument(frame));
      frameListeners.add(frame);
    }}
    if(frame.contentDocument&&frame.contentDocument.readyState==='complete')attachWorkspaceDocument(frame);
  }}

  function selectTab(id,update=true){{
    if(!buttons.some(button=>button.dataset.v9Tab===id))id={json.dumps(active)};
    buttons.forEach(button=>button.classList.toggle('active',button.dataset.v9Tab===id));
    panels.forEach(panel=>{{
      const on=panel.dataset.v9Panel===id;
      panel.classList.toggle('active',on);
      if(on){{
        const frame=panel.querySelector('iframe[data-src]');
        if(frame){{
          if(!frame.getAttribute('src'))frame.setAttribute('src',frame.dataset.src);
          bindWorkspaceFrame(frame);
          setTimeout(()=>resizeWorkspaceFrame(frame),100);
        }}
      }}
    }});
    if(update){{
      const url=new URL(location.href);url.searchParams.set('tab',id);history.replaceState(null,'',url);
      try{{localStorage.setItem('siyi-workspace-'+location.pathname,id)}}catch(_error){{}}
    }}
  }}

  buttons.forEach(button=>button.addEventListener('click',()=>selectTab(button.dataset.v9Tab)));
  document.querySelectorAll('iframe.v10-auto-frame').forEach(bindWorkspaceFrame);
  document.getElementById('v9-refresh-tab').addEventListener('click',()=>{{
    const panel=document.querySelector('.v9-frame-panel.active');
    const frame=panel&&panel.querySelector('iframe');
    if(frame)frame.contentWindow.location.reload();
    else location.reload();
  }});

  let requested=new URLSearchParams(location.search).get('tab');
  if(!requested){{try{{requested=localStorage.getItem('siyi-workspace-'+location.pathname)}}catch(_error){{}}}}
  selectTab(requested||{json.dumps(active)},false);
  window.addEventListener('resize',()=>document.querySelectorAll('iframe.v10-auto-frame').forEach(resizeWorkspaceFrame));
}})();
</script>
"""


def page(title, body):
    document = _v10_previous_page(title, body)
    v10_css = r"""
/* CONTROL_CENTER_HARMONIZATION_V10 */
.v9-workspace-frame{height:480px;min-height:480px;overflow:hidden;background:#0f172a}
.v9-frame-panel{overflow:visible}
.v9-native-panel{min-height:0}
body.v9-embedded,body.v9-embedded main{min-height:0!important}
.piwifi-head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:16px;flex-wrap:wrap}
.piwifi-head h1{margin:0}
.piwifi-link-button{display:inline-flex;align-items:center;justify-content:center;background:#2563eb;color:white!important;text-decoration:none;border-radius:9px;padding:9px 13px;font-size:13px;font-weight:700}
.piwifi-secondary{background:#1e293b!important;border:1px solid #475569!important;color:#e2e8f0!important}
.piwifi-summary{display:grid;grid-template-columns:repeat(4,minmax(150px,1fr));gap:12px;margin-bottom:16px}
.piwifi-kpi{background:#111827;border:1px solid #334155;border-radius:12px;padding:14px}
.piwifi-kpi-label{font-size:12px;color:#94a3b8;margin-bottom:6px}
.piwifi-kpi-value{font-size:16px;font-weight:800;word-break:break-word}
.piwifi-section-head,.piwifi-card-title{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
.piwifi-section-head h2,.piwifi-card-title h2{margin:0 0 4px}
.piwifi-profile-row{border:1px solid #334155;background:#0b1220;border-radius:12px;padding:14px;margin-top:10px}
.piwifi-profile-summary{display:flex;justify-content:space-between;align-items:center;gap:14px}
.piwifi-profile-editor{display:none;border-top:1px solid #334155;margin-top:12px;padding-top:13px}
.piwifi-profile-editor.open{display:block}
.piwifi-editor-form{display:grid;grid-template-columns:repeat(2,minmax(160px,1fr));gap:12px;border:1px solid #253247;border-radius:10px;padding:12px;margin-bottom:10px}
.piwifi-form-actions,.piwifi-row-actions{display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin-top:12px}
.piwifi-row-actions form{margin:0}
.piwifi-checkbox{display:flex;gap:7px;align-items:center;margin-top:7px}
.piwifi-checkbox input{width:auto}
.piwifi-readonly{padding:11px;border-radius:9px;background:#111827;border:1px solid #334155;color:#94a3b8}
.piwifi-current{display:flex;justify-content:space-between;align-items:center;gap:14px}
.piwifi-nearby-row{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:11px 0;border-bottom:1px solid #253247}
.piwifi-nearby-row:last-child{border-bottom:0}
.piwifi-notice{margin-bottom:14px;padding:10px 12px;border-radius:9px;background:#172554;border:1px solid #1d4ed8;color:#bfdbfe;font-size:13px}
.piwifi-modal{display:none;position:fixed;inset:0;background:rgba(2,6,23,.82);z-index:10000;align-items:center;justify-content:center;padding:20px}
.piwifi-modal.open{display:flex}
.piwifi-modal-dialog{width:min(760px,96vw);background:#111827;border:1px solid #475569;border-radius:14px;padding:18px;box-shadow:0 24px 80px rgba(0,0,0,.6)}
.piwifi-modal-head{display:flex;justify-content:space-between;align-items:center;gap:12px}
.piwifi-modal-head h2{margin:0}
.piwifi-close{background:transparent!important;border:0!important;font-size:27px!important;padding:0 5px!important}
.v10-operations-head{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;flex-wrap:wrap;margin-bottom:14px}
.v10-operations-head h2{margin:0 0 6px}
.v10-service-table td{vertical-align:middle}
.v10-service-table .v10-service-group td{padding-top:16px;color:#93c5fd;font-weight:800;background:#0b1220}
@media(max-width:900px){
  .piwifi-summary{grid-template-columns:repeat(2,minmax(140px,1fr))}
  .piwifi-editor-form{grid-template-columns:1fr}
}
@media(max-width:560px){
  .piwifi-summary{grid-template-columns:1fr}
  .piwifi-profile-summary,.piwifi-current{align-items:flex-start;flex-direction:column}
}
"""
    document = document.replace("</style></head>", v10_css + "\n</style></head>", 1)
    document = document.replace("Control Center 4.0.3", "Control Center 4.0.3")
    return document


def _v10_send_json(handler, payload, status=200):
    raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def _v10_do_GET(self):
    parsed = urllib.parse.urlparse(self.path)
    path = parsed.path
    query = dict(urllib.parse.parse_qsl(parsed.query, keep_blank_values=True))

    if path == "/wifi/api/scan":
        if software_update_lock_active():
            return _v10_previous_get(self)
        try:
            return _v10_send_json(self, {"networks": _v10_pi_wifi_scan(refresh=True), "error": ""})
        except Exception as exc:
            return _v10_send_json(self, {"networks": [], "error": str(exc)}, 500)

    if path == "/wifi":
        if software_update_lock_active():
            return _v10_previous_get(self)
        if not _v9_is_embedded(self, query):
            return _v9_redirect_response(self, "/connectivity?tab=pi")
        return _v9_send_workspace(self, "Pi Wi-Fi", _v10_pi_wifi_page())

    if path == "/operations":
        return _v9_redirect_response(self, "/system?tab=operations")

    return _v10_previous_get(self)


H.do_GET = _v10_do_GET

# CONTROL_CENTER_HARMONIZATION_V10_END


# CONTROL_CENTER_PASSWORD_PRESERVATION_V11
# Configured Pi Wi-Fi passwords use the local display store first and then
# NetworkManager's saved secret. New-network fields intentionally stay blank.
# Upgrade preservation also covers the password display store and MAVLink main.conf.



# PI_WIFI_FRESH_SCAN_V12
# Waits for NetworkManager's asynchronous scan to finish, refreshes when the
# page opens, and shows networks available to add before configured networks.




# BUTTON_CAMERA_WORKSPACE_V13_START

def _v13_buttons_assignment_rows():
    rows = read_button_rows()
    html_rows = []
    mapping = []
    for index, row in enumerate(rows):
        button = str(row.get("Button", ""))
        tap = str(row.get("Tap", "NO_ACTION") or "NO_ACTION")
        hold = str(row.get("Hold", "NO_ACTION") or "NO_ACTION")
        release_hold = str(row.get("ReleaseAfterHold", "NO_ACTION") or "NO_ACTION")
        release_tap = str(row.get("ReleaseAfterTap", "NO_ACTION") or "NO_ACTION")
        double_tap = str(row.get("DoubleTap", "NO_ACTION") or "NO_ACTION")
        notes = str(row.get("Notes", "") or "")
        mapping.append({
            "button": button,
            "Tap": tap,
            "Hold": hold,
            "ReleaseAfterHold": release_hold,
        })
        html_rows.append(
            "<tr data-v15-button-row='" + esc(button.upper()) + "'>"
            "<td class='v15-button-placeholder' data-v15-button='" + esc(button.upper()) + "'>"
            "<span class='v15-button-label'><span class='v15-button-led'></span><b>" + esc(button) + "</b></span>"
            "<input type='hidden' name='Button_" + str(index) + "' value='" + esc(button) + "'>"
            "<input type='hidden' name='ReleaseAfterTap_" + str(index) + "' value='" + esc(release_tap) + "'>"
            "<input type='hidden' name='DoubleTap_" + str(index) + "' value='" + esc(double_tap) + "'>"
            "<input type='hidden' name='Notes_" + str(index) + "' value='" + esc(notes) + "'>"
            "</td>"
            "<td>" + action_select("Tap_" + str(index), tap) + "</td>"
            "<td>" + action_select("Hold_" + str(index), hold) + "</td>"
            "<td class='v13-advanced-column'>" + action_select("ReleaseAfterHold_" + str(index), release_hold) + "</td>"
            "</tr>"
        )
    return rows, "".join(html_rows), mapping


def buttons_workspace_page():
    rows, assignment_rows, mapping = _v13_buttons_assignment_rows()
    bridge_state = sh(
        "systemctl is-active siyi-button-bridge.service 2>/dev/null || true"
    ).strip() or "unknown"
    bridge_class = "ok" if bridge_state == "active" else (
        "bad" if bridge_state == "failed" else "warn"
    )
    try:
        mode_payload = flight_mode_state_read_once()
        current_mode = str(
            mode_payload.get("mode")
            or mode_payload.get("flight_mode")
            or "Unavailable"
        ) if isinstance(mode_payload, dict) else "Unavailable"
    except Exception:
        current_mode = "Unavailable"

    safety = read_button_safety_config()
    blocked = list(safety.get("block_when_armed") or [])
    mapping_json = json.dumps(mapping, ensure_ascii=False)

    return f"""
    <style>
      .v13-button-head{{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;flex-wrap:wrap;margin-bottom:16px}}
      .v13-button-head h1{{margin:0}}
      .v13-button-summary{{display:flex;gap:8px;flex-wrap:wrap}}
      .v13-summary-pill{{background:#0b1220;border:1px solid #334155;border-radius:999px;padding:7px 11px;font-size:13px}}
      .v13-button-tabs{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}}
      .v13-button-tab{{background:#1e293b;color:#cbd5e1;border:1px solid #334155;margin:0}}
      .v13-button-tab.active{{background:#2563eb;color:white;border-color:#60a5fa}}
      .v13-button-panel{{display:none}}
      .v13-button-panel.active{{display:block}}
      .v13-assignment-toolbar{{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px}}
      .v13-segmented{{display:inline-flex;border:1px solid #334155;border-radius:9px;overflow:hidden;background:#0b1220}}
      .v13-segmented button{{margin:0;border:0;border-right:1px solid #334155;border-radius:0;background:transparent;color:#cbd5e1;padding:8px 12px}}
      .v13-segmented button:last-child{{border-right:0}}
      .v13-segmented button.active{{background:#2563eb;color:white}}
      .v13-button-table-wrap{{overflow-x:auto}}
      .v13-button-table select{{min-width:160px}}
      .v15-button-placeholder{{
        min-width:96px;
        transition:background-color 35ms linear,border-color 35ms linear,box-shadow 35ms linear,color 35ms linear;
      }}
      .v15-button-label{{display:inline-flex;align-items:center;gap:9px}}
      .v15-button-led{{
        width:10px;height:10px;border-radius:50%;
        background:#334155;border:1px solid #64748b;
        box-shadow:inset 0 0 0 2px rgba(2,6,23,.35);
        transition:all 35ms linear;
      }}
      .v15-button-placeholder.v15-held{{
        color:#dcfce7;
        background:linear-gradient(135deg,#14532d,#166534);
        box-shadow:inset 0 0 0 2px #4ade80,0 0 18px rgba(34,197,94,.42);
      }}
      .v15-button-placeholder.v15-held .v15-button-led{{
        background:#4ade80;border-color:#bbf7d0;
        box-shadow:0 0 12px rgba(74,222,128,.95);
      }}
      .v15-live-input-pill{{
        display:inline-flex;align-items:center;gap:7px;
        border:1px solid #334155;border-radius:999px;
        background:#0b1220;color:#94a3b8;
        padding:7px 11px;font-size:12px;
      }}
      .v15-live-input-pill.connected{{color:#bbf7d0;border-color:#166534;background:#052e16}}
      .v15-live-input-pill.reconnecting{{color:#fde68a;border-color:#92400e;background:#451a03}}
      .v13-simple .v13-advanced-column{{display:none}}
      .v13-radio-row{{display:flex;gap:8px;flex-wrap:wrap}}
      .v13-radio-option{{display:inline-flex;align-items:center;gap:7px;background:#0b1220;border:1px solid #334155;border-radius:999px;padding:8px 12px;cursor:pointer}}
      .v13-radio-option:has(input:checked){{background:#172554;border-color:#3b82f6;color:#dbeafe}}
      .v13-radio-option input{{width:auto;margin:0;accent-color:#3b82f6}}
      .v13-test-grid{{display:grid;grid-template-columns:repeat(2,minmax(240px,1fr));gap:14px}}
      .v13-test-result{{background:#0b1220;border:1px solid #334155;border-radius:12px;padding:16px;min-height:96px}}
      .v13-test-action{{font-size:24px;font-weight:800;margin-top:8px;color:#bfdbfe}}
      .v13-drawer-backdrop{{display:none;position:fixed;inset:0;background:rgba(2,6,23,.62);z-index:12000}}
      .v13-drawer-backdrop.open{{display:block}}
      .v13-gamepad-drawer{{position:fixed;right:0;top:0;height:100vh;width:min(520px,92vw);background:#0f172a;border-left:1px solid #475569;box-shadow:-18px 0 55px rgba(0,0,0,.45);transform:translateX(102%);transition:transform .2s ease;z-index:12001;padding:20px;box-sizing:border-box;overflow:auto}}
      .v13-gamepad-drawer.open{{transform:translateX(0)}}
      .v13-drawer-head{{display:flex;justify-content:space-between;align-items:center;gap:12px}}
      .v13-drawer-head h2{{margin:0}}
      .v14-drawer-actions{{display:flex;gap:8px;align-items:center}}
      .v13-close-drawer,.v14-float-button{{background:#334155;color:white;border-radius:999px;padding:6px 12px;margin:0}}
      .v14-float-button{{background:#2563eb;border-color:#60a5fa}}
      .v13-gamepad-drawer img{{width:100%;border-radius:14px;margin-top:18px}}
      @media(max-width:760px){{.v13-test-grid{{grid-template-columns:1fr}}}}
    </style>

    <div class='v13-button-head'>
      <div>
        <h1>Button controls</h1>
        <div class='small'>Assignments, flight-safety protection and a safe mapping test in one place.</div>
      </div>
      <div class='v13-button-summary'>
        <span class='v13-summary-pill'>Bridge: <b class='{bridge_class}'>{esc(bridge_state.title())}</b></span>
        <span class='v13-summary-pill'>Mappings: <b>{len(rows)}</b></span>
        <span class='v13-summary-pill'>Current mode: <b>{esc(current_mode)}</b></span>
      </div>
    </div>

    <div class='v13-button-tabs'>
      <button type='button' class='v13-button-tab active' data-v13-button-tab='assignments'>Assignments</button>
      <button type='button' class='v13-button-tab' data-v13-button-tab='safety'>Safety</button>
      <button type='button' class='v13-button-tab' data-v13-button-tab='test'>Live test</button>
    </div>

    <section class='v13-button-panel active' data-v13-button-panel='assignments'>
      <div class='card'>
        <div class='v13-assignment-toolbar'>
          <div>
            <h2 style='margin:0 0 4px'>Button assignments</h2>
            <div class='small'>Simple view shows Tap and Hold. Advanced view also shows Release after hold.</div>
          </div>
          <div style='display:flex;gap:10px;align-items:center;flex-wrap:wrap'>
            <div class='v13-segmented'>
              <button id='v13SimpleButton' type='button' class='active' onclick="setV13ButtonView('simple')">Simple</button>
              <button id='v13AdvancedButton' type='button' onclick="setV13ButtonView('advanced')">Advanced</button>
            </div>
            <span id='v15LiveInputStatus' class='v15-live-input-pill'>Live input: connecting…</span>
            <button type='button' class='secondary' onclick='openV13GamepadDrawer()'>Gamepad reference</button>
          </div>
        </div>

        <form id='buttonMapForm' method='post' action='/save_buttons' class='v13-simple'>
          <input type='hidden' name='count' value='{len(rows)}'>
          <div class='v13-button-table-wrap'>
            <table class='v13-button-table'>
              <tr><th>Button</th><th>Tap</th><th>Hold</th><th class='v13-advanced-column'>Release after hold</th></tr>
              {assignment_rows}
            </table>
          </div>
          <div style='display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;margin-top:10px'>
            <div id='buttonMapSaveStatus' class='small' style='color:#94a3b8'>Saved automatically</div>
            <a class='v9-link-button secondary' href='/media?tab=siyi-camera' target='_top'>Manage gimbal presets</a>
          </div>
        </form>
      </div>
    </section>

    <section class='v13-button-panel' data-v13-button-panel='safety'>
      <div style='margin-bottom:10px' class='small'>Protection status: <b>{len(blocked)} armed-flight blocker(s)</b>. Airborne disarm protection remains locked by default.</div>
      {button_safety_card()}
    </section>

    <section class='v13-button-panel' data-v13-button-panel='test'>
      <div class='card'>
        <h2>Safe assignment test</h2>
        <p class='small'>Select a button and interaction to verify the configured action. This test does not send commands to the aircraft.</p>
        <div class='v13-test-grid'>
          <div>
            <label>Button</label>
            <select id='v13TestButton'></select>
            <label style='margin-top:14px'>Interaction</label>
            <div class='v13-radio-row'>
              <label class='v13-radio-option'><input type='radio' name='v13TestType' value='Tap' checked><span>Tap</span></label>
              <label class='v13-radio-option'><input type='radio' name='v13TestType' value='Hold'><span>Hold</span></label>
              <label class='v13-radio-option'><input type='radio' name='v13TestType' value='ReleaseAfterHold'><span>Release after hold</span></label>
            </div>
          </div>
          <div class='v13-test-result'>
            <div class='small'>Configured result</div>
            <div id='v13TestAction' class='v13-test-action'>NO_ACTION</div>
            <div id='v13TestSafety' class='small' style='margin-top:8px'></div>
          </div>
        </div>
      </div>
      <div class='card'>
        <h2>Button bridge</h2>
        <p>Service state: <b class='{bridge_class}'>{esc(bridge_state)}</b></p>
        <p class='small'>Service restart and disable controls are maintained under System → Operations &amp; Services.</p>
        <a class='v9-link-button secondary' href='/system?tab=operations' target='_top'>Open Operations &amp; Services</a>
      </div>
    </section>

    <div id='v13DrawerBackdrop' class='v13-drawer-backdrop' onclick='closeV13GamepadDrawer()'></div>
    <aside id='v13GamepadDrawer' class='v13-gamepad-drawer' aria-hidden='true'>
      <div class='v13-drawer-head'>
        <h2>Gamepad reference</h2>
        <div class='v14-drawer-actions'>
          <button type='button' class='v14-float-button' onclick='floatV14GamepadReference()'>Release to floating</button>
          <button type='button' class='v13-close-drawer' onclick='closeV13GamepadDrawer()'>×</button>
        </div>
      </div>
      <img src='/static/gamepad_reference.png' alt='Standard gamepad button reference'>
      <p class='small'>Release the reference into a movable, resizable panel that remains above the whole Control Center workspace.</p>
    </aside>

    <script>
    (function(){{
      const mapping={mapping_json};
      const blockedActions=new Set({json.dumps(blocked, ensure_ascii=False)});

      function selectPanel(name){{
        document.querySelectorAll('[data-v13-button-tab]').forEach(button=>button.classList.toggle('active',button.dataset.v13ButtonTab===name));
        document.querySelectorAll('[data-v13-button-panel]').forEach(panel=>panel.classList.toggle('active',panel.dataset.v13ButtonPanel===name));
        try{{localStorage.setItem('siyi-buttons-inner-tab',name)}}catch(_error){{}}
        window.dispatchEvent(new Event('resize'));
      }}
      document.querySelectorAll('[data-v13-button-tab]').forEach(button=>button.addEventListener('click',()=>selectPanel(button.dataset.v13ButtonTab)));
      let savedTab='assignments';
      try{{savedTab=localStorage.getItem('siyi-buttons-inner-tab')||savedTab}}catch(_error){{}}
      if(['assignments','safety','test'].includes(savedTab))selectPanel(savedTab);

      window.setV13ButtonView=function(mode){{
        const form=document.getElementById('buttonMapForm');
        const advanced=mode==='advanced';
        form.classList.toggle('v13-simple',!advanced);
        document.getElementById('v13SimpleButton').classList.toggle('active',!advanced);
        document.getElementById('v13AdvancedButton').classList.toggle('active',advanced);
        try{{localStorage.setItem('siyi-buttons-view',mode)}}catch(_error){{}}
        window.dispatchEvent(new Event('resize'));
      }};
      let savedView='simple';
      try{{savedView=localStorage.getItem('siyi-buttons-view')||savedView}}catch(_error){{}}
      setV13ButtonView(savedView==='advanced'?'advanced':'simple');

      const form=document.getElementById('buttonMapForm');
      const status=document.getElementById('buttonMapSaveStatus');
      let timer=null;
      async function saveButtonMap(){{
        clearTimeout(timer);
        timer=setTimeout(async()=>{{
          if(status)status.textContent='Saving…';
          try{{
            const response=await fetch('/save_buttons',{{method:'POST',body:new URLSearchParams(new FormData(form))}});
            if(!response.ok)throw new Error('HTTP '+response.status);
            if(status)status.textContent='Saved automatically';
          }}catch(error){{
            if(status)status.textContent='Save failed';
          }}
        }},300);
      }}
      form.querySelectorAll('select,input').forEach(element=>element.addEventListener('change',saveButtonMap));

      const testButton=document.getElementById('v13TestButton');
      mapping.forEach(item=>{{
        const option=document.createElement('option');
        option.value=item.button;
        option.textContent='Button '+item.button;
        testButton.appendChild(option);
      }});
      function updateTest(){{
        const item=mapping.find(row=>row.button===testButton.value)||mapping[0]||{{}};
        const type=(document.querySelector('input[name="v13TestType"]:checked')||{{value:'Tap'}}).value;
        const action=item[type]||'NO_ACTION';
        document.getElementById('v13TestAction').textContent=action;
        document.getElementById('v13TestSafety').textContent=blockedActions.has(action)
          ? 'This action is configured to be blocked while armed.'
          : 'No armed-flight blocker is configured for this action.';
      }}
      testButton.addEventListener('change',updateTest);
      document.querySelectorAll('input[name="v13TestType"]').forEach(element=>element.addEventListener('change',updateTest));
      updateTest();

      const v15LiveStatus=document.getElementById('v15LiveInputStatus');
      const v15ButtonCells=new Map(
        [...document.querySelectorAll('[data-v15-button]')]
          .map(cell=>[String(cell.dataset.v15Button||'').toUpperCase(),cell])
      );
      let v15HeldButtons=new Set();
      let v15ButtonStream=null;

      function v15ApplyHeldButtons(buttons){{
        const next=new Set(
          (Array.isArray(buttons)?buttons:[])
            .map(button=>String(button||'').trim().toUpperCase())
            .filter(Boolean)
        );
        for(const [name,cell] of v15ButtonCells){{
          cell.classList.toggle('v15-held',next.has(name));
        }}
        v15HeldButtons=next;
      }}

      function v15SetLiveStatus(state,text){{
        if(!v15LiveStatus)return;
        v15LiveStatus.classList.remove('connected','reconnecting');
        if(state)v15LiveStatus.classList.add(state);
        v15LiveStatus.textContent=text;
      }}

      function v15ConnectLiveButtons(){{
        if(v15ButtonStream)v15ButtonStream.close();
        v15SetLiveStatus('','Live input: connecting…');
        v15ButtonStream=new EventSource('/button_live_stream?ts='+Date.now());
        v15ButtonStream.onopen=()=>v15SetLiveStatus('connected','Live input: connected');
        v15ButtonStream.onmessage=event=>{{
          try{{
            const data=JSON.parse(event.data||'{{}}');
            v15ApplyHeldButtons(data.held||[]);
            v15SetLiveStatus('connected','Live input: connected');
          }}catch(_error){{}}
        }};
        v15ButtonStream.onerror=()=>{{
          v15SetLiveStatus('reconnecting','Live input: reconnecting…');
        }};
      }}

      v15ConnectLiveButtons();
      window.addEventListener('pagehide',()=>{{
        if(v15ButtonStream)v15ButtonStream.close();
      }});

      const v14FloatId='v14GamepadFloatingPanel';
      const v14FloatStyleId='v14GamepadFloatingStyle';

      function v14TopWindow(){{
        try{{
          if(window.top&&window.top.document)return window.top;
        }}catch(_error){{}}
        return window;
      }}

      function v14EnsureFloatingStyle(topWindow){{
        const topDocument=topWindow.document;
        if(topDocument.getElementById(v14FloatStyleId))return;
        const style=topDocument.createElement('style');
        style.id=v14FloatStyleId;
        style.textContent=`
          #${{v14FloatId}}{{
            position:fixed;
            left:calc(100vw - 560px);
            top:92px;
            width:520px;
            height:560px;
            min-width:320px;
            min-height:260px;
            max-width:calc(100vw - 24px);
            max-height:calc(100vh - 24px);
            z-index:50000;
            display:flex;
            flex-direction:column;
            overflow:hidden;
            resize:both;
            box-sizing:border-box;
            color:#e5e7eb;
            background:#0f172a;
            border:1px solid #64748b;
            border-radius:15px;
            box-shadow:0 22px 70px rgba(0,0,0,.55);
          }}
          #${{v14FloatId}} .v14-float-head{{
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:10px;
            padding:11px 12px;
            cursor:move;
            user-select:none;
            background:linear-gradient(135deg,#172554,#1e3a8a);
            border-bottom:1px solid #475569;
          }}
          #${{v14FloatId}} .v14-float-title{{font-weight:800}}
          #${{v14FloatId}} .v14-float-actions{{display:flex;gap:7px}}
          #${{v14FloatId}} button{{
            width:auto;
            margin:0;
            padding:6px 10px;
            border-radius:8px;
            border:1px solid #64748b;
            background:#1e293b;
            color:white;
            cursor:pointer;
          }}
          #${{v14FloatId}} button:hover{{background:#334155}}
          #${{v14FloatId}} .v14-float-body{{
            flex:1;
            overflow:auto;
            padding:13px;
          }}
          #${{v14FloatId}} img{{
            display:block;
            width:100%;
            height:auto;
            border-radius:12px;
          }}
          #${{v14FloatId}} .v14-float-help{{
            margin:10px 0 0;
            color:#94a3b8;
            font:13px/1.45 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
          }}
        `;
        topDocument.head.appendChild(style);
      }}

      function v14ReadFloatGeometry(){{
        try{{
          const parsed=JSON.parse(localStorage.getItem('siyi-gamepad-floating-geometry')||'null');
          return parsed&&typeof parsed==='object'?parsed:null;
        }}catch(_error){{
          return null;
        }}
      }}

      function v14SaveFloatGeometry(panel){{
        try{{
          localStorage.setItem('siyi-gamepad-floating-geometry',JSON.stringify({{
            left:panel.style.left,
            top:panel.style.top,
            width:panel.style.width,
            height:panel.style.height
          }}));
        }}catch(_error){{}}
      }}

      function v14ClampPanel(panel,topWindow){{
        const rect=panel.getBoundingClientRect();
        const maxLeft=Math.max(8,topWindow.innerWidth-Math.min(rect.width,topWindow.innerWidth-16)-8);
        const maxTop=Math.max(8,topWindow.innerHeight-Math.min(rect.height,topWindow.innerHeight-16)-8);
        panel.style.left=Math.min(Math.max(8,rect.left),maxLeft)+'px';
        panel.style.top=Math.min(Math.max(8,rect.top),maxTop)+'px';
      }}

      function v14BringToFront(panel){{
        panel.style.zIndex=String(50000+Math.floor(Date.now()%10000));
      }}

      function v14CreateFloatingPanel(){{
        const topWindow=v14TopWindow();
        const topDocument=topWindow.document;
        v14EnsureFloatingStyle(topWindow);

        let panel=topDocument.getElementById(v14FloatId);
        if(panel){{
          v14BringToFront(panel);
          return panel;
        }}

        panel=topDocument.createElement('section');
        panel.id=v14FloatId;
        panel.setAttribute('role','dialog');
        panel.setAttribute('aria-label','Floating gamepad reference');
        panel.innerHTML=`
          <div class="v14-float-head">
            <span class="v14-float-title">Gamepad reference</span>
            <div class="v14-float-actions">
              <button type="button" data-v14-dock>Dock</button>
              <button type="button" data-v14-close>×</button>
            </div>
          </div>
          <div class="v14-float-body">
            <img src="${{new URL('/static/gamepad_reference.png',location.origin).href}}" alt="Standard gamepad button reference">
            <p class="v14-float-help">Drag the title bar to move. Drag the lower-right edge to resize. Dock returns the reference to the side drawer.</p>
          </div>
        `;
        topDocument.body.appendChild(panel);

        const geometry=v14ReadFloatGeometry();
        if(geometry){{
          if(geometry.left)panel.style.left=geometry.left;
          if(geometry.top)panel.style.top=geometry.top;
          if(geometry.width)panel.style.width=geometry.width;
          if(geometry.height)panel.style.height=geometry.height;
        }}

        requestAnimationFrame(()=>v14ClampPanel(panel,topWindow));
        v14BringToFront(panel);

        const head=panel.querySelector('.v14-float-head');
        let dragging=false;
        let startX=0,startY=0,startLeft=0,startTop=0;

        head.addEventListener('pointerdown',event=>{{
          if(event.target.closest('button'))return;
          dragging=true;
          const rect=panel.getBoundingClientRect();
          startX=event.clientX;
          startY=event.clientY;
          startLeft=rect.left;
          startTop=rect.top;
          head.setPointerCapture(event.pointerId);
          v14BringToFront(panel);
          event.preventDefault();
        }});

        head.addEventListener('pointermove',event=>{{
          if(!dragging)return;
          panel.style.left=(startLeft+event.clientX-startX)+'px';
          panel.style.top=(startTop+event.clientY-startY)+'px';
          v14ClampPanel(panel,topWindow);
        }});

        function finishDrag(){{
          if(!dragging)return;
          dragging=false;
          v14SaveFloatGeometry(panel);
        }}
        head.addEventListener('pointerup',finishDrag);
        head.addEventListener('pointercancel',finishDrag);

        panel.addEventListener('pointerdown',()=>v14BringToFront(panel));
        panel.querySelector('[data-v14-close]').addEventListener('click',()=>{{
          v14SaveFloatGeometry(panel);
          panel.remove();
        }});
        panel.querySelector('[data-v14-dock]').addEventListener('click',()=>{{
          v14SaveFloatGeometry(panel);
          panel.remove();
          openV13GamepadDrawer();
        }});

        if('ResizeObserver' in topWindow){{
          const observer=new topWindow.ResizeObserver(()=>{{
            v14ClampPanel(panel,topWindow);
            v14SaveFloatGeometry(panel);
          }});
          observer.observe(panel);
        }}
        topWindow.addEventListener('resize',()=>v14ClampPanel(panel,topWindow));

        return panel;
      }}

      window.openV13GamepadDrawer=function(){{
        const topWindow=v14TopWindow();
        const floating=topWindow.document.getElementById(v14FloatId);
        if(floating){{
          v14BringToFront(floating);
          return;
        }}
        document.getElementById('v13DrawerBackdrop').classList.add('open');
        document.getElementById('v13GamepadDrawer').classList.add('open');
        document.getElementById('v13GamepadDrawer').setAttribute('aria-hidden','false');
      }};

      window.closeV13GamepadDrawer=function(){{
        document.getElementById('v13DrawerBackdrop').classList.remove('open');
        document.getElementById('v13GamepadDrawer').classList.remove('open');
        document.getElementById('v13GamepadDrawer').setAttribute('aria-hidden','true');
      }};

      window.floatV14GamepadReference=function(){{
        closeV13GamepadDrawer();
        v14CreateFloatingPanel();
      }};

      document.addEventListener('keydown',event=>{{
        if(event.key==='Escape')closeV13GamepadDrawer();
      }});
    }})();
    </script>
    """


_v13_original_unigcs_controls_page = unigcs_controls_page

def unigcs_controls_page():
    html = _v13_original_unigcs_controls_page()
    html = html.replace(
        "<div class=\"cam-full\"><h1>Camera Controls</h1>",
        "<div class=\"cam-full\"><h1>SIYI Camera</h1><p class='small'>Live image, stream, recording and gimbal controls. Sliders and radio choices apply immediately.</p>",
        1,
    )
    common_css = r"""
    /* CAMERA_UI_HARMONIZATION_V13 */
    .cam-grid .card{border-radius:14px;border-color:#334155;background:#111827}
    .cam-grid .card h2{font-size:17px}
    .cam-grid input[type=range]{accent-color:#3b82f6}
    .cam-grid input[type=radio]{accent-color:#3b82f6;width:18px;height:18px}
    .cam-grid form:has(input[type=radio]) span{background:#0b1220;border:1px solid #334155;border-radius:999px;padding:8px 12px}
    .cam-grid form:has(input[type=radio]) span:has(input:checked){background:#172554;border-color:#3b82f6;color:#dbeafe}
    """
    html = html.replace("</style>", common_css + "\n</style>", 1)
    html += (
        "<div class='cam-full' style='margin-top:14px'>"
        "<div style='display:flex;justify-content:space-between;align-items:end;gap:12px;flex-wrap:wrap;margin-bottom:8px'>"
        "<div><h2 style='margin:0'>Gimbal presets</h2><div class='small'>Preset positions are available as button actions.</div></div>"
        "<a class='v9-link-button secondary' href='/aircraft?tab=buttons' target='_top'>Open button assignments</a>"
        "</div>"
        + gimbal_presets_card()
        + "</div>"
    )
    return html


def _wl2_camera_field_html(control):
    path = str(control["path"])
    label = esc(control["label"])
    description = esc(control.get("description") or "")
    value = control.get("value")
    field_name = "camera." + path
    field_id = "wl2-camera-" + re.sub(r"[^a-zA-Z0-9_-]+", "-", path)
    enum = list(control.get("enum") or [])
    input_html = ""

    if enum:
        choices = []
        for index, item in enumerate(enum):
            checked = " checked" if str(item) == str(value) else ""
            choices.append(
                "<label class='wl2-camera-radio'><input type='radio' name='"
                + esc(field_name) + "' value='" + esc(item) + "'" + checked
                + "><span>" + esc(_wl2_human_label(str(item))) + "</span></label>"
            )
        input_html = "<div class='wl2-camera-radio-group'>" + "".join(choices) + "</div>"
    elif control["type"] == "boolean":
        current = str(value).lower() in {"1", "true", "yes", "on"}
        input_html = (
            "<div class='wl2-camera-radio-group'>"
            "<label class='wl2-camera-radio'><input type='radio' name='" + esc(field_name)
            + "' value='true'" + (" checked" if current else "") + "><span>On</span></label>"
            "<label class='wl2-camera-radio'><input type='radio' name='" + esc(field_name)
            + "' value='false'" + ("" if current else " checked") + "><span>Off</span></label>"
            "</div>"
        )
    elif control["type"] in {"integer", "number"} and control.get("minimum") is not None and control.get("maximum") is not None:
        minimum = control.get("minimum")
        maximum = control.get("maximum")
        step = "any" if control["type"] == "number" else "1"
        input_html = (
            "<div class='wl2-camera-slider-row'><input id='" + esc(field_id)
            + "' type='range' step='" + step + "' min='" + esc(minimum)
            + "' max='" + esc(maximum) + "' name='" + esc(field_name)
            + "' value='" + esc(value) + "' oninput=\"document.getElementById('"
            + esc(field_id) + "-value').value=this.value\">"
            "<output id='" + esc(field_id) + "-value'>" + esc(value) + "</output></div>"
        )
    elif control["type"] in {"integer", "number"}:
        step = "any" if control["type"] == "number" else "1"
        input_html = (
            "<input type='number' step='" + step + "' name='" + esc(field_name)
            + "' value='" + esc(value) + "'>"
        )
    else:
        input_html = "<input name='" + esc(field_name) + "' value='" + esc(value) + "'>"

    help_text = (
        "<div class='small' style='margin-top:6px'>" + description + "</div>"
        if description else ""
    )
    return (
        "<div class='wl2-camera-field'><label>" + label + "</label>"
        + input_html + help_text + "</div>"
    )

# BUTTON_CAMERA_WORKSPACE_V13_END



# GAMEPAD_FLOATING_REFERENCE_V14
# The gamepad reference can be released from the side drawer into a draggable,
# resizable overlay in the top-level Control Center workspace and docked again.




# BUTTON_LIVE_ASSIGNMENT_HIGHLIGHT_V15
_BUTTON_LIVE_STATE_FILE = "/tmp/siyi_button_live.json"


def _v15_read_button_live_state():
    now = time.time()
    payload = {}
    try:
        with open(_BUTTON_LIVE_STATE_FILE, "r", encoding="utf-8") as handle:
            loaded = json.load(handle)
        if isinstance(loaded, dict):
            payload = loaded
    except Exception:
        payload = {}

    try:
        source_ts = float(payload.get("ts") or 0.0)
    except Exception:
        source_ts = 0.0

    held = payload.get("held")
    if not isinstance(held, list):
        held = []

    normalized = []
    for value in held:
        name = str(value or "").strip().upper()
        if name and name not in normalized:
            normalized.append(name)

    # Clear the display quickly if input traffic stops or the bridge state file
    # becomes stale. This prevents a button remaining green after disconnect.
    age = max(0.0, now - source_ts) if source_ts else 999.0
    if age > 0.45:
        normalized = []

    return {
        "held": normalized,
        "source_ts": source_ts,
        "age_ms": int(age * 1000) if age < 999.0 else None,
        "fresh": age <= 0.45,
    }


_v15_previous_get = H.do_GET


def _v15_do_GET(self):
    parsed = urllib.parse.urlparse(self.path)

    if parsed.path == "/button_live_state":
        send_json_response(self, _v15_read_button_live_state(), 200)
        return

    if parsed.path == "/button_live_stream":
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()

        last_serialized = None
        last_heartbeat = 0.0
        try:
            while True:
                state = _v15_read_button_live_state()
                serialized = json.dumps(state, separators=(",", ":"))
                now = time.monotonic()

                if serialized != last_serialized:
                    self.wfile.write(("data: " + serialized + "\n\n").encode("utf-8"))
                    self.wfile.flush()
                    last_serialized = serialized
                    last_heartbeat = now
                elif now - last_heartbeat >= 10.0:
                    self.wfile.write(b": keepalive\n\n")
                    self.wfile.flush()
                    last_heartbeat = now

                # 20 ms sampling, with no deliberate UI debounce.
                time.sleep(0.02)
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            pass
        except Exception:
            pass
        return

    return _v15_previous_get(self)


H.do_GET = _v15_do_GET
# BUTTON_LIVE_ASSIGNMENT_HIGHLIGHT_V15_END



# SIYI_CONTROL_CENTER_RELEASE_4_0_1
# Release UI baseline: V15 cumulative interface.
# Missing Air Link profile-manager components are installed on demand from
# the packaged, non-user-specific payload under /usr/local/share/siyi/wifilink2.



# GROUND_STATION_MONITOR_POC_V1_START
# Read-only Ground Station proof of concept: dedicated telemetry daemon proxy,
# responsive HUD, vector navigation view, messages, and browser video using the
# existing MediaMTX main.264 path. No vehicle command endpoint is exposed.
GROUNDSTATION_INTERNAL_BASE = "http://127.0.0.1:18765"


def _groundstation_fetch(path, timeout=3.0):
    request = urllib.request.Request(
        GROUNDSTATION_INTERNAL_BASE + path,
        headers={"User-Agent": "SIYI-WebUI-GroundStation/1"},
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read(4 * 1024 * 1024)


def _groundstation_send_json(handler, path):
    try:
        raw = _groundstation_fetch(path)
        json.loads(raw.decode("utf-8"))
        status = 200
    except Exception as exc:
        raw = json.dumps(
            {
                "ok": False,
                "error": "Ground Station backend unavailable",
                "detail": str(exc),
            },
            ensure_ascii=False,
        ).encode("utf-8")
        status = 503
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)


def _groundstation_page():
    template = r'''<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta name="theme-color" content="#020617">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<title>SIYI Ground Station</title>
<style>
:root{--bg:#020617;--panel:rgba(7,18,38,.88);--line:#334155;--text:#f8fafc;--muted:#94a3b8;--ok:#22c55e;--warn:#f59e0b;--bad:#ef4444;--blue:#38bdf8}
*{box-sizing:border-box}html,body{margin:0;width:100%;height:100%;overflow:hidden;background:var(--bg);color:var(--text);font-family:Arial,Helvetica,sans-serif}
button{font:inherit}.gs-app{height:100vh;display:grid;grid-template-rows:auto 1fr auto;background:radial-gradient(circle at 50% 0,#0b1d38 0,#020617 45%)}
.gs-top{display:flex;align-items:center;gap:8px;padding:7px 9px;background:#020617;border-bottom:1px solid var(--line);min-height:52px;overflow-x:auto;white-space:nowrap;z-index:30}
.gs-brand{display:flex;align-items:center;gap:8px;font-weight:800;margin-right:4px}.gs-logo{width:31px;height:31px;border:1px solid #60a5fa;border-radius:8px;display:grid;place-items:center;color:#7dd3fc;background:#0b1930}
.gs-chip{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--line);background:#0b1220;padding:7px 9px;border-radius:9px;font-size:12px;font-weight:700}.gs-chip strong{font-size:13px}.gs-dot{width:9px;height:9px;border-radius:50%;background:#64748b}.gs-dot.ok{background:var(--ok);box-shadow:0 0 9px var(--ok)}.gs-dot.warn{background:var(--warn);box-shadow:0 0 9px var(--warn)}.gs-dot.bad{background:var(--bad);box-shadow:0 0 9px var(--bad)}
.gs-spacer{flex:1}.gs-btn{border:1px solid #475569;background:#111c31;color:var(--text);border-radius:9px;padding:8px 11px;cursor:pointer;font-weight:700}.gs-btn:hover,.gs-btn.active{background:#1d4ed8;border-color:#60a5fa}.gs-btn.warn{background:#78350f;border-color:#f59e0b}.gs-btn.compact{padding:6px 8px;font-size:12px}
.gs-main{min-height:0;display:grid;grid-template-columns:minmax(0,1fr) 300px;grid-template-rows:minmax(0,1fr);gap:8px;padding:8px}.gs-stage{min-width:0;min-height:0;position:relative;border:1px solid var(--line);border-radius:12px;overflow:hidden;background:#000}.gs-side{min-height:0;display:flex;flex-direction:column;gap:8px;overflow:auto}.gs-panel{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:10px}.gs-panel-title{font-size:12px;text-transform:uppercase;letter-spacing:.12em;color:#a5b4fc;margin-bottom:8px;font-weight:800}
.gs-view{position:absolute;inset:0;display:none}.gs-view.active{display:block}.gs-split{display:none;position:absolute;inset:0;grid-template-columns:1fr 1fr;gap:6px;background:#020617;padding:6px}.gs-split.active{display:grid}.gs-split>div{position:relative;min-width:0;min-height:0;border:1px solid #334155;border-radius:9px;overflow:hidden;background:#000}
.gs-video-frame{width:100%;height:100%;border:0;background:#000}.gs-video-overlay{position:absolute;inset:0;pointer-events:none}.gs-video-controls{position:absolute;left:10px;bottom:10px;display:flex;gap:6px;pointer-events:auto}.gs-video-state{position:absolute;top:10px;left:10px;background:rgba(2,6,23,.74);border:1px solid #475569;border-radius:8px;padding:6px 9px;font-size:12px}.gs-video-protocol{color:#7dd3fc;font-weight:800}
.gs-hud{position:absolute;inset:0;overflow:hidden;pointer-events:none}.gs-horizon-wrap{position:absolute;left:50%;top:50%;width:140%;height:140%;transform:translate(-50%,-50%);overflow:hidden}.gs-horizon{position:absolute;left:0;top:-50%;width:100%;height:200%;background:linear-gradient(to bottom,#2276a5 0,#4ca7d0 46%,#f1f5f9 49.6%,#334155 50%,#78552f 53%,#3d2b1d 100%);transform-origin:50% 50%;transition:transform .09s linear}.gs-hud-mask{position:absolute;inset:0;background:radial-gradient(circle,transparent 0,transparent 44%,rgba(0,0,0,.08) 70%,rgba(0,0,0,.36) 100%)}
.gs-aircraft-symbol{position:absolute;left:50%;top:50%;width:96px;height:22px;transform:translate(-50%,-50%)}.gs-aircraft-symbol:before,.gs-aircraft-symbol:after{content:"";position:absolute;top:9px;width:39px;height:3px;background:#ffd54a;box-shadow:0 0 3px #000}.gs-aircraft-symbol:before{left:0}.gs-aircraft-symbol:after{right:0}.gs-aircraft-symbol span{position:absolute;left:45px;top:3px;width:7px;height:15px;border:3px solid #ffd54a;border-top:0;border-radius:0 0 5px 5px}
.gs-heading{position:absolute;top:10px;left:50%;transform:translateX(-50%);background:rgba(2,6,23,.75);border:1px solid #64748b;border-radius:8px;padding:7px 13px;font-size:18px;font-weight:900}.gs-tape{position:absolute;top:19%;bottom:16%;width:92px;background:rgba(2,6,23,.58);border:1px solid rgba(148,163,184,.55);border-radius:10px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-shadow:0 2px 4px #000}.gs-tape.left{left:10px}.gs-tape.right{right:10px}.gs-tape .label{font-size:11px;color:#cbd5e1;text-transform:uppercase}.gs-tape .value{font-size:27px;font-weight:900}.gs-tape .secondary{font-size:12px;color:#bae6fd}.gs-mode-overlay{position:absolute;left:50%;bottom:12px;transform:translateX(-50%);background:rgba(2,6,23,.78);border:1px solid #64748b;border-radius:9px;padding:7px 13px;font-weight:900}.gs-data-lost{display:none;position:absolute;left:50%;top:24%;transform:translateX(-50%);background:#7f1d1d;border:1px solid #fca5a5;padding:8px 14px;border-radius:9px;font-weight:900}.gs-data-lost.show{display:block}
.gs-map{width:100%;height:100%;display:block;background:#07111f;touch-action:none}.gs-map-note{position:absolute;left:10px;top:10px;background:rgba(2,6,23,.78);border:1px solid #334155;padding:6px 9px;border-radius:8px;font-size:11px;color:#cbd5e1}.gs-map-controls{position:absolute;right:10px;top:10px;display:flex;flex-direction:column;gap:5px}.gs-map-controls button{width:34px;height:34px;border:1px solid #64748b;border-radius:8px;background:rgba(2,6,23,.82);color:white;font-size:18px;cursor:pointer}
.gs-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}.gs-tile{background:#081427;border:1px solid #334155;border-radius:9px;padding:8px}.gs-tile .k{font-size:10px;color:#94a3b8;text-transform:uppercase;letter-spacing:.08em}.gs-tile .v{font-size:19px;font-weight:900;margin-top:3px}.gs-tile .s{font-size:10px;color:#64748b;margin-top:2px}.gs-attitude{height:110px;position:relative;overflow:hidden;border-radius:9px;border:1px solid #334155;background:#111827}.gs-mini-horizon{position:absolute;left:-25%;top:-100%;width:150%;height:300%;background:linear-gradient(#3184b5 0,#54a8cf 48.5%,#e2e8f0 49.5%,#6b4a2d 50.5%,#362516 100%);transform-origin:50% 50%;transition:transform .09s linear}.gs-mini-symbol{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);color:#fde047;font-size:30px;font-weight:900;text-shadow:0 1px 4px #000}.gs-mission-line{font-size:13px;line-height:1.55}.gs-message-list{height:126px;overflow:auto;font-size:12px}.gs-message{border-left:3px solid #64748b;padding:5px 7px;margin-bottom:5px;background:#07111f}.gs-message.Warning{border-color:var(--warn)}.gs-message.Error,.gs-message.Critical,.gs-message.Emergency,.gs-message.Alert{border-color:var(--bad)}.gs-message-time{color:#64748b;margin-right:6px}
.gs-bottom{display:grid;grid-template-columns:auto 1fr auto;align-items:center;gap:8px;padding:7px 9px;border-top:1px solid var(--line);background:#020617;min-height:48px}.gs-layout-buttons,.gs-source-buttons{display:flex;gap:5px;flex-wrap:wrap}.gs-alert{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#cbd5e1;font-size:12px}.gs-monitor{color:#86efac;border:1px solid #166534;background:#052e16;padding:6px 9px;border-radius:8px;font-size:11px;font-weight:900}
.gs-pip{position:absolute;right:14px;bottom:14px;width:min(32%,360px);height:min(30%,230px);border:2px solid #94a3b8;border-radius:10px;overflow:hidden;z-index:15;box-shadow:0 12px 35px rgba(0,0,0,.5);cursor:pointer;background:#020617}.gs-pip .gs-map,.gs-pip .gs-video-frame{pointer-events:none}.gs-pip-label{position:absolute;left:6px;top:6px;background:rgba(2,6,23,.78);padding:4px 7px;border-radius:6px;font-size:10px;z-index:4;max-width:calc(100% - 12px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.gs-pip-sourcebar{position:absolute;left:6px;right:6px;bottom:6px;z-index:6;display:grid;grid-template-columns:1fr 1fr;gap:5px;pointer-events:auto;background:rgba(2,6,23,.72);border:1px solid rgba(100,116,139,.8);border-radius:8px;padding:5px;cursor:default}.gs-pip-sourcebar .gs-btn{min-width:0;padding:5px 6px;font-size:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.gs-pip-sourcebar .gs-btn:disabled{opacity:.52;cursor:wait}.gs-pip-switching{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);z-index:7;display:none;background:rgba(2,6,23,.9);border:1px solid #60a5fa;border-radius:8px;padding:7px 10px;font-size:11px;font-weight:900;color:#bae6fd;pointer-events:none}.gs-pip-switching.show{display:block}
@media(max-width:1000px){.gs-main{grid-template-columns:minmax(0,1fr) 250px}.gs-tape{width:77px}.gs-tape .value{font-size:23px}}
@media(max-width:760px){.gs-main{grid-template-columns:1fr;padding:4px}.gs-side{position:absolute;right:6px;top:59px;bottom:55px;width:min(84vw,310px);z-index:40;transform:translateX(110%);transition:transform .2s;background:#020617;padding:5px;border-left:1px solid #334155}.gs-side.open{transform:translateX(0)}.gs-top{min-height:48px}.gs-brand span:last-child{display:none}.gs-chip.optional{display:none}.gs-bottom{grid-template-columns:1fr auto}.gs-source-buttons{display:none}.gs-alert{grid-column:1/-1}.gs-pip{width:42%;height:30%;right:8px;bottom:8px}.gs-pip-sourcebar{left:4px;right:4px;bottom:4px;padding:3px;gap:3px}.gs-pip-sourcebar .gs-btn{padding:4px 3px;font-size:9px}.gs-tape{top:24%;bottom:20%;width:68px}.gs-tape .value{font-size:21px}.gs-tape.left{left:5px}.gs-tape.right{right:5px}.gs-split.active{grid-template-columns:1fr;grid-template-rows:1fr 1fr}}
.gs-camera-label{position:absolute;left:7px;top:7px;z-index:8;background:rgba(2,6,23,.84);border:1px solid rgba(100,116,139,.8);border-radius:7px;padding:5px 8px;font-size:11px;font-weight:900;max-width:calc(100% - 14px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;pointer-events:none}
#splitSecondaryPane .gs-video-frame{pointer-events:none}.gs-audio-controls{display:flex;align-items:center;gap:5px}.gs-volume{width:76px;accent-color:#38bdf8}.gs-btn.audio-on{background:#14532d;border-color:#4ade80}.gs-btn.audio-muted{background:#78350f;border-color:#f59e0b}.gs-dual-status{display:flex;align-items:center;gap:7px;min-width:0;font-size:11px;color:#bae6fd}.gs-dual-status span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
@media(max-width:760px){.gs-volume{display:none}.gs-audio-controls .audio-secondary{display:none}.gs-camera-label{font-size:9px;padding:4px 6px}}
.gs-video-frame{object-fit:cover;background:#000}
.gs-dual-status #airlinkBufferState{color:#94a3b8}
.gs-dual-status #airlinkBufferState.warn{color:#fbbf24}
.gs-dual-status #airlinkBufferState.bad{color:#f87171}
.gs-btn.resyncing{opacity:.65;cursor:wait}
@media(max-width:760px){#airlinkBufferState{max-width:125px}.gs-dual-status{gap:4px}.gs-dual-status .gs-btn{padding:5px 6px;font-size:9px}}

/* GROUND_STATION_FULLSCREEN_FLIGHT_UI_V6 */
:root{--gs-top-clear:58px;--gs-bottom-clear:54px}
.gs-app{position:relative;height:100dvh;min-height:100vh;display:block;background:#000;isolation:isolate}
.gs-main{position:absolute;inset:0;display:block;min-height:0;padding:0;z-index:1}
.gs-stage{position:absolute;inset:0;min-width:0;min-height:0;border:0;border-radius:0;overflow:hidden;background:#000}
.gs-view,.gs-split{z-index:1}
#videoView>.gs-video-frame{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.gs-top{position:absolute;left:0;right:0;top:0;z-index:70;min-height:var(--gs-top-clear);padding:7px 9px;background:linear-gradient(to bottom,rgba(2,6,23,.90),rgba(2,6,23,.66));border-bottom:1px solid rgba(148,163,184,.38);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px)}
.gs-bottom{position:absolute;left:0;right:0;bottom:0;z-index:70;min-height:var(--gs-bottom-clear);padding:7px 9px;background:linear-gradient(to top,rgba(2,6,23,.92),rgba(2,6,23,.62));border-top:1px solid rgba(148,163,184,.38);backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px)}
.gs-side{position:absolute;right:8px;top:calc(var(--gs-top-clear) + 8px);bottom:calc(var(--gs-bottom-clear) + 8px);width:min(360px,92vw);z-index:85;display:flex;transform:translateX(calc(100% + 24px));transition:transform .2s ease;background:rgba(2,6,23,.86);border:1px solid rgba(100,116,139,.75);border-radius:12px;padding:7px;overflow:auto;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);box-shadow:0 18px 50px rgba(0,0,0,.45)}
.gs-side.open{transform:translateX(0)}
.gs-panel{background:rgba(7,18,38,.70)}
.gs-video-overlay{z-index:18}
.gs-video-state{top:calc(var(--gs-top-clear) + 8px);background:rgba(2,6,23,.58);backdrop-filter:blur(4px)}
.gs-video-controls{bottom:calc(var(--gs-bottom-clear) + 8px)}
.gs-hud{z-index:22;overflow:visible}
.gs-attitude-overlay{position:absolute;left:50%;top:50%;width:clamp(250px,36vw,370px);height:clamp(140px,21vw,205px);transform:translate(-50%,-50%);border:1px solid rgba(226,232,240,.68);border-radius:16px;overflow:hidden;background:rgba(2,6,23,.16);box-shadow:0 10px 34px rgba(0,0,0,.26),inset 0 0 26px rgba(2,6,23,.22);backdrop-filter:blur(1.5px);-webkit-backdrop-filter:blur(1.5px);transition:opacity .15s ease,border-color .15s ease}
.gs-attitude-overlay.stale{border-color:rgba(248,113,113,.78)}
.gs-attitude-overlay .gs-horizon-wrap{position:absolute;inset:0;width:100%;height:100%;transform:none;overflow:hidden}
.gs-attitude-overlay .gs-horizon{left:-25%;top:-50%;width:150%;height:200%;background:linear-gradient(to bottom,rgba(34,118,165,.46) 0,rgba(76,167,208,.38) 46%,rgba(241,245,249,.78) 49.3%,rgba(241,245,249,.88) 50%,rgba(120,85,47,.40) 52%,rgba(61,43,29,.46) 100%);transition:transform .08s linear}
.gs-attitude-overlay:before{content:"";position:absolute;left:50%;top:12%;bottom:12%;width:1px;background:linear-gradient(transparent,rgba(226,232,240,.55),transparent);z-index:2}
.gs-attitude-overlay:after{content:"";position:absolute;top:50%;left:8%;right:8%;height:1px;background:rgba(226,232,240,.66);box-shadow:0 -24px 0 rgba(226,232,240,.28),0 24px 0 rgba(226,232,240,.28);z-index:2}
.gs-attitude-overlay .gs-hud-mask{position:absolute;inset:0;background:radial-gradient(circle,transparent 0,rgba(2,6,23,.04) 54%,rgba(2,6,23,.34) 100%);z-index:3}
.gs-attitude-overlay .gs-aircraft-symbol{z-index:6}
.gs-attitude-overlay .gs-heading{z-index:7;top:7px;padding:4px 10px;font-size:15px;background:rgba(2,6,23,.52)}
.gs-attitude-numbers{position:absolute;left:8px;right:8px;bottom:7px;z-index:7;display:flex;justify-content:center;gap:12px;font-size:11px;font-weight:800;color:#e2e8f0;text-shadow:0 1px 3px #000}
.gs-attitude-overlay .gs-data-lost{left:50%;top:auto;bottom:31px;z-index:9;padding:5px 9px;font-size:10px;white-space:nowrap;background:rgba(127,29,29,.82)}
.gs-telemetry-overlay{position:absolute;left:10px;bottom:calc(var(--gs-bottom-clear) + 10px);z-index:24;width:min(250px,31vw);display:grid;grid-template-columns:repeat(2,minmax(92px,1fr));gap:7px}
.gs-telemetry-box{min-width:0;padding:8px 9px;border:1px solid rgba(148,163,184,.48);border-radius:10px;background:rgba(2,6,23,.52);box-shadow:0 6px 20px rgba(0,0,0,.18);backdrop-filter:blur(5px);-webkit-backdrop-filter:blur(5px);text-shadow:0 2px 4px rgba(0,0,0,.9)}
.gs-telemetry-box .label{display:block;font-size:9px;letter-spacing:.10em;color:#cbd5e1;text-transform:uppercase}
.gs-telemetry-box .reading{display:flex;align-items:baseline;gap:4px;margin-top:2px;white-space:nowrap}
.gs-telemetry-box strong{font-size:22px;line-height:1;font-weight:900;overflow:hidden;text-overflow:ellipsis}
.gs-telemetry-box em{font-size:9px;color:#bae6fd;font-style:normal}
.gs-pip{right:10px;bottom:calc(var(--gs-bottom-clear) + 10px);z-index:36;touch-action:none;user-select:none;-webkit-user-select:none;will-change:left,top;cursor:grab}
.gs-pip.dragging{cursor:grabbing;box-shadow:0 14px 42px rgba(0,0,0,.62);border-color:#7dd3fc}
.gs-pip-label{cursor:grab}
.gs-mode-overlay,.gs-tape{display:none!important}
@media(max-width:1000px){.gs-main{display:block}.gs-side{width:min(340px,92vw)}.gs-telemetry-overlay{width:min(240px,34vw)}}
@media(max-width:760px){
 :root{--gs-top-clear:52px;--gs-bottom-clear:50px}
 .gs-main{padding:0}.gs-stage{border:0;border-radius:0}
 .gs-side{right:5px;top:calc(var(--gs-top-clear) + 5px);bottom:calc(var(--gs-bottom-clear) + 5px);width:min(330px,92vw);padding:5px}
 .gs-top{min-height:var(--gs-top-clear)}.gs-bottom{min-height:var(--gs-bottom-clear)}
 .gs-attitude-overlay{width:min(58vw,330px);height:min(33vw,185px)}
 .gs-telemetry-overlay{left:7px;bottom:calc(var(--gs-bottom-clear) + 7px);width:min(230px,42vw);gap:5px}
 .gs-telemetry-box{padding:6px 7px}.gs-telemetry-box strong{font-size:19px}
 .gs-pip{width:38%;height:27%;right:7px;bottom:calc(var(--gs-bottom-clear) + 7px)}
 .gs-video-state{top:calc(var(--gs-top-clear) + 5px);left:7px}.gs-video-controls{left:7px;bottom:calc(var(--gs-bottom-clear) + 7px)}
}

/* GROUND_STATION_PHONE_HUD_UI_V7 */
:root{--gs-top-clear:40px;--gs-bottom-clear:34px}
.gs-top,.gs-bottom{
  background:transparent!important;
  border:0!important;
  box-shadow:none!important;
  backdrop-filter:none!important;
  -webkit-backdrop-filter:none!important;
  min-height:0!important;
  max-height:none;
  white-space:nowrap;
}
.gs-top{
  height:var(--gs-top-clear);
  padding:2px 5px!important;
  gap:4px!important;
  overflow-x:auto;
  overflow-y:hidden;
  scrollbar-width:none;
}
.gs-top::-webkit-scrollbar,.gs-bottom::-webkit-scrollbar{display:none}
.gs-bottom{
  height:var(--gs-bottom-clear);
  padding:2px 5px!important;
  gap:4px!important;
  display:flex!important;
  align-items:center;
  overflow-x:auto;
  overflow-y:hidden;
}
.gs-brand,.gs-chip,.gs-monitor,.gs-video-state,.gs-pip-label,.gs-camera-label{
  background:transparent!important;
  box-shadow:none!important;
  backdrop-filter:none!important;
  -webkit-backdrop-filter:none!important;
}
.gs-chip,.gs-monitor{
  border-color:rgba(226,232,240,.34)!important;
  padding:3px 6px!important;
  border-radius:6px!important;
  text-shadow:0 1px 3px rgba(0,0,0,.95);
}
.gs-btn,
.gs-btn:hover,
.gs-btn:focus,
.gs-btn.active,
.gs-btn.warn,
.gs-btn.audio-on,
.gs-btn.audio-muted{
  background:transparent!important;
  box-shadow:none!important;
  backdrop-filter:none!important;
  -webkit-backdrop-filter:none!important;
  border-color:rgba(226,232,240,.38)!important;
  color:#f8fafc!important;
  text-shadow:0 1px 3px rgba(0,0,0,.95);
}
.gs-btn.active,.gs-btn:focus-visible{
  border-color:#7dd3fc!important;
  color:#bae6fd!important;
  outline:none;
}
.gs-btn.compact{padding:4px 7px!important;font-size:10px!important;border-radius:6px!important}
.gs-layout-buttons,.gs-source-buttons,.gs-dual-status,.gs-audio-controls{flex-wrap:nowrap!important;flex:0 0 auto}
.gs-alert{flex:1 0 180px;text-shadow:0 1px 3px #000}
.gs-monitor{flex:0 0 auto;font-size:9px!important}

/* Only the moving level line and the small orange aircraft remain. */
.gs-attitude-overlay{
  position:absolute;
  left:50%;
  top:50%;
  width:clamp(200px,34vw,340px)!important;
  height:clamp(72px,12vw,112px)!important;
  transform:translate(-50%,-50%);
  overflow:visible!important;
  border:0!important;
  border-radius:0!important;
  background:transparent!important;
  box-shadow:none!important;
  backdrop-filter:none!important;
  -webkit-backdrop-filter:none!important;
  pointer-events:none;
}
.gs-attitude-overlay.stale{border:0!important;opacity:.55}
.gs-attitude-overlay:before,.gs-attitude-overlay:after,
.gs-attitude-overlay .gs-hud-mask,
.gs-attitude-overlay .gs-heading,
.gs-attitude-overlay .gs-attitude-numbers,
.gs-attitude-overlay .gs-data-lost{display:none!important}
.gs-attitude-overlay .gs-horizon-wrap{position:absolute;inset:0;overflow:visible!important}
.gs-attitude-overlay .gs-horizon{
  position:absolute!important;
  left:-15%!important;
  top:50%!important;
  width:130%!important;
  height:0!important;
  background:none!important;
  border:0!important;
  border-top:2px solid rgba(248,250,252,.94)!important;
  box-shadow:0 1px 3px rgba(0,0,0,.95)!important;
  transform-origin:50% 0!important;
  transition:transform .08s linear;
}
.gs-attitude-overlay .gs-horizon:before,
.gs-attitude-overlay .gs-horizon:after{
  content:"";
  position:absolute;
  top:-5px;
  width:1px;
  height:9px;
  background:rgba(248,250,252,.94);
  box-shadow:0 1px 2px #000;
}
.gs-attitude-overlay .gs-horizon:before{left:34%}
.gs-attitude-overlay .gs-horizon:after{right:34%}
.gs-attitude-overlay .gs-aircraft-symbol{
  z-index:6;
  width:72px!important;
  height:18px!important;
}
.gs-attitude-overlay .gs-aircraft-symbol:before,
.gs-attitude-overlay .gs-aircraft-symbol:after{
  top:8px!important;
  width:28px!important;
  height:3px!important;
  background:#ff8a00!important;
  box-shadow:0 0 3px rgba(0,0,0,.95)!important;
}
.gs-attitude-overlay .gs-aircraft-symbol span{
  left:33px!important;
  top:3px!important;
  width:6px!important;
  height:12px!important;
  border-color:#ff8a00!important;
  border-width:3px!important;
  box-shadow:0 1px 2px rgba(0,0,0,.75);
}

/* Telemetry retains grouping but has no fill, border, blur or box shadow. */
.gs-telemetry-overlay{
  left:6px!important;
  bottom:calc(var(--gs-bottom-clear) + 5px)!important;
  width:min(244px,34vw)!important;
  gap:4px!important;
}
.gs-telemetry-box{
  padding:3px 5px!important;
  border:0!important;
  border-radius:0!important;
  background:transparent!important;
  box-shadow:none!important;
  backdrop-filter:none!important;
  -webkit-backdrop-filter:none!important;
  text-shadow:0 2px 4px rgba(0,0,0,1)!important;
}
.gs-telemetry-box .label{font-size:8px!important;color:#e2e8f0!important}
.gs-telemetry-box .reading{margin-top:0!important;gap:3px!important}
.gs-telemetry-box strong{font-size:19px!important}
.gs-telemetry-box em{font-size:8px!important;color:#e0f2fe!important}
.gs-mode-overlay{background:transparent!important;border:0!important;box-shadow:none!important;text-shadow:0 1px 4px #000}

/* Movable and touch-resizable PiP. */
.gs-pip{
  min-width:120px;
  min-height:76px;
  max-width:72vw;
  max-height:64vh;
  border:1px solid rgba(226,232,240,.58)!important;
  box-shadow:0 7px 20px rgba(0,0,0,.38)!important;
}
.gs-pip-resize{
  position:absolute;
  right:0;
  bottom:0;
  z-index:12;
  width:28px;
  height:28px;
  padding:0;
  border:0;
  border-radius:10px 0 0 0;
  background:linear-gradient(135deg,transparent 0 44%,rgba(255,138,0,.95) 45% 54%,transparent 55% 66%,rgba(255,138,0,.95) 67% 76%,transparent 77%)!important;
  cursor:nwse-resize;
  touch-action:none;
  opacity:.88;
}
.gs-pip.resizing{cursor:nwse-resize!important;border-color:#ff8a00!important}

@media(max-width:760px), (max-height:560px){
  :root{--gs-top-clear:32px;--gs-bottom-clear:29px}
  .gs-top{height:var(--gs-top-clear);padding:1px 3px!important;gap:3px!important}
  .gs-bottom{height:var(--gs-bottom-clear);padding:1px 3px!important;gap:3px!important}
  .gs-logo{width:23px!important;height:23px!important;font-size:9px!important;border-radius:5px!important}
  .gs-brand{gap:2px!important}
  .gs-brand span{display:none!important}
  .gs-chip{padding:2px 4px!important;font-size:9px!important;border-radius:5px!important}
  .gs-chip.optional{display:none!important}
  .gs-btn.compact{height:25px;padding:2px 5px!important;font-size:9px!important;border-radius:5px!important}
  .gs-audio-controls{gap:3px!important}
  #audioMuteBtn,#audioTestBtn,#audioVolume{display:none!important}
  .gs-monitor{padding:2px 4px!important;font-size:8px!important}
  .gs-alert{display:none!important}
  .gs-dual-status{gap:3px!important;font-size:9px!important}
  #dualVideoSummary{display:none!important}
  #airlinkBufferState{max-width:92px!important}
  .gs-side{top:calc(var(--gs-top-clear) + 3px)!important;bottom:calc(var(--gs-bottom-clear) + 3px)!important}
  .gs-video-state{top:calc(var(--gs-top-clear) + 3px)!important;left:4px!important;padding:2px 4px!important;font-size:8px!important}
  .gs-video-controls{left:4px!important;bottom:calc(var(--gs-bottom-clear) + 3px)!important;gap:3px!important}
  .gs-attitude-overlay{width:min(48vw,235px)!important;height:min(21vw,78px)!important}
  .gs-attitude-overlay .gs-aircraft-symbol{width:64px!important}
  .gs-attitude-overlay .gs-aircraft-symbol:before,.gs-attitude-overlay .gs-aircraft-symbol:after{width:24px!important}
  .gs-attitude-overlay .gs-aircraft-symbol span{left:29px!important}
  .gs-telemetry-overlay{
    left:3px!important;
    bottom:calc(var(--gs-bottom-clear) + 3px)!important;
    width:auto!important;
    max-width:52vw;
    grid-template-columns:repeat(2,minmax(72px,1fr))!important;
    gap:2px 7px!important;
  }
  .gs-telemetry-box{padding:1px 2px!important}
  .gs-telemetry-box .label{font-size:7px!important;letter-spacing:.06em!important}
  .gs-telemetry-box strong{font-size:16px!important}
  .gs-telemetry-box em{font-size:7px!important}
  .gs-pip{
    width:34vw;
    height:24vh;
    min-width:110px;
    min-height:68px;
    max-width:68vw;
    max-height:58vh;
    right:4px;
    bottom:calc(var(--gs-bottom-clear) + 4px);
    border-radius:7px!important;
  }
  .gs-camera-label{font-size:8px!important;padding:2px 4px!important}
  .gs-pip-resize{width:30px;height:30px}
}

/* GROUND_STATION_PHONE_HUD_CLEANUP_V8 */

/* Remove duplicate lower-left telemetry and diagnostic clutter. */
.gs-telemetry-overlay{display:none!important}
.gs-dual-status,.gs-monitor{display:none!important}
#airlinkBufferState,#resyncAirlinkBtn,#swapCamerasBtn{display:none!important}

/* Split means navigation map plus the currently selected main camera. */
.gs-split{
  grid-template-columns:1fr 1fr!important;
  gap:1px!important;
  padding:0!important;
  background:transparent!important;
}
.gs-split>div{
  border:0!important;
  border-radius:0!important;
  background:#000!important;
}
.gs-split-map-pane{position:relative;min-width:0;min-height:0}
.gs-split-video-pane{position:relative;min-width:0;min-height:0}
.gs-split-video-pane .gs-video-frame{position:absolute;inset:0;object-fit:cover}

/* Instruments: only text and values remain visible. */
.gs-side{
  --instrument-scale:1;
  right:auto!important;
  bottom:auto!important;
  width:min(330px,92vw)!important;
  height:min(72vh,520px)!important;
  min-width:180px!important;
  min-height:140px!important;
  max-width:96vw!important;
  max-height:calc(100dvh - var(--gs-top-clear) - var(--gs-bottom-clear) - 6px)!important;
  padding:0!important;
  overflow:hidden!important;
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
  backdrop-filter:none!important;
  -webkit-backdrop-filter:none!important;
  touch-action:none;
}
.gs-side.open{transform:none!important}
.gs-instruments-drag{
  position:absolute;
  left:0;
  right:0;
  top:0;
  z-index:5;
  height:22px;
  display:flex;
  align-items:center;
  justify-content:center;
  color:#e2e8f0;
  font-size:calc(10px * var(--instrument-scale));
  font-weight:900;
  letter-spacing:.12em;
  text-shadow:0 2px 4px #000;
  cursor:grab;
  touch-action:none;
  user-select:none;
  -webkit-user-select:none;
}
.gs-side.instrument-dragging .gs-instruments-drag{cursor:grabbing}
.gs-instruments-content{
  position:absolute;
  left:0;
  right:0;
  top:22px;
  bottom:0;
  overflow:auto;
  padding:0;
  scrollbar-width:none;
  touch-action:pan-y;
}
.gs-instruments-content::-webkit-scrollbar{display:none}
.gs-side .gs-panel,
.gs-side .gs-tile,
.gs-side .gs-message{
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
  backdrop-filter:none!important;
  -webkit-backdrop-filter:none!important;
}
.gs-side .gs-panel{padding:calc(5px * var(--instrument-scale))!important}
.gs-side .gs-panel-title{
  margin-bottom:calc(5px * var(--instrument-scale))!important;
  font-size:calc(10px * var(--instrument-scale))!important;
  color:#c7d2fe!important;
  text-shadow:0 2px 4px #000;
}
.gs-side .gs-grid{gap:calc(4px * var(--instrument-scale))!important}
.gs-side .gs-tile{padding:calc(4px * var(--instrument-scale))!important;text-shadow:0 2px 4px #000}
.gs-side .gs-tile .k{
  font-size:calc(8px * var(--instrument-scale))!important;
  color:#cbd5e1!important;
}
.gs-side .gs-tile .v{
  font-size:calc(16px * var(--instrument-scale))!important;
  margin-top:calc(1px * var(--instrument-scale))!important;
}
.gs-side .gs-tile .s{
  font-size:calc(8px * var(--instrument-scale))!important;
  color:#cbd5e1!important;
}
.gs-side .gs-mission-line{
  font-size:calc(11px * var(--instrument-scale))!important;
  line-height:1.4!important;
  text-shadow:0 2px 4px #000;
}
.gs-side .gs-message-list{
  height:calc(120px * var(--instrument-scale))!important;
  font-size:calc(10px * var(--instrument-scale))!important;
}
.gs-side .gs-message{
  padding:calc(3px * var(--instrument-scale))!important;
  margin-bottom:calc(2px * var(--instrument-scale))!important;
  text-shadow:0 2px 4px #000;
}
.gs-instruments-resize{
  position:absolute;
  z-index:9;
  width:34px;
  height:34px;
  padding:0;
  border:0;
  background:transparent;
  opacity:.01;
  touch-action:none;
}
.gs-instruments-resize.nw{left:0;top:0;cursor:nwse-resize}
.gs-instruments-resize.ne{right:0;top:0;cursor:nesw-resize}
.gs-instruments-resize.sw{left:0;bottom:0;cursor:nesw-resize}
.gs-instruments-resize.se{right:0;bottom:0;cursor:nwse-resize}

/* PiP can be resized from every corner. */
.gs-pip-resize{
  width:32px!important;
  height:32px!important;
  border:0!important;
  border-radius:0!important;
  background:transparent!important;
  opacity:1!important;
  touch-action:none!important;
}
.gs-pip-resize.nw{left:0!important;right:auto!important;top:0!important;bottom:auto!important;cursor:nwse-resize!important}
.gs-pip-resize.ne{right:0!important;left:auto!important;top:0!important;bottom:auto!important;cursor:nesw-resize!important}
.gs-pip-resize.sw{left:0!important;right:auto!important;bottom:0!important;top:auto!important;cursor:nesw-resize!important}
.gs-pip-resize.se{right:0!important;left:auto!important;bottom:0!important;top:auto!important;cursor:nwse-resize!important}
.gs-pip-resize:before{
  content:"";
  position:absolute;
  width:10px;
  height:10px;
  border-color:#ff8a00;
  border-style:solid;
  filter:drop-shadow(0 1px 1px #000);
}
.gs-pip-resize.nw:before{left:4px;top:4px;border-width:2px 0 0 2px}
.gs-pip-resize.ne:before{right:4px;top:4px;border-width:2px 2px 0 0}
.gs-pip-resize.sw:before{left:4px;bottom:4px;border-width:0 0 2px 2px}
.gs-pip-resize.se:before{right:4px;bottom:4px;border-width:0 2px 2px 0}

/* Phone-first vertical efficiency. */
@media(max-width:760px), (max-height:560px){
  :root{--gs-top-clear:28px;--gs-bottom-clear:24px}
  .gs-top{height:var(--gs-top-clear)!important;padding:1px 2px!important;gap:2px!important}
  .gs-bottom{height:var(--gs-bottom-clear)!important;padding:1px 2px!important;gap:2px!important}
  .gs-logo{width:21px!important;height:21px!important}
  .gs-chip{padding:1px 3px!important;font-size:8px!important}
  .gs-btn.compact{height:21px!important;padding:1px 4px!important;font-size:8px!important}
  .gs-layout-buttons{gap:2px!important}
  .gs-side{
    max-height:calc(100dvh - var(--gs-top-clear) - var(--gs-bottom-clear) - 4px)!important;
  }
  .gs-instruments-drag{height:19px}
  .gs-instruments-content{top:19px}
  .gs-pip-resize{width:34px!important;height:34px!important}
}


/* GROUND_STATION_PHONE_HUD_REFINEMENT_V9 */

/* Remove obsolete/diagnostic text without touching the WebRTC sessions. */
#heartbeatAge,.gs-video-protocol,.gs-video-controls{display:none!important}
.gs-video-state{display:block!important}
.gs-video-state span{display:inline!important}
#controlCenterBtn{display:inline-flex;align-items:center;justify-content:center;text-decoration:none}

/* Instruments disappear completely when closed. */
.gs-side:not(.open){
  display:none!important;
  visibility:hidden!important;
  pointer-events:none!important;
}
.gs-side.open{
  display:block!important;
  visibility:visible!important;
  pointer-events:auto!important;
  transform:none!important;
}
.gs-side{
  --instrument-scale:1;
  position:fixed!important;
  z-index:90!important;
  left:auto;
  right:2px!important;
  top:calc(var(--gs-top-clear) + 2px)!important;
  bottom:auto!important;
  width:min(300px,46vw)!important;
  height:min(70vh,480px)!important;
  min-width:150px!important;
  min-height:120px!important;
  max-width:calc(100vw - 4px)!important;
  max-height:calc(100dvh - var(--gs-top-clear) - var(--gs-bottom-clear) - 4px)!important;
  margin:0!important;
  padding:0!important;
  overflow:hidden!important;
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
  backdrop-filter:none!important;
  -webkit-backdrop-filter:none!important;
  transition:none!important;
  touch-action:none!important;
}
.gs-instruments-drag{
  height:22px!important;
  cursor:grab;
  touch-action:none!important;
}
.gs-side.instrument-dragging .gs-instruments-drag{cursor:grabbing}
.gs-instruments-content{top:22px!important;touch-action:pan-y!important}
.gs-side .gs-grid{
  display:grid!important;
  grid-template-columns:repeat(auto-fit,minmax(105px,1fr))!important;
  align-items:start!important;
  gap:calc(4px * var(--instrument-scale))!important;
}
.gs-side .gs-tile{min-width:0!important}
.gs-instruments-resize{
  width:48px!important;
  height:48px!important;
  opacity:0!important;
  pointer-events:auto!important;
  touch-action:none!important;
}

/* Long-hold PiP minimises it to an edge control while the video stays attached. */
.gs-pip-edge-button{display:none}
.gs-pip.pip-minimized{
  left:auto!important;
  top:auto!important;
  right:0!important;
  bottom:var(--gs-bottom-clear)!important;
  width:38px!important;
  height:48px!important;
  min-width:38px!important;
  min-height:48px!important;
  border:1px solid rgba(255,138,0,.92)!important;
  border-right:0!important;
  border-radius:10px 0 0 10px!important;
  overflow:hidden!important;
  background:rgba(2,6,23,.22)!important;
  box-shadow:none!important;
  cursor:pointer!important;
}
.gs-pip.pip-minimized .gs-video-frame{
  position:absolute!important;
  left:0!important;
  top:0!important;
  width:1px!important;
  height:1px!important;
  opacity:0!important;
  pointer-events:none!important;
}
.gs-pip.pip-minimized .gs-camera-label,
.gs-pip.pip-minimized .gs-pip-resize{display:none!important}
.gs-pip.pip-minimized .gs-pip-edge-button{
  position:absolute;
  inset:0;
  z-index:20;
  display:flex!important;
  align-items:center;
  justify-content:center;
  padding:0;
  border:0;
  background:transparent;
  color:#ff9b28;
  font-size:9px;
  font-weight:900;
  letter-spacing:.08em;
  text-shadow:0 1px 3px #000;
  touch-action:manipulation;
}

@media(max-width:760px), (max-height:560px){
  .gs-side{
    width:min(280px,46vw)!important;
    height:min(72dvh,430px)!important;
    min-width:145px!important;
    min-height:110px!important;
  }
  .gs-instruments-drag{height:19px!important;font-size:calc(9px * var(--instrument-scale))!important}
  .gs-instruments-content{top:19px!important}
  .gs-side .gs-grid{grid-template-columns:repeat(auto-fit,minmax(92px,1fr))!important}
  .gs-instruments-resize{width:50px!important;height:50px!important}
}


/* GROUND_STATION_PHONE_HUD_TELEMETRY_V10 */

/* Stream name only: protocol text is removed from the DOM in V10. */
.gs-video-state{display:block!important}
.gs-video-protocol{display:none!important}

/* The connection chip also opens the vehicle-message viewer. */
.gs-connection-chip{
  appearance:none;
  -webkit-appearance:none;
  font:inherit;
  color:inherit;
  cursor:pointer;
  touch-action:manipulation;
}
.gs-connection-chip:active{opacity:.72}

/* Telemetry-only panel. No heading, frame or background. */
.gs-side{
  --instrument-scale:1;
  left:var(--telemetry-left,calc(100vw - var(--telemetry-width,156px) - 2px))!important;
  top:var(--telemetry-top,calc(100dvh - var(--telemetry-height,300px) - 2px))!important;
  right:auto!important;
  bottom:auto!important;
  width:var(--telemetry-width,156px)!important;
  height:var(--telemetry-height,300px)!important;
  min-width:112px!important;
  min-height:76px!important;
  max-width:calc(100vw - 4px)!important;
  max-height:calc(100dvh - var(--gs-top-clear) - 4px)!important;
  z-index:96!important;
  overflow:hidden!important;
  padding:0!important;
  margin:0!important;
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
  backdrop-filter:none!important;
  -webkit-backdrop-filter:none!important;
  touch-action:none!important;
  user-select:none;
  -webkit-user-select:none;
}
.gs-side.open{display:block!important;visibility:visible!important;pointer-events:auto!important}
.gs-side:not(.open){display:none!important;visibility:hidden!important;pointer-events:none!important}
.gs-telemetry-content{
  position:absolute;
  inset:0;
  overflow:hidden;
  padding:0;
  touch-action:none;
}
.gs-side #telemetryGrid{
  display:grid!important;
  grid-template-columns:repeat(auto-fit,minmax(min(106px,100%),1fr))!important;
  grid-auto-flow:row!important;
  align-content:start!important;
  align-items:stretch!important;
  gap:calc(2px * var(--instrument-scale))!important;
  width:100%!important;
  height:100%!important;
  padding:0!important;
  margin:0!important;
}
.gs-side .gs-tile{
  min-width:0!important;
  min-height:calc(23px * var(--instrument-scale))!important;
  display:grid!important;
  grid-template-columns:minmax(0,1fr) auto!important;
  grid-template-areas:'label value'!important;
  align-items:center!important;
  column-gap:calc(5px * var(--instrument-scale))!important;
  padding:calc(2px * var(--instrument-scale)) calc(3px * var(--instrument-scale))!important;
  margin:0!important;
  overflow:hidden!important;
  background:transparent!important;
  border:0!important;
  border-radius:0!important;
  box-shadow:none!important;
  text-shadow:0 2px 4px #000!important;
}
.gs-side .gs-tile .k{
  grid-area:label;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  font-size:calc(8px * var(--instrument-scale))!important;
  color:#dbeafe!important;
  line-height:1.05!important;
}
.gs-side .gs-tile .v{
  grid-area:value;
  margin:0!important;
  white-space:nowrap;
  text-align:right;
  font-size:calc(12px * var(--instrument-scale))!important;
  line-height:1!important;
}
.gs-side .gs-tile .s{display:none!important}
.gs-side.instrument-dragging{cursor:grabbing!important}
.gs-side.instrument-resizing{cursor:nwse-resize!important}

/* Large invisible corner targets keep the panel visually transparent. */
.gs-instruments-resize{
  position:absolute!important;
  z-index:15!important;
  width:42px!important;
  height:42px!important;
  padding:0!important;
  border:0!important;
  background:transparent!important;
  opacity:0!important;
  pointer-events:auto!important;
  touch-action:none!important;
}
.gs-instruments-resize.nw{left:0!important;top:0!important}
.gs-instruments-resize.ne{right:0!important;top:0!important}
.gs-instruments-resize.sw{left:0!important;bottom:0!important}
.gs-instruments-resize.se{right:0!important;bottom:0!important}

/* Messages open by tapping CONNECTED / connection state. */
.gs-message-popover{
  position:fixed;
  z-index:110;
  left:2px;
  top:calc(var(--gs-top-clear) + 2px);
  width:min(420px,calc(100vw - 4px));
  max-height:calc(100dvh - var(--gs-top-clear) - 4px);
  display:none;
  overflow:hidden;
  padding:4px;
  background:rgba(2,6,23,.82);
  border:1px solid rgba(148,163,184,.32);
  border-radius:7px;
  box-shadow:0 8px 26px rgba(0,0,0,.38);
  backdrop-filter:blur(4px);
  -webkit-backdrop-filter:blur(4px);
}
.gs-message-popover.open{display:block}
.gs-message-popover-head{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:8px;
  padding:2px 3px 5px;
  font-size:10px;
  color:#e2e8f0;
}
.gs-message-popover-close{
  width:24px;
  height:22px;
  padding:0;
  border:0;
  background:transparent;
  color:#fff;
  font-size:18px;
  line-height:1;
}
.gs-message-popover .gs-message-list{
  max-height:calc(100dvh - var(--gs-top-clear) - 42px);
  overflow:auto;
  padding:0;
  background:transparent!important;
  border:0!important;
}
.gs-message-popover .gs-message{
  padding:4px 3px!important;
  margin:0 0 2px!important;
  background:transparent!important;
  border:0!important;
  text-shadow:0 1px 3px #000;
}

@media(max-width:760px), (max-height:560px){
  .gs-side{
    --telemetry-width:148px;
    --telemetry-height:292px;
    min-width:108px!important;
    min-height:70px!important;
  }
  .gs-side #telemetryGrid{
    grid-template-columns:repeat(auto-fit,minmax(min(96px,100%),1fr))!important;
  }
  .gs-instruments-resize{width:46px!important;height:46px!important}
  .gs-message-popover{
    width:min(360px,calc(100vw - 4px));
    padding:3px;
  }
}




/* GROUND_STATION_PHONE_VIEWPORT_V11 */
/* GROUND_STATION_PHONE_VIEWPORT_V12 */
/* GROUND_STATION_PHONE_UI_V13 */
/* GROUND_STATION_PHONE_UI_V14 */

html,body{width:100%!important;height:100%!important;margin:0!important;overflow:hidden!important;overscroll-behavior:none}
:root{--gs-vv-width:100vw;--gs-vv-height:100dvh}
.gs-app{position:fixed!important;inset:0!important;width:var(--gs-vv-width)!important;height:var(--gs-vv-height)!important;max-width:none!important;max-height:none!important;overflow:hidden!important}

.gs-top,.gs-bottom{position:absolute!important;left:0!important;right:0!important;width:auto!important;min-width:0!important;max-width:none!important;box-sizing:border-box!important;overflow-y:hidden!important;direction:ltr!important;scrollbar-width:none}
.gs-top::-webkit-scrollbar,.gs-bottom::-webkit-scrollbar,.gs-top-left::-webkit-scrollbar,.gs-telemetry-content::-webkit-scrollbar{display:none}
.gs-top{top:0!important;display:flex!important;align-items:center!important;gap:4px!important}
.gs-bottom{bottom:0!important}

/* Independent left and right groups prevent GS, MODE and DISARMED overlap. */
.gs-top-left{display:flex;align-items:center;gap:4px;min-width:0;flex:1 1 auto;overflow-x:auto;overflow-y:hidden;white-space:nowrap;scrollbar-width:none}
.gs-top-right{display:flex;align-items:center;justify-content:flex-end;gap:3px;flex:0 0 auto;white-space:nowrap}
.gs-top-left>*{position:static!important;transform:none!important;flex:0 0 auto!important}
.gs-top-left .gs-brand{margin-right:1px!important;gap:4px!important}
.gs-top-left .gs-chip{margin:0!important}
.gs-top-right .gs-audio-controls{display:flex;align-items:center;gap:3px;flex:0 0 auto!important}
.gs-top-right>.gs-btn,.gs-top-right .gs-btn{flex:0 0 auto!important}

.gs-layout-buttons{display:flex!important;flex:0 0 auto!important;margin:0!important;padding:0!important}

/* Telemetry panel: content scrolls, panel moves from its invisible edge band. */
.gs-side{position:fixed!important;left:var(--telemetry-left,auto)!important;top:var(--telemetry-top,auto)!important;right:auto!important;bottom:auto!important;width:var(--telemetry-width,230px)!important;height:var(--telemetry-height,250px)!important;min-width:110px!important;min-height:80px!important;max-width:none!important;max-height:none!important;contain:none!important;overflow:hidden!important;padding:10px!important;box-sizing:border-box!important;touch-action:auto!important}
.gs-side.open{transform:none!important}
.gs-telemetry-content{position:absolute;inset:10px;overflow:auto!important;overscroll-behavior:contain;scrollbar-width:none;touch-action:pan-x pan-y!important}
.gs-side #telemetryGrid{display:grid!important;grid-template-columns:repeat(var(--telemetry-cols,2),var(--telemetry-cell-width,104px))!important;grid-template-rows:repeat(var(--telemetry-rows,6),var(--telemetry-cell-height,42px))!important;grid-auto-columns:var(--telemetry-cell-width,104px)!important;grid-auto-rows:var(--telemetry-cell-height,42px)!important;grid-auto-flow:row!important;align-content:start!important;align-items:stretch!important;gap:var(--telemetry-gap,3px)!important;width:max(100%,var(--telemetry-grid-width,210px))!important;min-height:max(100%,var(--telemetry-grid-height,267px))!important}
.gs-side .gs-tile{min-width:0!important;min-height:0!important;display:grid!important;grid-template-columns:minmax(0,1fr)!important;grid-template-rows:auto 1fr auto!important;grid-template-areas:'label' 'value' 'description'!important;align-content:center!important;gap:1px!important;padding:3px 5px!important;overflow:hidden!important;background:transparent!important;border:0!important;box-shadow:none!important}
.gs-side .gs-tile .k{grid-area:label;font-size:calc(var(--telemetry-font-size,16px) * .62)!important;line-height:1.05!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;color:#cbd5e1!important}
.gs-side .gs-tile .v{grid-area:value;font-size:var(--telemetry-font-size,16px)!important;line-height:1.05!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;color:#f8fafc!important}
.gs-side .gs-tile .s{grid-area:description;display:none!important;font-size:calc(var(--telemetry-font-size,16px) * .55)!important;line-height:1.05!important;overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;color:#94a3b8!important}
.gs-side.show-descriptions .gs-tile .s{display:block!important}

/* V14 has no visible resize corners. Size is set in the hold menu. */
.gs-instruments-resize,.gs-telemetry-layout-badge{display:none!important}

.gs-telemetry-settings-backdrop{position:fixed;inset:0;z-index:119;display:none;background:rgba(0,0,0,.42)}
.gs-telemetry-settings-backdrop.open{display:block}
.gs-telemetry-settings{position:fixed;left:50%;top:50%;z-index:120;display:none;width:min(340px,calc(100vw - 24px));max-height:calc(100dvh - 24px);overflow:auto;transform:translate(-50%,-50%);padding:12px;border:1px solid #64748b;border-radius:12px;background:rgba(2,6,23,.96);box-shadow:0 18px 60px rgba(0,0,0,.65);color:#e2e8f0}
.gs-telemetry-settings.open{display:block}
.gs-telemetry-settings-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;font-weight:900}
.gs-telemetry-settings-close{border:0;background:transparent;color:#e2e8f0;font-size:22px;line-height:1;padding:2px 5px}
.gs-telemetry-settings-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.gs-telemetry-setting{display:grid;gap:4px;font-size:11px;font-weight:800;color:#cbd5e1}
.gs-telemetry-setting input[type=number]{width:100%;box-sizing:border-box;border:1px solid #475569;border-radius:7px;background:#0f172a;color:#f8fafc;padding:7px 8px;font-size:14px}
.gs-telemetry-setting.wide{grid-column:1/-1}
.gs-telemetry-check{grid-column:1/-1;display:flex;align-items:center;gap:8px;font-size:13px;font-weight:800}
.gs-telemetry-settings-note{grid-column:1/-1;font-size:10px;line-height:1.35;color:#94a3b8}
.gs-telemetry-settings-actions{display:flex;justify-content:flex-end;gap:7px;margin-top:11px}
.gs-telemetry-settings-actions .gs-btn{padding:7px 10px}

@media(max-width:1000px),(pointer:coarse){
  html.gs-phone-host .gs-top{padding-left:max(14px,env(safe-area-inset-left))!important;padding-right:max(8px,env(safe-area-inset-right))!important;overflow:hidden!important}
  html.gs-phone-host .gs-bottom{display:flex!important;align-items:center!important;justify-content:flex-start!important;padding-left:max(14px,env(safe-area-inset-left))!important;padding-right:max(8px,env(safe-area-inset-right))!important;padding-bottom:max(1px,env(safe-area-inset-bottom))!important;overflow-x:hidden!important}
  html.gs-phone-host .gs-top-left{gap:3px;flex:1 1 auto!important}
  html.gs-phone-host .gs-top-right{gap:2px;flex:0 0 auto!important}
  html.gs-phone-host .gs-logo{width:24px!important;height:24px!important;border-radius:6px!important;font-size:10px!important}
  html.gs-phone-host .gs-brand span:last-child{display:none!important}
  html.gs-phone-host .gs-top-left .gs-chip{padding:2px 4px!important;font-size:8px!important;border-radius:6px!important}
  html.gs-phone-host .gs-top-left .gs-chip strong{font-size:9px!important}
  html.gs-phone-host #connectionChip{max-width:90px;overflow:hidden;text-overflow:ellipsis}
  html.gs-phone-host .gs-top-right .gs-btn{height:21px!important;padding:1px 4px!important;font-size:8px!important;border-radius:6px!important}
  html.gs-phone-host .gs-top-right .gs-audio-controls{gap:2px!important}
  html.gs-phone-host .gs-top-right .audio-secondary,html.gs-phone-host .gs-top-right .gs-volume{display:none!important}
}

html.gs-phone-host.gs-native-fullscreen #fullscreenBtn{display:none!important}


/* GROUND_STATION_PHONE_UI_V15 */

/* Movement is explicit: settings -> Move box -> drag anywhere. */
.gs-side.telemetry-move-mode{
  cursor:move!important;
  touch-action:none!important;
  box-shadow:0 0 0 2px rgba(255,155,40,.92),0 10px 30px rgba(0,0,0,.42)!important;
}
.gs-side.telemetry-move-mode .gs-telemetry-content{
  pointer-events:none!important;
  touch-action:none!important;
}
.gs-telemetry-move-hint{
  position:absolute;
  left:50%;
  top:50%;
  z-index:30;
  display:none;
  transform:translate(-50%,-50%);
  padding:7px 10px;
  border:1px solid rgba(255,155,40,.9);
  border-radius:8px;
  background:rgba(2,6,23,.88);
  color:#ffb45e;
  font-size:11px;
  font-weight:900;
  white-space:nowrap;
  text-shadow:0 1px 2px #000;
  pointer-events:none;
}
.gs-side.telemetry-move-mode .gs-telemetry-move-hint{display:block}
#telemetryMoveBtn{margin-right:auto}

</style>
</head>
<body>
<div class="gs-app" id="gsApp">
  <div class="gs-top">
    <div class="gs-top-left">
      <div class="gs-brand"><div class="gs-logo">GS</div><span>Ground Station</span></div>
      <button class="gs-chip gs-connection-chip" id="connectionChip" type="button" aria-label="Show vehicle messages"><span class="gs-dot" id="connDot"></span><strong id="connState">CONNECTING</strong><span id="heartbeatAge">—</span></button>
      <div class="gs-chip"><span>MODE</span><strong id="modeValue">—</strong></div>
      <div class="gs-chip"><strong id="armedValue">UNKNOWN</strong></div>
      <div class="gs-chip optional"><span>GPS</span><strong id="gpsValue">—</strong></div>
      <div class="gs-chip optional"><span>BAT</span><strong id="batteryTop">—</strong></div>
      <div class="gs-chip optional"><span>LINK</span><strong id="linkTop">—</strong></div>
      <div class="gs-chip optional"><span>FLIGHT</span><strong id="flightTime">00:00:00</strong></div>
    </div>
    <div class="gs-top-right">
      <!-- GROUND_STATION_DUAL_VIDEO_AUDIO_V3 -->
      <div class="gs-audio-controls">
        <button class="gs-btn compact" id="audioEnableBtn">Enable audio</button>
        <button class="gs-btn compact audio-secondary" id="audioMuteBtn" disabled>Mute</button>
        <input class="gs-volume" id="audioVolume" type="range" min="0" max="1" step="0.05" value="0.85" aria-label="Flight audio volume">
        <button class="gs-btn compact audio-secondary" id="audioTestBtn" disabled>Test</button>
      </div>
      <button class="gs-btn compact" id="drawerBtn">Telemetry</button>
      <button class="gs-btn compact" id="hudBtn">HUD</button>
      <button class="gs-btn compact" id="fullscreenBtn">Full screen</button>
      <button class="gs-btn compact" id="controlCenterBtn" type="button">Control center</button>
    </div>
  </div>

  <div class="gs-main">
    <div class="gs-stage" id="stage">
      <div class="gs-view active" id="videoView">
        <video class="gs-video-frame" id="videoFrame" autoplay muted playsinline disablepictureinpicture title="Live aircraft video"></video>
        <div class="gs-video-overlay">
          <div class="gs-video-state"><span id="videoSourceName">Video</span></div>
          <div class="gs-video-controls">
            <button class="gs-btn compact" id="videoReconnect">Reconnect</button>
            <button class="gs-btn compact" id="videoFallback">Use HLS</button>
          </div>
        </div>
        <div class="gs-hud" id="hud">
          <div class="gs-attitude-overlay" id="attitudeOverlay" aria-label="Attitude level indicator">
            <div class="gs-horizon-wrap"><div class="gs-horizon" id="mainHorizon"></div></div>
            <div class="gs-aircraft-symbol"><span></span></div>
          </div>
          <div class="gs-telemetry-overlay" aria-label="Primary flight telemetry">
            <div class="gs-telemetry-box"><span class="label">Airspeed</span><span class="reading"><strong id="hudAirspeed">—</strong><em>km/h</em></span></div>
            <div class="gs-telemetry-box"><span class="label">Groundspeed</span><span class="reading"><strong id="hudGroundspeed">—</strong><em>km/h</em></span></div>
            <div class="gs-telemetry-box"><span class="label">Altitude</span><span class="reading"><strong id="hudAltitude">—</strong><em>m</em></span></div>
            <div class="gs-telemetry-box"><span class="label">Throttle</span><span class="reading"><strong id="hudThrottle">—</strong><em>%</em></span></div>
          </div>
          <div class="gs-mode-overlay" id="hudMode">MONITOR ONLY · —</div>
          <span id="hudVspeed" hidden>—</span>
        </div>
        <div class="gs-pip" id="cameraPip" title="Tap to swap cameras; drag to move">
          <div class="gs-camera-label" id="secondaryVideoLabel">SECOND CAMERA — TAP TO SWAP</div>
          <video class="gs-video-frame" id="videoFrameSecondary" autoplay muted playsinline disablepictureinpicture title="Secondary live aircraft video"></video>
          <button class="gs-pip-resize nw" data-corner="nw" type="button" aria-label="Resize picture in picture from top left" title="Drag to resize"></button>
          <button class="gs-pip-resize ne" data-corner="ne" type="button" aria-label="Resize picture in picture from top right" title="Drag to resize"></button>
          <button class="gs-pip-resize sw" data-corner="sw" type="button" aria-label="Resize picture in picture from bottom left" title="Drag to resize"></button>
          <button class="gs-pip-resize se" data-corner="se" type="button" aria-label="Resize picture in picture from bottom right" title="Drag to resize"></button>
          <button class="gs-pip-edge-button" id="pipRestoreButton" type="button" aria-label="Restore picture in picture"><span>CAM</span></button>
        </div>
      </div>

      <div class="gs-view" id="mapView">
        <canvas class="gs-map" id="mapCanvasMain"></canvas>
        <div class="gs-map-note">Offline-capable vector navigation view</div>
        <div class="gs-map-controls"><button data-map="plus">+</button><button data-map="minus">−</button><button data-map="fit">⌖</button></div>
        <div class="gs-pip" id="videoPip" title="Tap to return to dual-camera Video view">
          <div class="gs-camera-label" id="mapVideoLabel">PRIMARY CAMERA — TAP FOR VIDEO VIEW</div>
          <video class="gs-video-frame" id="videoFramePip" autoplay muted playsinline disablepictureinpicture title="Primary live aircraft video picture in picture"></video>
        </div>
      </div>

      <div class="gs-split" id="splitView">
        <div class="gs-split-map-pane">
          <canvas class="gs-map" id="mapCanvasSplit"></canvas>
        </div>
        <div class="gs-split-video-pane">
          <div class="gs-camera-label" id="splitPrimaryLabel">PRIMARY CAMERA</div>
          <video class="gs-video-frame" id="videoFrameSplitPrimary" autoplay muted playsinline disablepictureinpicture title="Current main video stream"></video>
        </div>
      </div>
    </div>

    <aside class="gs-side" id="sidePanel" aria-label="Telemetry panel">
      <div class="gs-telemetry-content" id="telemetryScroll"><div class="gs-grid" id="telemetryGrid"></div></div>
      <div class="gs-telemetry-move-hint" id="telemetryMoveHint">DRAG ANYWHERE - RELEASE TO SNAP</div>
    </aside>

    <div class="gs-telemetry-settings-backdrop" id="telemetrySettingsBackdrop" aria-hidden="true"></div>
    <section class="gs-telemetry-settings" id="telemetrySettings" aria-hidden="true" role="dialog" aria-label="Telemetry layout settings">
      <div class="gs-telemetry-settings-head"><span>Telemetry layout</span><button class="gs-telemetry-settings-close" id="telemetrySettingsClose" type="button" aria-label="Close telemetry settings">×</button></div>
      <div class="gs-telemetry-settings-grid">
        <label class="gs-telemetry-setting">Columns<input id="telemetryColsInput" type="number" min="1" max="24" step="1" value="2"></label>
        <label class="gs-telemetry-setting">Rows<input id="telemetryRowsInput" type="number" min="1" max="24" step="1" value="6"></label>
        <label class="gs-telemetry-setting">Box width (px)<input id="telemetryWidthInput" type="number" min="110" max="1200" step="10" value="230"></label>
        <label class="gs-telemetry-setting">Box height (px)<input id="telemetryHeightInput" type="number" min="80" max="1000" step="10" value="250"></label>
        <label class="gs-telemetry-setting wide">Value font size (px)<input id="telemetryFontInput" type="number" min="10" max="30" step="1" value="16"></label>
        <label class="gs-telemetry-check"><input id="telemetryDescriptionInput" type="checkbox">Show descriptions</label>
        <div class="gs-telemetry-settings-note">Hold the Telemetry box to open this menu. The chosen matrix may be larger than the box; the values then scroll inside it. Tap Move box, then drag anywhere on the Telemetry box and release to snap.</div>
      </div>
      <div class="gs-telemetry-settings-actions"><button class="gs-btn compact" id="telemetryMoveBtn" type="button">Move box</button><button class="gs-btn compact" id="telemetrySettingsReset" type="button">Reset</button><button class="gs-btn compact" id="telemetrySettingsCancel" type="button">Cancel</button><button class="gs-btn compact active" id="telemetrySettingsApply" type="button">Apply</button></div>
    </section>

    <aside class="gs-message-popover" id="messagePopover" aria-hidden="true">
      <div class="gs-message-popover-head"><strong>Vehicle messages</strong><button class="gs-message-popover-close" id="messagePopoverClose" type="button" aria-label="Close vehicle messages">×</button></div>
      <div class="gs-message-list" id="messageList"><div class="gs-message">Waiting for messages…</div></div>
    </aside>
  </div>

  <div class="gs-bottom">
    <div class="gs-layout-buttons"><button class="gs-btn compact active" data-layout="video">Video</button><button class="gs-btn compact" data-layout="map">Map</button><button class="gs-btn compact" data-layout="split">Split</button></div>
    <!-- GROUND_STATION_ANDROID_WEBRTC_RESYNC_V4 -->
    <!-- GROUND_STATION_FULLSCREEN_FLIGHT_UI_V6 -->
    <!-- GROUND_STATION_PHONE_HUD_UI_V7 -->
    <!-- GROUND_STATION_PHONE_HUD_CLEANUP_V8 -->
    <!-- GROUND_STATION_PHONE_HUD_REFINEMENT_V9 -->
    <!-- GROUND_STATION_PHONE_HUD_TELEMETRY_V10 -->
    <!-- GROUND_STATION_PHONE_VIEWPORT_V11 -->
    <div class="gs-dual-status">
      <span id="dualVideoSummary">Primary: SIYI · PiP: Air Link</span>
      <span id="airlinkBufferState">Air Link: starting</span>
      <button class="gs-btn compact" id="resyncAirlinkBtn">Resync Air Link</button>
      <button class="gs-btn compact" id="swapCamerasBtn">Swap cameras</button>
    </div>
    <div class="gs-monitor">MONITOR ONLY</div>
    <div class="gs-alert" id="statusMessage">Ground Station backend is connecting. Vehicle commands are not available in this patch.</div>
  </div>
</div>
<script>
'use strict';
const GS={state:null,layout:'video',protocol:'webrtc',hud:true,mapScale:1,sourceNames:{siyi_rtsp:'SIYI',hdmi_usb:'HDMI',wifilink_rtsp:'Air Link'},primarySource:'siyi_rtsp',secondarySource:'wifilink_rtsp',videoPaths:{siyi_rtsp:'gs_siyi',wifilink_rtsp:'gs_wifilink'},players:{},audioEnabled:false,audioMuted:false,audioVolume:.85,lastMessageTs:0,lastSpoken:{},lastConnection:null,lastMode:null,lastArmed:null,hiddenAt:0};
const $=id=>document.getElementById(id);
const number=(value,digits=0)=>typeof value==='number'&&Number.isFinite(value)?value.toFixed(digits):'—';
const kmh=value=>typeof value==='number'?value*3.6:null;
const clock=seconds=>{seconds=Math.max(0,Math.floor(Number(seconds)||0));const h=String(Math.floor(seconds/3600)).padStart(2,'0');const m=String(Math.floor((seconds%3600)/60)).padStart(2,'0');const s=String(seconds%60).padStart(2,'0');return h+':'+m+':'+s;};
const ageFresh=(key,limit)=>GS.state&&GS.state.field_age_s&&typeof GS.state.field_age_s[key]==='number'&&GS.state.field_age_s[key]<=limit;
function setText(id,value){const node=$(id);if(node)node.textContent=value;}
class GroundStationWhepPlayer{
  constructor(source,path){this.source=source;this.path=path;this.pc=null;this.stream=null;this.resourceUrl=null;this.etag=null;this.connecting=false;this.lastStats=null;this.badSamples=0;this.lastReconnect=0;this.statsTimer=null;this.retryTimer=null;}
  endpoint(){return 'http://'+window.location.hostname+':8889/'+encodeURIComponent(this.path)+'/whep';}
  async waitForIce(pc){if(pc.iceGatheringState==='complete')return;await new Promise(resolve=>{const timeout=setTimeout(resolve,1800);const handler=()=>{if(pc.iceGatheringState==='complete'){clearTimeout(timeout);pc.removeEventListener('icegatheringstatechange',handler);resolve();}};pc.addEventListener('icegatheringstatechange',handler);});}
  async start(reason='startup'){
    if(this.connecting)return;
    this.connecting=true;
    if(this.retryTimer){clearTimeout(this.retryTimer);this.retryTimer=null;}
    try{
      await this.close(true);
      const pc=new RTCPeerConnection({bundlePolicy:'max-bundle'});
      this.pc=pc;
      pc.addTransceiver('video',{direction:'recvonly'});
      pc.ontrack=event=>{this.stream=event.streams[0]||new MediaStream([event.track]);applyVideo(false);};
      pc.onconnectionstatechange=()=>{if(this.source==='wifilink_rtsp'&&['failed','disconnected'].includes(pc.connectionState))this.reconnect('connection '+pc.connectionState);};
      const offer=await pc.createOffer();
      await pc.setLocalDescription(offer);
      await this.waitForIce(pc);
      const response=await fetch(this.endpoint(),{method:'POST',headers:{'Content-Type':'application/sdp'},body:pc.localDescription.sdp});
      if(!response.ok)throw new Error('WHEP HTTP '+response.status);
      const location=response.headers.get('Location');
      this.resourceUrl=location?new URL(location,this.endpoint()).toString():null;
      this.etag=response.headers.get('ETag');
      await pc.setRemoteDescription({type:'answer',sdp:await response.text()});
      this.lastStats=null;
      this.badSamples=0;
      this.beginStats();
      if(this.source==='wifilink_rtsp')setAirlinkState('Air Link: live','');
    }catch(error){
      if(this.source==='wifilink_rtsp')setAirlinkState('Air Link: '+error.message,'bad');
      this.retryTimer=setTimeout(()=>this.reconnect('retry'),2500);
    }finally{this.connecting=false;}
  }
  async close(deleteResource=true){
    if(this.statsTimer){clearInterval(this.statsTimer);this.statsTimer=null;}
    const resource=this.resourceUrl,etag=this.etag;
    this.resourceUrl=null;this.etag=null;
    if(this.pc){try{this.pc.close();}catch(_e){}this.pc=null;}
    this.stream=null;
    if(deleteResource&&resource){try{const headers={};if(etag)headers['If-Match']=etag;await fetch(resource,{method:'DELETE',headers});}catch(_e){}}
  }
  async reconnect(reason='manual'){
    const now=Date.now();
    if(this.connecting||now-this.lastReconnect<5000)return;
    this.lastReconnect=now;
    if(this.source==='wifilink_rtsp'){setAirlinkState('Air Link: resyncing…','warn');$('resyncAirlinkBtn').classList.add('resyncing');}
    await this.start(reason);
    if(this.source==='wifilink_rtsp')$('resyncAirlinkBtn').classList.remove('resyncing');
  }
  async sampleStats(){
    if(!this.pc||this.pc.connectionState!=='connected')return;
    const stats=await this.pc.getStats();
    let inbound=null;
    stats.forEach(report=>{if(report.type==='inbound-rtp'&&report.kind==='video')inbound=report;});
    if(!inbound)return;
    const current={time:performance.now(),framesDecoded:Number(inbound.framesDecoded||0),framesReceived:Number(inbound.framesReceived||0),framesDropped:Number(inbound.framesDropped||0),jitterDelay:Number(inbound.jitterBufferDelay||0),jitterCount:Number(inbound.jitterBufferEmittedCount||0),jitterTarget:Number(inbound.jitterBufferTargetDelay||0),freezeCount:Number(inbound.freezeCount||0),fps:Number(inbound.framesPerSecond||0)};
    if(this.lastStats){
      const elapsed=(current.time-this.lastStats.time)/1000;
      const decoded=current.framesDecoded-this.lastStats.framesDecoded;
      const received=current.framesReceived-this.lastStats.framesReceived;
      const emitted=current.jitterCount-this.lastStats.jitterCount;
      const jitterDelta=current.jitterDelay-this.lastStats.jitterDelay;
      const targetDelta=current.jitterTarget-this.lastStats.jitterTarget;
      const measuredFps=current.fps||((elapsed>0)?decoded/elapsed:0);
      const bufferSeconds=(emitted>0)?jitterDelta/emitted:0;
      const targetSeconds=(emitted>0)?targetDelta/emitted:0;
      const backlog=Math.max(0,received-decoded);
      const froze=current.freezeCount>this.lastStats.freezeCount;
      if(this.source==='wifilink_rtsp'){
        const shownMs=Math.round(Math.max(bufferSeconds,targetSeconds)*1000);
        setAirlinkState('Air Link: '+measuredFps.toFixed(0)+' fps · '+shownMs+' ms buffer',shownMs>550?'bad':shownMs>300?'warn':'');
        const unhealthy=bufferSeconds>.55||targetSeconds>.55||froze||(received>4&&decoded<2)||backlog>18;
        if(unhealthy)this.badSamples++;else this.badSamples=Math.max(0,this.badSamples-1);
        if(this.badSamples>=3&&Date.now()-this.lastReconnect>20000){this.badSamples=0;this.reconnect('automatic receiver recovery');}
      }
    }
    this.lastStats=current;
  }
  beginStats(){if(this.statsTimer)clearInterval(this.statsTimer);this.statsTimer=setInterval(()=>this.sampleStats().catch(()=>{}),2000);}
}
function setAirlinkState(text,level){setText('airlinkBufferState',text);const element=$('airlinkBufferState');if(!element)return;element.classList.remove('warn','bad');if(level)element.classList.add(level);}
function ensurePlayers(){if(!GS.players.siyi_rtsp){GS.players.siyi_rtsp=new GroundStationWhepPlayer('siyi_rtsp','gs_siyi');GS.players.siyi_rtsp.start();}if(!GS.players.wifilink_rtsp){GS.players.wifilink_rtsp=new GroundStationWhepPlayer('wifilink_rtsp','gs_wifilink');GS.players.wifilink_rtsp.start();}}
function setNativeFrame(id,source,active){const video=$(id);if(!video)return;video.style.display=active?'block':'none';const player=GS.players[source],stream=player&&player.stream;if(active&&stream&&video.srcObject!==stream){video.srcObject=stream;video.play().catch(()=>{});}if(!active&&video.srcObject)video.srcObject=null;}
function applyVideo(force=false){ensurePlayers();if(force){GS.players.siyi_rtsp.reconnect('manual all');GS.players.wifilink_rtsp.reconnect('manual all');}const video=GS.layout==='video',map=GS.layout==='map',split=GS.layout==='split';setNativeFrame('videoFrame',GS.primarySource,video);setNativeFrame('videoFrameSecondary',GS.secondarySource,video);setNativeFrame('videoFramePip',GS.primarySource,map);setNativeFrame('videoFrameSplitPrimary',GS.primarySource,split);updateCameraLabels();}
function setLayout(layout){GS.layout=layout;$('videoView').classList.toggle('active',layout==='video');$('mapView').classList.toggle('active',layout==='map');$('splitView').classList.toggle('active',layout==='split');document.querySelectorAll('[data-layout]').forEach(button=>button.classList.toggle('active',button.dataset.layout===layout));applyVideo(false);setTimeout(drawMaps,40);try{localStorage.setItem('siyi-groundstation-layout',layout);}catch(_e){}}
function horizonTransform(roll,pitch){roll=Number(roll)||0;pitch=Math.max(-45,Math.min(45,Number(pitch)||0));return 'translateY('+(pitch*3.2)+'px) rotate('+(-roll)+'deg)';}
function updateHud(state){const attitude=state.attitude||{},speed=state.speed||{},position=state.position||{};const roll=(typeof attitude.roll_deg==='number'&&Number.isFinite(attitude.roll_deg))?attitude.roll_deg:null,pitch=(typeof attitude.pitch_deg==='number'&&Number.isFinite(attitude.pitch_deg))?attitude.pitch_deg:null,heading=(typeof attitude.heading_deg==='number'&&Number.isFinite(attitude.heading_deg))?attitude.heading_deg:null;const hasAttitude=roll!==null&&pitch!==null;const attitudeAge=state.field_age_s&&Number(state.field_age_s.attitude);const fresh=hasAttitude&&Number.isFinite(attitudeAge)&&attitudeAge<=5;const transform=horizonTransform(roll,pitch);['mainHorizon','splitHorizon'].forEach(id=>{if($(id))$(id).style.transform=transform;});setText('hudHeading',(Number.isFinite(heading)?number(heading,0).padStart(3,'0'):'—')+'°');setText('splitHeading',(Number.isFinite(heading)?number(heading,0).padStart(3,'0'):'—')+'°');setText('hudRoll','R '+(Number.isFinite(roll)?number(roll,1):'—')+'°');setText('hudPitch','P '+(Number.isFinite(pitch)?number(pitch,1):'—')+'°');setText('hudAirspeed',number(kmh(speed.airspeed_m_s),0));setText('hudGroundspeed',number(kmh(speed.groundspeed_m_s),0));setText('hudAltitude',number(position.relative_alt_m,0));setText('hudThrottle',number(speed.throttle_pct,0));setText('hudVspeed',number(speed.vertical_speed_m_s,1));setText('hudMode','MONITOR ONLY · '+((state.vehicle||{}).mode||'—'));const lost=$('attitudeLost'),overlay=$('attitudeOverlay');if(lost)lost.classList.toggle('show',!fresh);if(overlay)overlay.classList.toggle('stale',!fresh);}
function tile(label,value,sub){return '<div class="gs-tile"><div class="k">'+label+'</div><div class="v">'+value+'</div><div class="s">'+sub+'</div></div>';}
function updateTelemetry(state){const s=state.speed||{},p=state.position||{},b=state.battery||{},g=state.gps||{},n=state.navigation||{},w=state.wind||{};$('telemetryGrid').innerHTML=[
 tile('Airspeed',number(kmh(s.airspeed_m_s),1)+' km/h','Reported airspeed'),tile('Groundspeed',number(kmh(s.groundspeed_m_s),1)+' km/h','Estimated ground speed'),
 tile('Relative altitude',number(p.relative_alt_m,1)+' m','Above home'),tile('Vertical speed',number(s.vertical_speed_m_s,1)+' m/s','Positive is climb'),
 tile('Battery',number(b.voltage_v,2)+' V',number(b.current_a,1)+' A · '+number(b.remaining_pct,0)+'%'),tile('Consumed',number(b.consumed_mah,0)+' mAh','Battery 1'),
 tile('Heading',number(state.attitude.heading_deg,0)+'°','Ground course '+number(p.ground_course_deg,0)+'°'),tile('Throttle',number(s.throttle_pct,0)+'%','VFR HUD'),
 tile('GPS',g.fix||'—',number(g.satellites,0)+' sats · HDOP '+number(g.hdop,2)),tile('Home',number(n.home_distance_m,0)+' m','Bearing '+number(n.home_bearing_deg,0)+'°'),
 tile('Wind',number(w.speed_m_s,1)+' m/s','From '+number(w.direction_deg,0)+'°'),tile('Waypoint',n.waypoint_current==null?'—':String(n.waypoint_current),'Distance '+number(n.distance_to_waypoint_m,0)+' m')
 ].join('');
syncTelemetryGridLayout();
}
function updateMessages(state){const items=(state.messages||[]).slice(-25).reverse();if(!items.length){$('messageList').innerHTML='<div class="gs-message">No vehicle messages received.</div>';return;}$('messageList').innerHTML=items.map(item=>{const date=new Date((item.ts||0)*1000);return '<div class="gs-message '+String(item.severity||'Info')+'"><span class="gs-message-time">'+date.toLocaleTimeString()+'</span><b>'+String(item.severity||'Info')+'</b> '+escapeHtml(item.text||'')+'</div>';}).join('');}
function escapeHtml(text){return String(text).replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));}
function updateTop(state){const c=state.connection||{},v=state.vehicle||{},g=state.gps||{},b=state.battery||{},l=state.link||{};setText('connState',c.state||'NO VEHICLE');setText('heartbeatAge',typeof c.heartbeat_age_s==='number'?c.heartbeat_age_s.toFixed(1)+'s':'—');const dot=$('connDot');dot.className='gs-dot '+(c.state==='CONNECTED'?'ok':c.state==='DEGRADED'?'warn':'bad');setText('modeValue',v.mode||'—');setText('armedValue',v.armed===true?'ARMED':v.armed===false?'DISARMED':'UNKNOWN');$('armedValue').style.color=v.armed===true?'#f87171':v.armed===false?'#86efac':'#cbd5e1';setText('gpsValue',(g.fix||'—')+'/'+(g.satellites==null?'—':g.satellites));setText('batteryTop',number(b.voltage_v,1)+'V / '+number(b.remaining_pct,0)+'%');setText('linkTop',l.rssi==null?'—':'RSSI '+l.rssi);setText('flightTime',clock((state.timers||{}).armed_s));let message='Monitor-only telemetry';if(c.multiple_vehicles)message='Multiple flight controllers detected — state selection blocked';else if(c.state==='NO_VEHICLE')message='Waiting for flight-controller heartbeat';else if(c.state==='LINK_LOST')message='Telemetry link lost — last values are stale';else if(c.state==='DEGRADED')message='Telemetry degraded — heartbeat age '+number(c.heartbeat_age_s,1)+' s';else message='Connected to vehicle '+c.system_id+'/'+c.component_id+' · '+(v.mode||'unknown mode');setText('statusMessage',message);}
function updateState(state){processFlightAudio(state);GS.state=state;updateTop(state);updateHud(state);updateTelemetry(state);updateMessages(state);drawMaps();}
function bounds(points){if(!points.length)return null;let minLat=points[0].lat,maxLat=points[0].lat,minLon=points[0].lon,maxLon=points[0].lon;for(const point of points){minLat=Math.min(minLat,point.lat);maxLat=Math.max(maxLat,point.lat);minLon=Math.min(minLon,point.lon);maxLon=Math.max(maxLon,point.lon);}return{minLat,maxLat,minLon,maxLon};}
function drawMap(canvas){if(!canvas||!GS.state)return;const rect=canvas.getBoundingClientRect();const ratio=window.devicePixelRatio||1;canvas.width=Math.max(1,Math.floor(rect.width*ratio));canvas.height=Math.max(1,Math.floor(rect.height*ratio));const ctx=canvas.getContext('2d');ctx.scale(ratio,ratio);const width=rect.width,height=rect.height;ctx.fillStyle='#07111f';ctx.fillRect(0,0,width,height);ctx.strokeStyle='#14243b';ctx.lineWidth=1;for(let x=0;x<width;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,height);ctx.stroke();}for(let y=0;y<height;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(width,y);ctx.stroke();}const state=GS.state,p=state.position||{},n=state.navigation||{};let points=(state.track||[]).filter(point=>typeof point.lat==='number'&&typeof point.lon==='number');if(typeof p.lat==='number'&&typeof p.lon==='number')points=points.concat([{lat:p.lat,lon:p.lon}]);if(typeof n.home_lat==='number'&&typeof n.home_lon==='number')points=points.concat([{lat:n.home_lat,lon:n.home_lon}]);if(!points.length){ctx.fillStyle='#94a3b8';ctx.font='14px Arial';ctx.textAlign='center';ctx.fillText('Waiting for estimated vehicle position',width/2,height/2);return;}const b=bounds(points),centerLat=(b.minLat+b.maxLat)/2,centerLon=(b.minLon+b.maxLon)/2;const latSpan=Math.max(.00025,(b.maxLat-b.minLat)*1.35/GS.mapScale),lonSpan=Math.max(.00025,(b.maxLon-b.minLon)*1.35/GS.mapScale);const project=(lat,lon)=>({x:width/2+(lon-centerLon)/lonSpan*width*.8,y:height/2-(lat-centerLat)/latSpan*height*.8});const track=state.track||[];if(track.length>1){ctx.strokeStyle='#38bdf8';ctx.lineWidth=2;ctx.beginPath();track.forEach((point,index)=>{const q=project(point.lat,point.lon);if(index===0)ctx.moveTo(q.x,q.y);else ctx.lineTo(q.x,q.y);});ctx.stroke();}if(typeof n.home_lat==='number'&&typeof n.home_lon==='number'){const h=project(n.home_lat,n.home_lon);ctx.strokeStyle='#22c55e';ctx.fillStyle='#052e16';ctx.lineWidth=2;ctx.beginPath();ctx.arc(h.x,h.y,8,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.fillStyle='#86efac';ctx.font='11px Arial';ctx.fillText('HOME',h.x+11,h.y+4);}if(typeof p.lat==='number'&&typeof p.lon==='number'){const a=project(p.lat,p.lon),heading=((state.attitude||{}).heading_deg||0)*Math.PI/180;ctx.save();ctx.translate(a.x,a.y);ctx.rotate(heading);ctx.fillStyle=ageFresh('position',3)?'#fde047':'#ef4444';ctx.strokeStyle='#020617';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(0,-13);ctx.lineTo(9,10);ctx.lineTo(0,6);ctx.lineTo(-9,10);ctx.closePath();ctx.fill();ctx.stroke();ctx.restore();}ctx.fillStyle='#94a3b8';ctx.font='11px Arial';ctx.fillText('Track '+(state.track||[]).length+' points',8,height-9);}
function drawMaps(){['mapCanvasMain','mapCanvasPip','mapCanvasSplit'].forEach(id=>drawMap($(id)));}
// GROUND_STATION_DUAL_VIDEO_AUDIO_V3
function sourceLabel(source){return GS.sourceNames[source]||({siyi_rtsp:'SIYI',wifilink_rtsp:'Air Link'}[source])||source||'Video';}
function updateCameraLabels(){const primary=sourceLabel(GS.primarySource),secondary=sourceLabel(GS.secondarySource);setText('videoSourceName',primary);setText('secondaryVideoLabel',secondary+' — TAP TO SWAP');setText('mapVideoLabel',primary+' — TAP FOR VIDEO VIEW');setText('splitPrimaryLabel',primary);setText('splitSecondaryLabel',secondary+' — TAP TO SWAP');setText('dualVideoSummary','Primary: '+primary+' · PiP: '+secondary);}
function swapCameras(){const previous=GS.primarySource;GS.primarySource=GS.secondarySource;GS.secondarySource=previous;updateCameraLabels();applyVideo(false);try{localStorage.setItem('siyi-groundstation-primary-camera',GS.primarySource);}catch(_e){}}
async function refreshVideoSource(){try{const response=await fetch('/video_source_status?ts='+Date.now(),{cache:'no-store'});if(!response.ok)return;const data=await response.json();GS.sourceNames=data.source_names||GS.sourceNames;updateCameraLabels();}catch(_e){}}

const GS_PIP_GEOMETRY_KEY='siyi-groundstation-pip-geometry-v7';
function pipBounds(pip){const top=document.querySelector('.gs-top'),bottom=document.querySelector('.gs-bottom');const topLimit=(top?top.getBoundingClientRect().bottom:0)+3;const bottomLimit=(bottom?bottom.getBoundingClientRect().top:window.innerHeight)-3;return{left:3,right:window.innerWidth-3,top:topLimit,bottom:bottomLimit,width:pip.offsetWidth,height:pip.offsetHeight,availableWidth:Math.max(1,window.innerWidth-6),availableHeight:Math.max(1,bottomLimit-topLimit)};}
function savePipGeometry(){const pip=$('cameraPip');if(!pip)return;const rect=pip.getBoundingClientRect();try{localStorage.setItem(GS_PIP_GEOMETRY_KEY,JSON.stringify({left:rect.left,top:rect.top,width:rect.width,height:rect.height}));localStorage.setItem('siyi-groundstation-pip-position',JSON.stringify({left:rect.left,top:rect.top}));}catch(_error){}}
function clampPipPosition(save=false){const pip=$('cameraPip');if(!pip)return;const bounds=pipBounds(pip);const phone=window.matchMedia('(max-width:760px), (max-height:560px)').matches;const minWidth=phone?110:120,minHeight=phone?68:76,maxWidth=Math.max(minWidth,Math.min(bounds.availableWidth*.72,window.innerWidth-6)),maxHeight=Math.max(minHeight,Math.min(bounds.availableHeight*.72,bounds.availableHeight));let width=Math.max(minWidth,Math.min(pip.offsetWidth,maxWidth)),height=Math.max(minHeight,Math.min(pip.offsetHeight,maxHeight));pip.style.width=width+'px';pip.style.height=height+'px';let left=pip.style.left?parseFloat(pip.style.left):pip.getBoundingClientRect().left,top=pip.style.top?parseFloat(pip.style.top):pip.getBoundingClientRect().top;left=Math.max(bounds.left,Math.min(left,bounds.right-width));top=Math.max(bounds.top,Math.min(top,bounds.bottom-height));pip.style.right='auto';pip.style.bottom='auto';pip.style.left=left+'px';pip.style.top=top+'px';if(save)savePipGeometry();}
function restorePipPosition(){const pip=$('cameraPip');if(!pip)return;let restored=false;try{const saved=JSON.parse(localStorage.getItem(GS_PIP_GEOMETRY_KEY)||'null');if(saved&&Number.isFinite(Number(saved.left))&&Number.isFinite(Number(saved.top))&&Number.isFinite(Number(saved.width))&&Number.isFinite(Number(saved.height))){pip.style.right='auto';pip.style.bottom='auto';pip.style.left=Number(saved.left)+'px';pip.style.top=Number(saved.top)+'px';pip.style.width=Number(saved.width)+'px';pip.style.height=Number(saved.height)+'px';restored=true;}}catch(_error){}if(!restored){try{const saved=JSON.parse(localStorage.getItem('siyi-groundstation-pip-position')||'null');if(saved&&Number.isFinite(Number(saved.left))&&Number.isFinite(Number(saved.top))){pip.style.right='auto';pip.style.bottom='auto';pip.style.left=Number(saved.left)+'px';pip.style.top=Number(saved.top)+'px';}}catch(_error){}}requestAnimationFrame(()=>clampPipPosition(false));}

const GS_PIP_MINIMIZED_KEY='siyi-groundstation-pip-minimized-v9';

function pipIsMinimized(){
  const pip=$('cameraPip');
  return Boolean(pip&&pip.classList.contains('pip-minimized'));
}

function setPipMinimized(minimized){
  const pip=$('cameraPip');
  if(!pip)return;
  if(minimized){
    savePipGeometry();
    pip.classList.add('pip-minimized');
    pip.setAttribute('aria-label','Minimized second camera. Tap to restore.');
  }else{
    pip.classList.remove('pip-minimized');
    pip.removeAttribute('aria-label');
    restorePipPosition();
  }
  try{localStorage.setItem(GS_PIP_MINIMIZED_KEY,minimized?'1':'0');}catch(_error){}
}

function restorePipMinimizedState(){
  let minimized=false;
  try{minimized=localStorage.getItem(GS_PIP_MINIMIZED_KEY)==='1';}catch(_error){}
  if(minimized)setPipMinimized(true);
}

function initMovablePip(){
  const pip=$('cameraPip');
  const restoreButton=$('pipRestoreButton');
  if(!pip)return;
  const handles=[...pip.querySelectorAll('.gs-pip-resize')];
  let action=null;
  let holdTimer=null;

  const clearHold=()=>{
    if(holdTimer){clearTimeout(holdTimer);holdTimer=null;}
  };

  const setFixedGeometry=rect=>{
    pip.style.right='auto';
    pip.style.bottom='auto';
    pip.style.left=rect.left+'px';
    pip.style.top=rect.top+'px';
    pip.style.width=rect.width+'px';
    pip.style.height=rect.height+'px';
  };

  const finish=event=>{
    if(!action||event.pointerId!==action.id)return;
    clearHold();
    const wasTap=action.type==='pending'&&!action.moved&&!action.longPressed&&Date.now()-action.started<700;
    try{pip.releasePointerCapture(event.pointerId);}catch(_error){}
    pip.classList.remove('dragging','resizing');
    const shouldClamp=action.type==='move'||action.type==='resize';
    action=null;
    if(shouldClamp)clampPipPosition(true);
    if(wasTap)swapCameras();
    event.preventDefault();
  };

  handles.forEach(handle=>{
    handle.addEventListener('pointerdown',event=>{
      if(pipIsMinimized())return;
      if(event.button!==undefined&&event.button!==0)return;
      clearHold();
      const rect=pip.getBoundingClientRect();
      action={
        type:'resize',corner:handle.dataset.corner||'se',id:event.pointerId,
        startX:event.clientX,startY:event.clientY,left:rect.left,top:rect.top,
        right:rect.right,bottom:rect.bottom,width:rect.width,height:rect.height,
        moved:true,longPressed:false,started:Date.now()
      };
      setFixedGeometry(rect);
      pip.classList.add('resizing');
      try{pip.setPointerCapture(event.pointerId);}catch(_error){}
      event.stopPropagation();
      event.preventDefault();
    });
  });

  if(restoreButton){
    restoreButton.addEventListener('pointerdown',event=>event.stopPropagation());
    restoreButton.addEventListener('click',event=>{
      event.stopPropagation();
      setPipMinimized(false);
    });
  }

  pip.addEventListener('pointerdown',event=>{
    if(event.target.closest&&event.target.closest('.gs-pip-resize,.gs-pip-edge-button'))return;
    if(pipIsMinimized())return;
    if(event.button!==undefined&&event.button!==0)return;
    const rect=pip.getBoundingClientRect();
    action={
      type:'pending',id:event.pointerId,startX:event.clientX,startY:event.clientY,
      left:rect.left,top:rect.top,width:rect.width,height:rect.height,
      moved:false,longPressed:false,started:Date.now()
    };
    try{pip.setPointerCapture(event.pointerId);}catch(_error){}
    holdTimer=setTimeout(()=>{
      if(!action||action.id!==event.pointerId||action.moved)return;
      action.longPressed=true;
      clearHold();
      setPipMinimized(true);
      try{navigator.vibrate&&navigator.vibrate(25);}catch(_error){}
    },700);
    event.preventDefault();
  });

  pip.addEventListener('pointermove',event=>{
    if(!action||event.pointerId!==action.id)return;
    const dx=event.clientX-action.startX;
    const dy=event.clientY-action.startY;
    const distance=Math.hypot(dx,dy);

    if(action.type==='pending'&&distance>8){
      clearHold();
      action.type='move';
      action.moved=true;
      const rect=pip.getBoundingClientRect();
      action.left=rect.left;
      action.top=rect.top;
      action.width=rect.width;
      action.height=rect.height;
      action.startX=event.clientX;
      action.startY=event.clientY;
      setFixedGeometry(rect);
      pip.classList.add('dragging');
      return;
    }

    if(action.longPressed||action.type==='pending')return;

    const limits=pipBounds(pip);
    const phone=window.matchMedia('(max-width:760px), (max-height:560px)').matches;
    const minWidth=phone?110:120,minHeight=phone?68:76;
    const maxWidth=Math.max(minWidth,Math.min(limits.availableWidth*.82,window.innerWidth-4));
    const maxHeight=Math.max(minHeight,Math.min(limits.availableHeight*.82,limits.availableHeight));

    if(action.type==='resize'){
      let left=action.left,top=action.top,right=action.right,bottom=action.bottom;
      const corner=action.corner;
      if(corner.includes('w'))left=Math.max(limits.left,Math.min(action.left+dx,right-minWidth));
      if(corner.includes('e'))right=Math.min(limits.right,Math.max(action.right+dx,left+minWidth));
      if(corner.includes('n'))top=Math.max(limits.top,Math.min(action.top+dy,bottom-minHeight));
      if(corner.includes('s'))bottom=Math.min(limits.bottom,Math.max(action.bottom+dy,top+minHeight));
      if(right-left>maxWidth){if(corner.includes('w'))left=right-maxWidth;else right=left+maxWidth;}
      if(bottom-top>maxHeight){if(corner.includes('n'))top=bottom-maxHeight;else bottom=top+maxHeight;}
      pip.style.left=left+'px';pip.style.top=top+'px';pip.style.width=(right-left)+'px';pip.style.height=(bottom-top)+'px';
    }else if(action.type==='move'){
      const moveDx=event.clientX-action.startX;
      const moveDy=event.clientY-action.startY;
      const left=Math.max(limits.left,Math.min(action.left+moveDx,limits.right-action.width));
      const top=Math.max(limits.top,Math.min(action.top+moveDy,limits.bottom-action.height));
      pip.style.left=left+'px';pip.style.top=top+'px';
    }
    event.preventDefault();
  });

  pip.addEventListener('pointerup',finish);
  pip.addEventListener('pointercancel',finish);
  restorePipPosition();
  restorePipMinimizedState();
}






const GS_INSTRUMENT_GEOMETRY_KEY='siyi-groundstation-telemetry-geometry';
const GS_INSTRUMENT_LEGACY_KEYS=['siyi-groundstation-telemetry-geometry-v12','siyi-groundstation-telemetry-geometry-v11','siyi-groundstation-telemetry-geometry-v10','siyi-groundstation-instruments-geometry-v8'];
let GS_TELEMETRY_GEOMETRY=null;
let GS_TELEMETRY_SAVE_TIMER=null;
let GS_TELEMETRY_MOVE_MODE=false;

function visualViewportRect(){const viewport=window.visualViewport;return{left:0,top:0,width:viewport?(Number(viewport.width)||window.innerWidth):window.innerWidth,height:viewport?(Number(viewport.height)||window.innerHeight):window.innerHeight};}
function syncGroundStationViewport(){const rect=visualViewportRect(),root=document.documentElement;root.style.setProperty('--gs-vv-width',rect.width+'px');root.style.setProperty('--gs-vv-height',rect.height+'px');const app=$('gsApp');if(app){app.style.width=rect.width+'px';app.style.height=rect.height+'px';}const top=document.querySelector('.gs-top-left'),bottom=document.querySelector('.gs-bottom');if(top)top.scrollLeft=0;if(bottom)bottom.scrollLeft=0;requestAnimationFrame(()=>{clampPipPosition(false);clampInstrumentGeometry(false);drawMaps();});}
function isPhoneGroundStationHost(){const mobileUa=/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent||''),coarse=window.matchMedia&&window.matchMedia('(pointer:coarse)').matches,noHover=window.matchMedia&&window.matchMedia('(hover:none)').matches,compact=Math.min(screen.width||9999,screen.height||9999)<=1000;return mobileUa||(coarse&&noHover&&compact);}
function requestGroundStationFullscreen(){if(document.fullscreenElement)return Promise.resolve(true);const target=document.documentElement;if(!target.requestFullscreen)return Promise.resolve(false);try{return Promise.resolve(target.requestFullscreen({navigationUI:'hide'})).then(()=>Boolean(document.fullscreenElement)).catch(()=>{try{return Promise.resolve(target.requestFullscreen()).then(()=>Boolean(document.fullscreenElement)).catch(()=>false);}catch(_error){return false;}});}catch(_error){return Promise.resolve(false);}}
function updateFullscreenUi(){document.documentElement.classList.toggle('gs-native-fullscreen',Boolean(document.fullscreenElement));syncGroundStationViewport();}
function initPhoneGroundStationViewport(){const phone=isPhoneGroundStationHost();document.documentElement.classList.toggle('gs-phone-host',phone);syncGroundStationViewport();if(window.visualViewport){window.visualViewport.addEventListener('resize',syncGroundStationViewport);window.visualViewport.addEventListener('scroll',syncGroundStationViewport);}document.addEventListener('fullscreenchange',updateFullscreenUi);if(phone&&!document.fullscreenElement){requestGroundStationFullscreen();let requesting=false;const enterFullscreen=()=>{if(requesting||document.fullscreenElement)return;requesting=true;requestGroundStationFullscreen().finally(()=>{requesting=false;});};document.addEventListener('pointerdown',enterFullscreen,true);document.addEventListener('touchstart',enterFullscreen,true);document.addEventListener('click',enterFullscreen,true);}}

function instrumentViewportBounds(){const viewport=visualViewportRect(),root=getComputedStyle(document.documentElement),topClear=parseFloat(root.getPropertyValue('--gs-top-clear'))||28;return{left:0,top:topClear,right:viewport.width,bottom:viewport.height};}
function clampNumber(value,min,max,fallback){const parsed=Number(value);return Number.isFinite(parsed)?Math.max(min,Math.min(max,parsed)):fallback;}
function defaultInstrumentGeometry(){const bounds=instrumentViewportBounds(),phone=isPhoneGroundStationHost(),width=Math.min(phone?230:300,bounds.right-bounds.left),height=Math.min(phone?250:320,bounds.bottom-bounds.top);return{left:bounds.right-width,top:bounds.bottom-height,width,height,cols:2,rows:6,fontSize:16,showDescriptions:false,snapLeft:false,snapRight:true,snapBottom:true};}
function normaliseInstrumentGeometry(geometry,snap=true){const bounds=instrumentViewportBounds(),maxWidth=Math.max(110,bounds.right-bounds.left),maxHeight=Math.max(80,bounds.bottom-bounds.top);let width=clampNumber(geometry.width,110,maxWidth,230),height=clampNumber(geometry.height,80,maxHeight,250),left=clampNumber(geometry.left,bounds.left,bounds.right-width,bounds.right-width),top=clampNumber(geometry.top,bounds.top,bounds.bottom-height,bounds.bottom-height);let result={left,top,width,height,cols:Math.round(clampNumber(geometry.cols,1,24,2)),rows:Math.round(clampNumber(geometry.rows,1,24,6)),fontSize:Math.round(clampNumber(geometry.fontSize,10,30,16)),showDescriptions:Boolean(geometry.showDescriptions),snapLeft:Boolean(geometry.snapLeft),snapRight:Boolean(geometry.snapRight),snapBottom:Boolean(geometry.snapBottom)};if(result.snapLeft){result.left=bounds.left;result.snapRight=false;}else if(result.snapRight){result.left=bounds.right-result.width;}if(result.snapBottom)result.top=bounds.bottom-result.height;result.left=Math.max(bounds.left,Math.min(result.left,bounds.right-result.width));result.top=Math.max(bounds.top,Math.min(result.top,bounds.bottom-result.height));if(snap){const threshold=72,leftDistance=Math.abs(result.left-bounds.left),rightDistance=Math.abs(result.left+result.width-bounds.right),bottomDistance=Math.abs(result.top+result.height-bounds.bottom);if(Math.min(leftDistance,rightDistance)<=threshold){result.snapLeft=leftDistance<=rightDistance;result.snapRight=!result.snapLeft;result.left=result.snapLeft?bounds.left:bounds.right-result.width;}else{result.snapLeft=false;result.snapRight=false;}result.snapBottom=bottomDistance<=threshold;if(result.snapBottom)result.top=bounds.bottom-result.height;}return result;}
function telemetryCellMetrics(geometry){const font=geometry.fontSize;return{width:Math.max(82,Math.round(font*6.4)),height:Math.max(34,Math.round(font*(geometry.showDescriptions?3.15:2.35))),gap:3};}
function syncTelemetryGridLayout(){const panel=$('sidePanel'),grid=$('telemetryGrid');if(!panel||!grid||!GS_TELEMETRY_GEOMETRY)return;const geometry=GS_TELEMETRY_GEOMETRY,metrics=telemetryCellMetrics(geometry),gridWidth=geometry.cols*metrics.width+Math.max(0,geometry.cols-1)*metrics.gap,gridHeight=geometry.rows*metrics.height+Math.max(0,geometry.rows-1)*metrics.gap;panel.style.setProperty('--telemetry-cols',String(geometry.cols));panel.style.setProperty('--telemetry-rows',String(geometry.rows));panel.style.setProperty('--telemetry-font-size',geometry.fontSize+'px');panel.style.setProperty('--telemetry-cell-width',metrics.width+'px');panel.style.setProperty('--telemetry-cell-height',metrics.height+'px');panel.style.setProperty('--telemetry-gap',metrics.gap+'px');panel.style.setProperty('--telemetry-grid-width',gridWidth+'px');panel.style.setProperty('--telemetry-grid-height',gridHeight+'px');panel.classList.toggle('show-descriptions',geometry.showDescriptions);}
function applyInstrumentGeometry(geometry){const panel=$('sidePanel');if(!panel)return;GS_TELEMETRY_GEOMETRY=normaliseInstrumentGeometry(geometry,false);const g=GS_TELEMETRY_GEOMETRY;panel.style.setProperty('--telemetry-left',g.left+'px');panel.style.setProperty('--telemetry-top',g.top+'px');panel.style.setProperty('--telemetry-width',g.width+'px');panel.style.setProperty('--telemetry-height',g.height+'px');syncTelemetryGridLayout();}
function saveInstrumentGeometry(immediate=false){if(!GS_TELEMETRY_GEOMETRY)return;const write=()=>{GS_TELEMETRY_SAVE_TIMER=null;try{localStorage.setItem(GS_INSTRUMENT_GEOMETRY_KEY,JSON.stringify(GS_TELEMETRY_GEOMETRY));}catch(_error){}};if(immediate){if(GS_TELEMETRY_SAVE_TIMER)clearTimeout(GS_TELEMETRY_SAVE_TIMER);write();return;}if(GS_TELEMETRY_SAVE_TIMER)clearTimeout(GS_TELEMETRY_SAVE_TIMER);GS_TELEMETRY_SAVE_TIMER=setTimeout(write,100);}
function loadSavedInstrumentGeometry(){for(const key of [GS_INSTRUMENT_GEOMETRY_KEY,...GS_INSTRUMENT_LEGACY_KEYS]){try{const saved=JSON.parse(localStorage.getItem(key)||'null');if(saved&&Number.isFinite(Number(saved.width))&&Number.isFinite(Number(saved.height))&&Number.isFinite(Number(saved.left))&&Number.isFinite(Number(saved.top))){const bounds=instrumentViewportBounds(),width=Number(saved.width),left=Number(saved.left);return{...saved,cols:Number(saved.cols)||2,rows:Number(saved.rows)||6,fontSize:Number(saved.fontSize)||16,showDescriptions:Boolean(saved.showDescriptions),snapLeft:typeof saved.snapLeft==='boolean'?saved.snapLeft:Math.abs(left-bounds.left)<=72,snapRight:typeof saved.snapRight==='boolean'?saved.snapRight:Math.abs(left+width-bounds.right)<=72,snapBottom:Boolean(saved.snapBottom)};}}catch(_error){}}return null;}
function restoreInstrumentGeometry(){applyInstrumentGeometry(normaliseInstrumentGeometry(loadSavedInstrumentGeometry()||defaultInstrumentGeometry(),true));saveInstrumentGeometry(true);}
function clampInstrumentGeometry(save=false){applyInstrumentGeometry(normaliseInstrumentGeometry(GS_TELEMETRY_GEOMETRY||defaultInstrumentGeometry(),true));if(save)saveInstrumentGeometry(true);}
function setTelemetryMoveMode(enabled){const panel=$('sidePanel');GS_TELEMETRY_MOVE_MODE=Boolean(enabled);if(panel){panel.classList.toggle('telemetry-move-mode',GS_TELEMETRY_MOVE_MODE);panel.setAttribute('aria-label',GS_TELEMETRY_MOVE_MODE?'Telemetry move mode. Drag anywhere to move.':'Telemetry panel');}const button=$('telemetryMoveBtn');if(button)button.classList.toggle('active',GS_TELEMETRY_MOVE_MODE);}
function toggleInstruments(){const panel=$('sidePanel');if(!panel)return;const opening=!panel.classList.contains('open');panel.classList.toggle('open',opening);$('drawerBtn').classList.toggle('active',opening);if(!opening)setTelemetryMoveMode(false);if(opening)requestAnimationFrame(()=>applyInstrumentGeometry(normaliseInstrumentGeometry(GS_TELEMETRY_GEOMETRY||loadSavedInstrumentGeometry()||defaultInstrumentGeometry(),true)));}

function setTelemetrySettingsOpen(open){const settings=$('telemetrySettings'),backdrop=$('telemetrySettingsBackdrop');if(!settings||!backdrop)return;if(open)setTelemetryMoveMode(false);settings.classList.toggle('open',open);backdrop.classList.toggle('open',open);settings.setAttribute('aria-hidden',open?'false':'true');backdrop.setAttribute('aria-hidden',open?'false':'true');if(open){const g=GS_TELEMETRY_GEOMETRY||defaultInstrumentGeometry();$('telemetryColsInput').value=String(g.cols);$('telemetryRowsInput').value=String(g.rows);$('telemetryWidthInput').value=String(Math.round(g.width));$('telemetryHeightInput').value=String(Math.round(g.height));$('telemetryFontInput').value=String(g.fontSize);$('telemetryDescriptionInput').checked=Boolean(g.showDescriptions);}}
function applyTelemetrySettings(){const current=GS_TELEMETRY_GEOMETRY||defaultInstrumentGeometry(),next={...current,cols:$('telemetryColsInput').value,rows:$('telemetryRowsInput').value,width:$('telemetryWidthInput').value,height:$('telemetryHeightInput').value,fontSize:$('telemetryFontInput').value,showDescriptions:$('telemetryDescriptionInput').checked};applyInstrumentGeometry(normaliseInstrumentGeometry(next,true));saveInstrumentGeometry(true);setTelemetrySettingsOpen(false);}
function resetTelemetrySettings(){const g=defaultInstrumentGeometry();$('telemetryColsInput').value=String(g.cols);$('telemetryRowsInput').value=String(g.rows);$('telemetryWidthInput').value=String(Math.round(g.width));$('telemetryHeightInput').value=String(Math.round(g.height));$('telemetryFontInput').value=String(g.fontSize);$('telemetryDescriptionInput').checked=g.showDescriptions;}
function armTelemetryMoveMode(){setTelemetrySettingsOpen(false);requestAnimationFrame(()=>setTelemetryMoveMode(true));}

function initMovableInstruments(){const panel=$('sidePanel');if(!panel)return;let action=null,holdTimer=null,holdOpened=false,holdStart=null;restoreInstrumentGeometry();const clearHold=()=>{if(holdTimer){clearTimeout(holdTimer);holdTimer=null;}};panel.addEventListener('pointerdown',event=>{if(event.button!==undefined&&event.button!==0)return;holdOpened=false;if(GS_TELEMETRY_MOVE_MODE){const g=GS_TELEMETRY_GEOMETRY||defaultInstrumentGeometry();action={id:event.pointerId,startX:event.clientX,startY:event.clientY,geometry:{...g},moved:false};try{panel.setPointerCapture(event.pointerId);}catch(_error){}event.preventDefault();return;}holdStart={id:event.pointerId,x:event.clientX,y:event.clientY};holdTimer=setTimeout(()=>{holdTimer=null;holdOpened=true;holdStart=null;setTelemetrySettingsOpen(true);},650);},{passive:false});panel.addEventListener('pointermove',event=>{if(action&&event.pointerId===action.id){const dx=event.clientX-action.startX,dy=event.clientY-action.startY;if(Math.hypot(dx,dy)>4)action.moved=true;applyInstrumentGeometry({...action.geometry,left:action.geometry.left+dx,top:action.geometry.top+dy,snapLeft:false,snapRight:false,snapBottom:false});saveInstrumentGeometry(false);event.preventDefault();return;}if(holdTimer&&holdStart&&event.pointerId===holdStart.id&&Math.hypot(event.clientX-holdStart.x,event.clientY-holdStart.y)>9){clearHold();holdStart=null;}},{passive:false});const finish=event=>{clearHold();holdStart=null;if(action&&event.pointerId===action.id){try{panel.releasePointerCapture(event.pointerId);}catch(_error){}const moved=action.moved;action=null;if(moved){clampInstrumentGeometry(true);setTelemetryMoveMode(false);}event.preventDefault();return;}if(holdOpened){holdOpened=false;event.preventDefault();}};panel.addEventListener('pointerup',finish,{passive:false});panel.addEventListener('pointercancel',finish,{passive:false});panel.addEventListener('contextmenu',event=>event.preventDefault());$('telemetrySettingsClose').addEventListener('click',()=>setTelemetrySettingsOpen(false));$('telemetrySettingsCancel').addEventListener('click',()=>setTelemetrySettingsOpen(false));$('telemetrySettingsBackdrop').addEventListener('click',()=>setTelemetrySettingsOpen(false));$('telemetrySettingsApply').addEventListener('click',applyTelemetrySettings);$('telemetrySettingsReset').addEventListener('click',resetTelemetrySettings);$('telemetryMoveBtn').addEventListener('click',armTelemetryMoveMode);document.addEventListener('keydown',event=>{if(event.key==='Escape'){setTelemetrySettingsOpen(false);setTelemetryMoveMode(false);}});window.addEventListener('pagehide',()=>saveInstrumentGeometry(true));document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')saveInstrumentGeometry(true);});}

function setMessagesOpen(open){
  const popover=$('messagePopover');
  if(!popover)return;
  popover.classList.toggle('open',open);
  popover.setAttribute('aria-hidden',open?'false':'true');
  $('connectionChip').classList.toggle('active',open);
}

function toggleMessages(){
  const popover=$('messagePopover');
  setMessagesOpen(!popover.classList.contains('open'));
}

function speechSupported(){return 'speechSynthesis' in window&&'SpeechSynthesisUtterance' in window;}
function audioUi(){const enable=$('audioEnableBtn'),mute=$('audioMuteBtn'),test=$('audioTestBtn'),volume=$('audioVolume');if(!speechSupported()){enable.textContent='Audio unsupported';enable.disabled=true;mute.disabled=true;test.disabled=true;return;}enable.textContent=GS.audioEnabled?'Audio enabled':'Enable audio';enable.classList.toggle('audio-on',GS.audioEnabled&&!GS.audioMuted);mute.disabled=!GS.audioEnabled;test.disabled=!GS.audioEnabled;mute.textContent=GS.audioMuted?'Unmute':'Mute';mute.classList.toggle('audio-muted',GS.audioMuted);volume.value=String(GS.audioVolume);}
function speakFlight(text,key='',force=false){text=String(text||'').trim();if(!text||!GS.audioEnabled||GS.audioMuted||!speechSupported())return;const now=Date.now(),dedupeKey=key||text.toLowerCase();if(!force&&GS.lastSpoken[dedupeKey]&&now-GS.lastSpoken[dedupeKey]<30000)return;GS.lastSpoken[dedupeKey]=now;const utterance=new SpeechSynthesisUtterance(text);utterance.volume=Math.max(0,Math.min(1,GS.audioVolume));utterance.rate=1;utterance.pitch=1;window.speechSynthesis.speak(utterance);}
function enableFlightAudio(){if(!speechSupported())return;GS.audioEnabled=true;GS.audioMuted=false;const messages=(GS.state&&GS.state.messages)||[];GS.lastMessageTs=messages.reduce((latest,item)=>Math.max(latest,Number(item.ts)||0),GS.lastMessageTs);audioUi();speakFlight('Flight audio enabled','audio-enabled',true);}
function processFlightAudio(state){if(!GS.audioEnabled)return;const c=state.connection||{},v=state.vehicle||{};if(GS.lastConnection!==null&&c.state!==GS.lastConnection){if(c.state==='LINK_LOST'||c.state==='NO_VEHICLE')speakFlight('Telemetry lost','telemetry-lost');else if(c.state==='CONNECTED'&&(GS.lastConnection==='LINK_LOST'||GS.lastConnection==='NO_VEHICLE'||GS.lastConnection==='DEGRADED'))speakFlight('Telemetry restored','telemetry-restored');}if(GS.lastMode!==null&&v.mode&&v.mode!==GS.lastMode)speakFlight('Flight mode '+v.mode,'mode-'+v.mode);if(GS.lastArmed!==null&&typeof v.armed==='boolean'&&v.armed!==GS.lastArmed)speakFlight(v.armed?'Aircraft armed':'Aircraft disarmed',v.armed?'armed':'disarmed');const messages=(state.messages||[]).slice().sort((a,b)=>(Number(a.ts)||0)-(Number(b.ts)||0));for(const item of messages){const ts=Number(item.ts)||0;if(ts<=GS.lastMessageTs)continue;GS.lastMessageTs=Math.max(GS.lastMessageTs,ts);const spoken=String(item.text||'').trim();if(spoken)speakFlight(spoken,'mavlink-'+spoken.toLowerCase());}GS.lastConnection=c.state||null;GS.lastMode=v.mode||null;GS.lastArmed=typeof v.armed==='boolean'?v.armed:null;}
function connectTelemetry(){const events=new EventSource('/api/groundstation/stream?ts='+Date.now());events.onmessage=event=>{try{updateState(JSON.parse(event.data));}catch(_e){}};events.onerror=()=>{setText('statusMessage','Ground Station telemetry stream disconnected — reconnecting automatically');};}
document.querySelectorAll('[data-layout]').forEach(button=>button.addEventListener('click',()=>setLayout(button.dataset.layout)));
initPhoneGroundStationViewport();
initMovablePip();
initMovableInstruments();
$('resyncAirlinkBtn').addEventListener('click',()=>{const player=GS.players.wifilink_rtsp;if(player)player.reconnect('manual button');});
$('swapCamerasBtn').addEventListener('click',swapCameras);
$('videoPip').addEventListener('click',()=>setLayout('video'));
$('videoReconnect').addEventListener('click',()=>applyVideo(true));
$('videoFallback').addEventListener('click',()=>setText('statusMessage','HLS is disabled in Android low-latency mode'));
$('hudBtn').addEventListener('click',()=>{GS.hud=!GS.hud;$('hud').style.display=GS.hud?'block':'none';$('hudBtn').classList.toggle('active',GS.hud);});
$('fullscreenBtn').addEventListener('click',async()=>{try{if(!document.fullscreenElement)await requestGroundStationFullscreen();else await document.exitFullscreen();}catch(_e){}});
$('controlCenterBtn').addEventListener('click',()=>{window.location.href='/';});
$('drawerBtn').addEventListener('click',toggleInstruments);
$('connectionChip').addEventListener('click',event=>{event.stopPropagation();toggleMessages();});
$('messagePopoverClose').addEventListener('click',()=>setMessagesOpen(false));
document.addEventListener('pointerdown',event=>{const popover=$('messagePopover');if(popover.classList.contains('open')&&!popover.contains(event.target)&&!$('connectionChip').contains(event.target))setMessagesOpen(false);});
document.querySelectorAll('[data-map]').forEach(button=>button.addEventListener('click',()=>{if(button.dataset.map==='plus')GS.mapScale=Math.min(12,GS.mapScale*1.35);else if(button.dataset.map==='minus')GS.mapScale=Math.max(.25,GS.mapScale/1.35);else GS.mapScale=1;drawMaps();}));
$('audioEnableBtn').addEventListener('click',()=>{if(GS.audioEnabled){GS.audioEnabled=false;window.speechSynthesis.cancel();}else enableFlightAudio();audioUi();});
$('audioMuteBtn').addEventListener('click',()=>{GS.audioMuted=!GS.audioMuted;if(GS.audioMuted)window.speechSynthesis.cancel();audioUi();try{localStorage.setItem('siyi-groundstation-audio-muted',GS.audioMuted?'1':'0');}catch(_e){}});
$('audioTestBtn').addEventListener('click',()=>speakFlight('Ground Station flight audio test','audio-test',true));
$('audioVolume').addEventListener('input',event=>{GS.audioVolume=Number(event.target.value)||0;try{localStorage.setItem('siyi-groundstation-audio-volume',String(GS.audioVolume));}catch(_e){}});
window.addEventListener('resize',syncGroundStationViewport);
document.addEventListener('visibilitychange',()=>{if(document.hidden){GS.hiddenAt=Date.now();}else if(GS.hiddenAt&&Date.now()-GS.hiddenAt>4000){const player=GS.players.wifilink_rtsp;if(player)player.reconnect('Android page resumed');GS.hiddenAt=0;}});
window.addEventListener('pageshow',event=>{if(event.persisted){const player=GS.players.wifilink_rtsp;if(player)player.reconnect('page restored');}});
window.addEventListener('beforeunload',()=>Object.values(GS.players).forEach(player=>player.close(false)));
try{const savedPrimary=localStorage.getItem('siyi-groundstation-primary-camera');if(savedPrimary==='wifilink_rtsp'){GS.primarySource='wifilink_rtsp';GS.secondarySource='siyi_rtsp';}const savedVolume=Number(localStorage.getItem('siyi-groundstation-audio-volume'));if(Number.isFinite(savedVolume))GS.audioVolume=Math.max(0,Math.min(1,savedVolume));GS.audioMuted=localStorage.getItem('siyi-groundstation-audio-muted')==='1';setLayout(localStorage.getItem('siyi-groundstation-layout')||'video');}catch(_e){setLayout('video');}
audioUi();refreshVideoSource();setInterval(refreshVideoSource,5000);connectTelemetry();
</script>
</body>
</html>'''
    return template


_groundstation_previous_nav_html = _v9_nav_html


def _v9_nav_html():
    navigation = _groundstation_previous_nav_html()
    if "href='/groundstation'" not in navigation:
        target = "  <a class='v9-nav-link' data-workspace='connectivity' href='/connectivity'>"
        entry = "  <a class='v9-nav-link' data-workspace='groundstation' href='/groundstation'><span class='v9-nav-icon'>G</span><span>Ground Station</span></a>\n"
        navigation = navigation.replace(target, entry + target, 1)
    return navigation


_groundstation_previous_get = H.do_GET


def _groundstation_do_GET(self):
    parsed = urllib.parse.urlparse(self.path)
    path = parsed.path
    if software_update_lock_active() and path.startswith("/api/groundstation"):
        _groundstation_send_json(self, "/health")
        return
    if software_update_lock_active() and path == "/groundstation":
        return _groundstation_previous_get(self)
    if path == "/groundstation":
        raw = _groundstation_page().encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)
        return
    if path == "/api/groundstation/health":
        _groundstation_send_json(self, "/health")
        return
    if path == "/api/groundstation/state":
        _groundstation_send_json(self, "/state")
        return
    if path == "/api/groundstation/messages":
        _groundstation_send_json(self, "/messages")
        return
    if path == "/api/groundstation/stream":
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream; charset=utf-8")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.send_header("Connection", "keep-alive")
        self.send_header("X-Accel-Buffering", "no")
        self.end_headers()
        request = urllib.request.Request(
            GROUNDSTATION_INTERNAL_BASE + "/stream",
            headers={"User-Agent": "SIYI-WebUI-GroundStation/1"},
        )
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                while True:
                    line = response.readline()
                    if not line:
                        break
                    self.wfile.write(line)
                    self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            pass
        except Exception as exc:
            try:
                payload = json.dumps({"error": str(exc)}, separators=(",", ":"))
                self.wfile.write(("event: error\ndata: " + payload + "\n\n").encode("utf-8"))
                self.wfile.flush()
            except Exception:
                pass
        return
    return _groundstation_previous_get(self)


H.do_GET = _groundstation_do_GET
# GROUND_STATION_MONITOR_POC_V1_END

if __name__ == "__main__":
    ThreadingHTTPServer(("0.0.0.0",PORT),H).serve_forever()


# FULL_LOGS_PAGE_FIX_START
from flask import Response
import subprocess
import shlex

def _safe_cmd(cmd, timeout=4):
    try:
        return subprocess.check_output(
            cmd, shell=True, text=True,
            stderr=subprocess.STDOUT, timeout=timeout
        )
    except subprocess.CalledProcessError as e:
        return e.output or str(e)
    except Exception as e:
        return str(e)

@app.route("/api/logs")
def api_logs():
    parts = []

    sources = [
        ("SIYI Web UI", "journalctl -u siyi-webui -n 250 --no-pager"),
        ("MAVLink Router", "journalctl -u mavlink-router -n 180 --no-pager"),
        ("SIYI Services", "journalctl -u 'siyi-*' -n 220 --no-pager"),
        ("System Errors", "journalctl -p warning..alert -n 120 --no-pager"),
    ]

    for title, cmd in sources:
        parts.append(f'\n\n===== {title} =====\n')
        parts.append(_safe_cmd(cmd))

    return Response("".join(parts), mimetype="text/plain")


@app.route("/logs")
def logs_page():
    return f"""
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SIYI Logs</title>
<style>
body {{
  margin: 0;
  background: #101418;
  color: #e8eef5;
  font-family: Arial, sans-serif;
}}
.header {{
  padding: 14px 18px;
  background: #171d24;
  border-bottom: 1px solid #2b3440;
  display: flex;
  gap: 12px;
  align-items: center;
  flex-wrap: wrap;
}}
h1 {{
  margin: 0;
  font-size: 20px;
}}
button, a.btn {{
  background: #253244;
  color: #e8eef5;
  border: 1px solid #3c4b5f;
  border-radius: 8px;
  padding: 8px 11px;
  text-decoration: none;
  cursor: pointer;
}}
button:hover, a.btn:hover {{
  background: #314158;
}}
.status {{
  opacity: .8;
  font-size: 13px;
}}
.version {{
  font-size: 12px;
  opacity: 0.6;
}}
#logs {{
  height: calc(100vh - 72px);
  overflow-y: auto;
  padding: 14px;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: Menlo, Consolas, monospace;
  font-size: 12px;
  line-height: 1.35;
}}
.err {{ color: #ff9b9b; }}
.warn {{ color: #ffd28a; }}
.ok {{ color: #a8ffbf; }}
</style>
</head>
<body>
<div class="header">
  <h1>SIYI Logs</h1>
  <span class="version">v{VERSION}</span>
  <button onclick="loadLogs(false)">Refresh</button>
  <button onclick="toggleFollow()" id="followBtn">Auto-follow: ON</button>
  <button onclick="copyLogs()">Copy diagnostics</button>
  <a class="btn" href="/" >Back</a>
  <span class="status" id="status">Loading…</span>
</div>

<pre id="logs"></pre>

<script>
let follow = true;
let timer = null;

function colorize(t) {{
  return t
    .replace(/(error|failed|traceback|exception|critical)/gi, '<span class="err">$1</span>')
    .replace(/(warning|warn)/gi, '<span class="warn">$1</span>')
    .replace(/(active \\(running\\)|started|success)/gi, '<span class="ok">$1</span>');
}}

async function loadLogs(auto) {{
  const box = document.getElementById('logs');
  const status = document.getElementById('status');
  try {{
    const r = await fetch('/api/logs?ts=' + Date.now());
    const t = await r.text();
    box.innerHTML = colorize(t);
    status.innerText = 'Updated: ' + new Date().toLocaleTimeString();
    if (follow) box.scrollTop = box.scrollHeight;
  }} catch(e) {{
    status.innerText = 'Failed to load logs';
    if (!auto) alert(e);
  }}
}}

function toggleFollow() {{
  follow = !follow;
  document.getElementById('followBtn').innerText = 'Auto-follow: ' + (follow ? 'ON' : 'OFF');
}}

function copyLogs() {{
  navigator.clipboard.writeText(document.getElementById('logs').innerText);
  document.getElementById('status').innerText = 'Copied diagnostics';
}}

loadLogs(false);
timer = setInterval(() => loadLogs(true), 3000);
</script>
</body>
</html>
"""
# FULL_LOGS_PAGE_FIX_END

# FORCE_LOGS2_PAGE_START
from flask import Response
import subprocess
import shlex

def _logs2_cmd(cmd, timeout=5):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT, timeout=timeout)
    except Exception as e:
        return str(e)

@app.route("/api/logs2")
def api_logs2():
    out = []
    checks = [
        ("SIYI WEBUI", "journalctl -u siyi-webui -n 300 --no-pager"),
        ("MAVLINK ROUTER", "journalctl -u mavlink-router -n 200 --no-pager"),
        ("ALL SIYI SERVICES", "journalctl -u 'siyi-*' -n 250 --no-pager"),
        ("SYSTEM WARNINGS", "journalctl -p warning..alert -n 150 --no-pager"),
    ]
    for title, cmd in checks:
        out.append("\\n\\n==================== " + title + " ====================\\n")
        out.append(_logs2_cmd(cmd))
    return Response("".join(out), mimetype="text/plain")

@app.route("/logs2")
def logs2_page():
    return """
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SIYI Logs v{VERSION}</title>
<style>
body{margin:0;background:#101418;color:#e8eef5;font-family:Arial,sans-serif}
.header{padding:14px 18px;background:#171d24;border-bottom:1px solid #2b3440;display:flex;gap:12px;align-items:center;flex-wrap:wrap}
h1{margin:0;font-size:20px}
.badge{font-size:12px;opacity:.7}
button,a{background:#253244;color:#e8eef5;border:1px solid #3c4b5f;border-radius:8px;padding:8px 11px;text-decoration:none;cursor:pointer}
button:hover,a:hover{background:#314158}
#status{opacity:.75;font-size:13px}
#logs{height:calc(100vh - 72px);overflow-y:auto;padding:14px;white-space:pre-wrap;word-break:break-word;font-family:Menlo,Consolas,monospace;font-size:12px;line-height:1.35}
.err{color:#ff9b9b;font-weight:bold}
.warn{color:#ffd28a;font-weight:bold}
.ok{color:#a8ffbf;font-weight:bold}
</style>
</head>
<body>
<div class="header">
  <h1>SIYI Logs</h1>
  <span class="badge">v{VERSION} / forced logs2 page</span>
  <button onclick="loadLogs()">Refresh</button>
  <button onclick="toggleFollow()" id="followBtn">Auto-follow: ON</button>
  <button onclick="copyLogs()">Copy diagnostics</button>
  <a href="/">Back</a>
  <span id="status">Loading…</span>
</div>
<pre id="logs"></pre>
<script>
let follow=true;
function colorize(t){
  return t
    .replace(/(error|failed|failure|traceback|exception|critical)/gi,'<span class="err">$1</span>')
    .replace(/(warning|warn)/gi,'<span class="warn">$1</span>')
    .replace(/(active \\(running\\)|started|success|online)/gi,'<span class="ok">$1</span>');
}
async function loadLogs(){
  const box=document.getElementById('logs');
  const status=document.getElementById('status');
  try{
    const r=await fetch('/api/logs2?t='+Date.now());
    const t=await r.text();
    box.innerHTML=colorize(t);
    status.innerText='Updated: '+new Date().toLocaleTimeString();
    if(follow) box.scrollTop=box.scrollHeight;
  }catch(e){
    status.innerText='Failed to load logs';
  }
}
function toggleFollow(){
  follow=!follow;
  document.getElementById('followBtn').innerText='Auto-follow: '+(follow?'ON':'OFF');
}
function copyLogs(){
  navigator.clipboard.writeText(document.getElementById('logs').innerText);
  document.getElementById('status').innerText='Copied diagnostics';
}
loadLogs();
setInterval(loadLogs,3000);
</script>
</body>
</html>
"""
# FORCE_LOGS2_PAGE_END


# SIYI_CONTROL_CENTER_RELEASE_4_0_2
