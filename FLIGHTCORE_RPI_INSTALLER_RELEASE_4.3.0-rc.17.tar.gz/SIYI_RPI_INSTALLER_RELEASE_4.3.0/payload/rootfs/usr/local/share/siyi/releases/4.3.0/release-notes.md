# FlightCore 4.3.0 RC17

Canonical machine identity: `4.3.0-rc.17`.

RC17 repairs the confirmed RC13-to-RC16 native-upgrade failure at final ownership-aware validation:

- Mandatory preservation now restores the saved UID/GID with `lchown` for every preserved top-level symbolic link before final fingerprint validation.
- The fix is generic. `/etc/siyi/joystick.json` exposed the defect but is not special-cased.
- Strict ownership-aware validation remains unchanged and still rejects incorrect ownership.
- The unchanged RC16 compatibility matrix—RC6/V71, RC12, RC13 and genuine fresh installation—is reused by explicit product-owner authorization. RC17 Registry freeze/recheck calls are skipped until a physical RC17 upgrade succeeds.

RC17 also completes TURN HOME forensic flight logging:

- Every 2 Hz sample records the calculator inputs, flight/wind qualification, both independent battery-limit calculations, return geometry/energy, forecast linkage and the exact displayed result.
- Flight metadata and events record the complete installed version, RC, build ID, source commit, release status and payload-manifest identity.
- CSV export includes every recorded scalar field and repeats the exact release identity in every portable row.
- The complete provider forecast response and calculated route/segments are stored once per refresh and referenced by snapshot ID, avoiding wasteful per-sample duplication.
- Logging uses already available telemetry and calculator results. It adds no MAVLink requests, network polling or flight-control authority.

All other RC16 product behavior remains intact. RC17 changes no TURN HOME calculation, UI, settings schema, defaults, networking, LTE Health, Smooth Voltage, ARSP, SIYI stream behavior, public fresh-install command or flight-control authority.
