#!/bin/bash

set -e

echo "Downloading SIYI installer..."

cd /home/pi
wget -O siyi_installer.tar.gz <PUT_YOUR_LINK_HERE>

tar -xzf siyi_installer.tar.gz
cd SIYI_PUBLIC_INSTALLER

chmod +x install.sh
./install.sh
