#!/bin/bash
set -e

FIFO="/tmp/siyi_record_proxy"
SERVICE="siyi-rec-proxy.service"
MARKER="Injected set_time_now"

echo "[PROXY_TIME] Waiting for $SERVICE active..."
for i in $(seq 1 40); do
  systemctl is-active --quiet "$SERVICE" && break
  sleep 1
done

systemctl is-active --quiet "$SERVICE" || {
  echo "[PROXY_TIME] ERROR: $SERVICE not active" >&2
  exit 1
}

echo "[PROXY_TIME] Waiting for FIFO..."
for i in $(seq 1 40); do
  [ -p "$FIFO" ] && break
  sleep 1
done

[ -p "$FIFO" ] || {
  echo "[PROXY_TIME] ERROR: FIFO not ready" >&2
  exit 1
}

SINCE="$(date '+%Y-%m-%d %H:%M:%S')"

echo "[PROXY_TIME] Opening dummy client to proxy..."
python3 - <<'PY' &
import socket, time
s = socket.create_connection(("127.0.0.1", 37256), timeout=5)
print("[PROXY_TIME] DUMMY_CLIENT_CONNECTED", flush=True)
time.sleep(15)
s.close()
PY

DUMMY_PID="$!"

sleep 3

echo "[PROXY_TIME] Sending set_time_now through FIFO..."
printf 'set_time_now\n' > "$FIFO"

sleep 3

echo "[PROXY_TIME] Closing dummy client..."
kill "$DUMMY_PID" 2>/dev/null || true
wait "$DUMMY_PID" 2>/dev/null || true

echo "[PROXY_TIME] Verifying injection..."
if journalctl -u "$SERVICE" --since "$SINCE" --no-pager | grep -q "$MARKER"; then
  echo "[PROXY_TIME] VERIFIED: camera time packet injected through proxy socket"
  exit 0
fi

echo "[PROXY_TIME] ERROR: no verified Injected set_time_now in proxy log" >&2
journalctl -u "$SERVICE" --since "$SINCE" --no-pager >&2 || true
exit 1
