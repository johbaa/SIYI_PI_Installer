
# === CONFIG LOAD ===
import json
try:
    with open("/home/pi/siyi-config.json") as cf:
        CFG = json.load(cf)
except Exception:
    CFG = {}

CAM_IP = CFG.get("camera_ip", "192.168.144.25")
QGC_HOSTS = CFG.get("qgc_hosts", [])
VIDEO_PORT = CFG.get("video_port", 5600)
# === END CONFIG ===

RELEASE_VERSION_FILE = "/etc/siyi/release_version"

def get_release_version():
    try:
        with open(RELEASE_VERSION_FILE, "r", encoding="utf-8") as f:
            v = f.read().strip()
        return v if v else "0.1.0"
    except Exception:
        return "0.1.0"

VERSION = get_release_version()
#!/usr/bin/env python3
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse, parse_qsl
import subprocess
import shlex, os, csv, html, time, shutil, re, json, urllib.request, urllib.parse, zipfile, tempfile

PORT=8080

BUTTON_MAP="/home/pi/button_map.csv"
MAVCONF="/etc/mavlink-router/main.conf"
VIDEO_SERVICE="/etc/systemd/system/siyi-video-dual.service"
BACKUP_DIR="/home/pi/siyi-webui/backups"
ENDPOINTS_FILE="/home/pi/siyi-webui/endpoints.json"
ZT_CONFIG_FILE="/etc/siyi/zerotier_config.json"
ZT_TOKEN_FILE="/etc/siyi/zerotier_api_token"


SETUP_COMPLETE_FILE="/etc/siyi/setup_complete.json"
SETUP_SKIP_FILE="/tmp/siyi_setup_skip"

WIFI_PASSWORD_STORE="/home/pi/siyi-webui/wifi_passwords.json"

def wifi_pw_store_read():
    try:
        if os.path.exists(WIFI_PASSWORD_STORE):
            return json.load(open(WIFI_PASSWORD_STORE, encoding="utf-8"))
    except Exception:
        pass
    return {}

def wifi_pw_store_write(d):
    try:
        os.makedirs(os.path.dirname(WIFI_PASSWORD_STORE), exist_ok=True)
        with open(WIFI_PASSWORD_STORE, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=2)
        os.chmod(WIFI_PASSWORD_STORE, 0o600)
    except Exception as e:
        print("wifi password store write failed:", e)

def wifi_pw_get(name):
    return wifi_pw_store_read().get(name, "")

def wifi_pw_set(name, password):
    d = wifi_pw_store_read()
    d[name] = password
    wifi_pw_store_write(d)

def wifi_pw_delete(name):
    d = wifi_pw_store_read()
    if name in d:
        del d[name]
        wifi_pw_store_write(d)


def setup_config_is_valid():
    try:
        eps = load_endpoints()
        return (
            len([e for e in eps if e.get("ip","").strip()]) >= 1
            and bool(zt_network_id_current())
            and bool(zt_read_token())
        )
    except Exception:
        return False

def setup_is_complete():
    try:
        if os.path.exists(SETUP_COMPLETE_FILE):
            return setup_config_is_valid()

        return False
    except Exception:
        return False

def setup_should_force():
    return (not setup_is_complete()) and (not os.path.exists(SETUP_SKIP_FILE))

def setup_banner():
    if setup_config_is_valid():
        return ""
    return """
    <div class='card' style='margin-bottom:16px;border:2px solid #d39e00;background:#fff3cd;color:#3b2f00;'>
      <h2 style='margin-top:0;color:#3b2f00;'>⚠ First setup incomplete</h2>
      <p>ZeroTier and at least one endpoint host should be configured.</p>
      <a href='/first_setup'><button style='pointer-events:auto;'>Open Setup Wizard</button></a>
    </div>
    """

def first_setup_page():
    return f"""
    <h1>First Setup Wizard</h1>

    <div class='card'>
      <p>This setup appears until completed.</p>
      <p>You can skip for now and continue using the UI during this boot.</p>
    </div>

    <form method='post' action='/first_setup_save'>

      <div class='card'>
        <h2>ZeroTier</h2>

        <label>Network ID</label>
        <input style='pointer-events:auto;' name='nwid'
               value='{esc(zt_network_id_current())}'
               placeholder='ZeroTier network ID'>

        <label>API Token</label>
        <input style='pointer-events:auto;'
               id='fstoken'
               type='password'
               name='token'
               value='{esc(zt_read_token())}'
               placeholder='ZeroTier API token'>

        <label style='display:block;margin-top:8px;'>
          <input type='checkbox'
                 style='width:auto;'
                 onclick="document.getElementById('fstoken').type=this.checked?'text':'password'">
          Show token
        </label>
      </div>

      <div class='card'>
        <h2>Host Endpoint</h2>

        <label>Host name</label>
        <input style='pointer-events:auto;' name='name'
               placeholder='Mac / Android / QGC'>

        <label>Host IP</label>
        <input style='pointer-events:auto;' name='ip'
               placeholder='192.168.x.x'>
      </div>

      <div class='card'>
        <h2>Optional Additional WiFi</h2>

        <label>SSID</label>
        <input style='pointer-events:auto;' name='ssid'
               placeholder='Optional SSID'>

        <label>Password</label>
        <input style='pointer-events:auto;'
               id='fswifi'
               type='password'
               name='password'
               placeholder='Optional password'>

        <label style='display:block;margin-top:8px;'>
          <input type='checkbox'
                 style='width:auto;'
                 onclick="document.getElementById('fswifi').type=this.checked?'text':'password'">
          Show password
        </label>
      </div>

      <div class='card'>
        <button style='pointer-events:auto;'>
          Save and Finish Setup
        </button>

        <button style='pointer-events:auto;margin-left:12px;'
                formaction='/first_setup_skip'>
          Skip for now
        </button>
      </div>

    </form>
    """

SERVICES=[
 "siyi-button-bridge",
 "siyi-video-dual",
 "mediamtx",
 "mavlink-router",
 "zerotier-one",
 "siyi-rec-proxy",
 "siyi-rec-redirect",
 "siyi-webui",
]



STATUS_LABELS={
    "active":"Running",
    "activating":"Waiting / Starting",
    "failed":"Error",
    "inactive":"Stopped",
    "unknown":"Unknown",
}


SERVICE_GROUPS = {
    "Flight Control": ["mavlink-router"],
    "Video System": ["siyi-video-dual", "siyi-rec-proxy", "siyi-rec-redirect"],
    "Control System": ["siyi-button-bridge"],
    "Network": ["zerotier-one"],
    "System": ["siyi-webui"],
}

SERVICE_LABELS={
    "siyi-button-bridge":"Button Control Bridge",
    "siyi-video-dual":"Video Stream Service",
    "mavlink-router":"MAVLink Router",
    "zerotier-one":"ZeroTier Network",
    "siyi-rec-proxy":"Camera / Recording Proxy",
    "siyi-rec-redirect":"Camera Control Redirect",
    "siyi-webui":"Web Interface",
}

ACTIONS=[
"NO_ACTION","MANUAL","FBWA","AUTOTUNE","CRUISE","LOITER","RTL",
"TAKEOFF","QHOVER","QLOITER","QLAND","QRTL",
"ARM","DISARM","TOGGLE_ARM",
"RECORD_TOGGLE","SNAPSHOT",
"ZOOM_IN","ZOOM_OUT","ZOOM_STOP",
"GIMBAL_YAW_RIGHT","GIMBAL_YAW_LEFT","GIMBAL_PITCH_UP","GIMBAL_PITCH_DOWN",
"GIMBAL_STOP","GIMBAL_CENTER","GIMBAL_CENTER_AND_ZOOM_OUT","GIMBAL_LOCK","GIMBAL_FOLLOW"
]

def sh(cmd):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT).strip()
    except subprocess.CalledProcessError as e:
        return e.output.strip()

def esc(x):
    return html.escape(str(x or ""))

def backup(path):
    os.makedirs(BACKUP_DIR, exist_ok=True)
    if os.path.exists(path):
        dst=f"{BACKUP_DIR}/{os.path.basename(path)}.{time.strftime('%Y%m%d_%H%M%S')}.bak"
        shutil.copy2(path,dst)

def read_file(path):
    try:
        return open(path, encoding="utf-8", errors="replace").read()
    except Exception:
        return ""

def write_file(path, content):
    backup(path)
    open(path, "w", encoding="utf-8").write(content)



def zt_save_config(cfg):
    try:
        os.makedirs("/etc/siyi", exist_ok=True)
        open(ZT_CONFIG_FILE, "w").write(json.dumps(cfg, indent=2))
        return True
    except Exception as e:
        print("zt_save_config failed:", e)
        return False


def zt_read_config():
    try:
        if os.path.exists(ZT_CONFIG_FILE):
            with open(ZT_CONFIG_FILE, encoding="utf-8") as f:
                data=json.load(f)
                if isinstance(data, dict):
                    return data
    except Exception:
        pass
    return {}

def zt_write_config(data):
    os.makedirs(os.path.dirname(ZT_CONFIG_FILE), exist_ok=True)
    with open(ZT_CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    try:
        os.chmod(ZT_CONFIG_FILE, 0o600)
    except Exception:
        pass

def zt_save_token(token):
    token=(token or "").strip()
    if not token:
        return
    os.makedirs(os.path.dirname(ZT_TOKEN_FILE), exist_ok=True)
    with open(ZT_TOKEN_FILE, "w", encoding="utf-8") as f:
        f.write(token + "\n")
    try:
        os.chmod(ZT_TOKEN_FILE, 0o600)
    except Exception:
        pass

def zt_read_token():
    try:
        return open(ZT_TOKEN_FILE, encoding="utf-8").read().strip()
    except Exception:
        return ""

def zt_token_saved():
    return bool(zt_read_token())

def zt_node_id():
    out=sh("zerotier-cli info 2>/dev/null || true")
    parts=out.split()
    if len(parts) >= 3 and parts[0] == "200" and parts[1] == "info":
        return parts[2]
    return ""

def zt_current_ip():
    out=sh("zerotier-cli listnetworks 2>/dev/null || true")
    for line in out.splitlines():
        if " OK " in line and "/" in line:
            parts=line.split()
            for part in reversed(parts):
                if "/" in part and "." in part:
                    return part.split("/")[0]
    out=sh("ip -4 -br addr | awk '/zt/ {print $3}' | head -n1 | cut -d/ -f1")
    return out.strip()

def zt_network_id_current():
    cfg=zt_read_config()
    nwid=(cfg.get("network_id") or "").strip()
    if nwid:
        return nwid
    out=sh("zerotier-cli listnetworks 2>/dev/null || true")
    for line in out.splitlines():
        parts=line.split()
        if len(parts) >= 3 and parts[0] == "200" and parts[1] == "listnetworks" and parts[2] != "<nwid>":
            return parts[2]
    return ""

def zt_api_request(method, path, payload=None):
    token=zt_read_token()
    if not token:
        return False, "No API token saved"
    url="https://api.zerotier.com/api/v1" + path
    data=None
    headers={
        "Authorization": "Bearer " + token,
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "curl/8.0 SIYI-Pi-WebUI",
    }
    if payload is not None:
        data=json.dumps(payload).encode("utf-8")
    req=urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=12) as r:
            body=r.read().decode("utf-8", errors="replace")
            return True, body
    except Exception as e:
        return False, str(e)

def zt_test_token():
    nwid=zt_network_id_current()
    if not nwid:
        return "ZT API test failed: no network ID saved/found"
    ok, body=zt_api_request("GET", "/network/" + nwid)
    if ok:
        return "ZT API token OK for network " + nwid
    return "ZT API token test failed for network " + nwid + ": " + body

def zt_authorize_this_pi(default_name="New_PI"):
    nwid=zt_network_id_current()
    node=zt_node_id()

    if not nwid:
        return "ZT authorize failed: no network ID configured"
    if not node:
        return "ZT authorize failed: no local node ID"

    hostname=sh("hostname").strip() or default_name

    # Proven working ZeroTier Central payload.
    payload={
        "config": {
            "authorized": True
        },
        "name": hostname
    }

    ok, body=zt_api_request("POST", "/network/" + nwid + "/member/" + node, payload)

    if not ok:
        return "ZT authorize failed:\n" + body

    return "ZT authorize OK for node " + node + " as " + hostname

def zt_update_camera_route():
    nwid=zt_network_id_current()
    ip=zt_current_ip()
    if not nwid:
        return "ZT route update failed: no network ID"
    if not ip:
        return "ZT route update failed: no Pi ZeroTier IP"

    ok, body=zt_api_request("GET", "/network/" + nwid)
    if not ok:
        return "ZT route update failed reading network: " + body

    try:
        obj=json.loads(body)
        cfg=obj.get("config",{})
        routes=cfg.get("routes") or []
        if not isinstance(routes, list):
            routes=[]
    except Exception as e:
        return "ZT route update failed parsing network JSON: " + str(e)

    # Replace only the camera subnet route, preserve all other routes.
    routes=[r for r in routes if not (isinstance(r,dict) and r.get("target")=="192.168.144.0/24")]
    routes.append({"target":"192.168.144.0/24","via":ip})

    payload={"config":{"routes":routes}}
    ok, body=zt_api_request("POST", "/network/" + nwid, payload)
    if ok:
        return "ZT managed route updated OK: 192.168.144.0/24 via " + ip
    return "ZT managed route update failed: " + body

def zt_full_setup():
    out=[]

    nwid=zt_network_id_current()

    if not nwid:
        return "ZT setup failed: no network ID configured"

    out.append("=== ZT FULL SETUP START ===")
    out.append("Network ID: " + nwid)

    # Step 1: Join network
    out.append("")
    out.append("=== JOIN NETWORK ===")
    join_out=sh(f"zerotier-cli join {nwid}")
    out.append(join_out)

    # Step 2: Authorize/update member
    out.append("")
    out.append("=== AUTHORIZE MEMBER ===")
    auth_out=zt_authorize_this_pi()
    out.append(auth_out)

    # Step 3: Wait for operational state
    out.append("")
    out.append("=== WAIT FOR ZT IP ===")

    zt_ip=None
    status_txt=""

    for i in range(1,16):
        time.sleep(2)

        try:
            status_txt=sh("zerotier-cli listnetworks")
        except Exception as e:
            status_txt=str(e)

        out.append(f"TRY {i}/15")
        out.append(status_txt)

        current=zt_current_ip()

        if current:
            zt_ip=current
            break

    # Step 4: Validate operational success
    if not zt_ip:
        out.append("")
        out.append("ZT SETUP FAILED")
        out.append("No managed ZeroTier IP received.")
        out.append("Current status:")
        out.append(status_txt)

        if "REQUESTING_CONFIGURATION" in status_txt:
            out.append("")
            out.append("Likely causes:")
            out.append("- Member not authorized")
            out.append("- Managed IP assignment disabled")
            out.append("- Broken/stale node state")
            out.append("- Invalid API token")
            out.append("- Network controller issue")

        if "ACCESS_DENIED" in status_txt:
            out.append("")
            out.append("Member exists but is NOT authorized in ZeroTier Central.")

        return "\\n".join(out)

    out.append("")
    out.append("ZT ONLINE OK")
    out.append("Pi ZT IP: " + zt_ip)

    # Step 5: Route update
    out.append("")
    out.append("=== UPDATE CAMERA ROUTE ===")
    out.append(zt_update_camera_route())

    out.append("")
    out.append("=== ZT SETUP COMPLETE ===")

    return "\\n".join(out)

def zt_status_html():
    cfg=zt_read_config()
    nwid=zt_network_id_current()
    token_status="saved" if zt_token_saved() else "not saved"
    node=zt_node_id() or "-"
    ip=zt_current_ip() or "-"
    raw=sh("zerotier-cli info; zerotier-cli listnetworks")
    return f"""
    <div class='grid'>
      <div><b>Network ID</b><br><span class='small'>{esc(nwid or "-")}</span></div>
      <div><b>API token</b><br><span class='small'>{esc(token_status)}</span></div>
      <div><b>This Pi node ID</b><br><span class='small'>{esc(node)}</span></div>
      <div><b>This Pi ZeroTier IP</b><br><span class='small'>{esc(ip)}</span></div>
    </div>
    <details style='margin-top:12px;'><summary>Show ZeroTier raw status</summary><pre>{esc(raw)}</pre></details>
    """

def get_video_values():
    txt=read_file(VIDEO_SERVICE)
    vals={"rtsp":"rtsp://"+CAM_IP+":8554/main.264","protocols":"tcp","latency":"0","host1":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","host2":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","port":"5600"}
    m=re.search(r"location=([^ ]+)", txt)
    if m: vals["rtsp"]=m.group(1)
    m=re.search(r"protocols=([^ ]+)", txt)
    if m: vals["protocols"]=m.group(1)
    m=re.search(r"latency=([^ ]+)", txt)
    if m: vals["latency"]=m.group(1)
    hosts=re.findall(r"udpsink host=([^ ]+) port=([0-9]+)", txt)
    if len(hosts)>0:
        vals["host1"], vals["port"]=hosts[0]
    if len(hosts)>1:
        vals["host2"], _=hosts[1]
    return vals

def make_video_service(rtsp, protocols, latency, host1, host2, port):
    return f"""[Unit]
Description=SIYI RTSP to dual UDP forwarder
After=network-online.target zerotier-one.service NetworkManager.service
Wants=network-online.target zerotier-one.service

[Service]
Type=simple
Restart=always
RestartSec=3
ExecStart=/usr/bin/gst-launch-1.0 -e rtspsrc location={rtsp} latency={latency} protocols={protocols} ! rtph265depay ! h265parse ! rtph265pay config-interval=1 pt=96 ! tee name=t t. ! queue ! udpsink host={host1} port={port} t. ! queue ! udpsink host={host2} port={port}
ExecStop=/usr/bin/pkill -f "gst-launch-1.0"
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
"""

def get_mav_values():
    txt=read_file(MAVCONF)
    vals={"device":"/dev/ttyAMA0","baud":"57600","android":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","mac":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","port":"14550","tcp":"5760"}
    m=re.search(r"TcpServerPort=([0-9]+)", txt)
    if m: vals["tcp"]=m.group(1)
    m=re.search(r"Device=(.+)", txt)
    if m: vals["device"]=m.group(1).strip()
    m=re.search(r"Baud=([0-9]+)", txt)
    if m: vals["baud"]=m.group(1)
    m=re.search(r"\[UdpEndpoint android\].*?Address=([0-9.]+).*?Port=([0-9]+)", txt, re.S)
    if m: vals["android"], vals["port"]=m.group(1), m.group(2)
    m=re.search(r"\[UdpEndpoint mac\].*?Address=([0-9.]+)", txt, re.S)
    if m: vals["mac"]=m.group(1)
    return vals

def make_mav_conf(device, baud, android, mac, port, tcp):
    return f"""[General]
TcpServerPort={tcp}
ReportStats=false

[UartEndpoint fc]
Device={device}
Baud={baud}

[UdpEndpoint android]
Mode=Normal
Address={android}
Port={port}

[UdpEndpoint mac]
Mode=Normal
Address={mac}
Port={port}

[UdpEndpoint button_safety]
Mode=Normal
Address=127.0.0.1
Port=14600
"""



def system_summary():
    problems = []
    warnings = []

    for s in SERVICES:
        state = sh(f"systemctl is-active {s} 2>/dev/null || true")
        if state == "failed":
            problems.append(s)
        elif state == "activating":
            warnings.append(s)

    if problems:
        return f"<div style='color:#ef4444;font-weight:bold'>❌ Issues: {', '.join(problems)}</div>"
    if warnings:
        return f"<div style='color:#f59e0b;font-weight:bold'>⚠ Waiting: {', '.join(warnings)}</div>"
    return "<div style='color:#22c55e;font-weight:bold'>✔ All systems running</div>"

def service_rows():
    rows = ""
    for group, services in SERVICE_GROUPS.items():
        rows += f"<tr><td colspan='3' style='padding-top:10px;font-weight:bold;color:#93c5fd'>{group}</td></tr>"
        for s in services:
            active = sh(f"systemctl is-active {s} 2>/dev/null || true")
            cls = "ok" if active == "active" else ("bad" if active in ["failed"] else "")
            disabled = "disabled" if s == "siyi-webui" else ""
            label = SERVICE_LABELS.get(s, s)
            status_label = STATUS_LABELS.get(active, active)
            rows += f"<tr><td><b>{esc(label)}</b><br><span class='small'>{esc(s)}</span></td><td class='{cls}'><b>{esc(status_label)}</b><br><span class='small'>{esc(active)}</span></td><td><form method='post' action='/restart'><input style='pointer-events:auto;' type='hidden' name='service' value='{s}'><button style='pointer-events:auto;' {disabled}>Restart</button></form></td></tr>"
    return rows


def action_select(name, current):
    return "<select style='pointer-events:auto;' name='%s'>%s</select>" % (
        name,
        "".join([f"<option {'selected' if a==current else ''}>{a}</option>" for a in ACTIONS])
    )

def read_button_rows():
    if not os.path.exists(BUTTON_MAP):
        return []
    with open(BUTTON_MAP,encoding="utf-8-sig") as f:
        return list(csv.DictReader(f,delimiter=";"))



def wifi_profiles_cards():
    active_ssid = sh("iwgetid -r 2>/dev/null || true").strip()
    active_conn = sh("nmcli -g GENERAL.CONNECTION dev show wlan0 2>/dev/null || true").strip()

    # --- LIVE SCAN ---
    scan_map = {}
    try:
        scan = sh("nmcli -t -f SSID,SIGNAL dev wifi list ifname wlan0 2>/dev/null")
        for line in scan.splitlines():
            parts = line.split(":")
            if len(parts) >= 2:
                ssid = parts[0].replace("\\:", ":").strip()
                sig = int(parts[1]) if parts[1].isdigit() else 0
                if ssid:
                    scan_map[ssid] = max(sig, scan_map.get(ssid, 0))
    except Exception:
        pass

    lines = sh("nmcli -t -f NAME,TYPE,DEVICE,AUTOCONNECT connection show").splitlines()

    active_list = []
    visible_list = []
    saved_list = []

    for line in lines:
        parts = line.split(":")
        if len(parts) < 4:
            continue

        name, typ, device, autoconnect = parts[0], parts[1], parts[2], parts[3]

        if typ not in ("wifi", "802-11-wireless"):
            continue

        ssid = sh(f"nmcli -g 802-11-wireless.ssid connection show '{name}' 2>/dev/null || true").strip()

        if not ssid and name == active_conn and active_ssid:
            ssid = active_ssid

        if not ssid:
            ssid = "(unknown)"

        prio = sh(f"nmcli -g connection.autoconnect-priority connection show '{name}' 2>/dev/null || true").strip() or "0"
        psk = wifi_pw_get(name)

        active = (name == active_conn or device == "wlan0")
        visible = ssid in scan_map
        signal = scan_map.get(ssid, 0)

        # --- CLASSIFY ---
        if active:
            state = "active"
        elif visible:
            state = "visible"
        else:
            state = "saved"

        entry = (ssid, name, device, autoconnect, prio, signal, state, psk)

        if state == "active":
            active_list.append(entry)
        elif state == "visible":
            visible_list.append(entry)
        else:
            saved_list.append(entry)

    # --- SORT ---
    visible_list.sort(key=lambda x: -x[5])
    saved_list.sort(key=lambda x: -int(x[4]))

    def render_card(e, highlight=False):
        ssid, name, device, autoconnect, prio, signal, state, psk = e

        if state == "active":
            label = "🟢 Connected"
            cls = "ok"
        elif state == "visible":
            label = f"🔵 In range ({signal}%)"
            cls = "warn"
        else:
            label = "🟡 Saved"
            cls = "bad"

        bars = int(signal / 20)
        signal_bar = "▮" * bars + "▯" * (5 - bars)

        is_system = name.startswith("netplan-")

        if is_system:
            controls = "<div class='readonlybox'>System network (read-only)</div>"
        else:
            controls = f"""
            <div class='inlineform'>
              <button style='pointer-events:auto;' class='switchbtn'   onclick="location.href='/wifi_switch?name={esc(name)}'">Connect</button>
              <label>Priority</label>
              <input style='pointer-events:auto;' value='{esc(prio)}' class='smallinput' readonly>
              <label>Auto</label>
              <span>{esc(autoconnect)}</span>
            </div>
            """

        bg = "#0f1b2e" if highlight else "#0b1220"

        try:
            in_range = int(signal) > 0
        except Exception:
            in_range = False

        wifi_actions = ""
        if not highlight:
            if in_range:
                wifi_actions += f"""
<form method='post' action='/wifi_switch' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<button class='switchbtn'>Connect now</button>
</form>"""

            wifi_actions += f"""
<form method='post' action='/wifi_update_password' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<input style='pointer-events:auto;width:170px;' type='password' name='password' value='{esc(psk)}' placeholder='Wi-Fi password'>
<label class='small'>
<input style='pointer-events:auto;width:auto;' type='checkbox' onclick="this.closest('form').querySelector('input[name=password]').type=this.checked?'text':'password'">
Show
</label>
<button style='pointer-events:auto;' type='submit'>Update password</button>
</form>

<form method='post' action='/wifi_delete' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<button class='danger'>Delete</button>
</form>"""

        return f"""
        <div class='ssidcard' style="background:{bg}; border:1px solid #334155;">
          <div class='ssidtop'>
            <div>
              <div class='ssidtitle'>{esc(ssid)} <span class='status-pill {cls}'>{label}</span></div>
              <div class='ssidmeta'>{signal_bar} {signal}%</div>
              <div class='ssidmeta'> {esc(name)}</div>
            </div>
            <div class='ssidfacts'>
              <div><b>Priority</b><br>{esc(prio)}</div>
              <div><b>Auto</b><br>{esc(autoconnect)}</div>
            </div>
          </div>
          <div class='ssidcontrols'>
<form method='post' action='/wifi_update' class='inlineform'>
<input type='hidden' name='name' value='{esc(name)}'>
<label>Priority</label>
<input name='priority' value='{esc(prio)}' class='smallinput'>
<label>Autoconnect</label>
<select name='autoconnect' class='smallselect'>
<option {'selected' if autoconnect=='yes' else ''}>yes</option>
<option {'selected' if autoconnect=='no' else ''}>no</option>
</select>
<button>Apply</button>
</form>
{wifi_actions}
</div>
        </div>
        """

    html = ""

    if active_list:
        html += "<h2>Connected</h2>"
        for e in active_list:
            html += render_card(e, True)

    if visible_list:
        html += "<h2>Available Networks</h2>"
        for e in visible_list:
            html += render_card(e)

    if saved_list:
        html += "<h2>Saved Networks</h2>"
        for e in saved_list:
            html += render_card(e)

    return html or "<p>No Wi-Fi profiles found</p>"
def page(title, body):
    return f"""<!doctype html>
<html><head><meta charset="utf-8"><title>{title}</title>
<style>
body{{margin:0;background:#0f172a;color:#e5e7eb;font-family:Arial}}
header{{background:#020617;padding:10px 20px;font-size:22px;font-weight:bold;border-bottom:1px solid #334155;position:fixed;top:0;left:0;right:0;z-index:2;height:36px}}
nav{{width:180px;background:#020617;height:calc(100vh - 58px);position:fixed;left:0;top:58px;padding:15px;border-right:1px solid #334155;overflow-y:auto}}
nav a{{display:block;color:#cbd5e1;text-decoration:none;padding:11px;border-radius:8px;margin-bottom:4px}}
nav a:hover{{background:#1f2937;color:white}}
main{{margin-left:210px;padding:82px 24px 24px 24px}}
.card{{background:#111827;border:1px solid #334155;border-radius:12px;padding:16px;margin-bottom:16px}}
.grid{{display:grid;grid-template-columns:repeat(2,minmax(220px,1fr));gap:12px}}
table{{border-collapse:collapse;width:100%;font-size:14px}}
td,th{{border-bottom:1px solid #334155;padding:8px;text-align:left;vertical-align:top}}
input,select,textarea{{background:#020617;color:#e5e7eb;border:1px solid #334155;border-radius:6px;padding:7px;width:100%}}
button{{background:#2563eb;color:white;border:0;border-radius:8px;padding:9px 13px;margin:4px;cursor:pointer}}
button.danger{{background:#991b1b}}
pre{{background:#020617;border:1px solid #334155;border-radius:8px;padding:12px;overflow:auto;white-space:pre-wrap}}
.ok{{color:#22c55e}} .bad{{color:#ef4444}} .small{{font-size:13px;color:#94a3b8}}
.pill{{padding:3px 8px;border-radius:999px;font-size:12px;margin-left:8px}}
.pill.active{{background:#14532d;color:#86efac}}
.pill.inactive{{background:#334155;color:#cbd5e1}}
.ssidcard{{border:1px solid #334155;border-radius:10px;padding:14px;margin-bottom:12px;background:#0b1220}}
.ssidtop{{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}}
.ssidtitle{{font-size:18px;font-weight:bold;margin-bottom:6px}}
.ssidmeta{{color:#94a3b8;font-size:13px;line-height:1.5}}
.ssidfacts{{display:flex;gap:18px;margin-top:10px}}
.ssidcontrols{{margin-top:12px;border-top:1px solid #334155;padding-top:10px}}
.inlineform{{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:6px 0}}
.smallinput{{width:80px}}
.smallselect{{width:120px}}
.switchbtn{{background:#16a34a}}
.readonlybox{{color:#94a3b8}}

.statusdotimg{{width:14px;height:14px;margin-left:12px;vertical-align:middle}}
.statuslabel{{font-size:13px;color:#94a3b8;margin-left:6px;font-weight:normal}}

.statusdot{{display:inline-block;width:13px;height:13px;border-radius:50%;background:#ef4444;margin-left:12px;vertical-align:middle;box-shadow:0 0 8px #ef4444}}
.statusdot.ok{{background:#22c55e;box-shadow:0 0 8px #22c55e}}
.statuslabel{{font-size:13px;color:#94a3b8;margin-left:6px;font-weight:normal}}


#top-status-bar{{display:inline-flex;gap:6px;align-items:center;white-space:nowrap}}
.status-pill{{font-size:13px;font-weight:bold;padding:5px 10px;border-radius:999px;color:white;margin-left:6px}}
.status-pill.ok{{background:#166534;color:white}}
.status-pill.bad{{background:#991b1b;color:white}}
.status-pill.warn{{background:#92400e;color:white}}

</style></head>
<body>
<header>SIYI Pi Control Center {VERSION}<span id="statusbar" style="display:inline-block;margin-left:14px;vertical-align:middle;"></span></header>
<nav>
<a href="/">Operations</a>
<a href="/first_setup">Wizard</a>
<a href="/wifi">WiFi</a>
<a href="/zerotier">ZeroTier</a>
<a href="/endpoints">Hosts</a>
<a href="/mavlink">MAVLink</a>
<a href="/video">Video</a>
<a href="/buttons">Buttons</a>
<a href="/camera_controls">Camera</a>
<a href="/camera_sd">Camera SD</a>
<a href="/logs">Diagnostics</a>
</nav>
<main>{body}</main>

<script>
function setPiStatus(ok){{
  var d=document.getElementById('pidot');
  var l=document.getElementById('pilabel');
  if(!d || !l) return;
  if(ok){{
    d.classList.add('ok');
    l.textContent='Pi connected';
  }} else {{
    d.classList.remove('ok');
    l.textContent='Pi disconnected';
  }}
}}
async function checkPi(){{
  try{{
    const r = await fetch('/health?ts=' + Date.now(), {{cache:'no-store'}});
    setPiStatus(r.ok);
  }} catch(e){{
    setPiStatus(false);
  }}
}}
async function refreshStatusBar(){{
  const el = document.getElementById('statusbar');
  try {{
    const r = await fetch('/status_bar?ts=' + Date.now(), {{cache:'no-store'}});
    if(!r.ok) throw new Error('status fetch failed');
    el.innerHTML = await r.text();
  }} catch(e) {{
    el.innerHTML = '<span style="font-size:13px;font-weight:bold;padding:5px 10px;border-radius:999px;color:white;background:#991b1b">Network Lost / Stale</span>';
  }}
}}

refreshStatusBar();
setInterval(refreshStatusBar,3000);

checkPi();
setInterval(checkPi,3000);
</script>

</body></html>"""


SERVICE_LABELS = {
    "siyi-button-bridge": "Button Control Bridge",
    "siyi-video-dual": "Video Stream (Dual Output)",
    "mavlink-router": "MAVLink Router (FC ↔ Hosts)",
    "zerotier-one": "ZeroTier Network",
    "siyi-rec-proxy": "Camera / Recording Proxy",
    "siyi-rec-redirect": "Camera Control Redirect",
    "siyi-webui": "Web Interface"
}


CAM_SD_BASE="http://"+CAM_IP+":82"
CAM_SD_DIR="100SIYI_VID"
CAM_SD_MEDIA_TYPE=1
UNIGCS_FIFO="/tmp/siyi_record_proxy"
BYTES_PER_SECOND_2K = int(2.5 * 1024 * 1024)
SD_TOTAL_BYTES = 68719476736

def camera_sd_json(url, timeout=5):
    with urllib.request.urlopen(url, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="replace"))


def probe_resolution(url):
    try:
        out = subprocess.check_output([
            "ffprobe","-v","error",
            "-select_streams","v:0",
            "-show_entries","stream=width,height",
            "-of","csv=p=0",
            url
        ], timeout=2).decode().strip()
        if out:
            w,h = out.split(",")
            return f"{w}x{h}"
    except Exception:
        pass
    return ""

def camera_sd_files():
    count_url=f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getmediacount?media_type={CAM_SD_MEDIA_TYPE}&path={urllib.parse.quote(CAM_SD_DIR)}"
    count_data=camera_sd_json(count_url)
    count=int(count_data.get("data",{}).get("count",0))
    list_url=f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getmedialist?media_type={CAM_SD_MEDIA_TYPE}&path={urllib.parse.quote(CAM_SD_DIR)}&start=0&count={count}"
    list_data=camera_sd_json(list_url)
    return list_data.get("data",{}).get("list",[])


def camera_sd_head(url, timeout=5):
    try:
        req=urllib.request.Request(url, method="HEAD")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            size=r.headers.get("Content-Length","")
            mod=r.headers.get("Last-Modified","")
            return size, mod
    except Exception:
        return "", ""

def human_size(n):
    try:
        n=int(n)
        for unit in ["B","KB","MB","GB"]:
            if n < 1024:
                return f"{n:.1f} {unit}" if unit!="B" else f"{n} {unit}"
            n = n / 1024
        return f"{n:.1f} TB"
    except Exception:
        return "-"


def camera_sd_capacity():
    """
    Try to read SD card capacity from SIYI camera API.
    Returns: total_bytes, free_bytes
    If unknown, returns: None, None
    """
    candidates = [
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getsdinfo",
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getmediainfo",
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/getstorageinfo",
    ]

    for url in candidates:
        try:
            with urllib.request.urlopen(url, timeout=3) as r:
                raw = r.read().decode(errors="ignore")
                data = json.loads(raw)

            def find_number(obj, keys):
                if isinstance(obj, dict):
                    for k, v in obj.items():
                        lk = str(k).lower()
                        if lk in keys:
                            try:
                                return int(v)
                            except Exception:
                                pass
                        found = find_number(v, keys)
                        if found is not None:
                            return found
                elif isinstance(obj, list):
                    for item in obj:
                        found = find_number(item, keys)
                        if found is not None:
                            return found
                return None

            total = find_number(data, {"total", "totalsize", "total_size", "capacity", "sd_total", "sdtotal"})
            free = find_number(data, {"free", "freesize", "free_size", "available", "avail", "sd_free", "sdfree"})

            if total and free is not None:
                return total, free

        except Exception:
            pass

    return None, None


def camera_sd_page():
    try:
        files=camera_sd_files()

        # SORT: newest -> oldest by SIYI filename
        try:
            files = sorted(files, key=lambda x: x.get("name",""), reverse=True)
        except Exception:
            pass

        # Fast metadata fetch: get file size/date in parallel instead of slow sequential HEAD calls
        meta = {}
        try:
            from concurrent.futures import ThreadPoolExecutor, as_completed
            urls = [x.get("url","") for x in files if x.get("url","")]
            with ThreadPoolExecutor(max_workers=16) as ex:
                futs = {ex.submit(camera_sd_head, u, 1.5): u for u in urls}
                for fut in as_completed(futs):
                    u = futs[fut]
                    try:
                        meta[u] = fut.result()
                    except Exception:
                        meta[u] = ("", "")
        except Exception:
            meta = {}

        rows=""
        total_used = 0
        for idx, f in enumerate(files):
            name=f.get("name","")
            url=f.get("url","")
            size,lastmod = meta.get(url, ("",""))

            res = ""
            label = name

            if size:
                try:
                    total_used += int(size)
                except Exception:
                    pass
            rows+=f"""<tr>
<td><input style='pointer-events:auto;' type="checkbox" class="sdcheck" name="urls" value="{esc(url)}"></td>
<td><b>{esc(label)}</b><br>
<span class='small'>{esc(url)}</span> <span class="sd-res small" data-url="{esc(url)}"></span><br>
<a href="{esc(url)}" target="_blank">Stream / Open</a>
&nbsp;|&nbsp;
<a href="/camera_sd_download?url={urllib.parse.quote(url)}">Download</a>
&nbsp;|&nbsp;
<a class="danger" href="/camera_sd_delete?url={urllib.parse.quote(url)}" onclick="return confirm('Delete this file from camera SD card?');">Delete</a>
</td>
<td>{esc(human_size(size))}</td>
<td>{esc(lastmod if lastmod else "-")}</td>
</tr>"""
        total_cap, free_cap = camera_sd_capacity()
        used_str = human_size(total_used)

        if SD_TOTAL_BYTES:
            total_str = human_size(SD_TOTAL_BYTES)
            free_bytes = SD_TOTAL_BYTES - total_used
            free_bytes = max(0, free_bytes)
            free_str = human_size(free_bytes)
            percent = int((total_used / SD_TOTAL_BYTES) * 100)

            # Estimate recording time left (2K)
            try:
                seconds_left = int(free_bytes / BYTES_PER_SECOND_2K)
                hours = seconds_left // 3600
                minutes = (seconds_left % 3600) // 60
                time_str = f"{hours}h {minutes:02d}m"
            except:
                time_str = "unknown"

            sd_summary = f"Used: {used_str} / {total_str} ({percent}%) | Free: {free_str} | Approx {time_str} 2K recording"
        else:
            sd_summary = f"Used: {used_str}"

        return f"""<h1>Camera SD Card</h1>
<span style="font-size:12px;opacity:.65;margin-left:10px;">v{VERSION}</span>
<div class='card' ><h2>Files on Camera SD</h2>
<p class='small'>Directory: {esc(CAM_SD_DIR)} | Count: {len(files)}<br>{esc(sd_summary)}</p>
<form id="sdform" method="post">
<div style="margin-bottom:10px;display:flex;gap:8px;flex-wrap:wrap;">
<button style='pointer-events:auto;' type="button" onclick="document.querySelectorAll('.sdcheck').forEach(c=>c.checked=true)">Select all</button>
<button style='pointer-events:auto;' type="button" onclick="document.querySelectorAll('.sdcheck').forEach(c=>c.checked=false)">Clear selection</button>
<button style='pointer-events:auto;' type="submit" formaction="/camera_sd_zip">Download selected as ZIP</button>
<button style='pointer-events:auto;' class="danger" type="submit" formaction="/camera_sd_delete_selected" onclick="return confirm('Delete all selected files from camera SD card?');">Delete selected</button>
</div>
<table><tr><th>Select</th><th>File</th><th>Size</th><th>Camera Date</th></tr>{rows}</table>
</form>

<script>
(function(){{
  async function loadSdRes(){{
    const spans = Array.from(document.querySelectorAll(".sd-res[data-url]"));
    for (const span of spans){{
      const url = span.dataset.url;
      if (!url) {{
        span.textContent = "-";
        continue;
      }}
      span.textContent = "...";
      try {{
        const r = await fetch("/camera_sd_res?url=" + encodeURIComponent(url), {{cache:"no-store"}});
        const j = await r.json();
        span.textContent = j.res || "-";
      }} catch(e) {{
        span.textContent = "ERR";
      }}
      await new Promise(resolve => setTimeout(resolve, 80));
    }}
  }}

  if (document.readyState === "loading") {{
    document.addEventListener("DOMContentLoaded", function(){{ setTimeout(loadSdRes, 200); }});
  }} else {{
    setTimeout(loadSdRes, 200);
  }}
}})();
</script>

</div>"""
    except Exception as e:
        return f"<h1>Camera SD Card</h1><div class='card'><h2 class='bad'>Could not read camera SD</h2><pre>{esc(str(e))}</pre></div>"


def camera_sd_delete_many(urls):
    data=json.dumps({"media_type":CAM_SD_MEDIA_TYPE,"paths":urls}).encode()
    req=urllib.request.Request(
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/deletemedialist",
        data=data,
        headers={"Content-Type":"application/json","Accept":"application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        return r.read().decode("utf-8", errors="replace")

def camera_sd_delete(url):
    data=json.dumps({"media_type":CAM_SD_MEDIA_TYPE,"paths":[url]}).encode()
    req=urllib.request.Request(
        f"{CAM_SD_BASE}/cgi-bin/media.cgi/api/v1/deletemedialist",
        data=data,
        headers={"Content-Type":"application/json","Accept":"application/json"},
        method="POST"
    )
    with urllib.request.urlopen(req, timeout=8) as r:
        return r.read().decode("utf-8", errors="replace")


def unigcs_controls_page():
    return """<div class="cam-full"><h1>Camera Controls</h1>\n




<style>/* CAMERA_CONTROLS_COMPACT_SAFE_V3 */
.cam-grid{
  display:grid;
  grid-template-columns: repeat(2, minmax(280px, 1fr));
  gap:12px 14px;
  width:100%;
  max-width:none;
  margin:0;
}
.cam-full{
  width:100%;
  max-width:none;
  margin:0 0 10px 0;
}
.card{
  max-width:none;
  width:100%;
  margin:0;
  padding:10px 12px;
  box-sizing:border-box;
}
.card h2{
  margin:0 0 8px 0;
  font-size:18px;
}
.card form{margin:6px 0;}
.gimbal-row{
  display:flex;
  gap:20px;
  align-items:center;
  flex-wrap:wrap;
}
.gimbal-row label{
  display:flex;
  align-items:center;
  gap:6px;
  white-space:nowrap;
}
.cam-grid .card:nth-child(5) form{
  display:inline-block;
  margin-right:4px;
  white-space:nowrap;
}
.cam-grid .card:nth-child(5) button{
  margin-left:0;
  margin-right:6px;
}
.card button{margin:3px 4px 3px 0;padding:6px 10px;}
.card input[type=range]{width:calc(100% - 55px);max-width:none;}
.image-row{
  display:grid;
  grid-template-columns:90px 1fr 38px;
  gap:8px;
  align-items:center;
  margin:4px 0;
}
.image-row label{
  white-space:nowrap;
  color:#cbd5e1;
}
.image-row input[type=range]{
  width:100%;
  max-width:none;
}

.exposure-row{
  display:grid;
  grid-template-columns:110px 1fr;
  gap:8px;
  align-items:center;
  margin:6px 0;
}
.exposure-row label{
  white-space:nowrap;
  color:#cbd5e1;
}
.exposure-row select{
  width:100%;
}

.image-row output{
  text-align:right;
  color:#e5e7eb;
}

.card output{display:inline-block;width:38px;text-align:right;}
.cam-grid .card:first-child button[type=submit]{display:none;}
@media(max-width:900px){
  .cam-grid{grid-template-columns:1fr;}
}
</style>





<script>
function sendSlider(el){
  const data = new URLSearchParams();
  data.append(el.name, el.value);

  fetch('/unigcs_control', {method:'POST', body:data})
    .then(()=>{ document.getElementById('unigcs_status').innerText='Sent: '+el.value; })
    .catch(()=>{ document.getElementById('unigcs_status').innerText='Failed'; });
}

function sendCmd(cmd){
  const data = new URLSearchParams();
  data.append('cmd', cmd);
  fetch('/unigcs_control', {method:'POST', body:data})
    .then(()=>{ document.getElementById('unigcs_status').innerText='Sent: '+cmd; })
    .catch(()=>{ document.getElementById('unigcs_status').innerText='Failed: '+cmd; });
  return false;
}

function sendForm(form){
  const data = new URLSearchParams(new FormData(form));
  fetch('/unigcs_control', {method:'POST', body:data})
    .then(()=>{ document.getElementById('unigcs_status').innerText='Sent'; })
    .catch(e=>{ document.getElementById('unigcs_status').innerText='Failed'; });
  return false;
}

// UI_ACTIVE_STATE_TRACKER_V1
(function(){
  const groups = {
    stream_720p: "stream_res",
    stream_1080p: "stream_res",
    rec_720p: "rec_res",
    rec_1080p: "rec_res",
    rec_2k: "rec_res",
    rec_4k: "rec_res",
    autorecord_on: "auto_rec",
    autorecord_off: "auto_rec",
    gimbal_lock: "gimbal_mode",
    gimbal_follow: "gimbal_mode",
    gimbal_fpv: "gimbal_mode"
  };

  function restoreRadio(group){
    const cmd = localStorage.getItem("siyi_state_" + group);
    if(!cmd) return;
    document.querySelectorAll('input[type="radio"][name="' + group + '"]').forEach(function(r){
      const onclick = r.getAttribute("onclick") || "";
      if(onclick.indexOf(cmd) >= 0) r.checked = true;
    });
  }

  const oldSendCmd = window.sendCmd;
  window.sendCmd = function(cmd){
    const group = groups[cmd];
    if(group) localStorage.setItem("siyi_state_" + group, cmd);
    return oldSendCmd(cmd);
  };

  function restoreValues(){
    ["brightness","contrast","saturation"].forEach(function(name){
      const val = localStorage.getItem("siyi_value_" + name);
      if(val === null) return;
      const el = document.querySelector('input[type="range"][name="' + name + '"]');
      if(el){
        el.value = val;
        const out = el.parentElement ? el.parentElement.querySelector("output") : null;
        if(out) out.value = val;
      }
    });

    ["ev","ss"].forEach(function(name){
      const val = localStorage.getItem("siyi_value_" + name);
      if(val === null) return;
      const el = document.querySelector('select[name="' + name + '"]');
      if(el) el.value = val;
    });
  }

  const oldSendSlider = window.sendSlider;
  window.sendSlider = function(el){
    if(el && el.name){
      localStorage.setItem("siyi_value_" + el.name, el.value);
    }
    return oldSendSlider(el);
  };

  const oldSendForm = window.sendForm;
  window.sendForm = function(form){
    if(form){
      const field = form.querySelector("select[name], input[name]");
      if(field && field.name){
        localStorage.setItem("siyi_value_" + field.name, field.value);
      }
    }
    return oldSendForm(form);
  };

  document.addEventListener("DOMContentLoaded", function(){
    restoreRadio("stream_res");
    restoreRadio("rec_res");
    restoreRadio("auto_rec");
    restoreRadio("gimbal_mode");
    restoreValues();
  });
})();


// PI_SHARED_STATE_SIDECAR_V1
(function(){
  const STATE_URL = "http://" + window.location.hostname + ":8081/ui_state";

  const groups = {
    stream_720p: "stream_res",
    stream_1080p: "stream_res",
    rec_720p: "rec_res",
    rec_1080p: "rec_res",
    rec_2k: "rec_res",
    rec_4k: "rec_res",
    autorecord_on: "auto_rec",
    autorecord_off: "auto_rec",
    gimbal_lock: "gimbal_mode",
    gimbal_follow: "gimbal_mode",
    gimbal_fpv: "gimbal_mode"
  };

  function postState(obj){
    fetch(STATE_URL, {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(obj)
    }).catch(function(){});
  }

  function applyState(st){
    if(!st) return;

    ["stream_res","rec_res","auto_rec","gimbal_mode"].forEach(function(group){
      const cmd = st[group];
      if(!cmd) return;
      document.querySelectorAll('input[type="radio"][name="' + group + '"]').forEach(function(r){
        const onclick = r.getAttribute("onclick") || "";
        if(onclick.indexOf(cmd) >= 0) r.checked = true;
      });
    });

    ["brightness","contrast","saturation"].forEach(function(name){
      const val = st[name];
      if(val === undefined || val === null) return;
      const el = document.querySelector('input[type="range"][name="' + name + '"]');
      if(el){
        el.value = val;
        const out = el.parentElement ? el.parentElement.querySelector("output") : null;
        if(out) out.value = val;
      }
    });

    ["ev","ss"].forEach(function(name){
      const val = st[name];
      if(val === undefined || val === null) return;
      const el = document.querySelector('select[name="' + name + '"]');
      if(el) el.value = val;
    });
  }

  const prevSendCmd = window.sendCmd;
  window.sendCmd = function(cmd){
    const group = groups[cmd];
    if(group){
      const obj = {};
      obj[group] = cmd;
      postState(obj);
    }
    return prevSendCmd(cmd);
  };

  const prevSendSlider = window.sendSlider;
  window.sendSlider = function(el){
    if(el && el.name){
      const obj = {};
      obj[el.name] = el.value;
      postState(obj);
    }
    return prevSendSlider(el);
  };

  const prevSendForm = window.sendForm;
  window.sendForm = function(form){
    if(form){
      const field = form.querySelector("select[name], input[name]");
      if(field && field.name){
        const obj = {};
        obj[field.name] = field.value;
        postState(obj);
      }
    }
    return prevSendForm(form);
  };

  document.addEventListener("DOMContentLoaded", function(){
    setTimeout(function(){
      fetch(STATE_URL, {cache:"no-store"})
        .then(function(r){ return r.json(); })
        .then(applyState)
        .catch(function(){});
    }, 250);
  });
})();

</script>
<div id="unigcs_status" class="small">Ready</div></div>
<div class="cam-grid">
<div class='card'>
<h2>Image</h2>

<form class="image-row" onsubmit="return false;">
<label>Brightness</label>
<input style='pointer-events:auto;' type="range" onchange="sendSlider(this)" name="brightness" min="0" max="100" value="50" oninput="bval.value=this.value">
<output id="bval">50</output>
</form>

<form class="image-row" onsubmit="return false;">
<label>Contrast</label>
<input style='pointer-events:auto;' type="range" onchange="sendSlider(this)" name="contrast" min="0" max="100" value="50" oninput="cval.value=this.value">
<output id="cval">50</output>
</form>

<form class="image-row" onsubmit="return false;">
<label>Saturation</label>
<input style='pointer-events:auto;' type="range" onchange="sendSlider(this)" name="saturation" min="0" max="100" value="50" oninput="sval.value=this.value">
<output id="sval">50</output>
</form>
</div>

<div class='card'>
<h2>Exposure <span style="color:#9ca3af;font-size:11px;font-style:italic;">(currently unsupported)</span></h2>

<form class="exposure-row" onsubmit="return false;">
<label>EV</label>
<select style='pointer-events:auto;' name="ev" onchange="sendForm(this.form)">
<option value="0">Auto</option>
<option value="1">-2.0</option>
<option value="2">-1.5</option>
<option value="3">-1.0</option>
<option value="4">-0.5</option>
<option value="5">0</option>
<option value="6">+0.5</option>
<option value="7">+1.0</option>
<option value="8">+1.5</option>
<option value="9">+2.0</option>
</select>
</form>

<form class="exposure-row" onsubmit="return false;">
<label>Shutter Speed</label>
<select style='pointer-events:auto;' name="ss" onchange="sendForm(this.form)">
<option value="0">Auto</option>
<option value="1">1/30</option>
<option value="2">1/60</option>
<option value="3">1/120</option>
<option value="4">1/250</option>
<option value="5">1/500</option>
<option value="6">1/1000</option>
<option value="7">1/2000</option>
</select>
</form>
</div>

<div class='card'>
<h2>Stream Resolution</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">720p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="stream_res" onclick="sendCmd('stream_720p')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">1080p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="stream_res" onclick="sendCmd('stream_1080p')"></span>
</form>
</div>

<div class='card'>
<h2>Recording Resolution</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">720p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_720p')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">1080p <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_1080p')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">2K <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_2k')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">4K <input style='pointer-events:auto;' style="width:auto;" type="radio" name="rec_res" onclick="sendCmd('rec_4k')"></span>
</form>
</div>

<div class='card'>
<h2>Gimbal Mode</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">Lock <input style='pointer-events:auto;' style="width:auto;" type="radio" name="gimbal_mode" onclick="sendCmd('gimbal_lock')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">Follow <input style='pointer-events:auto;' style="width:auto;" type="radio" name="gimbal_mode" onclick="sendCmd('gimbal_follow')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">FPV <input style='pointer-events:auto;' style="width:auto;" type="radio" name="gimbal_mode" onclick="sendCmd('gimbal_fpv')"></span>
</form>
</div>

<div class='card'>
<h2>Auto Recording</h2>
<form onsubmit="return false;" style="display:flex;flex-direction:row;align-items:center;gap:22px;flex-wrap:nowrap;">
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">On <input style='pointer-events:auto;' style="width:auto;" type="radio" name="auto_rec" onclick="sendCmd('autorecord_on')"></span>
<span style="display:inline-flex;align-items:center;gap:6px;white-space:nowrap;">Off <input style='pointer-events:auto;' style="width:auto;" type="radio" name="auto_rec" onclick="sendCmd('autorecord_off')"></span>
</form>
</div>

</div>
<p class="small cam-full"></p>
"""

def send_unigcs_fifo(command):
    command = (command or "").strip()
    if not command:
        return "No command"

    allowed_prefixes = ("brightness:", "saturation:", "contrast:", "ev:", "ss:")
    allowed_exact = {
        "stream_720p", "stream_1080p",
        "rec_720p", "rec_1080p", "rec_2k", "rec_4k",
        "gimbal_lock", "gimbal_follow", "gimbal_fpv",
        "autorecord_on", "autorecord_off",
        "start", "stop",
    }

    commands = [c.strip() for c in command.split(";") if c.strip()]

    for c in commands:
        if c not in allowed_exact and not c.startswith(allowed_prefixes):
            return "Rejected command: " + c

    import os, errno, time

    try:
        # retry open FIFO safely
        fd = None
        for _ in range(20):
            try:
                fd = os.open(UNIGCS_FIFO, os.O_WRONLY | os.O_NONBLOCK)
                break
            except OSError:
                time.sleep(0.05)
        if fd is None:
            return "FIFO not ready"

        try:
            for c in commands:
                os.write(fd, (c + "\n").encode())
                time.sleep(0.05)
        finally:
            os.close(fd)
    except OSError as e:
        if e.errno == errno.ENXIO:
            return "FIFO has no active reader / SIYI proxy not ready"
        return "FIFO write failed: " + str(e)

    return "Sent UniGCS control: " + command



# ENDPOINTS_SHARED_CONFIG_V1
def load_endpoints():
    defaults = [
        {"name":"Host 1","ip":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","video":True,"mavlink":True},
        {"name":"Host 2","ip":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","video":True,"mavlink":True},
    ]
    try:
        if os.path.exists(ENDPOINTS_FILE):
            data=json.loads(read_file(ENDPOINTS_FILE))
            if isinstance(data,list) and data:
                return data
    except Exception:
        pass
    return defaults

def save_endpoints_from_params(data):
    names=data.get("name",[])
    ips=data.get("ip",[])
    delete_on=set(data.get("delete_host",[]))
    endpoints=[]
    for i,ip in enumerate(ips):
        if str(i) in delete_on:
            continue
        ip=(ip or "").strip()
        if not ip:
            continue
        name=(names[i].strip() if i < len(names) and names[i].strip() else f"Host {i+1}")
        endpoints.append({
            "name": name,
            "ip": ip,
            "video": False,
            "mavlink": True,
        })
    if not endpoints:
        try:
            existing = load_endpoints()
            if existing:
                endpoints = existing
        except Exception:
            pass

    if not endpoints:
        endpoints=[
            {"name":"Host 1","ip":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"","video":True,"mavlink":True},
            {"name":"Host 2","ip":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"","video":True,"mavlink":True},
        ]
    write_file(ENDPOINTS_FILE, json.dumps(endpoints, indent=2))
    apply_siyi_endpoints_now()
    apply_siyi_endpoints_now()


def host_ping_status(ip):
    if not ip:
        return ("bad", "No IP")

    out=sh(f"ping -c 1 -W 1 {ip} 2>/dev/null || true")

    if "1 received" in out or "1 packets received" in out:
        m=re.search(r"time=([0-9.]+)", out)
        return ("ok", "OK" + (f" {m.group(1)} ms" if m else ""))

    return ("bad", "No ping")

def host_mavlink_status(ip):
    if not ip:
        return ("bad", "No IP")

    conf=read_file(MAVCONF)
    configured=(ip in conf)

    if not configured:
        return ("bad", "Not configured")

    # Real MAVLink activity is tracked by background tcpdump monitor.
    # UI should not run tcpdump during page rendering.
    try:
        data=json.loads(read_file("/tmp/siyi_mavlink_host_activity.json") or "{}")
        item=data.get(ip,{})
        last=float(item.get("last_seen",0))
        age=time.time()-last
        if last > 0 and age < 15:
            return ("ok", "ACTIVE")
        if last > 0:
            return ("warn", "STALE")
    except Exception:
        pass

    return ("warn", "Configured, waiting to send packets")
def host_video_status(ip):
    if not ip:
        return ("bad", "No IP")

    # Current architecture: QGC pulls RTSP from MediaMTX on :8554.
    # A host is video-active if it has an established TCP session to local :8554
    # or recent MediaMTX logs show that host reading main.264.
    ss_out=sh("ss -tunap 2>/dev/null | grep ':8554' || true")
    logs=sh("journalctl -u mediamtx.service -n 160 --no-pager 2>/dev/null || true")

    active_tcp=(ip in ss_out and ":8554" in ss_out and "ESTAB" in ss_out)
    active_log=(ip in logs and ("is reading from path" in logs or "session" in logs))

    if active_tcp:
        return ("ok", "ACTIVE")

    if active_log:
        return ("warn", "RECENT")

    mediamtx=sh("systemctl is-active mediamtx.service 2>/dev/null || true").strip()
    if mediamtx=="active":
        return ("warn", "NO CLIENT")

    return ("bad", "OFFLINE")


def host_qgc_status(ip):
    if not ip:
        return ("bad", "No IP")

    ss_out=sh("ss -tunap 2>/dev/null || true")
    medialog=sh("journalctl -u mediamtx.service -n 180 --no-pager 2>/dev/null || true")

    # Strong QGC confirmation signals:
    # 1) Host has active RTSP TCP session to MediaMTX :8554.
    # 2) Host has REC/control TCP session to :37256.
    # 3) Recent MediaMTX log from host reading stream.
    active_rtsp=(ip in ss_out and ":8554" in ss_out and "ESTAB" in ss_out)
    active_control=(ip in ss_out and ":37256" in ss_out and "ESTAB" in ss_out)
    recent_rtsp=(ip in medialog and ("is reading from path" in medialog or "created by" in medialog))

    if active_rtsp and active_control:
        return ("ok", "VIDEO + CTRL")

    if active_rtsp:
        return ("ok", "VIDEO")

    if active_control:
        return ("ok", "CTRL")

    if recent_rtsp:
        return ("warn", "RECENT")

    return ("warn", "NOT CONFIRMED")


def host_operational_table():
    eps=load_endpoints()

    if not eps:
        return "<p class='small'>No endpoint hosts configured.</p>"

    rows=""

    for e in eps:
        name=e.get("name","")
        ip=e.get("ip","")

        ping_cls,ping_txt=host_ping_status(ip)

        if e.get("mavlink",True):
            mav_cls,mav_txt=host_mavlink_status(ip)
        else:
            mav_cls,mav_txt=("warn","Disabled")

        vid_cls,vid_txt=host_video_status(ip)
        qgc_cls,qgc_txt=host_qgc_status(ip)

        rows += f"""
        <tr>
          <td><b>{esc(name)}</b><br><span class='small'>{esc(ip)}</span></td>
          <td><span class='status-pill {ping_cls}'>{esc(ping_txt)}</span></td>
          <td><span class='status-pill {mav_cls}'>{esc(mav_txt)}</span></td>
          <td><span class='status-pill {vid_cls}'>{esc(vid_txt)}</span></td>
          <td><span class='status-pill {qgc_cls}'>{esc(qgc_txt)}</span></td>
        </tr>
        """

    return f"""
    <style>
    .hoststatus table {{
      width:100%;
      table-layout:auto;
    }}

    .hoststatus td,
    .hoststatus th {{
      vertical-align:middle;
      white-space:nowrap;
    }}

    .hoststatus .status-pill {{
      display:inline-block;
      padding:5px 10px;
      border-radius:999px;
      font-size:12px;
      font-weight:700;
      line-height:1.0;
      white-space:nowrap;
    }}

    .hoststatus th:nth-child(2),
    .hoststatus td:nth-child(2),
    .hoststatus th:nth-child(3),
    .hoststatus td:nth-child(3),
    .hoststatus th:nth-child(4),
    .hoststatus td:nth-child(4) {{
      width:120px;
    }}

    .hoststatus th:nth-child(5),
    .hoststatus td:nth-child(5) {{
      width:150px;
    }}
    </style>

    <div class='hoststatus'>
    <table>
      <tr>
        <th>Host</th>
        <th>Network</th>
        <th>MAVLink</th>
        <th>Video</th>
        <th>QGC</th>
      </tr>
      {rows}
    </table>

    <p class='small'>
    Network = ICMP ping reachability only.<br>
    MAVLink sent = Pi has recently sent UDP telemetry packets to this host on port 14550.<br>
    Video = active/recent RTSP client session from this host via MediaMTX.<br>
    QGC = confirmed only by host-side RTSP/control activity back to the Pi.
    </p></div>
    """


def endpoints_summary(kind):
    eps=load_endpoints()
    rows=""
    for e in eps:
        enabled=e.get(kind,False)
        rows+=f"<tr><td>{esc(e.get('name',''))}</td><td>{esc(e.get('ip',''))}</td><td>{'Yes' if enabled else 'No'}</td></tr>"
    return f"<table><tr><th>Host</th><th>IP</th><th>{kind.capitalize()}</th></tr>{rows}</table><p class='small'>Edit hosts on the Endpoints page.</p>"

def endpoints_page():
    eps=load_endpoints()
    rows=""
    for i,e in enumerate(eps):
        rows+=f"""
        <tr>
          <td><input style='pointer-events:auto;' name='name' value='{esc(e.get("name",f"Host {i+1}"))}'></td>
          <td><input style='pointer-events:auto;' name='ip' value='{esc(e.get("ip",""))}'></td>
          <td style='text-align:center'><input style='pointer-events:auto;width:auto;' type='checkbox' name='delete_host' value='{i}'></td>
        </tr>"""
    rows += """
        <tr>
          <td><input style='pointer-events:auto;' name='name' placeholder='Host 3'></td>
          <td><input style='pointer-events:auto;' name='ip' placeholder='192.168.191.xxx'></td>
          <td></td>
        </tr>"""
    return f"""<h1>MAVLink Hosts</h1>

    <div class='card'>
    <h2>Host Operational Status</h2>
    {host_operational_table()}
    </div>

    <div class='card'>
    <p class='small'>Saved hosts are automatically used as MAVLink destinations.</p>

    <form method='post' action='/save_endpoints'>
    <table><tr><th>Name</th><th>IP</th><th>Delete</th></tr>{rows}</table>
    <button style='pointer-events:auto;'>Save endpoints</button>
    </form>
    </div>"""

def make_video_service_from_endpoints(rtsp, protocols, latency, port):
    eps=[e for e in load_endpoints() if e.get("video",False) and e.get("ip")]
    if not eps:
        eps=[{"ip":""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+""},{"ip":""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+""}]
    branches=" ".join([f"t. ! queue ! udpsink host={e['ip']} port={port}" for e in eps])
    return f"""[Unit]
Description=SIYI RTSP to UDP forwarder
After=network-online.target zerotier-one.service NetworkManager.service
Wants=network-online.target zerotier-one.service

[Service]
Type=simple
Restart=always
RestartSec=3
ExecStart=/usr/bin/gst-launch-1.0 -e rtspsrc location={rtsp} latency={latency} protocols={protocols} ! rtph265depay ! h265parse ! rtph265pay config-interval=1 pt=96 ! tee name=t {branches}
ExecStop=/usr/bin/pkill -f "gst-launch-1.0"
TimeoutStopSec=5

[Install]
WantedBy=multi-user.target
"""

def make_mav_conf_from_endpoints(device, baud, port, tcp):
    eps=[e for e in load_endpoints() if e.get("ip")]

    lines=[f"""[UartEndpoint fc]
Device={device}
Baud={baud}

[UdpEndpoint webui_status_monitor]
Mode=Normal
Address=127.0.0.1
Port=14601

[UdpEndpoint button_safety]
Mode=Normal
Address=127.0.0.1
Port=14600
"""]

    for i,e in enumerate(eps,1):
        lines.append(f"""
[UdpEndpoint host{i}]
Mode=Normal
Address={e['ip']}
Port={port}
""")

    lines.append(f"""
[TcpEndpoint server]
Mode=Server
Address=0.0.0.0
Port={tcp}
""")

    return "".join(lines)

# ENDPOINTS_SHARED_CONFIG_V1_END



def apply_siyi_endpoints_now():
    try:
        subprocess.run(["/home/pi/apply_siyi_endpoints.sh"], timeout=10, check=False)
    except Exception as e:
        print("apply_siyi_endpoints failed:", e)

class H(BaseHTTPRequestHandler):

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        data = self.rfile.read(length).decode()
        params = dict(parse_qsl(data))

        if self.path == "/unigcs_control":
            cmd = params.get("cmd", "")
            send_unigcs_fifo(cmd)
            self.send_response(303)
            self.send_header("Location", "/camera_controls")
            self.end_headers()
            return

    def do_GET(self):

        if self.path.startswith("/static/"):
            path = "/home/pi/siyi-webui" + self.path

            if not os.path.isfile(path):
                self.send_error(404)
                return

            ctype = "application/octet-stream"

            if path.endswith(".png"):
                ctype = "image/png"
            elif path.endswith(".jpg") or path.endswith(".jpeg"):
                ctype = "image/jpeg"

            with open(path, "rb") as f:
                data = f.read()

            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/camera_sd_meta"):
            qs = dict(parse_qsl(urlparse(self.path).query))
            url = qs.get("url", "")
            size, mod = camera_sd_head(url, timeout=3)
            data = json.dumps({"size": human_size(size), "date": mod if mod else "-"}).encode()
            self.send_response(200)
            self.send_header("Content-Type","application/json")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/camera_sd_res"):
            qs = dict(parse_qsl(urlparse(self.path).query))
            url = qs.get("url","")
            res = ""
            try:
                if url:
                    res = probe_resolution(url)
            except:
                res = ""
            data = json.dumps({"res": res}).encode()
            self.send_response(200)
            self.send_header("Content-Type","application/json")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/camera_sd_stream"):
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            url = q.get("url", [""])[0]

            if not url.startswith(CAM_SD_BASE + "/mp4/"):
                self.send_error(400, "Invalid camera SD URL")
                return

            try:
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=20) as r:
                    self.send_response(200)
                    self.send_header("Content-Type", "video/mp4")
                    self.send_header("Content-Disposition", "inline")
                    self.end_headers()
                    shutil.copyfileobj(r, self.wfile, length=1024*1024)
                return
            except Exception as e:
                self.send_error(502, "Camera SD stream failed: " + str(e))
                return

        if self.path in ("/camera_controls", "/unigcs_controls"):
            body = page("Camera Controls", unigcs_controls_page())
            self.send_response(200)
            self.send_header("Content-Type","text/html")
            self.end_headers()
            self.wfile.write(body.encode())
            return

        if self.path.startswith("/camera_sd_download"):
            qs=dict(parse_qsl(urlparse(self.path).query))
            url=qs.get("url","")
            if not url.startswith(CAM_SD_BASE + "/mp4/"):
                self.send_error(400, "Invalid camera SD URL"); return
            filename=os.path.basename(urlparse(url).path) or "camera_file.mp4"
            try:
                with urllib.request.urlopen(url, timeout=10) as r:
                    data=r.read()
                self.send_response(200)
                self.send_header("Content-Type","video/mp4")
                self.send_header("Content-Disposition",f'attachment; filename="{filename}"')
                self.send_header("Content-Length",str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            except Exception as e:
                self.send_error(502, str(e))
            return

        if self.path.startswith("/status_bar"):
            out = sh("/usr/bin/python3 /home/pi/siyi-webui/status_probe.py")
            data = out.encode()
            self.send_response(200)
            self.send_header("Content-Type","text/html; charset=utf-8")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/health"):
            data = b"OK"
            self.send_response(200)
            self.send_header("Content-Type","text/plain")
            self.send_header("Cache-Control","no-store")
            self.send_header("Content-Length",str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path=="/first_setup":
            body=first_setup_page()

        elif self.path=="/":
            if setup_should_force():
                self.send_response(303)
                self.send_header("Location","/first_setup")
                self.end_headers()
                return

            body=f"""
            <h1>Operations</h1>

            <div class='card'>
              <h2>Operations</h2>
              <p class='small'>Use these controls to restart the main operational areas shown in the top status bar.</p>

              <table>
                <tr><th>System</th><th>Purpose</th><th>Action</th></tr>

                <tr>
                  <td><b>MAVLink</b></td>
                  <td class='small'>Telemetry routing to configured hosts.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='mavlink-router'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart MAVLink</button></form></td>
                </tr>

                <tr>
                  <td><b>Video</b></td>
                  <td class='small'>RTSP relay / MediaMTX video service.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='mediamtx'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart Video</button></form></td>
                </tr>

                

                <tr>
                  <td><b>ZT</b></td>
                  <td class='small'>ZeroTier overlay network.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='zerotier-one'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart ZT</button></form></td>
                </tr>

                <tr>
                  <td><b>Buttons</b></td>
                  <td class='small'>MAVLink button bridge.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='siyi-button-bridge'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart Buttons</button></form></td>
                </tr>

                <tr>
                  <td><b>WebUI</b></td>
                  <td class='small'>This control interface.</td>
                  <td><form method='post' action='/restart'><input type='hidden' name='service' value='siyi-webui'><button style='pointer-events:auto;min-width:160px;text-align:center;'>Restart WebUI</button></form></td>
                </tr>
              </table>
            </div>
            """

        elif self.path=="/buttons":
            rows=read_button_rows()
            tr=""
            for i,r in enumerate(rows):
                b=esc(r.get("Button",""))
                tr+=f"<tr><td>{b}<input style='pointer-events:auto;' type='hidden' name='Button_{i}' value='{b}'></td>"
                for col in ["Tap","Hold","ReleaseAfterTap","ReleaseAfterHold","DoubleTap"]:
                    cell = action_select(col+'_'+str(i), r.get(col,''))
                    if col in ["ReleaseAfterTap","DoubleTap"]:
                        cell = cell.replace("<select", "<select disabled style='opacity:.45;pointer-events:none;'")
                    tr+=f"<td>{cell}</td>"
                tr+="</tr>"
            body="""
            <h1>Button Control System</h1>
            <div class='card'>
            <p>Configure gamepad button actions for the SIYI control system.</p>
            </div>

            <div id='gamepadFloat' class='card' style='position:fixed;right:24px;top:82px;width:420px;min-width:260px;max-width:80vw;max-height:85vh;overflow:auto;z-index:20;box-shadow:0 12px 30px rgba(0,0,0,.35);'>
            <h2 id='gamepadDragHandle' style='cursor:move;margin-top:0;'>Standard Gamepad Layout (Reference)</h2>
            <div style='text-align:left;'>
            <img src='/static/gamepad_reference.png'
                 style='max-width:100%;width:100%;border-radius:12px;'>
            </div>
            <p class='small' style='margin-bottom:0;'>Drag this panel by the title bar.</p>

            <div id='gamepadResizeHandle'
                 style='position:absolute;left:0;bottom:0;width:26px;height:26px;cursor:nesw-resize;'>
            </div>

            </div>

            <script>
            (function(){
              const box=document.getElementById('gamepadFloat');
              const handle=document.getElementById('gamepadDragHandle');
              if(!box||!handle) return;

              let dragging=false;
              let startX=0,startY=0,startLeft=0,startTop=0;

              handle.addEventListener('mousedown', function(e){
                dragging=true;

                const r=box.getBoundingClientRect();

                startX=e.clientX;
                startY=e.clientY;
                startLeft=r.left;
                startTop=r.top;

                document.body.style.userSelect='none';

                e.preventDefault();
              });

              window.addEventListener('mousemove', function(e){
                if(!dragging) return;

                let left=startLeft + (e.clientX-startX);
                let top=startTop + (e.clientY-startY);

                const maxLeft=window.innerWidth-box.offsetWidth-8;
                const maxTop=window.innerHeight-box.offsetHeight-8;

                left=Math.max(8,Math.min(left,maxLeft));
                top=Math.max(58,Math.min(top,maxTop));

                box.style.left=left+'px';
                box.style.top=top+'px';
                box.style.right='auto';
              });

              const resize=document.getElementById('gamepadResizeHandle');

              let resizing=false;
              let startWidth=0;

              resize.addEventListener('mousedown', function(e){
                resizing=true;

                startX=e.clientX;
                startWidth=box.offsetWidth;

                document.body.style.userSelect='none';

                e.preventDefault();
                e.stopPropagation();
              });

              window.addEventListener('mousemove', function(e){

                if(resizing){

                  let newWidth=startWidth - (e.clientX-startX);

                  newWidth=Math.max(260, Math.min(newWidth, window.innerWidth*0.8));

                  box.style.width=newWidth+'px';

                  return;
                }

              });

              window.addEventListener('mouseup', function(){
                dragging=false;
                resizing=false;
                document.body.style.userSelect='';
              });
            })();
            </script>
            """

            body += f"<div class='card'><form method='post' action='/save_buttons'><input style='pointer-events:auto;' type='hidden' name='count' value='{len(rows)}'><table><tr><th>Button</th><th>Tap</th><th>Hold</th><th>ReleaseAfterTap<br><span style='font-size:11px;font-style:italic;color:#9ca3af;'>(currently unsupported)</span></th><th>ReleaseAfterHold</th><th>DoubleTap<br><span style='font-size:11px;font-style:italic;color:#9ca3af;'>(currently unsupported)</span></th></tr>{tr}</table><button style='pointer-events:auto;'>Save button map + restart bridge</button></form></div>"

            body += """
            <div class='card'>
            <h2>Disable Button Controls</h2>
            <p class='small'>Stops the runtime button bridge without affecting MAVLink or video.</p>
            <form method='post' action='/stop_bridge'>
            <button style='pointer-events:auto;' class='danger'>Disable Bridge</button>
            </form>
            </div>
            """


        elif self.path=="/video":
            v=get_video_values()
            body=f"""<h1>Video Settings</h1>
            <div class='card'><h2>Video Pipeline</h2><form method='post' action='/save_video'><div class='grid'>
            <div><label>RTSP URL</label><input style='pointer-events:auto;' name='rtsp' value='{esc(v["rtsp"])}'></div>
            <div><label>RTSP protocol</label><select style='pointer-events:auto;' name='protocols'><option {'selected' if v["protocols"]=='tcp' else ''}>tcp</option><option {'selected' if v["protocols"]=='udp' else ''}>udp</option></select></div>
            <div><label>Latency</label><input style='pointer-events:auto;' name='latency' value='{esc(v["latency"])}'></div>
            <div><label>UDP Port</label><input style='pointer-events:auto;' name='port' value='{esc(v["port"])}'></div>
            </div><button style='pointer-events:auto;'>Save video service + restart video</button></form></div>
            <div class='card'><h2>Video troubleshooting</h2><p>If video does not stream, toggle ZeroTier network off/on in host ZeroTier client.</p></div>
            <div class='card'>
              <h2>Live Preview</h2>
              <p class='small'>On-demand browser preview using MediaMTX WebRTC. This does not replace or modify the QGC video stream.</p>
              <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:10px;">
                <button type="button" style="pointer-events:auto;" onclick="startVideoPreview()">Start Preview</button>
                <button type="button" style="pointer-events:auto;" onclick="stopVideoPreview()">Stop Preview</button>
                <span id="videoPreviewStatus" class="pill warn">PREVIEW OFF</span>
              </div>
              <div id="videoPreviewBox" style="display:none;border:1px solid #ddd;border-radius:10px;overflow:hidden;background:#111;">
                <iframe id="videoPreviewFrame" style="width:100%;height:360px;border:0;background:#111;" allow="autoplay; fullscreen"></iframe>
              </div>
              <script>
              function startVideoPreview(){{
                const host = window.location.hostname;
                const url = "http://" + host + ":8889/main.264/";
                document.getElementById("videoPreviewFrame").src = url;
                document.getElementById("videoPreviewBox").style.display = "block";
                const st = document.getElementById("videoPreviewStatus");
                st.textContent = "PREVIEW ON";
                st.className = "pill ok";
              }}
              function stopVideoPreview(){{
                document.getElementById("videoPreviewFrame").src = "about:blank";
                document.getElementById("videoPreviewBox").style.display = "none";
                const st = document.getElementById("videoPreviewStatus");
                st.textContent = "PREVIEW OFF";
                st.className = "pill warn";
              }}
              window.addEventListener("beforeunload", stopVideoPreview);
              document.addEventListener("visibilitychange", function(){{
                if (document.hidden) {{
                  stopVideoPreview();
                }}
              }});
              </script>
            </div>
            <div class='card'><h2>Advanced: Current Service File</h2><details><summary>Show service file</summary><pre>{esc(read_file(VIDEO_SERVICE))}</pre></details></div>"""

        elif self.path=="/mavlink":
            m=get_mav_values()
            body=f"""<h1>MAVLink Settings</h1>
            <div class='card'><h2>Telemetry Routing</h2><form method='post' action='/save_mavlink_form'><div class='grid'>
            <div><label>Serial device</label><input style='pointer-events:auto;' name='device' value='{esc(m["device"])}'></div>
            <div><label>Baud</label><input style='pointer-events:auto;' name='baud' value='{esc(m["baud"])}'></div>
            <div><label>UDP MAVLink port</label><input style='pointer-events:auto;' name='port' value='{esc(m["port"])}'></div>
            <div><label>TCP server port</label><input style='pointer-events:auto;' name='tcp' value='{esc(m["tcp"])}'></div>
            </div><button style='pointer-events:auto;'>Save MAVLink config + restart mavlink-router</button></form></div>
            <div class='card'><h2>MAVLink Destination Hosts</h2>{endpoints_summary("mavlink")}<a href='/endpoints'><button style='pointer-events:auto;'>Edit endpoints</button></a></div>"""

        elif self.path=="/endpoints":
            body=endpoints_page()

        elif self.path=="/wifi":
            msg=esc(sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true"))
            body=f"""<h1>WiFi</h1>
            <div class='card'>{wifi_profiles_cards()}</div>
            <div class='card'><h2>Add / Replace Saved Wi-Fi SSID</h2><p class='small'>Saves profile without forcing reconnect.</p>
            <form method='post' action='/wifi_add'><div class='grid'><div><label>SSID</label><input style='pointer-events:auto;' name='ssid'></div><div><label>Password</label><input id='wifi_add_password' style='pointer-events:auto;' name='password' type='password'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="this.closest('div').querySelector('input[name=password]').type=this.checked?'text':'password'"> Show password</label></div><div><label>Priority</label><input style='pointer-events:auto;' name='priority' value='10'></div><div><label>Autoconnect</label><select style='pointer-events:auto;' name='autoconnect'><option selected>yes</option><option>no</option></select></div></div><button style='pointer-events:auto;'>Save Wi-Fi profile only</button></form></div>"""

        elif self.path=="/zerotier":
            msg=esc(sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true"))
            body=f"""<h1>ZeroTier</h1>
            <div class='card'>
            {zt_status_html()}
            <form method='post' action='/zt_save_config'>
              <div class='grid'>
                <div><label>ZeroTier Network ID</label><input style='pointer-events:auto;' name='nwid' value='{esc(zt_network_id_current())}' placeholder='ZeroTier network ID'></div>
                <div><label>ZeroTier API Token</label><input id='zt_token_field' style='pointer-events:auto;' name='token' type='password' value='{esc(zt_read_token())}' placeholder='Paste token to save/update'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="document.getElementById('zt_token_field').type=this.checked?'text':'password'"> Show token</label></div>
              </div>
              <button style='pointer-events:auto;'>Save ZeroTier config</button>
            </form>
            <p class='small'>Saving ZeroTier config also runs setup: join network, authorize/name this Pi, and update camera managed route 192.168.144.0/24 via this Pi.</p>
            </div>"""

        elif self.path=="/network":
            msg=esc(sh("cat /tmp/siyi_webui_last_action 2>/dev/null || true"))
            body=f"""<h1>Network</h1>
            <div class='card'>{wifi_profiles_cards()}</div>
            <div class='card'><h2>Add / Replace Saved Wi-Fi SSID</h2><p class='small'>Saves profile without forcing reconnect.</p>
            <form method='post' action='/wifi_add'><div class='grid'><div><label>SSID</label><input style='pointer-events:auto;' name='ssid'></div><div><label>Password</label><input id='wifi_add_password' style='pointer-events:auto;' name='password' type='password'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="this.closest('div').querySelector('input[name=password]').type=this.checked?'text':'password'"> Show password</label></div><div><label>Priority</label><input style='pointer-events:auto;' name='priority' value='10'></div><div><label>Autoconnect</label><select style='pointer-events:auto;' name='autoconnect'><option selected>yes</option><option>no</option></select></div></div><button style='pointer-events:auto;'>Save Wi-Fi profile only</button></form></div>
            <div class='card'><h2>ZeroTier</h2>
            {zt_status_html()}
            <form method='post' action='/zt_save_config'>
              <div class='grid'>
                <div><label>ZeroTier Network ID</label><input style='pointer-events:auto;' name='nwid' value='{esc(zt_network_id_current())}' placeholder='ZeroTier network ID'></div>
                <div><label>ZeroTier API Token</label><input id='zt_token_field' style='pointer-events:auto;' name='token' type='password' value='{esc(zt_read_token())}' placeholder='Paste token to save/update'><label class='small' style='display:block;margin-top:6px;'><input style='pointer-events:auto;width:auto;' type='checkbox' onclick="document.getElementById('zt_token_field').type=this.checked?'text':'password'"> Show token</label></div>
              </div>
              <button style='pointer-events:auto;'>Save ZeroTier config</button>
            </form>
            <p class='small'>Saving ZeroTier config also runs setup: join network, authorize/name this Pi, and update camera managed route 192.168.144.0/24 via this Pi.</p>
            </div>"""

        elif self.path=="/camera_sd":
            body=camera_sd_page()

        elif self.path=="/logs":
            body="<h1>Logs</h1>"
            for s in SERVICES:
                body+=f"<div class='card'><h2>{s}</h2><pre>{esc(sh(f'journalctl -u {s} -n 80 --no-pager -l'))}</pre></div>"

        elif self.path=="/safety":
            body="<h1>Safety / Failsafe</h1><div class='card'><p>The Web UI edits configuration files and restarts services.</p><p>The button bridge remains the runtime executor.</p><p>ArduPlane / FC failsafe remains independent from this UI.</p><form method='post' action='/stop_bridge'><button style='pointer-events:auto;' class='danger'>Disable Button Bridge</button></form></div>"

        else:
            self.send_error(404); return

        if self.path != "/first_setup":
            body = setup_banner() + body

        data=page("SIYI Pi Control Center",body).encode()
        self.send_response(200)
        self.send_header("Content-Type","text/html; charset=utf-8")
        self.send_header("Content-Length",str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        if self.path == "/unigcs_control":
            length = int(self.headers.get("Content-Length", "0"))
            data = self.rfile.read(length).decode(errors="ignore")
            q = dict(parse_qsl(data))

            cmd = ""

            if "cmd" in q:
                cmd = q.get("cmd", "")
            elif "brightness" in q:
                cmd = "brightness:" + q.get("brightness", "50")
            elif "saturation" in q:
                cmd = "saturation:" + q.get("saturation", "60")
            elif "contrast" in q:
                cmd = "contrast:" + q.get("contrast", "50")
            elif "ev" in q:
                cmd = "ev:" + q.get("ev", "0")
            elif "ss" in q:
                cmd = "ss:" + q.get("ss", "0")

            try:
                out = send_unigcs_fifo(cmd)
            except Exception as e:
                out = "UniGCS control failed: " + str(e)

            try:
                open("/tmp/siyi_webui_last_action", "w").write(out)
            except Exception:
                pass

            self.send_response(303)
            self.send_header("Location", "/camera_controls")
            self.end_headers()
            return

        length=int(self.headers.get("Content-Length",0))
        data=parse_qs(self.rfile.read(length).decode())


        if self.path=="/first_setup_skip":
            open(SETUP_SKIP_FILE,"w").write("skip\n")

        elif self.path=="/first_setup_save":

            nwid=data.get("nwid",[""])[0].strip()
            token=data.get("token",[""])[0].strip()

            if nwid:
                cfg=zt_read_config()
                cfg["network_id"]=nwid
                zt_save_config(cfg)

            if token:
                zt_save_token(token)

            save_endpoints_from_params(data)

            ssid=data.get("ssid",[""])[0].strip()
            password=data.get("password",[""])[0]

            if ssid:
                sh(f"nmcli connection add type wifi ifname wlan0 con-name webui-wifi-{ssid.replace(' ','_')} ssid {shlex.quote(ssid)} 2>/dev/null || true")
                con_name = "webui-wifi-" + ssid.replace(" ","_")
                sh(f"nmcli connection modify {shlex.quote(con_name)} wifi-sec.key-mgmt wpa-psk wifi-sec.psk {shlex.quote(password)} 2>/dev/null || true")
                wifi_pw_set(con_name, password)

            out=zt_full_setup()

            if setup_config_is_valid():
                os.makedirs("/etc/siyi",exist_ok=True)
                open(SETUP_COMPLETE_FILE,"w").write(json.dumps({"complete":True},indent=2))
                if os.path.exists(SETUP_SKIP_FILE):
                    os.remove(SETUP_SKIP_FILE)

            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/restart":
            s=data.get("service",[""])[0]
            if s == "mavlink-router":
                sh("systemctl stop mavlink-router")
                time.sleep(5)
                sh("systemctl start mavlink-router")
                time.sleep(2)
                sh("systemctl restart siyi-button-bridge")
            elif s == "zerotier-one":
                sh("systemctl stop zerotier-one")
                time.sleep(5)
                sh("systemctl start zerotier-one")
                time.sleep(3)

                sh("systemctl stop mavlink-router")
                time.sleep(5)
                sh("systemctl start mavlink-router")
                time.sleep(2)
                sh("systemctl restart siyi-button-bridge")

            elif s == "siyi-webui":
                sh("systemd-run --unit=siyi-webui-delayed-restart --on-active=2 /bin/systemctl restart siyi-webui 2>/dev/null || true")
            elif s in SERVICES:
                sh(f"systemctl restart {s}")

        elif self.path=="/save_buttons":
            backup(BUTTON_MAP)
            count=int(data.get("count",["0"])[0])
            with open(BUTTON_MAP,"w",encoding="utf-8",newline="") as f:
                w=csv.writer(f,delimiter=";")
                w.writerow(["Button","Tap","Hold","ReleaseAfterTap","ReleaseAfterHold","DoubleTap","Notes"])
                for i in range(count):
                    w.writerow([data.get(f"Button_{i}",[""])[0],data.get(f"Tap_{i}",["NO_ACTION"])[0],data.get(f"Hold_{i}",["NO_ACTION"])[0],data.get(f"ReleaseAfterTap_{i}",["NO_ACTION"])[0],data.get(f"ReleaseAfterHold_{i}",["NO_ACTION"])[0],data.get(f"DoubleTap_{i}",["NO_ACTION"])[0],data.get(f"Notes_{i}",[""])[0]])
            sh("systemctl restart siyi-button-bridge")

        elif self.path=="/save_endpoints":
            save_endpoints_from_params(data)

        elif self.path=="/save_video":
            write_file(VIDEO_SERVICE, make_video_service_from_endpoints(data.get("rtsp",[""])[0],data.get("protocols",["tcp"])[0],data.get("latency",["0"])[0],data.get("port",["5600"])[0]))
            sh("systemctl daemon-reload")
            sh("systemctl restart siyi-video-dual")

        elif self.path=="/save_mavlink_form":
            write_file(MAVCONF, make_mav_conf_from_endpoints(data.get("device",["/dev/ttyAMA0"])[0],data.get("baud",["57600"])[0],data.get("port",["14550"])[0],data.get("tcp",["5760"])[0]))
            sh("systemctl restart mavlink-router")

        elif self.path=="/wifi_add":
            ssid=data.get("ssid",[""])[0].strip()
            pw=data.get("password",[""])[0]
            prio=data.get("priority",["10"])[0].strip() or "10"
            ac=data.get("autoconnect",["yes"])[0].strip()
            if ssid and pw:
                safe="webui-wifi-" + ssid.replace(" ","_")
                out=[]
                out.append(sh(f"nmcli connection delete '{safe}' 2>/dev/null || true"))
                out.append(sh(f"nmcli connection add type wifi ifname wlan0 con-name '{safe}' ssid '{ssid}'"))
                out.append(sh(f"nmcli connection modify '{safe}' wifi-sec.key-mgmt wpa-psk wifi-sec.psk '{pw}'"))
                wifi_pw_set(safe, pw)
                out.append(sh(f"nmcli connection modify '{safe}' connection.autoconnect {ac} connection.autoconnect-priority {prio}"))
                out.append("Saved Wi-Fi profile without forcing reconnect: " + safe)
                open("/tmp/siyi_webui_last_action","w").write("\\n".join([x for x in out if x]))

        elif self.path=="/wifi_update":
            name=data.get("name",[""])[0]
            prio=data.get("priority",["0"])[0]
            ac=data.get("autoconnect",["yes"])[0]
            if name and not name.startswith("netplan-"):
                sh(f"nmcli connection modify '{name}' connection.autoconnect {ac}")
                sh(f"nmcli connection modify '{name}' connection.autoconnect-priority {prio}")
                open("/tmp/siyi_webui_last_action","w").write(f"Updated {name}: priority={prio}, autoconnect={ac}")

        elif self.path=="/wifi_switch":
            name=data.get("name",[""])[0]
            if name:
                out=sh(f"sudo nmcli connection up '{name}'")
                open("/tmp/siyi_webui_last_action","w").write(out or f"Switched to {name}")
                sh("systemd-run --unit=siyi-webui-delayed-restart --on-active=3 /bin/systemctl restart siyi-webui 2>/dev/null || true")

        elif self.path=="/wifi_update_password":
            name=data.get("name",[""])[0]
            pw=data.get("password",[""])[0]
            if name and pw:
                out=sh(f"nmcli connection modify '{name}' wifi-sec.psk '{pw}'")
                wifi_pw_set(name, pw)
                open("/tmp/siyi_webui_last_action","w").write(out or f"Updated Wi-Fi password for {name}")

        elif self.path=="/wifi_delete":
            name=data.get("name",[""])[0]
            if name and not name.startswith("netplan-"):
                out=sh(f"nmcli connection delete '{name}'")
                wifi_pw_delete(name)
                open("/tmp/siyi_webui_last_action","w").write(out or f"Deleted {name}")



        elif self.path=="/camera_sd_zip":
            urls=data.get("urls",[])
            urls=[u for u in urls if u.startswith(CAM_SD_BASE + "/mp4/")]
            if urls:
                tmp=tempfile.NamedTemporaryFile(delete=False,suffix=".zip")
                tmp.close()
                try:
                    with zipfile.ZipFile(tmp.name,"w",compression=zipfile.ZIP_STORED) as z:
                        for url in urls:
                            name=os.path.basename(urlparse(url).path) or "camera_file.mp4"
                            with urllib.request.urlopen(url, timeout=30) as r:
                                z.writestr(name, r.read())
                    with open(tmp.name,"rb") as f:
                        payload=f.read()
                    os.unlink(tmp.name)
                    self.send_response(200)
                    self.send_header("Content-Type","application/zip")
                    self.send_header("Content-Disposition",'attachment; filename="camera_sd_selected.zip"')
                    self.send_header("Content-Length",str(len(payload)))
                    self.end_headers()
                    self.wfile.write(payload)
                    return
                except Exception as e:
                    try:
                        os.unlink(tmp.name)
                    except Exception:
                        pass
                    self.send_error(502, str(e))
                    return


        elif self.path=="/camera_sd_delete_selected":
            urls=data.get("urls",[])
            urls=[u for u in urls if u.startswith(CAM_SD_BASE + "/mp4/")]
            if urls:
                out=camera_sd_delete_many(urls)
                open("/tmp/siyi_webui_last_action","w").write("Camera SD batch delete: " + out)

        elif self.path=="/camera_sd_delete":
            url=data.get("url",[""])[0]
            if url.startswith(CAM_SD_BASE + "/mp4/"):
                out=camera_sd_delete(url)
                open("/tmp/siyi_webui_last_action","w").write("Camera SD delete: " + out)

        elif self.path=="/zt_save_config":
            nwid=data.get("nwid",[""])[0].strip()
            token=data.get("token",[""])[0].strip()
            cfg=zt_read_config()
            if nwid:
                cfg["network_id"]=nwid
                zt_write_config(cfg)
            if token:
                zt_save_token(token)

            saved_msg="Saved ZeroTier config. Network ID=" + (nwid or cfg.get("network_id",""))
            if token:
                saved_msg += " API token=saved"
            else:
                saved_msg += " API token=unchanged"

            setup_msg=zt_full_setup()
            open("/tmp/siyi_webui_last_action","w").write(saved_msg + "\n\n" + setup_msg)

        elif self.path=="/zt_test_token":
            out=zt_test_token()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_authorize_pi":
            out=zt_authorize_this_pi()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_update_route":
            out=zt_update_camera_route()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_full_setup":
            out=zt_full_setup()
            open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/zt_join":
            nwid=data.get("nwid",[""])[0].strip() or zt_network_id_current()
            if nwid:
                cfg=zt_read_config()
                cfg["network_id"]=nwid
                zt_write_config(cfg)
                out=sh(f"zerotier-cli join {nwid}")
                open("/tmp/siyi_webui_last_action","w").write(out)

        elif self.path=="/stop_bridge":
            sh("systemctl stop siyi-button-bridge")

        loc="/"
        if self.path.startswith("/save_video"): loc="/video"
        elif self.path.startswith("/save_mavlink"): loc="/mavlink"
        elif self.path.startswith("/save_endpoints"): loc="/endpoints"
        elif self.path.startswith("/save_buttons"): loc="/buttons"
        elif self.path.startswith("/wifi") or self.path.startswith("/zt"):
            loc="/wifi" if self.path.startswith("/wifi") else "/zerotier"

        elif self.path == "/unigcs_control":
            length = int(self.headers.get("Content-Length", "0"))
            data = self.rfile.read(length).decode(errors="ignore")
            q = dict(parse_qsl(data))

            cmd = ""

            if "cmd" in q:
                cmd = q.get("cmd", "")
            elif "brightness" in q:
                cmd = "brightness:" + q.get("brightness", "50")
            elif "saturation" in q:
                cmd = "saturation:" + q.get("saturation", "60")
            elif "contrast" in q:
                cmd = "contrast:" + q.get("contrast", "50")
            elif "ev" in q:
                cmd = "ev:" + q.get("ev", "0")
            elif "ss" in q:
                cmd = "ss:" + q.get("ss", "0")

            try:
                out = send_unigcs_fifo(cmd)
            except Exception as e:
                out = "UniGCS control failed: " + str(e)

            try:
                open("/tmp/siyi_webui_last_action", "w").write(out)
            except Exception:
                pass

            self.send_response(303)
            self.send_header("Location", "/camera_controls")
            self.end_headers()
            return

        self.send_response(303)
        self.send_header("Location",loc)
        self.end_headers()


# REAL_HTTP_LOGS_PAGE_FIX_START
def _real_logs_cmd(cmd, timeout=6):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT, timeout=timeout)
    except Exception as e:
        return str(e)

def _log_level(line):
    low = line.lower()
    if any(x in low for x in ["error", "failed", "failure", "traceback", "exception", "critical", "panic"]):
        return "ERROR"
    if any(x in low for x in ["warning", "warn", "denied", "timeout", "unreachable"]):
        return "WARN"
    return "INFO"

def _log_category(line):
    low = line.lower()
    if "mavlink-router" in low or "mavlink" in low or "/dev/ttyama0" in low:
        return "MAVLINK"
    if "siyi-video" in low or "gstreamer" in low or "rtsp" in low or "udp" in low or "video" in low:
        return "VIDEO"
    if "siyi-button" in low or "siyi-rec" in low or "unigcs" in low or "camera" in low:
        return "SIYI"
    if "zerotier" in low or "wlan" in low or "network" in low:
        return "NETWORK"
    if "siyi-webui" in low or "python3" in low or "webui" in low or "get /" in low:
        return "WEBUI"
    return "SYSTEM"

def _noise(line):
    low = line.lower()
    noise_words = [
        "pipewire", "wireplumber", "xdg-desktop", "rtkit", "bluez",
        "bcm2835", "vc_sm_cma", "alsa", "portal", "upower",
        "pam_unix(sudo:session): session opened",
        "pam_unix(sudo:session): session closed",
        "command=/usr/sbin/zerotier-cli info",
        "get /status_bar", "get /health", "get /api/logs",
    ]
    return any(w in low for w in noise_words)

def _simplify(line):
    raw = line.strip()
    msg = raw

    # Remove noisy syslog prefix as much as possible
    m = re.match(r"^([A-Z][a-z]{2}\s+\d+\s+\d\d:\d\d:\d\d)\s+\S+\s+(.*)$", raw)
    ts = ""
    if m:
        ts = m.group(1)
        msg = m.group(2)

    msg = re.sub(r"^\S+\[\d+\]:\s*", "", msg)
    msg = msg.replace('"GET ', "GET ").replace(' HTTP/1.1" 200 -', "")

    low = msg.lower()

    if "opened uart" in low and "/dev/ttyama0" in low:
        msg = "FC serial opened: /dev/ttyAMA0"
    elif "uart" in low and "speed = 57600" in low:
        msg = "FC serial speed: 57600"
    elif "opened udp client" in low and ""+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+"" in low:
        msg = "MAVLink endpoint opened: Mac "+(QGC_HOSTS[1] if len(QGC_HOSTS)>1 else "")+":14550"
    elif "opened udp client" in low and ""+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+"" in low:
        msg = "MAVLink endpoint opened: Android "+(QGC_HOSTS[0] if len(QGC_HOSTS)>0 else "")+":14550"
    elif "started mavlink-router" in low:
        msg = "MAVLink Router started"
    elif "started siyi-webui" in low:
        msg = "Web UI service started"
    elif "get /logs" in low:
        msg = "Logs page opened"
    elif "get /camera_controls" in low:
        msg = "Camera Controls page opened"
    elif "get /safety" in low:
        msg = "Safety page opened"
    elif "permissions for /lib/netplan" in low:
        msg = "Netplan file permissions are too open"
    elif "registration to specific type not supported" in low:
        msg = "WiFi driver capability warning"
    elif "bgscan simple" in low:
        msg = "WiFi background scan warning"

    return ts, msg

def _real_logs_events(mode="important"):
    raw = _real_logs_cmd("journalctl --since '6 hours ago' --no-pager -n 1200")
    events = []

    for line in raw.splitlines():
        if not line.strip():
            continue
        if _noise(line):
            continue

        cat = _log_category(line)
        lvl = _log_level(line)
        ts, msg = _simplify(line)

        keep = False
        if mode == "full":
            keep = True
        elif mode == "important":
            keep = (
                lvl in ("ERROR", "WARN")
                or cat in ("MAVLINK", "VIDEO", "SIYI", "NETWORK")
                or "started" in msg.lower()
                or "opened" in msg.lower()
            )
        else:
            keep = (cat.lower() == mode.lower())

        if keep:
            events.append((ts, lvl, cat, msg))

    # Newest first. journalctl is chronological, so reverse after filtering.
    events = list(reversed(events))[:250]

    if not events:
        return "No important events found. This usually means the system is quiet/healthy."

    lines = []
    for ts, lvl, cat, msg in events:
        lines.append(f"{ts:<15}  {lvl:<5}  {cat:<8}  {msg}")
    return "\n".join(lines)

def _real_logs_text(mode="important"):
    return _real_logs_events(mode)

def _send_bytes(self, data, ctype="text/html; charset=utf-8"):
    if isinstance(data, str):
        data = data.encode("utf-8", "replace")
    self.send_response(200)
    self.send_header("Content-Type", ctype)
    self.send_header("Cache-Control", "no-store")
    self.send_header("Content-Length", str(len(data)))
    self.end_headers()
    self.wfile.write(data)

def _real_logs_page():
    return f"""<style>
.logbar{{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px;align-items:center}}
.logbtn{{background:#253244;color:#e8eef5;border:1px solid #3c4b5f;border-radius:8px;padding:8px 11px;cursor:pointer}}
.logbtn:hover{{background:#314158}}
.loghint{{opacity:.75;font-size:13px;margin-left:4px}}
#logs{{height:calc(100vh - 230px);min-height:420px;overflow-y:auto;padding:14px;white-space:pre-wrap;word-break:break-word;font-family:Menlo,Consolas,monospace;font-size:12px;line-height:1.4;background:#101418;color:#e8eef5;border-radius:12px;border:1px solid #2b3440}}
.err{{color:#ff9b9b;font-weight:bold}}
.warn{{color:#ffd28a;font-weight:bold}}
.info{{color:#a8ffbf;font-weight:bold}}
</style>

<h2>Logs <span style="font-size:13px;opacity:.65">v{VERSION}</span></h2>
<p style="opacity:.8;margin-top:-4px">Filtered diagnostic timeline. Newest first. Desktop/audio noise is hidden.</p>

<div class="logbar">
  <button class="logbtn" onclick="setMode('important')">Important</button>
  <button class="logbtn" onclick="setMode('mavlink')">MAVLink</button>
  <button class="logbtn" onclick="setMode('video')">Video</button>
  <button class="logbtn" onclick="setMode('siyi')">SIYI</button>
  <button class="logbtn" onclick="setMode('network')">Network</button>
  <button class="logbtn" onclick="setMode('webui')">Web UI</button>
  <button class="logbtn" onclick="setMode('system')">System</button>
  <button class="logbtn" onclick="setMode('full')">Full Filtered</button>
  <button class="logbtn" onclick="copyLogs()">Copy</button>
  <span class="loghint" id="status">Loading…</span>
</div>

<pre id="logs"></pre>

<script>
let mode='important';
let follow=true;

function colorize(t){{
  return t
    .replace(/(ERROR)/g,'<span class="err">$1</span>')
    .replace(/(WARN)/g,'<span class="warn">$1</span>')
    .replace(/(INFO)/g,'<span class="info">$1</span>');
}}

async function loadLogs(){{
  const box=document.getElementById('logs');
  const status=document.getElementById('status');
  try{{
    const r=await fetch('/api/logs?mode='+encodeURIComponent(mode)+'&t='+Date.now(), {{cache:'no-store'}});
    const t=await r.text();
    box.innerHTML=colorize(t);
    status.innerText='Mode: '+mode+' | Updated: '+new Date().toLocaleTimeString();
    if(follow) box.scrollTop=0;
  }}catch(e){{
    status.innerText='Failed to load logs';
  }}
}}

function setMode(m){{
  mode=m;
  loadLogs();
}}

function copyLogs(){{
  navigator.clipboard.writeText(document.getElementById('logs').innerText);
  document.getElementById('status').innerText='Copied diagnostics';
}}

loadLogs();
setInterval(loadLogs,5000);
</script>"""

_old_do_GET = H.do_GET
def _patched_do_GET(self):
    parsed = urlparse(self.path)
    path = parsed.path
    qs = dict(parse_qsl(parsed.query))

    if path == "/logs":
        return _send_bytes(self, page("Logs", _real_logs_page()), "text/html; charset=utf-8")

    if path == "/api/logs":
        mode = qs.get("mode", "important")
        return _send_bytes(self, _real_logs_text(mode), "text/plain; charset=utf-8")

    return _old_do_GET(self)

H.do_GET = _patched_do_GET
# REAL_HTTP_LOGS_PAGE_FIX_END


if __name__ == "__main__":
    HTTPServer(("0.0.0.0",PORT),H).serve_forever()


# FULL_LOGS_PAGE_FIX_START
from flask import Response
import subprocess
import shlex

def _safe_cmd(cmd, timeout=4):
    try:
        return subprocess.check_output(
            cmd, shell=True, text=True,
            stderr=subprocess.STDOUT, timeout=timeout
        )
    except subprocess.CalledProcessError as e:
        return e.output or str(e)
    except Exception as e:
        return str(e)

@app.route("/api/logs")
def api_logs():
    parts = []

    sources = [
        ("SIYI Web UI", "journalctl -u siyi-webui -n 250 --no-pager"),
        ("MAVLink Router", "journalctl -u mavlink-router -n 180 --no-pager"),
        ("SIYI Services", "journalctl -u 'siyi-*' -n 220 --no-pager"),
        ("System Errors", "journalctl -p warning..alert -n 120 --no-pager"),
    ]

    for title, cmd in sources:
        parts.append(f'\n\n===== {title} =====\n')
        parts.append(_safe_cmd(cmd))

    return Response("".join(parts), mimetype="text/plain")


@app.route("/logs")
def logs_page():
    return f"""
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SIYI Logs</title>
<style>
body {{
  margin: 0;
  background: #101418;
  color: #e8eef5;
  font-family: Arial, sans-serif;
}}
.header {{
  padding: 14px 18px;
  background: #171d24;
  border-bottom: 1px solid #2b3440;
  display: flex;
  gap: 12px;
  align-items: center;
  flex-wrap: wrap;
}}
h1 {{
  margin: 0;
  font-size: 20px;
}}
button, a.btn {{
  background: #253244;
  color: #e8eef5;
  border: 1px solid #3c4b5f;
  border-radius: 8px;
  padding: 8px 11px;
  text-decoration: none;
  cursor: pointer;
}}
button:hover, a.btn:hover {{
  background: #314158;
}}
.status {{
  opacity: .8;
  font-size: 13px;
}}
.version {{
  font-size: 12px;
  opacity: 0.6;
}}
#logs {{
  height: calc(100vh - 72px);
  overflow-y: auto;
  padding: 14px;
  white-space: pre-wrap;
  word-break: break-word;
  font-family: Menlo, Consolas, monospace;
  font-size: 12px;
  line-height: 1.35;
}}
.err {{ color: #ff9b9b; }}
.warn {{ color: #ffd28a; }}
.ok {{ color: #a8ffbf; }}
</style>
</head>
<body>
<div class="header">
  <h1>SIYI Logs</h1>
  <span class="version">v{VERSION}</span>
  <button onclick="loadLogs(false)">Refresh</button>
  <button onclick="toggleFollow()" id="followBtn">Auto-follow: ON</button>
  <button onclick="copyLogs()">Copy diagnostics</button>
  <a class="btn" href="/" >Back</a>
  <span class="status" id="status">Loading…</span>
</div>

<pre id="logs"></pre>

<script>
let follow = true;
let timer = null;

function colorize(t) {{
  return t
    .replace(/(error|failed|traceback|exception|critical)/gi, '<span class="err">$1</span>')
    .replace(/(warning|warn)/gi, '<span class="warn">$1</span>')
    .replace(/(active \\(running\\)|started|success)/gi, '<span class="ok">$1</span>');
}}

async function loadLogs(auto) {{
  const box = document.getElementById('logs');
  const status = document.getElementById('status');
  try {{
    const r = await fetch('/api/logs?ts=' + Date.now());
    const t = await r.text();
    box.innerHTML = colorize(t);
    status.innerText = 'Updated: ' + new Date().toLocaleTimeString();
    if (follow) box.scrollTop = box.scrollHeight;
  }} catch(e) {{
    status.innerText = 'Failed to load logs';
    if (!auto) alert(e);
  }}
}}

function toggleFollow() {{
  follow = !follow;
  document.getElementById('followBtn').innerText = 'Auto-follow: ' + (follow ? 'ON' : 'OFF');
}}

function copyLogs() {{
  navigator.clipboard.writeText(document.getElementById('logs').innerText);
  document.getElementById('status').innerText = 'Copied diagnostics';
}}

loadLogs(false);
timer = setInterval(() => loadLogs(true), 3000);
</script>
</body>
</html>
"""
# FULL_LOGS_PAGE_FIX_END

# FORCE_LOGS2_PAGE_START
from flask import Response
import subprocess
import shlex

def _logs2_cmd(cmd, timeout=5):
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT, timeout=timeout)
    except Exception as e:
        return str(e)

@app.route("/api/logs2")
def api_logs2():
    out = []
    checks = [
        ("SIYI WEBUI", "journalctl -u siyi-webui -n 300 --no-pager"),
        ("MAVLINK ROUTER", "journalctl -u mavlink-router -n 200 --no-pager"),
        ("ALL SIYI SERVICES", "journalctl -u 'siyi-*' -n 250 --no-pager"),
        ("SYSTEM WARNINGS", "journalctl -p warning..alert -n 150 --no-pager"),
    ]
    for title, cmd in checks:
        out.append("\\n\\n==================== " + title + " ====================\\n")
        out.append(_logs2_cmd(cmd))
    return Response("".join(out), mimetype="text/plain")

@app.route("/logs2")
def logs2_page():
    return """
<!doctype html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>SIYI Logs v{VERSION}</title>
<style>
body{margin:0;background:#101418;color:#e8eef5;font-family:Arial,sans-serif}
.header{padding:14px 18px;background:#171d24;border-bottom:1px solid #2b3440;display:flex;gap:12px;align-items:center;flex-wrap:wrap}
h1{margin:0;font-size:20px}
.badge{font-size:12px;opacity:.7}
button,a{background:#253244;color:#e8eef5;border:1px solid #3c4b5f;border-radius:8px;padding:8px 11px;text-decoration:none;cursor:pointer}
button:hover,a:hover{background:#314158}
#status{opacity:.75;font-size:13px}
#logs{height:calc(100vh - 72px);overflow-y:auto;padding:14px;white-space:pre-wrap;word-break:break-word;font-family:Menlo,Consolas,monospace;font-size:12px;line-height:1.35}
.err{color:#ff9b9b;font-weight:bold}
.warn{color:#ffd28a;font-weight:bold}
.ok{color:#a8ffbf;font-weight:bold}
</style>
</head>
<body>
<div class="header">
  <h1>SIYI Logs</h1>
  <span class="badge">v{VERSION} / forced logs2 page</span>
  <button onclick="loadLogs()">Refresh</button>
  <button onclick="toggleFollow()" id="followBtn">Auto-follow: ON</button>
  <button onclick="copyLogs()">Copy diagnostics</button>
  <a href="/">Back</a>
  <span id="status">Loading…</span>
</div>
<pre id="logs"></pre>
<script>
let follow=true;
function colorize(t){
  return t
    .replace(/(error|failed|failure|traceback|exception|critical)/gi,'<span class="err">$1</span>')
    .replace(/(warning|warn)/gi,'<span class="warn">$1</span>')
    .replace(/(active \\(running\\)|started|success|online)/gi,'<span class="ok">$1</span>');
}
async function loadLogs(){
  const box=document.getElementById('logs');
  const status=document.getElementById('status');
  try{
    const r=await fetch('/api/logs2?t='+Date.now());
    const t=await r.text();
    box.innerHTML=colorize(t);
    status.innerText='Updated: '+new Date().toLocaleTimeString();
    if(follow) box.scrollTop=box.scrollHeight;
  }catch(e){
    status.innerText='Failed to load logs';
  }
}
function toggleFollow(){
  follow=!follow;
  document.getElementById('followBtn').innerText='Auto-follow: '+(follow?'ON':'OFF');
}
function copyLogs(){
  navigator.clipboard.writeText(document.getElementById('logs').innerText);
  document.getElementById('status').innerText='Copied diagnostics';
}
loadLogs();
setInterval(loadLogs,3000);
</script>
</body>
</html>
"""
# FORCE_LOGS2_PAGE_END
