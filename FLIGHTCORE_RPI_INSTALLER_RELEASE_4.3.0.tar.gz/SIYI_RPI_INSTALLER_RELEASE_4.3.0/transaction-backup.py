#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,os,shutil,stat,sys
from pathlib import Path


def digest_file(path: str) -> str:
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def node_record(path: str, rel: str|None=None) -> dict:
    st=os.lstat(path)
    if stat.S_ISREG(st.st_mode): kind='file'; digest=digest_file(path); link=''
    elif stat.S_ISDIR(st.st_mode): kind='directory'; digest=''; link=''
    elif stat.S_ISLNK(st.st_mode): kind='symlink'; link=os.readlink(path); digest=hashlib.sha256(link.encode()).hexdigest()
    else: raise SystemExit('unsupported snapshot path type: '+path)
    out={'kind':kind,'uid':st.st_uid,'gid':st.st_gid,'mode':stat.S_IMODE(st.st_mode),'atime_ns':st.st_atime_ns,'mtime_ns':st.st_mtime_ns,'sha256':digest,'link_target':link}
    if rel is not None: out['rel']=rel
    return out

def tree_metadata(path: str) -> list[dict]:
    records=[node_record(path,'.')]
    for root,dirs,files in os.walk(path,topdown=True,followlinks=False):
        dirs.sort(); files.sort()
        for name in list(dirs):
            p=os.path.join(root,name); records.append(node_record(p,os.path.relpath(p,path)))
            if os.path.islink(p): dirs.remove(name)
        for name in files:
            p=os.path.join(root,name); records.append(node_record(p,os.path.relpath(p,path)))
    return records

def metadata_fingerprint(records: list[dict]) -> str:
    normalized=[(r['rel'],r['kind'],r['uid'],r['gid'],r['mode'],r['sha256'],r['link_target']) for r in records]
    return hashlib.sha256(json.dumps(normalized,separators=(',',':')).encode()).hexdigest()

def copy_content(path: str, backup_root: str) -> None:
    dst=os.path.join(backup_root,path.lstrip('/'))
    os.makedirs(os.path.dirname(dst),exist_ok=True)
    if os.path.islink(path): os.symlink(os.readlink(path),dst)
    elif os.path.isdir(path): shutil.copytree(path,dst,symlinks=True,copy_function=shutil.copy2)
    else: shutil.copy2(path,dst,follow_symlinks=False)

manifest_path,index_path,backup_root=sys.argv[1:]
data=json.load(open(manifest_path,encoding='utf-8'))
ordered=[]; spec={}
def add(path: str, full_tree=False, reason='target'):
    if path not in spec: ordered.append(path); spec[path]={'full_tree':False,'reasons':[]}
    spec[path]['full_tree']=bool(spec[path]['full_tree'] or full_tree)
    if reason not in spec[path]['reasons']: spec[path]['reasons'].append(reason)
for item in data['files']: add(item['path'],False,'target')
for path in ['/usr/local/bin/mediamtx','/usr/bin/mavlink-routerd','/usr/bin/mavlink-router','/usr/local/bin/mavlink-routerd','/usr/local/bin/mavlink-router','/boot/firmware/cmdline.txt','/boot/firmware/config.txt','/boot/cmdline.txt','/boot/config.txt']: add(path,False,'external')
for path in data.get('obsolete_paths',[]): add(path,True,'obsolete')
Path(backup_root).mkdir(parents=True,exist_ok=True)
entries=[]
for path in ordered:
    exists=os.path.lexists(path)
    entry={'path':path,'existed':exists,'full_tree':bool(spec[path]['full_tree']),'reasons':spec[path]['reasons']}
    if exists:
        entry.update(node_record(path))
        content_backed=entry['kind']!='directory' or entry['full_tree']
        entry['content_backed_up']=content_backed
        if entry['kind']=='directory' and entry['full_tree']:
            records=tree_metadata(path); entry['tree_metadata']=records; entry['tree_fingerprint']=metadata_fingerprint(records)
        if content_backed: copy_content(path,backup_root)
    entries.append(entry)
result={'schema_version':2,'manifest_release':data.get('release_version'),'manifest_build':data.get('build_id'),'entries':entries}
Path(index_path).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
