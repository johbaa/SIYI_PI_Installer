# FlightCore 4.2.2 RC13 acceptance checklist

- [x] RC12 load-bound Ground Station daemon retained byte-identically.
- [x] RC11/RC7 gimbal and FC-native failsafe bridge retained byte-identically.
- [x] Browser telemetry proxy parses URL and preserves queries.
- [x] Full telemetry catalogue/editor requests work through WebUI.
- [x] Selected flight telemetry requests work through WebUI.
- [x] Request-handler `time` shadowing removed.
- [x] Offline proxy-to-daemon, JavaScript, load and package tests passed.
- [ ] Exact RC12 -> RC13 native WebUI upgrade passes.
- [ ] Existing telemetry groups visibly update on Android.
- [ ] Physical gimbal regression check passes.
- [ ] 30-minute actual 4G/ZeroTier/video/joystick soak passes.
- [ ] Controlled flight acceptance passes.
