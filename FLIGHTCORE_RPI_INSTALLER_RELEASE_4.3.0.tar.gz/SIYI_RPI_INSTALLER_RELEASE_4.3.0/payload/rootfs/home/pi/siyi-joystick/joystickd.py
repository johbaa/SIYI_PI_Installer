#!/usr/bin/env python3
from __future__ import annotations

import copy
import errno
import fcntl
import glob
import json
import logging
import os
import re
import select
import struct
import tempfile
import threading
import time
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

CONFIG_PATH = Path('/etc/siyi/joystick.json')
HOST = '127.0.0.1'
PORT = 18766
MARKER = 'GROUND_STATION_USB_JOYSTICK_STAGE1_V1'

EV_SYN=0x00
EV_KEY=0x01
EV_ABS=0x03
ABS_MAX=0x3f
KEY_MAX=0x2ff
BTN_MISC=0x100

DEFAULT_CONFIG={
  'version':1,
  'stage':'read_only',
  'enabled':False,
  'device':{'name':'','vendor_id':'','product_id':'','unique_id':'','by_id_path':''},
  'output':{'type':'manual_control','send_rate_hz':30,'target_system':1,'target_component':1,'active':False},
  'axes':{
    'roll':{'source':'ABS_X','invert':False,'minimum':-32768,'center':0,'maximum':32767,'deadzone':0.04,'expo':0.20},
    'pitch':{'source':'ABS_Y','invert':True,'minimum':-32768,'center':0,'maximum':32767,'deadzone':0.04,'expo':0.20},
    'yaw':{'source':'ABS_RZ','invert':False,'minimum':-32768,'center':0,'maximum':32767,'deadzone':0.05,'expo':0.10},
    'throttle':{'source':'ABS_THROTTLE','invert':True,'minimum':0,'center':None,'maximum':255,'deadzone':0.0,'expo':0.0},
  },
  'axis_calibration':{},
  'buttons':{},
  'safety':{
    'require_groundstation_lease':True,
    'lease_timeout_ms':1500,
    'disconnect_timeout_ms':500,
    'require_throttle_safe_on_enable':True,
    'allow_arm_button':False,
    'allow_disarm_button':False,
  },
}

logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')
LOG=logging.getLogger('siyi-joystickd')


def deep_merge(base:dict, override:dict)->dict:
    result=copy.deepcopy(base)
    for key,value in override.items():
        if isinstance(value,dict) and isinstance(result.get(key),dict):
            result[key]=deep_merge(result[key],value)
        else:
            result[key]=copy.deepcopy(value)
    return result


def validate_config(raw:Any)->dict:
    if not isinstance(raw,dict):
        raise ValueError('configuration must be a JSON object')
    cfg=deep_merge(DEFAULT_CONFIG,raw)
    cfg['version']=1
    cfg['stage']='read_only'
    cfg['enabled']=False
    cfg.setdefault('output',{})['active']=False
    device=cfg.get('device')
    if not isinstance(device,dict): raise ValueError('device must be an object')
    axes=cfg.get('axes')
    if not isinstance(axes,dict): raise ValueError('axes must be an object')
    for role in ('roll','pitch','yaw','throttle'):
        item=axes.get(role)
        if not isinstance(item,dict): raise ValueError(f'axes.{role} must be an object')
        item['source']=str(item.get('source',''))
        item['invert']=bool(item.get('invert',False))
        item['deadzone']=max(0.0,min(0.4,float(item.get('deadzone',0.0))))
        item['expo']=max(0.0,min(1.0,float(item.get('expo',0.0))))
        for key in ('minimum','maximum'):
            item[key]=int(item.get(key,0))
        center=item.get('center')
        item['center']=None if center is None else int(center)
        if item['maximum']<=item['minimum']:
            raise ValueError(f'axes.{role} maximum must exceed minimum')
    safety=cfg.setdefault('safety',{})
    safety['allow_arm_button']=False
    safety['allow_disarm_button']=False
    return cfg


def atomic_write_json(path:Path,data:dict)->None:
    target=path.resolve(strict=False)
    target.parent.mkdir(parents=True,exist_ok=True)
    encoded=(json.dumps(data,indent=2,sort_keys=True)+'\n').encode('utf-8')
    fd,tmp=tempfile.mkstemp(prefix='.joystick.',suffix='.tmp',dir=str(target.parent))
    try:
        with os.fdopen(fd,'wb') as handle:
            handle.write(encoded);handle.flush();os.fsync(handle.fileno())
        os.chmod(tmp,0o640)
        os.replace(tmp,target)
        dfd=os.open(str(target.parent),os.O_DIRECTORY)
        try: os.fsync(dfd)
        finally: os.close(dfd)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass


def load_config()->dict:
    try:
        return validate_config(json.loads(CONFIG_PATH.read_text(encoding='utf-8')))
    except FileNotFoundError:
        cfg=validate_config({});atomic_write_json(CONFIG_PATH,cfg);return cfg
    except Exception as exc:
        LOG.error('Configuration validation failed: %s',exc)
        return validate_config({})

# Linux ioctl helpers.
_IOC_NRBITS=8;_IOC_TYPEBITS=8;_IOC_SIZEBITS=14;_IOC_DIRBITS=2
_IOC_NRSHIFT=0
_IOC_TYPESHIFT=_IOC_NRSHIFT+_IOC_NRBITS
_IOC_SIZESHIFT=_IOC_TYPESHIFT+_IOC_TYPEBITS
_IOC_DIRSHIFT=_IOC_SIZESHIFT+_IOC_SIZEBITS
_IOC_READ=2

def _IOC(direction:int,type_:int,nr:int,size:int)->int:
    return ((direction<<_IOC_DIRSHIFT)|(type_<<_IOC_TYPESHIFT)|(nr<<_IOC_NRSHIFT)|(size<<_IOC_SIZESHIFT))
def _IOR(type_:str,nr:int,size:int)->int:return _IOC(_IOC_READ,ord(type_),nr,size)
def EVIOCGNAME(length:int)->int:return _IOC(_IOC_READ,ord('E'),0x06,length)
def EVIOCGUNIQ(length:int)->int:return _IOC(_IOC_READ,ord('E'),0x08,length)
def EVIOCGBIT(ev:int,length:int)->int:return _IOC(_IOC_READ,ord('E'),0x20+ev,length)
def EVIOCGABS(code:int)->int:return _IOR('E',0x40+code,24)
EVIOCGID=_IOR('E',0x02,8)

EVENT_STRUCT=struct.Struct('@llHHI')
ABSINFO_STRUCT=struct.Struct('@iiiiii')
INPUT_ID_STRUCT=struct.Struct('@HHHH')

FALLBACK_ABS={0:'ABS_X',1:'ABS_Y',2:'ABS_Z',3:'ABS_RX',4:'ABS_RY',5:'ABS_RZ',6:'ABS_THROTTLE',7:'ABS_RUDDER',8:'ABS_WHEEL',9:'ABS_GAS',10:'ABS_BRAKE',16:'ABS_HAT0X',17:'ABS_HAT0Y',18:'ABS_HAT1X',19:'ABS_HAT1Y',20:'ABS_HAT2X',21:'ABS_HAT2Y',22:'ABS_HAT3X',23:'ABS_HAT3Y'}
FALLBACK_KEYS={0x120:'BTN_TRIGGER',0x121:'BTN_THUMB',0x122:'BTN_THUMB2',0x123:'BTN_TOP',0x124:'BTN_TOP2',0x125:'BTN_PINKIE',0x126:'BTN_BASE',0x127:'BTN_BASE2',0x128:'BTN_BASE3',0x129:'BTN_BASE4',0x12a:'BTN_BASE5',0x12b:'BTN_BASE6',0x130:'BTN_SOUTH',0x131:'BTN_EAST',0x133:'BTN_NORTH',0x134:'BTN_WEST',0x136:'BTN_TL',0x137:'BTN_TR',0x138:'BTN_TL2',0x139:'BTN_TR2',0x13a:'BTN_SELECT',0x13b:'BTN_START',0x13c:'BTN_MODE',0x13d:'BTN_THUMBL',0x13e:'BTN_THUMBR',0x220:'BTN_DPAD_UP',0x221:'BTN_DPAD_DOWN',0x222:'BTN_DPAD_LEFT',0x223:'BTN_DPAD_RIGHT'}

def load_code_names():
    abs_names=dict(FALLBACK_ABS);key_names=dict(FALLBACK_KEYS)
    for header in ('/usr/include/linux/input-event-codes.h','/usr/include/linux/input.h'):
        try: content=Path(header).read_text(encoding='utf-8',errors='ignore')
        except Exception: continue
        for name,value in re.findall(r'^#define\s+((?:ABS|BTN)_[A-Z0-9_]+)\s+(0x[0-9A-Fa-f]+|[0-9]+)\b',content,re.M):
            try: code=int(value,0)
            except ValueError: continue
            if name.startswith('ABS_'): abs_names.setdefault(code,name)
            elif name.startswith('BTN_'): key_names.setdefault(code,name)
    return abs_names,key_names
ABS_NAMES,KEY_NAMES=load_code_names()

def bitmap_has(data:bytes,code:int)->bool:
    index=code//8
    return index<len(data) and bool(data[index]&(1<<(code%8)))

def ioctl_bytes(fd:int,request:int,length:int)->bytes:
    buf=bytearray(length);fcntl.ioctl(fd,request,buf,True);return bytes(buf)

def ioctl_string(fd:int,request:int,length:int=256)->str:
    raw=ioctl_bytes(fd,request,length).split(b'\0',1)[0]
    return raw.decode('utf-8','replace').strip()

def abs_info(fd:int,code:int):
    raw=ioctl_bytes(fd,EVIOCGABS(code),ABSINFO_STRUCT.size)
    value,minimum,maximum,fuzz,flat,resolution=ABSINFO_STRUCT.unpack(raw)
    return {'value':value,'minimum':minimum,'maximum':maximum,'fuzz':fuzz,'flat':flat,'resolution':resolution}

def by_id_map()->dict[str,str]:
    result={}
    for item in glob.glob('/dev/input/by-id/*-event-joystick'):
        try: result[os.path.realpath(item)]=item
        except OSError: pass
    return result

def probe_device(path:str,by_id:str='')->dict|None:
    fd=None
    try:
        fd=os.open(path,os.O_RDONLY|os.O_NONBLOCK)
        event_bits=ioctl_bytes(fd,EVIOCGBIT(0,64),64)
        has_abs=bitmap_has(event_bits,EV_ABS);has_key=bitmap_has(event_bits,EV_KEY)
        if not has_abs and not has_key:return None
        abs_bits=ioctl_bytes(fd,EVIOCGBIT(EV_ABS,64),64) if has_abs else b''
        key_bits=ioctl_bytes(fd,EVIOCGBIT(EV_KEY,96),96) if has_key else b''
        axes=[code for code in range(ABS_MAX+1) if bitmap_has(abs_bits,code)]
        buttons=[code for code in range(BTN_MISC,KEY_MAX+1) if bitmap_has(key_bits,code)]
        # A joystick candidate should expose at least one absolute axis and one
        # joystick/gamepad button, unless udev explicitly classified it.
        if not by_id and (not axes or not buttons):return None
        ids=INPUT_ID_STRUCT.unpack(ioctl_bytes(fd,EVIOCGID,INPUT_ID_STRUCT.size))
        name=ioctl_string(fd,EVIOCGNAME(256)) or Path(path).name
        try: unique=ioctl_string(fd,EVIOCGUNIQ(256))
        except OSError: unique=''
        return {'path':path,'by_id_path':by_id,'name':name,'bustype':f'{ids[0]:04x}','vendor_id':f'{ids[1]:04x}','product_id':f'{ids[2]:04x}','version':f'{ids[3]:04x}','unique_id':unique,'axis_codes':axes,'button_codes':buttons}
    except (OSError,IOError):return None
    finally:
        if fd is not None:
            try:os.close(fd)
            except OSError:pass

def enumerate_devices()->list[dict]:
    links=by_id_map();paths=sorted(set(glob.glob('/dev/input/event*'))|set(links))
    devices=[]
    for path in paths:
        item=probe_device(path,links.get(os.path.realpath(path),''))
        if item:devices.append(item)
    devices.sort(key=lambda d:(0 if d['by_id_path'] else 1,d['name'],d['path']))
    return devices

class JoystickManager:
    def __init__(self):
        self.lock=threading.RLock();self.cond=threading.Condition(self.lock)
        self.config=load_config();self.devices=[];self.device=None;self.fd=None
        self.raw_axes={};self.buttons={};self.last_input_monotonic=None
        self.error='';self.serial=0;self.calibration=None;self.test_mode=False
        self.running=True
        threading.Thread(target=self._discovery_loop,name='joystick-discovery',daemon=True).start()
        threading.Thread(target=self._reader_loop,name='joystick-reader',daemon=True).start()

    def _touch(self):
        self.serial+=1;self.cond.notify_all()

    def _configured(self)->bool:
        d=self.config.get('device',{})
        return any(str(d.get(k,'')).strip() for k in ('by_id_path','unique_id','vendor_id','product_id','name'))

    def _matches(self,item:dict)->bool:
        d=self.config.get('device',{})
        byid=str(d.get('by_id_path',''))
        if byid:return item.get('by_id_path')==byid
        uid=str(d.get('unique_id',''))
        if uid and item.get('unique_id')==uid:return True
        vendor=str(d.get('vendor_id','')).lower();product=str(d.get('product_id','')).lower();name=str(d.get('name',''))
        return bool(vendor and product and item.get('vendor_id','').lower()==vendor and item.get('product_id','').lower()==product and (not name or item.get('name')==name))

    def _desired_device(self):
        if self._configured():
            return next((d for d in self.devices if self._matches(d)),None)
        return self.devices[0] if self.devices else None

    def _discovery_loop(self):
        previous_signature=None
        while self.running:
            try:devices=enumerate_devices();error=''
            except Exception as exc:devices=[];error=str(exc)
            with self.lock:
                self.devices=devices
                desired=self._desired_device()
                signature=(desired or {}).get('path')
                if signature!=previous_signature or (desired is not None and self.fd is None):
                    self._close_locked('device changed')
                    previous_signature=signature
                    if desired:self._open_locked(desired)
                    elif self._configured():LOG.warning('Configured controller disconnected')
                    self._touch()
                if error!=self.error:self.error=error;self._touch()
            time.sleep(1.5)

    def _open_locked(self,item:dict):
        try:
            fd=os.open(item['path'],os.O_RDONLY|os.O_NONBLOCK)
            axes={}
            for code in item['axis_codes']:
                try:info=abs_info(fd,code)
                except OSError:continue
                name=ABS_NAMES.get(code,f'ABS_{code}')
                axes[name]={'code':code,'raw':info['value'],'kernel_min':info['minimum'],'kernel_max':info['maximum'],'flat':info['flat'],'fuzz':info['fuzz']}
            buttons={KEY_NAMES.get(code,f'BTN_{code}'):{'code':code,'pressed':False} for code in item['button_codes']}
            self.fd=fd;self.device=copy.deepcopy(item);self.raw_axes=axes;self.buttons=buttons;self.error=''
            LOG.info('Controller discovered: %s (%s)',item['name'],item.get('by_id_path') or item['path'])
        except OSError as exc:
            self.error=f'{item["path"]}: {exc}';LOG.error('Input error: %s',self.error)

    def _close_locked(self,reason:str):
        if self.fd is not None:
            try:os.close(self.fd)
            except OSError:pass
            if self.device:LOG.warning('Controller disconnected: %s (%s)',self.device.get('name'),reason)
        self.fd=None;self.device=None;self.raw_axes={};self.buttons={};self.calibration=None;self.test_mode=False

    def _reader_loop(self):
        while self.running:
            with self.lock:fd=self.fd
            if fd is None:time.sleep(0.1);continue
            try:
                ready,_,_=select.select([fd],[],[],0.25)
                if not ready:continue
                data=os.read(fd,EVENT_STRUCT.size*64)
                if not data:raise OSError(errno.ENODEV,'input device closed')
                changed=False
                for offset in range(0,len(data)-EVENT_STRUCT.size+1,EVENT_STRUCT.size):
                    _sec,_usec,event_type,code,value=EVENT_STRUCT.unpack_from(data,offset)
                    with self.lock:
                        if event_type==EV_ABS:
                            name=ABS_NAMES.get(code,f'ABS_{code}')
                            axis=self.raw_axes.get(name)
                            if axis:
                                axis['raw']=int(value);changed=True
                                if self.calibration is not None:
                                    observed=self.calibration['axes'].setdefault(name,{'minimum':int(value),'center':int(value),'maximum':int(value)})
                                    observed['minimum']=min(observed['minimum'],int(value));observed['maximum']=max(observed['maximum'],int(value))
                        elif event_type==EV_KEY:
                            name=KEY_NAMES.get(code,f'BTN_{code}')
                            button=self.buttons.get(name)
                            if button and button['pressed']!=bool(value):button['pressed']=bool(value);changed=True
                if changed:
                    with self.lock:self.last_input_monotonic=time.monotonic();self._touch()
            except OSError as exc:
                with self.lock:self.error=str(exc);self._close_locked('read error');self._touch()

    def _processed_role(self,role:str)->float|None:
        item=self.config.get('axes',{}).get(role,{})
        source=item.get('source','');axis=self.raw_axes.get(source)
        if not axis:return None
        raw=float(axis['raw']);minimum=float(item.get('minimum',axis['kernel_min']));maximum=float(item.get('maximum',axis['kernel_max']))
        center=item.get('center');invert=bool(item.get('invert',False));deadzone=float(item.get('deadzone',0));expo=float(item.get('expo',0))
        if role=='throttle' or center is None:
            value=(raw-minimum)/max(1.0,maximum-minimum);value=max(0.0,min(1.0,value));value=1.0-value if invert else value
            if deadzone>0 and value<deadzone:value=0.0
            return round(value,4)
        center=float(center)
        value=(raw-center)/max(1.0,(maximum-center) if raw>=center else (center-minimum));value=max(-1.0,min(1.0,value));value=-value if invert else value
        if abs(value)<=deadzone:value=0.0
        else:value=(abs(value)-deadzone)/max(0.0001,1.0-deadzone)*(1 if value>=0 else -1)
        value=(1.0-expo)*value+expo*(abs(value)**3)*(1 if value>=0 else -1)
        return round(max(-1.0,min(1.0,value)),4)

    def snapshot(self)->dict:
        with self.lock:
            now=time.monotonic();age=None if self.last_input_monotonic is None else int(max(0,(now-self.last_input_monotonic)*1000))
            device=copy.deepcopy(self.device)
            axes={name:{**copy.deepcopy(item),'processed_preview':None} for name,item in self.raw_axes.items()}
            return {'ok':True,'marker':MARKER,'stage':'read_only','aircraft_control_available':False,'connected':device is not None,'configured':self._configured(),'calibrated':bool(self.config.get('axis_calibration')),'device':device,'devices':copy.deepcopy(self.devices),'last_input_ms':age,'input_error':self.error,'calibration':copy.deepcopy(self.calibration),'test_mode':self.test_mode,'control_active':False,'mavlink_output':False,'axes':axes,'processed':{role:self._processed_role(role) for role in ('roll','pitch','yaw','throttle')},'buttons':{name:bool(item['pressed']) for name,item in self.buttons.items()},'serial':self.serial}

    def get_config(self)->dict:
        with self.lock:return copy.deepcopy(self.config)

    def save_config(self,raw:dict)->dict:
        cfg=validate_config(raw)
        with self.lock:
            atomic_write_json(CONFIG_PATH,cfg);self.config=cfg;self._close_locked('configuration changed');self._touch()
        LOG.info('Joystick configuration saved')
        return cfg

    def select_device(self,payload:dict)->dict:
        wanted=str(payload.get('by_id_path') or payload.get('path') or '')
        with self.lock:
            selected=next((d for d in self.devices if wanted in (d.get('by_id_path'),d.get('path'))),None)
            if not selected:raise ValueError('selected controller is not currently available')
            cfg=copy.deepcopy(self.config);cfg['device']={k:selected.get(k,'') for k in ('name','vendor_id','product_id','unique_id','by_id_path')}
        self.save_config(cfg);LOG.info('Controller selected: %s',selected['name']);return self.snapshot()

    def calibration_start(self)->dict:
        with self.lock:
            if not self.device:raise ValueError('no controller connected')
            axes={name:{'minimum':int(item['raw']),'center':int(item['raw']),'maximum':int(item['raw'])} for name,item in self.raw_axes.items()}
            self.calibration={'active':True,'started_at':time.time(),'axes':axes};self.test_mode=True;self._touch()
        LOG.info('Calibration started');return self.snapshot()

    def calibration_cancel(self)->dict:
        with self.lock:self.calibration=None;self._touch()
        LOG.info('Calibration cancelled');return self.snapshot()

    def calibration_save(self)->dict:
        with self.lock:
            if not self.calibration:raise ValueError('calibration is not active')
            cfg=copy.deepcopy(self.config);observed=copy.deepcopy(self.calibration['axes']);cfg['axis_calibration']=observed
            for role,item in cfg.get('axes',{}).items():
                source=item.get('source');cal=observed.get(source)
                if cal:
                    item['minimum']=cal['minimum'];item['maximum']=cal['maximum'];item['center']=None if role=='throttle' else cal['center']
            self.calibration=None
        self.save_config(cfg);LOG.info('Calibration saved');return self.snapshot()

    def set_test_mode(self,enabled:bool)->dict:
        with self.lock:self.test_mode=bool(enabled);self._touch()
        LOG.info('Test mode %s','started' if enabled else 'stopped');return self.snapshot()

MANAGER=JoystickManager()

class Handler(BaseHTTPRequestHandler):
    server_version='SIYIJoystickStage1/1'
    def log_message(self,fmt,*args):pass
    def _json(self,status:int,payload:Any):
        raw=json.dumps(payload,separators=(',',':'),ensure_ascii=False).encode('utf-8')
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
    def _body(self):
        length=min(1024*1024,int(self.headers.get('Content-Length','0') or 0));raw=self.rfile.read(length) if length else b'{}';return json.loads(raw.decode('utf-8'))
    def do_GET(self):
        path=self.path.split('?',1)[0]
        if path=='/health':return self._json(200,{'ok':True,'marker':MARKER,'stage':'read_only','control_output':False})
        if path=='/status':return self._json(200,MANAGER.snapshot())
        if path=='/config':return self._json(200,{'ok':True,'config':MANAGER.get_config()})
        if path=='/stream':
            self.send_response(200);self.send_header('Content-Type','text/event-stream; charset=utf-8');self.send_header('Cache-Control','no-cache, no-store');self.send_header('Connection','keep-alive');self.send_header('X-Accel-Buffering','no');self.end_headers()
            last=-1;last_keepalive=0.0
            try:
                while True:
                    with MANAGER.cond:
                        if MANAGER.serial==last:MANAGER.cond.wait(timeout=1.0)
                        serial=MANAGER.serial
                    now=time.monotonic()
                    if serial!=last:
                        payload=json.dumps(MANAGER.snapshot(),separators=(',',':'),ensure_ascii=False)
                        self.wfile.write(('data: '+payload+'\n\n').encode('utf-8'));self.wfile.flush();last=serial;last_keepalive=now
                        time.sleep(0.05)
                    elif now-last_keepalive>=10:
                        self.wfile.write(b': keepalive\n\n');self.wfile.flush();last_keepalive=now
            except (BrokenPipeError,ConnectionResetError,TimeoutError):pass
            return
        self._json(404,{'ok':False,'error':'not found'})
    def do_PUT(self):
        try:
            if self.path.split('?',1)[0]!='/config':return self._json(404,{'ok':False,'error':'not found'})
            cfg=MANAGER.save_config(self._body());return self._json(200,{'ok':True,'config':cfg})
        except Exception as exc:return self._json(400,{'ok':False,'error':str(exc)})
    def do_POST(self):
        path=self.path.split('?',1)[0]
        try:
            payload=self._body()
            if path=='/device/select':result=MANAGER.select_device(payload)
            elif path=='/calibration/start':result=MANAGER.calibration_start()
            elif path=='/calibration/save':result=MANAGER.calibration_save()
            elif path=='/calibration/cancel':result=MANAGER.calibration_cancel()
            elif path=='/test/start':result=MANAGER.set_test_mode(True)
            elif path=='/test/stop':result=MANAGER.set_test_mode(False)
            else:return self._json(404,{'ok':False,'error':'not found'})
            return self._json(200,result)
        except Exception as exc:return self._json(400,{'ok':False,'error':str(exc)})

if __name__=='__main__':
    LOG.info('%s listening on %s:%s; aircraft control output is disabled',MARKER,HOST,PORT)
    ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
