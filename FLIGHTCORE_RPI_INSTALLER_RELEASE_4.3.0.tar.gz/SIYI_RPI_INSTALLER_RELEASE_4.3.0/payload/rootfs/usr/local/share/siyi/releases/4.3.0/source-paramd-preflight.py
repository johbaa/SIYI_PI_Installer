#!/usr/bin/env python3
"""Repair and prove the known SIYI 4.2.0 V23 parameter-daemon storage omission.

This runs before the target transaction snapshot. It is intentionally limited to
an exact, already source-verified 4.2.0 V23 system. On failure it restores the
three storage paths to their precise preflight state before returning nonzero.
"""
from __future__ import annotations

import argparse
import datetime as dt
import grp
import hashlib
import json
import os
import pathlib
import pwd
import shutil
import stat
import subprocess
import sys
import tempfile
import time
from typing import Any

P = pathlib.Path
EXPECTED_PARAMD_SHA = "2421ef12b2a30cb7d35a60ab342e82f70ee9ab8ff5b4525e48c462306368b38a"
EXPECTED_UNIT_SHA = "b700141458a2802b774e8e28de5177f53e5275d4b5a91f02fc556fdffe48c0ec"
STORAGE_PATHS = (
    "/var/lib/siyi-param-import",
    "/var/lib/siyi-param-import/sessions",
    "/var/backups/siyi-param-import",
)
BACKUP_ROOTS = (
    "/var/lib/siyi-param-import",
    "/var/backups/siyi-param-import",
)


def sha256(path: P) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def root_path(root: P, absolute: str) -> P:
    return root / absolute.lstrip("/")


def atomic_json(path: P, payload: dict[str, Any], mode: int = 0o600) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, sort_keys=True)
            f.write("\n")
        os.chmod(tmp_name, mode)
        os.replace(tmp_name, path)
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)


def run(cmd: list[str], *, timeout: float = 30, check: bool = False) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, text=True, capture_output=True, timeout=timeout, check=check)


def marker(root: P, path: str) -> str:
    try:
        return root_path(root, path).read_text(encoding="utf-8-sig").replace("\x00", "").strip()
    except FileNotFoundError:
        return ""


def path_state(path: P) -> dict[str, Any]:
    if not os.path.lexists(path):
        return {"exists": False}
    st = os.lstat(path)
    kind = "directory" if stat.S_ISDIR(st.st_mode) else "symlink" if stat.S_ISLNK(st.st_mode) else "file" if stat.S_ISREG(st.st_mode) else "other"
    return {
        "exists": True,
        "type": kind,
        "uid": st.st_uid,
        "gid": st.st_gid,
        "mode": f"{stat.S_IMODE(st.st_mode):04o}",
    }


def copy_existing(path: P, backup: P) -> None:
    backup.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        os.symlink(os.readlink(path), backup)
    elif path.is_dir():
        shutil.copytree(path, backup, symlinks=True)
    elif path.is_file():
        shutil.copy2(path, backup, follow_symlinks=False)
    else:
        raise RuntimeError(f"unsupported storage path type: {path}")


def remove_path(path: P) -> None:
    if not os.path.lexists(path):
        return
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    else:
        path.unlink()


def chown_tree(path: P, uid: int, gid: int) -> None:
    os.chown(path, uid, gid, follow_symlinks=False)
    if path.is_dir() and not path.is_symlink():
        for base, dirs, files in os.walk(path, topdown=True, followlinks=False):
            for name in dirs + files:
                child = P(base) / name
                os.chown(child, uid, gid, follow_symlinks=False)


def systemctl(args: argparse.Namespace, *parts: str, timeout: float = 30) -> subprocess.CompletedProcess[str]:
    return run([args.systemctl, *parts], timeout=timeout)


def curl_health(args: argparse.Namespace) -> tuple[bool, str]:
    proc = run([args.curl, "-fsS", "--max-time", "4", args.health_url], timeout=8)
    text = (proc.stdout or proc.stderr or "").strip()
    if proc.returncode != 0:
        return False, text or f"curl exited {proc.returncode}"
    try:
        data = json.loads(proc.stdout)
    except Exception as exc:
        return False, f"invalid health JSON: {exc}: {proc.stdout[:300]}"
    return data.get("ok") is True, proc.stdout.strip()


def service_snapshot(args: argparse.Namespace) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for prop in ("ActiveState", "SubState", "Result", "NRestarts"):
        proc = systemctl(args, "show", "siyi-paramd.service", "-p", prop, "--value")
        result[prop] = proc.stdout.strip() if proc.returncode == 0 else f"error:{proc.returncode}:{proc.stderr.strip()}"
    return result


def restore(args: argparse.Namespace, state: dict[str, Any], backup_root: P) -> list[str]:
    errors: list[str] = []
    systemctl(args, "stop", "siyi-paramd.service")
    for absolute in sorted(STORAGE_PATHS, key=lambda value: value.count("/"), reverse=True):
        path = root_path(args.root, absolute)
        try:
            remove_path(path)
        except Exception as exc:
            errors.append(f"remove {absolute}: {exc}")
    for absolute in BACKUP_ROOTS:
        before = state[absolute]
        if not before["exists"]:
            continue
        src = backup_root / absolute.lstrip("/")
        dst = root_path(args.root, absolute)
        try:
            dst.parent.mkdir(parents=True, exist_ok=True)
            if src.is_symlink():
                os.symlink(os.readlink(src), dst)
            elif src.is_dir():
                shutil.copytree(src, dst, symlinks=True)
            else:
                shutil.copy2(src, dst, follow_symlinks=False)
        except Exception as exc:
            errors.append(f"restore {absolute}: {exc}")
    systemctl(args, "daemon-reload")
    proc = systemctl(args, "restart", "siyi-paramd.service")
    if proc.returncode != 0:
        errors.append(f"restart after restore: {proc.stderr.strip() or proc.stdout.strip()}")
    return errors


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--transaction-dir", required=True)
    ap.add_argument("--json-output", required=True)
    ap.add_argument("--root", default="/")
    ap.add_argument("--systemctl", default="systemctl")
    ap.add_argument("--curl", default="curl")
    ap.add_argument("--health-url", default="http://127.0.0.1:8765/health")
    ap.add_argument("--wait-seconds", type=int, default=40)
    ap.add_argument("--stability-seconds", type=float, default=8.0)
    ap.add_argument("--owner-uid", type=int)
    ap.add_argument("--group-gid", type=int)
    ap.add_argument("--expected-paramd-sha", default=EXPECTED_PARAMD_SHA)
    ap.add_argument("--expected-unit-sha", default=EXPECTED_UNIT_SHA)
    args = ap.parse_args()
    args.root = P(args.root).resolve()
    tx = P(args.transaction_dir).resolve()
    out = P(args.json_output).resolve()
    backup_root = tx / "source-paramd-preflight-backup" / "rootfs"
    evidence: dict[str, Any] = {
        "schema_version": 1,
        "captured_at": dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "ok": False,
        "source_version": marker(args.root, "/etc/siyi/release_version"),
        "source_build": marker(args.root, "/etc/siyi/release_build"),
        "source_status": marker(args.root, "/etc/siyi/release_status"),
        "paths_before": {},
        "paths_after": {},
        "service_before": {},
        "service_after": {},
        "restored_after_failure": False,
        "restore_errors": [],
        "error": "",
    }
    state: dict[str, Any] = {}
    mutated = False
    try:
        if evidence["source_version"] != "4.2.0":
            raise RuntimeError("source version is not 4.2.0")
        if evidence["source_build"] != "SIYI_4_2_0_RELEASE_CANDIDATE_V23":
            raise RuntimeError("source build is not approved 4.2.0 V23")
        if evidence["source_status"] not in {"accepted", "core_accepted_hardware_pending"}:
            raise RuntimeError("source release status is not accepted")
        paramd = root_path(args.root, "/usr/local/bin/siyi-paramd")
        unit = root_path(args.root, "/etc/systemd/system/siyi-paramd.service")
        if sha256(paramd) != args.expected_paramd_sha:
            raise RuntimeError("source siyi-paramd checksum mismatch")
        if sha256(unit) != args.expected_unit_sha:
            raise RuntimeError("source siyi-paramd.service checksum mismatch")
        uid = args.owner_uid if args.owner_uid is not None else pwd.getpwnam("pi").pw_uid
        gid = args.group_gid if args.group_gid is not None else grp.getgrnam("pi").gr_gid
        evidence["service_before"] = service_snapshot(args)
        for absolute in STORAGE_PATHS:
            path = root_path(args.root, absolute)
            state[absolute] = path_state(path)
            evidence["paths_before"][absolute] = state[absolute]
            if state[absolute]["exists"] and state[absolute]["type"] != "directory":
                raise RuntimeError(f"storage path is not a directory: {absolute}")
        backup_root.mkdir(parents=True, exist_ok=True)
        for absolute in BACKUP_ROOTS:
            path = root_path(args.root, absolute)
            if state[absolute]["exists"]:
                copy_existing(path, backup_root / absolute.lstrip("/"))
        atomic_json(tx / "source-paramd-preflight-state.json", state)
        mutated = True
        for absolute in STORAGE_PATHS:
            path = root_path(args.root, absolute)
            path.mkdir(parents=True, exist_ok=True)
            chown_tree(path, uid, gid)
            os.chmod(path, 0o775)
        for absolute in STORAGE_PATHS:
            path = root_path(args.root, absolute)
            st = os.stat(path)
            if st.st_uid != uid or st.st_gid != gid or stat.S_IMODE(st.st_mode) != 0o775:
                raise RuntimeError(f"storage normalization failed: {absolute}")
        for command in (("daemon-reload",), ("reset-failed", "siyi-paramd.service"), ("restart", "siyi-paramd.service")):
            proc = systemctl(args, *command)
            if proc.returncode != 0 and command[0] != "reset-failed":
                raise RuntimeError(f"systemctl {' '.join(command)} failed: {proc.stderr.strip() or proc.stdout.strip()}")
        deadline = time.monotonic() + max(1, args.wait_seconds)
        health_text = ""
        while time.monotonic() < deadline:
            active = systemctl(args, "is-active", "--quiet", "siyi-paramd.service")
            health_ok, health_text = curl_health(args)
            if active.returncode == 0 and health_ok:
                break
            time.sleep(1)
        else:
            raise RuntimeError(f"parameter daemon did not become healthy: {health_text}")
        before = service_snapshot(args)
        restart_before = before.get("NRestarts", "")
        time.sleep(max(0.0, args.stability_seconds))
        after = service_snapshot(args)
        health_ok, health_text = curl_health(args)
        if after.get("ActiveState") != "active" or after.get("SubState") != "running" or after.get("Result") != "success":
            raise RuntimeError(f"parameter daemon is not stably active: {after}")
        if restart_before != after.get("NRestarts"):
            raise RuntimeError(f"parameter daemon restart counter changed: {restart_before} -> {after.get('NRestarts')}")
        if not health_ok:
            raise RuntimeError(f"parameter daemon health endpoint failed after stability window: {health_text}")
        evidence["service_after"] = after
        evidence["health_response"] = health_text
        for absolute in STORAGE_PATHS:
            evidence["paths_after"][absolute] = path_state(root_path(args.root, absolute))
        evidence["ok"] = True
        atomic_json(out, evidence)
        print("4.2.0 parameter-daemon source preflight accepted.")
        return 0
    except Exception as exc:
        evidence["error"] = f"{type(exc).__name__}: {exc}"
        if mutated:
            evidence["restore_errors"] = restore(args, state, backup_root)
            evidence["restored_after_failure"] = not evidence["restore_errors"]
        evidence["service_after"] = service_snapshot(args)
        for absolute in STORAGE_PATHS:
            evidence["paths_after"][absolute] = path_state(root_path(args.root, absolute))
        atomic_json(out, evidence)
        print(f"4.2.0 parameter-daemon source preflight failed: {evidence['error']}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
