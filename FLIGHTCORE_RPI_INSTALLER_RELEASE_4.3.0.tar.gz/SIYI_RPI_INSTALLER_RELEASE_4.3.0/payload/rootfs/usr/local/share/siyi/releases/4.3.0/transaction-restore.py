#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,os,shutil,stat,sys


def digest_file(path: str) -> str:
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def node_record(path: str, rel: str|None=None) -> dict:
    st=os.lstat(path)
    if stat.S_ISREG(st.st_mode): kind='file'; digest=digest_file(path); link=''
    elif stat.S_ISDIR(st.st_mode): kind='directory'; digest=''; link=''
    elif stat.S_ISLNK(st.st_mode): kind='symlink'; link=os.readlink(path); digest=hashlib.sha256(link.encode()).hexdigest()
    else: raise SystemExit('unsupported restored path type: '+path)
    out={'kind':kind,'uid':st.st_uid,'gid':st.st_gid,'mode':stat.S_IMODE(st.st_mode),'sha256':digest,'link_target':link}
    if rel is not None: out['rel']=rel
    return out

def metadata_fingerprint(path: str) -> str:
    records=[node_record(path,'.')]
    for root,dirs,files in os.walk(path,topdown=True,followlinks=False):
        dirs.sort(); files.sort()
        for name in list(dirs):
            p=os.path.join(root,name); records.append(node_record(p,os.path.relpath(p,path)))
            if os.path.islink(p): dirs.remove(name)
        for name in files:
            p=os.path.join(root,name); records.append(node_record(p,os.path.relpath(p,path)))
    normalized=[(r['rel'],r['kind'],r['uid'],r['gid'],r['mode'],r['sha256'],r['link_target']) for r in records]
    return hashlib.sha256(json.dumps(normalized,separators=(',',':')).encode()).hexdigest()

def remove(path: str) -> None:
    if os.path.isdir(path) and not os.path.islink(path): shutil.rmtree(path)
    elif os.path.lexists(path): os.unlink(path)

def restore_content(path: str, backup_root: str) -> None:
    src=os.path.join(backup_root,path.lstrip('/'))
    if not os.path.lexists(src): raise SystemExit('missing transaction backup: '+path)
    os.makedirs(os.path.dirname(path),exist_ok=True)
    if os.path.islink(src): os.symlink(os.readlink(src),path)
    elif os.path.isdir(src): shutil.copytree(src,path,symlinks=True,copy_function=shutil.copy2)
    else: shutil.copy2(src,path,follow_symlinks=False)

def apply_metadata(path: str, entry: dict) -> None:
    st=os.lstat(path)
    uid=int(entry['uid']); gid=int(entry['gid'])
    if (st.st_uid,st.st_gid)!=(uid,gid):
        if entry['kind']=='symlink' and hasattr(os,'lchown'): os.lchown(path,uid,gid)
        elif entry['kind']!='symlink': os.chown(path,uid,gid)
    if entry['kind']!='symlink': os.chmod(path,int(entry['mode']))
    try: os.utime(path,ns=(int(entry['atime_ns']),int(entry['mtime_ns'])),follow_symlinks=False)
    except (NotImplementedError,PermissionError): pass

def apply_tree_metadata(root: str, records: list[dict]) -> None:
    for r in sorted(records,key=lambda x:x['rel'].count('/'),reverse=True):
        path=root if r['rel']=='.' else os.path.join(root,r['rel'])
        if not os.path.lexists(path): raise SystemExit('restored tree node missing: '+path)
        apply_metadata(path,r)

def verify(path: str, entry: dict) -> None:
    if not os.path.lexists(path): raise SystemExit('restore verification missing: '+path)
    r=node_record(path)
    for key in ('kind','uid','gid','mode'):
        if r[key]!=entry[key]: raise SystemExit(f'restore verification {key} mismatch: {path}')
    if entry['kind'] in ('file','symlink') and r['sha256']!=entry['sha256']: raise SystemExit('restore checksum mismatch: '+path)
    if entry['kind']=='directory' and entry.get('full_tree') and metadata_fingerprint(path)!=entry.get('tree_fingerprint'): raise SystemExit('restore tree fingerprint mismatch: '+path)

manifest_path,index_path,backup_root=sys.argv[1:]
manifest=json.load(open(manifest_path,encoding='utf-8'))
index=json.load(open(index_path,encoding='utf-8'))
if int(index.get('schema_version',0))!=2: raise SystemExit('unsupported transaction index schema')
entries=index.get('entries',[]); by_path={e['path']:e for e in entries}
expected=[item['path'] for item in manifest['files']]
expected += ['/usr/local/bin/mediamtx','/usr/bin/mavlink-routerd','/usr/bin/mavlink-router','/usr/local/bin/mavlink-routerd','/usr/local/bin/mavlink-router','/boot/firmware/cmdline.txt','/boot/firmware/config.txt','/boot/cmdline.txt','/boot/config.txt']
expected += list(manifest.get('obsolete_paths',[]))
missing=[p for p in dict.fromkeys(expected) if p not in by_path]
if missing: raise SystemExit('transaction index missing paths: '+','.join(missing))
# Remove every target-created path deepest-first.
for e in sorted([x for x in entries if not x.get('existed')],key=lambda x:x['path'].count('/'),reverse=True): remove(e['path'])
# Restore content-backed source nodes exactly.
for e in sorted([x for x in entries if x.get('existed') and x.get('content_backed_up')],key=lambda x:x['path'].count('/')):
    remove(e['path']); restore_content(e['path'],backup_root)
    if e['kind']=='directory' and e.get('full_tree'): apply_tree_metadata(e['path'],e.get('tree_metadata',[]))
    else: apply_metadata(e['path'],e)
# Restore metadata-only source directories after their children.
for e in sorted([x for x in entries if x.get('existed') and x.get('kind')=='directory' and not x.get('content_backed_up')],key=lambda x:x['path'].count('/'),reverse=True):
    os.makedirs(e['path'],exist_ok=True); apply_metadata(e['path'],e)
for e in entries:
    if e.get('existed'): verify(e['path'],e)
    elif os.path.lexists(e['path']): raise SystemExit('target-created path remained after rollback: '+e['path'])
