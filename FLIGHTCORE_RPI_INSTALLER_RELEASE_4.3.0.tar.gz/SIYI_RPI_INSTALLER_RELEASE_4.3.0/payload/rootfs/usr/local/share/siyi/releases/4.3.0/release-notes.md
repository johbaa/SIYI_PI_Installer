# FlightCore 4.3.0 RC7 / Factory V74

## User-facing changes
- First Setup no longer contains or requires Hosts; zero Hosts is valid and optional external MAVLink destinations are configured later in Network - Hosts.
- The final Host can be deleted normally.
- Cloud telemetry profiles can be deleted with Registry tombstone tracking.
- Ground Station and Control Center use the FlightCore logo and dynamic RC7/V72 identity tooltip.
- Fresh-install browser/Terminal flow opens First Setup exactly once.

## Engineering / performance changes
- External Host, network and ZeroTier reachability moved out of the synchronous status-bar request path into a cached background service.
- Non-stream browser polling rates reduced; live telemetry remains on stream/WebSocket paths.
- Air Link First Setup performs an explicit post-reconnect health check.
- Native upgrade compatibility is Registry-derived: exact RC6/V71 for this candidate plus mandatory fresh install.

## RC7 / Factory V74 refinements
- Flight Logs viewer redesigned for selectable measures, meaningful unit-aware scales, secondary Y-axis for two unit groups, horizontal scrolling, timestamp axis, zoom/pan, tooltips, events, navigator, statistics and CSV export. Existing RC6 Flight Logs are rendered by the new viewer.
- Fixed Smooth Voltage settings persistence: battery calibration is unit-global and telemetry profiles can no longer overwrite resistance, cruise current, chemistry, cell count or voltage endpoints.

## RC7 / Factory V74 cloud additions
- Release Notes are available from the standalone FlightCore Cloud page.
- Cloud Last seen and related timestamps are displayed as YYYY-MM-DD HH:mm with an explicit browser-timezone label; stored source timestamps remain UTC.
- Full completed Flight Logs are tenant-scoped in cloud object storage with D1 metadata and use the complete RC7 interactive viewer.
- A separate low-priority sync service uploads finalized logs only while disarmed and backfills compatible existing RC6 logs; cloud failure remains non-critical.

## RC7 / Factory V75 provenance and compatibility correction
- V75 supersedes V74 after post-upgrade evidence proved accepted history omitted source_build.
- Accepted history now persists source_release, source_build and source_variant before the transaction directory is removed.
- V75 supports strict native WebUI upgrade from the exact Registry-represented RC6/V71 and RC7/V74 identities, plus fresh install.
- V75 uses updater-visible unique build ID `FLIGHTCORE_4_3_0_RELEASE_CANDIDATE_V7_FACTORY_V75` so V74 can discover the V75 update despite both remaining 4.3.0 RC7.
- Ground Station Android branding is compact while keeping the FlightCore logo at the far left and an explicit gap between the left and right pill groups.
- Local and cloud profile deletion now presents a selection list.
- Ground Station -> Control Center uses a native same-origin link to remove the newly observed handoff delay.
- The confirmed V74 battery/profile error `name 'copy' is not defined` is fixed by importing Python `copy` and regression-testing the affected endpoints.
- Release Notes are ordered newest version/RC first, then descending.
- Cloud remains schema V8; the V75 handoff refreshes Release Notes in R2 without rerunning migration 0007.

## RC7 / Factory V76 consolidated physical-acceptance rebuild
- V76 supersedes V75.
- Air Link desired RTSP configuration persists even when live validation fails; initial Air Link UI is non-blocking and Restart Majestic is explicitly restored.
- Battery/Smooth Voltage settings use independent unit-global persisted authority and are preserved across telemetry-profile operations.
- Ext MAV reachability pill is removed while optional external MAVLink destinations remain functional.
- Cloud V9 requires telemetry-profile tombstone migration and adds RC6 Flight Log compatibility/error handling.
- Native upgrade routes: exact RC6/V71 and exact RC7/V75, plus fresh install, subject to the mandatory live Registry freeze before publication.
- Protected Ground Station daemon/button bridge and FC-owned failsafe boundary remain unchanged.

## RC7 / Factory V77 acceptance rebuild
- V77 supersedes and rejects V76 after physical acceptance exposed three remaining blockers.
- Settings persistence is redesigned so telemetry/battery values save independently of viewport geometry, are durably written, and must pass server read-back verification before success is shown.
- When a telemetry profile is selected, Settings saves update that profile snapshot so a later reload cannot silently restore stale values.
- Cloud Registry V10 fixes the standalone Flight Log viewer runtime JavaScript defect and adds an explicit embedded-script syntax gate.
- Air Link workspaces are isolated: Connectivity owns the single Device connection editor; Media contains Camera controls only; the live-detail frame is filtered to the intended workspace.
- V76 desired-address persistence, non-blocking first render, Restart Majestic, Ext MAV pill removal, cloud profile deletion, and protected control/failsafe boundaries remain preserved.
- Native upgrade routes: exact RC6/V71 and exact RC7/V76, plus fresh install, subject to the mandatory live Registry freeze before publication.

## RC7 / Factory V78 Settings and workspace overhaul
- V78 supersedes and rejects V77 after physical acceptance showed that normal Settings-dialog changes still did not persist reliably.
- The final rendered Settings dialog now uses one queued verified persistence transaction for Enter, field blur, Done and close; edits arriving during an in-flight save are not dropped.
- Ordinary Settings save no longer autosaves the selected telemetry profile. Profiles own visual layout/view state while Battery/Smooth Voltage remains unit-global and profile application preserves it.
- Telemetry Columns and Font size now update their durable serialization baselines as well as visible group state; labels and units remain preserved.
- Air Link ownership is canonical and non-overlapping: Connectivity owns Device/Wi-Fi/diagnostics/full-device restart; Media owns Majestic camera/video settings and Restart Majestic. Legacy /wifilink2 redirects to the canonical workspace.
- Cloud Registry remains V10; factory browser acceptance must open a realistic RC6/schema-1 synchronized log from the standalone Registry into the analytical viewer.
- Native upgrade routes: exact RC6/V71 and exact RC7/V77 plus fresh install, subject to mandatory live Registry freeze before publication.

## RC7 / Factory V79 runtime fingerprint correction
- V79 supersedes and rejects V78 after native V77 -> V78 acceptance failed before deployment when /home/pi/siyi_gimbal_state.json.tmp appeared between external preflight and the inner canonical source check. Rollback completed.
- V79 treats only siyi_gimbal_state.json.tmp* as legitimate runtime atomic-write state. V71/V77 source verification normalizes that exact transient and narrowly retries the canonical fingerprint if it races verification; unrelated managed extras still fail.
- The complete V78 Settings-dialog overhaul, canonical non-duplicated Connectivity/Media Air Link workspaces, Cloud Registry V10, Flight Logs browser behavior and protected FC-owned safety/control boundary are retained unchanged.
