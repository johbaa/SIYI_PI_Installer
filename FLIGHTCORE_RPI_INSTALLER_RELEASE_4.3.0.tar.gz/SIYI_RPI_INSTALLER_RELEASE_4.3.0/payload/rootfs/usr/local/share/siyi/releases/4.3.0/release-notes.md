FlightCore 4.3.0 RC6 / Factory V71

RC6 / Factory V71 scope

- Retains all V70 fresh-install, one-touch, progress, handler-chain, RC6 feature and safety behavior.
- Retains exact RC4/V63 native Software Update compatibility.
- Corrects the Registry-required RC5 route after the real registered RC5/V5 unit resolved to exact Factory V64 bytes, while V70 had pinned only V65.
- RC5/V5 now accepts only exact published Factory V64 or Factory V65 cryptographic variants; every other RC5/V5 byte pattern is rejected.
- No Cloud Registry change or redeployment is required.

V70 external RC5 route failure

- Unit FC-96252C19BFD9 reported 4.3.0 / FLIGHTCORE_4_3_0_RELEASE_CANDIDATE_V5 / accepted.
- Exact server/payload/fingerprint matched published Factory V64 (canonical fingerprint 47d3286387958feb2f996615ee5002e7e2f8d7878465afac8f7c1d52c24b4183).
- V70 preflight rejected it because V70 expected only Factory V65 hashes. No upgrade was started and the unit was not modified.

Factory V71 correction

- Adds strict Factory V64 and V65 source variants under the same Registry RC5/V5 identity.
- Shared protected Ground Station daemon, button bridge, Registry client and Registry configuration hashes remain mandatory for both variants.
- RC5 source preflight records which exact variant was resolved so post-upgrade preservation evidence remains deterministic.
