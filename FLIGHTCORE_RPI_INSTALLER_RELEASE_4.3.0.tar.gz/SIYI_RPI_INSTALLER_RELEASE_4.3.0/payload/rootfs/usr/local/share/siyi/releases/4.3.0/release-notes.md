FlightCore 4.3.0 RC4 / Factory V63

- Moves profile management to a dedicated Settings -> Profiles tab; Telemetry has a dedicated Telemetry Layout heading.
- Selecting a profile applies immediately; local/cloud Import also applies immediately and uses the same authoritative selection path.
- Widget move/resize changes autosave the selected profile after an approximately 750 ms debounce.
- Profile restore is authoritative on reload for telemetry configuration, group geometry and overlays; newer Ground Station state is restored when present.
- Active profile selection is browser/client-specific: MacBook and Android can keep different active profiles while sharing the same profile library.
- After profile apply/reload, Settings returns to Profiles; clicking outside Settings closes the dialog.
- Older compatible snapshots remain usable for the fields they contain.
- Corrects RC3 fresh-install Device Registry fleet assignment with explicit one-time Fleet Join Codes; anonymous enrollment remains isolated until the user joins an existing fleet.
- Corrects the RC3 fresh-install UX baseline: the public GitHub macOS launcher confirms the Pi target, starts the commit-pinned installer and automatically opens the live port-8090 Progress WebUI before handoff to First Setup.
- System -> Documentation serves Release Notes, User Manual and Installation Guide locally.
- Upgrade-source pruning based on Device Registry membership is intentionally ON HOLD in RC4; the existing controlled upgrade source matrix is preserved.
- Preserves the protected Ground Station daemon, button bridge, Smooth Voltage, Wind Gust and FC-owned failsafe authority from RC3/V61.
