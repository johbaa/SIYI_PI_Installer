FlightCore 4.3.0 RC5 / Factory V64

RC5 scope
---------
- Fresh-install Progress WebUI: public launcher prestarts and verifies port 8090 before inner deployment, opens it on macOS, and refuses to continue silently if the progress service cannot start.
- Fleet Join: complete 18-character FCJ-XXXX-XXXX-XXXX input, non-consuming validation before commit, readable retry errors, and no ERR_EMPTY_RESPONSE on invalid/expired/used codes.
- Pre-registry migration UX: isolated units can Join existing fleet from System -> Registered Units without a terminal helper.
- Standalone Registry: administrator can generate a one-time 15-minute Fleet Join Code for the selected tenant/fleet.
- Registry presence: heartbeat reduced to 5 minutes and Cloud Registry online freshness reduced to approximately 15 minutes.

Compatibility and safety
------------------------
- Adds exact accepted RC4 / Factory V63 as a supported same-version candidate upgrade source while preserving the existing controlled source matrix.
- Upgrade-source pruning based on Device Registry membership remains ON HOLD.
- Protected Ground Station telemetry/control daemon and button bridge remain byte-identical to RC4/V63. Smooth Voltage and Wind Gust implementations remain unchanged.
- Flight-controller native failsafe authority remains unchanged; FlightCore does not force RTL/mode on joystick/GCS/link loss.
