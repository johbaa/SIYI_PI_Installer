# FlightCore 4.3.0 RC7 / Factory V74

## User-facing changes
- First Setup no longer contains or requires Hosts; zero Hosts is valid and optional external MAVLink destinations are configured later in Network - Hosts.
- The final Host can be deleted normally.
- Cloud telemetry profiles can be deleted with Registry tombstone tracking.
- Ground Station and Control Center use the FlightCore logo and dynamic RC7/V72 identity tooltip.
- Fresh-install browser/Terminal flow opens First Setup exactly once.

## Engineering / performance changes
- External Host, network and ZeroTier reachability moved out of the synchronous status-bar request path into a cached background service.
- Non-stream browser polling rates reduced; live telemetry remains on stream/WebSocket paths.
- Air Link First Setup performs an explicit post-reconnect health check.
- Native upgrade compatibility is Registry-derived: exact RC6/V71 for this candidate plus mandatory fresh install.

## RC7 / Factory V74 refinements
- Flight Logs viewer redesigned for selectable measures, meaningful unit-aware scales, secondary Y-axis for two unit groups, horizontal scrolling, timestamp axis, zoom/pan, tooltips, events, navigator, statistics and CSV export. Existing RC6 Flight Logs are rendered by the new viewer.
- Fixed Smooth Voltage settings persistence: battery calibration is unit-global and telemetry profiles can no longer overwrite resistance, cruise current, chemistry, cell count or voltage endpoints.

## RC7 / Factory V74 cloud additions
- Release Notes are available from the standalone FlightCore Cloud page.
- Cloud Last seen and related timestamps are displayed as YYYY-MM-DD HH:mm with an explicit browser-timezone label; stored source timestamps remain UTC.
- Full completed Flight Logs are tenant-scoped in cloud object storage with D1 metadata and use the complete RC7 interactive viewer.
- A separate low-priority sync service uploads finalized logs only while disarmed and backfills compatible existing RC6 logs; cloud failure remains non-critical.
