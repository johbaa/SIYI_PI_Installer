# FlightCore 4.3.0 RC1 / Factory V59

## RC1 changes

- **Wind Gust telemetry**: adds a selectable display-only telemetry value `Wind Gust`, derived only from the incoming ArduPlane horizontal wind estimate. It has zero influence on aircraft control, modes, failsafes, throttle, navigation or flight-controller parameters.
- Gust detector V1 uses a 0.50 s fast filter, 30 s background baseline, threshold `max(1.0 m/s, 20% of background wind)`, 0.75 s persistence/credibility, candidate-peak capture from threshold onset and a 10 s peak hold. When no validated recent gust exists the telemetry tile shows `-`.
- A stronger validated gust during the hold replaces the displayed peak and restarts the 10 s timer. Single spikes, weak fluctuations, stale-source candidate continuation and pure direction reversals are rejected toward no gust.
- Detector diagnostics retain fast/background wind, delta, threshold, candidate peak/state and hold time in the Ground Station state for controlled and flight validation. Initial tuning constants remain code-tunable pending flight evidence.
- Device Registry V2: FlightCore 4.3.0+ performs zero-touch self-enrollment after transactional post-reboot acceptance and receives a unique per-device credential. No universal fleet write secret is embedded.
- Registered units support a cloud-persistent **Nice name** that is independent of the Linux hostname.
- Registry administrators can delete units. Deletion removes current state, history and the device credential and leaves a tombstone so an active deleted Unit ID cannot silently auto-register again.
- System -> Registered Units uses the unit's unique credential for fleet reads; the separate `READ_TOKEN` remains the administrator credential for standalone fleet management, cross-unit rename and delete.
- Fresh installs and supported upgrades from exact 4.2.2 RC13 and accepted 4.2.3 RC5/RC10/RC11/RC12/RC13 automatically create/preserve the permanent Unit ID and enroll after successful post-reboot acceptance.
- Registry activation remains non-critical and cannot block Ground Station, MAVLink, joystick, video or aircraft operation.
- Smooth Voltage/Battery %, joystick/GCS-loss authority, gimbal transport and button-bridge behavior are intentionally unchanged. The Ground Station daemon changes only to add the display-only Wind Gust estimator/output.

## Factory lineage

Factory V59 supersedes the pre-physical-use V58 package by adding Wind Gust before RC1 is put into service. Controlled parent remains exact FlightCore 4.2.3 RC13 / Factory V57 inner archive SHA256 `efd301dc49d235f0497389955ecf6513af044ad361357fb71d67fcb40436eb40`.

## Wind Gust initial validation targets

- No event from a single isolated spike or steady/weakly noisy wind.
- Multi-second controlled gust detection latency approximately 0.5-1.5 s from the wind estimate arriving at FlightCore.
- Displayed event peak target within approximately 0.2-0.5 m/s of the incoming ArduPlane wind-estimate peak.
- Peak holds approximately 10 s, then returns to `-`; stale wind data cannot create a gust.

# FlightCore 4.2.3 RC13 / Factory V57

## RC13 changes
- WebUI Software Update clears/suppresses stale previous-run completion/failure state immediately when a new upgrade is requested.
- Fresh install progress WebUI V2: progress URL is logged, the supplied Mac launcher opens it automatically, and successful completion transitions the open browser to First Setup after reboot.
- Device Registry V1: stable `/etc/flightcore/device-id`, boot registration + 5-minute heartbeat service/timer, System -> Registered Units, and a Cloudflare Worker/D1 standalone fleet registry deployment pack.
- Device Registry is cloud-noncritical and explicitly excludes aircraft location, continuous flight telemetry, logs, video, Wi-Fi passwords, ZeroTier secrets/private keys, and flight-controller parameters.
- RC12 Smooth Voltage low-current fade/rest convergence and monotonic no-rise invariant are unchanged.
- RC12, RC11, RC10, RC5 and canonical 4.2.2 RC13 source routes remain supported under their exact identity gates.

# FlightCore 4.2.3 RC12 / Factory V56

RC12 is built from the accepted RC11/V55 release line plus the physically accepted First Setup P17/P18 corrections, the P19 telemetry-profile placement continuation, and one deliberately narrow Smooth Voltage refinement.

## RC12 changes
- First Setup: an offline optional Air Link can no longer abort Save; delayed ZeroTier managed-IP assignment is reconciled after the synchronous setup attempt; the camera managed route is rewritten and verified through the current Pi before setup is marked complete; saved Host name/IP are rendered when the wizard is reopened.
- Telemetry profile Apply: the named profile snapshot remains authoritative after reload for telemetry-group geometry and overlay placement, preventing startup persistence from replacing imported placement.
- Smooth Voltage low-current refinement: current >=3 A is unchanged from RC11. After 4 continuous seconds below 3 A, the applied compensation fades smoothly from 100% at 3 A to 0% at <=1 A. Confirmed low-current Raw may pull Smooth gently downward with a 5-second time constant.
- Smooth Voltage session invariant: after initial acquisition, Smooth Voltage can hold or decrease only; it can never move upward.
- Raw FC voltage, FC battery warnings/failsafes, joystick/GCS-loss policy, gimbal transport, button bridge and flight-mode authority are unchanged.

## Supported routes
- Fresh Raspberry Pi OS 64-bit / Debian 13 -> 4.2.3 RC12.
- Exact accepted 4.2.2 RC13 -> RC12.
- Exact accepted 4.2.3 RC5 / Factory V47 -> RC12 with `--repair`.
- Exact FlightCore 4.2.3 RC10 / Factory V52 pristine or accepted P16 -> RC12 with `--repair`.
- Exact accepted FlightCore 4.2.3 RC11 / Factory V55 pristine or exact P17/P18/P19 continuation -> RC12 with `--repair`.

## Acceptance status at factory handover
Factory/offline validation must prove deterministic packaging, exact source gates, protected button/failsafe behavior, unchanged >=3 A Smooth Voltage behavior, monotonic output, and low-current convergence. Physical RC12 upgrade and flight/bench confirmation remain acceptance gates.

# FlightCore 4.2.3 RC7 / Factory V49

RC7 is a correction candidate built from exact RC6 / Factory V48. It addresses the RC6 physical findings: Air Link apply/recovery, dual-Ground-Station video load and stale-live latency recovery, telemetry editor movement, cross-host telemetry geometry/profile usability, Parameters group scrolling, loaded-session connection banner overlap, and Mac top-banner parity.

Protected behavior is intentionally unchanged: the Ground Station daemon (including Smooth Voltage anti-drift/rest-anchor and consumed-mAh reconnect guard), joystick/button bridge, gimbal transport, and Pi/FC failsafe boundary are carried forward byte-for-byte.

# FlightCore 4.2.3 RC6 — Factory V48

Controlled parent: FlightCore 4.2.3 RC5 / Factory V47, itself derived through the accepted 4.2.2 RC13 release line. Production upgrade source remains exact accepted 4.2.2 RC13.

## RC6 fixes
- Smooth Voltage anti-drift: preserve correct takeoff/early-cruise sag compensation, prevent time-accumulated positive cruise drift, and converge to measured Raw voltage at genuine disarmed/low-load rest. User settings remain 75 mΩ and 6 A for the validated aircraft setup.
- Remove pilot-facing Smooth Voltage `LIMIT` text while retaining the internal correction safety clamp.
- Air Link settings apply/reconnect/restart now signals already-loaded Ground Stations to recreate the Air Link WHEP session automatically; no Ground Station reload should be required.
- Telemetry editor drag made robust; named telemetry profiles preserve groups, contents, columns, font size and placement and are reusable across hosts on the same Pi; JSON export/import supports transfer across Pi systems.
- Telemetry geometry keeps a last-known-complete backup and repairs only accidentally missing geometry fields for groups that still exist.
- ArduPlane Parameter Groups gets its own scrollbar; obsolete phone drawer X removed.
- Loaded-session disconnect/reconnect: keep receivers alive/retrying, show disconnected top-bar state, announce regained connection, restart visible video, and guard consumed mAh against reconnect-to-zero artifacts.
- Mac/Android top-bar visual parity; Map top button is hidden while a joystick is connected.
- System-wide generic branding audit: product-facing generic SIYI naming is replaced by FlightCore while real SIYI hardware/protocol and internal compatibility identifiers remain.

## Protected unchanged behavior
- Joystick/GCS/link loss never makes the Pi command RTL or force flight mode; MANUAL_CONTROL/source-255 heartbeat withdrawal leaves failsafe authority to the flight controller.
- RC7-style gimbal command transport/passive feedback remains protected.
- RC12/RC13 Ground Station load bounds and telemetry proxy behavior remain protected.
- Raw FC battery voltage remains safety-authoritative; Smooth Voltage/Battery % are display/voice only.
- RC5 silent WHEP-maintenance behavior and 10-second confirmed NO VIDEO threshold remain intact.

## Supported routes
- Fresh Raspberry Pi OS 64-bit / Debian 13 -> 4.2.3 RC6.
- Exact accepted 4.2.2 RC13 -> 4.2.3 RC6 native transactional upgrade.

## Acceptance status at factory handover
Extensive offline factory/static/regression validation must pass before handover. Hardware-dependent Air Link, Android/Mac reconnect, fresh-SD and flight checks remain physical RC acceptance gates and are not claimed by offline validation.


# FlightCore 4.2.3 RC8 — Factory V50

- Branding-clean public release artifact names and public manifest identity.
- Verified migration path from non-brand-clean 4.2.3 RC6/RC7 via same-version repair.
- Telemetry profile lifecycle: obvious New profile action, Delete, reliable Apply/active state, and cross-host telemetry-value content.
- Removed Share current / Use shared and obsolete Move / resize group UI.
- Telemetry geometry v5 uses available-travel normalization on non-sticky axes to survive fullscreen/viewport changes.
- Removed RC7 dual-Ground-Station secondary-video pause policy; both visible streams remain available to both hosts.
- Loaded-session connection-loss state and full reconnect recovery corrected.
- Parameters group scrollbar bounded to the actual viewport.
- Control Center heading/footer expose only `Release Candidate 8` on mouse hover.


# FlightCore 4.2.3 RC9 — Factory V51

- Fix telemetry groups snapping/bouncing back while being moved. Live drag coordinates are authoritative; persistence is applied only at initialization and stable viewport transitions.
- Geometry schema v6 preserves proportional position on non-sticky axes and true edge stickiness across fullscreen/viewport changes.
- Fix ArduPlane Parameters scrolling with a single viewport-bounded desktop/tablet pane and independent scroll containers for Parameter Groups and parameter results.
- Prevent host `pip` configuration (including unreachable piwheels indexes) from multiplying upgrade time: dependency install uses explicit PyPI with bounded retries/timeouts.
- Preserve the physically accepted RC8 Ground Station disconnect/reconnect recovery unchanged.
- Control Center heading/footer hover now reports `Release Candidate 9`.

Physical telemetry profile/content tests blocked by the RC8 positioning defect remain pending until RC9 hardware/UI verification. Fresh-install-only acceptance remains pending separately.


# FlightCore 4.2.3 RC10 — Factory V52

- Integrates the physically accepted telemetry-profile content Apply fix as a server-atomic transaction with stale-write protection.
- Integrates the physically accepted final Parameters layout: responsive browser-height shell, no whole-page scrollbar, independent left group and right parameter-list scrollbars.
- Retains accepted telemetry geometry-v6 stabilization guards.
- Removes visible “Tap to swap” wording from the camera PiP while retaining swap behavior.
- Native same-version RC9 → RC10 upgrade accepts pristine RC9 or the exact physically accepted RC9 P13 live-patched server.


# FlightCore 4.2.3 RC11 — Factory V54

- Exact target parent remains FlightCore 4.2.3 RC10 / Factory V52. Factory V54 adds a strict native same-version upgrade route from exact accepted 4.2.3 RC5 / Factory V47, while retaining pristine RC10 and exact RC10 P16 continuation.
- RC5 admission is exact-source gated by accepted status, server/daemon/button-bridge/payload-manifest hashes and canonical source fingerprint verification; arbitrary 4.2.3 candidate states remain refused.
- Cleanly integrates the RC10 P1–P16 field patch result without shipping the live Python wrapper chain; superseded P8/P9 interaction layers are omitted.
- Restores explicit Connect for every inactive configured Pi Wi-Fi profile, including system/netplan-managed profiles.
- Retains accepted telemetry geometry-v6 ownership guards and server-atomic telemetry-profile Apply behavior.
- Ground Station configuration is consolidated into one movable/resizable Settings dialog with General, Telemetry, Battery, Joystick and Audio tabs. Double-clicking a telemetry group opens Settings → Telemetry for that group.
- Settings movement/resizing uses a lightweight proxy during the gesture and commits real geometry once on release; Android opening/dragging keeps the title below the actual top banner.
- General adds persistent Settings opacity. Audio default-ON and harmonized Voice Alerts second-view behavior are retained.
- Joystick Settings is disabled when no joystick is connected; a read-only Joystick top pill reports green connected/red disconnected. Flight-mode status uses matching green/red status treatment.
- Android uses the same vertical side Settings tabs as desktop. Telemetry/Data uses native pan-y/momentum scrolling on touch devices; Mac mouse-wheel Data scrolling is retained.
- Obsolete “independent groups”, Settings close-X and move/resize helper text are removed.
- Battery % uses session-only startup detection: >0–14 V = 3S, 15–28 V = 6S. Its effective 100% V/cell is max(user-defined, detected startup V/cell); detected values affect Battery % only and are never written to Settings or persisted.
- Automatic/default fullscreen remains deferred to a later sprint.
- Protected Ground Station daemon, button bridge, gimbal transport and FC-native failsafe boundary remain unchanged.

# FlightCore 4.2.3 RC11 — Factory V55

- Supersedes rejected Factory V54. V54 failed an actual RC10 + accepted P16 -> RC11 native upgrade at 6% before target deployment because `/etc/siyi/joystick.json` was represented as a symlink in `payload-manifest.json` without its required `sha256` field.
- V55 restores the canonical symlink manifest representation: target `joystick.d/joystick.json`, size `0`, and SHA256 of the symlink target string.
- Factory validation now rejects any managed file/symlink entry that lacks its required checksum and verifies every symlink target/checksum against the staged payload.
- RC11 runtime `server.py`, protected Ground Station daemon, protected button bridge, accepted RC5 route, RC10/P16 route, canonical 4.2.2 RC13 route and clean fresh-SD path are otherwise unchanged.
