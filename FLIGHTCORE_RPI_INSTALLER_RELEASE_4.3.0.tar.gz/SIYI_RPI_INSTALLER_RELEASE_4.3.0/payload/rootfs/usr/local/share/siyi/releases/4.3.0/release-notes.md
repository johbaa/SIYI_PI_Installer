FlightCore 4.3.0 RC6 / Factory V68

RC6 / Factory V68 scope
- Retains the complete RC6 user scope: Airspeed Sensor status pill and visibility setting, airspeed lost/restored voice, once-per-boot GPS fix voice, Smooth Voltage Raw fallback while airspeed health is not confirmed, five-second healthy reacquisition, automatic Flight Logs V1, cached ARM/DISARM parameter snapshots/diff, System -> Flight Logs, Wind/Wind Gust, Profiles, Device Registry and locally served documentation.
- Retains Factory V65 fresh-install/First Setup/Fleet Join corrections, 5-minute Registry heartbeat, Cloud V6 approximately 15-minute online freshness and the canonical port-8090 installer Progress WebUI path.
- Retains strict checksum-pinned native Software Update routes from the Registry-required exact RC4 / Factory V63 and RC5 / Factory V65 source identities plus clean fresh installation.

Factory V68 correction
- Factory V67 is superseded after genuine fresh-install acceptance reached the port-8090 Progress WebUI but the normal port-8080 WebUI / First Setup path failed.
- Evidence showed server request fall-through repeatedly cycling through older RC handler wrappers until Python raised RecursionError: maximum recursion depth exceeded.
- Root cause: the 4.3.0 RC6 server extension reused private _fc6_* predecessor/wrapper globals already used by the older 4.2.3 RC6 server layer. Later global rebinding could therefore redirect older fallback functions back into the chain.
- Factory V68 gives the complete current RC6 server extension a release-unique _fc430rc6_* / FC430RC6_* namespace, including GET, POST, Ground Station page, Documentation page and helper state.
- Factory regression now rejects duplicate predecessor/wrapper names and exercises GET/POST fall-through plus /first_setup and RC6-specific routes.
- No Ground Station daemon, protected button bridge, Device Registry client/config, Cloud V6, Smooth Voltage, Wind/Wind Gust, joystick/control or FC-native failsafe-authority change.

Acceptance status
- Factory V68 requires its own 15/15 factory PASS on final packaged bytes.
- Publication verification, genuine fresh-SD install via the canonical V68 Mac launcher, browser auto-open, port-8090 live progress, port-8080 /first_setup, post-fresh validation, both RC4 and RC5 native WebUI upgrade routes, normal physical regression and required flight acceptance remain external gates.
