FlightCore 4.3.0 RC3 / Factory V61

- Adds System -> Documentation with locally bundled Release Notes and User Manual.
- Adds Cloud Registry V4 tenant isolation: normal device credentials are fleet/tenant scoped; READ_TOKEN remains global administrator authority.
- Registered Units can manage any unit within the authorized tenant.
- Telemetry Profile UI uses Save / Apply / Import / Export / Done and selectable cloud imports.
- Ground Station top-left identity shows FlightCore 4.3.0 RC3 / Factory V61.
- Fresh-install port-8090 progress -> /first_setup is an RC3 acceptance gate.
- Preserves protected Ground Station daemon, button bridge, Smooth Voltage, Wind Gust and FC-owned failsafe authority.
