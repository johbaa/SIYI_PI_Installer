FlightCore 4.3.0 RC6 / Factory V66

RC6 / Factory V66 scope
------------------------
- Airspeed health: new top-banner ARSP status pill (OK / FAIL / Off-Checking) based on configured sensor detection and live MAVLink differential-pressure health. The pill has a user visibility toggle, default ON; hiding it does not disable monitoring.
- Airspeed voice: announces "Airspeed sensor lost" and "Airspeed sensor restored" on health transitions. FlightCore remains warning/display only and never changes flight mode.
- Smooth Voltage guard: when an expected airspeed sensor is missing or unhealthy, Smooth Voltage becomes invalid and reports Raw Voltage; Battery % and voltage voice use Raw. After recovery, five continuous healthy seconds are required before Smooth reacquires.
- Flight Logs V1: automatic arm/disarm flight records with buffered 2 Hz telemetry samples, event timeline, sensor/connection/STATUSTEXT events, and System -> Flight Logs review with synchronized key graphs.
- Parameter snapshots: complete cached FC parameter snapshot at ARM and DISARM with automatic diff. No full parameter sweep is requested over MAVLink while armed.
- GPS voice: "GPS fix acquired" once per FlightCore/Pi boot when fix type is 3D or better and satellite count reaches 7 or more. It does not repeat after later drop/recovery.
- Performance invariant: logging consumes existing telemetry, uses buffered file writes, and introduces no new high-rate MAVLink requests or flight-control commands.

Compatibility and carried-forward RC5 fixes
------------------------------------------
- Exact accepted RC4 / Factory V63 remains the controlled parent and supported same-version candidate source. The existing controlled upgrade matrix is retained; Registry-driven pruning remains ON HOLD.
- Carries the V65 Progress WebUI state-handoff/macOS auto-open correction, full 18-character Fleet Join validation, direct Fleet Join, 5-minute Registry heartbeat, approximately 15-minute Cloud online window, standalone join-code creation, and transactional First Setup handling.
- Wind Gust, protected button bridge, gimbal transport, joystick/GCS-loss authority boundary, and core RC12 Smooth algorithm remain otherwise unchanged.

Inherited RC5 / Factory V65 notes
---------------------------------
RC5 / Factory V65 scope
------------------------
- Fresh-install Progress WebUI: public launcher prestarts and verifies port 8090 before inner deployment, opens it on macOS, and refuses to continue silently if the progress service cannot start.
- Fleet Join: complete 18-character FCJ-XXXX-XXXX-XXXX input, non-consuming validation before commit, readable retry errors, and no ERR_EMPTY_RESPONSE on invalid/expired/used codes.
- Pre-registry migration UX: isolated units can Join existing fleet from System -> Registered Units without a terminal helper.
- Standalone Registry: administrator can generate a one-time 15-minute Fleet Join Code for the selected tenant/fleet.
- Registry presence: heartbeat reduced to 5 minutes and Cloud Registry online freshness reduced to approximately 15 minutes.

Compatibility and safety
------------------------
- Adds exact accepted RC4 / Factory V63 as a supported same-version candidate upgrade source while preserving the existing controlled source matrix.
- Upgrade-source pruning based on Device Registry membership remains ON HOLD.
- Protected Ground Station telemetry/control daemon and button bridge remain byte-identical to RC4/V63. Smooth Voltage and Wind Gust implementations remain unchanged.
- Flight-controller native failsafe authority remains unchanged; FlightCore does not force RTL/mode on joystick/GCS/link loss.

Factory V65 fresh-install acceptance corrections
------------------------------------------------
- Supersedes Factory V64 after physical fresh-install testing exposed two installer UX defects and one First Setup HTML validation defect.
- Preserves the bootstrap Progress WebUI state path across the inner installer's sudo/root handoff, so the browser page receives the same live progress state that the terminal installer is advancing.
- The canonical macOS launcher uses a checked /usr/bin/open request once the live /state endpoint is reachable; physical acceptance still requires the browser to open automatically.
- Escapes the Fleet Join HTML regex quantifiers correctly inside the Python f-string, so a valid 18-character code such as FCJ-7724-0BB2-2B2D passes browser-side validation and reaches the backend.
