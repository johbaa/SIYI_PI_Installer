# FlightCore 4.3.0 RC7 / Factory V74

## User-facing changes
- First Setup no longer contains or requires Hosts; zero Hosts is valid and optional external MAVLink destinations are configured later in Network - Hosts.
- The final Host can be deleted normally.
- Cloud telemetry profiles can be deleted with Registry tombstone tracking.
- Ground Station and Control Center use the FlightCore logo and dynamic RC7/V72 identity tooltip.
- Fresh-install browser/Terminal flow opens First Setup exactly once.

## Engineering / performance changes
- External Host, network and ZeroTier reachability moved out of the synchronous status-bar request path into a cached background service.
- Non-stream browser polling rates reduced; live telemetry remains on stream/WebSocket paths.
- Air Link First Setup performs an explicit post-reconnect health check.
- Native upgrade compatibility is Registry-derived: exact RC6/V71 for this candidate plus mandatory fresh install.

## RC7 / Factory V74 refinements
- Flight Logs viewer redesigned for selectable measures, meaningful unit-aware scales, secondary Y-axis for two unit groups, horizontal scrolling, timestamp axis, zoom/pan, tooltips, events, navigator, statistics and CSV export. Existing RC6 Flight Logs are rendered by the new viewer.
- Fixed Smooth Voltage settings persistence: battery calibration is unit-global and telemetry profiles can no longer overwrite resistance, cruise current, chemistry, cell count or voltage endpoints.

## RC7 / Factory V74 cloud additions
- Release Notes are available from the standalone FlightCore Cloud page.
- Cloud Last seen and related timestamps are displayed as YYYY-MM-DD HH:mm with an explicit browser-timezone label; stored source timestamps remain UTC.
- Full completed Flight Logs are tenant-scoped in cloud object storage with D1 metadata and use the complete RC7 interactive viewer.
- A separate low-priority sync service uploads finalized logs only while disarmed and backfills compatible existing RC6 logs; cloud failure remains non-critical.

## RC7 / Factory V75 provenance and compatibility correction
- V75 supersedes V74 after post-upgrade evidence proved accepted history omitted source_build.
- Accepted history now persists source_release, source_build and source_variant before the transaction directory is removed.
- V75 supports strict native WebUI upgrade from the exact Registry-represented RC6/V71 and RC7/V74 identities, plus fresh install.
- V75 uses updater-visible unique build ID `FLIGHTCORE_4_3_0_RELEASE_CANDIDATE_V7_FACTORY_V75` so V74 can discover the V75 update despite both remaining 4.3.0 RC7.
- Ground Station Android branding is compact while keeping the FlightCore logo at the far left and an explicit gap between the left and right pill groups.
- Local and cloud profile deletion now presents a selection list.
- Ground Station -> Control Center uses a native same-origin link to remove the newly observed handoff delay.
- The confirmed V74 battery/profile error `name 'copy' is not defined` is fixed by importing Python `copy` and regression-testing the affected endpoints.
- Release Notes are ordered newest version/RC first, then descending.
- Cloud remains schema V8; the V75 handoff refreshes Release Notes in R2 without rerunning migration 0007.

## RC7 / Factory V76 consolidated physical-acceptance rebuild
- V76 supersedes V75.
- Air Link desired RTSP configuration persists even when live validation fails; initial Air Link UI is non-blocking and Restart Majestic is explicitly restored.
- Battery/Smooth Voltage settings use independent unit-global persisted authority and are preserved across telemetry-profile operations.
- Ext MAV reachability pill is removed while optional external MAVLink destinations remain functional.
- Cloud V9 requires telemetry-profile tombstone migration and adds RC6 Flight Log compatibility/error handling.
- Native upgrade routes: exact RC6/V71 and exact RC7/V75, plus fresh install, subject to the mandatory live Registry freeze before publication.
- Protected Ground Station daemon/button bridge and FC-owned failsafe boundary remain unchanged.
