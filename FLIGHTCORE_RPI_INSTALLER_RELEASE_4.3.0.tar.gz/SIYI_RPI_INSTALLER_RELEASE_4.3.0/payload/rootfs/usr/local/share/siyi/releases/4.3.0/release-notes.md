FlightCore 4.3.0 RC6 / Factory V70

RC6 / Factory V70 scope
- Retains the complete RC6 user/runtime scope: Airspeed Sensor status and voice, GPS fix voice, Smooth Voltage Raw fallback/reacquisition, Flight Logs V1, Wind/Wind Gust, Profiles, Device Registry, locally served documentation and FC-native failsafe authority.
- Retains the V65 fresh-install/First Setup/Fleet Join corrections, V67 Registry-required exact RC4/V63 + RC5/V65 native Software Update compatibility, the V68 release-unique server handler namespace correction, and V69 one-touch/progress synchronization.
- Cloud Registry V6, Registry schema/API, Ground Station daemon, protected button bridge, Registry client/config and protected flight-control behavior are unchanged.

Factory V69 physical failure retained
- The normal-user one-touch command reached target selection and SSH availability, but authentication stopped with REMOTE HOST IDENTIFICATION HAS CHANGED when the freshly reimaged Pi reused an IP that already had an older key in the Mac known_hosts file.
- No separate ssh-keygen recovery command is acceptable for normal-user or RC fresh-install flow. V69 is superseded.

Factory V70 fresh-install correction
- The normal-user one-touch GitHub command itself is unchanged.
- After Pi IP/user selection, the public macOS launcher automatically runs ssh-keygen -R for the confirmed Pi IP before the first authenticated SSH connection, then continues through the same temporary ControlMaster session.
- Users therefore do not need a second Terminal command after reimaging a Pi that keeps the same IP address.
- V69 automatic :8090 opening, live elapsed time, synchronized live percentage/activity and automatic /first_setup handoff are retained.
- Factory regression requires stale-host-key cleanup to be present and ordered before ControlMaster authentication, and exercises a synthetic known_hosts removal case plus a negative fixture.

Acceptance status
- Factory V70 requires its own 15/15 factory PASS on final packaged bytes.
- External gates remain: immutable publication verification, genuine fresh-SD preflight, fresh install using the documented unchanged one-touch GitHub command with automatic stale-host-key recovery/:8090 open/live progress/live elapsed/synchronized percentage, :8080 /first_setup, post-fresh validation, exact RC4/V63 and RC5/V65 native WebUI upgrade routes, physical regression and required flight acceptance.
