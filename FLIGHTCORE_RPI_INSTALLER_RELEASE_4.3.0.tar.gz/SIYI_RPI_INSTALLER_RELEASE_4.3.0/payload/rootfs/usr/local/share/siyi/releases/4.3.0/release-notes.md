# FlightCore 4.3.0 RC2 / Factory V60

Controlled parent: 4.3.0 RC1 / Factory V59.

RC2 scope:
- Telemetry profile export/import: local disk or authenticated Cloudflare/D1 cloud storage.
- Fresh-install port-8090 progress UI starts earlier and the Mac launcher auto-opens it.
- Air Link First Setup shows only enable + camera IP; hidden defaults root/12345, TCP, latency 0, stream=0.
- Correct Control Center header/footer hover identity.
- Fresh-install Registry fleet read works with the unique per-device token (root:pi 0640).
- Fresh Air Link setup restarts Majestic automatically and verifies RTSP/route.

Protected joystick/GCS-loss, gimbal, Smooth Voltage/Battery, Wind Gust and telemetry placement behavior are retained from RC1.
