FlightCore 4.3.0 RC6 / Factory V69

RC6 / Factory V69 scope
- Retains the complete RC6 user/runtime scope: Airspeed Sensor status and voice, GPS fix voice, Smooth Voltage Raw fallback/reacquisition, Flight Logs V1, Wind/Wind Gust, Profiles, Device Registry, locally served documentation and FC-native failsafe authority.
- Retains the V65 fresh-install/First Setup/Fleet Join corrections, V67 Registry-required exact RC4/V63 + RC5/V65 native Software Update compatibility, and the V68 release-unique server handler namespace correction.
- Cloud Registry V6, Registry schema/API, Ground Station daemon, protected button bridge, Registry client/config and protected flight-control behavior are unchanged.

Factory V69 fresh-install correction
- The normal user fresh-installs from the public GitHub publication with one copy/paste/Enter Terminal command. No separate .command download is required for normal use.
- The public macOS launcher asks for Pi IP and SSH user, waits for SSH, authenticates normally through OpenSSH, then reuses a temporary authenticated ControlMaster session. No hard-coded Pi password is required by the public path.
- The launcher resolves and pins the current immutable GitHub main commit before starting the Pi installer and automatically requests the port-8090 Progress WebUI when /state becomes reachable.
- Terminal progress and the port-8090 Progress WebUI now use one authoritative live progress/activity state. Every progress render publishes the current percentage and elapsed_seconds, so the browser follows the same live percentage/activity rather than stage-only snapshots.
- The Progress WebUI shows live elapsed installation time and continues to transition to /first_setup after successful install/reboot.
- Failure publication stops the progress animator first so a background progress tick cannot overwrite failed state.

V68 physical evidence retained
- Port 8090 ran and showed relevant activity; activity label aligned.
- Port 8080 First Setup Wizard was reached and auto-opened, confirming the V68 handler-recursion correction.
- Live elapsed time was absent and WebUI percentage was not aligned to the Terminal animation.
- Port-8090 auto-open was not validly tested because the canonical Mac launcher/log path was not used in that run.

Acceptance status
- Factory V69 requires its own 15/15 factory PASS on final packaged bytes.
- External gates remain: immutable publication verification, genuine fresh-SD preflight, fresh install using the documented one-touch GitHub command with automatic :8090 open/live progress/live elapsed/synchronized percentage, :8080 /first_setup, post-fresh validation, exact RC4/V63 and RC5/V65 native WebUI upgrade routes, physical regression and required flight acceptance.
