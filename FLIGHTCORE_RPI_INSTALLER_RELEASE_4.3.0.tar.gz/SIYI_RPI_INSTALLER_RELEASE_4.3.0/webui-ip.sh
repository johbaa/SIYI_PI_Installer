#!/usr/bin/env bash
# SIYI_4_2_1_WEBUI_URL_SELECTION_V1
# Functions only. This file is sourced by the release installer.

_siyi_route_source_ipv4() {
  local destination="${1:-}"
  [ -n "$destination" ] || return 1
  ip -4 route get "$destination" 2>/dev/null | awk '
    { for (i=1; i<=NF; i++) if ($i=="src" && (i+1)<=NF) { print $(i+1); exit } }
  '
}

_siyi_camera_ipv4() {
  local value="${SIYI_CAMERA_ETH_IP:-}" config="${SIYI_CONFIG_PATH:-/home/pi/siyi-config.json}"
  if [ -z "$value" ] && [ -f "$config" ]; then
    value="$(python3 - "$config" <<'PYWEB'
import json,sys
try:
    value=str(json.load(open(sys.argv[1],encoding='utf-8')).get('camera_eth_ip','')).strip()
except Exception:
    value=''
print(value)
PYWEB
)"
  fi
  value="${value%%/*}"
  printf '%s\n' "$value"
}

_siyi_usable_webui_ipv4() {
  local value="${1:-}" camera="${2:-}"
  [[ "$value" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] || return 1
  case "$value" in
    0.0.0.0|255.255.255.255|127.*|169.254.*) return 1 ;;
  esac
  [ -z "$camera" ] || [ "$value" != "$camera" ] || return 1
  return 0
}

siyi_capture_install_route_context() {
  if [ -z "${SIYI_INSTALL_SSH_CONNECTION:-}" ] && [ -n "${SSH_CONNECTION:-}" ]; then
    SIYI_INSTALL_SSH_CONNECTION="$SSH_CONNECTION"
  fi
  if [ -z "${SIYI_INSTALL_ROUTE_IP:-}" ] && [ -n "${SIYI_INSTALL_SSH_CONNECTION:-}" ]; then
    local client route_ip
    client="$(printf '%s\n' "$SIYI_INSTALL_SSH_CONNECTION" | awk '{print $1}')"
    route_ip="$(_siyi_route_source_ipv4 "$client" || true)"
    if [[ "$route_ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]]; then
      SIYI_INSTALL_ROUTE_IP="$route_ip"
    fi
  fi
  export SIYI_INSTALL_SSH_CONNECTION="${SIYI_INSTALL_SSH_CONNECTION:-}"
  export SIYI_INSTALL_ROUTE_IP="${SIYI_INSTALL_ROUTE_IP:-}"
}

siyi_select_primary_webui_ip() {
  local camera client candidate line addr
  camera="$(_siyi_camera_ipv4)"

  candidate="${SIYI_INSTALL_ROUTE_IP:-}"
  if _siyi_usable_webui_ipv4 "$candidate" "$camera"; then
    printf '%s\n' "$candidate"
    return 0
  fi

  if [ -n "${SIYI_INSTALL_SSH_CONNECTION:-${SSH_CONNECTION:-}}" ]; then
    client="$(printf '%s\n' "${SIYI_INSTALL_SSH_CONNECTION:-${SSH_CONNECTION:-}}" | awk '{print $1}')"
    candidate="$(_siyi_route_source_ipv4 "$client" || true)"
    if _siyi_usable_webui_ipv4 "$candidate" "$camera"; then
      printf '%s\n' "$candidate"
      return 0
    fi
  fi

  candidate="$(_siyi_route_source_ipv4 1.1.1.1 || true)"
  if _siyi_usable_webui_ipv4 "$candidate" "$camera"; then
    printf '%s\n' "$candidate"
    return 0
  fi

  while IFS= read -r line; do
    addr="$(printf '%s\n' "$line" | awk '{print $4}')"
    addr="${addr%%/*}"
    if _siyi_usable_webui_ipv4 "$addr" "$camera"; then
      printf '%s\n' "$addr"
      return 0
    fi
  done < <(ip -o -4 addr show scope global 2>/dev/null || true)

  printf '%s.local\n' "$(hostname -s 2>/dev/null || hostname)"
}
